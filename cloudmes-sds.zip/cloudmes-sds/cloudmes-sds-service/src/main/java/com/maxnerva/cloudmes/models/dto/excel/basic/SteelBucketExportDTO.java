package com.maxnerva.cloudmes.models.dto.excel.basic;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.excel.converter.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @ClassName SteelBucketExportDTO
 * @Description TODO
 * @Author Likun
 * @Date 2024/10/28
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("托盘信息导出DTO")
@Data
public class SteelBucketExportDTO {

    @ApiModelProperty(value = "组织")
    @ExcelProperty(value = "组织", index = 0)
    private String orgCode;

    @ApiModelProperty(value = "托盘编码")
    @ExcelProperty(value = "托盘编码", index = 1)
    private String bucketNo;

    @ApiModelProperty(value = "托盘类别名称")
    @ExcelProperty(value = "托盘类别", index = 2)
    private String bucketTypeName;

    @ApiModelProperty(value = "托盘重量")
    @ExcelProperty(value = "托盘重量", index = 3)
    private BigDecimal bucketWeight;

    @ApiModelProperty(value = "单位")
    @ExcelProperty(value = "单位", index = 4)
    private String uom;

    @ApiModelProperty(value = "承重下限")
    @ExcelProperty(value = "承量下限", index = 5)
    private BigDecimal weightLow;

    @ApiModelProperty(value = "承重上限")
    @ExcelProperty(value = "承重上限", index = 6)
    private BigDecimal weightUp;

    @ApiModelProperty(value = "是否启用")
    @ExcelProperty(value = "是否启用", index = 7)
    private String isEnable;

    @ApiModelProperty(value = "长")
    @ExcelProperty(value = "长", index = 8)
    private BigDecimal length;

    @ApiModelProperty(value = "宽")
    @ExcelProperty(value = "宽", index = 9)
    private BigDecimal width;

    @ApiModelProperty(value = "高")
    @ExcelProperty(value = "高", index = 10)
    private BigDecimal height;

    @ApiModelProperty(value = "容积")
    @ExcelProperty(value = "容积", index = 11)
    private BigDecimal volume;

    @ApiModelProperty(value = "报废大类名称")
    @ExcelProperty(value = "报废大类", index = 12)
    private String scrapClassName;

    @ApiModelProperty(value = "报废小类名称")
    @ExcelProperty(value = "报废小类", index = 13)
    private String scrapDetailClassName;

    @ApiModelProperty(value = "厂部代码")
    @ExcelProperty(value = "厂部", index = 14)
    private String departmentCode;

    @ApiModelProperty(value = "报废类型名称")
    @ExcelProperty(value = "报废类型", index = 15)
    private String scrapTypeName;

    @ApiModelProperty(value = "是否进废料暂存区名称")
    @ExcelProperty(value = "是否进废料暂存区", index = 16)
    private String isScrapAreaName;

    @ApiModelProperty(value = "创建人")
    @ExcelProperty(value = "创建人", index = 17)
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "创建时间")
    @ExcelProperty(value = "创建时间", index = 18, converter = LocalDateTimeStringConverter.class)
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "修改人")
    @ExcelProperty(value = "修改人", index = 19)
    private String lastEditor;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "修改时间")
    @ExcelProperty(value = "修改时间", index = 20, converter = LocalDateTimeStringConverter.class)
    private LocalDateTime lastEditedDt;
}
