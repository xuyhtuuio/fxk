package com.maxnerva.cloudmes.models.vo.plan;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @ClassName PlanInfoUpdateVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/8
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("年度计划信息修改vo")
@Data
public class PlanInfoUpdateVO {

    @ApiModelProperty("主键id")
    private Integer id;

    @ApiModelProperty(value = "本年度原始计划量（KG）")
    private BigDecimal originalWeight;
}
