package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName AgvTaskTypeEnum
 * @Description 托盘类别枚举
 * @Author Likun
 * @Date 2024/11/5
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum BucketTypeEnum {

    BUCKET("bucket", "钢桶"),
    PALLET("pallet", "栈板");


    private String dictCode;

    private String dictName;

    BucketTypeEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (BucketTypeEnum bucketTypeEnum : values()) {
            if (bucketTypeEnum.getDictCode().equals(dictCode)) {
                return bucketTypeEnum.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

    /**
     * 提前判断，用于解决
     * Case中出现的Constant expression required
     *
     * @param dictCode 值
     * @return bucketTypeEnum
     */
    public static BucketTypeEnum getByValue(String dictCode) {
        for (BucketTypeEnum bucketTypeEnum : values()) {
            if (bucketTypeEnum.getDictCode().equals(dictCode)) {
                return bucketTypeEnum;
            }
        }
        return null;
    }
}
