package com.maxnerva.cloudmes.models.vo.excel.basic;

import com.alibaba.excel.annotation.ExcelProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName MaterialClassImportVO
 * @Description TODO
 * @Author Likun
 * @Date 2024/10/28
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("物料类别信息导入VO")
@Data
public class MaterialClassImportVO {

    @ApiModelProperty(value = "分类代码")
    @ExcelProperty(value = "分类代码",index = 0)
    private String classCode;

    @ApiModelProperty(value = "物料类别")
    @ExcelProperty(value = "物料类别",index = 1)
    private String className;
}
