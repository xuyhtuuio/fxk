package com.maxnerva.cloudmes.models.dto.scrap;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

/**
 * @ClassName PaymentUploadDTO
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/3/20 下午 04:29
 * @Version 1.0
 **/
@Data
public class PaymentUploadDTO {

    @ApiModelProperty(value = "上传人")
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "上传时间")
    private LocalDateTime createdDt;

    private String fileName;

    private String url;

    private Integer fileId;

}
