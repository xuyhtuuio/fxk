package com.maxnerva.cloudmes.models.vo.scrap;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class SteelInventoryPlanHeaderCompleteVO {

    @ApiModelProperty(value = "ID", required = true)
    private Integer id;
}
