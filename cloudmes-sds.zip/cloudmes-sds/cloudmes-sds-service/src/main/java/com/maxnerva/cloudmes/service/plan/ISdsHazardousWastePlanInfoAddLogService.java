package com.maxnerva.cloudmes.service.plan;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.basic.FlownetResponse;
import com.maxnerva.cloudmes.models.dto.plan.PlanInfoAddLogDTO;
import com.maxnerva.cloudmes.models.entity.plan.SdsHazardousWastePlanInfoAddLog;
import com.maxnerva.cloudmes.models.vo.plan.PlanFlownetApprovalVO;
import com.maxnerva.cloudmes.models.vo.plan.PlanInfoAddLogQueryVO;
import com.maxnerva.cloudmes.models.vo.plan.PlanInfoAddLogSaveVO;
import com.maxnerva.cloudmes.models.vo.plan.PlanInfoAddLogUpdateVO;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;

/**
 * <p>
 * 年度计划说明表 服务类
 * </p>
 *
 * @author likun
 * @since 2025-05-08
 */
public interface ISdsHazardousWastePlanInfoAddLogService extends IService<SdsHazardousWastePlanInfoAddLog> {

    void savePlanInfoAddLog(PlanInfoAddLogSaveVO saveVO);

    void updatePlanInfoAddLog(PlanInfoAddLogUpdateVO  updateVO);

    PageDataDTO<PlanInfoAddLogDTO> selectPlanInfoAddLogPage(PlanInfoAddLogQueryVO queryVO);

    void deletePlanInfoAddLog(Integer id);

    void exportPlanInfoAddLog(HttpServletResponse response, PlanInfoAddLogQueryVO queryVO);

    R<Void> approvalCompleted(String jsonString);

    void flownetApproval(List<PlanFlownetApprovalVO> approvalVOList);

    HashMap<String, String> sendToSign(HttpServletRequest request, Integer id);

    FlownetResponse approvalStatus(Integer id);
}
