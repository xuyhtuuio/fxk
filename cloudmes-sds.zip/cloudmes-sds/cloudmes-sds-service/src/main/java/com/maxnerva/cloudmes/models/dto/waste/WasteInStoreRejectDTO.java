package com.maxnerva.cloudmes.models.dto.waste;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @ClassName WasteRejectDTO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/16
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("入库拒收信息dto")
@Data
public class WasteInStoreRejectDTO {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "组织")
    private String orgCode;

    @ApiModelProperty(value = "废物俗称")
    private String hazardousWasteName;

    @ApiModelProperty(value = "申请部门")
    private String depName;

    @ApiModelProperty(value = "费用代码")
    private String costCode;

    @ApiModelProperty(value = "单据状态")
    private String status;

    @ApiModelProperty(value = "单号")
    private String docNo;

    @ApiModelProperty(value = "单据id")
    private Integer docId;

    @ApiModelProperty(value = "单据类型")
    private String docType;

    @ApiModelProperty(value = "SDS料号")
    private String hazardousWasteNo;

    @ApiModelProperty(value = "栈板重量")
    private BigDecimal palletWeight;

    @ApiModelProperty(value = "产废毛重")
    private BigDecimal applyGrossWeight;

    @ApiModelProperty(value = "产废净重")
    private BigDecimal applyNetWeight;

    @ApiModelProperty(value = "产废称重人")
    private String weightEmp;

    @ApiModelProperty(value = "产废称重时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime weightDt;

    @ApiModelProperty(value = "入库毛重")
    private BigDecimal instoreGrossWeight;

    @ApiModelProperty(value = "入库净重")
    private BigDecimal instoreNetWeight;

    @ApiModelProperty(value = "入库人")
    private String instoreEmp;

    @ApiModelProperty(value = "入库时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime instoreDt;

    @ApiModelProperty(value = "拒收原因")
    private String rejectReasonType;

    @ApiModelProperty(value = "拒收人")
    private String rejectEmpNo;

    @ApiModelProperty(value = "拒收时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime rejectDt;

    @ApiModelProperty(value = "处理人")
    private String handleEmpNo;

    @ApiModelProperty(value = "处理时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime handleDt;

    @ApiModelProperty(value = "处理方式")
    private String handleMethod;

    @ApiModelProperty(value = "产废图片")
    private String imageUrlList;

    @ApiModelProperty(value = "拒收图片")
    private String rejectImageList;

    @ApiModelProperty(value = "单据状态名称")
    private String statusName;

    @ApiModelProperty(value = "处理方式名称")
    private String handleMethodName;

    @ApiModelProperty(value = "拒收原因名称")
    private String rejectReasonTypeName;
}
