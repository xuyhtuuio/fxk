package com.maxnerva.cloudmes.service.waste.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.mapper.waste.SdsHazardousMoveOutConfigMapper;
import com.maxnerva.cloudmes.models.dto.waste.WasteMoveOutConfigDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousMoveOutConfig;
import com.maxnerva.cloudmes.service.waste.ISdsHazardousMoveOutConfigService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 危废移出单位配置档 服务实现类
 * </p>
 *
 * @author likun
 * @since 2025-05-27
 */
@Slf4j
@Service
public class SdsHazardousMoveOutConfigServiceImpl extends ServiceImpl<SdsHazardousMoveOutConfigMapper, SdsHazardousMoveOutConfig> implements ISdsHazardousMoveOutConfigService {

    @Override
    public List<WasteMoveOutConfigDTO> selectMoveOutConfigList() {
        return baseMapper.selectMoveOutConfigList();
    }
}
