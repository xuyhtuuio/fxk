package com.maxnerva.cloudmes.models.dto.waste;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @ClassName WasteInStoreWeightSubmitDTO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/16
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("入库称重信息dto")
@Data
public class WasteInStoreWeightSubmitDTO {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "单号")
    private String docNo;

    @ApiModelProperty(value = "废物俗称")
    private String hazardousWasteName;

    @ApiModelProperty(value = "申请人部门")
    private String depName;

    @ApiModelProperty("申请数量")
    private BigDecimal applyQty;

    @ApiModelProperty(value = "托盘重量")
    private BigDecimal palletWeight;

    @ApiModelProperty(value = "产品毛重")
    private BigDecimal instoreGrossWeight;

    @ApiModelProperty(value = "产品净重")
    private BigDecimal instoreNetWeight;

    @ApiModelProperty(value = "申请人费用代码")
    private String costCode;

    @ApiModelProperty(value = "SDS料号")
    private String hazardousWasteNo;

    @ApiModelProperty(value = "车间净重")
    private BigDecimal workshopNetWeight;

    @ApiModelProperty(value = "是否需要手动确认, Y/N")
    private String handleConfirm;
}
