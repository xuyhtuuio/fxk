package com.maxnerva.cloudmes.service.scrap.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.config.MinIOProperties;
import com.maxnerva.cloudmes.common.constant.BucketConstant;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.excel.handler.AddNoHandler;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelPaymentHeaderMapper;
import com.maxnerva.cloudmes.models.dto.excel.scrap.SteelPaymentHeaderExportDTO;
import com.maxnerva.cloudmes.models.dto.scrap.PaymentUploadDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelPaymentHeaderDTO;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelPaymentHeader;
import com.maxnerva.cloudmes.models.vo.scrap.SteelPaymentHeaderQueryVO;
import com.maxnerva.cloudmes.service.scrap.ISdsSteelPaymentHeaderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;

import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Slf4j
@Service
public class SdsSteelPaymentHeaderService extends ServiceImpl<SdsSteelPaymentHeaderMapper, SdsSteelPaymentHeader> implements ISdsSteelPaymentHeaderService {

    @Autowired
    private MinIOProperties minIOProperties;


    @Override
    public PageDataDTO<SteelPaymentHeaderDTO> selectPageList(SteelPaymentHeaderQueryVO vo, Boolean isPage) {
        Page page = new Page();
        if (BooleanUtil.isTrue(isPage)){
            page = PageHelper.startPage(vo.getPageIndex(), vo.getPageSize());
        }
        List<SdsSteelPaymentHeader> list = baseMapper.selectPageList(vo);
        List<SteelPaymentHeaderDTO> sdsSteelPaymentHeaders = new ArrayList<>();
        list.forEach(item -> {
            SteelPaymentHeaderDTO steelPaymentHeaderDTO = new SteelPaymentHeaderDTO();
            BeanUtil.copyProperties(item, steelPaymentHeaderDTO, "fileList");
            if (StrUtil.isNotBlank(item.getFileList())){
                List<PaymentUploadDTO> scrapFileDTOList = JSONUtil.toList(item.getFileList(), PaymentUploadDTO.class);
                scrapFileDTOList.forEach(scrapFileDTO -> {
                    scrapFileDTO.setUrl(minIOProperties.getFileAddrForAuth(BucketConstant.CLOUD_SAAS, scrapFileDTO.getUrl()));
                });
                steelPaymentHeaderDTO.setPaymentFileList(scrapFileDTOList);
            }
            sdsSteelPaymentHeaders.add(steelPaymentHeaderDTO);
        });
        return new PageDataDTO(page.getTotal(), sdsSteelPaymentHeaders);
    }

    @Override
    public void exportDetail(SteelPaymentHeaderQueryVO vo, HttpServletResponse response) {
        PageDataDTO<SteelPaymentHeaderDTO> pageDataDTO = selectPageList(vo, Boolean.FALSE);
        List<SteelPaymentHeaderExportDTO> exportDTOList = ListUtil.toList();
        pageDataDTO.getList().forEach(item -> {
            SteelPaymentHeaderExportDTO dto = new SteelPaymentHeaderExportDTO();
            BeanUtil.copyProperties(item, dto);
            exportDTOList.add(dto);
        });

        String fileName = "固废缴款单" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), SteelPaymentHeaderExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getLocalCode()));
        }
    }
}
