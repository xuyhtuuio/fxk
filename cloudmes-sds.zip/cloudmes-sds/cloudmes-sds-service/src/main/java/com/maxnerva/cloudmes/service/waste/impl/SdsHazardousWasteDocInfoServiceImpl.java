package com.maxnerva.cloudmes.service.waste.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.date.LocalDateTimeUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.fastjson2.JSON;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.config.MinIOProperties;
import com.maxnerva.cloudmes.common.constant.BucketConstant;
import com.maxnerva.cloudmes.common.enums.ResultCode;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.common.utils.WebContextUtil;
import com.maxnerva.cloudmes.enums.*;
import com.maxnerva.cloudmes.excel.handler.AddNoHandler;
import com.maxnerva.cloudmes.feign.basic.ICodeRuleClient;
import com.maxnerva.cloudmes.feign.print.IPrintTemplateClient;
import com.maxnerva.cloudmes.mapper.basic.SdsHazardousWasteCostAuditRelationConfigMapper;
import com.maxnerva.cloudmes.mapper.basic.SdsPrintTemplateConfigMapper;
import com.maxnerva.cloudmes.mapper.plan.SdsHazardousWastePlanInfoMapper;
import com.maxnerva.cloudmes.mapper.waste.SdsHazardousWasteDocInfoLogMapper;
import com.maxnerva.cloudmes.mapper.waste.SdsHazardousWasteDocInfoMapper;
import com.maxnerva.cloudmes.mapper.waste.SdsHazardousWasteRejectMapper;
import com.maxnerva.cloudmes.models.dto.excel.waste.WasteDocInfoExportDTO;
import com.maxnerva.cloudmes.models.dto.print.PrintTemplateFeignDTO;
import com.maxnerva.cloudmes.models.dto.waste.HazardousWasteDocInfoDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteDocPrintDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteDocPrintDataDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteWeightInfoSubmitDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsHazardousWasteCostAuditRelationConfig;
import com.maxnerva.cloudmes.models.entity.basic.SdsPrintTemplateConfig;
import com.maxnerva.cloudmes.models.entity.plan.SdsHazardousWastePlanInfo;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteDocInfo;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteDocInfoLog;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteReject;
import com.maxnerva.cloudmes.models.vo.waste.*;
import com.maxnerva.cloudmes.service.waste.ISdsHazardousWasteDocInfoLogService;
import com.maxnerva.cloudmes.service.waste.ISdsHazardousWasteDocInfoService;
import com.maxnerva.cloudmes.system.feign.IOrganizationClient;
import com.maxnerva.cloudmes.system.feign.IUploadFileClient;
import com.maxnerva.cloudmes.system.models.dto.UploadFileRespDTO;
import com.maxnerva.cloudmes.system.models.vo.FileUploadVO;
import com.maxnerva.cloudmes.system.utils.DictLangUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.util.MimeTypeUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <p>
 * 产废单据表 服务实现类
 * </p>
 *
 * @author likun
 * @since 2025-05-14
 */
@Service
@Slf4j
public class SdsHazardousWasteDocInfoServiceImpl extends ServiceImpl<SdsHazardousWasteDocInfoMapper, SdsHazardousWasteDocInfo> implements ISdsHazardousWasteDocInfoService {

    @Resource
    private DictLangUtils dictLangUtils;

    @Resource
    private ICodeRuleClient codeRuleClient;

    @Resource
    private SdsHazardousWasteCostAuditRelationConfigMapper relationConfigMapper;

    @Resource
    private SdsHazardousWastePlanInfoMapper sdsHazardousWastePlanInfoMapper;

    @Resource
    private SdsHazardousWasteDocInfoLogMapper sdsHazardousWasteDocInfoLogMapper;

    @Resource
    private PlatformTransactionManager transactionManager;

    @Resource
    private SdsPrintTemplateConfigMapper sdsPrintTemplateConfigMapper;

    @Resource
    private IPrintTemplateClient printTemplateClient;

    @Resource
    private IUploadFileClient uploadFileClient;

    @Resource
    private MinIOProperties minIOProperties;

    @Resource
    private ISdsHazardousWasteDocInfoLogService sdsHazardousWasteDocInfoLogService;

    @Resource
    private IOrganizationClient organizationClient;

    @Resource
    private SdsHazardousWasteRejectMapper sdsHazardousWasteRejectMapper;

    @Override
    public void saveWasteDocInfo(HazardousWasteDocInfoSaveVO saveVO) {
        String orgCode = saveVO.getOrgCode();
        String hazardousWasteNo = saveVO.getHazardousWasteNo();
        String productionDate = saveVO.getProductionDate();
        String isPallet = saveVO.getIsPallet();
        SdsHazardousWasteDocInfo docInfo = new SdsHazardousWasteDocInfo();
        BeanUtils.copyProperties(saveVO, docInfo);
        if (!"0".equals(isPallet)) {
            //有栈板,去查询字典并写入栈板重量
            Map<String, String> configMap = dictLangUtils.getByType("SDS_PALLET_WEIGHT_CONFIG");
            String palletConfig = configMap.values().stream().findFirst().orElse("0");
            docInfo.setPalletWeight(new BigDecimal(isPallet).multiply(new BigDecimal(palletConfig)));
        }
        LocalDateTime parse = LocalDateTimeUtil.parse(productionDate,
                DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        docInfo.setProductionDate(parse);
        String serialNo;
        HashMap<String, String> map = new HashMap<>();
        map.put("HAZARDOUS_WASTE_NO", hazardousWasteNo);
        String simpleCode = organizationClient.getSimpleCodeByOrgCode(orgCode).getData();
        map.put("BU", simpleCode);
        R<List<String>> result = codeRuleClient.getSerialNumberAndParams(CodeRuleEnum.SDS_WASTE_PRODUCT_DOC_NO
                .getDictCode(), 1, map);
        if (result.getCode() == ResultCode.SUCCESS.getCode()) {
            serialNo = result.getData().get(0);
        } else {
            throw new CloudmesException(SdsResultCode.CONNECT_BASIC_GET_SERIAL_NUMBER.getCode()
                    , MessageUtils.get(SdsResultCode.CONNECT_BASIC_GET_SERIAL_NUMBER.getLocalCode()));
        }
        docInfo.setDocNo(serialNo);
        baseMapper.insert(docInfo);
    }

    @Override
    public PageDataDTO<HazardousWasteDocInfoDTO> selectWasteDocInfoList(HazardousWasteDocInfoQueryVO queryVO) {
        if (queryVO.getPageIndex() != null && queryVO.getPageSize() != null
                && queryVO.getPageIndex() != 0 && queryVO.getPageSize() != 0) {
            Page page = PageHelper.startPage(queryVO.getPageIndex(), queryVO.getPageSize());
            String currentStaffCode = WebContextUtil.getCurrentStaffCode();
            List<String> types = CollUtil.newArrayList();
            types.add("SDS_HAZARDOUS_WASTE_ENTRY_TYPE");
            types.add("SDS_HAZARDOUS_WASTE_PACK_TYPE");
            types.add("SDS_WASTE_DOC_INFO_STATUS");
            Map<String, Map<String, String>> data = dictLangUtils.getByTypes(types);
            Map<String, String> entryTypeMap = data.get("SDS_HAZARDOUS_WASTE_ENTRY_TYPE");
            Map<String, String> packTypeMap = data.get("SDS_HAZARDOUS_WASTE_PACK_TYPE");
            Map<String, String> docStatusMap = data.get("SDS_WASTE_DOC_INFO_STATUS");
            List<HazardousWasteDocInfoDTO> hazardousWasteDocInfoDTOS = baseMapper
                    .selectHazardousWasteDocInfoPage(queryVO);
            hazardousWasteDocInfoDTOS.forEach(hazardousWasteDocInfoDTO -> {
                hazardousWasteDocInfoDTO.setDocTypeName(entryTypeMap.get(hazardousWasteDocInfoDTO.getDocType()));
                hazardousWasteDocInfoDTO.setPackTypeName(packTypeMap.get(hazardousWasteDocInfoDTO.getPackType()));
                hazardousWasteDocInfoDTO.setDocStatusName(docStatusMap.get(hazardousWasteDocInfoDTO.getDocStatus()));
                String costCode = hazardousWasteDocInfoDTO.getCostCode();
                Long count = relationConfigMapper
                        .selectCount(Wrappers.<SdsHazardousWasteCostAuditRelationConfig>lambdaQuery()
                                .eq(SdsHazardousWasteCostAuditRelationConfig::getOrgCode,
                                        hazardousWasteDocInfoDTO.getOrgCode())
                                .eq(SdsHazardousWasteCostAuditRelationConfig::getCostCode, costCode)
                                .eq(SdsHazardousWasteCostAuditRelationConfig::getStaffCode, currentStaffCode));
                hazardousWasteDocInfoDTO.setAuditFlag(count > 0 && WasteDocInfoStatusEnum.SIGNED.getDictCode()
                        .equals(hazardousWasteDocInfoDTO.getDocStatus()) ? Boolean.TRUE : Boolean.FALSE);
            });
            return new PageDataDTO<>(page.getTotal(), hazardousWasteDocInfoDTOS);
        } else {
            List<HazardousWasteDocInfoDTO> hazardousWasteDocInfoDTOS = getHazardousWasteDocInfoDTOList(queryVO);
            return new PageDataDTO<>((long) hazardousWasteDocInfoDTOS.size(), hazardousWasteDocInfoDTOS);
        }
    }

    @Override
    public R<WasteWeightInfoSubmitDTO> submitWasteWeightInfo(WasteWeightInfoSubmitVO submitVO) {
        log.info("wasteWeigh: {} {} start", submitVO.getDocNo(), submitVO.getGrossWeight());
        String currentStaffCode = WebContextUtil.getCurrentStaffCode();
        String docNo = submitVO.getDocNo();
        BigDecimal grossWeight = submitVO.getGrossWeight();
        WasteWeightInfoSubmitDTO dto = new WasteWeightInfoSubmitDTO();
        R<WasteWeightInfoSubmitDTO> r = new R<>();
        r.setData(dto);
        dto.setDocNo(docNo);
        dto.setApplyGrossWeight(grossWeight);
        SdsHazardousWasteDocInfo sdsHazardousWasteDocInfo = baseMapper
                .selectOne(Wrappers.<SdsHazardousWasteDocInfo>lambdaQuery()
                        .eq(SdsHazardousWasteDocInfo::getDocNo, docNo)
                        .last("limit 1"));
        if (ObjectUtil.isNull(sdsHazardousWasteDocInfo)) {
            r.setCode(SdsResultCode.WASTE_DOC_NOT_EXIST.getCode());
            r.setMsg(String.format(MessageUtils.get(SdsResultCode.WASTE_DOC_NOT_EXIST.getLocalCode()),
                    docNo));
            return r;
        }
        dto.setId(sdsHazardousWasteDocInfo.getId());
        dto.setHazardousWasteName(sdsHazardousWasteDocInfo.getHazardousWasteName());
        dto.setDepName(sdsHazardousWasteDocInfo.getDepName());
        dto.setPalletWeight(sdsHazardousWasteDocInfo.getPalletWeight());
        dto.setCostCode(sdsHazardousWasteDocInfo.getCostCode());
        dto.setHazardousWasteNo(sdsHazardousWasteDocInfo.getHazardousWasteNo());
        //单据的org_code+cost_code（部门）在拒收记录中是否存在超过3小时（字典配置）未处理的拒收记录，若有,不允许产废车间称重
        Map<String, String> configMap = dictLangUtils.getByType("SDS_REJECT_TIMEOUT_CONFIG");
        String timeOutConfig = configMap.values().stream().findFirst().orElse("0");
        SdsHazardousWasteReject sdsHazardousWasteReject = sdsHazardousWasteRejectMapper
                .selectOne(Wrappers.<SdsHazardousWasteReject>lambdaQuery()
                        .eq(SdsHazardousWasteReject::getOrgCode, sdsHazardousWasteDocInfo.getOrgCode())
                        .eq(SdsHazardousWasteReject::getCostCode, sdsHazardousWasteDocInfo.getCostCode())
                        .eq(SdsHazardousWasteReject::getStatus, "0")
                        .orderByAsc(SdsHazardousWasteReject::getId)
                        .last("limit 1"));
        if (ObjectUtil.isNotNull(sdsHazardousWasteReject)) {
            if (LocalDateTimeUtil.between(sdsHazardousWasteReject.getCreatedDt(), LocalDateTime.now()).toHours() >=
                    Integer.parseInt(timeOutConfig)) {
                r.setCode(SdsResultCode.REJECT_INFO_EXIST_MORE_THAN_APPOINT_TIME.getCode());
                r.setMsg(String.format(MessageUtils.get(SdsResultCode.REJECT_INFO_EXIST_MORE_THAN_APPOINT_TIME
                        .getLocalCode()), Integer.parseInt(timeOutConfig)));
                return r;
            }
        }
        if ("Y".equals(sdsHazardousWasteDocInfo.getApplyWeighStatus())) {
            r.setCode(SdsResultCode.CAN_NOT_REPEAT_WEIGH.getCode());
            r.setMsg(MessageUtils.get(SdsResultCode.CAN_NOT_REPEAT_WEIGH.getLocalCode()));
            return r;
        }
        BigDecimal palletWeight = sdsHazardousWasteDocInfo.getPalletWeight();
        //申请重量（产品净重）=产废毛重（产品重量）-栈板重量 若申请重量<=0,报错：产品净重不能小于等于0
        BigDecimal netWeight = grossWeight.subtract(palletWeight);
        if (netWeight.compareTo(BigDecimal.ZERO) <= 0) {
            r.setCode(SdsResultCode.NET_WEIGHT_CAN_NOT_LESS_THAN_ZERO.getCode());
            r.setMsg(String.format(MessageUtils.get(SdsResultCode.NET_WEIGHT_CAN_NOT_LESS_THAN_ZERO.getLocalCode()),
                    netWeight));
            return r;
        }
        dto.setApplyNetWeight(netWeight);
        int year = LocalDate.now().getYear();
        String orgCode = sdsHazardousWasteDocInfo.getOrgCode();
        String costCode = sdsHazardousWasteDocInfo.getCostCode();
        String hazardousWasteNo = sdsHazardousWasteDocInfo.getHazardousWasteNo();
        SdsHazardousWastePlanInfo sdsHazardousWastePlanInfo = sdsHazardousWastePlanInfoMapper
                .selectOne(Wrappers.<SdsHazardousWastePlanInfo>lambdaQuery()
                        .eq(SdsHazardousWastePlanInfo::getOrgCode, orgCode)
                        .eq(SdsHazardousWastePlanInfo::getCostCode, costCode)
                        .eq(SdsHazardousWastePlanInfo::getPlanYear, String.valueOf(year))
                        .eq(SdsHazardousWastePlanInfo::getHazardousWasteNo, hazardousWasteNo));
        //剩余量(可用量)
        BigDecimal remainWeight = ObjectUtil.isNull(sdsHazardousWastePlanInfo) ?
                BigDecimal.ZERO : sdsHazardousWastePlanInfo.getPlanWeight()
                .subtract(sdsHazardousWastePlanInfo.getUsedWeight());
        if (netWeight.compareTo(remainWeight) > 0) {
            r.setCode(SdsResultCode.APPLY_QTY_MORE_THAN_REMAIN_QTY_IN_THIS_YEAR.getCode());
            r.setMsg(String.format(MessageUtils.get(SdsResultCode.APPLY_QTY_MORE_THAN_REMAIN_QTY_IN_THIS_YEAR.getLocalCode()),
                    netWeight, year, remainWeight));
            return r;
        }
        dto.setRemainWeight(remainWeight);
        // 手动开启事务
        TransactionStatus transactionStatus = transactionManager.getTransaction(new DefaultTransactionDefinition());
        try {
            //更新产废单中的产废毛重（产品重量）、产废净重（产品净重）、称重人、称重时间等栏位
            baseMapper.update(null, Wrappers.<SdsHazardousWasteDocInfo>lambdaUpdate()
                    .eq(SdsHazardousWasteDocInfo::getId, sdsHazardousWasteDocInfo.getId())
                    .set(SdsHazardousWasteDocInfo::getApplyWeighStatus, "Y")
                    .set(SdsHazardousWasteDocInfo::getApplyGrossWeight, grossWeight)
                    .set(SdsHazardousWasteDocInfo::getApplyNetWeight, netWeight)
                    .set(SdsHazardousWasteDocInfo::getWeightEmp, currentStaffCode)
                    .set(SdsHazardousWasteDocInfo::getWeightDt, LocalDateTime.now())
                    .set(SdsHazardousWasteDocInfo::getLastEditor, currentStaffCode)
                    .set(SdsHazardousWasteDocInfo::getLastEditedDt, LocalDateTime.now()));
            //更新年度计划单的used_weight（将产品净重累加到此栏位中）
            sdsHazardousWastePlanInfoMapper.addUsedWeight(sdsHazardousWastePlanInfo.getId(),
                    netWeight, currentStaffCode);
            //年度剩余量
            dto.setRemainWeight(remainWeight.subtract(netWeight));
            //写称重sds_hazardous_waste_doc_info_log，类型：危废产废车间称重
            SdsHazardousWasteDocInfoLog sdsHazardousWasteDocInfoLog = new SdsHazardousWasteDocInfoLog();
            BeanUtils.copyProperties(sdsHazardousWasteDocInfo, sdsHazardousWasteDocInfoLog);
            sdsHazardousWasteDocInfoLog.setId(null);
            sdsHazardousWasteDocInfoLog.setApplyWeighStatus("Y");
            sdsHazardousWasteDocInfoLog.setApplyGrossWeight(grossWeight);
            sdsHazardousWasteDocInfoLog.setApplyNetWeight(netWeight);
            sdsHazardousWasteDocInfoLog.setWeightEmp(currentStaffCode);
            sdsHazardousWasteDocInfoLog.setWeightDt(LocalDateTime.now());
            sdsHazardousWasteDocInfoLog.setOperateType(WasteDocOperateType.WASTE_PRODUCT_WEIGH.getDictCode());
            sdsHazardousWasteDocInfoLog.setOperateMsg(WasteDocOperateType.WASTE_PRODUCT_WEIGH.getDictName());
            sdsHazardousWasteDocInfoLogMapper.insert(sdsHazardousWasteDocInfoLog);
            transactionManager.commit(transactionStatus);
        } catch (CloudmesException e) {
            transactionManager.rollback(transactionStatus);
            throw e;
        } catch (Exception e) {
            transactionManager.rollback(transactionStatus);
            e.printStackTrace();
            throw new CloudmesException(e.getMessage());
        }
        r.setCode(ResultCode.SUCCESS.getCode());
        r.setSuccess(Boolean.TRUE);
        r.setMsg(MessageUtils.get(ResultCode.SUCCESS.getLocalCode()));
        r.setData(dto);
        log.info("wasteWeight: {} {} {} {} end", docNo, grossWeight, r.getMsg(), r.getCode());
        return r;
    }

    @Override
    public WasteDocPrintDTO printWasteDocInfo(WasteDocInfoPrintVO printVO) {
        String printTemplateId = printVO.getPrintTemplateId();
        Integer id = printVO.getId();
        //如果传入模板id为空，则查询配置表中配置的模板id
        if (StrUtil.isEmpty(printTemplateId)) {
            SdsPrintTemplateConfig sdsPrintTemplateConfig = sdsPrintTemplateConfigMapper
                    .selectOne(Wrappers.<SdsPrintTemplateConfig>lambdaQuery()
                            .eq(SdsPrintTemplateConfig::getOrgCode, "ALL")
                            .eq(SdsPrintTemplateConfig::getPrintType, PrintTypeEnum.HW_DOC_BUCKET.getDictCode())
                            .last("limit 1"));
            printTemplateId = sdsPrintTemplateConfig.getPrintTemplateId().toString();
        }
        SdsHazardousWasteDocInfo sdsHazardousWasteDocInfo = baseMapper.selectById(id);
        //增加打印log
        SdsHazardousWasteDocInfoLog sdsHazardousWasteDocInfoLog = new SdsHazardousWasteDocInfoLog();
        BeanUtils.copyProperties(sdsHazardousWasteDocInfo, sdsHazardousWasteDocInfoLog);
        sdsHazardousWasteDocInfoLog.setId(null);
        sdsHazardousWasteDocInfoLog.setOperateType(WasteDocOperateType.WASTE_PRODUCT_PRINT.getDictCode());
        sdsHazardousWasteDocInfoLog.setOperateMsg(WasteDocOperateType.WASTE_PRODUCT_PRINT.getDictName());
        sdsHazardousWasteDocInfoLogMapper.insert(sdsHazardousWasteDocInfoLog);
        //调用打印服务查询模板content以及模板类型
        PrintTemplateFeignDTO printTemplateFeignDTO = selectPrintTemplate(printTemplateId);
        WasteDocPrintDataDTO wasteDocPrintDataDTO = new WasteDocPrintDataDTO();
        BeanUtils.copyProperties(sdsHazardousWasteDocInfo, wasteDocPrintDataDTO);
        WasteDocPrintDTO wasteDocPrintDTO = new WasteDocPrintDTO();
        wasteDocPrintDTO.setData(wasteDocPrintDataDTO);
        wasteDocPrintDTO.setContent(printTemplateFeignDTO.getContent());
        wasteDocPrintDTO.setType(printTemplateFeignDTO.getFileType());
        return wasteDocPrintDTO;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void cancelWasteDocInfo(Integer id) {
        String currentStaffCode = WebContextUtil.getCurrentStaffCode();
        SdsHazardousWasteDocInfo sdsHazardousWasteDocInfo = baseMapper.selectById(id);
        if (!WasteDocInfoStatusEnum.CREATE.getDictCode().equals(sdsHazardousWasteDocInfo.getDocStatus())) {
            throw new CloudmesException(SdsResultCode.SIGNED_CAN_NOT_CANCEL.getCode(),
                    MessageUtils.get(SdsResultCode.SIGNED_CAN_NOT_CANCEL.getLocalCode()));
        }
        String applyWeighStatus = sdsHazardousWasteDocInfo.getApplyWeighStatus();
        if ("Y".equals(applyWeighStatus)) {
            String orgCode = sdsHazardousWasteDocInfo.getOrgCode();
            String costCode = sdsHazardousWasteDocInfo.getCostCode();
            String hazardousWasteNo = sdsHazardousWasteDocInfo.getHazardousWasteNo();
            int year = LocalDate.now().getYear();
            sdsHazardousWastePlanInfoMapper.subtractUsedWeight(orgCode, costCode, String.valueOf(year), hazardousWasteNo,
                    sdsHazardousWasteDocInfo.getApplyNetWeight(), currentStaffCode);
        }
        baseMapper.update(null, Wrappers.<SdsHazardousWasteDocInfo>lambdaUpdate()
                .eq(SdsHazardousWasteDocInfo::getId, id)
                .set(SdsHazardousWasteDocInfo::getIsDeleted, Boolean.TRUE)
                .set(SdsHazardousWasteDocInfo::getLastEditor, currentStaffCode)
                .set(SdsHazardousWasteDocInfo::getLastEditedDt, LocalDateTime.now()));
        SdsHazardousWasteDocInfoLog sdsHazardousWasteDocInfoLog = new SdsHazardousWasteDocInfoLog();
        BeanUtils.copyProperties(sdsHazardousWasteDocInfo, sdsHazardousWasteDocInfoLog);
        sdsHazardousWasteDocInfoLog.setId(null);
        sdsHazardousWasteDocInfoLog.setOperateType(WasteDocOperateType.WASTE_DOC_CANCEL.getDictCode());
        sdsHazardousWasteDocInfoLog.setOperateMsg(WasteDocOperateType.WASTE_DOC_CANCEL.getDictName());
        sdsHazardousWasteDocInfoLogMapper.insert(sdsHazardousWasteDocInfoLog);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void uploadImage(WasteDocInfoUploadImageVO vo) {
        Integer id = vo.getId();
        FileUploadVO fileUploadVO = new FileUploadVO();
        fileUploadVO.setBucketName("cloudsaas");
        fileUploadVO.setFiles(vo.getFiles());
        R<List<UploadFileRespDTO>> result = uploadFileClient.uploadBatch(fileUploadVO);
        List<UploadFileRespDTO> uploadFileRespDTOList = result.getData();
        List<String> urlList = uploadFileRespDTOList.stream().map(UploadFileRespDTO::getName)
                .collect(Collectors.toList());
        baseMapper.update(null, Wrappers.<SdsHazardousWasteDocInfo>lambdaUpdate()
                .setSql("image_url_list = image_url_list")
                .eq(SdsHazardousWasteDocInfo::getId, vo.getId()));
        SdsHazardousWasteDocInfo sdsHazardousWasteDocInfo = baseMapper.selectById(id);
        String imageUrlListStr = sdsHazardousWasteDocInfo.getImageUrlList();
        List<String> imageUrlList;
        if (StrUtil.isBlank(imageUrlListStr)) {
            imageUrlList = urlList;
        } else {
            imageUrlList = JSON.parseArray(imageUrlListStr, String.class);
            imageUrlList.addAll(urlList);
        }
        baseMapper.update(null, Wrappers.<SdsHazardousWasteDocInfo>lambdaUpdate()
                .set(SdsHazardousWasteDocInfo::getImageUrlList, JSON.toJSONString(imageUrlList))
                .set(SdsHazardousWasteDocInfo::getLastEditor, WebContextUtil.getCurrentStaffCode())
                .set(SdsHazardousWasteDocInfo::getLastEditedDt, LocalDateTime.now())
                .eq(SdsHazardousWasteDocInfo::getId, id));
        SdsHazardousWasteDocInfoLog sdsHazardousWasteDocInfoLog = new SdsHazardousWasteDocInfoLog();
        BeanUtils.copyProperties(sdsHazardousWasteDocInfo, sdsHazardousWasteDocInfoLog);
        sdsHazardousWasteDocInfoLog.setId(null);
        sdsHazardousWasteDocInfoLog.setImageUrlList(JSON.toJSONString(imageUrlList));
        sdsHazardousWasteDocInfoLog.setOperateType(WasteDocOperateType.WASTE_PRODUCT_UPLOAD_IMAGE.getDictCode());
        sdsHazardousWasteDocInfoLog.setOperateMsg(WasteDocOperateType.WASTE_PRODUCT_UPLOAD_IMAGE.getDictName());
        sdsHazardousWasteDocInfoLogMapper.insert(sdsHazardousWasteDocInfoLog);
    }

    @Override
    public List<String> selectImageList(Integer id) {
        String imageUrl = baseMapper.getImageUrlList(id);
        List<String> imageUrlList = CollUtil.newArrayList();
        if (StrUtil.isNotEmpty(imageUrl)) {
            List<String> imageList = JSON.parseArray(imageUrl).toList(String.class);
            imageUrlList = imageList.stream().map(link -> minIOProperties.getFileAddr(BucketConstant.CLOUD_SAAS, link))
                    .collect(Collectors.toList());
        }
        return imageUrlList;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void auditWasteDocInfo(Integer id) {
        String currentStaffCode = WebContextUtil.getCurrentStaffCode();
        SdsHazardousWasteDocInfo sdsHazardousWasteDocInfo = baseMapper.selectById(id);
        String applyWeighStatus = sdsHazardousWasteDocInfo.getApplyWeighStatus();
        String docStatus = sdsHazardousWasteDocInfo.getDocStatus();
        boolean weighFlag = "Y".equals(applyWeighStatus);
        String docType = sdsHazardousWasteDocInfo.getDocType();
        LambdaUpdateWrapper<SdsHazardousWasteDocInfo> updateWrapper = Wrappers.<SdsHazardousWasteDocInfo>lambdaUpdate();
        updateWrapper.eq(SdsHazardousWasteDocInfo::getId, id);
        updateWrapper.set(SdsHazardousWasteDocInfo::getLastEditor, WebContextUtil.getCurrentStaffCode());
        updateWrapper.set(SdsHazardousWasteDocInfo::getLastEditedDt, LocalDateTime.now());
        SdsHazardousWasteDocInfoLog sdsHazardousWasteDocInfoLog = new SdsHazardousWasteDocInfoLog();
        BeanUtils.copyProperties(sdsHazardousWasteDocInfo, sdsHazardousWasteDocInfoLog);
        if (WasteDocTypeEnum.NO_STORAGE.getDictCode().equals(sdsHazardousWasteDocInfo.getDocType())
                && weighFlag) {
            updateWrapper.set(SdsHazardousWasteDocInfo::getDocStatus, WasteDocInfoStatusEnum.IN_STORAGE.getDictCode())
                    .set(SdsHazardousWasteDocInfo::getInstoreGrossWeight,
                            sdsHazardousWasteDocInfo.getApplyGrossWeight())
                    .set(SdsHazardousWasteDocInfo::getInstoreNetWeight,
                            sdsHazardousWasteDocInfo.getApplyNetWeight())
                    .set(SdsHazardousWasteDocInfo::getInstoreWeighStatus, applyWeighStatus)
                    .set(SdsHazardousWasteDocInfo::getInstoreEmp, sdsHazardousWasteDocInfo.getWeightEmp())
                    .set(SdsHazardousWasteDocInfo::getInstoreDt, sdsHazardousWasteDocInfo.getWeightDt())
                    .set(SdsHazardousWasteDocInfo::getApplyInEmp, currentStaffCode)
                    .set(SdsHazardousWasteDocInfo::getApplyInDt, LocalDateTime.now())
                    .set(SdsHazardousWasteDocInfo::getAcceptFlag, "Y")
                    .set(SdsHazardousWasteDocInfo::getAcceptEmpNo, currentStaffCode)
                    .set(SdsHazardousWasteDocInfo::getAcceptDt, LocalDateTime.now());
            docStatus = WasteDocInfoStatusEnum.IN_STORAGE.getDictCode();
            sdsHazardousWasteDocInfoLog.setInstoreGrossWeight(sdsHazardousWasteDocInfo.getApplyGrossWeight());
            sdsHazardousWasteDocInfoLog.setInstoreNetWeight(sdsHazardousWasteDocInfo.getApplyNetWeight());
            sdsHazardousWasteDocInfoLog.setInstoreEmp(sdsHazardousWasteDocInfo.getWeightEmp());
            sdsHazardousWasteDocInfoLog.setInstoreDt(sdsHazardousWasteDocInfo.getWeightDt());
            sdsHazardousWasteDocInfoLog.setApplyInEmp(currentStaffCode);
            sdsHazardousWasteDocInfoLog.setApplyInDt(LocalDateTime.now());
            sdsHazardousWasteDocInfoLog.setAcceptFlag("Y");
            sdsHazardousWasteDocInfoLog.setAcceptEmpNo(currentStaffCode);
            sdsHazardousWasteDocInfoLog.setAcceptDt(LocalDateTime.now());
        } else if (WasteDocTypeEnum.STORAGE.getDictCode().equals(docType)
                && weighFlag) {
            updateWrapper.set(SdsHazardousWasteDocInfo::getDocStatus, WasteDocInfoStatusEnum.AUDITED.getDictCode());
            docStatus = WasteDocInfoStatusEnum.AUDITED.getDictCode();
        }
        updateWrapper.set(SdsHazardousWasteDocInfo::getApprovedEmp, currentStaffCode)
                .set(SdsHazardousWasteDocInfo::getApprovedDt, LocalDateTime.now());
        baseMapper.update(null, updateWrapper);
        sdsHazardousWasteDocInfoLog.setId(null);
        sdsHazardousWasteDocInfoLog.setDocStatus(docStatus);
        sdsHazardousWasteDocInfoLog.setApprovedEmp(currentStaffCode);
        sdsHazardousWasteDocInfoLog.setApprovedDt(LocalDateTime.now());
        sdsHazardousWasteDocInfoLog.setOperateType(WasteDocOperateType.WASTE_DOC_AUDIT.getDictCode());
        sdsHazardousWasteDocInfoLog.setOperateMsg(WasteDocOperateType.WASTE_DOC_AUDIT.getDictName());
        sdsHazardousWasteDocInfoLogMapper.insert(sdsHazardousWasteDocInfoLog);
    }

    @Override
    public void applyStorage(List<Integer> idList) {
        List<SdsHazardousWasteDocInfo> sdsHazardousWasteDocInfoList = baseMapper
                .selectList(Wrappers.<SdsHazardousWasteDocInfo>lambdaQuery()
                        .in(SdsHazardousWasteDocInfo::getId, idList));
        long count = sdsHazardousWasteDocInfoList.stream().filter(sdsHazardousWasteDocInfo ->
                !WasteDocInfoStatusEnum.AUDITED.getDictCode().equals(sdsHazardousWasteDocInfo.getDocStatus())
                        || !WasteDocTypeEnum.STORAGE.getDictCode().equals(sdsHazardousWasteDocInfo.getDocType())
                        || !"Y".equals(sdsHazardousWasteDocInfo.getApplyWeighStatus())).count();
        if (count > 0) {
            throw new CloudmesException(SdsResultCode.CAN_NOT_CONFORM_TO_APPLY_IN_STORE_CONDITION.getCode(),
                    MessageUtils.get(SdsResultCode.CAN_NOT_CONFORM_TO_APPLY_IN_STORE_CONDITION.getLocalCode()));
        }
        baseMapper.update(null, Wrappers.<SdsHazardousWasteDocInfo>lambdaUpdate()
                .in(SdsHazardousWasteDocInfo::getId, idList)
                .set(SdsHazardousWasteDocInfo::getDocStatus, WasteDocInfoStatusEnum.APPLIED_FOR_STORAGE.getDictCode())
                .set(SdsHazardousWasteDocInfo::getApplyInEmp, WebContextUtil.getCurrentStaffCode())
                .set(SdsHazardousWasteDocInfo::getApplyInDt, LocalDateTime.now())
                .set(SdsHazardousWasteDocInfo::getLastEditor, WebContextUtil.getCurrentStaffCode())
                .set(SdsHazardousWasteDocInfo::getLastEditedDt, LocalDateTime.now()));
        List<SdsHazardousWasteDocInfoLog> sdsHazardousWasteDocInfoLogList = CollUtil.newArrayList();
        for (SdsHazardousWasteDocInfo sdsHazardousWasteDocInfo : sdsHazardousWasteDocInfoList) {
            SdsHazardousWasteDocInfoLog sdsHazardousWasteDocInfoLog = new SdsHazardousWasteDocInfoLog();
            BeanUtils.copyProperties(sdsHazardousWasteDocInfo, sdsHazardousWasteDocInfoLog);
            sdsHazardousWasteDocInfoLog.setId(null);
            sdsHazardousWasteDocInfoLog.setDocStatus(WasteDocInfoStatusEnum.APPLIED_FOR_STORAGE.getDictCode());
            sdsHazardousWasteDocInfoLog.setOperateType(WasteDocOperateType.APPLY_IN_STORE.getDictCode());
            sdsHazardousWasteDocInfoLog.setOperateMsg(WasteDocOperateType.APPLY_IN_STORE.getDictName());
            sdsHazardousWasteDocInfoLog.setApplyInEmp(WebContextUtil.getCurrentStaffCode());
            sdsHazardousWasteDocInfoLog.setApplyInDt(LocalDateTime.now());
            sdsHazardousWasteDocInfoLogList.add(sdsHazardousWasteDocInfoLog);
        }
        sdsHazardousWasteDocInfoLogService.saveBatch(sdsHazardousWasteDocInfoLogList);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void sign(Integer id) {
        SdsHazardousWasteDocInfo sdsHazardousWasteDocInfo = baseMapper.selectById(id);
        String applyWeighStatus = sdsHazardousWasteDocInfo.getApplyWeighStatus();
        if (!"Y".equals(applyWeighStatus)) {
            throw new CloudmesException(SdsResultCode.SIGN_MUST_AFTER_WASTE_WEIGHT.getCode(),
                    MessageUtils.get(SdsResultCode.SIGN_MUST_AFTER_WASTE_WEIGHT.getLocalCode()));
        }
        baseMapper.update(null, Wrappers.<SdsHazardousWasteDocInfo>lambdaUpdate()
                .eq(SdsHazardousWasteDocInfo::getId, id)
                .set(SdsHazardousWasteDocInfo::getDocStatus, WasteDocInfoStatusEnum.SIGNED.getDictCode())
                .set(SdsHazardousWasteDocInfo::getLastEditor, WebContextUtil.getCurrentStaffCode())
                .set(SdsHazardousWasteDocInfo::getLastEditedDt, LocalDateTime.now()));
        SdsHazardousWasteDocInfoLog sdsHazardousWasteDocInfoLog = new SdsHazardousWasteDocInfoLog();
        BeanUtils.copyProperties(sdsHazardousWasteDocInfo, sdsHazardousWasteDocInfoLog);
        sdsHazardousWasteDocInfoLog.setId(null);
        sdsHazardousWasteDocInfoLog.setDocStatus(WasteDocInfoStatusEnum.SIGNED.getDictCode());
        sdsHazardousWasteDocInfoLog.setOperateType(WasteDocOperateType.WASTE_DOC_SIGN.getDictCode());
        sdsHazardousWasteDocInfoLog.setOperateMsg(WasteDocOperateType.WASTE_DOC_SIGN.getDictName());
        sdsHazardousWasteDocInfoLogMapper.insert(sdsHazardousWasteDocInfoLog);
    }

    @Override
    public void uploadImgInApp(WasteDocInfoAppUploadImageVO vo) {
        String orgCode = vo.getOrgCode();
        String docNo = vo.getDocNo();
        FileUploadVO fileUploadVO = new FileUploadVO();
        fileUploadVO.setBucketName("cloudsaas");
        fileUploadVO.setFiles(vo.getFiles());
        R<List<UploadFileRespDTO>> result = uploadFileClient.uploadBatch(fileUploadVO);
        List<UploadFileRespDTO> uploadFileRespDTOList = result.getData();
        List<String> urlList = uploadFileRespDTOList.stream().map(UploadFileRespDTO::getName)
                .collect(Collectors.toList());
        SdsHazardousWasteDocInfo sdsHazardousWasteDocInfo = baseMapper
                .selectOne(Wrappers.<SdsHazardousWasteDocInfo>lambdaQuery()
                        .eq(SdsHazardousWasteDocInfo::getOrgCode, orgCode)
                        .eq(SdsHazardousWasteDocInfo::getDocNo, docNo)
                        .orderByDesc(SdsHazardousWasteDocInfo::getId)
                        .last("limit 1"));
        Integer id = sdsHazardousWasteDocInfo.getId();
        baseMapper.update(null, Wrappers.<SdsHazardousWasteDocInfo>lambdaUpdate()
                .setSql("image_url_list = image_url_list")
                .eq(SdsHazardousWasteDocInfo::getId, id));
        String imageUrlListStr = sdsHazardousWasteDocInfo.getImageUrlList();
        List<String> imageUrlList;
        if (StrUtil.isBlank(imageUrlListStr)) {
            imageUrlList = urlList;
        } else {
            imageUrlList = JSON.parseArray(imageUrlListStr, String.class);
            imageUrlList.addAll(urlList);
        }
        baseMapper.update(null, Wrappers.<SdsHazardousWasteDocInfo>lambdaUpdate()
                .set(SdsHazardousWasteDocInfo::getImageUrlList, JSON.toJSONString(imageUrlList))
                .set(SdsHazardousWasteDocInfo::getLastEditor, WebContextUtil.getCurrentStaffCode())
                .set(SdsHazardousWasteDocInfo::getLastEditedDt, LocalDateTime.now())
                .eq(SdsHazardousWasteDocInfo::getId, id));
        SdsHazardousWasteDocInfoLog sdsHazardousWasteDocInfoLog = new SdsHazardousWasteDocInfoLog();
        BeanUtils.copyProperties(sdsHazardousWasteDocInfo, sdsHazardousWasteDocInfoLog);
        sdsHazardousWasteDocInfoLog.setId(null);
        sdsHazardousWasteDocInfoLog.setImageUrlList(JSON.toJSONString(imageUrlList));
        sdsHazardousWasteDocInfoLog.setOperateType(WasteDocOperateType.WASTE_PRODUCT_UPLOAD_IMAGE.getDictCode());
        sdsHazardousWasteDocInfoLog.setOperateMsg(WasteDocOperateType.WASTE_PRODUCT_UPLOAD_IMAGE.getDictName());
        sdsHazardousWasteDocInfoLogMapper.insert(sdsHazardousWasteDocInfoLog);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void rejectWasteDoc(WasteDocRejectVO vo) {
        String currentStaffCode = WebContextUtil.getCurrentStaffCode();
        String orgCode = vo.getOrgCode();
        List<String> imageUrlList = null;
        if (ObjectUtil.isNotNull(vo.getFiles())) {
            FileUploadVO fileUploadVO = new FileUploadVO();
            fileUploadVO.setBucketName("cloudsaas");
            fileUploadVO.setFiles(vo.getFiles());
            R<List<UploadFileRespDTO>> result = uploadFileClient.uploadBatch(fileUploadVO);
            List<UploadFileRespDTO> uploadFileRespDTOList = result.getData();
            List<String> urlList = uploadFileRespDTOList.stream().map(UploadFileRespDTO::getName)
                    .collect(Collectors.toList());
            imageUrlList = urlList;
        }
        String docNo = vo.getDocNo();
        Long count = sdsHazardousWasteRejectMapper
                .selectCount(Wrappers.<SdsHazardousWasteReject>lambdaQuery()
                        .eq(SdsHazardousWasteReject::getDocNo, docNo)
                        .last("limit 1"));
        if (count > 0) {
            if (CollUtil.isNotEmpty(imageUrlList)) {
                sdsHazardousWasteRejectMapper.update(null,
                        Wrappers.<SdsHazardousWasteReject>lambdaUpdate()
                                .eq(SdsHazardousWasteReject::getDocNo, docNo)
                                .set(SdsHazardousWasteReject::getRejectImageList,
                                        JSON.toJSONString(imageUrlList))
                                .set(SdsHazardousWasteReject::getLastEditor, currentStaffCode)
                                .set(SdsHazardousWasteReject::getLastEditedDt, LocalDateTime.now()));
            }
        } else {
            SdsHazardousWasteDocInfo sdsHazardousWasteDocInfo = baseMapper
                    .selectOne(Wrappers.<SdsHazardousWasteDocInfo>lambdaQuery()
                            .eq(SdsHazardousWasteDocInfo::getDocNo, docNo)
                            .last("limit 1"));
            Optional.ofNullable(sdsHazardousWasteDocInfo)
                    .orElseThrow(() -> new CloudmesException(SdsResultCode.WASTE_DOC_NOT_EXIST_CAN_NOT_REJECT.getCode(),
                            String.format(MessageUtils.get(SdsResultCode.WASTE_DOC_NOT_EXIST_CAN_NOT_REJECT.getLocalCode()),
                                    docNo)));
            Optional.of(sdsHazardousWasteDocInfo)
                    .filter(docInfo -> WasteDocTypeEnum.STORAGE.getDictCode().equals(docInfo.getDocType()))
                    .orElseThrow(() -> new CloudmesException(SdsResultCode.DOC_IS_NOT_STORAGE_CAN_NOT_REJECT.getCode(),
                            String.format(MessageUtils.get(SdsResultCode.DOC_IS_NOT_STORAGE_CAN_NOT_REJECT.getLocalCode()),
                                    docNo)));
            Optional.of(sdsHazardousWasteDocInfo)
                    .filter(docInfo -> !WasteDocInfoStatusEnum.CREATED_SHIP_DOC.getDictCode().equals(docInfo.getDocStatus()))
                    .orElseThrow(() -> new CloudmesException(SdsResultCode.DOC_HAVE_BEEN_CREATED_SHIP_INFO_CAN_NOT_REJECT
                            .getCode(), String.format(MessageUtils.get(SdsResultCode
                            .DOC_HAVE_BEEN_CREATED_SHIP_INFO_CAN_NOT_REJECT.getLocalCode()), docNo)));
            baseMapper.update(null, Wrappers.<SdsHazardousWasteDocInfo>lambdaUpdate()
                    .eq(SdsHazardousWasteDocInfo::getId, sdsHazardousWasteDocInfo.getId())
                    .set(SdsHazardousWasteDocInfo::getIsDeleted, Boolean.TRUE)
                    .set(SdsHazardousWasteDocInfo::getLastEditor, currentStaffCode)
                    .set(SdsHazardousWasteDocInfo::getLastEditedDt, LocalDateTime.now()));
            SdsHazardousWasteReject sdsHazardousWasteReject = new SdsHazardousWasteReject();
            BeanUtils.copyProperties(sdsHazardousWasteDocInfo, sdsHazardousWasteReject);
            sdsHazardousWasteReject.setId(null);
            sdsHazardousWasteReject.setRejectEmpNo(vo.getOperateEmpNo());
            sdsHazardousWasteReject.setRejectDt(LocalDateTime.now());
            sdsHazardousWasteReject.setRejectReasonType(vo.getOperateRemarkType());
            sdsHazardousWasteReject.setDocId(sdsHazardousWasteDocInfo.getId());
            if (CollUtil.isNotEmpty(imageUrlList)) {
                sdsHazardousWasteReject.setRejectImageList(JSON.toJSONString(imageUrlList));
            }
            sdsHazardousWasteRejectMapper.insert(sdsHazardousWasteReject);
            SdsHazardousWasteDocInfoLog sdsHazardousWasteDocInfoLog = new SdsHazardousWasteDocInfoLog();
            BeanUtils.copyProperties(sdsHazardousWasteDocInfo, sdsHazardousWasteDocInfoLog);
            sdsHazardousWasteDocInfoLog.setId(null);
            sdsHazardousWasteDocInfoLog.setOperateType(WasteDocOperateType.IN_STORE_ERR_REJECT.getDictCode());
            sdsHazardousWasteDocInfoLog.setOperateMsg(WasteDocOperateType.IN_STORE_ERR_REJECT.getDictName());
            sdsHazardousWasteDocInfoLogService.save(sdsHazardousWasteDocInfoLog);
            String costCode = sdsHazardousWasteDocInfo.getCostCode();
            String hazardousWasteNo = sdsHazardousWasteDocInfo.getHazardousWasteNo();
            int year = LocalDate.now().getYear();
            sdsHazardousWastePlanInfoMapper.subtractUsedWeight(orgCode, costCode, String.valueOf(year), hazardousWasteNo,
                    sdsHazardousWasteDocInfo.getApplyNetWeight(), currentStaffCode);
        }
    }

    @Override
    public void checkUploadImage(WasteDocInfoAppUploadCheckVO checkVO) {
        Long count = baseMapper.selectCount(Wrappers.<SdsHazardousWasteDocInfo>lambdaQuery()
                .eq(SdsHazardousWasteDocInfo::getOrgCode, checkVO.getOrgCode())
                .eq(SdsHazardousWasteDocInfo::getDocNo, checkVO.getDocNo()));
        if (count == 0) {
            throw new CloudmesException(SdsResultCode.WASTE_DOC_NOT_EXIST.getCode(),
                    String.format(MessageUtils.get(SdsResultCode.WASTE_DOC_NOT_EXIST.getLocalCode()),
                            checkVO.getDocNo()));
        }
    }

    @Override
    public void exportWasteDocInfo(HttpServletResponse response, HazardousWasteDocInfoQueryVO queryVO) {
        List<WasteDocInfoExportDTO> exportDTOList = CollUtil.newArrayList();
        List<HazardousWasteDocInfoDTO> hazardousWasteDocInfoDTOS = getHazardousWasteDocInfoDTOList(queryVO);
        hazardousWasteDocInfoDTOS.forEach(hazardousWasteDocInfoDTO -> {
            WasteDocInfoExportDTO wasteDocInfoExportDTO = new WasteDocInfoExportDTO();
            BeanUtils.copyProperties(hazardousWasteDocInfoDTO, wasteDocInfoExportDTO);
            exportDTOList.add(wasteDocInfoExportDTO);
        });
        String fileName = "产废单信息" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), WasteDocInfoExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.HAZARDOUS_WASTE_DOC_INFO_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.HAZARDOUS_WASTE_DOC_INFO_EXPORT_FAIL.getLocalCode()));
        }
    }

    private List<HazardousWasteDocInfoDTO> getHazardousWasteDocInfoDTOList(HazardousWasteDocInfoQueryVO queryVO) {
        List<String> types = new ArrayList<>();
        types.add("SDS_HAZARDOUS_WASTE_ENTRY_TYPE");
        types.add("SDS_HAZARDOUS_WASTE_PACK_TYPE");
        types.add("SDS_WASTE_DOC_INFO_STATUS");
        Map<String, Map<String, String>> data = dictLangUtils.getByTypes(types);
        Map<String, String> entryTypeMap = data.get("SDS_HAZARDOUS_WASTE_ENTRY_TYPE");
        Map<String, String> packTypeMap = data.get("SDS_HAZARDOUS_WASTE_PACK_TYPE");
        Map<String, String> docStatusMap = data.get("SDS_WASTE_DOC_INFO_STATUS");
        List<HazardousWasteDocInfoDTO> hazardousWasteDocInfoDTOS = baseMapper
                .selectHazardousWasteDocInfoPage(queryVO);
        hazardousWasteDocInfoDTOS.forEach(hazardousWasteDocInfoDTO -> {
            hazardousWasteDocInfoDTO.setDocTypeName(entryTypeMap.get(hazardousWasteDocInfoDTO.getDocType()));
            hazardousWasteDocInfoDTO.setPackTypeName(packTypeMap.get(hazardousWasteDocInfoDTO.getPackType()));
            hazardousWasteDocInfoDTO.setDocStatusName(docStatusMap.get(hazardousWasteDocInfoDTO.getDocStatus()));
        });
        return hazardousWasteDocInfoDTOS;
    }

    private PrintTemplateFeignDTO selectPrintTemplate(String printTemplateId) {
        R<PrintTemplateFeignDTO> templateResult = printTemplateClient
                .getFeignTemplateById(Integer.valueOf(printTemplateId));
        PrintTemplateFeignDTO printTemplateFeignDTO = templateResult.getData();
        if (ObjectUtil.isNull(printTemplateFeignDTO)) {
            throw new CloudmesException(SdsResultCode.PRINT_TEMPLATE_NOT_FIND.getCode()
                    , MessageUtils.get(SdsResultCode.PRINT_TEMPLATE_NOT_FIND.getLocalCode()));
        }
        return printTemplateFeignDTO;
    }
}
