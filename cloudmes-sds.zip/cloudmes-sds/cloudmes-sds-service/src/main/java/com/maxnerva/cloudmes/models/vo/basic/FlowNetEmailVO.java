package com.maxnerva.cloudmes.models.vo.basic;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.List;

/**
 * @ClassName FlownetEmailVO
 * @Description flownet发邮件vo
 * @Author Likun
 * @Date 2023/12/21
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("flownet发邮件vo")
@Data
public class FlowNetEmailVO {

    @ApiModelProperty("账号")
    private String UserID;

    @ApiModelProperty("密码")
    private String Password;

    @ApiModelProperty("收件人邮箱，可以为多个，逗号隔开")
    private String MAILTO;

    @ApiModelProperty("抄送人邮箱 ，可以为多个， 逗号隔开")
    private String CC;

    @ApiModelProperty("邮件主旨 不可为空")
    private String Subject;

    @ApiModelProperty("邮件内容 如果有格式要求，请自行拼接HTML")
    private String BODY;

    @ApiModelProperty("附件")
    private List<File> Attachment;

}
