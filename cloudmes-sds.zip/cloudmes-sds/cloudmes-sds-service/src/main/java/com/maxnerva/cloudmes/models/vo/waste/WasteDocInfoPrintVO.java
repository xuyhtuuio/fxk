package com.maxnerva.cloudmes.models.vo.waste;

import com.maxnerva.cloudmes.models.vo.CommonPrintVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @ClassName WasteDocInfoPrintVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/14
 * @Version 1.0
 * @Since JDK 1.8
 **/
@EqualsAndHashCode(callSuper = true)
@ApiModel(value = "产废称重提交VO")
@Data
public class WasteDocInfoPrintVO extends CommonPrintVO {

    @ApiModelProperty("单据信息主键id")
    private Integer id;
}
