package com.maxnerva.cloudmes.service.basic.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.mapper.basic.SdsHazardousWasteInfoMapper;
import com.maxnerva.cloudmes.mapper.basic.SdsHwDepartmentPartRelationMapper;
import com.maxnerva.cloudmes.models.dto.basic.HwDepartmentCostConfigDTO;
import com.maxnerva.cloudmes.models.dto.basic.HwDepartmentPartRelationDTO;
import com.maxnerva.cloudmes.models.dto.basic.WasteInfoBindDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsHazardousWasteInfo;
import com.maxnerva.cloudmes.models.entity.basic.SdsHwDepartmentPartRelation;
import com.maxnerva.cloudmes.models.vo.basic.HwDepartmentPartRelationQueryVO;
import com.maxnerva.cloudmes.models.vo.basic.WasteInfoBindSubmitVO;
import com.maxnerva.cloudmes.service.basic.ISdsHwDepartmentPartRelationService;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 部门对应危废种类 服务实现类
 * </p>
 *
 * @author likun
 * @since 2025-05-06
 */
@Service
public class SdsHwDepartmentPartRelationServiceImpl extends ServiceImpl<SdsHwDepartmentPartRelationMapper,
        SdsHwDepartmentPartRelation> implements ISdsHwDepartmentPartRelationService {

    @Resource
    private SdsHazardousWasteInfoMapper sdsHazardousWasteInfoMapper;

    @Override
    public PageDataDTO<HwDepartmentPartRelationDTO> selectPartRelationPage(HwDepartmentPartRelationQueryVO queryVO) {
        if (queryVO.getPageIndex() != null && queryVO.getPageSize() != null
                && queryVO.getPageIndex() != 0 && queryVO.getPageSize() != 0) {
            Page page = PageHelper.startPage(queryVO.getPageIndex(), queryVO.getPageSize());
            List<HwDepartmentPartRelationDTO> departmentPartRelationDTOList = baseMapper
                    .selectDepartmentPartRelationList(queryVO);
            return new PageDataDTO<>(page.getTotal(), departmentPartRelationDTOList);
        } else {
            List<HwDepartmentPartRelationDTO> departmentPartRelationDTOList = baseMapper
                    .selectDepartmentPartRelationList(queryVO);
            return new PageDataDTO<>((long) departmentPartRelationDTOList.size(), departmentPartRelationDTOList);
        }
    }

    @Override
    public List<WasteInfoBindDTO> selectBindWasteInfoList(String orgCode, String costCode,
                                                          String hazardousWasteName) {
        List<WasteInfoBindDTO> wasteInfoBindDTOList = CollUtil.newArrayList();
        WasteInfoBindDTO wasteInfoBindDTO = sdsHazardousWasteInfoMapper.selectWasteInfoBindList(orgCode, costCode, hazardousWasteName,
                StrUtil.EMPTY);
        if (ObjectUtil.isNotNull(wasteInfoBindDTO)) {
            throw new CloudmesException(SdsResultCode.COST_CODE_EXIST_HAZARDOUS_WASTE_NAME.getCode(),
                    String.format(MessageUtils.get(SdsResultCode.COST_CODE_EXIST_HAZARDOUS_WASTE_NAME.getLocalCode()),
                            costCode, hazardousWasteName));
        }
        SdsHazardousWasteInfo sdsHazardousWasteInfo = sdsHazardousWasteInfoMapper
                .selectOne(Wrappers.<SdsHazardousWasteInfo>lambdaQuery()
                        .eq(SdsHazardousWasteInfo::getHazardousWasteName, hazardousWasteName)
                        .last("limit 1"));
        if (ObjectUtil.isNotNull(sdsHazardousWasteInfo)) {
            WasteInfoBindDTO bindDTO = new WasteInfoBindDTO();
            BeanUtils.copyProperties(sdsHazardousWasteInfo, bindDTO);
            bindDTO.setCostCode(costCode);
            bindDTO.setOrgCode(orgCode);
            wasteInfoBindDTOList.add(bindDTO);
        }
        return wasteInfoBindDTOList;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void bindWasteInfo(List<WasteInfoBindSubmitVO> wasteInfoBindSubmitVOList) {
        List<SdsHwDepartmentPartRelation> sdsHwDepartmentPartRelationList = CollUtil.newArrayList();
        for (WasteInfoBindSubmitVO wasteInfoBindSubmitVO : wasteInfoBindSubmitVOList) {
            String orgCode = wasteInfoBindSubmitVO.getOrgCode();
            String costCode = wasteInfoBindSubmitVO.getCostCode();
            String hazardousWasteNo = wasteInfoBindSubmitVO.getHazardousWasteNo();
            WasteInfoBindDTO wasteInfoBindDTO = sdsHazardousWasteInfoMapper.selectWasteInfoBindList(orgCode,
                    costCode, StrUtil.EMPTY, hazardousWasteNo);
            if (ObjectUtil.isNotNull(wasteInfoBindDTO)) {
                throw new CloudmesException(SdsResultCode.COST_CODE_EXIST_HAZARDOUS_WASTE_NO.getCode(),
                        String.format(MessageUtils.get(SdsResultCode.COST_CODE_EXIST_HAZARDOUS_WASTE_NO.getLocalCode()),
                                costCode, hazardousWasteNo));
            }
            SdsHwDepartmentPartRelation sdsHwDepartmentPartRelation = new SdsHwDepartmentPartRelation();
            BeanUtil.copyProperties(wasteInfoBindSubmitVO, sdsHwDepartmentPartRelation);
            sdsHwDepartmentPartRelationList.add(sdsHwDepartmentPartRelation);
        }
        this.saveBatch(sdsHwDepartmentPartRelationList);
    }
}
