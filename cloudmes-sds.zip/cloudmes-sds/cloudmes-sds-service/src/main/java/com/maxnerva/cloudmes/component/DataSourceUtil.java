package com.maxnerva.cloudmes.component;

import com.maxnerva.cloudmes.common.models.dto.DatasourceKeyDTO;
import com.maxnerva.cloudmes.common.utils.DSThreadLocalUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
public class DataSourceUtil {

    @Value("${cloudmes.default.cope-code:}")
    private String copeCode;

    @Value("${model.name:}")
    private String serviceName;

    @Value("${factory.code:}")
    private String factoryCode;

    private static DatasourceKeyDTO datasourceKeyDTO;

    @PostConstruct
    public void init(){
        datasourceKeyDTO = new DatasourceKeyDTO();
        datasourceKeyDTO.setCopeCode(copeCode);
        datasourceKeyDTO.setFactoryCode(factoryCode);
        datasourceKeyDTO.setServiceName(serviceName);
    }

    /**
     * 切换SDS数据源
     */
    public static void setSdsDataSource() {
        DSThreadLocalUtil.setDatasourceKey(datasourceKeyDTO);
    }
}
