package com.maxnerva.cloudmes.models.entity.basic;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 物料类别信息
 * </p>
 *
 * @author likun
 * @since 2024-10-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="SdsMaterialClass对象", description="物料类别信息")
public class SdsMaterialClass extends BaseEntity<SdsMaterialClass> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "组织")
    private String orgCode;

    @ApiModelProperty(value = "分类代码")
    private String classCode;

    @ApiModelProperty(value = "物料类别")
    private String className;

}
