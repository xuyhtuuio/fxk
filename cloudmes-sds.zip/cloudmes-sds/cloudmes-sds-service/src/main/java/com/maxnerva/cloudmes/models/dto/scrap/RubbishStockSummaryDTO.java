package com.maxnerva.cloudmes.models.dto.scrap;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class RubbishStockSummaryDTO {

    @ApiModelProperty(value = "报废类别")
    private String scrapDetailClass;

    @ApiModelProperty(value = "报废类别名")
    private String scrapDetailClassName;

    @ApiModelProperty(value = "BU称重量")
    private BigDecimal buStockQty;

    @ApiModelProperty(value = "结余库存")
    private BigDecimal summaryQty;

    @ApiModelProperty(value = "入库量")
    private BigDecimal inStockQty;

    @ApiModelProperty(value = "出库量")
    private BigDecimal outStockQty;
}
