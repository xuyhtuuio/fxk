package com.maxnerva.cloudmes.mapper.waste;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.dto.waste.WasteTransferHeaderDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteTransferHeader;
import com.maxnerva.cloudmes.models.vo.waste.WasteTransferHeaderQueryVO;

import java.util.List;

/**
 * <p>
 * 危废转移单单头 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2025-05-27
 */
public interface SdsHazardousWasteTransferHeaderMapper extends BaseMapper<SdsHazardousWasteTransferHeader> {

    List<WasteTransferHeaderDTO> selectTransferHeaderList(WasteTransferHeaderQueryVO queryVO);

    WasteTransferHeaderDTO selectTransferHeaderById(Integer id);

    String selectFileUrl(Integer id);
}
