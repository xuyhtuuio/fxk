package com.maxnerva.cloudmes.enums;

public enum SteelIssueType {
    /**
     * 鋼桶異常類型
     */
    UNWEIGHTED_BEFORE_LEAVING_THE_FACTORY("UNWEIGHTED_BEFORE_LEAVING_THE_FACTORY", "未称重出厂"),
    DOUBLE_BUCKET_NO("DOUBLE_BUCKET_NO", "同时识别到多个托盘");


    private String dictCode;

    private String dictName;

    SteelIssueType(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public void setDictCode(String dictCode) {
        this.dictCode = dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public void setDictName(String dictName) {
        this.dictName = dictName;
    }

}
