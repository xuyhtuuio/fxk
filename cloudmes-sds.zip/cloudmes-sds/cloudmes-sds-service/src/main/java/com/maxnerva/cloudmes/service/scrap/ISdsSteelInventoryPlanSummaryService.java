package com.maxnerva.cloudmes.service.scrap;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelInventoryPlanSummaryDTO;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelInventoryPlanSummary;
import com.maxnerva.cloudmes.models.vo.scrap.BalanceInventoryWeightVO;
import com.maxnerva.cloudmes.models.vo.scrap.SteelInventoryPlanSummaryQueryVO;

import javax.servlet.http.HttpServletResponse;

public interface ISdsSteelInventoryPlanSummaryService extends IService<SdsSteelInventoryPlanSummary> {

    PageDataDTO<SteelInventoryPlanSummaryDTO> selectPageList(SteelInventoryPlanSummaryQueryVO vo, Boolean isPage);

    void exportDetail(SteelInventoryPlanSummaryQueryVO vo, HttpServletResponse response);

    void balanceWeight(BalanceInventoryWeightVO vo);

}
