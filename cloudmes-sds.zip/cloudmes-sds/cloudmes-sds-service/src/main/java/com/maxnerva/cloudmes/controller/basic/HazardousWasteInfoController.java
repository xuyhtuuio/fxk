package com.maxnerva.cloudmes.controller.basic;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.basic.HazardousWasteInfoDTO;
import com.maxnerva.cloudmes.models.dto.basic.WasteInfoBindDTO;
import com.maxnerva.cloudmes.models.dto.basic.WasteNameInfoDTO;
import com.maxnerva.cloudmes.models.vo.basic.HazardousWasteInfoQueryVO;
import com.maxnerva.cloudmes.service.basic.ISdsHazardousWasteInfoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @ClassName HazardousWasteInfoController
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/7
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "危废物信息管理")
@Slf4j
@RestController
@RequestMapping("/hazardousWasteInfo")
public class HazardousWasteInfoController {

    @Resource
    private ISdsHazardousWasteInfoService sdsHazardousWasteInfoService;

    @ApiOperation("分页查询")
    @PostMapping("/list")
    public R<PageDataDTO<HazardousWasteInfoDTO>> selectWasteInfoPage(
            @RequestBody HazardousWasteInfoQueryVO queryVO) {
        return R.ok(sdsHazardousWasteInfoService.selectWasteInfoPage(queryVO));
    }

    @ApiOperation("查询危废名称列表")
    @GetMapping("/wasteNameList")
    public R<List<String>> selectWastNameList() {
        return R.ok(sdsHazardousWasteInfoService.selectWastNameList());
    }

    @ApiOperation("导出")
    @PostMapping("/export")
    public R<Void> exportHazardousWasteInfo(HttpServletResponse response,
                                            @RequestBody HazardousWasteInfoQueryVO queryVO) {
        sdsHazardousWasteInfoService.exportHazardousWasteInfo(response, queryVO);
        return R.ok();
    }

    @ApiOperation("查询危废名称列表BY费用代码")
    @GetMapping("/wasteNameListByCostCode")
    public R<List<String>> selectWastNameByOrgCodeAndCostCode(@RequestParam String orgCode,
                                                              @RequestParam String costCode) {
        return R.ok(sdsHazardousWasteInfoService.selectWastNameByOrgCodeAndCostCode(orgCode, costCode));
    }

    @ApiOperation("根据危废名称查询危废信息")
    @GetMapping("/wasteInfo")
    public R<WasteInfoBindDTO> selectWasteInfoByWasteCode(@RequestParam String orgCode,
                                                          @RequestParam String costCode,
                                                          @RequestParam String hazardousWasteName) {
        return R.ok(sdsHazardousWasteInfoService.selectWasteInfoByWasteCode(orgCode, costCode, hazardousWasteName));
    }

    @ApiOperation("根据组织费用代码查询危废俗称信息")
    @GetMapping("/wasteNameInfo")
    public R<List<WasteNameInfoDTO>> selectWasteNameInfoByOrgCodeAndCostCode(@RequestParam String orgCode,
                                                                             @RequestParam String costCode) {
        return R.ok(sdsHazardousWasteInfoService.selectWasteNameInfoByOrgCodeAndCostCode(orgCode, costCode));
    }

    @ApiOperation("查询所有危废俗称信息")
    @GetMapping("/allWasteNameInfo")
    public R<List<WasteNameInfoDTO>> selectWasteNameInfo(){
        return R.ok(sdsHazardousWasteInfoService.selectWasteNameInfo());
    }
}
