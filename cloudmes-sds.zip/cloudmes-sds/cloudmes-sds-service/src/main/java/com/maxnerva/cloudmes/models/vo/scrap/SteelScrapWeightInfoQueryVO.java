package com.maxnerva.cloudmes.models.vo.scrap;

import com.maxnerva.cloudmes.models.vo.PageQueryVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

@EqualsAndHashCode(callSuper = true)
@ApiModel("固废称重信息查询vo")
@Data
public class SteelScrapWeightInfoQueryVO extends PageQueryVO {
    @ApiModelProperty("报废小类")
    private String scrapDetailClass;

    @ApiModelProperty(value = "托盘编码")
    private String bucketNo;

    @ApiModelProperty(value = "开始时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime startDateTime;

    @ApiModelProperty(value = "结束时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime endDateTime;

    @ApiModelProperty(value = "厂部")
    private String departmentCode;

    @ApiModelProperty(value = "RFID位置")
    private String positionName;
}
