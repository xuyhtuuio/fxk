package com.maxnerva.cloudmes.models.vo.plan;

import com.maxnerva.cloudmes.models.vo.CommonRequestVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

/**
 * @ClassName PlanInfoAddVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/8
 * @Version 1.0
 * @Since JDK 1.8
 **/
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel("计划信息新增")
public class PlanInfoSaveVO extends CommonRequestVO {

    @ApiModelProperty(value = "年度")
    private String planYear;

    @ApiModelProperty(value = "费用代码")
    private String costCode;

    @ApiModelProperty(value = "部门名称")
    private String depName;

    @ApiModelProperty(value = "本年度原始计划量（KG）")
    private BigDecimal originalWeight;

    @ApiModelProperty("废物俗称")
    private String hazardousWasteName;

    @ApiModelProperty(value = "SDS危废料号")
    private String hazardousWasteNo;
}
