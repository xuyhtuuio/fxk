package com.maxnerva.cloudmes.models.entity;

import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.collect.Sets;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

/**
 * @ClassName BaseEntity
 * @Description 表映射基类
 * @Author Likun
 * @Date 2022/7/20
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Data
@EqualsAndHashCode(callSuper = true)
public class BaseEntity<T extends BaseEntity> extends Model {

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(hidden = true)
    private LocalDateTime createdDt;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(hidden = true)
    private String creator;

    /**
     * 最后修改人
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty(hidden = true)
    private String lastEditor;

    /**
     * 最后一次编辑时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(hidden = true)
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime lastEditedDt;

    @JsonIgnore
    @TableField(exist = false)
    @ApiModelProperty(hidden = true)
    private String relationType;

    @JsonIgnore
    @TableField(exist = false)
    @ApiModelProperty(hidden = true)
    private String conditions;

    @ApiModelProperty(value = "创建人员工id，冗余字段",hidden = true)
    private Integer creatorId;

    @ApiModelProperty(value = "修改人员工id，冗余字段",hidden = true)
    private Integer lastEditorId;

    public Set<BaseSearchField> getConditions() {
        JSONArray json = JSONUtil.parseArray(conditions);
        List<BaseSearchField> list = JSONUtil.toList(json, BaseSearchField.class);
        return Sets.newHashSet(list);
    }
}
