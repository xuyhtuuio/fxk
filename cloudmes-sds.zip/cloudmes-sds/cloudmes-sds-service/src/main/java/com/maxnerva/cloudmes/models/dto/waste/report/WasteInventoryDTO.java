package com.maxnerva.cloudmes.models.dto.waste.report;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @ClassName WasteInventoryDTO
 * @Description TODO
 * @Author Likun
 * @Date 2025/6/20
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("危废库存dto")
@Data
public class WasteInventoryDTO {

    @ApiModelProperty(value = "废料料号")
    private String hazardousWasteNo;

    @ApiModelProperty(value = "废物俗称")
    private String hazardousWasteName;

    @ApiModelProperty(value = "产废重量(KG)")
    private BigDecimal totalApplyNetWeight;

    @ApiModelProperty(value = "入库重量(KG)")
    private BigDecimal totalInstoreNetWeight;

    @ApiModelProperty(value = "出库重量(KG)")
    private BigDecimal shipNetWeight;

    @ApiModelProperty(value = "结余库存(KG)")
    private BigDecimal remainNetWeight;
}
