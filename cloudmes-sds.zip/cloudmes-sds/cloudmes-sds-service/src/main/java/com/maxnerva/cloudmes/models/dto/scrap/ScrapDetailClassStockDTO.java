package com.maxnerva.cloudmes.models.dto.scrap;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class ScrapDetailClassStockDTO {

    @ApiModelProperty(value = "报废类别")
    private String scrapDetailClass;

    @ApiModelProperty(value = "净重")
    private BigDecimal netWeight;

}
