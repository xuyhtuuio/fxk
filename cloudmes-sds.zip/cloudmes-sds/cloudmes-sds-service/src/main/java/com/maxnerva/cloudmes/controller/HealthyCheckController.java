package com.maxnerva.cloudmes.controller;

import com.maxnerva.cloudmes.common.utils.R;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author likun
 */
@Api(tags = "健康检查")
@RestController
@RequestMapping("/health")
public class HealthyCheckController {

    @ApiOperation(value = "健康检查接口")
    @GetMapping("/check")
    public R check() {
        return R.ok();
    }

}
