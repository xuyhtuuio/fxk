package com.maxnerva.cloudmes.models.entity.basic;

import com.baomidou.mybatisplus.annotation.TableName;

import java.math.BigDecimal;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 固废缴款期限方案
 * </p>
 *
 * @author baomidou
 * @since 2025-01-08
 */
@TableName("sds_steel_payment_end_date_config")
@ApiModel(value = "SdsSteelPaymentDeadline对象", description = "固废缴款期限方案")
@Data
public class SdsSteelPaymentEndDateConfig extends BaseEntity<SdsSteelPaymentEndDateConfig> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("厂商CODE")
    private String mfgCode;

    @ApiModelProperty("百分比")
    private BigDecimal leftPercentage;

    @ApiModelProperty("百分比")
    private BigDecimal rightPercentage;

    @ApiModelProperty("期限计算方式 0 天，1 下个月几号")
    private String endDateType;

    @ApiModelProperty("期限计算数")
    private Integer num;

    @ApiModelProperty(value = "是否左闭合")
    private Boolean isLeftClose;

    @ApiModelProperty(value = "是否右闭合")
    private Boolean isRightClose;

    @ApiModelProperty(value = "文本模板")
    private String template;
}
