package com.maxnerva.cloudmes.service.scrap.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.NumberUtil;
import cn.hutool.core.util.ReflectUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.excel.handler.FreezeAndFilterHandler;
import com.maxnerva.cloudmes.excel.handler.MergeHandler;
import com.maxnerva.cloudmes.excel.handler.TitleHandler;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelPaymentHeaderMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelPaymentSalesSummaryMapper;
import com.maxnerva.cloudmes.models.dto.excel.scrap.SteelPaymentSalesSummaryExportDTO;
import com.maxnerva.cloudmes.models.dto.excel.scrap.SteelScrapWeightRejectExportDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelPaymentSalesSummaryDTO;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelPaymentHeader;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelPaymentSalesSummary;
import com.maxnerva.cloudmes.models.vo.excel.ExcelMergeCellValue;
import com.maxnerva.cloudmes.service.scrap.ISdsSteelPaymentSalesSummaryService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;

import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
public class SdsSteelPaymentSalesSummaryService extends ServiceImpl<SdsSteelPaymentSalesSummaryMapper, SdsSteelPaymentSalesSummary> implements ISdsSteelPaymentSalesSummaryService {

    @Autowired
    SdsSteelPaymentHeaderMapper steelPaymentHeaderMapper;

    @Override
    public List<SteelPaymentSalesSummaryDTO> selectList(String paymentDocNo) {
        SdsSteelPaymentHeader steelPaymentHeader = steelPaymentHeaderMapper.selectOne(Wrappers.<SdsSteelPaymentHeader>lambdaQuery()
                .eq(SdsSteelPaymentHeader::getDocNo, paymentDocNo)
                .last("limit 1")
        );
        List<SdsSteelPaymentSalesSummary> steelPaymentSalesSummaryList = baseMapper.selectList(Wrappers.<SdsSteelPaymentSalesSummary>lambdaQuery()
                .eq(SdsSteelPaymentSalesSummary::getPaymentDocNo, paymentDocNo)
        );
        Map<String, List<SdsSteelPaymentSalesSummary>> scrapDetailClassSalesSummaryGroupMap = steelPaymentSalesSummaryList.stream()
                    .collect(Collectors.groupingBy(SdsSteelPaymentSalesSummary::getScrapDetailClass));
        List<SteelPaymentSalesSummaryDTO> result = ListUtil.toList();
        BigDecimal summaryTotalSplitShipNetWeight = BigDecimal.ZERO;
        BigDecimal summaryTotalSplitShipAccount = steelPaymentHeader.getSales();
        BigDecimal summaryTotalInStoreNetWeight = BigDecimal.ZERO;
        Integer index = 1;
        for (List<SdsSteelPaymentSalesSummary> salesSummaryList : scrapDetailClassSalesSummaryGroupMap.values()){
            List<SteelPaymentSalesSummaryDTO> subResult = ListUtil.toList();
            for (SdsSteelPaymentSalesSummary salesSummary : salesSummaryList){
                SteelPaymentSalesSummaryDTO dto = new SteelPaymentSalesSummaryDTO();
                ExcelMergeCellValue<String> idx = new ExcelMergeCellValue(index.toString());
                idx.setRowSpan(0);
                ExcelMergeCellValue<String> scrapPartName = new ExcelMergeCellValue(salesSummary.getScrapPartName());
                scrapPartName.setRowSpan(0);
                ExcelMergeCellValue<String> costCode = new ExcelMergeCellValue(salesSummary.getCostCode());
                ExcelMergeCellValue<BigDecimal> splitShipNetWeight = new ExcelMergeCellValue(salesSummary.getSplitShipNetWeight());
                ExcelMergeCellValue<BigDecimal> splitShipAccount = new ExcelMergeCellValue(salesSummary.getSplitShipAccount());
                ExcelMergeCellValue<BigDecimal> inStoreNetWeight = new ExcelMergeCellValue(salesSummary.getInStoreNetWeight());
                ExcelMergeCellValue<BigDecimal> inStorePercentage = new ExcelMergeCellValue(salesSummary.getInStorePercentage());
                ExcelMergeCellValue<String> inStorePercentageName = new ExcelMergeCellValue(NumberUtil.decimalFormat("0.00%", salesSummary.getInStorePercentage()));
                dto.setIndex(idx);
                dto.setScrapPartName(scrapPartName);
                dto.setCostCode(costCode);
                dto.setSplitShipNetWeight(splitShipNetWeight);
                dto.setSplitShipAccount(splitShipAccount);
                dto.setInStoreNetWeight(inStoreNetWeight);
                dto.setInStorePercentage(inStorePercentage);
                dto.setInStorePercentageName(inStorePercentageName);
                subResult.add(dto);
            }


            SteelPaymentSalesSummaryDTO firstDTO = subResult.get(0);
            firstDTO.getIndex().setRowSpan(salesSummaryList.size() + 1);
            firstDTO.getScrapPartName().setRowSpan(salesSummaryList.size());

            SdsSteelPaymentSalesSummary firstSalesSummary = salesSummaryList.get(0);
            SteelPaymentSalesSummaryDTO lastDTO = new SteelPaymentSalesSummaryDTO();
            ExcelMergeCellValue<String> idx = new ExcelMergeCellValue(index.toString());
            idx.setRowSpan(0);
            ExcelMergeCellValue<String> scrapPartName = new ExcelMergeCellValue(firstSalesSummary.getScrapPartName() + " 合計");
            scrapPartName.setColSpan(2);
            ExcelMergeCellValue<String> costCode = new ExcelMergeCellValue(StrUtil.EMPTY);
            costCode.setColSpan(0);
            BigDecimal totalSplitShipNetWeight = salesSummaryList.stream().map(item -> item.getSplitShipNetWeight()).reduce(BigDecimal.ZERO, BigDecimal::add);
            ExcelMergeCellValue<BigDecimal> splitShipNetWeight = new ExcelMergeCellValue(totalSplitShipNetWeight);
            BigDecimal totalSplitShipAccount = salesSummaryList.stream().map(item -> item.getSplitShipAccount()).reduce(BigDecimal.ZERO, BigDecimal::add);
            ExcelMergeCellValue<BigDecimal> splitShipAccount = new ExcelMergeCellValue(totalSplitShipAccount);
            BigDecimal totalInStoreNetWeight = salesSummaryList.stream().map(item -> item.getInStoreNetWeight()).reduce(BigDecimal.ZERO, BigDecimal::add);
            ExcelMergeCellValue<BigDecimal> inStoreNetWeight = new ExcelMergeCellValue(totalInStoreNetWeight);
            ExcelMergeCellValue<BigDecimal> inStorePercentage = new ExcelMergeCellValue(BigDecimal.ONE);
            ExcelMergeCellValue<String> inStorePercentageName = new ExcelMergeCellValue(NumberUtil.decimalFormat("0.00%", BigDecimal.ONE));

            lastDTO.setIndex(idx);
            lastDTO.setScrapPartName(scrapPartName);
            lastDTO.setCostCode(costCode);
            lastDTO.setSplitShipNetWeight(splitShipNetWeight);
            lastDTO.setSplitShipAccount(splitShipAccount);
            lastDTO.setInStoreNetWeight(inStoreNetWeight);
            lastDTO.setInStorePercentage(inStorePercentage);
            lastDTO.setInStorePercentageName(inStorePercentageName);
            subResult.add(lastDTO);

            summaryTotalSplitShipNetWeight = summaryTotalSplitShipNetWeight.add(totalSplitShipNetWeight);
            summaryTotalInStoreNetWeight = summaryTotalInStoreNetWeight.add(totalInStoreNetWeight);
            index ++;

            result.addAll(subResult);
        }
        // 合計
        SteelPaymentSalesSummaryDTO summaryDTO = new SteelPaymentSalesSummaryDTO();
        ExcelMergeCellValue idx = new ExcelMergeCellValue("匯總");
        idx.setColSpan(3);
        summaryDTO.setIndex(idx);
        summaryDTO.setScrapPartName(new ExcelMergeCellValue(StrUtil.EMPTY, 1, 0));
        summaryDTO.setCostCode(new ExcelMergeCellValue(StrUtil.EMPTY, 1, 0));
        summaryDTO.setSplitShipNetWeight(new ExcelMergeCellValue(summaryTotalSplitShipNetWeight));
        summaryDTO.setSplitShipAccount(new ExcelMergeCellValue(summaryTotalSplitShipAccount));
        summaryDTO.setInStoreNetWeight(new ExcelMergeCellValue(summaryTotalInStoreNetWeight));
        summaryDTO.setInStorePercentage(new ExcelMergeCellValue(BigDecimal.ONE));
        ExcelMergeCellValue<String> inStorePercentageName = new ExcelMergeCellValue(NumberUtil.decimalFormat("0.00%", BigDecimal.ONE));
        summaryDTO.setInStorePercentageName(inStorePercentageName);
        result.add(summaryDTO);
        return result;
    }

    @Override
    public void exportDetail(String paymentDocNo, HttpServletResponse response) {
        List<SteelPaymentSalesSummaryDTO> list = selectList(paymentDocNo);
        List<String> fieldOrderList = ListUtil.toList("index", "scrapPartName", "costCode", "splitShipNetWeight", "splitShipAccount", "inStoreNetWeight", "inStorePercentage");
        List<List<Integer>> mergeList = ListUtil.toList();
        List<SteelPaymentSalesSummaryExportDTO> exportDTOList = ListUtil.toList();
        int rowIndex = 3;
        for (int i = 0; i < list.size(); i ++){
            SteelPaymentSalesSummaryDTO salesSummaryDTO = list.get(i);
            for (int colIndex = 0; colIndex < fieldOrderList.size(); colIndex ++){
                String field = fieldOrderList.get(colIndex);
                ExcelMergeCellValue excelMergeCellValue = (ExcelMergeCellValue)ReflectUtil.getFieldValue(salesSummaryDTO, field);
                if (excelMergeCellValue.getRowSpan() > 1 || excelMergeCellValue.getColSpan() > 1){
                    mergeList.add(ListUtil.toList(rowIndex, rowIndex + excelMergeCellValue.getRowSpan() - 1, colIndex, colIndex + excelMergeCellValue.getColSpan() - 1));
                }
            }
            SteelPaymentSalesSummaryExportDTO dto = new SteelPaymentSalesSummaryExportDTO();
            dto.setIndex(salesSummaryDTO.getIndex().getValue());
            dto.setCostCode(salesSummaryDTO.getCostCode().getValue());
            dto.setInStoreNetWeight(salesSummaryDTO.getInStoreNetWeight().getValue());
            dto.setInStorePercentage(salesSummaryDTO.getInStorePercentage().getValue());
            dto.setScrapPartName(salesSummaryDTO.getScrapPartName().getValue());
            dto.setSplitShipAccount(salesSummaryDTO.getSplitShipAccount().getValue());
            dto.setSplitShipNetWeight(salesSummaryDTO.getSplitShipNetWeight().getValue());
            exportDTOList.add(dto);
            rowIndex ++;
        }

        String fileName = "废料销售汇总" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), SteelPaymentSalesSummaryExportDTO.class)
                    .relativeHeadRowIndex(2)
                    .sheet(fileName)
                    .registerWriteHandler(new MergeHandler(mergeList))
                    .registerWriteHandler(new TitleHandler(0, "天津富聯西區園區廢料銷售匯總表", 6))
                    .registerWriteHandler(new FreezeAndFilterHandler(3))
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CloudmesException(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getLocalCode()));
        }
    }
}
