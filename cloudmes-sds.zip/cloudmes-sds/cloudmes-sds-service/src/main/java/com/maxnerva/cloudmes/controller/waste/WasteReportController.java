package com.maxnerva.cloudmes.controller.waste;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.waste.report.WasteInventoryDTO;
import com.maxnerva.cloudmes.models.dto.waste.report.WasteInventoryDetailDTO;
import com.maxnerva.cloudmes.models.dto.waste.report.WasteInventoryOverdueWarnDTO;
import com.maxnerva.cloudmes.models.vo.waste.report.WasteInventoryDetailQueryVO;
import com.maxnerva.cloudmes.models.vo.waste.report.WasteInventoryOverdueWarnQueryVO;
import com.maxnerva.cloudmes.models.vo.waste.report.WasteInventoryQueryVO;
import com.maxnerva.cloudmes.service.waste.IWasteReportService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

/**
 * @ClassName ReportController
 * @Description TODO
 * @Author Likun
 * @Date 2025/6/20
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "危废报表管理")
@Slf4j
@RestController
@RequestMapping("/wasteReport")
public class WasteReportController {

    @Resource
    private IWasteReportService wasteReportService;

    @PostMapping("inventoryList")
    @ApiOperation("结余库存查询")
    public R<PageDataDTO<WasteInventoryDTO>> selectWasteInventoryPage(
            @RequestBody WasteInventoryQueryVO queryVO) {
        return R.ok(wasteReportService.selectWasteInventoryPage(queryVO));
    }

    @PostMapping("inventoryDetailList")
    @ApiOperation("结余库存详情查询")
    public R<PageDataDTO<WasteInventoryDetailDTO>> selectWasteInventoryDetailPage(
            @RequestBody WasteInventoryDetailQueryVO queryVO) {
        return R.ok(wasteReportService.selectWasteInventoryDetailPage(queryVO));
    }

    @ApiOperation("导出结余库存")
    @PostMapping("/exportInventory")
    public R<Void> exportPlanInfoAddLog(HttpServletResponse response,
                                        @RequestBody WasteInventoryQueryVO queryVO) {
        wasteReportService.exportWasteInventory(response, queryVO);
        return R.ok();
    }

    @ApiOperation("导出结余库存详情")
    @PostMapping("/exportInventoryDetail")
    public R<Void> exportPlanInfoAddLog(HttpServletResponse response,
                                        @RequestBody WasteInventoryDetailQueryVO queryVO) {
        wasteReportService.exportWasteInventoryDetail(response, queryVO);
        return R.ok();
    }


    @ApiOperation("库存超期预警查询")
    @PostMapping("/overdueWarnList")
    public R<PageDataDTO<WasteInventoryOverdueWarnDTO>> selectWasteInventoryOverdueWarnPage(
            @RequestBody WasteInventoryOverdueWarnQueryVO queryVO) {
        return R.ok(wasteReportService.selectWasteInventoryOverdueWarnPage(queryVO));
    }

    @ApiOperation("导出库存超期预警")
    @PostMapping("/exportOverdueWarnInfo")
    public R<Void> exportOverdueWarnInfo(HttpServletResponse response,
                                         @RequestBody WasteInventoryOverdueWarnQueryVO queryVO) {
        wasteReportService.exportWasteInventoryOverdueWarnInfo(response, queryVO);
        return R.ok();
    }
}
