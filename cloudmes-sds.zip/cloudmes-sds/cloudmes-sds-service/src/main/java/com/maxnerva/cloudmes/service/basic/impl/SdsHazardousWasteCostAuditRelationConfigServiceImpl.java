package com.maxnerva.cloudmes.service.basic.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.mapper.basic.SdsHazardousWasteCostAuditRelationConfigMapper;
import com.maxnerva.cloudmes.models.entity.basic.SdsHazardousWasteCostAuditRelationConfig;
import com.maxnerva.cloudmes.service.basic.ISdsHazardousWasteCostAuditRelationConfigService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 签核课级配置关系表 服务实现类
 * </p>
 *
 * @author likun
 * @since 2025-05-14
 */
@Service
public class SdsHazardousWasteCostAuditRelationConfigServiceImpl extends
        ServiceImpl<SdsHazardousWasteCostAuditRelationConfigMapper, SdsHazardousWasteCostAuditRelationConfig>
        implements ISdsHazardousWasteCostAuditRelationConfigService {

}
