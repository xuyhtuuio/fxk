package com.maxnerva.cloudmes.models.dto.scrap;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class RubbishInStockDTO {

    @ApiModelProperty(value = "厂部")
    private String departmentCodeName;

    @ApiModelProperty(value = "报废类别")
    private String scrapDetailClass;

    @ApiModelProperty(value = "报废类别名")
    private String scrapDetailClassName;

    @ApiModelProperty(value = "托盘编码")
    private String bucketNo;

    @ApiModelProperty(value = "托盘重量")
    private BigDecimal bucketWeight;

    @ApiModelProperty(value = "单位")
    private String uom;

    @ApiModelProperty("报废厂毛重")
    private BigDecimal rubbishGrossWeight;

    @ApiModelProperty("报废厂净重")
    private BigDecimal rubbishNetWeight;

    @ApiModelProperty("报废厂称重人")
    private String rubbishWeighEmpNo;

    @ApiModelProperty("报废厂称重时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime rubbishWeighDt;
}
