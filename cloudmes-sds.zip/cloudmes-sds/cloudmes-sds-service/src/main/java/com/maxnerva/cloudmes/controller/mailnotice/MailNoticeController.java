package com.maxnerva.cloudmes.controller.mailnotice;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.service.scrap.ISteelPaymentOrderService;
import com.maxnerva.cloudmes.service.scrap.ISteelScrapWeightService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(tags = "邮件提醒")
@Slf4j
@RestController
@RequestMapping("/mailNotice")
public class MailNoticeController {

    @Autowired
    ISteelScrapWeightService steelScrapWeightService;

    @Autowired
    ISteelPaymentOrderService steelPaymentOrderService;

    @ApiOperation("废料厂拒收邮件通知")
    @PostMapping("/scrapRejectSendMail")
    R scrapRejectSendMail(){
        steelScrapWeightService.scrapRejectSendMail();
        return R.ok();
    }

    @ApiOperation("固废本期销售额超出邮件通知")
    @PostMapping("/salesMailNotify")
    R salesMailNotify(){
        steelPaymentOrderService.salesMailNotify();
        return R.ok();
    }

    @ApiOperation("固废超24小时未入废料厂邮件通知")
    @PostMapping("/timeOutToRubbishSendMail")
    R timeOutToRubbishSendMail() {
        steelScrapWeightService.timeOutToRubbishSendMail();
        return R.ok();
    }

    @ApiOperation("缴款单发票邮件通知")
    @PostMapping("/paymentOrderSendMail")
    R paymentOrderSendMail() {
        steelPaymentOrderService.paymentOrderUploadSendMail();
        return R.ok();
    }

    @ApiOperation("缴款单文件上传")
    @PostMapping("/paymentOrderUploadSendMail")
    R paymentOrderUploadSendMail(){
        steelPaymentOrderService.paymentOrderUploadSendMail();
        return R.ok();
    }

}