package com.maxnerva.cloudmes.models.entity.scrap;

import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName SdsHikAreaCodeLink
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/1/4 下午 03:23
 * @Version 1.0
 **/

@TableName("sds_hik_area_code_link")
@ApiModel(value = "SdsHikAreaCodeLink对象", description = "地区与摄像头编码对应配置表")
@Data
public class SdsHikAreaCodeLink {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("摄像头唯一编码")
    private String cameraCode;

    @ApiModelProperty("地区名称")
    private String areaName;

    @ApiModelProperty("地区编码")
    private String areaCode;

    @ApiModelProperty("区域类型")
    private String areaType;

    @ApiModelProperty("区域类型名称")
    private String areaTypeName;
}
