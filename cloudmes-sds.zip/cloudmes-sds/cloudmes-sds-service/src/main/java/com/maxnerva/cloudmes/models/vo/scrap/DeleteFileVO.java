package com.maxnerva.cloudmes.models.vo.scrap;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @ClassName DeleteFileVO
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/3/25 上午 10:15
 * @Version 1.0
 **/
@Data
public class DeleteFileVO {

    @ApiModelProperty(value = "报废处理单ID")
    private String docNo;

    @ApiModelProperty(value = "报废文件ID列表")
    private List<Integer> idList;
}
