package com.maxnerva.cloudmes.models.dto.basic;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName WasteNameInfoDTO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/8
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("废物俗称信息查询dto")
@Data
public class WasteNameInfoDTO {

    @ApiModelProperty(value = "危废物信息表的SDS料号")
    private String hazardousWasteNo;

    @ApiModelProperty(value = "废物俗称")
    private String hazardousWasteName;

}
