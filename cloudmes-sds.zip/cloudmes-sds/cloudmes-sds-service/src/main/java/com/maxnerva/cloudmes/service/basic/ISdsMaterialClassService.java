package com.maxnerva.cloudmes.service.basic;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.models.dto.basic.MaterialClassDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsMaterialClass;
import com.maxnerva.cloudmes.models.vo.basic.MaterialClassQueryVO;
import com.maxnerva.cloudmes.models.vo.basic.MaterialClassSaveOrUpdateVO;
import com.maxnerva.cloudmes.models.vo.excel.ExcelImportVO;

import javax.servlet.http.HttpServletResponse;

/**
 * <p>
 * 物料类别信息 服务类
 * </p>
 *
 * @author likun
 * @since 2024-10-28
 */
public interface ISdsMaterialClassService extends IService<SdsMaterialClass> {

    PageDataDTO<MaterialClassDTO> selectMaterialClassPage(MaterialClassQueryVO queryVO);

    void saveMaterialClass(MaterialClassSaveOrUpdateVO materialClassSaveOrUpdateVO);

    void updateMaterialClass(MaterialClassSaveOrUpdateVO materialClassSaveOrUpdateVO);

    void deleteMaterialClass(Integer id);

    void importMaterialClass(ExcelImportVO excelImportVO);

    void exportMaterialClass(HttpServletResponse response, MaterialClassQueryVO queryVO);
}
