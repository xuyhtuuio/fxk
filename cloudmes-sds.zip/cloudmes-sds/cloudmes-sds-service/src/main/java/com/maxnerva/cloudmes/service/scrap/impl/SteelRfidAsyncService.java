package com.maxnerva.cloudmes.service.scrap.impl;

import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.common.utils.RedisUtil;
import com.maxnerva.cloudmes.component.DataSourceUtil;
import com.maxnerva.cloudmes.component.RFIDSocketClient;
import com.maxnerva.cloudmes.config.RFIDConfig;
import com.maxnerva.cloudmes.enums.SteelIssueType;
import com.maxnerva.cloudmes.mapper.basic.SdsSteelReturnConfigMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsRfidSteelConfigMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsRfidSteelIssueLogMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelScrapWeightInfoMapper;
import com.maxnerva.cloudmes.models.entity.basic.SdsSteelReturnConfig;
import com.maxnerva.cloudmes.models.entity.scrap.SdsRfidSteelIssueLog;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapWeightInfo;
import com.maxnerva.cloudmes.service.scrap.ISteelRfidAsyncService;
import com.maxnerva.cloudmes.service.scrap.ISteelScrapWeightService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
public class SteelRfidAsyncService implements ISteelRfidAsyncService {

    @Autowired
    RFIDConfig rfidConfig;

    @Autowired
    ISteelScrapWeightService steelScrapWeightService;

    @Autowired
    SdsSteelScrapWeightInfoMapper steelScrapWeightInfoMapper;

    @Autowired
    SdsSteelReturnConfigMapper sdsSteelReturnConfigMapper;

    @Autowired
    SdsRfidSteelConfigMapper rfidSteelConfigMapper;

    @Autowired
    SdsRfidSteelIssueLogMapper rfidSteelIssueLogMapper;

    @Autowired
    SteelScrapWeightService IsteelScrapWeightService;

    @Autowired
    RedisUtil redisUtil;

    @Override
    @Async
    public void dealWithRFID(String key) {
        DataSourceUtil.setSdsDataSource();
        Set<String> rfidAsyncSymbolSet = rfidConfig.getRfidAsyncSymbolSet();
        rfidAsyncSymbolSet.add(key);
        try {
            Map<String, Set<String>> rfidCardMap = rfidConfig.getRfidCardMap();
            Set<String> carSet = rfidCardMap.get(key);
            Set<String> actualCardSet = new HashSet();
            String currentBucketNo = null;
            for (String card : carSet){
                if (rfidConfig.getCardLinkMap().containsKey(card)) {
                    String actualCard = rfidConfig.getCardLinkMap().get(card);
                    currentBucketNo = actualCard;
                    actualCardSet.add(actualCard);
                }
            }
            carSet.clear();
            RFIDSocketClient rfidSocketClient = rfidConfig.getRfidSocketClientMap().get(key);
            if (BooleanUtil.isFalse(rfidSocketClient.getIsConnected())){
                return;
            }
            SdsRfidSteelIssueLog rfidSteelIssueLog = rfidSteelIssueLogMapper.selectOne(Wrappers.<SdsRfidSteelIssueLog>lambdaQuery()
                    .eq(SdsRfidSteelIssueLog::getPositionName, rfidSocketClient.getPositionName())
                    .eq(SdsRfidSteelIssueLog::getHandleFlag, "N")
                    .last("limit 1")
            );
            if (ObjectUtil.isNotNull(rfidSteelIssueLog)){
                // 存在未处理异常，亮红灯
                rfidSocketClient.turnLight("2");
                return;
            }

            log.info("{}", actualCardSet.stream().collect(Collectors.joining(",")));
            if (actualCardSet.size() == 1) {
                // 拒收返回，称重完返回。需要修改return标识。防止还没进入就绿转红灯。需要豁免60s
                String greenMark = (String)redisUtil.get(rfidConfig.getLIGHT_GREEN_EXPIRED_KEY() + currentBucketNo);
                if (StrUtil.isNotBlank(greenMark)){
                    // 亮绿灯
                    rfidSocketClient.turnLight("1");
                    log.info("PASS -------------------------");
                    return;
                }
                // 当前标签
                SdsSteelScrapWeightInfo currentBucketInfo = steelScrapWeightInfoMapper.selectOne(Wrappers.<SdsSteelScrapWeightInfo>lambdaQuery()
                        .eq(SdsSteelScrapWeightInfo::getBucketNo, currentBucketNo)
                        .orderByDesc(SdsSteelScrapWeightInfo::getId)
                        .last("limit 1")
                );
                // isreturn表查询
                SdsSteelReturnConfig sdsSteelReturnConfig = sdsSteelReturnConfigMapper.selectOne(Wrappers.<SdsSteelReturnConfig>lambdaQuery()
                        .eq(SdsSteelReturnConfig::getBucketNo, currentBucketNo)
                        .last("limit 1")
                );
                if (ObjectUtil.isEmpty(sdsSteelReturnConfig)) {
                    //  警告灯
                    rfidSocketClient.turnLight("2");
                    log.error("{}", "当前无该标签称重记录 ------------------------------");
                    IsteelScrapWeightService.catchSteelIssue(SteelIssueType.UNWEIGHTED_BEFORE_LEAVING_THE_FACTORY.getDictCode()
                            , SteelIssueType.UNWEIGHTED_BEFORE_LEAVING_THE_FACTORY.getDictName(), currentBucketNo, rfidSocketClient.getPositionName());
                } else if (ObjectUtil.isNotEmpty(currentBucketInfo)) {
                    if ("N".equals(sdsSteelReturnConfig.getIsReturn()) && "Y".equals(currentBucketInfo.getWeighFlag())) {
                        if ("Y".equals(currentBucketInfo.getAcceptFlag())) {
                            turnReturnStatus("Y", currentBucketNo);
                            redisUtil.set(rfidConfig.getLIGHT_GREEN_EXPIRED_KEY() + currentBucketNo, "Y", rfidConfig.getPassingTime());
                        }
                        // 亮绿灯
                        rfidSocketClient.turnLight("1");
                        log.info("PASS -------------------------");
                    } else {
                        //  警告灯
                        rfidSocketClient.turnLight("2");
                        log.error("{}", "WARNING --------------------");
                        IsteelScrapWeightService.catchSteelIssue(SteelIssueType.UNWEIGHTED_BEFORE_LEAVING_THE_FACTORY.getDictCode()
                                , SteelIssueType.UNWEIGHTED_BEFORE_LEAVING_THE_FACTORY.getDictName(), currentBucketNo, rfidSocketClient.getPositionName());
                    }
                } else if ("N".equals(sdsSteelReturnConfig.getIsReturn())) {
                    // 亮绿灯, 第一次称重被拒收
                    rfidSocketClient.turnLight("1");
                    turnReturnStatus("Y", currentBucketNo);
                    redisUtil.set(rfidConfig.getLIGHT_GREEN_EXPIRED_KEY() + currentBucketNo, "Y", rfidConfig.getPassingTime());
                    log.info("PASS -------------------------");
                } else if ("Y".equals(sdsSteelReturnConfig.getIsReturn())){
                    // 黄灯
                    rfidSocketClient.turnLight("2");
                    log.info("当前无该标签称重记录或未接收 ------------------------------");
                    IsteelScrapWeightService.catchSteelIssue(SteelIssueType.UNWEIGHTED_BEFORE_LEAVING_THE_FACTORY.getDictCode()
                            , SteelIssueType.UNWEIGHTED_BEFORE_LEAVING_THE_FACTORY.getDictName(), currentBucketNo, rfidSocketClient.getPositionName());
                }
            } else if (actualCardSet.size() > 1) {
                // 黄灯
                rfidSocketClient.turnLight("2");
                IsteelScrapWeightService.catchSteelIssue(SteelIssueType.DOUBLE_BUCKET_NO.getDictCode()
                        , String.format("%s,%s", SteelIssueType.DOUBLE_BUCKET_NO.getDictName(), actualCardSet.stream().collect(Collectors.joining(","))), currentBucketNo, rfidSocketClient.getPositionName());
            } else {
                rfidSocketClient.turnLight("3");
            }
        } catch (Exception e) {
            log.error("steel-rfid {} prevent leave err", e);
        } finally {
            rfidAsyncSymbolSet.remove(key);
        }
    }

    private void turnReturnStatus(String currentStatus, String currentBucketNo) {
        int y = sdsSteelReturnConfigMapper.update(null, Wrappers.<SdsSteelReturnConfig>lambdaUpdate()
                .set(SdsSteelReturnConfig::getIsReturn, currentStatus)
                .eq(SdsSteelReturnConfig::getBucketNo, currentBucketNo)

        );
        log.info("当前更新数量为: {} ---------------------", y);
    }

}
