package com.maxnerva.cloudmes.service.basic.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.mapper.basic.SdsPrintTemplateConfigMapper;
import com.maxnerva.cloudmes.models.entity.basic.SdsPrintTemplateConfig;
import com.maxnerva.cloudmes.service.basic.ISdsPrintTemplateConfigService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 打印模板配置关系表 服务实现类
 * </p>
 *
 * @author likun
 * @since 2022-12-12
 */
@Service
public class SdsPrintTemplateConfigServiceImpl extends ServiceImpl<SdsPrintTemplateConfigMapper, SdsPrintTemplateConfig>
        implements ISdsPrintTemplateConfigService {

}
