package com.maxnerva.cloudmes.models.vo.excel;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author likun
 */

@ApiModel("excel导入公共vo")
@Data
public class ExcelImportVO {

    @ApiModelProperty("工厂组织")
    private String orgCode;

    @ApiModelProperty("excel文件")
    private MultipartFile file;
}
