package com.maxnerva.cloudmes.models.dto.waste;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

/**
 * @ClassName NoStorageApplyShipScanDTO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/26
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel(value = "立产立清申请出库扫描返回dto")
@Data
public class NoStorageApplyShipScanDTO {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "说明单号")
    private String docNo;

    @ApiModelProperty(value = "单据类型")
    private String docType;

    @ApiModelProperty(value = "SDS料号")
    private String hazardousWasteNo;

    @ApiModelProperty(value = "废物俗称")
    private String hazardousWasteName;

    @ApiModelProperty(value = "费用代码")
    private String costCode;

    @ApiModelProperty(value = "入库净重")
    private BigDecimal instoreNetWeight;
}
