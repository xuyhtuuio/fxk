package com.maxnerva.cloudmes.controller.basic;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.basic.CostCodeNameDTO;
import com.maxnerva.cloudmes.models.dto.basic.HwDepartmentCostConfigDTO;
import com.maxnerva.cloudmes.models.vo.basic.HwDepartmentCostConfigQueryVO;
import com.maxnerva.cloudmes.service.basic.ISdsHwDepartmentCostConfigService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName HwDepartmentCostConfigController
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/7
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "费用管理")
@Slf4j
@RestController
@RequestMapping("/hwDepartmentCostConfig")
public class HwDepartmentCostConfigController {

    @Resource
    private ISdsHwDepartmentCostConfigService sdsHwDepartmentCostConfigService;

    @ApiOperation("分页查询")
    @PostMapping("/list")
    public R<PageDataDTO<HwDepartmentCostConfigDTO>> selectConfigPage(
            @RequestBody HwDepartmentCostConfigQueryVO queryVO){
        return R.ok(sdsHwDepartmentCostConfigService.selectConfigPage(queryVO));
    }

    @ApiOperation("费用代码查询")
    @GetMapping("/costCodeList")
    public R<List<String>> selectCostCodeListByOrgCode(@RequestParam("orgCode") String orgCode){
        return R.ok(sdsHwDepartmentCostConfigService.selectCostCodeListByOrgCode(orgCode));
    }

    @ApiOperation("费用代码信息查询")
    @GetMapping("/costCodeInfoList")
    public R<List<CostCodeNameDTO>> selectCostCodeNameListByOrgCode(@RequestParam("orgCode") String orgCode){
        return R.ok(sdsHwDepartmentCostConfigService.selectCostCodeNameListByOrgCode(orgCode));
    }
}
