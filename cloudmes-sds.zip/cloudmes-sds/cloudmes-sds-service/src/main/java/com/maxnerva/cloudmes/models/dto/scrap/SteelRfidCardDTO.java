package com.maxnerva.cloudmes.models.dto.scrap;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class SteelRfidCardDTO {

    @ApiModelProperty(value = "RFID CARD")
    private String rfidCard;

    @ApiModelProperty(value = "实际编码")
    private String actualCard;
}
