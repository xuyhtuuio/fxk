package com.maxnerva.cloudmes.service.basic.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.mapper.basic.SdsHwDepartmentCostConfigMapper;
import com.maxnerva.cloudmes.models.dto.basic.CostCodeNameDTO;
import com.maxnerva.cloudmes.models.dto.basic.HwDepartmentCostConfigDTO;
import com.maxnerva.cloudmes.models.dto.basic.SteelBucketDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsHwDepartmentCostConfig;
import com.maxnerva.cloudmes.models.vo.basic.HwDepartmentCostConfigQueryVO;
import com.maxnerva.cloudmes.service.basic.ISdsHwDepartmentCostConfigService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 危废费用部门配置表 服务实现类
 * </p>
 *
 * @author likun
 * @since 2025-05-06
 */
@Service
public class SdsHwDepartmentCostConfigServiceImpl extends ServiceImpl<SdsHwDepartmentCostConfigMapper,
        SdsHwDepartmentCostConfig> implements ISdsHwDepartmentCostConfigService {

    @Override
    public PageDataDTO<HwDepartmentCostConfigDTO> selectConfigPage(HwDepartmentCostConfigQueryVO queryVO) {
        if (queryVO.getPageIndex() != null && queryVO.getPageSize() != null
                && queryVO.getPageIndex() != 0 && queryVO.getPageSize() != 0) {
            Page page = PageHelper.startPage(queryVO.getPageIndex(), queryVO.getPageSize());
            List<HwDepartmentCostConfigDTO> departmentCostConfigDTOList = baseMapper
                    .selectDepartmentCostConfigList(queryVO);
            return new PageDataDTO<>(page.getTotal(), departmentCostConfigDTOList);
        } else {
            List<HwDepartmentCostConfigDTO> departmentCostConfigDTOList = baseMapper
                    .selectDepartmentCostConfigList(queryVO);
            return new PageDataDTO<>((long) departmentCostConfigDTOList.size(), departmentCostConfigDTOList);
        }
    }

    @Override
    public List<String> selectCostCodeListByOrgCode(String orgCode) {
        return baseMapper.selectCostCodeListByOrgCode(orgCode);
    }

    @Override
    public List<CostCodeNameDTO> selectCostCodeNameListByOrgCode(String orgCode) {
        return baseMapper.selectCostCodeNameInfo(orgCode);
    }
}
