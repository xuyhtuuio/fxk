package com.maxnerva.cloudmes.models.vo.scrap;

import com.maxnerva.cloudmes.models.vo.PageQueryVO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class SteelInventoryPlanDetailErrLogQueryVO extends PageQueryVO {

    @ApiModelProperty(value = "盘点单号", required = true)
    private String inventoryPlanNo;


}
