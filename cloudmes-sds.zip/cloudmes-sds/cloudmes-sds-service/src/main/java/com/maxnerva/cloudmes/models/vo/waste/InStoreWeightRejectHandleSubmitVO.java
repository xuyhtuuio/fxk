package com.maxnerva.cloudmes.models.vo.waste;

import com.maxnerva.cloudmes.models.vo.CommonRequestVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @ClassName InStoreWeightRejectHandleSubmitVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/19
 * @Version 1.0
 * @Since JDK 1.8
 **/
@EqualsAndHashCode(callSuper = true)
@ApiModel("入库拒收记录处理VO")
@Data
public class InStoreWeightRejectHandleSubmitVO extends CommonRequestVO {

    @ApiModelProperty(value = "主键ID", required = true)
    private Integer id;

    @ApiModelProperty(value = "单号", required = true)
    private String docNo;

    @ApiModelProperty(value = "处理方式", required = true)
    private String handleMethod;
}
