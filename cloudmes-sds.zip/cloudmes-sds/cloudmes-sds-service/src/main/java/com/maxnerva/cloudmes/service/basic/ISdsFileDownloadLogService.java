package com.maxnerva.cloudmes.service.basic;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.models.entity.basic.SdsFileDownloadLog;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;

public interface ISdsFileDownloadLogService extends IService<SdsFileDownloadLog> {

    SdsFileDownloadLog uploadFile(String type, String fileName, String creator, byte[] bytes);


    void downLoadFile(Integer id, HttpServletResponse response);

    MultipartFile handleHttpFileURLToMulitpartFile(String fileUrl, String fileName);
}
