package com.maxnerva.cloudmes.models.vo.scrap;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.models.vo.PageQueryVO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

@Data
public class RubbishWeightRejectQueryVO extends PageQueryVO {

    @ApiModelProperty(value = "托盘编码")
    private String bucketNo;

    @ApiModelProperty(value = "报废类别")
    private String scrapDetailClass;

    @ApiModelProperty(value = "状态 0 未处理， 1 已处理， 2 全部", required = true)
    private String status;

    @ApiModelProperty(value = "厂部")
    private String departmentCode;

    @ApiModelProperty(value = "拒收开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime startDateTime;

    @ApiModelProperty(value = "拒收结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime endDateTime;
}
