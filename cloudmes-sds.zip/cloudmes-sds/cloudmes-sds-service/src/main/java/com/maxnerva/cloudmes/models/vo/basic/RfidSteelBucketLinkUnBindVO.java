package com.maxnerva.cloudmes.models.vo.basic;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
public class RfidSteelBucketLinkUnBindVO {

    @ApiModelProperty(value = "托盘编码", required = true)
    private String bucketNo;

    @ApiModelProperty(value = "RFID编码", required = true)
    private List<String> rfidNoList;
}
