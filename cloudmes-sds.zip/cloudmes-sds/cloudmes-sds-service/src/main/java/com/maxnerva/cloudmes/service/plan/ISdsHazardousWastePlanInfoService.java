package com.maxnerva.cloudmes.service.plan;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.plan.PlanInfoDTO;
import com.maxnerva.cloudmes.models.entity.plan.SdsHazardousWastePlanInfo;
import com.maxnerva.cloudmes.models.vo.plan.PlanFlownetApprovalVO;
import com.maxnerva.cloudmes.models.vo.plan.PlanInfoQueryVO;
import com.maxnerva.cloudmes.models.vo.plan.PlanInfoSaveVO;
import com.maxnerva.cloudmes.models.vo.plan.PlanInfoUpdateVO;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * <p>
 * 年度计划表 服务类
 * </p>
 *
 * @author likun
 * @since 2025-05-08
 */
public interface ISdsHazardousWastePlanInfoService extends IService<SdsHazardousWastePlanInfo> {

    void savePlanInfo(PlanInfoSaveVO planInfoSaveVO);

    void updatePlanInfo(PlanInfoUpdateVO planInfoUpdateVO);

    PageDataDTO<PlanInfoDTO> selectPlanInfoList(PlanInfoQueryVO queryVO);

    void deletePlanInfo(Integer id);

    void exportPlanInfo(HttpServletResponse response, PlanInfoQueryVO queryVO);

    R<Void> approvalCompleted(String jsonString);

    void flownetApproval(List<PlanFlownetApprovalVO> approvalVOList);
}
