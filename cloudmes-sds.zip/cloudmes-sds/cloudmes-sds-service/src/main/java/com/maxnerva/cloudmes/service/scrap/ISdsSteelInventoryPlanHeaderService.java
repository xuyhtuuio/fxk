package com.maxnerva.cloudmes.service.scrap;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelInventoryPlanHeaderDTO;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelInventoryPlanHeader;
import com.maxnerva.cloudmes.models.vo.scrap.SteelInventoryPlanHeaderCompleteVO;
import com.maxnerva.cloudmes.models.vo.scrap.SteelInventoryPlanHeaderCreateVO;
import com.maxnerva.cloudmes.models.vo.scrap.SteelInventoryPlanHeaderQueryVO;

import javax.servlet.http.HttpServletResponse;

public interface ISdsSteelInventoryPlanHeaderService extends IService<SdsSteelInventoryPlanHeader> {

    PageDataDTO<SteelInventoryPlanHeaderDTO> selectPageList(SteelInventoryPlanHeaderQueryVO vo, Boolean isPage);

    void exportDetail(SteelInventoryPlanHeaderQueryVO vo, HttpServletResponse response);

    void create(SteelInventoryPlanHeaderCreateVO vo);

    void complete(SteelInventoryPlanHeaderCompleteVO vo);
}
