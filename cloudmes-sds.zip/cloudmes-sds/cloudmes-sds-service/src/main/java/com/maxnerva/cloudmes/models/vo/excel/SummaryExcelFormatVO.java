package com.maxnerva.cloudmes.models.vo.excel;

import lombok.Data;

@Data
public class SummaryExcelFormatVO {

    public SummaryExcelFormatVO(Integer summaryIndex, Short dataFormat, String format) {
        this.summaryIndex = summaryIndex;
        this.dataFormat = dataFormat;
        this.format = format;
    }

    private Integer summaryIndex;

    private Short dataFormat;

    private String format;
}
