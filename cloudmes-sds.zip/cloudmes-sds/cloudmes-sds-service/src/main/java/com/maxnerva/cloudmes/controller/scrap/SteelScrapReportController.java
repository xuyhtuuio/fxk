package com.maxnerva.cloudmes.controller.scrap;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.scrap.InventoryReportDTO;
import com.maxnerva.cloudmes.models.dto.scrap.RubbishInStockDTO;
import com.maxnerva.cloudmes.models.dto.scrap.RubbishOutStockDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelInventoryBalanceLogDTO;
import com.maxnerva.cloudmes.models.vo.excel.ExcelMergeCellValue;
import com.maxnerva.cloudmes.models.vo.scrap.*;
import com.maxnerva.cloudmes.service.scrap.ISdsSteelInventoryBalanceLogService;
import com.maxnerva.cloudmes.service.scrap.ISdsSteelRemainingInventoryInfoService;
import com.maxnerva.cloudmes.service.scrap.ISteelScrapReportService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Api(tags = "固废报表管理")
@Slf4j
@RestController
@RequestMapping("/steelScrapReport")
public class SteelScrapReportController {

    @Autowired
    ISdsSteelInventoryBalanceLogService steelInventoryBalanceLogService;

    @Autowired
    ISteelScrapReportService steelScrapReportService;

    @Autowired
    ISdsSteelRemainingInventoryInfoService steelRemainingInventoryInfoService;

    @ApiOperation("盘点核账记录分页查询")
    @GetMapping("/getInventoryBalanceLogPageList")
    R<PageDataDTO<SteelInventoryBalanceLogDTO>> getInventoryBalanceLogPageList(SteelInventoryBalanceLogQueryVO vo){
        return R.ok(steelInventoryBalanceLogService.selectPageList(vo, Boolean.TRUE));
    }

    @ApiOperation("盘点核账记录导出")
    @GetMapping("/exportInventoryBalanceLog")
    void exportInventoryBalanceLog(SteelInventoryBalanceLogQueryVO vo, HttpServletResponse response){
        steelInventoryBalanceLogService.exportDetail(vo, response);
    }

    @ApiOperation("固废库存入库记录")
    @GetMapping("/getRubbishInStock")
    R<PageDataDTO<RubbishInStockDTO>> getRubbishInStock(RubbishInStockQueryVO vo){
        return R.ok(steelScrapReportService.getRubbishInStock(vo, Boolean.TRUE));
    }

    @ApiOperation("固废库存入库记录导出")
    @GetMapping("/exportRubbishInStock")
    void exportRubbishInStock(RubbishInStockQueryVO vo, HttpServletResponse response){
        steelScrapReportService.exportRubbishInStock(vo, response);
    }

    @ApiOperation("固废库存出库记录")
    @GetMapping("/getRubbishOutStock")
    R<PageDataDTO<RubbishOutStockDTO>> getRubbishOutStock(RubbishOutStockQueryVO vo){
        return R.ok(steelScrapReportService.getRubbishOutStock(vo, Boolean.TRUE));
    }

    @ApiOperation("固废库存出库记录导出")
    @GetMapping("/exportRubbishOutStock")
    void exportRubbishOutStock(RubbishOutStockQueryVO vo, HttpServletResponse response){
        steelScrapReportService.exportRubbishOutStock(vo, response);
    }

    @ApiOperation("固废库存结余记录")
    @GetMapping("/getRubbishStockSummary")
    R<PageDataDTO> getRubbishStockSummary(RubbishStockSummaryQueryVO vo){
        return R.ok(steelScrapReportService.getRubbishStockSummary(vo, Boolean.TRUE));
    }

    @ApiOperation("固废库存结余记录导出")
    @GetMapping("/exportRubbishStockSummary")
    void exportRubbishStockSummary(RubbishStockSummaryQueryVO vo, HttpServletResponse response){
        steelScrapReportService.exportRubbishStockSummary(vo, response);
    }

    @ApiOperation("经管盘点报表")
    @GetMapping("/selectInventoryReport")
    R<InventoryReportDTO> selectInventoryReport(SteelScrapInventoryReportQueryVO vo) {
        return R.ok(steelScrapReportService.selectInventoryReport(vo));
    }

    @ApiOperation("经管盘点报表导出")
    @GetMapping("/exportInventoryReport")
    void exportInventoryReport(SteelScrapInventoryReportQueryVO vo, HttpServletResponse response) {
        steelScrapReportService.exportInventoryReport(vo, response);
    }

    @ApiOperation("添加固废本月剩余量")
    @PostMapping("/createSteelRemainWeight")
    R createSteelRemainWeight(@RequestBody SteelRemainingInventoryInfoCreateVO vo) {
        steelRemainingInventoryInfoService.create(vo);
        return R.ok();
    }

    @ApiOperation("归档固废盘点报表")
    @PostMapping("/archiveInventoryReport")
    R archiveInventoryReport(@RequestBody SteelScrapInventoryReportQueryVO vo) {
        steelScrapReportService.archiveInventoryReport(vo);
        return R.ok();
    }
}
