package com.maxnerva.cloudmes.models.dto.scrap;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class SteelScrapWeightInfoLogDTO {
    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("工厂组织")
    private String orgCode;

    @ApiModelProperty("托盘编码")
    private String bucketNo;

    @ApiModelProperty("托盘重量")
    private BigDecimal bucketWeight;

    @ApiModelProperty("单位")
    private String uom;

    @ApiModelProperty("毛重")
    private BigDecimal grossWeight;

    @ApiModelProperty("净重")
    private BigDecimal netWeight;

    @ApiModelProperty("称重时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime weighDt;

    @ApiModelProperty("称重员工")
    private String weighEmpNo;

    @ApiModelProperty("N 未称重，Y 已称重")
    private String weighFlag;

    @ApiModelProperty(value = "是否称重名")
    private String weighFlagName;

    @ApiModelProperty("图片列表")
    private List<String> imageUrlList;

    @ApiModelProperty("N 未接收， Y 已接收")
    private String acceptFlag;

    @ApiModelProperty("是否接收名")
    private String acceptFlagName;

    @ApiModelProperty("接收时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime acceptDt;

    @ApiModelProperty("接收人")
    private String acceptEmpNo;

    @ApiModelProperty("报废小类")
    private String scrapDetailClass;

    @ApiModelProperty("报废小类名")
    private String scrapDetailClassName;

    @ApiModelProperty("报废厂毛重")
    private BigDecimal rubbishGrossWeight;

    @ApiModelProperty("报废厂净重")
    private BigDecimal rubbishNetWeight;

    @ApiModelProperty("报废厂称重时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime rubbishWeighDt;

    @ApiModelProperty("报废厂称重人")
    private String rubbishWeighEmpNo;

    @ApiModelProperty("报废厂称重状态N/Y")
    private String rubbishWeighFlag;

    @ApiModelProperty("废料厂是否称重名")
    private String rubbishWeighFlagName;

    @ApiModelProperty("操作类型")
    private String operateType;

    @ApiModelProperty("操作内容")
    private String operateMessage;

    @ApiModelProperty(value = "创建人")
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "创建时间")
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "修改人")
    private String lastEditor;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "修改时间")
    private LocalDateTime lastEditedDt;
}
