package com.maxnerva.cloudmes.service.basic;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.models.entity.basic.SdsHazardousWasteCostAuditRelationConfig;

/**
 * <p>
 * 签核课级配置关系表 服务类
 * </p>
 *
 * @author likun
 * @since 2025-05-14
 */
public interface ISdsHazardousWasteCostAuditRelationConfigService extends IService<SdsHazardousWasteCostAuditRelationConfig> {

}
