package com.maxnerva.cloudmes.enums;


public enum  SteelScrapOperateType {

    /**
     * 调整单单据类型
     */
    ACCEPT("ACCEPT_CONFIRM", "接收确认"),
    UPLOAD_IMAGE("UPLOAD_IMAGE", "固废上传图片"),
    WEIGH("WEIGH", "固废车间称重"),
    RUBBISH_WEIGH("RUBBISH_WEIGH", "废料厂称重接收"),
    RUBBISH_ERR_ACCEPT("EXCEPTION_ACCEPT", "废料厂异常接收"),
    RUBBISH_ERR_REJECT("EXCEPTION_REJECT", "废料厂异常拒收"),
    RUBBISH_ERR_HANDLE("EXCEPTION_HANDLE", "废料厂异常处理"),
    OUTSOURCED_FACTORY_WEIGH("OUTSOURCED_FACTORY_WEIGH", "委外称重");


    private String dictCode;

    private String dictName;

    SteelScrapOperateType(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public void setDictCode(String dictCode) {
        this.dictCode = dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public void setDictName(String dictName) {
        this.dictName = dictName;
    }
}
