package com.maxnerva.cloudmes.mapper.scrap;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.dto.scrap.SteelPaymentHeaderDTO;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelPaymentHeader;
import com.maxnerva.cloudmes.models.vo.scrap.SteelPaymentHeaderQueryVO;

import java.util.List;

public interface SdsSteelPaymentHeaderMapper extends BaseMapper<SdsSteelPaymentHeader> {

    List<SdsSteelPaymentHeader> selectPageList(SteelPaymentHeaderQueryVO vo);
}
