package com.maxnerva.cloudmes.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.entity.basic.SdsSolidWmsConfig;

public interface SdsSolidWmsConfigMapper extends BaseMapper<SdsSolidWmsConfig> {
}
