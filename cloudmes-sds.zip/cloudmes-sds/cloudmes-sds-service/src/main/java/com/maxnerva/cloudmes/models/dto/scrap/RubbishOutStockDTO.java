package com.maxnerva.cloudmes.models.dto.scrap;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class RubbishOutStockDTO {

    @ApiModelProperty(value = "报废类别")
    private String scrapDetailClass;

    @ApiModelProperty(value = "报废类别名")
    private String scrapDetailClassName;

    @ApiModelProperty("申报单号")
    private String declareNumber;

    @ApiModelProperty("空车重量")
    private BigDecimal carWeight;

    @ApiModelProperty("單位")
    private String weightUom;

    @ApiModelProperty("整车重量")
    private BigDecimal fullCarWeight;

    @ApiModelProperty("废料净重")
    private BigDecimal scrapNetWeight;

    @ApiModelProperty("整車称重人")
    private String fullCarWeightEmp;

    @ApiModelProperty("整車称重时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime fullCarWeightDt;

}
