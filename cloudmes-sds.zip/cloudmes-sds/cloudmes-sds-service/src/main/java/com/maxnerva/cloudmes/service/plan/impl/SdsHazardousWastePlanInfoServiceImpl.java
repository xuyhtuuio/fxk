package com.maxnerva.cloudmes.service.plan.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.map.MapUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpStatus;
import com.alibaba.excel.EasyExcel;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.enums.ResultCode;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.common.utils.WebContextUtil;
import com.maxnerva.cloudmes.enums.CodeRuleEnum;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.enums.WastePlanDocStatusEnum;
import com.maxnerva.cloudmes.excel.handler.AddNoHandler;
import com.maxnerva.cloudmes.feign.basic.ICodeRuleClient;
import com.maxnerva.cloudmes.mapper.basic.SdsHazardousWasteFlownetRequestLogMapper;
import com.maxnerva.cloudmes.mapper.plan.SdsHazardousWastePlanInfoMapper;
import com.maxnerva.cloudmes.models.dto.excel.plan.PlanInfoExportDTO;
import com.maxnerva.cloudmes.models.dto.plan.PlanInfoDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsHazardousWasteFlownetRequestLog;
import com.maxnerva.cloudmes.models.entity.plan.SdsHazardousWastePlanInfo;
import com.maxnerva.cloudmes.models.vo.plan.PlanFlownetApprovalVO;
import com.maxnerva.cloudmes.models.vo.plan.PlanInfoQueryVO;
import com.maxnerva.cloudmes.models.vo.plan.PlanInfoSaveVO;
import com.maxnerva.cloudmes.models.vo.plan.PlanInfoUpdateVO;
import com.maxnerva.cloudmes.service.datahub.DataHubService;
import com.maxnerva.cloudmes.service.plan.ISdsHazardousWastePlanInfoService;
import com.maxnerva.cloudmes.system.feign.IOrganizationClient;
import com.maxnerva.cloudmes.system.utils.DictLangUtils;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.MimeTypeUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.time.LocalDateTime;
import java.util.*;

/**
 * <p>
 * 年度计划表 服务实现类
 * </p>
 *
 * @author likun
 * @since 2025-05-08
 */
@Slf4j
@Service
public class SdsHazardousWastePlanInfoServiceImpl extends ServiceImpl<SdsHazardousWastePlanInfoMapper,
        SdsHazardousWastePlanInfo> implements ISdsHazardousWastePlanInfoService {

    @Resource
    private ICodeRuleClient codeRuleClient;

    @Resource
    private DictLangUtils dictLangUtils;

    @Resource
    private IOrganizationClient organizationClient;

    @Resource
    private SdsHazardousWasteFlownetRequestLogMapper sdsHazardousWasteFlownetRequestLogMapper;

    @Resource
    private DataHubService dataHubService;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void savePlanInfo(PlanInfoSaveVO planInfoSaveVO) {
        String orgCode = planInfoSaveVO.getOrgCode();
        String planYear = planInfoSaveVO.getPlanYear();
        String costCode = planInfoSaveVO.getCostCode();
        String hazardousWasteNo = planInfoSaveVO.getHazardousWasteNo();
        Long count = baseMapper.selectCount(Wrappers.<SdsHazardousWastePlanInfo>lambdaQuery()
                .eq(SdsHazardousWastePlanInfo::getOrgCode, orgCode)
                .eq(SdsHazardousWastePlanInfo::getCostCode, costCode)
                .eq(SdsHazardousWastePlanInfo::getPlanYear, planYear)
                .eq(SdsHazardousWastePlanInfo::getHazardousWasteNo, hazardousWasteNo));
        if (count > 0) {
            throw new CloudmesException(SdsResultCode.PLAN_INFO_EXIST_CAN_NOT_REPEAT_APPLY.getCode(),
                    String.format(MessageUtils.get(SdsResultCode.PLAN_INFO_EXIST_CAN_NOT_REPEAT_APPLY.getLocalCode()),
                            hazardousWasteNo, planYear));
        }
        SdsHazardousWastePlanInfo sdsHazardousWastePlanInfo = new SdsHazardousWastePlanInfo();
        BeanUtils.copyProperties(planInfoSaveVO, sdsHazardousWastePlanInfo);
        HashMap<String, String> map = MapUtil.newHashMap();
        String simpleCode = organizationClient.getSimpleCodeByOrgCode(orgCode).getData();
        map.put("BU", simpleCode);
        String serialNo;
        R<List<String>> result = codeRuleClient.getSerialNumberAndParams(CodeRuleEnum.SDS_WASTE_PLAN_DOC_NO
                .getDictCode(), 1, map);
        if (result.getCode() == ResultCode.SUCCESS.getCode()) {
            serialNo = result.getData().get(0);
        } else {
            throw new CloudmesException(SdsResultCode.CONNECT_BASIC_GET_SERIAL_NUMBER.getCode()
                    , MessageUtils.get(SdsResultCode.CONNECT_BASIC_GET_SERIAL_NUMBER.getLocalCode()));
        }
        sdsHazardousWastePlanInfo.setDocNo(serialNo);
        sdsHazardousWastePlanInfo.setPlanWeight(planInfoSaveVO.getOriginalWeight());
        //目前新增完,默认审核状态
        sdsHazardousWastePlanInfo.setDocStatus(WastePlanDocStatusEnum.AUDIT.getDictCode());
        baseMapper.insert(sdsHazardousWastePlanInfo);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void updatePlanInfo(PlanInfoUpdateVO planInfoUpdateVO) {
        Integer id = planInfoUpdateVO.getId();
        BigDecimal originalWeight = planInfoUpdateVO.getOriginalWeight();
        SdsHazardousWastePlanInfo sdsHazardousWastePlanInfo = baseMapper.selectById(id);
        if (WastePlanDocStatusEnum.SIGN.getDictCode().equals(sdsHazardousWastePlanInfo.getDocStatus())||
                WastePlanDocStatusEnum.AUDIT.getDictCode().equals(sdsHazardousWastePlanInfo.getDocStatus())) {
            throw new CloudmesException(SdsResultCode.SIGN_OR_AUDIT_CAN_NOT_EDIT.getCode(),
                    MessageUtils.get(SdsResultCode.SIGN_OR_AUDIT_CAN_NOT_EDIT.getLocalCode()));
        }
        baseMapper.update(null, Wrappers.<SdsHazardousWastePlanInfo>lambdaUpdate()
                .eq(SdsHazardousWastePlanInfo::getId, id)
                .set(SdsHazardousWastePlanInfo::getOriginalWeight, originalWeight)
                .set(SdsHazardousWastePlanInfo::getPlanWeight, originalWeight)
                .set(SdsHazardousWastePlanInfo::getLastEditor, WebContextUtil.getCurrentStaffCode())
                .set(SdsHazardousWastePlanInfo::getLastEditedDt, LocalDateTime.now()));
    }

    @Override
    public PageDataDTO<PlanInfoDTO> selectPlanInfoList(PlanInfoQueryVO queryVO) {
        if (queryVO.getPageIndex() != null && queryVO.getPageSize() != null
                && queryVO.getPageIndex() != 0 && queryVO.getPageSize() != 0) {
            Page page = PageHelper.startPage(queryVO.getPageIndex(), queryVO.getPageSize());
            List<PlanInfoDTO> planInfoDTOList = getPlanInfoDTOList(queryVO);
            return new PageDataDTO<>(page.getTotal(), planInfoDTOList);
        } else {
            List<PlanInfoDTO> planInfoDTOList = getPlanInfoDTOList(queryVO);
            return new PageDataDTO<>((long) planInfoDTOList.size(), planInfoDTOList);
        }
    }

    @NotNull
    private List<PlanInfoDTO> getPlanInfoDTOList(PlanInfoQueryVO queryVO) {
        List<PlanInfoDTO> planInfoDTOList = baseMapper.selectPlanInfoList(queryVO);
        Map<String, String> docStatusMap = dictLangUtils.getByType("SDS_PLAN_INFO_DOC_STATUS");
        planInfoDTOList.forEach(planInfoDTO -> planInfoDTO.setDocStatusName(docStatusMap
                .get(planInfoDTO.getDocStatus())));
        return planInfoDTOList;
    }

    @Override
    public void deletePlanInfo(Integer id) {
        SdsHazardousWastePlanInfo sdsHazardousWastePlanInfo = baseMapper.selectById(id);
        String docStatus = sdsHazardousWastePlanInfo.getDocStatus();
        if (WastePlanDocStatusEnum.SIGN.getDictCode().equals(docStatus) ||
                WastePlanDocStatusEnum.AUDIT.getDictCode().equals(docStatus)) {
            throw new CloudmesException(SdsResultCode.PLAN_INFO_ADD_LOG_SIGNED_OR_AUDIT_CAN_NOT_DELETE.getCode(),
                    MessageUtils.get(SdsResultCode.PLAN_INFO_ADD_LOG_SIGNED_OR_AUDIT_CAN_NOT_DELETE.getLocalCode()));
        }
        baseMapper.deleteById(id);
    }

    @Override
    public void exportPlanInfo(HttpServletResponse response, PlanInfoQueryVO queryVO) {
        List<PlanInfoExportDTO> exportDTOList = CollUtil.newArrayList();
        List<PlanInfoDTO> planInfoDTOList = getPlanInfoDTOList(queryVO);
        planInfoDTOList.forEach(planInfoDTO -> {
            PlanInfoExportDTO planInfoExportDTO = new PlanInfoExportDTO();
            BeanUtils.copyProperties(planInfoDTO, planInfoExportDTO);
            exportDTOList.add(planInfoExportDTO);
        });
        String fileName = "年度计划信息" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), PlanInfoExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.PLAN_INFO_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.PLAN_INFO_EXPORT_FAIL.getLocalCode()));
        }
    }

    @Override
    public R<Void> approvalCompleted(String jsonString) {
        List<PlanFlownetApprovalVO> planFlownetApprovalVOList = CollUtil.newArrayList();
        PlanFlownetApprovalVO planFlownetApprovalVO = new PlanFlownetApprovalVO();
        planFlownetApprovalVO.setJsonString(jsonString);
        planFlownetApprovalVOList.add(planFlownetApprovalVO);
        HttpResponse httpResponse = dataHubService.flownetPlanInfoApprovalCompleted(planFlownetApprovalVOList);
        String body = httpResponse.body();
        if (StrUtil.isEmpty(body)) {
            throw new CloudmesException(SdsResultCode.FLOWNET_AN_EXCEPTION_OCCURS_WHEN_INTERFACE_INVOCATION_IS_APPROVED
                    .getCode(), MessageUtils.get(SdsResultCode
                    .FLOWNET_AN_EXCEPTION_OCCURS_WHEN_INTERFACE_INVOCATION_IS_APPROVED.getLocalCode()));
        }
        log.info("approvalCompleted jsonString:{}, call datahub return:{}", jsonString, body);
        if (httpResponse.getStatus() == HttpStatus.HTTP_OK) {
            JSONObject dataHubReturnInfo = JSON.parseObject(body);
            int code = dataHubReturnInfo.getInteger("code");
            String msg = dataHubReturnInfo.getString("msg");
            if (200 != code) {
                return R.no(code, msg);
            }
            return R.ok();
        }
        throw new CloudmesException(SdsResultCode.FLOWNET_AN_EXCEPTION_OCCURS_WHEN_INTERFACE_INVOCATION_IS_APPROVED
                .getCode(), MessageUtils.get(SdsResultCode
                .FLOWNET_AN_EXCEPTION_OCCURS_WHEN_INTERFACE_INVOCATION_IS_APPROVED.getLocalCode()));
    }

    @Transactional
    @Override
    public void flownetApproval(List<PlanFlownetApprovalVO> approvalVOList) {
        String jsonString = approvalVOList.get(0).getJsonString();
        JSONObject jsonObject = JSONObject.parseObject(jsonString);
        //审批状态
        String approvalStatus = jsonObject.getString("flownetFormStatus");
        //单号
        String docNo = jsonObject.getString("businessRequestNo");
        log.info("plan info flownetApproval datahub parameter=========》：::docNo={}", docNo);
        try {
            SdsHazardousWastePlanInfo sdsHazardousWastePlanInfo = baseMapper
                    .selectOne(Wrappers.<SdsHazardousWastePlanInfo>lambdaQuery()
                            .eq(SdsHazardousWastePlanInfo::getDocNo, docNo)
                            .last("limit 1"));
            Optional.ofNullable(sdsHazardousWastePlanInfo)
                    .orElseThrow(() -> new CloudmesException(SdsResultCode.NOT_FOUND_PLAN_INFO.getCode(),
                            String.format(MessageUtils.get(SdsResultCode.NOT_FOUND_PLAN_INFO.getLocalCode()),
                                    docNo)));
            String status = "Approved".equals(approvalStatus) ? WastePlanDocStatusEnum.AUDIT.getDictCode() :
                    WastePlanDocStatusEnum.REJECT.getDictCode();
            sdsHazardousWastePlanInfo.setDocStatus(status);
            sdsHazardousWastePlanInfo.setFlownetMsg(jsonString);
            sdsHazardousWastePlanInfo.setFlownetApprovalResult(approvalStatus);
            baseMapper.updateById(sdsHazardousWastePlanInfo);
        } catch (Exception e) {
            log.info("plan info flownetApproval datahub paramete docNo:{}, exception:{}", docNo,
                    e.getMessage());
            throw new CloudmesException(e.getMessage());
        } finally {
            //产生调用记录
            SdsHazardousWasteFlownetRequestLog requestLog = new SdsHazardousWasteFlownetRequestLog();
            requestLog.setRequestJson(jsonString);
            sdsHazardousWasteFlownetRequestLogMapper.insert(requestLog);
        }
    }
}
