package com.maxnerva.cloudmes.models.entity.waste;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

/**
 * <p>
 * 危废转移单明细
 * </p>
 *
 * @author likun
 * @since 2025-05-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="SdsHazardousWasteTransferDetail对象", description="危废转移单明细")
public class SdsHazardousWasteTransferDetail extends BaseEntity<SdsHazardousWasteTransferDetail> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "转移单号")
    private String transferDocNo;

    @ApiModelProperty(value = "出库单号")
    private String shipDocNo;

    @ApiModelProperty(value = "SDS危废料号")
    private String hazardousWasteNo;

    @ApiModelProperty(value = "废物俗称")
    private String hazardousWasteName;

    @ApiModelProperty(value = "危险废物")
    private String hazardousWaste;

    @ApiModelProperty(value = "废物形态")
    private String shape;

    @ApiModelProperty(value = "主要成分")
    private String rohs;

    @ApiModelProperty(value = "危险特性")
    private String toxicity;

    @ApiModelProperty(value = "废物类别")
    private String hazardousWasteCategory;

    @ApiModelProperty(value = "废物代码")
    private String hazardousWasteCode;

    @ApiModelProperty(value = "包装类型")
    private String packType;

    @ApiModelProperty(value = "包装数量")
    private BigDecimal applyQty;

    @ApiModelProperty(value = "预估转移量")
    private BigDecimal preTransferQty;

    @ApiModelProperty(value = "实际转移量")
    private BigDecimal actTransferQty;

    @ApiModelProperty(value = "栈板数量")
    private BigDecimal palletQty;

    @ApiModelProperty(value = "图片地址")
    private String imageUrlList;
}
