package com.maxnerva.cloudmes.service.scrap;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.models.dto.scrap.SteelInventoryPlanDetailDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelInventoryPlanDetailSubmitDTO;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelInventoryPlanDetail;
import com.maxnerva.cloudmes.models.vo.scrap.SteelInventoryPlanDetailSubmitVO;

public interface ISdsSteelInventoryPlanDetailService extends IService<SdsSteelInventoryPlanDetail> {

    SteelInventoryPlanDetailDTO selectOne(String inventoryPlanNo);

    SteelInventoryPlanDetailSubmitDTO weightSubmit(SteelInventoryPlanDetailSubmitVO vo);
}
