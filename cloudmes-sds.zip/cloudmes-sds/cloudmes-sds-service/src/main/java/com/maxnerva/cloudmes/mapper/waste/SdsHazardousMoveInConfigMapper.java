package com.maxnerva.cloudmes.mapper.waste;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.dto.waste.WasteMoveInConfigDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousMoveInConfig;

import java.util.List;

/**
 * <p>
 * 危废接受单位配置档 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2025-05-27
 */
public interface SdsHazardousMoveInConfigMapper extends BaseMapper<SdsHazardousMoveInConfig> {

    List<WasteMoveInConfigDTO> selectMoveInConfigList();
}
