package com.maxnerva.cloudmes.models.entity.scrap;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 固废出库单
 * </p>
 *
 * @author baomidou
 * @since 2024-12-17
 */
@TableName("sds_steel_scrap_ship_header")
@ApiModel(value = "SdsSteelScrapShipHeader对象", description = "固废出库单")
@Data
public class SdsSteelScrapShipHeader extends BaseEntity<SdsSteelScrapShipHeader> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("申报单号")
    private String declareNumber;

    @ApiModelProperty("厂商")
    private String manFacturer;

    @ApiModelProperty("废料名称")
    private String scrapPartName;

    @ApiModelProperty("关务代码")
    private String customsCode;

    @ApiModelProperty("废料料号")
    private String scrapPartNo;

    @ApiModelProperty("废料类别")
    private String scrapType;

    @ApiModelProperty("区域代码")
    private String areaCode;

    @ApiModelProperty("车牌")
    private String licenseCarNumber;

    @ApiModelProperty("司机")
    private String driver;

    @ApiModelProperty("申请人")
    private String applyor;

    @ApiModelProperty("申请时间")
    private LocalDateTime applyDt;

    @ApiModelProperty("出货法人")
    private String shippingCorporation;

    @ApiModelProperty("归属单位")
    private String costCode;

    @ApiModelProperty("计量单位")
    private String uom;

    @ApiModelProperty("备案号")
    private String filedNumber;

    @ApiModelProperty("关锁号")
    private String lockNumber;

    @ApiModelProperty("车况-工具箱")
    private String carToolBox;

    @ApiModelProperty("车况-油箱")
    private String carFuelTank;

    @ApiModelProperty("车况-钢圈")
    private String carSteelRing;

    @ApiModelProperty("车况-水箱")
    private String carWaterTank;

    @ApiModelProperty("车况-备胎")
    private String carSpareTire;

    @ApiModelProperty("空车重量")
    private BigDecimal carWeight;

    @ApiModelProperty("进厂时间")
    private LocalDateTime entryTime;

    @ApiModelProperty("空车称重人")
    private String carWeightEmp;

    @ApiModelProperty("空车称重时间")
    private LocalDateTime carWeightDt;

    @ApiModelProperty("單位")
    private String weightUom;

    @ApiModelProperty("整车重量")
    private BigDecimal fullCarWeight;

    @ApiModelProperty("出厂时间")
    private LocalDateTime leaveTime;

    @ApiModelProperty("整車称重人")
    private String fullCarWeightEmp;

    @ApiModelProperty("整車称重时间")
    private LocalDateTime fullCarWeightDt;

    @ApiModelProperty("废料净重")
    private BigDecimal scrapNetWeight;

    @ApiModelProperty("进出废料区状态（0未进，1已进，2已出）")
    private String scrapAreaStatus;

    @ApiModelProperty("进废料区时间")
    private LocalDateTime inScrapAreaDt;

    @ApiModelProperty("进废料区放行人")
    private String inScrapAreaEmpNo;

    @ApiModelProperty(value = "出废料区时间")
    private LocalDateTime outScrapAreaDt;

    @ApiModelProperty("出废料区放行人")
    private String outScrapAreaEmpNo;

    @ApiModelProperty(value = "报废小类")
    private String scrapDetailClass;

    @ApiModelProperty(value = "厂商代码")
    private String mfgCode;

    @ApiModelProperty(value = "单价")
    private BigDecimal price;

    @ApiModelProperty(value = "盘点单号")
    private String inventoryPlanNo;

    @ApiModelProperty(value = "SDS废料类别")
    private String sdsScrapType;

    @ApiModelProperty("缴款单号")
    private String paymentDocNo;

}
