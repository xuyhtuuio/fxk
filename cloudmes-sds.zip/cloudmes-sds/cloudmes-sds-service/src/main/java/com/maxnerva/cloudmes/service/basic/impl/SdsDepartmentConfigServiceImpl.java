package com.maxnerva.cloudmes.service.basic.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.mapper.basic.SdsDepartmentConfigMapper;
import com.maxnerva.cloudmes.models.dto.basic.DepartmentConfigDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsDepartmentConfig;
import com.maxnerva.cloudmes.service.basic.ISdsDepartmentConfigService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 厂部配置 服务实现类
 * </p>
 *
 * @author likun
 * @since 2024-12-11
 */
@Slf4j
@Service
public class SdsDepartmentConfigServiceImpl extends ServiceImpl<SdsDepartmentConfigMapper, SdsDepartmentConfig>
        implements ISdsDepartmentConfigService {

    @Override
    public List<DepartmentConfigDTO> selectConfigList(String orgCode) {
        return baseMapper.selectConfigList(orgCode);
    }

    @Override
    public List<DepartmentConfigDTO> selectConfigListNoBu() {
        return baseMapper.selectConfigListNoBu();
    }
}
