package com.maxnerva.cloudmes.controller.waste;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.waste.TransferBindShipDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteDocShipInfoDTO;
import com.maxnerva.cloudmes.models.vo.waste.TransferBindShipInfoQueryVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteDocShipInfoQueryVO;
import com.maxnerva.cloudmes.service.waste.ISdsHazardousWasteShipInfoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @ClassName HazardousWasteDocShipInfoController
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/21
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "出库单管理")
@Slf4j
@RestController
@RequestMapping("/hazardousWasteDocShipInfo")
public class HazardousWasteDocShipInfoController {

    @Resource
    private ISdsHazardousWasteShipInfoService sdsHazardousWasteShipInfoService;

    @ApiOperation("查询出库单信息")
    @PostMapping("/list")
    public R<PageDataDTO<WasteDocShipInfoDTO>> selectShipInfoPage(@RequestBody WasteDocShipInfoQueryVO queryVO) {
        return R.ok(sdsHazardousWasteShipInfoService.selectShipInfoPage(queryVO));
    }

    @ApiOperation("查询可绑定转移单的出库单信息")
    @PostMapping("/transferBindShipList")
    public R<List<List<TransferBindShipDTO>>> selectTransferBindShipList(
            @RequestBody TransferBindShipInfoQueryVO queryVO){
        return R.ok(sdsHazardousWasteShipInfoService.selectTransferBindShipList(queryVO));
    }

    @ApiOperation("导出")
    @PostMapping("/export")
    public R<Void> exportHazardousDocShip(HttpServletResponse response,
                                              @RequestBody WasteDocShipInfoQueryVO queryVO) {
        sdsHazardousWasteShipInfoService.exportDocShip(response, queryVO);
        return R.ok();
    }
}
