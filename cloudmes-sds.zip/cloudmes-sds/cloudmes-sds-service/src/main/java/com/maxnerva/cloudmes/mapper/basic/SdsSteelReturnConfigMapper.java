package com.maxnerva.cloudmes.mapper.basic;

import com.maxnerva.cloudmes.models.dto.basic.SteelReturnConfigDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsSteelReturnConfig;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @ClassName SdsSteelReturnConfigMapper
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2024/12/25 上午 09:08
 * @Version 1.0
 **/
public interface SdsSteelReturnConfigMapper extends BaseMapper<SdsSteelReturnConfig> {

    void insertReturnRecord(SteelReturnConfigDTO steelReturnConfigDTO);

}
