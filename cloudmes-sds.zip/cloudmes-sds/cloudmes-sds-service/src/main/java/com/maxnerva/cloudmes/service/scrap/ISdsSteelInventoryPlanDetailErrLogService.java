package com.maxnerva.cloudmes.service.scrap;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelInventoryPlanDetailErrLogDTO;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelInventoryPlanDetailErrLog;
import com.maxnerva.cloudmes.models.vo.scrap.SteelInventoryPlanDetailErrLogQueryVO;

import javax.servlet.http.HttpServletResponse;

public interface ISdsSteelInventoryPlanDetailErrLogService extends IService<SdsSteelInventoryPlanDetailErrLog> {

    PageDataDTO<SteelInventoryPlanDetailErrLogDTO> selectPageList(SteelInventoryPlanDetailErrLogQueryVO vo, Boolean isPage);

    void exportDetail(SteelInventoryPlanDetailErrLogQueryVO vo, HttpServletResponse response);
}
