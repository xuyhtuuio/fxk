package com.maxnerva.cloudmes.controller.waste;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.waste.WasteFileDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteTransferDetailDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteTransferHeaderDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteTransferSaveDTO;
import com.maxnerva.cloudmes.models.vo.UpdateCommonVO;
import com.maxnerva.cloudmes.models.vo.waste.*;
import com.maxnerva.cloudmes.service.waste.ISdsHazardousWasteTransferDetailService;
import com.maxnerva.cloudmes.service.waste.ISdsHazardousWasteTransferHeaderService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @ClassName HazardousWasteTransferController
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/27
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "危废转移单管理")
@Slf4j
@RestController
@RequestMapping("/wasteTransferOrder")
public class HazardousWasteTransferController {

    @Resource
    private ISdsHazardousWasteTransferHeaderService transferHeaderService;

    @Resource
    private ISdsHazardousWasteTransferDetailService transferDetailService;

    @ApiOperation("获取危废转移单单头列表")
    @PostMapping("/headerList")
    public R<PageDataDTO<WasteTransferHeaderDTO>> getWasteTransferHeaderList(@RequestBody WasteTransferHeaderQueryVO queryVO) {
        return R.ok(transferHeaderService.getWasteTransferHeaderList(queryVO));
    }

    @ApiOperation("获取危废转移单单头详情")
    @GetMapping("/headerInfo")
    public R<WasteTransferHeaderDTO> selectHeaderById(@RequestParam Integer id) {
        return R.ok(transferHeaderService.selectHeaderById(id));
    }

    @ApiOperation("获取危废转移单单头文件列表")
    @GetMapping("/fileUrlList")
    public R<List<WasteFileDTO>> selectFileUrlList(@RequestParam Integer id) {
        return R.ok(transferHeaderService.selectFileUrlList(id));
    }

    @ApiOperation("单头上传文件")
    @PostMapping("/uploadFile")
    public R<Void> uploadFile(TransferHeaderUploadFileVO uploadFileVO) {
        transferHeaderService.uploadFile(uploadFileVO);
        return R.ok();
    }

    @ApiOperation("离厂确认")
    @PutMapping("/leaveConfirm")
    public R<Void> leaveConfirm(@RequestBody UpdateCommonVO commonVO) {
        transferHeaderService.leaveConfirm(commonVO.getId());
        return R.ok();
    }

    @ApiOperation("新增转移单")
    @PostMapping("/saveTransferInfo")
    public R<WasteTransferSaveDTO> saveTransferInfo(@RequestBody WasteTransferSaveVO saveVO) {
        return R.ok(transferHeaderService.saveTransferInfo(saveVO));
    }

    @ApiOperation("编辑转移单")
    @PutMapping("/updateTransferInfo")
    public R<Void> updateTransferInfo(@RequestBody WasteTransferHeaderUpdateVO updateVO) {
        transferHeaderService.updateTransferInfo(updateVO);
        return R.ok();
    }

    @ApiOperation("获取危废转移单明细列表")
    @PostMapping("/detailList")
    public R<List<WasteTransferDetailDTO>> selectDetailList(@RequestBody WasteTransferDetailQueryVO queryVO) {
        return R.ok(transferDetailService.selectDetailList(queryVO));
    }

    @ApiOperation("获取危废转移单明细图片列表")
    @GetMapping("/imageUrlList")
    public R<List<String>> selectImageUrlList(@RequestParam Integer id) {
        return R.ok(transferDetailService.selectImageUrlList(id));
    }

    @ApiOperation("明细上传图片")
    @PostMapping("/uploadImage")
    public R<Void> uploadImage(TransferDetailUploadImageVO uploadImageVO) {
        transferDetailService.uploadImage(uploadImageVO);
        return R.ok();
    }

    @ApiOperation("编辑转移单明细")
    @PutMapping("/updateDetail")
    public R<Void> updateDetail(@RequestBody WasteTransferDetailUpdateVO updateVO) {
        transferDetailService.updateDetail(updateVO);
        return R.ok();
    }

    @ApiOperation("删除转移单明细")
    @DeleteMapping("/deleteDetail/{id}")
    public R<Void> deleteDetail(@PathVariable("id") Integer id) {
        transferDetailService.deleteDetail(id);
        return R.ok();
    }

    @ApiOperation("导出")
    @PostMapping("/export")
    public R<Void> exportHazardousTransferDoc(HttpServletResponse response,
                                              @RequestBody WasteTransferHeaderQueryVO queryVO) {
        transferHeaderService.exportTransferInfo(response, queryVO);
        return R.ok();
    }
}
