package com.maxnerva.cloudmes.models.vo.waste;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName WasteTransferDetailQueryVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/27
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("危废转移单明细查询vo")
@Data
public class WasteTransferDetailQueryVO {

    @ApiModelProperty(value = "转移单号")
    private String transferDocNo;

    @ApiModelProperty(value = "废物俗称")
    private String hazardousWasteName;
}
