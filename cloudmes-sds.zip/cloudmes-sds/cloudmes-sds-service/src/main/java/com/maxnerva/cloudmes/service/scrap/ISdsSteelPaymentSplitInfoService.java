package com.maxnerva.cloudmes.service.scrap;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelPaymentSplitInfoDTO;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelPaymentSplitInfo;
import com.maxnerva.cloudmes.models.vo.scrap.SteelPaymentSplitInfoQueryVO;

import javax.servlet.http.HttpServletResponse;

public interface ISdsSteelPaymentSplitInfoService extends IService<SdsSteelPaymentSplitInfo> {

    PageDataDTO<SteelPaymentSplitInfoDTO> selectPageList(SteelPaymentSplitInfoQueryVO vo, Boolean isPage);

    void exportDetail(SteelPaymentSplitInfoQueryVO vo, HttpServletResponse response);
}
