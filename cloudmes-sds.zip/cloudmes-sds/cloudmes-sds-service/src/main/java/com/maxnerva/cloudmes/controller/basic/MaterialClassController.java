package com.maxnerva.cloudmes.controller.basic;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.basic.MaterialClassDTO;
import com.maxnerva.cloudmes.models.vo.basic.MaterialClassQueryVO;
import com.maxnerva.cloudmes.models.vo.basic.MaterialClassSaveOrUpdateVO;
import com.maxnerva.cloudmes.models.vo.excel.ExcelImportVO;
import com.maxnerva.cloudmes.service.basic.ISdsMaterialClassService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

/**
 * @ClassName MaterialClassController
 * @Description TODO
 * @Author Likun
 * @Date 2024/10/28
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "物料类别管理")
@Slf4j
@RestController
@RequestMapping("/materialClass")
public class MaterialClassController {

    @Resource
    private ISdsMaterialClassService materialClassService;

    @ApiOperation("查询物料分类信息")
    @PostMapping("/list")
    public R<PageDataDTO<MaterialClassDTO>> selectMaterialClassPage(@RequestBody MaterialClassQueryVO queryVO) {
        return R.ok(materialClassService.selectMaterialClassPage(queryVO));
    }

    @ApiOperation("新增物料分类信息")
    @PostMapping("/save")
    public R<Void> saveMaterialClass(@RequestBody MaterialClassSaveOrUpdateVO saveOrUpdateVO) {
        materialClassService.saveMaterialClass(saveOrUpdateVO);
        return R.ok();
    }

    @ApiOperation("修改物料分类信息")
    @PostMapping("/update")
    public R<Void> updateMaterialClass(@RequestBody MaterialClassSaveOrUpdateVO saveOrUpdateVO) {
        materialClassService.updateMaterialClass(saveOrUpdateVO);
        return R.ok();
    }

    @ApiOperation("删除")
    @DeleteMapping("/del/{id}")
    public R<Void> delMaterialClass(@PathVariable("id") Integer id) {
        materialClassService.deleteMaterialClass(id);
        return R.ok();
    }

    @ApiOperation("导出")
    @PostMapping("/export")
    public R<Void> exportMaterialClass(HttpServletResponse response,
                                       @RequestBody MaterialClassQueryVO queryVO) {
        materialClassService.exportMaterialClass(response, queryVO);
        return R.ok();
    }

    @ApiOperation("导入")
    @PostMapping("/import")
    public R<Void> importMaterialClass(ExcelImportVO excelImportVO) {
        materialClassService.importMaterialClass(excelImportVO);
        return R.ok();
    }
}
