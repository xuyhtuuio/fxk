package com.maxnerva.cloudmes.service.waste;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.models.dto.waste.NoStorageApplyShipScanDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteProduceAndClearDocDTO;
import com.maxnerva.cloudmes.models.vo.waste.NoStorageApplyShipScanVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteInStoreDocQueryVO;

import javax.servlet.http.HttpServletResponse;

/**
 * @ClassName WasteProductAndClearService
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/19
 * @Version 1.0
 * @Since JDK 1.8
 **/
public interface WasteProductAndClearService {

    PageDataDTO<WasteProduceAndClearDocDTO> selectProduceAndClearList(WasteInStoreDocQueryVO queryVO);

    NoStorageApplyShipScanDTO scanDocNo(NoStorageApplyShipScanVO scanVO);

    void exportProductAndClearInfo(HttpServletResponse response, WasteInStoreDocQueryVO queryVO);
}
