package com.maxnerva.cloudmes.models.dto.scrap;

import lombok.Data;

@Data
public class SyncWmsScrapHandlePalletDTO {

    private String message;

}
