package com.maxnerva.cloudmes.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.entity.basic.SdsFileDownloadLog;

public interface SdsFileDownloadLogMapper extends BaseMapper<SdsFileDownloadLog> {
}
