package com.maxnerva.cloudmes.models.entity.basic;

import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName SdsSteelReturnConfig
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2024/12/25 上午 09:06
 * @Version 1.0
 **/

@TableName("sds_steel_return_config")
@ApiModel(value = "SdsSteelReturnConfig對象", description = "钢桶返回配置描述")
@Data
public class SdsSteelReturnConfig {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("BU")
    private Integer id;

    @ApiModelProperty("是否返回 Y 已返回 N 未返回")
    private String isReturn;

    @ApiModelProperty("钢桶编码")
    private String bucketNo;
}
