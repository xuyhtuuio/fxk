package com.maxnerva.cloudmes.service.basic;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.models.entity.basic.SdsHazardousWasteFlownetRequestLog;

/**
 * <p>
 * 危废flownet审核完成调用日志 服务类
 * </p>
 *
 * @author likun
 * @since 2025-06-09
 */
public interface ISdsHazardousWasteFlownetRequestLogService extends IService<SdsHazardousWasteFlownetRequestLog> {

}
