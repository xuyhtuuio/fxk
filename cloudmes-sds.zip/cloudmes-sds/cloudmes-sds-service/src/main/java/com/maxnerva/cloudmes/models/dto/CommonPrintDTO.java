package com.maxnerva.cloudmes.models.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @ClassName CommonPrintDTO
 * @Description 打印公共返回DTO
 * @Author Likun
 * @Date 2024/11/05
 * @Version 1.0
 * @Since JDK 1.8
 **/
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@ApiModel("打印公共返回DTO")
@Data
public class CommonPrintDTO {

    @ApiModelProperty("模板content")
    private String content;

    @ApiModelProperty("模板类型")
    private String type;
}
