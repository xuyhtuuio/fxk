package com.maxnerva.cloudmes.service.basic.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.io.StreamProgress;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import com.alibaba.fastjson2.JSON;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.common.config.MinIOProperties;
import com.maxnerva.cloudmes.common.constant.BucketConstant;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.enums.SteelScrapOperateType;
import com.maxnerva.cloudmes.mapper.basic.SdsFileDownloadLogMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelPaymentHeaderMapper;
import com.maxnerva.cloudmes.models.dto.scrap.SteelScrapWeightInfoDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsFileDownloadLog;

import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelPaymentHeader;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapWeightInfo;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapWeightInfoLog;
import com.maxnerva.cloudmes.models.vo.scrap.PaymentFileUploadVO;
import com.maxnerva.cloudmes.models.vo.scrap.SteelScrapWeightInfoQueryOneVO;

import com.maxnerva.cloudmes.service.basic.ISdsFileDownloadLogService;
import com.maxnerva.cloudmes.system.feign.IUploadFileClient;
import com.maxnerva.cloudmes.system.models.dto.UploadFileRespDTO;
import com.maxnerva.cloudmes.system.models.vo.FileUploadVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class SdsFileDownloadLogService extends ServiceImpl<SdsFileDownloadLogMapper, SdsFileDownloadLog> implements ISdsFileDownloadLogService {
    @Autowired
    IUploadFileClient uploadFileClient;

    @Autowired
    private MinIOProperties minIOProperties;

    @Override
    public SdsFileDownloadLog uploadFile(String type, String fileName, String creator, byte[] bytes) {
        MultipartFile file = new MultipartFile() {
            @Override
            public String getName() {
                return fileName;
            }
            @Override
            public String getOriginalFilename() {
                return fileName;
            }
            @Override
            public String getContentType() {
                return MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE;
            }
            @Override
            public boolean isEmpty() {
                return false;
            }
            @Override
            public long getSize() {
                return bytes.length;
            }
            @Override
            public byte[] getBytes() throws IOException {
                return bytes;
            }
            @Override
            public InputStream getInputStream() throws IOException {
                return new ByteArrayInputStream(bytes);
            }
            @Override
            public void transferTo(File dest) throws IOException, IllegalStateException {
            }
        };
        FileUploadVO fileUploadVO = new FileUploadVO();
        fileUploadVO.setBucketName(BucketConstant.CLOUD_SAAS);
        fileUploadVO.setFiles(ListUtil.toList(file));
        R<List<UploadFileRespDTO>> res =  uploadFileClient.uploadBatch(fileUploadVO);
        if (res.getCode() == 200){
            UploadFileRespDTO dto = res.getData().get(0);
            SdsFileDownloadLog sdsFileDownloadLog = new SdsFileDownloadLog();
            sdsFileDownloadLog.setCreatedDt(LocalDateTime.now());
            sdsFileDownloadLog.setCreator(creator);
            sdsFileDownloadLog.setLastEditedDt(LocalDateTime.now());
            sdsFileDownloadLog.setLastEditor(creator);
            sdsFileDownloadLog.setFileId(dto.getId());
            sdsFileDownloadLog.setFileName(fileName);
            sdsFileDownloadLog.setLink(dto.getName());
            sdsFileDownloadLog.setType(type);
            baseMapper.insert(sdsFileDownloadLog);
            return sdsFileDownloadLog;
        }

        return null;
    }

    @Override
    public MultipartFile handleHttpFileURLToMulitpartFile(String fileUrl, String fileName) {
        InputStream inputStream = null;
        MultipartFile multipartFile = null;

        try {
            // 初始化SSL
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, new TrustManager[]{
                    new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }

                        @Override
                        public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }

                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return new X509Certificate[0];
                        }
                    }
            }, new SecureRandom());

            // 创建URL对象
            URL url = new URL(fileUrl);

            // 打开连接
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setDoOutput(true);// 允许输出

            // 设置证书忽略相关操作
//            connection.setSSLSocketFactory(sc.getSocketFactory());
//            connection.setHostnameVerifier(new HostnameVerifier() {
//                @Override
//                public boolean verify(String s, SSLSession sslSession) {
//                    return true;
//                }
//            });

            // 创建连接
            connection.connect();

            // 检查响应码
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                // 获取输入流（图片数据）
                inputStream = connection.getInputStream();

                // 使用 ByteArrayOutputStream 来保存 InputStream 的数据
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                byte[] buffer = new byte[1024];
                int bytesRead;

                // 将 InputStream 的数据读取到 ByteArrayOutputStream 中
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    byteArrayOutputStream.write(buffer, 0, bytesRead);
                }

                // 获取字节数组
                final byte[] bytes = byteArrayOutputStream.toByteArray();
                // 创建文件对象
                multipartFile = new MultipartFile() {
                    @Override
                    public String getName() {
                        return fileName;
                    }

                    @Override
                    public String getOriginalFilename() {
                        return fileName;
                    }

                    @Override
                    public String getContentType() {
                        return MimeTypeUtils.IMAGE_JPEG_VALUE;
                    }

                    @Override
                    public boolean isEmpty() {
                        return false;
                    }

                    @Override
                    public long getSize() {
                        return bytes.length;
                    }

                    @Override
                    public byte[] getBytes() throws IOException {
                        return bytes;
                    }

                    @Override
                    public InputStream getInputStream() throws IOException {
                        return new ByteArrayInputStream(bytes);
                    }

                    @Override
                    public void transferTo(File dest) throws IOException, IllegalStateException {
                    }
                };

                // 关闭资源
                byteArrayOutputStream.close();
                if (inputStream != null) {
                    inputStream.close();
                }
                // 断开连接
                connection.disconnect();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return multipartFile;
    }



    @Override
    public void downLoadFile(Integer id, HttpServletResponse response) {
        SdsFileDownloadLog sdsFileDownloadLog = baseMapper.selectById(id);
        String fileUrl = minIOProperties.getFileAddr(BucketConstant.CLOUD_SAAS, sdsFileDownloadLog.getLink());
        HttpResponse response1 = HttpRequest.get(fileUrl)
                .execute();
        response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
        try {
            response.setHeader("Content-Disposition",
                    "attachment; filename=" + URLEncoder.encode(sdsFileDownloadLog.getFileName(), "UTF-8"));
            StreamProgress streamProgress = new StreamProgress() {
                @Override
                public void start() {}
                @Override
                public void progress(long l, long l1) {}
                @Override
                public void finish() {}
            };
            response1.writeBody(response.getOutputStream(), true, streamProgress);
        } catch (Exception e){}
    }

}
