package com.maxnerva.cloudmes.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.entity.basic.SdsHazardousWasteStorageFacilities;

import java.util.List;

/**
 * <p>
 * 危废贮存设施表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2025-05-14
 */
public interface SdsHazardousWasteStorageFacilitiesMapper extends BaseMapper<SdsHazardousWasteStorageFacilities> {

    List<String> selectFacilitiesNameList();
}
