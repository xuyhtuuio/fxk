package com.maxnerva.cloudmes.models.dto.excel.waste;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.excel.converter.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @ClassName WasteDocInfoExportDTO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/15
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("产废单导出DTO")
@Data
public class WasteDocInfoExportDTO {

    @ApiModelProperty(value = "组织")
    @ExcelProperty(value = "组织")
    private String orgCode;

    @ApiModelProperty(value = "单号")
    @ExcelProperty(value = "单号")
    private String docNo;

    @ApiModelProperty("单据类型")
    @ExcelProperty(value = "单据类型")
    private String docTypeName;

    @ApiModelProperty("包装类型")
    @ExcelProperty(value = "包装类型")
    private String packTypeName;

    @ApiModelProperty(value = "单据状态")
    @ExcelProperty(value = "单据状态")
    private String docStatusName;

    @ApiModelProperty(value = "申请人费用代码")
    @ExcelProperty(value = "申请人费用代码")
    private String costCode;

    @ApiModelProperty(value = "申请人部门")
    @ExcelProperty(value = "申请人部门")
    private String depName;

    @ApiModelProperty(value = "SDS料号")
    @ExcelProperty(value = "SDS料号")
    private String hazardousWasteNo;

    @ApiModelProperty(value = "废物俗称")
    @ExcelProperty(value = "废物俗称")
    private String hazardousWasteName;

    @ApiModelProperty(value = "危险废物")
    @ExcelProperty(value = "危险废物")
    private String hazardousWaste;

    @ApiModelProperty(value = "废物形态")
    @ExcelProperty(value = "废物形态")
    private String shape;

    @ApiModelProperty(value = "主要成分")
    @ExcelProperty(value = "主要成分")
    private String rohs;

    @ApiModelProperty(value = "危险特性")
    @ExcelProperty(value = "危险特性")
    private String toxicity;

    @ApiModelProperty(value = "废物类别")
    @ExcelProperty(value = "废物类别")
    private String hazardousWasteCategory;

    @ApiModelProperty(value = "废物代码")
    @ExcelProperty(value = "废物代码")
    private String hazardousWasteCode;

    @ApiModelProperty(value = "废物包装规格")
    @ExcelProperty(value = "废物包装规格")
    private String packagingType;

    @ApiModelProperty(value = "产生时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "产生时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime productionDate;

    @ApiModelProperty(value = "包装类型")
    @ExcelProperty(value = "包装类型")
    private String packType;

    @ApiModelProperty(value = "包装数量")
    @ExcelProperty(value = "包装数量")
    private BigDecimal applyQty;

    @ApiModelProperty(value = "产废毛重")
    @ExcelProperty(value = "产废毛重")
    private BigDecimal applyGrossWeight;

    @ApiModelProperty(value = "产废净重")
    @ExcelProperty(value = "产废净重")
    private BigDecimal applyNetWeight;

    @ApiModelProperty(value = "有无栈板")
    @ExcelProperty(value = "有无栈板")
    private String isPallet;

    @ApiModelProperty(value = "栈板重量")
    @ExcelProperty(value = "栈板重量")
    private BigDecimal palletWeight;

    @ApiModelProperty(value = "产废称重人")
    @ExcelProperty(value = "产废称重人")
    private String weightEmp;

    @ApiModelProperty(value = "产废称重时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "产废称重时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime weightDt;

    @ApiModelProperty(value = "签核人")
    @ExcelProperty(value = "签核人")
    private String approvedEmp;

    @ApiModelProperty(value = "签核时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "签核时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime approvedDt;

    @ApiModelProperty(value = "申请入库人")
    @ExcelProperty(value = "申请入库人")
    private String applyInEmp;

    @ApiModelProperty(value = "申请入库时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "申请入库时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime applyInDt;

    @ApiModelProperty(value = "入库毛重")
    @ExcelProperty(value = "入库毛重")
    private BigDecimal instoreGrossWeight;

    @ApiModelProperty(value = "入库净重")
    @ExcelProperty(value = "入库净重")
    private BigDecimal instoreNetWeight;

    @ApiModelProperty(value = "入库人")
    @ExcelProperty(value = "入库人")
    private String instoreEmp;

    @ApiModelProperty(value = "入库时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "入库时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime instoreDt;

    @ApiModelProperty(value = "创建人")
    @ExcelProperty(value = "创建人")
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "创建时间", converter = LocalDateTimeStringConverter.class)
    @ApiModelProperty(value = "创建时间")
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "修改人")
    @ExcelProperty(value = "修改人")
    private String lastEditor;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "修改时间", converter = LocalDateTimeStringConverter.class)
    @ApiModelProperty(value = "修改时间")
    private LocalDateTime lastEditedDt;

}
