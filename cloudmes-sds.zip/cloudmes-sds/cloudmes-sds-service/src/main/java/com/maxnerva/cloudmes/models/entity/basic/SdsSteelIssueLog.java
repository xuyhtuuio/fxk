package com.maxnerva.cloudmes.models.entity.basic;

import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @ClassName SdsSteelIssueLog
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2024/12/25 下午 01:16
 * @Version 1.0
 **/
@TableName("sds_steel_issue_log")
@ApiModel(value = "SdsSteelIssueLog對象", description = "问题钢桶记录")
@Data
public class SdsSteelIssueLog {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("BU")
    private Integer id;

    @ApiModelProperty("问题钢桶编号")
    private String bucketNo;

    @ApiModelProperty("问题类型")
    private String issueType;

    @ApiModelProperty("问题描述")
    private String issueMessage;
}
