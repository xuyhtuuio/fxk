package com.maxnerva.cloudmes.controller.scrap;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.scrap.*;
import com.maxnerva.cloudmes.models.vo.scrap.*;
import com.maxnerva.cloudmes.service.scrap.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Api(tags = "废料区管理")
@Slf4j
@RestController
@RequestMapping("/steelRubbish")
public class SteelRubbishController {

    @Autowired
    private ISdsSteelScrapWeightInfoService steelScrapWeightInfoService;

    @Autowired
    private ISteelScrapWeightService steelScrapWeightService;

    @Autowired
    private ISdsSteelScrapWeightInfoLogService steelScrapWeightInfoLogService;

    @Autowired
    private ISdsSteelScrapWeightRejectService steelScrapWeightRejectService;

    @Autowired
    private ISdsSteelScrapShipHeaderService steelScrapShipHeaderService;


    @ApiOperation("废料厂提交入库")
    @PostMapping("/submitRubbishWeightInfo")
    R<RubbishWeightInfoSubmitDTO> submitRubbishWeightInfo(@RequestBody RubbishWeightInfoSubmitVO vo){
        return steelScrapWeightService.submitRubbishWeightInfo(vo);
    }

    @ApiOperation("废料厂异常接收/拒收")
    @PostMapping("/confirmRubbishWeightInfo")
    R confirmRubbishWeightInfo(@RequestBody RubbishWeightInfoConfirmVO vo){
        steelScrapWeightService.confirmRubbishWeightInfo(vo);
        return R.ok();
    }

    @ApiOperation("废料厂入库拒收处理分页")
    @GetMapping("/getWeightInfoRejectPageList")
    R<PageDataDTO<SteelScrapWeightRejectDTO>> getWeightInfoRejectPageList(RubbishWeightRejectQueryVO vo){
        return R.ok(steelScrapWeightRejectService.selectPageList(vo, Boolean.TRUE));
    }

    @ApiOperation("废料厂入库拒收处理导出")
    @GetMapping("/exportWeightInfoRejectPageList")
    void exportWeightInfoRejectPageList(RubbishWeightRejectQueryVO vo, HttpServletResponse response){
        steelScrapWeightRejectService.exportDetail(vo, response);
    }

    @ApiOperation("废料厂拒收处理")
    @PostMapping("/rejectHandleRubbishSubmit")
    R rejectHandleRubbishSubmit(@RequestBody RubbishWeightRejectHandleSubmitVO vo){
        steelScrapWeightRejectService.handleSubmit(vo);
        return R.ok();
    }

    @ApiOperation("固废出库列印单据")
    @PostMapping("/printScrapShipmentApply")
    R<PrintScrapShipmentApplyDTO> printScrapShipmentApply(@RequestBody PrintScrapShipmentApplyVO vo){
        return R.ok(steelScrapShipHeaderService.printScrapShipmentApply(vo));
    }

    @ApiOperation("固废出库放行后同步整车重量JOB")
    @PostMapping("/syncFullCarWeight")
    R syncFullCarWeight(){
        steelScrapShipHeaderService.syncFullCarWeight();
        return R.ok();
    }

    @ApiOperation("入废料区信息查询")
    @GetMapping("/inScrapAreaInfo")
    R<InScrapAreaInfoDTO> inScrapAreaInfo(InScrapAreaInfoVO vo){
        return R.ok(steelScrapShipHeaderService.inScrapAreaInfo(vo));
    }

    @ApiOperation("入废料区放行")
    @PostMapping("/inScrapAreaSubmit")
    R inScrapAreaSubmit(@RequestBody InScrapAreaSubmitVO vo){
        steelScrapShipHeaderService.inScrapAreaSubmit(vo);
        return R.ok();
    }

    @ApiOperation("出废料区信息查询")
    @GetMapping("/outScrapAreaInfo")
    R<OutScrapAreaInfoDTO> outScrapAreaInfo(OutScrapAreaInfoVO vo){
        return R.ok(steelScrapShipHeaderService.outScrapAreaInfo(vo));
    }

    @ApiOperation("出废料区放行")
    @PostMapping("/outScrapAreaSubmit")
    R outScrapAreaSubmit(@RequestBody OutScrapAreaSubmitVO vo){
        steelScrapShipHeaderService.outScrapAreaSubmit(vo);
        return R.ok();
    }

    @ApiOperation("出库单分页查询")
    @GetMapping("/getScrapShipHeaderPageList")
    R<PageDataDTO<SteelScrapShipHeaderDTO>> getScrapShipHeaderPageList(SteelScrapShipHeaderQueryVO vo){
        return R.ok(steelScrapShipHeaderService.selectPageList(vo, Boolean.TRUE));
    }

    @ApiOperation("获取出库单图片列表")
    @GetMapping("/getPictureList")
    R<List<String>> getPictureList(String docNo){
        return R.ok(steelScrapShipHeaderService.getPictureList(docNo));
    }

    @ApiOperation("出库单导出")
    @GetMapping("/exportScrapShipHeaderPageList")
    void exportScrapShipHeaderPageList(SteelScrapShipHeaderQueryVO vo, HttpServletResponse response){
        steelScrapShipHeaderService.exportDetail(vo, response);
    }

    @ApiOperation("废料厂拒收")
    @PostMapping("/rejectWeightInfo")
    R rejectWeightInfo(RejectWeightInfoVO vo){
        steelScrapWeightService.rejectWeightInfo(vo);
        return R.ok();
    }
}
