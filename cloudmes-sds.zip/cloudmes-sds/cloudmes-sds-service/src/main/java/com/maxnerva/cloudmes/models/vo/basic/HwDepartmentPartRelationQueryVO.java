package com.maxnerva.cloudmes.models.vo.basic;

import com.maxnerva.cloudmes.models.vo.PageQueryVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @ClassName HwDepartmentPartRelationVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/7
 * @Version 1.0
 * @Since JDK 1.8
 **/
@EqualsAndHashCode(callSuper = true)
@ApiModel("危废种类查询vo")
@Data
public class HwDepartmentPartRelationQueryVO extends PageQueryVO {

    @ApiModelProperty("费用代码")
    private String costCode;

    @ApiModelProperty("废物俗称")
    private String hazardousWasteName;
}
