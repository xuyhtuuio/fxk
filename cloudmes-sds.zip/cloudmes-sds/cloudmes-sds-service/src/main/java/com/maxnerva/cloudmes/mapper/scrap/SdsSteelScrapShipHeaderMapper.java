package com.maxnerva.cloudmes.mapper.scrap;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.dto.scrap.ScrapDetailClassStockDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelScrapShipHeaderByPaymentDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelScrapShipHeaderPaymentDTO;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapShipHeader;
import com.maxnerva.cloudmes.models.vo.scrap.SteelScrapShipHeaderByPaymentQueryVO;
import com.maxnerva.cloudmes.models.vo.scrap.SteelScrapShipHeaderPaymentQueryVO;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public interface SdsSteelScrapShipHeaderMapper extends BaseMapper<SdsSteelScrapShipHeader> {

    BigDecimal selectTotalScrapNetWeight(String scrapDetailClass);

    List<ScrapDetailClassStockDTO> selectAllTotalScrapNetWeight(List<String> scrapDetailClassList, LocalDateTime startDateTime, LocalDateTime endDateTime);

    List<SteelScrapShipHeaderPaymentDTO> selectPaymentPageList(SteelScrapShipHeaderPaymentQueryVO vo);

    List<SteelScrapShipHeaderByPaymentDTO> selectByPaymentPageList(SteelScrapShipHeaderByPaymentQueryVO vo);
}
