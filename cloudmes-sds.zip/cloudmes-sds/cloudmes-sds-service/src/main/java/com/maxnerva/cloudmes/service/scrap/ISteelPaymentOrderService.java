package com.maxnerva.cloudmes.service.scrap;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.models.dto.scrap.PaymentUploadDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelScrapShipHeaderByPaymentDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelScrapShipHeaderPaymentDTO;
import com.maxnerva.cloudmes.models.vo.scrap.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

public interface ISteelPaymentOrderService {

    PageDataDTO<SteelScrapShipHeaderPaymentDTO> shipHeaderPageList(SteelScrapShipHeaderPaymentQueryVO vo, Boolean isPage);

    void exportShipHeaderPageList(SteelScrapShipHeaderPaymentQueryVO vo, HttpServletResponse response);

    PageDataDTO<SteelScrapShipHeaderByPaymentDTO> shipHeaderByPaymentPageList(SteelScrapShipHeaderByPaymentQueryVO vo, Boolean isPage);

    void exportShipHeaderByPaymentPageList(SteelScrapShipHeaderByPaymentQueryVO vo, HttpServletResponse response);

    String createPaymentOrderByShipHeader(SteelScrapShipHeaderPaymentQueryVO vo);

    void exportPaymentOrderExcel(PaymentOrderExcelExportVO vo, HttpServletResponse response);

    void salesMailNotify();

    void uploadFile(PaymentFileUploadVO paymentFileUploadVO);

    void paymentOrderUploadSendMail();

    List<PaymentUploadDTO> deleteFile(DeleteFileVO deleteFileVO);
}
