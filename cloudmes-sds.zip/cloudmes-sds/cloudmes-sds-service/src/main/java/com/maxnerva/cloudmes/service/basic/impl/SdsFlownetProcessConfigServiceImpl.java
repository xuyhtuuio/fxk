package com.maxnerva.cloudmes.service.basic.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.mapper.basic.SdsFlownetProcessConfigMapper;
import com.maxnerva.cloudmes.models.entity.basic.SdsFlownetProcessConfig;
import com.maxnerva.cloudmes.service.basic.ISdsFlownetProcessConfigService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 危废flownet流程id配置表 服务实现类
 * </p>
 *
 * @author likun
 * @since 2025-07-01
 */
@Service
public class SdsFlownetProcessConfigServiceImpl extends ServiceImpl<SdsFlownetProcessConfigMapper, SdsFlownetProcessConfig>
        implements ISdsFlownetProcessConfigService {

}
