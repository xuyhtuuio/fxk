package com.maxnerva.cloudmes.models.dto.waste.report;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @ClassName WasteInventoryOverdueWarnDTO
 * @Description TODO
 * @Author Likun
 * @Date 2025/6/23
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("库存超期预警dto")
@Data
public class WasteInventoryOverdueWarnDTO {

    @ApiModelProperty(value = "申请单号")
    private String docNo;

    @ApiModelProperty(value = "危废料号")
    private String hazardousWasteNo;

    @ApiModelProperty(value = "废物俗称")
    private String hazardousWasteName;

    @ApiModelProperty(value = "申请人")
    private String creator;

    @ApiModelProperty(value = "申请人费用代码")
    private String costCode;

    @ApiModelProperty(value = "申请人部门")
    private String depName;

    @ApiModelProperty(value = "产生时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime productionDate;

    @ApiModelProperty(value = "申请数量")
    private BigDecimal applyQty;

    @ApiModelProperty(value = "产废毛重")
    private BigDecimal applyGrossWeight;

    @ApiModelProperty(value = "产废净重")
    private BigDecimal applyNetWeight;

    @ApiModelProperty(value = "入库毛重")
    private BigDecimal instoreGrossWeight;

    @ApiModelProperty(value = "入库净重")
    private BigDecimal instoreNetWeight;

    @ApiModelProperty(value = "入库时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime instoreDt;

    @ApiModelProperty(value = "入库人")
    private String instoreEmp;

    @ApiModelProperty(value = "产废称重人")
    private String weightEmp;

    @ApiModelProperty(value = "产废称重时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime weightDt;
}
