package com.maxnerva.cloudmes.service.waste;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.waste.WasteInStoreDocInfoDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteInStoreWeightSubmitDTO;
import com.maxnerva.cloudmes.models.vo.waste.WasteInStoreConfirmVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteInStoreDocQueryVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteWeightInfoSubmitVO;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @ClassName WasteInStoreService
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/16
 * @Version 1.0
 * @Since JDK 1.8
 **/
public interface WasteInStoreService {

    PageDataDTO<WasteInStoreDocInfoDTO> selectWasteInStorePage(WasteInStoreDocQueryVO queryVO);

    R<WasteInStoreWeightSubmitDTO> inStoreWeightSubmit(WasteWeightInfoSubmitVO submitVO);

    void confirmInStoreWeightInfo(WasteInStoreConfirmVO confirmVO);

    void applyShip(List<Integer> idList, String docType);


    void exportInStoreDoc(HttpServletResponse response, WasteInStoreDocQueryVO queryVO);

}
