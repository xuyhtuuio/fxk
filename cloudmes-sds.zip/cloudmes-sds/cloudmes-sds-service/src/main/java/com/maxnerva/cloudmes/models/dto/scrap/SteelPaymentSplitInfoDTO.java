package com.maxnerva.cloudmes.models.dto.scrap;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class SteelPaymentSplitInfoDTO {
    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("缴款单号")
    private String paymentDocNo;

    @ApiModelProperty("厂部")
    private String departmentCode;

    @ApiModelProperty("厂部名称")
    private String departmentCodeName;

    @ApiModelProperty("入库重量")
    private BigDecimal inStoreNetWeight;

    @ApiModelProperty("入库占比")
    private BigDecimal inStorePercentage;

    @ApiModelProperty("入库占比")
    private String inStorePercentageName;

    @ApiModelProperty("分账金额")
    private BigDecimal splitAccount;

    @ApiModelProperty("费用代码")
    private String costCode;
}
