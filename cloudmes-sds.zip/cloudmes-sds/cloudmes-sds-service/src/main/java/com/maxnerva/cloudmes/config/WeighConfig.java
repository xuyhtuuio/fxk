package com.maxnerva.cloudmes.config;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

import java.time.LocalDate;


@RefreshScope
@Component
@Data
public class WeighConfig {

    @Value("${weight.rubbish-timeout:}")
    private Long rubbishTimeout;

    @JsonFormat(pattern = "yyyy-MM-dd")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @Value("${weight.rubbish-start-date:}")
    private LocalDate rubbishStartDate;
}
