package com.maxnerva.cloudmes.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.entity.basic.SdsSteelPaymentEndDateConfig;

public interface SdsSteelPaymentEndDateConfigMapper extends BaseMapper<SdsSteelPaymentEndDateConfig> {
}
