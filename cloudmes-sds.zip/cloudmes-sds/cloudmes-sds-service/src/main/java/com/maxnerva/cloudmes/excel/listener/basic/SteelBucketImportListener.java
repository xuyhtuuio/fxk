package com.maxnerva.cloudmes.excel.listener.basic;

import cn.hutool.core.util.ObjectUtil;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.google.common.collect.Lists;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.models.vo.excel.basic.SteelBucketImportVO;
import jodd.util.StringUtil;

import java.util.List;

/**
 * @ClassName SteelBucketImportListener
 * @Description TODO
 * @Author Likun
 * @Date 2024/10/28
 * @Version 1.0
 * @Since JDK 1.8
 **/
public class SteelBucketImportListener extends AnalysisEventListener<SteelBucketImportVO> {

    public List<SteelBucketImportVO> getSteelBucketImportVOList() {
        return steelBucketImportVOList;
    }

    public List<String> getError() {
        return error;
    }

    private List<SteelBucketImportVO> steelBucketImportVOList = Lists.newArrayList();

    private List<String> error = Lists.newArrayList();

    private int row = 1;

    @Override
    public void invoke(SteelBucketImportVO steelBucketImportVO, AnalysisContext context) {
        row++;
        convertAndCheck(steelBucketImportVO);
        steelBucketImportVOList.add(steelBucketImportVO);
    }

    @Override
    public void doAfterAllAnalysed(AnalysisContext context) {

    }

    private void convertAndCheck(SteelBucketImportVO steelBucketImportVO) {
        StringBuilder msg = new StringBuilder();
        if (StringUtil.isBlank(steelBucketImportVO.getBucketNo())) {
            msg.append(MessageUtils.get(SdsResultCode.BUCKET_NO_IS_EMPTY
                    .getLocalCode())).append(",");
        }
        if (ObjectUtil.isNull(steelBucketImportVO.getBucketWeight())) {
            msg.append(MessageUtils.get(SdsResultCode.BUCKET_WEIGHT_IS_NULL
                    .getLocalCode())).append(",");
        }
        if (msg.length() > 0) {
            msg.insert(0, String.format(MessageUtils.get(SdsResultCode.ERROR_MESSAGE_IN_LINE
                    .getLocalCode()), row));
            msg.delete(msg.length() - 1, msg.length());
            msg.append(";");
            error.add(msg.toString());
        }
    }
}
