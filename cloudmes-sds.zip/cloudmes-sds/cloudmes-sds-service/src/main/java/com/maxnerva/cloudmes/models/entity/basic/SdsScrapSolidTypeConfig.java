package com.maxnerva.cloudmes.models.entity.basic;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 固废分类配置表
 * </p>
 *
 * @author likun
 * @since 2024-12-11
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="SdsScrapSolidTypeConfig对象", description="固废分类配置表")
public class SdsScrapSolidTypeConfig extends BaseEntity<SdsScrapSolidTypeConfig> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "报废大类")
    private String scrapClass;

    @ApiModelProperty(value = "报废大类描述")
    private String scrapClassDesc;

    @ApiModelProperty(value = "报废小类")
    private String scrapDetailClass;

    @ApiModelProperty(value = "报废小类描述")
    private String scrapDetailClassDesc;

    @ApiModelProperty(value = "报废类型")
    private String scrapType;

    @ApiModelProperty(value = "是否贵重")
    private Boolean isValuable;

    @ApiModelProperty(value = "是否进废料暂存区")
    private Boolean isScrapArea;

    @ApiModelProperty(value = "报废料号")
    private String scrapPartNo;

    @ApiModelProperty(value = "ECUS废料描述")
    private String ecusScrapDesc;

    @ApiModelProperty(value = "ECUS废料类型")
    private String ecusScrapType;
}
