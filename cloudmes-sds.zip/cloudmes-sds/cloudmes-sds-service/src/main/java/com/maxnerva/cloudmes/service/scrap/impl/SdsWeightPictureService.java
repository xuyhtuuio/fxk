package com.maxnerva.cloudmes.service.scrap.impl;

import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hikvision.artemis.sdk.ArtemisHttpUtil;
import com.hikvision.artemis.sdk.config.ArtemisConfig;
import com.hikvision.artemis.sdk.constant.Constants;
import com.maxnerva.cloudmes.common.constant.BucketConstant;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.enums.HikApiTypeEnum;
import com.maxnerva.cloudmes.enums.HikAreaCodeEnum;
import com.maxnerva.cloudmes.enums.PrintTypeEnum;
import com.maxnerva.cloudmes.mapper.scrap.SdsHikAreaCodeLinkMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsHikPictureLogMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelScrapShipHeaderMapper;
import com.maxnerva.cloudmes.models.dto.scrap.HikvisionPictureDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsPrintTemplateConfig;
import com.maxnerva.cloudmes.models.entity.scrap.SdsHikAreaCodeLink;
import com.maxnerva.cloudmes.models.entity.scrap.SdsHikPictureLog;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapShipHeader;
import com.maxnerva.cloudmes.service.scrap.ISdsWeightPictureService;
import com.maxnerva.cloudmes.system.feign.IUploadFileClient;
import com.maxnerva.cloudmes.system.models.dto.UploadFileDTO;
import com.maxnerva.cloudmes.system.models.dto.UploadFileRespDTO;
import com.maxnerva.cloudmes.system.models.vo.FileDeleteVO;
import com.maxnerva.cloudmes.system.models.vo.FileQueryByIdsVO;
import com.maxnerva.cloudmes.system.models.vo.FileUploadVO;
import jodd.util.StringUtil;
import jodd.util.concurrent.ThreadFactoryBuilder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.multipart.MultipartFile;
import io.minio.errors.MinioException;

import javax.annotation.Resource;
import javax.net.ssl.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

/**
 * @ClassName SdsWeightPictureService
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/1/2 下午 02:15
 * @Version 1.0
 **/
@Service
@Slf4j
@RefreshScope
public class SdsWeightPictureService extends ServiceImpl<SdsHikPictureLogMapper, SdsHikPictureLog> implements ISdsWeightPictureService {

    @Value("${hik.host:}")
    private String host;

    @Value("${hik.appKey:}")
    private String appKey;

    @Value("${hik.appSecret:}")
    private String appSecret;

    private static final String ARTEMIS_PATH = "/artemis";

    @Autowired
    IUploadFileClient uploadFileClient;

    @Autowired
    SdsHikPictureLogMapper sdsHikPictureLogMapper;

    @Autowired
    SdsHikAreaCodeLinkMapper sdsHikAreaCodeLinkMapper;

    @Resource
    SdsSteelScrapShipHeaderMapper sdsSteelScrapShipHeaderMapper;

    static {
        //连接超时时间
        Constants.DEFAULT_TIMEOUT = 10000000;
        //读取超时时间
        Constants.SOCKET_TIMEOUT = 10000000;

    }

    @Override
    public void catchHikvisionPictureJob() {
        SdsSteelScrapShipHeader currentShipHeader = null;
        // 只要前五个
        List<SdsSteelScrapShipHeader> sdsSteelScrapShipHeaderList = sdsSteelScrapShipHeaderMapper.selectList(new LambdaQueryWrapper<SdsSteelScrapShipHeader>()
                .orderByDesc(SdsSteelScrapShipHeader::getId)
                .last("limit 5")
        );
        for (SdsSteelScrapShipHeader sdsSteelScrapHeader: sdsSteelScrapShipHeaderList) {
            if(ObjectUtil.isNotNull(sdsSteelScrapHeader.getInScrapAreaDt()) && ObjectUtil.isNull(sdsSteelScrapHeader.getOutScrapAreaDt())) {
                currentShipHeader = sdsSteelScrapHeader;
            }
        }
        // 当前文件ID
        Integer currentPicId = null;
        List<HikAreaCodeEnum> hikAreaCodeEnumList = Arrays.asList(HikAreaCodeEnum.values());
        ArrayList<SdsHikPictureLog> sdsHikPictureLogs = new ArrayList<>();
        if (ObjectUtil.isNotNull(currentShipHeader)) {
            for (HikAreaCodeEnum hikAreaCodeItem : hikAreaCodeEnumList) {
                try {
                    // 获取图片链接
                    String picUrl = catchPicture(hikAreaCodeItem.getDictCode());
                    if (StringUtil.isEmpty(picUrl)) {
                        log.info("当前图片获取失败，当前图片为： {}", hikAreaCodeItem.getDictName());
                    }
                    log.info("抓取成功, 图片路径为:   {}", picUrl);

                    // 获取当前日期并格式化为文件夹名称
                    String uniqueFileName = UUID.randomUUID().toString() + ".jpeg";
                    String fileName = uniqueFileName;
                    // 获取当前文件
                    MultipartFile multipartFile = pictureLinkToMultipartFileHandler(picUrl, fileName);
                    log.info("获取文件成功, 文件为: {}", multipartFile);
                    List<MultipartFile> fileList = new ArrayList<>();
                    fileList.add(multipartFile);
                    //上传文件
                    FileUploadVO fileUploadVO = new FileUploadVO();
                    fileUploadVO.setBucketName(BucketConstant.CLOUD_SAAS);
                    fileUploadVO.setFiles(fileList);
                    // 上传到OSS
                    R<List<UploadFileRespDTO>> listR = uploadFileClient.uploadBatch(fileUploadVO);
                    List<UploadFileRespDTO> uploadFileRespDTOList = listR.getData();
                    if (ObjectUtil.isEmpty(uploadFileRespDTOList)) {
                        throw new CloudmesException("上传失败");
                    }

                    log.info("当前图片下载路径为:  {}", uploadFileRespDTOList.get(0).getLink());
                    List<String> urlList = uploadFileRespDTOList.stream().map(UploadFileRespDTO::getName).collect(Collectors.toList());
                    String hikvisionCameraPictureLink = urlList.get(0);
                    currentPicId = uploadFileRespDTOList.get(0).getId();

                    SdsHikAreaCodeLink sdsHikAreaCodeLink = sdsHikAreaCodeLinkMapper.selectOne(Wrappers.<SdsHikAreaCodeLink>lambdaQuery()
                            .eq(SdsHikAreaCodeLink::getAreaCode, hikAreaCodeItem.getDictCode())
                            .last("limit 1"));
                    SdsHikPictureLog sdsHikPictureLog = new SdsHikPictureLog();
                    sdsHikPictureLog.setId(null);
                    sdsHikPictureLog.setPicUrl(hikvisionCameraPictureLink);
                    sdsHikPictureLog.setPicName(fileName);
                    sdsHikPictureLog.setPicId(currentPicId);
                    sdsHikPictureLog.setAreaName(hikAreaCodeItem.getDictName());
                    sdsHikPictureLog.setAreaCode(hikAreaCodeItem.getDictCode());
                    sdsHikPictureLog.setAreaType(sdsHikAreaCodeLink.getAreaType());
                    sdsHikPictureLog.setAreaTypeName(sdsHikAreaCodeLink.getAreaTypeName());
                    sdsHikPictureLog.setDeclareNumber(currentShipHeader.getDeclareNumber());
                    sdsHikPictureLogs.add(sdsHikPictureLog);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            Boolean isHikPictureUpload = saveBatch(sdsHikPictureLogs);
            if (BooleanUtil.isFalse(isHikPictureUpload)) {
                log.info("添加图片到数据库失败 ");
                if (checkObjectFileIsExist(currentPicId)) {
                    // 保证双方一致性
                    deleteObjectFromMinio(BucketConstant.CLOUD_SAAS, currentPicId);
                }
            }
        } else {
            log.info("当前暂存区无车辆进入");
        }
    }

    @Override
    public String catchPicture(String areaCode) throws Exception {
        ArtemisConfig config = new ArtemisConfig();

        config.setHost(this.host); // 代理API网关nginx服务器ip端口
        config.setAppKey(this.appKey);  // 秘钥appkey
        config.setAppSecret(this.appSecret);// 秘钥appSecret
        // 根路径
        final String getCamsApi = ARTEMIS_PATH + HikApiTypeEnum.GET_PICTURE_ON_TIME.getDictName();
        // post请求Form表单参数
        Map<String, String> paramMap = new HashMap<String, String>();

        // 沖壓厂設備ID
        SdsHikAreaCodeLink sdsHikAreaCodeLink = sdsHikAreaCodeLinkMapper.selectOne(Wrappers.<SdsHikAreaCodeLink>lambdaQuery()
                .eq(SdsHikAreaCodeLink::getAreaCode, areaCode)
                .last("limit 1"));

        paramMap.put("cameraIndexCode", sdsHikAreaCodeLink.getCameraCode());

        String body = JSON.toJSON(paramMap).toString();
        Map<String, String> path = new HashMap<String, String>(2) {
            {
                put("https://", getCamsApi);
            }
        };
        String resJson = ArtemisHttpUtil.doPostStringArtemis(config, path, body, null, null, "application/json");
        JSONObject jsonObject = JSON.parseObject(resJson);
        HikvisionPictureDTO data = jsonObject.getObject("data", HikvisionPictureDTO.class);
        return data.getPicUrl();
    }

    @Override
    public MultipartFile pictureLinkToMultipartFileHandler(String imageUrl, String fileName) {
        InputStream inputStream = null;
        MultipartFile multipartFile = null;

        try {
            // 初始化SSL
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, new TrustManager[]{
                    new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }

                        @Override
                        public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }

                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return new X509Certificate[0];
                        }
                    }
            }, new SecureRandom());

            // 创建URL对象
            URL url = new URL(imageUrl);

            // 打开连接
            HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setDoOutput(true);// 允许输出

            // 设置证书忽略相关操作
            connection.setSSLSocketFactory(sc.getSocketFactory());
            connection.setHostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String s, SSLSession sslSession) {
                    return true;
                }
            });

            // 创建连接
            connection.connect();

            // 检查响应码
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                // 获取输入流（图片数据）
                inputStream = connection.getInputStream();

                // 使用 ByteArrayOutputStream 来保存 InputStream 的数据
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                byte[] buffer = new byte[1024];
                int bytesRead;

                // 将 InputStream 的数据读取到 ByteArrayOutputStream 中
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    byteArrayOutputStream.write(buffer, 0, bytesRead);
                }

                // 获取字节数组
                final byte[] bytes = byteArrayOutputStream.toByteArray();
                // 创建文件对象
                multipartFile = new MultipartFile() {
                    @Override
                    public String getName() {
                        return fileName;
                    }

                    @Override
                    public String getOriginalFilename() {
                        return fileName;
                    }

                    @Override
                    public String getContentType() {
                        return MimeTypeUtils.IMAGE_JPEG_VALUE;
                    }

                    @Override
                    public boolean isEmpty() {
                        return false;
                    }

                    @Override
                    public long getSize() {
                        return bytes.length;
                    }

                    @Override
                    public byte[] getBytes() throws IOException {
                        return bytes;
                    }

                    @Override
                    public InputStream getInputStream() throws IOException {
                        return new ByteArrayInputStream(bytes);
                    }

                    @Override
                    public void transferTo(File dest) throws IOException, IllegalStateException {
                    }
                };

                // 关闭资源
                byteArrayOutputStream.close();
                if (inputStream != null) {
                    inputStream.close();
                }
                // 断开连接
                connection.disconnect();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return multipartFile;
    }

    private void deleteObjectFromMinio(String bucketName, Integer currentObjectId) {
        FileDeleteVO fileDeleteVO = new FileDeleteVO();
        fileDeleteVO.setBucketName(bucketName);
        Set<Integer> uploadPictureIds = new HashSet<>();
        uploadPictureIds.add(currentObjectId);
        fileDeleteVO.setFileIds(uploadPictureIds);
        uploadFileClient.delete(fileDeleteVO);
    }

    private Boolean checkObjectFileIsExist(Integer fileId) {
        Boolean currentExist = Boolean.TRUE;
        FileQueryByIdsVO fileQueryByIdsVO = new FileQueryByIdsVO();
        Set<Integer> currentObjectSet = new HashSet<>();
        currentObjectSet.add(fileId);
        fileQueryByIdsVO.setFileIds(currentObjectSet);
        R<List<UploadFileDTO>> byIds = uploadFileClient.findByIds(fileQueryByIdsVO);

        if (ObjectUtil.isEmpty(byIds)) {
            currentExist = Boolean.FALSE;
        }
        return currentExist;
    }
}
