package com.maxnerva.cloudmes.mapper.scrap;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.dto.scrap.ScrapDetailClassStockDTO;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapWeightInfo;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public interface SdsSteelScrapWeightInfoMapper extends BaseMapper<SdsSteelScrapWeightInfo> {

    BigDecimal selectTotalScrapNetWeight(String scrapDetailClass);

    List<ScrapDetailClassStockDTO> selectAllTotalScrapNetWeight(List<String> scrapDetailClassList, LocalDateTime startDateTime, LocalDateTime endDateTime);

    List<ScrapDetailClassStockDTO> selectAllTotalBuScrapNetWeight(List<String> scrapDetailClassList, LocalDateTime startDateTime, LocalDateTime endDateTime);
}
