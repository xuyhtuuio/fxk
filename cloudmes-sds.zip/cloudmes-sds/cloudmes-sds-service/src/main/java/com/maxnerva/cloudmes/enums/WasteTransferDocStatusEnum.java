package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName WasteTransferDocStatusEnum
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/28
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum WasteTransferDocStatusEnum {

    LEAVE_FACTORY("LEAVE_FACTORY","已离厂"),
    UN_LEAVE_FACTORY("UN_LEAVE_FACTORY","未离厂");


    private String dictCode;

    private String dictName;

    WasteTransferDocStatusEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (WasteTransferDocStatusEnum wasteTransferDocStatusEnum : values()) {
            if (wasteTransferDocStatusEnum.getDictCode().equals(dictCode)) {
                return wasteTransferDocStatusEnum.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

    /**
     * 提前判断，用于解决
     * Case中出现的Constant expression required
     *
     * @param dictCode 值
     * @return wasteTransferDocStatusEnum
     */
    public static WasteTransferDocStatusEnum getByValue(String dictCode) {
        for (WasteTransferDocStatusEnum wasteTransferDocStatusEnum : values()) {
            if (wasteTransferDocStatusEnum.getDictCode().equals(dictCode)) {
                return wasteTransferDocStatusEnum;
            }
        }
        return null;
    }
}
