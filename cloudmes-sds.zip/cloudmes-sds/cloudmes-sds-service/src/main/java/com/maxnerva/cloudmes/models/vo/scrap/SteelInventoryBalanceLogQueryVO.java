package com.maxnerva.cloudmes.models.vo.scrap;

import com.maxnerva.cloudmes.models.vo.PageQueryVO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class SteelInventoryBalanceLogQueryVO extends PageQueryVO {
    @ApiModelProperty(value = "盘点单号")
    private String inventoryPlanNo;

    @ApiModelProperty("报废类别")
    private String scrapDetailClass;
}
