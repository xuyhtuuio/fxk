package com.maxnerva.cloudmes.service.scrap.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.enums.ResultCode;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.enums.CodeRuleEnum;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.excel.handler.AddNoHandler;
import com.maxnerva.cloudmes.feign.basic.ICodeRuleClient;
import com.maxnerva.cloudmes.mapper.basic.SdsSteelBucketInfoMapper;
import com.maxnerva.cloudmes.mapper.scrap.*;
import com.maxnerva.cloudmes.models.dto.excel.scrap.SteelInventoryPlanHeaderExportDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelInventoryPlanHeaderDTO;
import com.maxnerva.cloudmes.models.entity.scrap.*;
import com.maxnerva.cloudmes.models.vo.scrap.SteelInventoryPlanHeaderCompleteVO;
import com.maxnerva.cloudmes.models.vo.scrap.SteelInventoryPlanHeaderCreateVO;
import com.maxnerva.cloudmes.models.vo.scrap.SteelInventoryPlanHeaderQueryVO;
import com.maxnerva.cloudmes.service.scrap.ISdsSteelInventoryPlanHeaderService;
import com.maxnerva.cloudmes.system.utils.DictLangUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.MimeTypeUtils;

import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class SdsSteelInventoryPlanHeaderService extends ServiceImpl<SdsSteelInventoryPlanHeaderMapper, SdsSteelInventoryPlanHeader> implements ISdsSteelInventoryPlanHeaderService {

    @Autowired
    private ICodeRuleClient codeRuleClient;

    @Autowired
    DictLangUtils dictLangUtils;

    @Autowired
    SdsSteelBucketInfoMapper steelBucketInfoMapper;

    @Autowired
    SdsSteelScrapWeightInfoMapper steelScrapWeightInfoMapper;

    @Autowired
    SdsSteelScrapShipHeaderMapper steelScrapShipHeaderMapper;

    @Autowired
    SdsSteelInventoryPlanDetailMapper steelInventoryPlanDetailMapper;

    @Autowired
    SdsSteelInventoryPlanSummaryMapper steelInventoryPlanSummaryMapper;

    @Override
    public PageDataDTO<SteelInventoryPlanHeaderDTO> selectPageList(SteelInventoryPlanHeaderQueryVO vo, Boolean isPage) {
        Page page = new Page();
        if (BooleanUtil.isTrue(isPage)){
            page = PageHelper.startPage(vo.getPageIndex(), vo.getPageSize());
        }
        List<SdsSteelInventoryPlanHeader> list = baseMapper.selectList(Wrappers.<SdsSteelInventoryPlanHeader>lambdaQuery()
                .eq(StrUtil.isNotBlank(vo.getInventoryPlanNo()), SdsSteelInventoryPlanHeader::getInventoryPlanNo, vo.getInventoryPlanNo())
                .eq(!"3".equals(vo.getInventoryStatus()), SdsSteelInventoryPlanHeader::getInventoryStatus, vo.getInventoryStatus())
                .between(ObjectUtil.isNotNull(vo.getStartDateTime()) && ObjectUtil.isNotNull(vo.getEndDateTime()),
                        SdsSteelInventoryPlanHeader::getCreatedDt, vo.getStartDateTime(), vo.getEndDateTime())
                .eq(StrUtil.isNotBlank(vo.getCreator()), SdsSteelInventoryPlanHeader::getCreator, vo.getCreator())
        );
        List<SteelInventoryPlanHeaderDTO> result = ListUtil.toList();
        Map<String, Map<String, String>> dictMap = dictLangUtils.getByTypes(ListUtil.toList("SDS_SOLID_INVENTORY_STATUS", "SDS_SCRAP_SOLID"));
        list.forEach(item -> {
            SteelInventoryPlanHeaderDTO dto = new SteelInventoryPlanHeaderDTO();
            BeanUtil.copyProperties(item, dto);
            dto.setInventoryStatusName(dictMap.get("SDS_SOLID_INVENTORY_STATUS").get(dto.getInventoryStatus()));
            dto.setScrapDetailClassName(dictMap.get("SDS_SCRAP_SOLID").get(dto.getScrapDetailClass()));
            result.add(dto);
        });
        return new PageDataDTO(page.getTotal(), result);
    }

    @Override
    public void exportDetail(SteelInventoryPlanHeaderQueryVO vo, HttpServletResponse response) {
        PageDataDTO<SteelInventoryPlanHeaderDTO> pageDataDTO = selectPageList(vo, Boolean.FALSE);
        List<SteelInventoryPlanHeaderExportDTO> exportDTOList = ListUtil.toList();
        pageDataDTO.getList().forEach(item -> {
            SteelInventoryPlanHeaderExportDTO dto = new SteelInventoryPlanHeaderExportDTO();
            BeanUtil.copyProperties(item, dto);
            exportDTOList.add(dto);
        });

        String fileName = "固废盘点单记录" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), SteelInventoryPlanHeaderExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getLocalCode()));
        }
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void create(SteelInventoryPlanHeaderCreateVO vo) {
        SdsSteelInventoryPlanHeader steelInventoryPlanHeader = baseMapper.selectOne(Wrappers.<SdsSteelInventoryPlanHeader>lambdaQuery()
                .eq(SdsSteelInventoryPlanHeader::getScrapDetailClass, vo.getScrapDetailClass())
                .orderByDesc(SdsSteelInventoryPlanHeader::getId)
                .last("limit 1")
        );
        if (ObjectUtil.isNotNull(steelInventoryPlanHeader)) {
            if (!"2".equals(steelInventoryPlanHeader.getInventoryStatus())){
                throw new CloudmesException(String.format("报废类别%s有上一笔盘点%s未完成，不允许再建盘点计划", vo.getScrapDetailClass(), steelInventoryPlanHeader.getInventoryPlanNo()));
            }
        }

        //产生盘点编码
        R<List<String>> result = codeRuleClient.getSerialNumber(CodeRuleEnum.SDS_SCRAP_INVENTORY_NO.getDictCode(), 1);
        if (result.getCode() != ResultCode.SUCCESS.getCode()) {
            throw new CloudmesException(SdsResultCode.CONNECT_BASIC_GET_SERIAL_NUMBER.getCode()
                    , MessageUtils.get(SdsResultCode.CONNECT_BASIC_GET_SERIAL_NUMBER.getLocalCode()));
        }
        List<String> inventoryPlanNoList = result.getData();
        String inventoryPlanNo = inventoryPlanNoList.get(0);

        // 查询库存净重
        BigDecimal stockNetWeight = steelScrapWeightInfoMapper.selectTotalScrapNetWeight(vo.getScrapDetailClass());
        steelScrapWeightInfoMapper.update(null, Wrappers.<SdsSteelScrapWeightInfo>lambdaUpdate()
                .set(SdsSteelScrapWeightInfo::getInventoryPlanNo, inventoryPlanNo)
                .eq(SdsSteelScrapWeightInfo::getScrapDetailClass, vo.getScrapDetailClass())
                .eq(SdsSteelScrapWeightInfo::getRubbishWeighFlag, "Y")
                .and(t -> t.isNull(SdsSteelScrapWeightInfo::getInventoryPlanNo).or().eq(SdsSteelScrapWeightInfo::getInventoryPlanNo, StrUtil.EMPTY))
        );
        // 查询出库净重
        BigDecimal shipNetWeight = steelScrapShipHeaderMapper.selectTotalScrapNetWeight(vo.getScrapDetailClass());
        steelScrapShipHeaderMapper.update(null, Wrappers.<SdsSteelScrapShipHeader>lambdaUpdate()
                .set(SdsSteelScrapShipHeader::getInventoryPlanNo, inventoryPlanNo)
                .eq(SdsSteelScrapShipHeader::getScrapDetailClass, vo.getScrapDetailClass())
                .isNotNull(SdsSteelScrapShipHeader::getFullCarWeight)
                .and(t -> t.isNull(SdsSteelScrapShipHeader::getInventoryPlanNo).or().eq(SdsSteelScrapShipHeader::getInventoryPlanNo, StrUtil.EMPTY))
        );
        BigDecimal totalNetWeight = stockNetWeight.subtract(shipNetWeight);

        SdsSteelInventoryPlanHeader newSteelInventoryPlanHeader = new SdsSteelInventoryPlanHeader();
        newSteelInventoryPlanHeader.setDescription(vo.getDescription());
        newSteelInventoryPlanHeader.setInventoryExecutorCode(vo.getInventoryExecutorCode());
        newSteelInventoryPlanHeader.setInventoryPlanNo(inventoryPlanNo);
        newSteelInventoryPlanHeader.setInventoryStatus("0");
        newSteelInventoryPlanHeader.setScrapDetailClass(vo.getScrapDetailClass());

        SdsSteelInventoryPlanDetail steelInventoryPlanDetail = new SdsSteelInventoryPlanDetail();
        steelInventoryPlanDetail.setInventoryNetWeight(BigDecimal.ZERO);
        steelInventoryPlanDetail.setInventoryPlanNo(inventoryPlanNo);
        steelInventoryPlanDetail.setScrapDetailClass(vo.getScrapDetailClass());
        steelInventoryPlanDetail.setTotalNetWeight(totalNetWeight);

        baseMapper.insert(newSteelInventoryPlanHeader);
        steelInventoryPlanDetailMapper.insert(steelInventoryPlanDetail);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void complete(SteelInventoryPlanHeaderCompleteVO vo) {
        int updateVal = baseMapper.update(null, Wrappers.<SdsSteelInventoryPlanHeader>lambdaUpdate()
                .set(SdsSteelInventoryPlanHeader::getInventoryStatus, "2")
                .eq(SdsSteelInventoryPlanHeader::getId, vo.getId())
                .in(SdsSteelInventoryPlanHeader::getInventoryStatus, ListUtil.toList("0", "1"))
        );
        if (updateVal == 0) {
            throw new CloudmesException("该盘点单已完成。");
        }
        SdsSteelInventoryPlanHeader steelInventoryPlanHeader = baseMapper.selectById(vo.getId());
        SdsSteelInventoryPlanDetail steelInventoryPlanDetail = steelInventoryPlanDetailMapper.selectOne(Wrappers.<SdsSteelInventoryPlanDetail>lambdaQuery()
                .eq(SdsSteelInventoryPlanDetail::getInventoryPlanNo, steelInventoryPlanHeader.getInventoryPlanNo())
                .last("limit 1")
        );
        SdsSteelInventoryPlanSummary steelInventoryPlanSummary = new SdsSteelInventoryPlanSummary();
        BeanUtil.copyProperties(steelInventoryPlanHeader, steelInventoryPlanSummary);
        BeanUtil.copyProperties(steelInventoryPlanDetail, steelInventoryPlanSummary);
        steelInventoryPlanSummary.setId(null);
        steelInventoryPlanSummary.setStatus("0");
        steelInventoryPlanSummaryMapper.insert(steelInventoryPlanSummary);
    }
}

