package com.maxnerva.cloudmes.models.vo.scrap;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Data
public class RejectWeightInfoVO {

    @ApiModelProperty(value = "托盘编码", required = true)
    private String bucketNo;

    @ApiModelProperty(value = "拒收人", required = true)
    private String operateEmpNo;

    @ApiModelProperty(value = "拒收备注", required = true)
    private String operateRemarkType;

    @ApiModelProperty(value = "文件")
    private List<MultipartFile> files;
}
