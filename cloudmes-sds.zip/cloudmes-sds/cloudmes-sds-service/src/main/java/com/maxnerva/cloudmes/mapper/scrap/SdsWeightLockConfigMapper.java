package com.maxnerva.cloudmes.mapper.scrap;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.entity.scrap.SdsWeightLockConfig;

/**
 * @ClassName SdsWeightLockConfigMapper
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/2/14 上午 09:51
 * @Version 1.0
 **/
public interface SdsWeightLockConfigMapper extends BaseMapper<SdsWeightLockConfig> {
}
