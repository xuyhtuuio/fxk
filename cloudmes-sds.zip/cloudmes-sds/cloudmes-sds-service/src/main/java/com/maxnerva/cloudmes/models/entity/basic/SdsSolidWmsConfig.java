package com.maxnerva.cloudmes.models.entity.basic;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * WMS和SDS固废类别对应关系
 * </p>
 *
 * @author baomidou
 * @since 2025-02-17
 */
@TableName("sds_solid_wms_config")
@ApiModel(value = "SdsSolidWmsConfig对象", description = "WMS和SDS固废类别对应关系")
@Data
public class SdsSolidWmsConfig extends BaseEntity<SdsSolidWmsConfig> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("WMS报废归类")
    private String scrapClass;

    @ApiModelProperty("SDS报废料号")
    private String sdsScrapDetailClass;

    @ApiModelProperty("SDS部门代码")
    private String sdsDepartmentCode;
}
