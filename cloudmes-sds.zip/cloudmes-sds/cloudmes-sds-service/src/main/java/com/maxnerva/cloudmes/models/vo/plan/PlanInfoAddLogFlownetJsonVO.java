package com.maxnerva.cloudmes.models.vo.plan;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.formula.functions.T;

import java.math.BigDecimal;
import java.util.List;

/**
 * @ClassName PlanInfoAddLogFlownetJsonVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/7/1
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("通用flownet流程vo")
@Data
public class PlanInfoAddLogFlownetJsonVO {

    @ApiModelProperty("申请单号")
    private String docNo;

    private Object applyUser;

    private String applyType;

    @ApiModelProperty("费用代码")
    private String costCode;

    @ApiModelProperty("申请人工号")
    private String creator;

    @ApiModelProperty("申请年度")
    private String planYear;

    @ApiModelProperty("废物俗称")
    private String hazardousWasteName;

    @ApiModelProperty("废物代码")
    private String hazardousWasteCode;

    @ApiModelProperty("当前年度量")
    private BigDecimal oldPlanWeight;

    @ApiModelProperty("增加量")
    private BigDecimal planAddWeight;

    @ApiModelProperty("增量原因")
    private String incrementReason;

    private List<Object> signStep;
}
