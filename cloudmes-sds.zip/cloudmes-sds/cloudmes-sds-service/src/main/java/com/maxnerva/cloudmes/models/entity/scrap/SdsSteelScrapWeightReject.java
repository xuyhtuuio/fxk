package com.maxnerva.cloudmes.models.entity.scrap;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 入库拒收处理表
 * </p>
 *
 * @author baomidou
 * @since 2024-12-16
 */
@TableName("sds_steel_scrap_weight_reject")
@ApiModel(value = "SdsSteelScrapWeightReject对象", description = "入库拒收处理表")
@Data
public class SdsSteelScrapWeightReject extends BaseEntity<SdsSteelScrapWeightReject> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("工厂组织")
    private String orgCode;

    @ApiModelProperty("报废小类")
    private String scrapDetailClass;

    @ApiModelProperty("厂部编码")
    private String departmentCode;

    @ApiModelProperty("状态")
    private String status;

    @ApiModelProperty("托盘编码")
    private String bucketNo;

    private BigDecimal bucketWeight;

    @ApiModelProperty("单位")
    private String uom;

    @ApiModelProperty("毛重")
    private BigDecimal grossWeight;

    @ApiModelProperty("净重")
    private BigDecimal netWeight;

    @ApiModelProperty("称重人")
    private String weighEmpNo;

    @ApiModelProperty("称重时间")
    private LocalDateTime weighDt;

    @ApiModelProperty("暂存区毛重")
    private BigDecimal rubbishGrossWeight;

    @ApiModelProperty("暂存区净重")
    private BigDecimal rubbishNetWeight;

    @ApiModelProperty("暂存区称重人")
    private String rubbishWeighEmpNo;

    @ApiModelProperty("暂存区称重时间")
    private LocalDateTime rubbishWeighDt;

    @ApiModelProperty("拒收原因")
    private String rejectReason;

    @ApiModelProperty("拒收人")
    private String rejectEmpNo;

    @ApiModelProperty("拒收时间")
    private LocalDateTime rejectDt;

    @ApiModelProperty("处理人")
    private String handleEmpNo;

    @ApiModelProperty("处理时间")
    private LocalDateTime handleDt;

    @ApiModelProperty("处理方式")
    private String handleMethod;

    @ApiModelProperty("当前托盘编码")
    private String nowBucketNo;

    @ApiModelProperty(value = "删除的实际称重ID")
    private Integer actualScrapWeightInfoId;

    @ApiModelProperty("图片列表")
    private String imageUrlList;

    @ApiModelProperty("拒收原因类型")
    private String rejectReasonType;

    @ApiModelProperty(value = "是否发送邮件通知")
    private String sendMailFlag;
    
    @ApiModelProperty("拒收圖片")
    private String rejectImageList;

    @ApiModelProperty(value = "称重来源")
    private String source;

    @ApiModelProperty(value = "来源单号")
    private String sourceDocNo;

    @ApiModelProperty(value = "RFID称重位置")
    private String rfidPositionName;

    @ApiModelProperty(value = "详细原因备注（处理时填）")
    private String reason;
}
