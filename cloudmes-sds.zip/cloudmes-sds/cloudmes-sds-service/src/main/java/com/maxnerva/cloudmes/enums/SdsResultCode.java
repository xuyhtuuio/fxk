package com.maxnerva.cloudmes.enums;

/**
 * @ClassName SdsResultCode
 * @Description SDS业务响应码
 * @Author Likun
 * @Date 2024/10/24
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum SdsResultCode {

    CLASS_CODE_EXISTED_CAN_NOT_REPEAT(45000,"45000","此分类代码已存在，不允许重复维护"),
    BUCKET_NO_EXISTED_CAN_NOT_REPEAT(45001,"45001","托盘编码已存在，不允许重复维护"),
    CLASS_CODE_IS_EMPTY(45002,"45002","分类代码为空"),
    CLASS_NAME_IS_EMPTY(45003,"45003","托盘编码为空"),
    ERROR_MESSAGE_IN_LINE(45004, "45004", "第行错误信息"),
    BUCKET_NO_IS_EMPTY(45005,"45005","托盘编码为空"),
    BUCKET_WEIGHT_IS_NULL(45006,"45006","托盘重量为空"),
    FILE_NOT_NULL(45007, "45007", "请选择要导入的文件"),
    WRONG_FILE_TYPE(45008, "45008", "文件类型错误(正确类型为:xls,xlsx)"),
    EXCEL_PARSE_ERROR(45009, "45009", "excel解析异常"),
    EXCEL_IMPORT_INFORMATION_IS_EMPTY(45010, "45010", "excel导入信息为空"),
    CLASS_CODE_REPEAT(45011, "45011", "分类代码重复"),
    BUCKET_NO_REPEAT(45012, "45012", "托盘编码重复"),
    MATERIAL_CLASS_EXPORT_FAIL(45013, "45013", "物料信息导出失败"),
    STEEL_BUCKET_EXPORT_FAIL(45014, "45014", "托盘信息导出失败"),
    REDISSON_ADDRESS_IS_EMPTY(45015, "45015", "redis地址为空"),
    CONNECT_BASIC_GET_SERIAL_NUMBER(45016, "45016", "调用basic获取流水号失败"),
    PRINT_TEMPLATE_NOT_FIND(45017, "45017", "未找到可用的打印模板"),
    BUCKET_NO_LENGTH_MUST_BE_ELEVEN(45018, "45018", "钢桶类型托盘编码长度必须为11位"),
    NOT_FOUND_SCRAP_DETAIL_CONFIG(45019, "45019", "未找到报废小类对应配置"),
    NOT_FOUND_DEPARTMENT_CODE_CONFIG(45020, "45020", "托盘编码的第一位厂部不存在，请确认"),
    MUST_BE_BUCKET_TYPE_DATA(45021, "45021", "此操作只适用于钢桶类型托盘"),
    COST_CODE_EXIST_HAZARDOUS_WASTE_NAME(45022, "45022", "此费用代码下已有此危废物，无需重复添加"),
    COST_CODE_EXIST_HAZARDOUS_WASTE_NO(45023, "45023", "此费用代码下已有危废料号，无需重复添加"),
    PLAN_INFO_EXIST_CAN_NOT_REPEAT_APPLY(45024, "45024", "危废物【谁】【哪年】年度已有计划，不能重复申请"),
    PLAN_INFO_SIGNED_OR_AUDIT_CAN_NOT_DELETE(45025, "45025", "该计划单已送签或已审核，不能删除"),
    PLAN_INFO_ADD_LOG_SIGNED_OR_AUDIT_CAN_NOT_DELETE(45026, "45026", "该计划说明单已送签或已审核，不能删除"),
    PLAN_DOC_NO_IN_ADD_LOG_UN_AUDITED_CAN_NOT_REPEAT_APPLY(45027, "45027", "单号还有未签核完的说明申请单，不能重复申请说明"),
    PLAN_INFO_EXPORT_FAIL(45028, "45028", "年度计划信息导出失败"),
    PLAN_INFO_ADD_LOG_EXPORT_FAIL(45029, "45029", "年度计划说明信息导出失败"),
    HAZARDOUS_WASTE_INFO_EXPORT_FAIL(45030, "45030", "危废物信息导出失败"),
    WASTE_DOC_NOT_EXIST(45031, "45031", "单据信息不存在，请确认"),
    CAN_NOT_REPEAT_WEIGH(45032, "45032", "已称重，不能复称"),
    NET_WEIGHT_CAN_NOT_LESS_THAN_ZERO(45033, "45033", "产品净重不能小于等于0"),
    APPLY_QTY_MORE_THAN_REMAIN_QTY_IN_THIS_YEAR(45034, "45034", "申请量已超出【当前年】的可报废剩余量，不允许此单据称重"),
    REJECT_TIME_OVER_SCHEDULE_TIME(45035, "45035", "拒收超过规定时间未处理，不能继续车间称重"),
    SIGNED_CAN_NOT_CANCEL(45036, "45036", "送签后不能作废"),
    CAN_NOT_CONFORM_TO_APPLY_IN_STORE_CONDITION(45037, "45037", "已签核并已称重的贮存类单据才能申请入库"),
    NO_STORAGE_DOC_CAN_NOT_IN_STORE(45038, "45038", "此单据类型废料不能入库，请联系管理员及厂部负责人确认"),
    DOC_HAVE_BEEN_IN_STORED(45039, "45039", "此单据已入库，不能重复入库"),
    DOC_NOT_WEIGHT(45040, "45040", "单据还未称重，不允许入库"),
    UN_MAINTAIN_WEIGHT_ERROR(45041, "45041", "未维护称重误差"),
    NOT_WITHIN_ALLOWABLE_RANGE(45042, "45042", "不在容许的误差范围内，请找管理员确认是否接收"),
    DOC_HAVE_BEEN_REJECT(45043, "45043", "单号已被拒收，不能重复拒收"),
    WASTE_DOC_NOT_EXIST_CAN_NOT_REJECT(45044, "45044", "单据不存在，不能拒收"),
    SELECT_DOC_MUST_BE_A_HAZARDOUS_WASTE_MATERIAL(45045, "45045", "勾选的单据的不是一种危废物料，请检查"),
    SELECT_DOC_MUST_BE_A_DOC_TYPE(45046, "45046", "勾选的单据的类型不一致，请检查"),
    DOC_NO_NOT_OF_STORAGE_DOC_TYPE(45047, "45047", "【单号】不是贮存类单据，不能在此页面生成"),
    DOC_NO_NOT_OF_NO_STORAGE_DOC_TYPE(45048, "45048", "【单号】不是立产立清类单据，不能在此页面生成"),
    SELECT_DOC_STATUS_IN_CONSISTEN(45049, "45049", "勾选的单据的单据状态不一致，请检查"),
    DOC_HAS_NOT_BEEN_IN_STORE_CAN_NOT_GENERATE_SHIP_DOC(45050, "45050", "【单号】还未入库，不能生成出库单"),
    SCAN_DOC_IS_NOT_HAZARDOUS_NAME(45051, "45051", "扫描的单据不是【废物俗称】，请确认"),
    CAR_HAVE_BEEN_LEAVE_FACTORY(45052, "45052", "车辆已离厂,请勿重复确认"),
    HAZARDOUS_WASTE_DOC_INFO_EXPORT_FAIL(45053, "45053", "产废单信息导出失败"),
    HAZARDOUS_WASTE_DOC_REJECT_EXPORT_FAIL(45054, "45054", "入库拒收信息导出失败"),
    HAZARDOUS_WASTE_NO_STORAGE_EXPORT_FAIL(45055, "45055", "立产立清信息导出失败"),
    HAZARDOUS_WASTE_DOC_SHIP_EXPORT_FAIL(45056, "45056", "出库单导出失败"),
    HAZARDOUS_WASTE_DOC_TRANSFER_EXPORT_FAIL(45057, "45057", "转移单导出失败"),
    HAZARDOUS_WASTE_IN_STORE_DOC_EXPORT_FAIL(45058, "45058", "入库单导出失败"),
    REJECT_INFO_EXIST_MORE_THAN_APPOINT_TIME(45059, "45059", "存在大于3小时未处理的拒收记录,不允许产废车间称重"),
    SIGN_MUST_AFTER_WASTE_WEIGHT(45060, "45060", "称重完才能送签"),
    NOT_FOUND_PLAN_INFO(45061, "45061", "未找到对应的申请计划"),
    NOT_FOUND_PLAN_INFO_ADD_LOG(45062, "45062", "未找到对应的申请计划说明"),
    FLOWNET_AN_EXCEPTION_OCCURS_WHEN_INTERFACE_INVOCATION_IS_APPROVED(45063, "45063", "flownet审批完成接口调用异常"),
    SIGN_OR_AUDIT_CAN_NOT_EDIT(45064, "45064", "送签和审核状态下不能编辑"),
    ORG_CODE_IN_CONSISTEN_CAN_NOT_HANDLE(45065, "45065", "当前组织不能处理其他产废单位的单子"),
    DOC_HAVE_NOT_APPLIED_FOR_STORAGE_CAN_NOT_WEIGHT(45066, "45066", "此单据未申请入库,不能入库称重"),
    DOC_IS_NOT_STORAGE_CAN_NOT_REJECT(45067, "45067", "单据不是贮存类，不能拒收"),
    DOC_HAVE_BEEN_CREATED_SHIP_INFO_CAN_NOT_REJECT(45068, "45068", "单据已生成出库单，不能拒收"),
    LEAVE_FACTORY_CAN_NOT_UPDATE(45069, "45069", "离厂状态不能编辑"),
    WASTE_INVENTORY_EXPORT_FAIL(45070, "45070", "危废库存报表导出失败"),
    WASTE_INVENTORY_DETAIL_EXPORT_FAIL(45071, "45071", "结余库存数据导出失败"),
    WASTE_INVENTORY_OVERDUE_WARN_EXPORT_FAIL(45072, "45072", "库存超期预警导出失败"),
    FLOWNET_RETURN_AN_EXCEPTION(45073, "45073", "flownet返回异常"),
    FAILED_TO_CALL_FLOWNET(45074, "45074", "调用flownet失败"),
    SIGN_A_FAILURE_TO_SEND(45075, "45075", "送签失败"),
    THE_DOCUMENT_CHECK_FLOW_IS_NOT_CONFIGURED(45076, "45076", "未配置单据签核流");






    SdsResultCode(int code, String localCode, String msg) {
        this.code = code;
        this.localCode = localCode;
        this.msg = msg;
    }

    /**
     * 状态码
     */
    private int code;
    /**
     * 国际化编码
     */
    private String localCode;

    /**
     * 错误消息
     */
    private String msg;

    public String getMessage() {
        return this.msg;
    }

    public int getCode() {
        return code;
    }

    public String getLocalCode() {
        return localCode;
    }

    public String getMsg() {
        return msg;
    }
}
