package com.maxnerva.cloudmes.controller.scrap;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.scrap.*;
import com.maxnerva.cloudmes.models.vo.scrap.*;
import com.maxnerva.cloudmes.service.scrap.ISdsSteelInventoryPlanDetailErrLogService;
import com.maxnerva.cloudmes.service.scrap.ISdsSteelInventoryPlanDetailService;
import com.maxnerva.cloudmes.service.scrap.ISdsSteelInventoryPlanHeaderService;
import com.maxnerva.cloudmes.service.scrap.ISdsSteelInventoryPlanSummaryService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;

@Api(tags = "废料区盘点单管理")
@Slf4j
@RestController
@RequestMapping("/steelRubbishInventory")
public class SteelRubbishInventoryController {

    @Autowired
    ISdsSteelInventoryPlanHeaderService steelInventoryPlanHeaderService;

    @Autowired
    ISdsSteelInventoryPlanDetailService steelInventoryPlanDetailService;

    @Autowired
    ISdsSteelInventoryPlanDetailErrLogService steelInventoryPlanDetailErrLogService;

    @Autowired
    ISdsSteelInventoryPlanSummaryService steelInventoryPlanSummaryService;


    @ApiOperation("盘点单分页查询")
    @GetMapping("/getInventoryHeaderPageList")
    R<PageDataDTO<SteelInventoryPlanHeaderDTO>> getInventoryHeaderPageList(SteelInventoryPlanHeaderQueryVO vo){
        return R.ok(steelInventoryPlanHeaderService.selectPageList(vo, Boolean.TRUE));
    }

    @ApiOperation("盘点单导出")
    @GetMapping("/exportInventoryHeader")
    void exportInventoryHeader(SteelInventoryPlanHeaderQueryVO vo, HttpServletResponse response){
        steelInventoryPlanHeaderService.exportDetail(vo, response);
    }

    @ApiOperation("创建盘点单")
    @PostMapping("/createInventoryHeader")
    R createInventoryHeader(@RequestBody SteelInventoryPlanHeaderCreateVO vo){
        steelInventoryPlanHeaderService.create(vo);
        return R.ok();
    }

    @ApiOperation("完成盘点单")
    @PostMapping("/completeInventoryHeader")
    R completeInventoryHeader(@RequestBody SteelInventoryPlanHeaderCompleteVO vo){
        steelInventoryPlanHeaderService.complete(vo);
        return R.ok();
    }

    @ApiOperation("盘点单详情查询")
    @GetMapping("/getInventoryDetail")
    R<SteelInventoryPlanDetailDTO> getInventoryDetail(String inventoryPlanNo){
        return R.ok(steelInventoryPlanDetailService.selectOne(inventoryPlanNo));
    }

    @ApiOperation("盘点单称重提交")
    @PostMapping("/weightInventorySubmit")
    R<SteelInventoryPlanDetailSubmitDTO> weightInventorySubmit(@RequestBody SteelInventoryPlanDetailSubmitVO vo){
        return R.ok(steelInventoryPlanDetailService.weightSubmit(vo));
    }

    @ApiOperation("盘点记录分页查询")
    @GetMapping("/getInventoryErrLogPageList")
    R<PageDataDTO<SteelInventoryPlanDetailErrLogDTO>> getInventoryErrLogPageList(SteelInventoryPlanDetailErrLogQueryVO vo){
        return R.ok(steelInventoryPlanDetailErrLogService.selectPageList(vo, Boolean.TRUE));
    }

    @ApiOperation("盘点记录导出")
    @GetMapping("/exportInventoryErrLog")
    void exportInventoryErrLog(SteelInventoryPlanDetailErrLogQueryVO vo, HttpServletResponse response){
        steelInventoryPlanDetailErrLogService.exportDetail(vo, response);
    }

    @ApiOperation("待平账记录分页查询")
    @GetMapping("/getInventorySummaryList")
    R<PageDataDTO<SteelInventoryPlanSummaryDTO>> getInventorySummaryList(SteelInventoryPlanSummaryQueryVO vo){
        return R.ok(steelInventoryPlanSummaryService.selectPageList(vo, Boolean.TRUE));
    }

    @ApiOperation("待平账记录导出")
    @GetMapping("/exportInventorySummaryList")
    void exportInventorySummaryList(SteelInventoryPlanSummaryQueryVO vo, HttpServletResponse response){
        steelInventoryPlanSummaryService.exportDetail(vo, response);
    }

    @ApiOperation("平账提交")
    @PostMapping("/balanceWeight")
    R balanceWeight(@RequestBody BalanceInventoryWeightVO vo){
        steelInventoryPlanSummaryService.balanceWeight(vo);
        return R.ok();
    }
}
