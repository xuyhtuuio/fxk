package com.maxnerva.cloudmes.models.vo.excel.basic;

import com.alibaba.excel.annotation.ExcelProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @ClassName SteelBucketImportVO
 * @Description TODO
 * @Author Likun
 * @Date 2024/10/28
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("托盘信息导入VO")
@Data
public class SteelBucketImportVO {

    @ApiModelProperty(value = "托盘编码")
    @ExcelProperty(value = "托盤编码",index = 0)
    private String bucketNo;

    @ApiModelProperty(value = "托盘重量")
    @ExcelProperty(value = "托盤重量",index = 1)
    private BigDecimal bucketWeight;

    @ApiModelProperty(value = "单位")
    @ExcelProperty(value = "单位（默认KG）",index = 2)
    private String uom;

    @ApiModelProperty(value = "承重下限")
    @ExcelProperty(value = "承量下限",index = 3)
    private BigDecimal weightLow;

    @ApiModelProperty(value = "承重上限")
    @ExcelProperty(value = "承重上限",index = 4)
    private BigDecimal weightUp;

    @ApiModelProperty(value = "长")
    @ExcelProperty(value = "长",index = 5)
    private BigDecimal length;

    @ApiModelProperty(value = "宽")
    @ExcelProperty(value = "宽",index = 6)
    private BigDecimal width;

    @ApiModelProperty(value = "高")
    @ExcelProperty(value = "高",index = 7)
    private BigDecimal height;

    @ApiModelProperty(value = "容积")
    @ExcelProperty(value = "容积",index = 8)
    private BigDecimal volume;

}
