package com.maxnerva.cloudmes.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.dto.basic.DepartmentConfigDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsDepartmentConfig;

import java.util.List;

/**
 * <p>
 * 厂部配置 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2024-12-11
 */
public interface SdsDepartmentConfigMapper extends BaseMapper<SdsDepartmentConfig> {
    List<DepartmentConfigDTO> selectConfigList(String orgCode);

    List<DepartmentConfigDTO> selectConfigListNoBu();
}
