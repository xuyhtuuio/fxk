package com.maxnerva.cloudmes.service.basic;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.models.entity.basic.SdsRfidSteelBucketLink;
import com.maxnerva.cloudmes.models.vo.basic.RfidSteelBucketLinkBindVO;
import com.maxnerva.cloudmes.models.vo.basic.RfidSteelBucketLinkQueryVO;
import com.maxnerva.cloudmes.models.vo.basic.RfidSteelBucketLinkUnBindVO;

import java.util.List;

public interface ISdsRfidSteelBucketLinkService extends IService<SdsRfidSteelBucketLink> {

    List<SdsRfidSteelBucketLink> selectList(RfidSteelBucketLinkQueryVO vo);

    void bindRfidCard(RfidSteelBucketLinkBindVO vo);

    void deleteRfidCard(RfidSteelBucketLinkUnBindVO vo);
}
