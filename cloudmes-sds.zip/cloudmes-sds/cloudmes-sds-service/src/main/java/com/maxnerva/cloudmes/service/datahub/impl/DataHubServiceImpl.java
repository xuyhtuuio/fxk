package com.maxnerva.cloudmes.service.datahub.impl;

import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.json.JSONUtil;
import com.maxnerva.cloudmes.config.DataHubUrlConfig;
import com.maxnerva.cloudmes.models.vo.plan.PlanFlownetApprovalVO;
import com.maxnerva.cloudmes.service.datahub.DataHubService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName DataHubServiceImpl
 * @Description 服务节点调用类
 * @Author Likun
 * @Date 2023/3/9
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Slf4j
@Service
public class DataHubServiceImpl implements DataHubService {

    @Resource
    private DataHubUrlConfig dataHubUrlConfig;


    @Override
    public HttpResponse flownetPlanInfoApprovalCompleted(List<PlanFlownetApprovalVO> planFlownetApprovalVOList) {
        String url = dataHubUrlConfig.getFlownetPlanInfoApprovalCompletedUrl();
        return HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(planFlownetApprovalVOList))
                .execute();
    }

    @Override
    public HttpResponse flownetPlanInfoAddLogApprovalCompleted(List<PlanFlownetApprovalVO> planFlownetApprovalVOList) {
        String url = dataHubUrlConfig.getFlownetPlanInfoAddLogApprovalCompletedUrl();
        return HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(planFlownetApprovalVOList))
                .execute();
    }
}
