package com.maxnerva.cloudmes.models.vo.waste;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @ClassName WasteTransferDetailSaveVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/27
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("危废转移单明细vo")
@Data
public class WasteTransferDetailSaveVO {

    @ApiModelProperty(value = "出库单号")
    private String shipDocNo;

    @ApiModelProperty(value = "SDS危废料号")
    private String hazardousWasteNo;

    @ApiModelProperty(value = "废物俗称")
    private String hazardousWasteName;

    @ApiModelProperty(value = "危险废物")
    private String hazardousWaste;

    @ApiModelProperty(value = "废物形态")
    private String shape;

    @ApiModelProperty(value = "主要成分")
    private String rohs;

    @ApiModelProperty(value = "危险特性")
    private String toxicity;

    @ApiModelProperty(value = "废物类别")
    private String hazardousWasteCategory;

    @ApiModelProperty(value = "废物代码")
    private String hazardousWasteCode;

    @ApiModelProperty(value = "包装类型")
    private String packType;

    @ApiModelProperty(value = "包装数量")
    private BigDecimal applyQty;

    @ApiModelProperty(value = "预估转移量")
    private BigDecimal preTransferQty;
}
