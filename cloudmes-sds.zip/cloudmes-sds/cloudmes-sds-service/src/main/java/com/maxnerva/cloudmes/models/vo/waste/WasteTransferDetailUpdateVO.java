package com.maxnerva.cloudmes.models.vo.waste;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @ClassName WasteTransferDetailUpdateVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/27
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("危废转移单明细编辑vo")
@Data
public class WasteTransferDetailUpdateVO {

    @ApiModelProperty("主键id")
    private Integer id;

    @ApiModelProperty(value = "实际转移量")
    private BigDecimal actTransferQty;

    @ApiModelProperty(value = "栈板数量")
    private BigDecimal palletQty;
}
