package com.maxnerva.cloudmes.models.vo.scrap;

import com.maxnerva.cloudmes.models.vo.PageQueryVO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class SteelScrapWeightLogQueryVO extends PageQueryVO {
    @ApiModelProperty(value = "托盘编码", required = true)
    private String bucketNo;
}
