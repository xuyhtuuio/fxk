package com.maxnerva.cloudmes.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

@RefreshScope
@Component
@Data
public class ECusUrlConfig {

    @Value("${ecus.Get_Bcw.url:}")
    private String bcwUrl;

    @Value("${ecus.Get_Bcw.p_cnn:}")
    private String bcwPcnn;

}
