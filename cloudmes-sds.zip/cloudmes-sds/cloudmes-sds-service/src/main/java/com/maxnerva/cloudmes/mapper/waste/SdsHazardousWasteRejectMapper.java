package com.maxnerva.cloudmes.mapper.waste;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.dto.waste.WasteInStoreRejectDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteReject;
import com.maxnerva.cloudmes.models.vo.waste.WasteInStoreDocQueryVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteInStoreRejectQueryVO;

import java.util.List;

/**
 * <p>
 * 入库拒收处理表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2025-05-16
 */
public interface SdsHazardousWasteRejectMapper extends BaseMapper<SdsHazardousWasteReject> {

    List<WasteInStoreRejectDTO> selectWasteInStoreRejectList(WasteInStoreRejectQueryVO queryVO);

    String getRejectImageUrlList(Integer id);
    String getWasteImageUrlList(Integer id);
}
