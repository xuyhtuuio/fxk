package com.maxnerva.cloudmes.models.entity.plan;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

/**
 * <p>
 * 年度计划表
 * </p>
 *
 * @author likun
 * @since 2025-05-08
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="SdsHazardousWastePlanInfo对象", description="年度计划表")
public class SdsHazardousWastePlanInfo extends BaseEntity<SdsHazardousWastePlanInfo> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "组织")
    private String orgCode;

    @ApiModelProperty(value = "计划单号")
    private String docNo;

    @ApiModelProperty(value = "年度")
    private String planYear;

    @ApiModelProperty(value = "费用代码")
    private String costCode;

    @ApiModelProperty(value = "部门名称")
    private String depName;

    @ApiModelProperty(value = "本年度原始计划量（KG）")
    private BigDecimal originalWeight;

    @ApiModelProperty(value = "本年度当前计划总量（KG）")
    private BigDecimal planWeight;

    @ApiModelProperty(value = "本年度已用计划量（KG）")
    private BigDecimal usedWeight;

    @ApiModelProperty(value = "SDS危废料号")
    private String hazardousWasteNo;

    @ApiModelProperty(value = "单据状态")
    private String docStatus;

    @ApiModelProperty(value = "flownet返回url")
    private String flownetUrl;

    @ApiModelProperty(value = "flownet调用结果")
    private String flownetFlag;

    @ApiModelProperty(value = "flownet返回表单id")
    private String flownetFormId;

    @ApiModelProperty(value = "flownet返回描述")
    private String flownetMsg;

    @ApiModelProperty(value = "flownet审批结果")
    private String flownetApprovalResult;

    @ApiModelProperty(value = "flownet流程id")
    private String flownetProcessId;
}
