package com.maxnerva.cloudmes.service.waste.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson2.JSON;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.common.config.MinIOProperties;
import com.maxnerva.cloudmes.common.constant.BucketConstant;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.common.utils.WebContextUtil;
import com.maxnerva.cloudmes.mapper.waste.SdsHazardousWasteShipInfoMapper;
import com.maxnerva.cloudmes.mapper.waste.SdsHazardousWasteTransferDetailMapper;
import com.maxnerva.cloudmes.models.dto.waste.WasteTransferDetailDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteShipInfo;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteTransferDetail;
import com.maxnerva.cloudmes.models.vo.waste.TransferDetailUploadImageVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteTransferDetailQueryVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteTransferDetailUpdateVO;
import com.maxnerva.cloudmes.service.waste.ISdsHazardousWasteTransferDetailService;
import com.maxnerva.cloudmes.system.feign.IUploadFileClient;
import com.maxnerva.cloudmes.system.models.dto.UploadFileRespDTO;
import com.maxnerva.cloudmes.system.models.vo.FileUploadVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * 危废转移单明细 服务实现类
 * </p>
 *
 * @author likun
 * @since 2025-05-27
 */
@Slf4j
@Service
public class SdsHazardousWasteTransferDetailServiceImpl extends ServiceImpl<SdsHazardousWasteTransferDetailMapper, SdsHazardousWasteTransferDetail> implements ISdsHazardousWasteTransferDetailService {

    @Resource
    private SdsHazardousWasteShipInfoMapper sdsHazardousWasteShipInfoMapper;

    @Resource
    private IUploadFileClient uploadFileClient;

    @Resource
    private MinIOProperties minIOProperties;

    @Override
    public List<WasteTransferDetailDTO> selectDetailList(WasteTransferDetailQueryVO queryVO) {
        return baseMapper.selectTransferDetailList(queryVO);
    }

    @Override
    public List<String> selectImageUrlList(Integer id) {
        String imageUrl = baseMapper.selectImageUrl(id);
        List<String> imageUrlList = CollUtil.newArrayList();
        if (StrUtil.isNotEmpty(imageUrl)) {
            List<String> imageList = JSON.parseArray(imageUrl).toList(String.class);
            imageUrlList = imageList.stream().map(link -> minIOProperties.getFileAddr(BucketConstant.CLOUD_SAAS, link))
                    .collect(Collectors.toList());
        }
        return imageUrlList;
    }

    @Override
    public void uploadImage(TransferDetailUploadImageVO vo) {
        Integer id = vo.getId();
        FileUploadVO fileUploadVO = new FileUploadVO();
        fileUploadVO.setBucketName("cloudsaas");
        fileUploadVO.setFiles(vo.getFiles());
        R<List<UploadFileRespDTO>> result = uploadFileClient.uploadBatch(fileUploadVO);
        List<UploadFileRespDTO> uploadFileRespDTOList = result.getData();
        List<String> urlList = uploadFileRespDTOList.stream().map(UploadFileRespDTO::getName)
                .collect(Collectors.toList());
        baseMapper.update(null, Wrappers.<SdsHazardousWasteTransferDetail>lambdaUpdate()
                .setSql("image_url_list = image_url_list")
                .eq(SdsHazardousWasteTransferDetail::getId, vo.getId()));
        SdsHazardousWasteTransferDetail sdsHazardousWasteTransferDetail = baseMapper.selectById(id);
        String imageUrlListStr = sdsHazardousWasteTransferDetail.getImageUrlList();
        List<String> imageUrlList;
        if (StrUtil.isBlank(imageUrlListStr)) {
            imageUrlList = urlList;
        } else {
            imageUrlList = JSON.parseArray(imageUrlListStr, String.class);
            imageUrlList.addAll(urlList);
        }
        baseMapper.update(null, Wrappers.<SdsHazardousWasteTransferDetail>lambdaUpdate()
                .set(SdsHazardousWasteTransferDetail::getImageUrlList, JSON.toJSONString(imageUrlList))
                .set(SdsHazardousWasteTransferDetail::getLastEditor, WebContextUtil.getCurrentStaffCode())
                .set(SdsHazardousWasteTransferDetail::getLastEditedDt, LocalDateTime.now())
                .eq(SdsHazardousWasteTransferDetail::getId, id));
    }

    @Override
    public void updateDetail(WasteTransferDetailUpdateVO updateVO) {
        baseMapper.update(null, Wrappers.<SdsHazardousWasteTransferDetail>lambdaUpdate()
                .eq(SdsHazardousWasteTransferDetail::getId, updateVO.getId())
                .set(SdsHazardousWasteTransferDetail::getActTransferQty, updateVO.getActTransferQty())
                .set(SdsHazardousWasteTransferDetail::getPalletQty, updateVO.getPalletQty())
                .set(SdsHazardousWasteTransferDetail::getLastEditor, WebContextUtil.getCurrentStaffCode())
                .set(SdsHazardousWasteTransferDetail::getLastEditedDt, LocalDateTime.now()));
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteDetail(Integer id) {
        SdsHazardousWasteTransferDetail sdsHazardousWasteTransferDetail = baseMapper.selectById(id);
        String transferDocNo = sdsHazardousWasteTransferDetail.getTransferDocNo();
        String shipDocNo = sdsHazardousWasteTransferDetail.getShipDocNo();
        //解除绑定
        baseMapper.deleteById(id);
        //解除转移单号与出库单号的绑定
        sdsHazardousWasteShipInfoMapper.update(null, Wrappers.<SdsHazardousWasteShipInfo>lambdaUpdate()
                .eq(SdsHazardousWasteShipInfo::getDocNo, shipDocNo)
                .eq(SdsHazardousWasteShipInfo::getTransferDocNo, transferDocNo)
                .set(SdsHazardousWasteShipInfo::getTransferDocNo, StrUtil.EMPTY)
                .set(SdsHazardousWasteShipInfo::getLastEditor, WebContextUtil.getCurrentStaffCode())
                .set(SdsHazardousWasteShipInfo::getLastEditedDt, LocalDateTime.now()));
    }
}
