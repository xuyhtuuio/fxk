package com.maxnerva.cloudmes.service.scrap.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONConfig;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.models.dto.DatasourceKeyDTO;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.DSThreadLocalUtil;
import com.maxnerva.cloudmes.common.utils.JsonUtil;
import com.maxnerva.cloudmes.common.utils.RedisUtil;
import com.maxnerva.cloudmes.common.utils.WebContextUtil;
import com.maxnerva.cloudmes.component.RFIDSocketClient;
import com.maxnerva.cloudmes.config.RFIDConfig;
import com.maxnerva.cloudmes.enums.SteelIssueType;
import com.maxnerva.cloudmes.mapper.basic.SdsSteelReturnConfigMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsRfidSteelConfigMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsRfidSteelIssueLogMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelScrapWeightInfoMapper;
import com.maxnerva.cloudmes.models.dto.scrap.RfidSteelIssueLogDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelRfidStatusDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsRfidSteelBucketLink;
import com.maxnerva.cloudmes.models.entity.basic.SdsSteelReturnConfig;
import com.maxnerva.cloudmes.models.entity.scrap.SdsRfidSteelConfig;
import com.maxnerva.cloudmes.models.entity.scrap.SdsRfidSteelIssueLog;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapWeightInfo;
import com.maxnerva.cloudmes.models.vo.scrap.HandleSteelIssueVO;
import com.maxnerva.cloudmes.models.vo.scrap.RfidSteelIssueLogQueryVO;
import com.maxnerva.cloudmes.service.scrap.ISteelRfidAsyncService;
import com.maxnerva.cloudmes.service.scrap.ISteelRfidService;
import com.maxnerva.cloudmes.service.scrap.ISteelScrapWeightService;
import com.maxnerva.cloudmes.service.scrap.impl.SteelScrapWeightService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @ClassName SteelRfidService
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2024/12/23 下午 01:33
 * @Version 1.0
 **/
@Service
@Slf4j
@EnableAsync
public class SteelRfidService implements ISteelRfidService {
    @Autowired
    RFIDConfig rfidConfig;

    @Autowired
    ISteelScrapWeightService steelScrapWeightService;

    @Autowired
    SdsSteelScrapWeightInfoMapper steelScrapWeightInfoMapper;

    @Autowired
    SdsSteelReturnConfigMapper sdsSteelReturnConfigMapper;

    @Autowired
    SdsRfidSteelConfigMapper rfidSteelConfigMapper;

    @Autowired
    SdsRfidSteelIssueLogMapper rfidSteelIssueLogMapper;

    @Autowired
    SteelScrapWeightService IsteelScrapWeightService;

    @Autowired
    RedisUtil redisUtil;

    @Autowired
    ISteelRfidAsyncService steelRfidAsyncService;

    @Override
    public Boolean getSocketPrivilege() {
        String redisUUID = (String) redisUtil.get(rfidConfig.getSOCKET_PRIVILEGE_UUID_KEY());
        // 锁在当前服务中
        if (rfidConfig.getUuid().equals(redisUUID)) {
            // 续约锁30s
            redisUtil.expire(rfidConfig.getSOCKET_PRIVILEGE_UUID_KEY(), 30);
            return Boolean.TRUE;
        } else if (StrUtil.isBlank(redisUUID)) {
            // 锁不在任何服务中
            Boolean hasLock = redisUtil.set(rfidConfig.getGET_SOCKET_PRIVILEGE_KEY(), "Y", 30);
            if (BooleanUtil.isTrue(hasLock)) {
                redisUtil.set(rfidConfig.getSOCKET_PRIVILEGE_UUID_KEY(), rfidConfig.getUuid(), 30);
                return Boolean.TRUE;
            }
        }
        return Boolean.FALSE;
    }

    @Override
    public Boolean hasSocketPrivilege() {
        String redisUUID = (String) redisUtil.get(rfidConfig.getSOCKET_PRIVILEGE_UUID_KEY());
        return rfidConfig.getUuid().equals(redisUUID);
    }

    @Override
    public void reConnect() {
        List<SdsRfidSteelConfig> rfidSocketConfigDTOList = rfidConfig.getRfidSocketConfigDTOList();
        Set<String> rfidSocketConfigKeySet = rfidSocketConfigDTOList.stream()
                .map(item -> StrUtil.concat(true, item.getHost(), item.getPort()))
                .collect(Collectors.toSet());

        Map<String, RFIDSocketClient> rfidSocketClientMap = rfidConfig.getRfidSocketClientMap();

        List<String> willDelKeyList = ListUtil.toList();
        rfidSocketClientMap.keySet().stream().forEach(key -> {

            if (!rfidSocketConfigKeySet.contains(key)){
                willDelKeyList.add(key);
                return;
            }
            if (BooleanUtil.isFalse(rfidSocketClientMap.get(key).getIsConnected())) {
                willDelKeyList.add(key);
            }

        });

        if (CollUtil.isNotEmpty(willDelKeyList)) {
            willDelKeyList.forEach(key -> {
                rfidSocketClientMap.get(key).destroy();
                rfidSocketClientMap.remove(key);
            });
        }

        rfidSocketConfigDTOList.forEach(item -> {
            String host = item.getHost();
            String port = item.getPort();
            String positionName = item.getPositionName();
            String key = StrUtil.concat(true, host, port);
            if (!rfidSocketClientMap.containsKey(key)){
                RFIDSocketClient rfidSocketClient = new RFIDSocketClient(host, port, positionName, rfidConfig);
                if (rfidSocketClient.openClient()) {
                    rfidSocketClientMap.put(key, rfidSocketClient);
                }
            }
        });
    }

    @Override
    public void disconnectAllConnect() {
        Map<String, RFIDSocketClient> rfidSocketClientMap = rfidConfig.getRfidSocketClientMap();
        rfidSocketClientMap.values().forEach(rfidSocketClient -> {
            rfidSocketClient.destroy();
        });
        rfidSocketClientMap.clear();
    }

    @Override
    public void notifyWarning() {
        Map<String, Set<String>> rfidCardMap = rfidConfig.getRfidCardMap();
        Set<String> rfidAsyncSymbolSet = rfidConfig.getRfidAsyncSymbolSet();
        rfidCardMap.keySet().forEach((String key) -> {
            // 正在执行中，防止重复执行
            if (rfidAsyncSymbolSet.contains(key)) {
                return;
            }
            // async 异步执行，只打印，不捕获异常。
            steelRfidAsyncService.dealWithRFID(key);
        });
    }

    @Override
    public void syncCardInfo() {
        List<SdsRfidSteelBucketLink> links = steelScrapWeightService.getRfidBucketNoLink();
        rfidConfig.getCardLinkMap().clear();
        links.forEach(item -> {
            rfidConfig.getCardLinkMap().put(item.getRfidNo(), item.getBucketNo());
        });
        List<SdsRfidSteelConfig> rfidConfigList = rfidSteelConfigMapper.selectList(Wrappers.<SdsRfidSteelConfig>lambdaQuery());
        rfidConfig.getRfidSocketConfigDTOList().clear();
        rfidConfig.getRfidSocketConfigDTOList().addAll(rfidConfigList);
    }

    @Override
    public void reportRfidStatus() {
        List<SdsRfidSteelConfig> rfidConfigList = rfidConfig.getRfidSocketConfigDTOList();
        Map<String, RFIDSocketClient> rfidSocketClientMap = rfidConfig.getRfidSocketClientMap();
        List<SteelRfidStatusDTO> statusDTOList = ListUtil.toList();

        rfidConfigList.forEach(rfidConfig -> {
            String key = StrUtil.concat(true, rfidConfig.getHost(), rfidConfig.getPort());
            RFIDSocketClient rfidSocketClient = rfidSocketClientMap.get(key);
            SteelRfidStatusDTO dto = new SteelRfidStatusDTO();
            dto.setHost(rfidConfig.getHost());
            dto.setPort(rfidConfig.getPort());
            dto.setPositionName(rfidConfig.getPositionName());
            dto.setConnectStatus("N");
            if (ObjectUtil.isNotNull(rfidSocketClient)) {
                dto.setLastConnectDateTime(rfidSocketClient.getLastConnectDateTime());
                dto.setConnectStatus(BooleanUtil.isTrue(rfidSocketClient.getIsConnected()) ? "Y" : "N");
            }
            statusDTOList.add(dto);
        });
        JSONConfig jsonConfig = JSONConfig.create();
        jsonConfig.setDateFormat("yyyy-MM-dd HH:mm:ss");
        redisUtil.set(rfidConfig.getRFID_STATUS_KEY(), JSONUtil.toJsonStr(statusDTOList, jsonConfig), 120);
    }

    private void turnReturnStatus(String currentStatus, String currentBucketNo) {
        int y = sdsSteelReturnConfigMapper.update(null, Wrappers.<SdsSteelReturnConfig>lambdaUpdate()
                .set(SdsSteelReturnConfig::getIsReturn, currentStatus)
                .eq(SdsSteelReturnConfig::getBucketNo, currentBucketNo)

        );
        log.info("当前更新数量为: {} ---------------------", y);
    }

    @Override
    public PageDataDTO<RfidSteelIssueLogDTO> getSteelIssuePageList(RfidSteelIssueLogQueryVO vo, Boolean isPage) {
        Page page = new Page();
        if (BooleanUtil.isTrue(isPage)){
            page = PageHelper.startPage(vo.getPageIndex(), vo.getPageSize());
        }
        List<SdsRfidSteelIssueLog> rfidSteelIssueLogList = rfidSteelIssueLogMapper.selectList(Wrappers.<SdsRfidSteelIssueLog>lambdaQuery()
            .eq(StrUtil.isNotBlank(vo.getPositionName()), SdsRfidSteelIssueLog::getPositionName, vo.getPositionName())
                .orderByDesc(SdsRfidSteelIssueLog::getId)
        );
        List<RfidSteelIssueLogDTO> result = ListUtil.toList();
        rfidSteelIssueLogList.forEach(item -> {
            RfidSteelIssueLogDTO dto = new RfidSteelIssueLogDTO();
            BeanUtil.copyProperties(item, dto);
            result.add(dto);
        });
        return new PageDataDTO(page.getTotal(), result);
    }

    @Override
    public void handleSteelIssue(HandleSteelIssueVO vo) {
        rfidSteelIssueLogMapper.update(null, Wrappers.<SdsRfidSteelIssueLog>lambdaUpdate()
                .set(SdsRfidSteelIssueLog::getHandleDt, LocalDateTime.now())
                .set(SdsRfidSteelIssueLog::getHandleFlag, "Y")
                .set(SdsRfidSteelIssueLog::getHandleEmpNo, vo.getHandleEmpNo())
                .eq(SdsRfidSteelIssueLog::getId, vo.getId())
        );
    }

    @Override
    public List<SteelRfidStatusDTO> getRfidStatus() {
        String rfidStatusStr = (String) redisUtil.get(rfidConfig.getRFID_STATUS_KEY());
        if (StrUtil.isNotBlank(rfidStatusStr)) {
            List<SteelRfidStatusDTO> rfidStatusDTOList = JSONUtil.toList(rfidStatusStr, SteelRfidStatusDTO.class);
            return rfidStatusDTOList;
        }
        return ListUtil.toList();
    }

    @Override
    public List<SdsRfidSteelConfig> getAllRfidConfig() {
        List<SdsRfidSteelConfig> list = rfidSteelConfigMapper.selectList(Wrappers.<SdsRfidSteelConfig>lambdaQuery());
        return list;
    }
}
