package com.maxnerva.cloudmes.models.vo.waste;

import com.maxnerva.cloudmes.models.vo.CommonRequestVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @ClassName ApplyShipScanVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/26
 * @Version 1.0
 * @Since JDK 1.8
 **/
@EqualsAndHashCode(callSuper = true)
@ApiModel(value = "立产立清申请出库扫描vo")
@Data
public class NoStorageApplyShipScanVO extends CommonRequestVO {

    @ApiModelProperty(value = "废物俗称")
    private String hazardousWasteName;

    @ApiModelProperty(value = "危废物信息表的SDS料号")
    private String hazardousWasteNo;

    @ApiModelProperty(value = "单据号")
    private String docNo;
}
