package com.maxnerva.cloudmes.controller.scrap;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.scrap.*;
import com.maxnerva.cloudmes.models.vo.scrap.*;
import com.maxnerva.cloudmes.service.basic.impl.SdsFileDownloadLogService;
import com.maxnerva.cloudmes.service.scrap.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.annotations.Delete;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Api(tags = "固废品缴款单管理")
@Slf4j
@RestController
@RequestMapping("/steelPaymentOrder")
public class SteelPaymentOrderController {

    @Autowired
    ISteelPaymentOrderService steelPaymentOrderService;

    @Autowired
    ISdsSteelPaymentHeaderService steelPaymentHeaderService;

    @Autowired
    ISdsSteelPaymentSplitInfoService steelPaymentSplitInfoService;

    @Autowired
    ISdsSteelPaymentSalesSummaryService steelPaymentSalesSummaryService;

    @Autowired
    SdsFileDownloadLogService sdsFileDownloadLogService;




    @ApiOperation("待生成缴款单明细分页查询")
    @GetMapping("/shipHeaderPageList")
    R<PageDataDTO<SteelScrapShipHeaderPaymentDTO>> shipHeaderPageList(SteelScrapShipHeaderPaymentQueryVO vo){
        return R.ok(steelPaymentOrderService.shipHeaderPageList(vo, Boolean.TRUE));
    }

    @ApiOperation("待生成缴款单明细导出")
    @GetMapping("/exportShipHeaderPageList")
    void exportShipHeaderPageList(SteelScrapShipHeaderPaymentQueryVO vo, HttpServletResponse response){
        steelPaymentOrderService.exportShipHeaderPageList(vo, response);
    }

    @ApiOperation("根据出货单生成缴款单明细")
    @PostMapping("/createPaymentOrderByShipHeader")
    R<String> createPaymentOrderByShipHeader(@RequestBody SteelScrapShipHeaderPaymentQueryVO vo){
        String paymentDocNo = steelPaymentOrderService.createPaymentOrderByShipHeader(vo);
        R r = R.ok();
        r.setData(paymentDocNo);
        return r;
    }

    @ApiOperation("导出缴款通知单Excel")
    @GetMapping("/exportPaymentOrderExcel")
    void exportPaymentOrderExcel(PaymentOrderExcelExportVO vo, HttpServletResponse response){
        steelPaymentOrderService.exportPaymentOrderExcel(vo, response);
    }

    @ApiOperation("缴款通知单分页查询")
    @GetMapping("/paymentHeaderPageList")
    R<PageDataDTO<SteelPaymentHeaderDTO>> paymentHeaderPageList(SteelPaymentHeaderQueryVO vo){
        return R.ok(steelPaymentHeaderService.selectPageList(vo, Boolean.TRUE));
    }

    @ApiOperation("缴款通知单导出")
    @GetMapping("/exportPaymentHeaderPageList")
    void exportPaymentHeaderPageList(SteelPaymentHeaderQueryVO vo, HttpServletResponse response){
        steelPaymentHeaderService.exportDetail(vo, response);
    }

    @ApiOperation("分账信息分页查询")
    @GetMapping("/paymentSplitInfoPageList")
    R<PageDataDTO<SteelPaymentSplitInfoDTO>> paymentSplitInfoPageList(SteelPaymentSplitInfoQueryVO vo){
        return R.ok(steelPaymentSplitInfoService.selectPageList(vo, Boolean.TRUE));
    }

    @ApiOperation("分账信息导出")
    @GetMapping("/exportPaymentSplitInfoPageList")
    void exportPaymentSplitInfoPageList(SteelPaymentSplitInfoQueryVO vo, HttpServletResponse response){
        steelPaymentSplitInfoService.exportDetail(vo, response);
    }

    @ApiOperation("缴款单关联出库明细分页查询")
    @GetMapping("/shipHeaderByPaymentPageList")
    R<PageDataDTO<SteelScrapShipHeaderByPaymentDTO>> shipHeaderByPaymentPageList(SteelScrapShipHeaderByPaymentQueryVO vo){
        return R.ok(steelPaymentOrderService.shipHeaderByPaymentPageList(vo, Boolean.TRUE));
    }

    @ApiOperation("缴款单关联出库明细导出")
    @GetMapping("/exportShipHeaderByPaymentPageList")
    void exportShipHeaderByPaymentPageList(SteelScrapShipHeaderByPaymentQueryVO vo, HttpServletResponse response){
        steelPaymentOrderService.exportShipHeaderByPaymentPageList(vo, response);
    }

    @ApiOperation("废料销售汇总表")
    @GetMapping("/paymentSalesSummary")
    R<List<SteelPaymentSalesSummaryDTO>> paymentSalesSummary(String paymentDocNo){
        return R.ok(steelPaymentSalesSummaryService.selectList(paymentDocNo));
    }

    @ApiOperation("废料销售汇总表导出")
    @GetMapping("/exportPaymentSalesSummary")
    void exportPaymentSalesSummary(String paymentDocNo, HttpServletResponse response){
        steelPaymentSalesSummaryService.exportDetail(paymentDocNo, response);
    }

    @ApiOperation("缴款单文件上传")
    @PostMapping("/upload")
    R<Void> upload(PaymentFileUploadVO paymentFileUploadVO){
        steelPaymentOrderService.uploadFile(paymentFileUploadVO);
        return R.ok();
    }

    @ApiOperation("缴款单文件刪除")
    @PostMapping("/deleteFile")
    R<List<PaymentUploadDTO>> deleteFile(@RequestBody DeleteFileVO deleteFileVO){
        return R.ok(steelPaymentOrderService.deleteFile(deleteFileVO));
    }
}
