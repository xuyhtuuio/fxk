package com.maxnerva.cloudmes.service.scrap;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.models.dto.scrap.InventoryReportDTO;
import com.maxnerva.cloudmes.models.dto.scrap.RubbishInStockDTO;
import com.maxnerva.cloudmes.models.dto.scrap.RubbishOutStockDTO;
import com.maxnerva.cloudmes.models.dto.scrap.RubbishStockSummaryDTO;
import com.maxnerva.cloudmes.models.vo.excel.ExcelMergeCellValue;
import com.maxnerva.cloudmes.models.vo.scrap.RubbishInStockQueryVO;
import com.maxnerva.cloudmes.models.vo.scrap.RubbishOutStockQueryVO;
import com.maxnerva.cloudmes.models.vo.scrap.RubbishStockSummaryQueryVO;
import com.maxnerva.cloudmes.models.vo.scrap.SteelScrapInventoryReportQueryVO;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

public interface ISteelScrapReportService {

    PageDataDTO<RubbishInStockDTO> getRubbishInStock(RubbishInStockQueryVO vo, Boolean isPage);

    void exportRubbishInStock(RubbishInStockQueryVO vo, HttpServletResponse response);

    PageDataDTO<RubbishOutStockDTO> getRubbishOutStock(RubbishOutStockQueryVO vo, Boolean isPage);

    void exportRubbishOutStock(RubbishOutStockQueryVO vo, HttpServletResponse response);

    PageDataDTO<RubbishStockSummaryDTO> getRubbishStockSummary(RubbishStockSummaryQueryVO vo, Boolean isPage);

    void exportRubbishStockSummary(RubbishStockSummaryQueryVO vo, HttpServletResponse response);

    InventoryReportDTO selectInventoryReport(SteelScrapInventoryReportQueryVO vo);

    void exportInventoryReport(SteelScrapInventoryReportQueryVO vo, HttpServletResponse response);

    void archiveInventoryReport(SteelScrapInventoryReportQueryVO vo);
}
