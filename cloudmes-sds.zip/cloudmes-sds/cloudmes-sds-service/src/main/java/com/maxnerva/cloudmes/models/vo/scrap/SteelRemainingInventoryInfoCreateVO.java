package com.maxnerva.cloudmes.models.vo.scrap;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class SteelRemainingInventoryInfoCreateVO {

    @ApiModelProperty(value = "年份yyyy", required = true)
    private String year;

    @ApiModelProperty(value = "月份MM", required = true)
    private String month;

    @ApiModelProperty(value = "报废类别", required = true)
    private String scrapDetailClass;

    @ApiModelProperty(value = "剩余重量", required = true)
    private BigDecimal remainWeight;

}
