package com.maxnerva.cloudmes.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.dto.basic.SteelBucketDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsSteelBucketInfo;
import com.maxnerva.cloudmes.models.vo.basic.SteelBucketQueryVO;

import java.util.List;

/**
 * <p>
 * 托盘信息表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2024-10-28
 */
public interface SdsSteelBucketInfoMapper extends BaseMapper<SdsSteelBucketInfo> {

    List<SteelBucketDTO> selectSteelBucketList(SteelBucketQueryVO queryVO);
}
