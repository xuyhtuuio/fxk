package com.maxnerva.cloudmes.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.dto.basic.HwDepartmentPartRelationDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsHwDepartmentPartRelation;
import com.maxnerva.cloudmes.models.vo.basic.HwDepartmentPartRelationQueryVO;

import java.util.List;

/**
 * <p>
 * 部门对应危废种类 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2025-05-06
 */
public interface SdsHwDepartmentPartRelationMapper extends BaseMapper<SdsHwDepartmentPartRelation> {

    List<HwDepartmentPartRelationDTO> selectDepartmentPartRelationList(HwDepartmentPartRelationQueryVO queryVO);

}
