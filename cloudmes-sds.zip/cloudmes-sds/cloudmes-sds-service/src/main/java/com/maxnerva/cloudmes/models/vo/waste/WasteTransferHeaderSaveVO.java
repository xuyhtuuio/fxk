package com.maxnerva.cloudmes.models.vo.waste;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @ClassName WasteTransferHeaderSaveVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/27
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("危废转移单单头新增vo")
@Data
public class WasteTransferHeaderSaveVO {

    @ApiModelProperty(value = "单据类型")
    private String docType;

    @ApiModelProperty(value = "车牌号")
    private String carNumber;

    @ApiModelProperty(value = "移出单位")
    private String moveOutDept;

    @ApiModelProperty(value = "移出单位地址")
    private String moveOutAddress;

    @ApiModelProperty(value = "移出单位联系人")
    private String moveOutContact;

    @ApiModelProperty(value = "移出单位联系电话")
    private String moveOutPhone;

    @ApiModelProperty(value = "移出单位紧急联系电话")
    private String moveOutEmergencyContact;

    @ApiModelProperty(value = "接受单位")
    private String moveInDept;

    @ApiModelProperty(value = "接受单位地址")
    private String moveInAddress;

    @ApiModelProperty(value = "接受单位许可证号")
    private String moveInLicense;

    @ApiModelProperty(value = "接受单位联系人")
    private String moveInContact;

    @ApiModelProperty(value = "接受单位联系电话")
    private String moveInPhone;

    @ApiModelProperty(value = "运输单位")
    private String transportDept;

    @ApiModelProperty(value = "运输单位联系人")
    private String transportContact;

    @ApiModelProperty(value = "运输单位电话")
    private String transportPhone;

    @ApiModelProperty(value = "运输单位地址")
    private String transportAddress;

    @ApiModelProperty(value = "运输方式")
    private String transportMode;

    @ApiModelProperty(value = "空车重量")
    private BigDecimal carWeight;

    @ApiModelProperty(value = "整车重量")
    private BigDecimal fullCarWeight;

}
