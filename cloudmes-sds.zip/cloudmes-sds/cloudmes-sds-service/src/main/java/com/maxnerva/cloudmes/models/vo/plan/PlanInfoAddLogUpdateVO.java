package com.maxnerva.cloudmes.models.vo.plan;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @ClassName PlanInfoAddLogUpdateVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/12
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("年度计划说明信息修改vo")
@Data
public class PlanInfoAddLogUpdateVO {

    @ApiModelProperty("主键id")
    private Integer id;

    @ApiModelProperty(value = "增加量（KG）")
    private BigDecimal planAddWeight;
}
