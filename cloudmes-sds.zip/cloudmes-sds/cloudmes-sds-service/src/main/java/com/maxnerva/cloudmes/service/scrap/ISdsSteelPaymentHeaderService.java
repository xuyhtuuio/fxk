package com.maxnerva.cloudmes.service.scrap;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelPaymentHeaderDTO;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelPaymentHeader;
import com.maxnerva.cloudmes.models.vo.scrap.SteelPaymentHeaderQueryVO;

import javax.servlet.http.HttpServletResponse;

public interface ISdsSteelPaymentHeaderService extends IService<SdsSteelPaymentHeader> {

    PageDataDTO<SteelPaymentHeaderDTO> selectPageList(SteelPaymentHeaderQueryVO vo, Boolean isPage);

    void exportDetail(SteelPaymentHeaderQueryVO vo, HttpServletResponse response);
}
