package com.maxnerva.cloudmes.component;

import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.StrUtil;
import com.maxnerva.cloudmes.config.RFIDConfig;
import com.maxnerva.cloudmes.models.entity.scrap.SdsRfidSteelConfig;
import com.maxnerva.cloudmes.service.scrap.ISteelRfidService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@ConditionalOnProperty(value = "model.name", havingValue = "sds")
@Component
@EnableScheduling
@Slf4j
public class RFIDSchedule {

    @Autowired
    RFIDConfig rfidConfig;

    @Autowired
    ISteelRfidService rfidService;

    @Scheduled(initialDelay = 1000, fixedDelay = 10000)
    void lock() {
        if (BooleanUtil.isFalse(rfidService.getSocketPrivilege())) {
            rfidService.disconnectAllConnect();
            rfidConfig.getRfidCardMap().clear();
        }
    }

    @Scheduled(initialDelay = 10000, fixedDelay = 20000)
    void connect() {
        if (BooleanUtil.isTrue(rfidService.hasSocketPrivilege())) {
            rfidService.reConnect();
        }
    }

    @Scheduled(initialDelay = 1000, fixedDelay = 120000)
    void syncCardInfo() {
        DataSourceUtil.setSdsDataSource();
        rfidService.syncCardInfo();
    }

    @Scheduled(initialDelay = 20000, fixedDelay = 1000)
    void preventLeave() {
        rfidService.notifyWarning();
    }

    @Scheduled(initialDelay = 60000, fixedDelay = 30000)
    void reportRfidStatus() {
        if (BooleanUtil.isTrue(rfidService.hasSocketPrivilege())) {
            rfidService.reportRfidStatus();
        }
    }
}

