package com.maxnerva.cloudmes.service.waste.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.mapper.waste.SdsHazardousMoveInConfigMapper;
import com.maxnerva.cloudmes.models.dto.waste.WasteMoveInConfigDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousMoveInConfig;
import com.maxnerva.cloudmes.service.waste.ISdsHazardousMoveInConfigService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 危废接受单位配置档 服务实现类
 * </p>
 *
 * @author likun
 * @since 2025-05-27
 */
@Slf4j
@Service
public class SdsHazardousMoveInConfigServiceImpl extends ServiceImpl<SdsHazardousMoveInConfigMapper, SdsHazardousMoveInConfig> implements ISdsHazardousMoveInConfigService {

    @Override
    public List<WasteMoveInConfigDTO> selectMoveInConfigList() {
        return baseMapper.selectMoveInConfigList();
    }
}
