package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName PrintTypeEnum
 * @Description TODO
 * @Author Likun
 * @Date 2024/11/5
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum PrintTypeEnum {

    BUCKET_PALLET("BUCKET_PALLET", "托盘编码信息列印"),
    SCRAP_SHIPMENT_APPLY("SCRAP_SHIPMENT_APPLY", "废料装运过磅申请单"),
    HW_DOC_BUCKET("HW_DOC_BUCKET", "产废列印");


    private String dictCode;

    private String dictName;

    PrintTypeEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (PrintTypeEnum printTypeEnum : values()) {
            if (printTypeEnum.getDictCode().equals(dictCode)) {
                return printTypeEnum.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

    /**
     * 提前判断，用于解决
     * Case中出现的Constant expression required
     *
     * @param dictCode 值
     * @return bucketTypeEnum
     */
    public static PrintTypeEnum getByValue(String dictCode) {
        for (PrintTypeEnum printTypeEnum : values()) {
            if (printTypeEnum.getDictCode().equals(dictCode)) {
                return printTypeEnum;
            }
        }
        return null;
    }
}
