package com.maxnerva.cloudmes.models.dto.scrap;

import cn.hutool.core.annotation.Alias;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class BcwInfoDTO {
    @ApiModelProperty(value = "申报单号")
    private String BCW01;

    @ApiModelProperty(value = "厂商")
    private String BCW37;

    @ApiModelProperty(value = "废料名称")
    private String BCW07;

    @ApiModelProperty(value = "关务代码")
    private String BCW03;

    @ApiModelProperty(value = "废料料号")
    private String BCW06;

    @ApiModelProperty(value = "废料类别")
    private String KXA03;

    @ApiModelProperty(value = "区域代码")
    private String KFB04;

    @ApiModelProperty(value = "车牌")
    private String BCW051;

    @ApiModelProperty(value = "司机")
    private String BCW052;

    @ApiModelProperty(value = "申请人")
    @Alias("BCW50_x007C__x007C_A.WZX02")
    private String BCW50;

    @ApiModelProperty(value = "申请时间")
    private String BCW02;

    @ApiModelProperty(value = "出货法人")
    private String KWY02;

    @ApiModelProperty(value = "归属单位")
    private String BCW10;

    @ApiModelProperty(value = "计量单位")
    private String GFE02;

    @ApiModelProperty(value = "备案号")
    private String BCW29;

    @ApiModelProperty(value = "关锁号")
    private String KFA06;

    @ApiModelProperty(value = "车况-工具箱")
    private String KFA18;

    @ApiModelProperty(value = "车况-油箱")
    private String KFA15;

    @ApiModelProperty(value = "车况-钢圈")
    private String KFA19;

    @ApiModelProperty(value = "车况-水箱")
    private String KFA16;

    @ApiModelProperty(value = "车况-备胎")
    private String KFA17;

    @ApiModelProperty(value = "空车重量")
    private String BCW11;

    @ApiModelProperty(value = "进厂时间 or 空车称重时间")
    private String BCW021;

    @ApiModelProperty(value = "空车称重人")
    @Alias(value = "BCW39_x007C__x007C_B.WZX02")
    private String BCW39;

    @ApiModelProperty(value = "單位")
    private String BCW16;

    @ApiModelProperty(value = "整车重量")
    private String BCW12;

    @ApiModelProperty(value = "出厂时间 or 整車称重时间")
    private String BCW023;

    @ApiModelProperty(value = "整車称重人")
    @Alias(value = "BCW40_x007C__x007C_C.WZX02")
    private String BCW40;

    @ApiModelProperty(value = "厂商代码")
    private String BCW04;

    @ApiModelProperty(value = "废料单价")
    private String BCW17;

    @ApiModelProperty(value = "净重")
    private String BCW14;
}
