package com.maxnerva.cloudmes.service.basic;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.models.entity.basic.SdsSteelMfgConfig;

import java.util.List;

public interface ISdsSteelMfgConfigService extends IService<SdsSteelMfgConfig> {

    List<SdsSteelMfgConfig> selectConfigList();

}
