package com.maxnerva.cloudmes.mapstruct;


import org.mapstruct.MappingTarget;

import java.util.List;

/**
 * @param <Vo>
 * @param <Entity>
 * @param <Dto>
 * @author likun
 * @version 1.0
 * @since jdk 8
 */
public interface BaseTuple3Mapper<Vo, Entity, Dto> {
    /**
     * switch Entity To Dto.
     *
     * @param entity entity
     * @return Dto
     */
    Dto switchEntityToDto(Entity entity);

    /**
     * switch Vo To Entity.
     *
     * @param vo vo
     * @return Entity
     */
    Entity switchVoToEntity(Vo vo);

    /**
     * update Vo To Entity.
     *
     * @param vo     vo
     * @param entity entity
     */
    void updateVoToEntity(Vo vo, @MappingTarget Entity entity);

    /**
     * switch Entity List To Dto List.
     *
     * @param entityList entityList
     * @return List<Dto>
     */
    List<Dto> switchEntityListToDtoList(List<Entity> entityList);

    /**
     * switch Vo List To Entity List.
     *
     * @param dtoList dtoList
     * @return List<Entity>
     */
    List<Entity> switchVoListToEntityList(List<Vo> dtoList);
}
