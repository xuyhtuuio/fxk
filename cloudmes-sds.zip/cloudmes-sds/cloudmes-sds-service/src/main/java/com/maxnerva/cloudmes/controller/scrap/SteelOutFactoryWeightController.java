package com.maxnerva.cloudmes.controller.scrap;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.scrap.OutFactoryWeightDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelScrapShipHeaderPaymentDTO;
import com.maxnerva.cloudmes.models.vo.scrap.OutFactoryWeightVO;
import com.maxnerva.cloudmes.models.vo.scrap.SteelScrapShipHeaderPaymentQueryVO;
import com.maxnerva.cloudmes.service.scrap.impl.SteelScrapWeightService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @ClassName SteelOutFactoryWeightController
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/2/26 上午 08:10
 * @Version 1.0
 **/
@Api(tags = "委外称重管理")
@Slf4j
@RestController
@RequestMapping("/outFactory")
public class SteelOutFactoryWeightController {

    @Autowired
    private SteelScrapWeightService steelScrapWeightService;


    @ApiOperation("委外厂称重")
    @PostMapping("/OutSourcedFactoryWeight")
    R<OutFactoryWeightDTO> OutSourcedFactoryWeight(@RequestBody OutFactoryWeightVO vo){
        return R.ok(steelScrapWeightService.outSourcedFactoryWeight(vo));
    }
}
