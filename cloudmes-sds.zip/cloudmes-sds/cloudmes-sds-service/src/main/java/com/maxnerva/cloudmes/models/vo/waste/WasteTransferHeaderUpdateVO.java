package com.maxnerva.cloudmes.models.vo.waste;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @ClassName WasteTransferHeaderUpdateVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/28
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("危废转移单单头编辑vo")
@Data
public class WasteTransferHeaderUpdateVO {

    @ApiModelProperty("单头主键id")
    private Integer id;

    @ApiModelProperty("转移单号")
    private String transferDocNo;

    @ApiModelProperty("明细新增信息")
    private List<WasteTransferDetailSaveVO> detailList;
}
