package com.maxnerva.cloudmes.service.scrap.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.common.utils.WebContextUtil;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.excel.handler.AddNoHandler;
import com.maxnerva.cloudmes.mapper.basic.SdsScrapSolidTypeConfigMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelInventoryBalanceLogMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelInventoryPlanSummaryMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelScrapShipHeaderMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelScrapWeightInfoMapper;
import com.maxnerva.cloudmes.models.dto.excel.scrap.SteelInventoryPlanSummaryExportDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelInventoryPlanSummaryDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsScrapSolidTypeConfig;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelInventoryBalanceLog;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelInventoryPlanSummary;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapShipHeader;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapWeightInfo;
import com.maxnerva.cloudmes.models.vo.scrap.BalanceInventoryWeightVO;
import com.maxnerva.cloudmes.models.vo.scrap.SteelInventoryPlanSummaryQueryVO;
import com.maxnerva.cloudmes.service.scrap.ISdsSteelInventoryPlanSummaryService;
import com.maxnerva.cloudmes.system.utils.DictLangUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.MimeTypeUtils;

import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class SdsSteelInventoryPlanSummaryService extends ServiceImpl<SdsSteelInventoryPlanSummaryMapper, SdsSteelInventoryPlanSummary> implements ISdsSteelInventoryPlanSummaryService {

    @Autowired
    DictLangUtils dictLangUtils;

    @Autowired
    SdsSteelInventoryBalanceLogMapper steelInventoryBalanceLogMapper;

    @Autowired
    SdsSteelScrapWeightInfoMapper steelScrapWeightInfoMapper;

    @Autowired
    SdsSteelScrapShipHeaderMapper steelScrapShipHeaderMapper;

    @Autowired
    SdsScrapSolidTypeConfigMapper sdsScrapSolidTypeConfigMapper;

    @Override
    public PageDataDTO<SteelInventoryPlanSummaryDTO> selectPageList(SteelInventoryPlanSummaryQueryVO vo, Boolean isPage) {
        Page page = new Page();
        if (BooleanUtil.isTrue(isPage)){
            page = PageHelper.startPage(vo.getPageIndex(), vo.getPageSize());
        }
        List<SdsSteelInventoryPlanSummary> list = baseMapper.selectList(Wrappers.<SdsSteelInventoryPlanSummary>lambdaQuery()
                .eq(StrUtil.isNotBlank(vo.getInventoryPlanNo()), SdsSteelInventoryPlanSummary::getInventoryPlanNo, vo.getInventoryPlanNo())
                .eq(StrUtil.isNotBlank(vo.getScrapDetailClass()), SdsSteelInventoryPlanSummary::getScrapDetailClass, vo.getScrapDetailClass())
                .eq(!"2".equals(vo.getStatus()), SdsSteelInventoryPlanSummary::getStatus, vo.getStatus())
                .orderByAsc(SdsSteelInventoryPlanSummary::getId)
        );
        List<SteelInventoryPlanSummaryDTO> result = ListUtil.toList();
        Map<String, Map<String, String>> dictMap = dictLangUtils.getByTypes(ListUtil.toList("SDS_SCRAP_SOLID", "SDS_SOLID_INVENTORY_BALANCE_STATUS"));
        list.forEach(item -> {
            SteelInventoryPlanSummaryDTO dto = new SteelInventoryPlanSummaryDTO();
            BeanUtil.copyProperties(item, dto);
            dto.setScrapDetailClassName(dictMap.get("SDS_SCRAP_SOLID").get(dto.getScrapDetailClass()));
            dto.setStatusName(dictMap.get("SDS_SOLID_INVENTORY_BALANCE_STATUS").get(dto.getStatus()));
            dto.setPrepareNewWeight(dto.getInventoryNetWeight().subtract(dto.getTotalNetWeight()));
            result.add(dto);
        });
        return new PageDataDTO(page.getTotal(), result);
    }

    @Override
    public void exportDetail(SteelInventoryPlanSummaryQueryVO vo, HttpServletResponse response) {
        PageDataDTO<SteelInventoryPlanSummaryDTO> pageDataDTO = selectPageList(vo, Boolean.FALSE);
        List<SteelInventoryPlanSummaryExportDTO> exportDTOList = ListUtil.toList();
        pageDataDTO.getList().forEach(item -> {
            SteelInventoryPlanSummaryExportDTO dto = new SteelInventoryPlanSummaryExportDTO();
            BeanUtil.copyProperties(item, dto);
            exportDTOList.add(dto);
        });

        String fileName = "固废待平账记录" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), SteelInventoryPlanSummaryExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getLocalCode()));
        }
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void balanceWeight(BalanceInventoryWeightVO vo) {
        SdsSteelInventoryPlanSummary steelInventoryPlanSummary = baseMapper.selectById(vo.getId());
        if ("1".equals(steelInventoryPlanSummary.getStatus())){
            throw new CloudmesException("单据已完成平账，不能重复执行");
        }
        BigDecimal prepareNetWeight = steelInventoryPlanSummary.getInventoryNetWeight().subtract(steelInventoryPlanSummary.getTotalNetWeight());
        int updateVal = baseMapper.update(null, Wrappers.<SdsSteelInventoryPlanSummary>lambdaUpdate()
                .set(SdsSteelInventoryPlanSummary::getStatus, "1")
                .set(SdsSteelInventoryPlanSummary::getBalanceDt, LocalDateTime.now())
                .set(SdsSteelInventoryPlanSummary::getBalanceEmpNo, WebContextUtil.getCurrentStaffCode())
                .set(SdsSteelInventoryPlanSummary::getBalanceRemark, vo.getBalanceRemark())
                .set(SdsSteelInventoryPlanSummary::getBalanceWeight, prepareNetWeight)
                .eq(SdsSteelInventoryPlanSummary::getId, vo.getId())
                .eq(SdsSteelInventoryPlanSummary::getStatus, "0")
        );
        if (updateVal == 0){
            throw new CloudmesException("单据已完成平账，不能重复执行");
        }

        SdsSteelInventoryBalanceLog steelInventoryBalanceLog = new SdsSteelInventoryBalanceLog();
        BeanUtil.copyProperties(steelInventoryPlanSummary, steelInventoryBalanceLog);
        steelInventoryBalanceLog.setId(null);
        steelInventoryBalanceLog.setBalanceDt(LocalDateTime.now());
        steelInventoryBalanceLog.setBalanceEmpNo(WebContextUtil.getCurrentStaffCode());
        steelInventoryBalanceLog.setBalanceRemark(vo.getBalanceRemark());
        steelInventoryBalanceLog.setBalanceWeight(prepareNetWeight);
        SdsScrapSolidTypeConfig scrapSolidTypeConfig = sdsScrapSolidTypeConfigMapper.selectOne(Wrappers.<SdsScrapSolidTypeConfig>lambdaQuery()
                .eq(SdsScrapSolidTypeConfig::getScrapDetailClass, steelInventoryPlanSummary.getScrapDetailClass())
                .last("limit 1")
        );
        // 实物大于库存（入库）
        if (prepareNetWeight.compareTo(BigDecimal.ZERO) > 0){
            steelInventoryBalanceLog.setBalanceType("0");
            SdsSteelScrapWeightInfo steelScrapWeightInfo = new SdsSteelScrapWeightInfo();
            steelScrapWeightInfo.setBucketNo(steelInventoryPlanSummary.getInventoryPlanNo());
            steelScrapWeightInfo.setNetWeight(prepareNetWeight);
            steelScrapWeightInfo.setGrossWeight(BigDecimal.ZERO);
            steelScrapWeightInfo.setDepartmentCode(null);
            steelScrapWeightInfo.setScrapType(scrapSolidTypeConfig.getScrapType());
            steelScrapWeightInfo.setIsScrapArea(scrapSolidTypeConfig.getIsScrapArea());
            steelScrapWeightInfo.setRubbishWeighFlag("Y");
            steelScrapWeightInfo.setRubbishWeighEmpNo(WebContextUtil.getCurrentStaffCode());
            steelScrapWeightInfo.setRubbishWeighDt(LocalDateTime.now());
            steelScrapWeightInfo.setRubbishNetWeight(prepareNetWeight);
            steelScrapWeightInfo.setRubbishGrossWeight(BigDecimal.ZERO);
            steelScrapWeightInfo.setWeighEmpNo(WebContextUtil.getCurrentStaffCode());
            steelScrapWeightInfo.setWeighDt(LocalDateTime.now());
            steelScrapWeightInfo.setAcceptFlag("Y");
            steelScrapWeightInfo.setWeighFlag("Y");
            steelScrapWeightInfo.setAcceptDt(LocalDateTime.now());
            steelScrapWeightInfo.setAcceptEmpNo(WebContextUtil.getCurrentCopeCode());
            steelScrapWeightInfo.setBucketWeight(BigDecimal.ZERO);
            steelScrapWeightInfo.setOrgCode("ALL");
            steelScrapWeightInfo.setScrapClass("SDS_SCRAP_SOLID");
            steelScrapWeightInfo.setScrapDetailClass(steelInventoryPlanSummary.getScrapDetailClass());
            steelScrapWeightInfo.setUom("KG");
            steelScrapWeightInfo.setInventoryPlanNo(steelInventoryPlanSummary.getInventoryPlanNo());

            steelScrapWeightInfoMapper.insert(steelScrapWeightInfo);
        } else if (prepareNetWeight.compareTo(BigDecimal.ZERO) < 0){
            steelInventoryBalanceLog.setBalanceType("1");

            SdsSteelScrapShipHeader steelScrapShipHeader = new SdsSteelScrapShipHeader();
            steelScrapShipHeader.setScrapDetailClass(steelInventoryPlanSummary.getScrapDetailClass());
            steelScrapShipHeader.setDeclareNumber(steelInventoryPlanSummary.getInventoryPlanNo());
            steelScrapShipHeader.setScrapNetWeight(prepareNetWeight.abs());
            steelScrapShipHeader.setScrapAreaStatus("2");
            steelScrapShipHeader.setCarWeight(BigDecimal.ZERO);
            steelScrapShipHeader.setFullCarWeight(prepareNetWeight.abs());
            steelScrapShipHeader.setInventoryPlanNo(steelInventoryPlanSummary.getInventoryPlanNo());
            steelScrapShipHeaderMapper.insert(steelScrapShipHeader);
        }
        steelInventoryBalanceLogMapper.insert(steelInventoryBalanceLog);
    }
}
