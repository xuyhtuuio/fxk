package com.maxnerva.cloudmes.excel.listener.basic;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.google.common.collect.Lists;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.models.vo.excel.basic.MaterialClassImportVO;
import jodd.util.StringUtil;

import java.util.List;

/**
 * @ClassName MaterialClassImportListener
 * @Description TODO
 * @Author Likun
 * @Date 2024/10/28
 * @Version 1.0
 * @Since JDK 1.8
 **/
public class MaterialClassImportListener extends AnalysisEventListener<MaterialClassImportVO> {

    public List<MaterialClassImportVO> getMaterialClassImportVOList() {
        return materialClassImportVOList;
    }

    public List<String> getError() {
        return error;
    }

    private List<MaterialClassImportVO> materialClassImportVOList = Lists.newArrayList();

    private List<String> error = Lists.newArrayList();

    private int row = 1;


    @Override
    public void invoke(MaterialClassImportVO materialClassImportVO, AnalysisContext context) {
        row++;
        convertAndCheck(materialClassImportVO);
        materialClassImportVOList.add(materialClassImportVO);
    }

    @Override
    public void doAfterAllAnalysed(AnalysisContext context) {

    }

    private void convertAndCheck(MaterialClassImportVO materialClassImportVO) {
        StringBuilder msg = new StringBuilder();
        //校验分类代码和物料类别
        if (StringUtil.isBlank(materialClassImportVO.getClassCode())) {
            msg.append(MessageUtils.get(SdsResultCode.CLASS_CODE_IS_EMPTY
                    .getLocalCode())).append(",");
        }
        if (StringUtil.isBlank(materialClassImportVO.getClassName())) {
            msg.append(MessageUtils.get(SdsResultCode.CLASS_NAME_IS_EMPTY
                    .getLocalCode())).append(",");
        }
        if (msg.length() > 0) {
            msg.insert(0, String.format(MessageUtils.get(SdsResultCode.ERROR_MESSAGE_IN_LINE
                    .getLocalCode()), row));
            msg.delete(msg.length() - 1, msg.length());
            msg.append(";");
            error.add(msg.toString());
        }
    }
}
