package com.maxnerva.cloudmes.models.dto.scrap;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class SteelScrapWeightRejectDTO {
    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("工厂组织")
    private String orgCode;

    @ApiModelProperty("报废小类")
    private String scrapDetailClass;

    @ApiModelProperty("报废小类名")
    private String scrapDetailClassName;

    @ApiModelProperty("厂部编码")
    private String departmentCode;

    @ApiModelProperty("厂部名称")
    private String departmentCodeName;

    @ApiModelProperty("状态")
    private String status;

    @ApiModelProperty("状态名")
    private String statusName;

    @ApiModelProperty("托盘编码")
    private String bucketNo;

    private BigDecimal bucketWeight;

    @ApiModelProperty("单位")
    private String uom;

    @ApiModelProperty("毛重")
    private BigDecimal grossWeight;

    @ApiModelProperty("净重")
    private BigDecimal netWeight;

    @ApiModelProperty("称重人")
    private String weighEmpNo;

    @ApiModelProperty("称重时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime weighDt;

    @ApiModelProperty("暂存区毛重")
    private BigDecimal rubbishGrossWeight;

    @ApiModelProperty("暂存区净重")
    private BigDecimal rubbishNetWeight;

    @ApiModelProperty("暂存区称重人")
    private String rubbishWeighEmpNo;

    @ApiModelProperty("暂存区称重时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime rubbishWeighDt;

    @ApiModelProperty("拒收原因")
    private String rejectReason;

    @ApiModelProperty("拒收人")
    private String rejectEmpNo;

    @ApiModelProperty("拒收时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime rejectDt;

    @ApiModelProperty("处理人")
    private String handleEmpNo;

    @ApiModelProperty("处理时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime handleDt;

    @ApiModelProperty("处理方式")
    private String handleMethod;

    @ApiModelProperty("当前托盘编码")
    private String nowBucketNo;

    @ApiModelProperty(value = "创建人")
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "创建时间")
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "修改人")
    private String lastEditor;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "修改时间")
    private LocalDateTime lastEditedDt;

    @ApiModelProperty(value = "是否发送邮件通知")
    private String sendMailFlag;

    @ApiModelProperty("图片列表")
    private List<String> imageUrlList;

    @ApiModelProperty("拒收圖片")
    private List<String> rejectImageList;

    @ApiModelProperty(value = "详细原因备注")
    private String reason;
}
