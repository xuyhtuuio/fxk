package com.maxnerva.cloudmes.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/**
 * @ClassName DatahubConfig
 * @Description 服务节点地址配置类
 * @Author Likun
 * @Date 2023/9/13
 * @Version 1.0
 * @Since JDK 1.8
 **/
@RefreshScope
@Component
@Data
public class DataHubUrlConfig {

    @Value("${flownetSystem.flownetPlanInfoApprovalCompleted:}")
    private String flownetPlanInfoApprovalCompletedUrl;

    @Value("${flownetSystem.flownetPlanInfoAddLogApprovalCompleted:}")
    private String flownetPlanInfoAddLogApprovalCompletedUrl;
}
