package com.maxnerva.cloudmes.mapper.waste;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.dto.waste.WasteTransferDetailDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteTransferDetail;
import com.maxnerva.cloudmes.models.vo.waste.WasteTransferDetailQueryVO;

import java.util.List;

/**
 * <p>
 * 危废转移单明细 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2025-05-27
 */
public interface SdsHazardousWasteTransferDetailMapper extends BaseMapper<SdsHazardousWasteTransferDetail> {

    List<WasteTransferDetailDTO> selectTransferDetailList(WasteTransferDetailQueryVO queryVO);

    String selectImageUrl(Integer id);
}
