package com.maxnerva.cloudmes.models.dto.scrap;

import com.maxnerva.cloudmes.models.vo.excel.ExcelMergeCellValue;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class SteelPaymentSalesSummaryDTO {

    @ApiModelProperty(value = "序号")
    private ExcelMergeCellValue<String> index;

    @ApiModelProperty(value = "废料品名")
    private ExcelMergeCellValue<String> scrapPartName ;

    @ApiModelProperty(value = "费用代码")
    private ExcelMergeCellValue<String> costCode;

    @ApiModelProperty(value = "加總 - 數量(KG）")
    private ExcelMergeCellValue<BigDecimal> splitShipNetWeight;

    @ApiModelProperty(value = "加總 - 金額(RMB）")
    private ExcelMergeCellValue<BigDecimal> splitShipAccount;

    @ApiModelProperty(value = "入库量")
    private ExcelMergeCellValue<BigDecimal> inStoreNetWeight;

    @ApiModelProperty(value = "入库占比")
    private ExcelMergeCellValue<BigDecimal> inStorePercentage;

    @ApiModelProperty(value = "入库占比文本")
    private ExcelMergeCellValue<String> inStorePercentageName;
}
