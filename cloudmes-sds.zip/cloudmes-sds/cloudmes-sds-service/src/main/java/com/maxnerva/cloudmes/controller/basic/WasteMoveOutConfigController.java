package com.maxnerva.cloudmes.controller.basic;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.waste.WasteMoveOutConfigDTO;
import com.maxnerva.cloudmes.service.waste.ISdsHazardousMoveOutConfigService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName WasteMoveOutConfigController
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/28
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "危废移出单位配置管理")
@Slf4j
@RestController
@RequestMapping("/wasteMoveOutConfig")
public class WasteMoveOutConfigController {

    @Resource
    private ISdsHazardousMoveOutConfigService outConfigService;

    @ApiOperation("查询危废移出单位配置列表")
    @GetMapping("/list")
    public R<List<WasteMoveOutConfigDTO>> selectMoveOutConfigList(){
        return R.ok(outConfigService.selectMoveOutConfigList());
    }
}
