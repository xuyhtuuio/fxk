package com.maxnerva.cloudmes.models.dto.waste;

import com.maxnerva.cloudmes.models.dto.CommonPrintDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @ClassName WasteDocPrintDTO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/14
 * @Version 1.0
 * @Since JDK 1.8
 **/
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@ApiModel(value = "产废单信息打印DTO")
@Data
public class WasteDocPrintDTO  extends CommonPrintDTO {

    @ApiModelProperty("打印数据dto")
    private WasteDocPrintDataDTO data;
}
