package com.maxnerva.cloudmes.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.dto.basic.HazardousWasteInfoDTO;
import com.maxnerva.cloudmes.models.dto.basic.WasteInfoBindDTO;
import com.maxnerva.cloudmes.models.dto.basic.WasteNameInfoDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsHazardousWasteInfo;
import com.maxnerva.cloudmes.models.vo.basic.HazardousWasteInfoQueryVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 危废物信息表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2025-05-06
 */
public interface SdsHazardousWasteInfoMapper extends BaseMapper<SdsHazardousWasteInfo> {

    List<HazardousWasteInfoDTO> selectHazardousWasteInfoList(HazardousWasteInfoQueryVO queryVO);

    List<String> selectWastNameList();


    WasteInfoBindDTO selectWasteInfoBindList(@Param("orgCode") String orgCode,
                                             @Param("costCode") String costCode,
                                             @Param("hazardousWasteName") String hazardousWasteName,
                                             @Param("hazardousWasteNo") String hazardousWasteNo);

    List<WasteNameInfoDTO> selectWasteNameInfoByOrgCodeAndCostCode(@Param("orgCode") String orgCode,
                                                                   @Param("costCode") String costCode);

    List<String> selectWastNameByOrgCodeAndCostCode(@Param("orgCode") String orgCode,
                                                    @Param("costCode") String costCode);

    List<WasteNameInfoDTO> selectWasteNameInfo();
}
