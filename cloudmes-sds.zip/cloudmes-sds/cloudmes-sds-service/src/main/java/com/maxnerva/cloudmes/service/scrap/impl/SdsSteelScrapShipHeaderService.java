package com.maxnerva.cloudmes.service.scrap.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.date.LocalDateTimeUtil;
import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.core.util.XmlUtil;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import com.alibaba.excel.EasyExcel;
import com.alibaba.fastjson2.JSON;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.config.MinIOProperties;
import com.maxnerva.cloudmes.common.constant.BucketConstant;
import com.maxnerva.cloudmes.common.enums.ResultCode;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.common.utils.WebContextUtil;
import com.maxnerva.cloudmes.config.ECusUrlConfig;
import com.maxnerva.cloudmes.enums.PrintTypeEnum;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.excel.handler.AddNoHandler;
import com.maxnerva.cloudmes.feign.print.IPrintTemplateClient;
import com.maxnerva.cloudmes.mapper.basic.SdsPrintTemplateConfigMapper;
import com.maxnerva.cloudmes.mapper.basic.SdsScrapSolidTypeConfigMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsHikPictureLogMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelScrapShipHeaderMapper;
import com.maxnerva.cloudmes.models.dto.excel.scrap.SteelScrapShipHeaderExportDTO;
import com.maxnerva.cloudmes.models.dto.excel.scrap.SteelScrapShipHeaderPaymentExportDTO;
import com.maxnerva.cloudmes.models.dto.print.PrintTemplateFeignDTO;
import com.maxnerva.cloudmes.models.dto.scrap.*;
import com.maxnerva.cloudmes.models.entity.basic.SdsPrintTemplateConfig;
import com.maxnerva.cloudmes.models.entity.basic.SdsScrapSolidTypeConfig;
import com.maxnerva.cloudmes.models.entity.scrap.SdsHikPictureLog;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapShipHeader;
import com.maxnerva.cloudmes.models.vo.scrap.*;
import com.maxnerva.cloudmes.service.scrap.ISdsSteelScrapShipHeaderService;
import com.maxnerva.cloudmes.system.utils.DictLangUtils;
import com.maxnerva.cloudmes.util.PageUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class SdsSteelScrapShipHeaderService extends ServiceImpl<SdsSteelScrapShipHeaderMapper, SdsSteelScrapShipHeader> implements ISdsSteelScrapShipHeaderService {

    @Autowired
    SdsPrintTemplateConfigMapper sdsPrintTemplateConfigMapper;

    @Autowired
    private IPrintTemplateClient printTemplateClient;

    @Autowired
    SdsScrapSolidTypeConfigMapper scrapSolidTypeConfigMapper;

    @Autowired
    ECusUrlConfig eCusUrlConfig;

    @Autowired
    DictLangUtils dictLangUtils;

    @Autowired
    SdsHikPictureLogMapper sdsHikPictureLogMapper;

    @Autowired
    private MinIOProperties minIOProperties;

    @Override
    public PrintScrapShipmentApplyDTO printScrapShipmentApply(PrintScrapShipmentApplyVO vo) {

        String printTemplateId = vo.getPrintTemplateId();
        //如果传入模板id为空，则查询配置表中配置的模板id
        if (StrUtil.isEmpty(printTemplateId)) {
            SdsPrintTemplateConfig sdsPrintTemplateConfig = sdsPrintTemplateConfigMapper
                    .selectOne(Wrappers.<SdsPrintTemplateConfig>lambdaQuery()
                            .eq(SdsPrintTemplateConfig::getOrgCode, "ALL")
                            .eq(SdsPrintTemplateConfig::getPrintType, PrintTypeEnum.SCRAP_SHIPMENT_APPLY.getDictCode())
                            .last("limit 1"));
            printTemplateId = sdsPrintTemplateConfig.getPrintTemplateId().toString();
        }
        //调用打印服务查询模板content以及模板类型
        PrintTemplateFeignDTO printTemplateFeignDTO = selectPrintTemplate(printTemplateId);

        SdsSteelScrapShipHeader steelScrapShipHeader = baseMapper.selectOne(Wrappers.<SdsSteelScrapShipHeader>lambdaQuery()
                .eq(SdsSteelScrapShipHeader::getDeclareNumber, vo.getDeclareNumber())
                .last("limit 1")
        );
        if (ObjectUtil.isNull(steelScrapShipHeader)) {
            BcwInfoDTO bcwInfoDTO = requestBcwInfo(vo.getDeclareNumber());
            if (ObjectUtil.isNull(bcwInfoDTO)) {
                throw new CloudmesException("此单号在ECUS中不存在");
            }
            steelScrapShipHeader = new SdsSteelScrapShipHeader();
            steelScrapShipHeader.setDeclareNumber(bcwInfoDTO.getBCW01());
            steelScrapShipHeader.setManFacturer(bcwInfoDTO.getBCW37());
            steelScrapShipHeader.setScrapPartName(bcwInfoDTO.getBCW07());
            steelScrapShipHeader.setScrapPartNo(bcwInfoDTO.getBCW06());
            if (StrUtil.isBlank(steelScrapShipHeader.getScrapPartNo())) {
                throw new CloudmesException("同步ECUS废料料号为空，不能同步");
            }
            SdsScrapSolidTypeConfig sdsScrapSolidTypeConfig = scrapSolidTypeConfigMapper.selectOne(Wrappers.<SdsScrapSolidTypeConfig>lambdaQuery()
                    .eq(SdsScrapSolidTypeConfig::getScrapPartNo, steelScrapShipHeader.getScrapPartNo())
                    .last("limit 1")
            );
            if (ObjectUtil.isNull(sdsScrapSolidTypeConfig)) {
                throw new CloudmesException(String.format("报废料号%s没有配置与报废类型的对应关系", steelScrapShipHeader.getScrapPartNo()));
            }
            String scrapDetailClass = sdsScrapSolidTypeConfig.getScrapDetailClass();
            String sdsScrapType = sdsScrapSolidTypeConfig.getScrapType();
            steelScrapShipHeader.setSdsScrapType(sdsScrapType);
            steelScrapShipHeader.setScrapDetailClass(scrapDetailClass);
            steelScrapShipHeader.setCustomsCode(bcwInfoDTO.getBCW03());
            steelScrapShipHeader.setScrapType(bcwInfoDTO.getKXA03());
            steelScrapShipHeader.setAreaCode(bcwInfoDTO.getKFB04());
            steelScrapShipHeader.setLicenseCarNumber(bcwInfoDTO.getBCW051());
            steelScrapShipHeader.setDriver(bcwInfoDTO.getBCW052());
            steelScrapShipHeader.setApplyor(bcwInfoDTO.getBCW50());
            if (StrUtil.isNotBlank(bcwInfoDTO.getBCW02())) {
                steelScrapShipHeader.setApplyDt(LocalDateTimeUtil.parse(bcwInfoDTO.getBCW02(), DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'+08:00'")));
            }
            steelScrapShipHeader.setShippingCorporation(bcwInfoDTO.getKWY02());
            steelScrapShipHeader.setCostCode(bcwInfoDTO.getBCW10());
            steelScrapShipHeader.setUom(bcwInfoDTO.getGFE02());
            steelScrapShipHeader.setFiledNumber(bcwInfoDTO.getBCW29());
            steelScrapShipHeader.setLockNumber(bcwInfoDTO.getKFA06());
            steelScrapShipHeader.setCarToolBox(bcwInfoDTO.getKFA18());
            steelScrapShipHeader.setCarFuelTank(bcwInfoDTO.getKFA15());
            steelScrapShipHeader.setCarSteelRing(bcwInfoDTO.getKFA19());
            steelScrapShipHeader.setCarWaterTank(bcwInfoDTO.getKFA16());
            steelScrapShipHeader.setCarSpareTire(bcwInfoDTO.getKFA17());
            if (StrUtil.isNotBlank(bcwInfoDTO.getBCW11())) {
                steelScrapShipHeader.setCarWeight(new BigDecimal(bcwInfoDTO.getBCW11()));
            }
            if (StrUtil.isNotBlank(bcwInfoDTO.getBCW021())) {
                steelScrapShipHeader.setEntryTime(LocalDateTime.parse(bcwInfoDTO.getBCW021(), DateTimeFormatter.ofPattern("yyyyMMddHHmm")));
            }
            steelScrapShipHeader.setCarWeightEmp(bcwInfoDTO.getBCW39());
            steelScrapShipHeader.setCarWeightDt(steelScrapShipHeader.getEntryTime());

            steelScrapShipHeader.setWeightUom(bcwInfoDTO.getBCW16());
            if (StrUtil.isNotBlank(bcwInfoDTO.getBCW12())) {
                steelScrapShipHeader.setFullCarWeight(new BigDecimal(bcwInfoDTO.getBCW12()));
            }
            if (StrUtil.isNotBlank(bcwInfoDTO.getBCW023())) {
                steelScrapShipHeader.setLeaveTime(LocalDateTime.parse(bcwInfoDTO.getBCW023(), DateTimeFormatter.ofPattern("yyyyMMddHHmm")));
            }
            steelScrapShipHeader.setFullCarWeightEmp(bcwInfoDTO.getBCW40());
            steelScrapShipHeader.setFullCarWeightDt(steelScrapShipHeader.getLeaveTime());
            steelScrapShipHeader.setScrapAreaStatus("0");

            if (StrUtil.isNotBlank(bcwInfoDTO.getBCW17())) {
                steelScrapShipHeader.setPrice(new BigDecimal(bcwInfoDTO.getBCW17()));
            }
            steelScrapShipHeader.setMfgCode(bcwInfoDTO.getBCW04());
            baseMapper.insert(steelScrapShipHeader);
        }
        SdsSteelScrapShipHeaderDTO dto = new SdsSteelScrapShipHeaderDTO();
        BeanUtil.copyProperties(steelScrapShipHeader, dto);
        PrintScrapShipmentApplyDTO printScrapShipmentApplyDTO = new PrintScrapShipmentApplyDTO();
        printScrapShipmentApplyDTO.setData(dto);
        printScrapShipmentApplyDTO.setContent(printTemplateFeignDTO.getContent());
        printScrapShipmentApplyDTO.setType(printTemplateFeignDTO.getFileType());
        return printScrapShipmentApplyDTO;
    }

    @Override
    public void syncFullCarWeight() {
        List<SdsSteelScrapShipHeader> steelScrapShipHeaderList = baseMapper.selectList(Wrappers.<SdsSteelScrapShipHeader>lambdaQuery()
                .eq(SdsSteelScrapShipHeader::getFullCarWeight, BigDecimal.ZERO)
                .or().isNull(SdsSteelScrapShipHeader::getFullCarWeight)
                .or().eq(SdsSteelScrapShipHeader::getPrice, BigDecimal.ZERO)
        );

        steelScrapShipHeaderList.forEach(steelScrapShipHeader -> {
            BcwInfoDTO bcwInfoDTO = requestBcwInfo(steelScrapShipHeader.getDeclareNumber());
            if (ObjectUtil.isNull(bcwInfoDTO)) {
                return;
            }
            if (StrUtil.isBlank(bcwInfoDTO.getBCW12())){
                return;
            }
            BigDecimal fullCarWeight = new BigDecimal(bcwInfoDTO.getBCW12());
            if (fullCarWeight.compareTo(BigDecimal.ZERO) == 0) {
                return;
            }
            String fullCarWeightEmp = bcwInfoDTO.getBCW40();
            LocalDateTime fullCarWeightDt = null;
            if (StrUtil.isNotBlank(bcwInfoDTO.getBCW023())) {
                fullCarWeightDt = LocalDateTime.parse(bcwInfoDTO.getBCW023(), DateTimeFormatter.ofPattern("yyyyMMddHHmm"));
            }
            BigDecimal scrapNetWeight = null;
            if (StrUtil.isNotBlank(bcwInfoDTO.getBCW14())) {
                scrapNetWeight = new BigDecimal(bcwInfoDTO.getBCW14());
            }
            BigDecimal price = steelScrapShipHeader.getPrice();
            if (price.compareTo(BigDecimal.ZERO) == 0 && StrUtil.isNotBlank(bcwInfoDTO.getBCW17())) {
                price = new BigDecimal(bcwInfoDTO.getBCW17());
            }
            baseMapper.update(null, Wrappers.<SdsSteelScrapShipHeader>lambdaUpdate()
                    .set(SdsSteelScrapShipHeader::getScrapNetWeight, scrapNetWeight)
                    .set(SdsSteelScrapShipHeader::getFullCarWeight, fullCarWeight)
                    .set(SdsSteelScrapShipHeader::getFullCarWeightDt, fullCarWeightDt)
                    .set(SdsSteelScrapShipHeader::getLeaveTime, fullCarWeightDt)
                    .set(SdsSteelScrapShipHeader::getFullCarWeightEmp, fullCarWeightEmp)
                    .set(price.compareTo(BigDecimal.ZERO) != 0, SdsSteelScrapShipHeader::getPrice, price)
                    .eq(SdsSteelScrapShipHeader::getId, steelScrapShipHeader.getId())
            );
            try {
                Thread.sleep(1000 * 10);
            } catch (Exception e) {
            }
        });

    }

    @Override
    public PageDataDTO<SteelScrapShipHeaderDTO> selectPageList(SteelScrapShipHeaderQueryVO vo, Boolean isPage) {
        Page page = new Page();
        if (BooleanUtil.isTrue(isPage)) {
            page = PageHelper.startPage(vo.getPageIndex(), vo.getPageSize());
        }
        List<SdsSteelScrapShipHeader> list = baseMapper.selectList(Wrappers.<SdsSteelScrapShipHeader>lambdaQuery()
                .eq(StrUtil.isNotBlank(vo.getDeclareNumber()), SdsSteelScrapShipHeader::getDeclareNumber, vo.getDeclareNumber())
                .eq(StrUtil.isNotBlank(vo.getSdsScrapType()), SdsSteelScrapShipHeader::getSdsScrapType, vo.getSdsScrapType())
                .eq(StrUtil.isNotBlank(vo.getLicenseCarNumber()), SdsSteelScrapShipHeader::getLicenseCarNumber, vo.getLicenseCarNumber())
                .eq(StrUtil.isNotBlank(vo.getMfgCode()), SdsSteelScrapShipHeader::getMfgCode, vo.getMfgCode())
                .eq(!"3".equals(vo.getScrapAreaStatus()), SdsSteelScrapShipHeader::getScrapAreaStatus, vo.getScrapAreaStatus())
        );
        List<SteelScrapShipHeaderDTO> result = ListUtil.toList();
        Map<String, Map<String, String>> dictMap = dictLangUtils.getByTypes(ListUtil.toList("SDS_IN_OUT_SCRAP_AREA_STATUS", "SDS_SCRAP_SOLID", "SDS_SOLID_SCRAP_TYPE"));
        list.forEach(item -> {
            SteelScrapShipHeaderDTO dto = new SteelScrapShipHeaderDTO();
//            List<String> pictureLinkList = ListUtil.toList();
            BeanUtil.copyProperties(item, dto, "imageList");
//            List<SdsHikPictureLog> sdsHikPictureLogList = sdsHikPictureLogMapper.selectList(Wrappers.<SdsHikPictureLog>lambdaQuery()
//                    .eq(SdsHikPictureLog::getDeclareNumber, item.getDeclareNumber())
//                    .last("limit 56")
//            );
//            for (SdsHikPictureLog hikPicture: sdsHikPictureLogList) {
//                pictureLinkList.add(hikPicture.getPicUrl());
//            }
            dto.setScrapDetailClassName(dictMap.get("SDS_SCRAP_SOLID").get(dto.getScrapDetailClass()));
            dto.setScrapAreaStatusName(dictMap.get("SDS_IN_OUT_SCRAP_AREA_STATUS").get(dto.getScrapAreaStatus()));
            dto.setSdsScrapTypeName(dictMap.get("SDS_SOLID_SCRAP_TYPE").get(dto.getSdsScrapType()));
//            if (CollectionUtil.isNotEmpty(pictureLinkList)){
//                pictureLinkList = pictureLinkList.stream().map(link -> minIOProperties.getFileAddr(BucketConstant.CLOUD_SAAS, link)).collect(Collectors.toList());
//                dto.setImageList(pictureLinkList);
//            }
            result.add(dto);
        });
        PageDataDTO pageDataDTO = new PageDataDTO(page.getTotal(), result);
        return pageDataDTO;
    }

    @Override
    public void exportDetail(SteelScrapShipHeaderQueryVO vo, HttpServletResponse response) {
        PageDataDTO<SteelScrapShipHeaderDTO> pageDataDTO = selectPageList(vo, Boolean.FALSE);
        List<SteelScrapShipHeaderExportDTO> exportDTOList = ListUtil.toList();
        pageDataDTO.getList().forEach(item -> {
            SteelScrapShipHeaderExportDTO dto = new SteelScrapShipHeaderExportDTO();
            BeanUtil.copyProperties(item, dto);
            exportDTOList.add(dto);
        });

        String fileName = "固废出货单记录" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), SteelScrapShipHeaderExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getLocalCode()));
        }
    }

    @Override
    public InScrapAreaInfoDTO inScrapAreaInfo(InScrapAreaInfoVO vo) {
        SdsSteelScrapShipHeader steelScrapShipHeader = baseMapper.selectOne(Wrappers.<SdsSteelScrapShipHeader>lambdaQuery()
                .eq(SdsSteelScrapShipHeader::getDeclareNumber, vo.getDeclareNumber())
                .last("limit 1")
        );
        if (ObjectUtil.isNull(steelScrapShipHeader)) {
            throw new CloudmesException("出库单号不存在");
        }
        if (ObjectUtil.isNull(steelScrapShipHeader.getCarWeight()) || steelScrapShipHeader.getCarWeight().compareTo(BigDecimal.ZERO) == 0) {
            BcwInfoDTO bcwInfoDTO = requestBcwInfo(steelScrapShipHeader.getDeclareNumber());
            if (ObjectUtil.isNull(bcwInfoDTO)) {
                throw new CloudmesException("空车未过磅，不允许进废料区或码头");
            }
            if (StrUtil.isBlank(bcwInfoDTO.getBCW11())) {
                throw new CloudmesException("空车未过磅，不允许进废料区或码头");
            }
            BigDecimal carWeight = new BigDecimal(bcwInfoDTO.getBCW11());
            if (carWeight.compareTo(BigDecimal.ZERO) == 0) {
                throw new CloudmesException("空车未过磅，不允许进废料区或码头");
            }
            LocalDateTime entryTime = null;
            if (StrUtil.isNotBlank(bcwInfoDTO.getBCW021())) {
                entryTime = LocalDateTime.parse(bcwInfoDTO.getBCW021(), DateTimeFormatter.ofPattern("yyyyMMddHHmm"));
            }
            String carWeightEmp = bcwInfoDTO.getBCW39();
            Map<String, String> inOutScrapAreaDict = dictLangUtils.getByType("SDS_IN_OUT_SCRAP_AREA_STATUS");
            InScrapAreaInfoDTO dto = new InScrapAreaInfoDTO();
            dto.setId(steelScrapShipHeader.getId());
            dto.setDeclareNumber(vo.getDeclareNumber());
            dto.setLicenseCarNumber(steelScrapShipHeader.getLicenseCarNumber());
            dto.setDriver(steelScrapShipHeader.getDriver());
            dto.setCarWeight(carWeight);
            dto.setCarWeightEmp(carWeightEmp);
            dto.setEntryTime(entryTime);
            dto.setScrapAreaStatus(steelScrapShipHeader.getScrapAreaStatus());
            dto.setScrapAreaStatusName(inOutScrapAreaDict.get(dto.getScrapAreaStatus()));
            dto.setScrapPartName(steelScrapShipHeader.getScrapPartName());
            dto.setScrapType(steelScrapShipHeader.getScrapType());
            baseMapper.update(null, Wrappers.<SdsSteelScrapShipHeader>lambdaUpdate()
                    .set(SdsSteelScrapShipHeader::getEntryTime, entryTime)
                    .set(SdsSteelScrapShipHeader::getCarWeightEmp, carWeightEmp)
                    .set(SdsSteelScrapShipHeader::getCarWeight, carWeight)
                    .set(SdsSteelScrapShipHeader::getCarWeightDt, entryTime)
                    .eq(SdsSteelScrapShipHeader::getId, steelScrapShipHeader.getId())
            );
            return dto;
        } else {
            Map<String, String> inOutScrapAreaDict = dictLangUtils.getByType("SDS_IN_OUT_SCRAP_AREA_STATUS");
            InScrapAreaInfoDTO dto = new InScrapAreaInfoDTO();
            dto.setId(steelScrapShipHeader.getId());
            dto.setDeclareNumber(vo.getDeclareNumber());
            dto.setLicenseCarNumber(steelScrapShipHeader.getLicenseCarNumber());
            dto.setDriver(steelScrapShipHeader.getDriver());
            dto.setCarWeight(steelScrapShipHeader.getCarWeight());
            dto.setCarWeightEmp(steelScrapShipHeader.getCarWeightEmp());
            dto.setEntryTime(steelScrapShipHeader.getEntryTime());
            dto.setScrapAreaStatus(steelScrapShipHeader.getScrapAreaStatus());
            dto.setScrapAreaStatusName(inOutScrapAreaDict.get(dto.getScrapAreaStatus()));
            dto.setScrapPartName(steelScrapShipHeader.getScrapPartName());
            dto.setScrapType(steelScrapShipHeader.getScrapType());
            return dto;
        }
    }

    @Override
    public void inScrapAreaSubmit(InScrapAreaSubmitVO vo) {
        int updateVal = baseMapper.update(null, Wrappers.<SdsSteelScrapShipHeader>lambdaUpdate()
                .set(SdsSteelScrapShipHeader::getCarWeight, vo.getCarWeight())
                .set(SdsSteelScrapShipHeader::getEntryTime, vo.getEntryTime())
                .set(SdsSteelScrapShipHeader::getCarWeightDt, vo.getEntryTime())
                .set(SdsSteelScrapShipHeader::getCarWeightEmp, vo.getCarWeightEmp())
                .set(SdsSteelScrapShipHeader::getScrapAreaStatus, "1")
                .set(SdsSteelScrapShipHeader::getInScrapAreaDt, LocalDateTime.now())
                .set(SdsSteelScrapShipHeader::getInScrapAreaEmpNo, WebContextUtil.getCurrentStaffCode())
                .eq(SdsSteelScrapShipHeader::getId, vo.getId())
                .eq(SdsSteelScrapShipHeader::getScrapAreaStatus, "0")
        );
        if (updateVal == 0) {
            throw new CloudmesException("只有未进厂状态车辆才能进废料区放行");
        }
    }

    @Override
    public OutScrapAreaInfoDTO outScrapAreaInfo(OutScrapAreaInfoVO vo) {
        SdsSteelScrapShipHeader steelScrapShipHeader = baseMapper.selectOne(Wrappers.<SdsSteelScrapShipHeader>lambdaQuery()
                .eq(SdsSteelScrapShipHeader::getDeclareNumber, vo.getDeclareNumber())
                .last("limit 1")
        );
        if (ObjectUtil.isNull(steelScrapShipHeader)) {
            throw new CloudmesException("出库单号不存在");
        }
        Map<String, String> inOutScrapAreaDict = dictLangUtils.getByType("SDS_IN_OUT_SCRAP_AREA_STATUS");
        OutScrapAreaInfoDTO dto = new OutScrapAreaInfoDTO();
        dto.setId(steelScrapShipHeader.getId());
        dto.setDeclareNumber(vo.getDeclareNumber());
        dto.setLicenseCarNumber(steelScrapShipHeader.getLicenseCarNumber());
        dto.setDriver(steelScrapShipHeader.getDriver());
        dto.setCarWeight(steelScrapShipHeader.getCarWeight());
        dto.setCarWeightEmp(steelScrapShipHeader.getCarWeightEmp());
        dto.setEntryTime(steelScrapShipHeader.getEntryTime());
        dto.setScrapAreaStatus(steelScrapShipHeader.getScrapAreaStatus());
        dto.setScrapAreaStatusName(inOutScrapAreaDict.get(dto.getScrapAreaStatus()));
        dto.setInScrapAreaDt(steelScrapShipHeader.getInScrapAreaDt());
        dto.setScrapPartName(steelScrapShipHeader.getScrapPartName());
        dto.setScrapType(steelScrapShipHeader.getScrapType());
        return dto;
    }

    @Override
    public List<String> getPictureList(String docNo) {
        List<String> pictureLinkList = ListUtil.toList();
        List<SdsHikPictureLog> sdsHikPictureLogList = sdsHikPictureLogMapper.selectList(Wrappers.<SdsHikPictureLog>lambdaQuery()
                .eq(SdsHikPictureLog::getDeclareNumber, docNo)
                .last("limit 56")
        );
        for (SdsHikPictureLog hikPicture : sdsHikPictureLogList) {
            pictureLinkList.add(hikPicture.getPicUrl());
        }
        return pictureLinkList.stream().map(link -> minIOProperties.getFileAddr(BucketConstant.CLOUD_SAAS, link)).collect(Collectors.toList());
    }

    @Override
    public void outScrapAreaSubmit(OutScrapAreaSubmitVO vo) {
        SdsSteelScrapShipHeader steelScrapShipHeader = baseMapper.selectById(vo.getId());
        if (!"1".equals(steelScrapShipHeader.getScrapAreaStatus())) {
            throw new CloudmesException("此车辆还未进行装货，不允许出废料区放行");
        }
        int updateVal = baseMapper.update(null, Wrappers.<SdsSteelScrapShipHeader>lambdaUpdate()
                .set(SdsSteelScrapShipHeader::getOutScrapAreaDt, LocalDateTime.now())
                .set(SdsSteelScrapShipHeader::getOutScrapAreaEmpNo, WebContextUtil.getCurrentStaffCode())
                .set(SdsSteelScrapShipHeader::getScrapAreaStatus, "2")
                .eq(SdsSteelScrapShipHeader::getId, vo.getId())
                .eq(SdsSteelScrapShipHeader::getScrapAreaStatus, "1")
        );
        if (updateVal == 0) {
            throw new CloudmesException("只有进厂状态车辆才能出废料区放行");
        }
    }

    private PrintTemplateFeignDTO selectPrintTemplate(String printTemplateId) {
        R<PrintTemplateFeignDTO> templateResult = printTemplateClient
                .getFeignTemplateById(Integer.valueOf(printTemplateId));
        PrintTemplateFeignDTO printTemplateFeignDTO = templateResult.getData();
        if (ObjectUtil.isNull(printTemplateFeignDTO)) {
            throw new CloudmesException(SdsResultCode.PRINT_TEMPLATE_NOT_FIND.getCode()
                    , MessageUtils.get(SdsResultCode.PRINT_TEMPLATE_NOT_FIND.getLocalCode()));
        }
        return printTemplateFeignDTO;
    }


    public BcwInfoDTO requestBcwInfo(String declareNumber) {
        Map<String, String> form = new HashMap<>();
        form.put("p_cnn", eCusUrlConfig.getBcwPcnn());
        form.put("p_no", declareNumber);
        form.put("p_grup", "");
        form.put("p_sdate", "");
        form.put("p_edate", "");
        HttpResponse response = HttpRequest.post(eCusUrlConfig.getBcwUrl())
                .header("Accept", "text/xml; charset=utf-8")
                .setConnectionTimeout(5000)
                .formStr(form)
                .execute();

        if (response.getStatus() == ResultCode.SUCCESS.getCode()) {
            NodeList list = XmlUtil.parseXml(response.body()).getElementsByTagName("Table");
            Node node = list.item(0);
            if (ObjectUtil.isNull(node)) {
                return null;
            }
            BcwInfoDTO cusInfoDTO = XmlUtil.xmlToBean(node, BcwInfoDTO.class);
            return cusInfoDTO;
        }
        return null;
    }
}
