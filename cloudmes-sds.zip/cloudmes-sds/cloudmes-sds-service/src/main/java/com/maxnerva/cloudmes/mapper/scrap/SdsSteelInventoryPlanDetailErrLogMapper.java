package com.maxnerva.cloudmes.mapper.scrap;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelInventoryPlanDetailErrLog;

public interface SdsSteelInventoryPlanDetailErrLogMapper extends BaseMapper<SdsSteelInventoryPlanDetailErrLog> {
}
