package com.maxnerva.cloudmes.service.basic.impl;


import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.excel.handler.AddNoHandler;
import com.maxnerva.cloudmes.mapper.basic.SdsHazardousWasteInfoMapper;
import com.maxnerva.cloudmes.models.dto.basic.HazardousWasteInfoDTO;
import com.maxnerva.cloudmes.models.dto.basic.WasteInfoBindDTO;
import com.maxnerva.cloudmes.models.dto.basic.WasteNameInfoDTO;
import com.maxnerva.cloudmes.models.dto.excel.basic.HazardousWasteInfoExportDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsHazardousWasteInfo;
import com.maxnerva.cloudmes.models.vo.basic.HazardousWasteInfoQueryVO;
import com.maxnerva.cloudmes.service.basic.ISdsHazardousWasteInfoService;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;

import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 危废物信息表 服务实现类
 * </p>
 *
 * @author likun
 * @since 2025-05-06
 */
@Service
public class SdsHazardousWasteInfoServiceImpl extends ServiceImpl<SdsHazardousWasteInfoMapper, SdsHazardousWasteInfo>
        implements ISdsHazardousWasteInfoService {

    @Override
    public PageDataDTO<HazardousWasteInfoDTO> selectWasteInfoPage(HazardousWasteInfoQueryVO queryVO) {
        if (queryVO.getPageIndex() != null && queryVO.getPageSize() != null
                && queryVO.getPageIndex() != 0 && queryVO.getPageSize() != 0) {
            Page page = PageHelper.startPage(queryVO.getPageIndex(), queryVO.getPageSize());
            List<HazardousWasteInfoDTO> hazardousWasteInfoDTOList = baseMapper.selectHazardousWasteInfoList(queryVO);
            return new PageDataDTO<>(page.getTotal(), hazardousWasteInfoDTOList);
        } else {
            List<HazardousWasteInfoDTO> hazardousWasteInfoDTOList = baseMapper.selectHazardousWasteInfoList(queryVO);
            return new PageDataDTO<>((long) hazardousWasteInfoDTOList.size(), hazardousWasteInfoDTOList);
        }
    }

    @Override
    public List<String> selectWastNameList() {
        return baseMapper.selectWastNameList();
    }

    @Override
    public void exportHazardousWasteInfo(HttpServletResponse response, HazardousWasteInfoQueryVO queryVO) {
        List<HazardousWasteInfoExportDTO> exportDTOList = CollUtil.newArrayList();
        List<HazardousWasteInfoDTO> hazardousWasteInfoDTOList = baseMapper.selectHazardousWasteInfoList(queryVO);
        hazardousWasteInfoDTOList.forEach(hazardousWasteInfoDTO -> {
            HazardousWasteInfoExportDTO hazardousWasteInfoExportDTO = new HazardousWasteInfoExportDTO();
            BeanUtils.copyProperties(hazardousWasteInfoDTO, hazardousWasteInfoExportDTO);
            exportDTOList.add(hazardousWasteInfoExportDTO);
        });
        String fileName = "危废物信息" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), HazardousWasteInfoExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.HAZARDOUS_WASTE_INFO_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.HAZARDOUS_WASTE_INFO_EXPORT_FAIL.getLocalCode()));
        }
    }

    @Override
    public List<String> selectWastNameByOrgCodeAndCostCode(String orgCode, String costCode) {
        return baseMapper.selectWastNameByOrgCodeAndCostCode(orgCode, costCode);
    }

    @Override
    public WasteInfoBindDTO selectWasteInfoByWasteCode(String orgCode, String costCode, String hazardousWasteName) {
        return baseMapper.selectWasteInfoBindList(orgCode, costCode, hazardousWasteName, StrUtil.EMPTY);
    }

    @Override
    public List<WasteNameInfoDTO> selectWasteNameInfoByOrgCodeAndCostCode(String orgCode, String costCode) {
        return baseMapper.selectWasteNameInfoByOrgCodeAndCostCode(orgCode,costCode);
    }

    @Override
    public List<WasteNameInfoDTO> selectWasteNameInfo() {
        return baseMapper.selectWasteNameInfo();
    }
}
