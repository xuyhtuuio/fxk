package com.maxnerva.cloudmes.service.basic;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.models.entity.basic.SdsPrintTemplateConfig;

/**
 * <p>
 * 打印模板配置关系表 服务类
 * </p>
 *
 * @author likun
 * @since 2022-12-12
 */
public interface ISdsPrintTemplateConfigService extends IService<SdsPrintTemplateConfig> {

}
