package com.maxnerva.cloudmes.mapper.scrap;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.entity.scrap.SdsRfidSteelIssueLog;

public interface SdsRfidSteelIssueLogMapper extends BaseMapper<SdsRfidSteelIssueLog> {
}
