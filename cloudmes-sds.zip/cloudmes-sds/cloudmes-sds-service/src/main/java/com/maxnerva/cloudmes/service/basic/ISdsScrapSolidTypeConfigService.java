package com.maxnerva.cloudmes.service.basic;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.models.dto.basic.SolidTypeConfigDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsScrapSolidTypeConfig;

/**
 * <p>
 * 固废分类配置表 服务类
 * </p>
 *
 * @author likun
 * @since 2024-12-11
 */
public interface ISdsScrapSolidTypeConfigService extends IService<SdsScrapSolidTypeConfig> {

    SolidTypeConfigDTO selectSolidTypeByDetailClass(String scrapDetailClass);
}
