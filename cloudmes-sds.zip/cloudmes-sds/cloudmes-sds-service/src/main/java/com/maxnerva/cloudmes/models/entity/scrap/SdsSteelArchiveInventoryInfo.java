package com.maxnerva.cloudmes.models.entity.scrap;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 经管盘点报表归档
 * </p>
 *
 * @author baomidou
 * @since 2025-05-24
 */
@EqualsAndHashCode(callSuper = true)
@TableName("sds_steel_archive_inventory_info")
@ApiModel(value = "SdsSteelArchiveInventoryInfo对象", description = "经管盘点报表归档")
@Data
public class SdsSteelArchiveInventoryInfo extends BaseEntity<SdsSteelArchiveInventoryInfo> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("年yyyy")
    private String year;

    @ApiModelProperty("月MM")
    private String month;

    @ApiModelProperty("文件链接")
    private String link;

    @ApiModelProperty("文件名")
    private String filename;

    @ApiModelProperty("文件ID")
    private Integer fileId;

    @ApiModelProperty("暫存區與ECUS差異比例")
    private String rubbishDiffPercentage;

    @ApiModelProperty("各BU稱重與ECUS差異比例")
    private String buDiffPercentage;

    @ApiModelProperty(value = "tableData原始数据")
    private String tableData;
}
