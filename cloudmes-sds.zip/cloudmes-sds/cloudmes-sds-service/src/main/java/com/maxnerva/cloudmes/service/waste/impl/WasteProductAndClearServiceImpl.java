package com.maxnerva.cloudmes.service.waste.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.enums.WasteDocInfoStatusEnum;
import com.maxnerva.cloudmes.enums.WasteDocTypeEnum;
import com.maxnerva.cloudmes.excel.handler.AddNoHandler;
import com.maxnerva.cloudmes.mapper.waste.SdsHazardousWasteDocInfoMapper;
import com.maxnerva.cloudmes.models.dto.excel.waste.WasteNoStorageExportDTO;
import com.maxnerva.cloudmes.models.dto.waste.NoStorageApplyShipScanDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteProduceAndClearDocDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteDocInfo;
import com.maxnerva.cloudmes.models.vo.waste.NoStorageApplyShipScanVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteInStoreDocQueryVO;
import com.maxnerva.cloudmes.service.waste.WasteProductAndClearService;
import com.maxnerva.cloudmes.system.utils.DictLangUtils;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * @ClassName WasteProductAndClearServiceImpl
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/19
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Slf4j
@Service
public class WasteProductAndClearServiceImpl implements WasteProductAndClearService {

    @Resource
    private SdsHazardousWasteDocInfoMapper sdsHazardousWasteDocInfoMapper;

    @Resource
    private DictLangUtils dictLangUtils;

    @Override
    public PageDataDTO<WasteProduceAndClearDocDTO> selectProduceAndClearList(WasteInStoreDocQueryVO queryVO) {
        if (queryVO.getPageIndex() != null && queryVO.getPageSize() != null
                && queryVO.getPageIndex() != 0 && queryVO.getPageSize() != 0) {
            Page page = PageHelper.startPage(queryVO.getPageIndex(), queryVO.getPageSize());
            List<WasteProduceAndClearDocDTO> wasteProduceAndClearDocDTOList = getProduceAndClearDocDTOList(queryVO);
            return new PageDataDTO<>(page.getTotal(), wasteProduceAndClearDocDTOList);
        } else {
            List<WasteProduceAndClearDocDTO> wasteProduceAndClearDocDTOList = getProduceAndClearDocDTOList(queryVO);
            return new PageDataDTO<>((long) wasteProduceAndClearDocDTOList.size(), wasteProduceAndClearDocDTOList);
        }
    }

    @Override
    public NoStorageApplyShipScanDTO scanDocNo(NoStorageApplyShipScanVO scanVO) {
        String docNo = scanVO.getDocNo();
        String scanHazardousWasteNo = scanVO.getHazardousWasteNo();
        String hazardousWasteName = scanVO.getHazardousWasteName();
        SdsHazardousWasteDocInfo sdsHazardousWasteDocInfo = sdsHazardousWasteDocInfoMapper
                .selectOne(Wrappers.<SdsHazardousWasteDocInfo>lambdaQuery()
                        .eq(SdsHazardousWasteDocInfo::getDocNo, docNo)
                        .orderByDesc(SdsHazardousWasteDocInfo::getId)
                        .last("limit 1"));
        Optional.ofNullable(sdsHazardousWasteDocInfo)
                .orElseThrow(() -> new CloudmesException(SdsResultCode.WASTE_DOC_NOT_EXIST.getCode(),
                        String.format(MessageUtils.get(SdsResultCode.WASTE_DOC_NOT_EXIST.getLocalCode()),
                                docNo)));
        String hazardousWasteNo = sdsHazardousWasteDocInfo.getHazardousWasteNo();
        if (!StrUtil.equals(scanHazardousWasteNo, hazardousWasteNo)) {
            throw new CloudmesException(SdsResultCode.SCAN_DOC_IS_NOT_HAZARDOUS_NAME.getCode(),
                    String.format(MessageUtils.get(SdsResultCode.SCAN_DOC_IS_NOT_HAZARDOUS_NAME.getLocalCode()),
                            hazardousWasteName));
        }
        if (!WasteDocTypeEnum.NO_STORAGE.getDictCode().equals(sdsHazardousWasteDocInfo.getDocType())) {
            throw new CloudmesException(SdsResultCode.DOC_NO_NOT_OF_NO_STORAGE_DOC_TYPE.getCode(),
                    String.format(MessageUtils.get(SdsResultCode.DOC_NO_NOT_OF_NO_STORAGE_DOC_TYPE.getLocalCode()),
                            docNo));
        }
        if (!WasteDocInfoStatusEnum.IN_STORAGE.getDictCode().equals(sdsHazardousWasteDocInfo.getDocStatus())) {
            throw new CloudmesException(SdsResultCode.DOC_HAS_NOT_BEEN_IN_STORE_CAN_NOT_GENERATE_SHIP_DOC.getCode(),
                    String.format(MessageUtils.get(SdsResultCode.DOC_HAS_NOT_BEEN_IN_STORE_CAN_NOT_GENERATE_SHIP_DOC
                            .getLocalCode()), docNo));
        }
        NoStorageApplyShipScanDTO noStorageApplyShipScanDTO = new NoStorageApplyShipScanDTO();
        BeanUtils.copyProperties(sdsHazardousWasteDocInfo, noStorageApplyShipScanDTO);
        return noStorageApplyShipScanDTO;
    }

    @Override
    public void exportProductAndClearInfo(HttpServletResponse response, WasteInStoreDocQueryVO queryVO) {
        List<WasteNoStorageExportDTO> exportDTOList = CollUtil.newArrayList();
        List<WasteProduceAndClearDocDTO> wasteProduceAndClearDocDTOList = getProduceAndClearDocDTOList(queryVO);
        wasteProduceAndClearDocDTOList.forEach(wasteInStoreDocInfoDTO -> {
            WasteNoStorageExportDTO wasteNoStorageExportDTO = new WasteNoStorageExportDTO();
            BeanUtils.copyProperties(wasteInStoreDocInfoDTO, wasteNoStorageExportDTO);
            exportDTOList.add(wasteNoStorageExportDTO);
        });
        String fileName = "立产立清信息" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), WasteNoStorageExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.HAZARDOUS_WASTE_NO_STORAGE_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.HAZARDOUS_WASTE_NO_STORAGE_EXPORT_FAIL.getLocalCode()));
        }
    }

    @NotNull
    private List<WasteProduceAndClearDocDTO> getProduceAndClearDocDTOList(WasteInStoreDocQueryVO queryVO) {
        List<WasteProduceAndClearDocDTO> wasteProduceAndClearDocDTOList = sdsHazardousWasteDocInfoMapper
                .selectProduceAndClearDocList(queryVO);
        List<String> types = CollUtil.newArrayList();
        types.add("SDS_HAZARDOUS_WASTE_ENTRY_TYPE");
        types.add("SDS_WASTE_NO_IN_STORAGE_DOC_STATUS");
        Map<String, Map<String, String>> data = dictLangUtils.getByTypes(types);
        Map<String, String> entryTypeMap = data.get("SDS_HAZARDOUS_WASTE_ENTRY_TYPE");
        Map<String, String> docStatusMap = data.get("SDS_WASTE_NO_IN_STORAGE_DOC_STATUS");
        wasteProduceAndClearDocDTOList.forEach(wasteProduceAndClearDocDTO -> {
            wasteProduceAndClearDocDTO.setDocStatusName(docStatusMap.get(wasteProduceAndClearDocDTO.getDocStatus()));
            wasteProduceAndClearDocDTO.setDocTypeName(entryTypeMap.get(wasteProduceAndClearDocDTO.getDocType()));
        });
        return wasteProduceAndClearDocDTOList;
    }
}
