package com.maxnerva.cloudmes.models.entity.scrap;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 固废缴款通知单明细
 * </p>
 *
 * @author baomidou
 * @since 2025-01-08
 */
@TableName("sds_steel_payment_split_info")
@ApiModel(value = "SdsSteelPaymentSplitInfo对象", description = "固废缴款通知单分账明细")
@Data
public class SdsSteelPaymentSplitInfo extends BaseEntity<SdsSteelPaymentSplitInfo> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("缴款单号")
    private String paymentDocNo;

    @ApiModelProperty("厂部")
    private String departmentCode;

    @ApiModelProperty("入库重量")
    private BigDecimal inStoreNetWeight;

    @ApiModelProperty("入库占比")
    private BigDecimal inStorePercentage;

    @ApiModelProperty("分账金额")
    private BigDecimal splitAccount;

    @ApiModelProperty("费用代码")
    private String costCode;
}
