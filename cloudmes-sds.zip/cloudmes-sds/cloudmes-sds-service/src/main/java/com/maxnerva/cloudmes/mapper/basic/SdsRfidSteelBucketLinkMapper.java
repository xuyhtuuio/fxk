package com.maxnerva.cloudmes.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.entity.basic.SdsRfidSteelBucketLink;

public interface SdsRfidSteelBucketLinkMapper extends BaseMapper<SdsRfidSteelBucketLink> {
}
