package com.maxnerva.cloudmes.service.basic.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.google.common.collect.Sets;
import com.maxnerva.cloudmes.common.enums.ResultCode;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.enums.BucketTypeEnum;
import com.maxnerva.cloudmes.enums.CodeRuleEnum;
import com.maxnerva.cloudmes.enums.PrintTypeEnum;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.excel.handler.AddNoHandler;
import com.maxnerva.cloudmes.excel.listener.basic.SteelBucketImportListener;
import com.maxnerva.cloudmes.feign.basic.ICodeRuleClient;
import com.maxnerva.cloudmes.feign.print.IPrintTemplateClient;
import com.maxnerva.cloudmes.mapper.basic.SdsDepartmentConfigMapper;
import com.maxnerva.cloudmes.mapper.basic.SdsPrintTemplateConfigMapper;
import com.maxnerva.cloudmes.mapper.basic.SdsScrapSolidTypeConfigMapper;
import com.maxnerva.cloudmes.mapper.basic.SdsSteelBucketInfoMapper;
import com.maxnerva.cloudmes.models.dto.basic.BucketNoDTO;
import com.maxnerva.cloudmes.models.dto.basic.BucketNoPrintDTO;
import com.maxnerva.cloudmes.models.dto.basic.SolidTypeConfigDTO;
import com.maxnerva.cloudmes.models.dto.basic.SteelBucketDTO;
import com.maxnerva.cloudmes.models.dto.excel.basic.SteelBucketExportDTO;
import com.maxnerva.cloudmes.models.dto.print.PrintTemplateFeignDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsDepartmentConfig;
import com.maxnerva.cloudmes.models.entity.basic.SdsPrintTemplateConfig;
import com.maxnerva.cloudmes.models.entity.basic.SdsScrapSolidTypeConfig;
import com.maxnerva.cloudmes.models.entity.basic.SdsSteelBucketInfo;
import com.maxnerva.cloudmes.models.vo.basic.BucketNoPrintVO;
import com.maxnerva.cloudmes.models.vo.basic.SteelBucketQueryVO;
import com.maxnerva.cloudmes.models.vo.basic.SteelBucketSaveOrUpdateVO;
import com.maxnerva.cloudmes.models.vo.excel.ExcelImportVO;
import com.maxnerva.cloudmes.models.vo.excel.basic.SteelBucketExcelImportVO;
import com.maxnerva.cloudmes.models.vo.excel.basic.SteelBucketImportVO;
import com.maxnerva.cloudmes.service.basic.ISdsSteelBucketInfoService;
import com.maxnerva.cloudmes.system.utils.DictLangUtils;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <p>
 * 托盘信息表 服务实现类
 * </p>
 *
 * @author likun
 * @since 2024-10-28
 */
@Slf4j
@Service
public class SdsSteelBucketInfoServiceImpl extends ServiceImpl<SdsSteelBucketInfoMapper, SdsSteelBucketInfo>
        implements ISdsSteelBucketInfoService {

    @Resource
    private DictLangUtils dictLangUtils;

    @Resource
    private ICodeRuleClient codeRuleClient;

    @Resource
    private SdsPrintTemplateConfigMapper sdsPrintTemplateConfigMapper;

    @Resource
    private IPrintTemplateClient printTemplateClient;

    @Resource
    private SdsDepartmentConfigMapper sdsDepartmentConfigMapper;

    @Resource
    private SdsScrapSolidTypeConfigMapper sdsScrapSolidTypeConfigMapper;

    /**
     * excel类型
     */
    private static final Set<String> EXCEL_FILE_TYPE = Sets.newHashSet(".xlsx", ".xls");

    @Override
    public PageDataDTO<SteelBucketDTO> selectSteelBucketInfoPage(SteelBucketQueryVO queryVO) {
        if (queryVO.getPageIndex() != null && queryVO.getPageSize() != null
                && queryVO.getPageIndex() != 0 && queryVO.getPageSize() != 0) {
            Page page = PageHelper.startPage(queryVO.getPageIndex(), queryVO.getPageSize());
            List<SteelBucketDTO> steelBucketDTOList = getSteelBucketDTOList(queryVO);
            return new PageDataDTO<>(page.getTotal(), steelBucketDTOList);
        } else {
            List<SteelBucketDTO> steelBucketDTOList = getSteelBucketDTOList(queryVO);
            return new PageDataDTO<>((long) steelBucketDTOList.size(), steelBucketDTOList);
        }
    }

    private List<SteelBucketDTO> getSteelBucketDTOList(SteelBucketQueryVO queryVO) {
        List<String> types = new ArrayList<>();
        types.add("SDS_SCRAP_SOLID");
        types.add("SDS_SOLID_TYPE");
        types.add("SDS_SOLID_SCRAP_TYPE");
        Map<String, Map<String, String>> data = dictLangUtils.getByTypes(types);
        Map<String, String> sdsScrapSolidMap = data.get("SDS_SCRAP_SOLID");
        Map<String, String> sdsSolidTypeMap = data.get("SDS_SOLID_TYPE");
        Map<String, String> sdsSolidScrapTypeMap = data.get("SDS_SOLID_SCRAP_TYPE");
        List<SteelBucketDTO> steelBucketDTOList = baseMapper.selectSteelBucketList(queryVO);
        steelBucketDTOList.forEach(steelBucketDTO -> {
            String scrapDetailClass = steelBucketDTO.getScrapDetailClass();
            String bucketType = steelBucketDTO.getBucketType();
            String scrapType = steelBucketDTO.getScrapType();
            steelBucketDTO.setScrapDetailClassName(sdsScrapSolidMap.get(scrapDetailClass));
            steelBucketDTO.setBucketTypeName(sdsSolidTypeMap.get(bucketType));
            steelBucketDTO.setScrapTypeName(sdsSolidScrapTypeMap.get(scrapType));
        });
        return steelBucketDTOList;
    }

    @Override
    public void saveSteelBucket(SteelBucketSaveOrUpdateVO steelBucketSaveOrUpdateVO) {
        String orgCode = steelBucketSaveOrUpdateVO.getOrgCode();
        String bucketNo = steelBucketSaveOrUpdateVO.getBucketNo();
        String bucketType = steelBucketSaveOrUpdateVO.getBucketType();
        if (!BucketTypeEnum.BUCKET.getDictCode().equals(bucketType)) {
            throw new CloudmesException(SdsResultCode.MUST_BE_BUCKET_TYPE_DATA.getCode(),
                    MessageUtils.get(SdsResultCode.MUST_BE_BUCKET_TYPE_DATA.getLocalCode()));
        }
        checkBucketNo(bucketNo);
        String departmentCode = bucketNo.substring(0, 1).toUpperCase();
        checkDepartmentCode(orgCode, bucketNo, departmentCode);
        Long count = baseMapper.selectCount(Wrappers.<SdsSteelBucketInfo>lambdaQuery()
                .eq(SdsSteelBucketInfo::getBucketNo, bucketNo));
        if (count > 0) {
            throw new CloudmesException(SdsResultCode.BUCKET_NO_EXISTED_CAN_NOT_REPEAT.getCode(),
                    String.format(MessageUtils.get(SdsResultCode.BUCKET_NO_EXISTED_CAN_NOT_REPEAT.getLocalCode()),
                            bucketNo));
        }
        SdsSteelBucketInfo sdsSteelBucketInfo = new SdsSteelBucketInfo();
        BeanUtils.copyProperties(steelBucketSaveOrUpdateVO, sdsSteelBucketInfo);
        sdsSteelBucketInfo.setBucketNo(steelBucketSaveOrUpdateVO.getBucketNo().toUpperCase());
        sdsSteelBucketInfo.setDepartmentCode(departmentCode);
        SdsScrapSolidTypeConfig solidTypeConfigDb = getSolidTypeConfig(sdsSteelBucketInfo.getScrapDetailClass());
        sdsSteelBucketInfo.setIsScrapArea(solidTypeConfigDb.getIsScrapArea());
        sdsSteelBucketInfo.setScrapType(solidTypeConfigDb.getScrapType());
        baseMapper.insert(sdsSteelBucketInfo);
    }

    @Override
    public void updateSteelBucket(SteelBucketSaveOrUpdateVO steelBucketSaveOrUpdateVO) {
        String bucketNo = steelBucketSaveOrUpdateVO.getBucketNo();
        String orgCode = steelBucketSaveOrUpdateVO.getOrgCode();
        String bucketType = steelBucketSaveOrUpdateVO.getBucketType();
        if (!BucketTypeEnum.BUCKET.getDictCode().equals(bucketType)) {
            throw new CloudmesException(SdsResultCode.MUST_BE_BUCKET_TYPE_DATA.getCode(),
                    MessageUtils.get(SdsResultCode.MUST_BE_BUCKET_TYPE_DATA.getLocalCode()));
        }
        checkBucketNo(bucketNo);
        String departmentCode = bucketNo.substring(0, 1).toUpperCase();
        checkDepartmentCode(orgCode, bucketNo, departmentCode);
        Integer id = steelBucketSaveOrUpdateVO.getId();
        SdsSteelBucketInfo sdsSteelBucketInfoDb = baseMapper.selectOne(Wrappers.<SdsSteelBucketInfo>lambdaQuery()
                .eq(SdsSteelBucketInfo::getBucketNo, bucketNo));
        if (ObjectUtil.isNotNull(sdsSteelBucketInfoDb)) {
            if (!id.equals(sdsSteelBucketInfoDb.getId())) {
                throw new CloudmesException(SdsResultCode.BUCKET_NO_REPEAT.getCode(),
                        String.format(MessageUtils.get(SdsResultCode.BUCKET_NO_REPEAT.getLocalCode()),
                                bucketNo));
            }
        }
        SdsSteelBucketInfo sdsSteelBucketInfo = new SdsSteelBucketInfo();
        BeanUtils.copyProperties(steelBucketSaveOrUpdateVO, sdsSteelBucketInfo);
        sdsSteelBucketInfo.setBucketNo(steelBucketSaveOrUpdateVO.getBucketNo().toUpperCase());
        sdsSteelBucketInfo.setDepartmentCode(departmentCode);
        SdsScrapSolidTypeConfig solidTypeConfigDb = getSolidTypeConfig(sdsSteelBucketInfo.getScrapDetailClass());
        sdsSteelBucketInfo.setIsScrapArea(solidTypeConfigDb.getIsScrapArea());
        sdsSteelBucketInfo.setScrapType(solidTypeConfigDb.getScrapType());
        baseMapper.updateById(sdsSteelBucketInfo);
    }

    @NotNull
    private SdsScrapSolidTypeConfig getSolidTypeConfig(String scrapDetailClass) {
        SdsScrapSolidTypeConfig solidTypeConfigDb = sdsScrapSolidTypeConfigMapper
                .selectOne(Wrappers.<SdsScrapSolidTypeConfig>lambdaQuery()
                        .eq(SdsScrapSolidTypeConfig::getScrapDetailClass, scrapDetailClass)
                        .last("limit 1"));
        if (ObjectUtil.isNull(solidTypeConfigDb)) {
            throw new CloudmesException(SdsResultCode.NOT_FOUND_SCRAP_DETAIL_CONFIG.getCode(),
                    String.format(MessageUtils.get(SdsResultCode.NOT_FOUND_SCRAP_DETAIL_CONFIG.getLocalCode()),
                            scrapDetailClass));
        }
        return solidTypeConfigDb;
    }

    private void checkDepartmentCode(String orgCode, String bucketNo, String departmentCode) {
        Long departmentCodeCount = sdsDepartmentConfigMapper.selectCount(Wrappers.<SdsDepartmentConfig>lambdaQuery()
                .eq(SdsDepartmentConfig::getOrgCode, orgCode)
                .eq(SdsDepartmentConfig::getDepartmentCode, departmentCode));
        if (departmentCodeCount == 0) {
            throw new CloudmesException(SdsResultCode.NOT_FOUND_DEPARTMENT_CODE_CONFIG.getCode(),
                    String.format(MessageUtils.get(SdsResultCode.NOT_FOUND_DEPARTMENT_CODE_CONFIG.getLocalCode()),
                            bucketNo, departmentCode));
        }
    }

    private void checkBucketNo(String bucketNo) {
        if (bucketNo.length() != 11) {
            throw new CloudmesException(SdsResultCode.BUCKET_NO_LENGTH_MUST_BE_ELEVEN.getCode(),
                    String.format(MessageUtils.get(SdsResultCode.BUCKET_NO_LENGTH_MUST_BE_ELEVEN.getLocalCode()),
                            bucketNo));
        }
    }

    @Override
    public void deleteSteelBucket(Integer id) {
        baseMapper.deleteById(id);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void importSteelBucket(SteelBucketExcelImportVO excelImportVO) {
        MultipartFile file = excelImportVO.getFile();
        String orgCode = excelImportVO.getOrgCode();
        String bucketType = excelImportVO.getBucketType();
        if (!BucketTypeEnum.BUCKET.getDictCode().equals(bucketType)) {
            throw new CloudmesException(SdsResultCode.MUST_BE_BUCKET_TYPE_DATA.getCode(),
                    MessageUtils.get(SdsResultCode.MUST_BE_BUCKET_TYPE_DATA.getLocalCode()));
        }
        String originalFilename = file.getOriginalFilename();
        if (StrUtil.isEmpty(originalFilename)) {
            throw new CloudmesException(SdsResultCode.FILE_NOT_NULL.getCode(),
                    MessageUtils.get(SdsResultCode.FILE_NOT_NULL.getLocalCode()));
        }
        //获取文件后缀
        String fileSuffix = StrUtil.sub(originalFilename, StrUtil.lastIndexOfIgnoreCase(originalFilename, "."),
                originalFilename.length());
        if (!EXCEL_FILE_TYPE.contains(fileSuffix)) {
            throw new CloudmesException(SdsResultCode.WRONG_FILE_TYPE.getCode(),
                    MessageUtils.get(SdsResultCode.WRONG_FILE_TYPE.getLocalCode()));
        }
        SteelBucketImportListener steelBucketImportListener = new SteelBucketImportListener();
        try {
            EasyExcel.read(new BufferedInputStream(file.getInputStream()), steelBucketImportListener)
                    .head(SteelBucketImportVO.class).sheet().doReadSync();
        } catch (IOException e) {
            log.error("托盘信息上传excel导入异常");
            throw new CloudmesException(SdsResultCode.EXCEL_PARSE_ERROR.getCode(),
                    MessageUtils.get(SdsResultCode.EXCEL_PARSE_ERROR.getLocalCode()));
        }
        List<SteelBucketImportVO> steelBucketImportVOList = steelBucketImportListener
                .getSteelBucketImportVOList();
        if (CollUtil.isEmpty(steelBucketImportVOList)) {
            throw new CloudmesException(SdsResultCode.EXCEL_IMPORT_INFORMATION_IS_EMPTY.getCode(),
                    MessageUtils.get(SdsResultCode.EXCEL_IMPORT_INFORMATION_IS_EMPTY.getLocalCode()));
        }
        List<String> errorList = steelBucketImportListener.getError();
        if (CollUtil.isNotEmpty(errorList)) {
            throw new CloudmesException(ResultCode.FAILURE.getCode(), errorList.toString());
        }
        Map<String, List<SteelBucketImportVO>> collect = steelBucketImportVOList.stream()
                .collect(Collectors.groupingBy(SteelBucketImportVO::getBucketNo));
        for (Map.Entry<String, List<SteelBucketImportVO>> entry : collect.entrySet()) {
            StringBuilder msg = new StringBuilder();
            String bucketNo = entry.getKey();
            if (bucketNo.length() != 11) {
                msg.append(String.format(MessageUtils.get(SdsResultCode
                        .BUCKET_NO_LENGTH_MUST_BE_ELEVEN.getLocalCode()), bucketNo));
            }
            List<SteelBucketImportVO> importVOList = entry.getValue();
            if (importVOList.size() > 1) {
                msg.append(String.format(MessageUtils.get(SdsResultCode
                        .BUCKET_NO_REPEAT.getLocalCode()), bucketNo));
            }
            if (msg.length() > 0) {
                msg.append(";");
                errorList.add(msg.toString());
            }
        }
        if (CollUtil.isNotEmpty(errorList)) {
            throw new CloudmesException(ResultCode.FAILURE.getCode(), errorList.toString());
        }
        List<SdsSteelBucketInfo> sdsSteelBucketInfoList = CollUtil.newArrayList();
        for (SteelBucketImportVO steelBucketImportVO : steelBucketImportVOList) {
            String bucketNo = steelBucketImportVO.getBucketNo();
            String departmentCode = bucketNo.substring(0, 1).toUpperCase();
            checkDepartmentCode(orgCode, bucketNo, departmentCode);
            String scrapDetailClass = bucketNo.substring(5, 7);
            SdsScrapSolidTypeConfig solidTypeConfig = getSolidTypeConfig(scrapDetailClass);
            Long count = baseMapper.selectCount(Wrappers.<SdsSteelBucketInfo>lambdaQuery()
                    .eq(SdsSteelBucketInfo::getBucketNo, bucketNo));
            if (count > 0) {
                throw new CloudmesException(SdsResultCode.BUCKET_NO_EXISTED_CAN_NOT_REPEAT.getCode(),
                        String.format(MessageUtils.get(SdsResultCode.BUCKET_NO_EXISTED_CAN_NOT_REPEAT.getLocalCode()),
                                bucketNo));
            }
            SdsSteelBucketInfo sdsSteelBucketInfo = new SdsSteelBucketInfo();
            BeanUtils.copyProperties(steelBucketImportVO, sdsSteelBucketInfo);
            sdsSteelBucketInfo.setBucketType(bucketType);
            sdsSteelBucketInfo.setOrgCode(orgCode);
            sdsSteelBucketInfo.setDepartmentCode(departmentCode);
            sdsSteelBucketInfo.setScrapDetailClass(scrapDetailClass);
            sdsSteelBucketInfo.setIsScrapArea(solidTypeConfig.getIsScrapArea());
            sdsSteelBucketInfo.setScrapType(solidTypeConfig.getScrapType());
            sdsSteelBucketInfoList.add(sdsSteelBucketInfo);
        }
        this.saveBatch(sdsSteelBucketInfoList);
    }

    @Override
    public void exportSteelBucket(HttpServletResponse response, SteelBucketQueryVO queryVO) {
        List<SteelBucketExportDTO> exportDTOList = CollUtil.newArrayList();
        List<SteelBucketDTO> steelBucketDTOList = getSteelBucketDTOList(queryVO);
        steelBucketDTOList.forEach(steelBucketDTO -> {
            SteelBucketExportDTO steelBucketExportDTO = new SteelBucketExportDTO();
            BeanUtils.copyProperties(steelBucketDTO, steelBucketExportDTO);
            exportDTOList.add(steelBucketExportDTO);
        });
        String fileName = "托盘信息" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), SteelBucketExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.STEEL_BUCKET_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.STEEL_BUCKET_EXPORT_FAIL.getLocalCode()));
        }
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public BucketNoPrintDTO printBucketNoInfo(BucketNoPrintVO bucketNoPrintVO) {
        String orgCode = bucketNoPrintVO.getOrgCode();
        BigDecimal bucketWeight = bucketNoPrintVO.getBucketWeight();
        String printTemplateId = bucketNoPrintVO.getPrintTemplateId();
        String scrapType = bucketNoPrintVO.getScrapType();
        //如果传入模板id为空，则查询配置表中配置的模板id
        if (StrUtil.isEmpty(printTemplateId)) {
            SdsPrintTemplateConfig sdsPrintTemplateConfig = sdsPrintTemplateConfigMapper
                    .selectOne(Wrappers.<SdsPrintTemplateConfig>lambdaQuery()
                            .eq(SdsPrintTemplateConfig::getOrgCode, orgCode)
                            .eq(SdsPrintTemplateConfig::getPrintType, PrintTypeEnum.BUCKET_PALLET.getDictCode())
                            .last("limit 1"));
            printTemplateId = sdsPrintTemplateConfig.getPrintTemplateId().toString();
        }
        //调用打印服务查询模板content以及模板类型
        PrintTemplateFeignDTO printTemplateFeignDTO = selectPrintTemplate(printTemplateId);
        Integer piece = bucketNoPrintVO.getPiece();
        HashMap<String, String> params = new HashMap<>();
        params.put("FACTORY", bucketNoPrintVO.getFactoryCode());
        params.put("BUILDING", bucketNoPrintVO.getBuilding());
        params.put("FLOOR", bucketNoPrintVO.getStorey().toString());
        params.put("SCRAPDETAIL", scrapType);
        //产生托盘编码
        R<List<String>> result = codeRuleClient.getSerialNumberAndParams(CodeRuleEnum.SDS_BUCKET_NO.getDictCode(),
                piece, params);
        if (result.getCode() != ResultCode.SUCCESS.getCode()) {
            throw new CloudmesException(SdsResultCode.CONNECT_BASIC_GET_SERIAL_NUMBER.getCode()
                    , MessageUtils.get(SdsResultCode.CONNECT_BASIC_GET_SERIAL_NUMBER.getLocalCode()));
        }
        List<String> bucketNoList = result.getData();
        List<SdsSteelBucketInfo> sdsSteelBucketInfoList = CollUtil.newArrayList();
        List<BucketNoDTO> bucketNoDTOList = CollUtil.newArrayList();
        SolidTypeConfigDTO solidTypeConfigDTO = sdsScrapSolidTypeConfigMapper
                .selectSolidTypeByDetailClass(scrapType);
        for (String bucketNo : bucketNoList) {
            BucketNoDTO bucketNoDTO = new BucketNoDTO();
            bucketNoDTO.setBucketNo(bucketNo);
            bucketNoDTO.setScrapDetailClass(solidTypeConfigDTO.getScrapDetailClassDesc());
            bucketNoDTOList.add(bucketNoDTO);
            SdsSteelBucketInfo sdsSteelBucketInfo = new SdsSteelBucketInfo();
            sdsSteelBucketInfo.setOrgCode(orgCode);
            sdsSteelBucketInfo.setBucketNo(bucketNo);
            sdsSteelBucketInfo.setBucketType(BucketTypeEnum.PALLET.getDictCode());
            sdsSteelBucketInfo.setBucketWeight(bucketWeight);
            sdsSteelBucketInfo.setScrapDetailClass(scrapType);
            sdsSteelBucketInfo.setIsScrapArea(solidTypeConfigDTO.getIsScrapArea());
            sdsSteelBucketInfo.setScrapType(solidTypeConfigDTO.getScrapType());
            sdsSteelBucketInfo.setDepartmentCode(bucketNoPrintVO.getFactoryCode());
            sdsSteelBucketInfoList.add(sdsSteelBucketInfo);
        }
        this.saveBatch(sdsSteelBucketInfoList);
        return BucketNoPrintDTO.builder()
                .data(bucketNoDTOList)
                .content(printTemplateFeignDTO.getContent())
                .type(printTemplateFeignDTO.getFileType())
                .build();
    }

    private PrintTemplateFeignDTO selectPrintTemplate(String printTemplateId) {
        R<PrintTemplateFeignDTO> templateResult = printTemplateClient
                .getFeignTemplateById(Integer.valueOf(printTemplateId));
        PrintTemplateFeignDTO printTemplateFeignDTO = templateResult.getData();
        if (ObjectUtil.isNull(printTemplateFeignDTO)) {
            throw new CloudmesException(SdsResultCode.PRINT_TEMPLATE_NOT_FIND.getCode()
                    , MessageUtils.get(SdsResultCode.PRINT_TEMPLATE_NOT_FIND.getLocalCode()));
        }
        return printTemplateFeignDTO;
    }
}
