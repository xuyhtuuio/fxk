package com.maxnerva.cloudmes.models.vo.waste;

import com.maxnerva.cloudmes.models.vo.CommonRequestVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @ClassName WasteDocInfoAppUploadCheckVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/28
 * @Version 1.0
 * @Since JDK 1.8
 **/
@EqualsAndHashCode(callSuper = true)
@ApiModel(value = "危废车间上传图片VO")
@Data
public class WasteDocInfoAppUploadCheckVO extends CommonRequestVO {

    @ApiModelProperty(value = "单号", required = true)
    private String docNo;
}
