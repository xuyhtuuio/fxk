package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName WasteTransferDocTypeEnum
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/27
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum WasteTransferDocTypeEnum {

    NORMAL_ORDER("NORMAL_ORDER","正常联单"),
    NO_INSTORAGE_ORDER("NO_INSTORAGE_ORDER","立产立清联单"),
    NORMAL_SUPPLY_RECORD("NORMAL_SUPPLY_RECORD","正常补录"),
    NO_INSTORAGE_SUPPLY_RECORD("NO_INSTORAGE_SUPPLY_RECORD","立产立清补录");


    private String dictCode;

    private String dictName;

    WasteTransferDocTypeEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (WasteTransferDocTypeEnum wasteTransferDocTypeEnum : values()) {
            if (wasteTransferDocTypeEnum.getDictCode().equals(dictCode)) {
                return wasteTransferDocTypeEnum.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

    /**
     * 提前判断，用于解决
     * Case中出现的Constant expression required
     *
     * @param dictCode 值
     * @return wasteTransferDocTypeEnum
     */
    public static WasteTransferDocTypeEnum getByValue(String dictCode) {
        for (WasteTransferDocTypeEnum wasteTransferDocTypeEnum : values()) {
            if (wasteTransferDocTypeEnum.getDictCode().equals(dictCode)) {
                return wasteTransferDocTypeEnum;
            }
        }
        return null;
    }
}
