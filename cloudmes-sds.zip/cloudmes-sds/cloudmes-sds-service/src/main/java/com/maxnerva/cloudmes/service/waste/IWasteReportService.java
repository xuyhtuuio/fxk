package com.maxnerva.cloudmes.service.waste;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.models.dto.waste.report.WasteInventoryDTO;
import com.maxnerva.cloudmes.models.dto.waste.report.WasteInventoryDetailDTO;
import com.maxnerva.cloudmes.models.dto.waste.report.WasteInventoryOverdueWarnDTO;
import com.maxnerva.cloudmes.models.vo.waste.report.WasteInventoryDetailQueryVO;
import com.maxnerva.cloudmes.models.vo.waste.report.WasteInventoryOverdueWarnQueryVO;
import com.maxnerva.cloudmes.models.vo.waste.report.WasteInventoryQueryVO;

import javax.servlet.http.HttpServletResponse;

/**
 * @ClassName IWasteReportService
 * @Description TODO
 * @Author Likun
 * @Date 2025/6/20
 * @Version 1.0
 * @Since JDK 1.8
 **/
public interface IWasteReportService {

    PageDataDTO<WasteInventoryDTO> selectWasteInventoryPage(WasteInventoryQueryVO queryVO);

    PageDataDTO<WasteInventoryDetailDTO> selectWasteInventoryDetailPage(WasteInventoryDetailQueryVO queryVO);

    void exportWasteInventory(HttpServletResponse response,WasteInventoryQueryVO queryVO);

    void exportWasteInventoryDetail(HttpServletResponse response,WasteInventoryDetailQueryVO queryVO);

    PageDataDTO<WasteInventoryOverdueWarnDTO> selectWasteInventoryOverdueWarnPage(
            WasteInventoryOverdueWarnQueryVO queryVO);

    void exportWasteInventoryOverdueWarnInfo(HttpServletResponse response,WasteInventoryOverdueWarnQueryVO queryVO);
}
