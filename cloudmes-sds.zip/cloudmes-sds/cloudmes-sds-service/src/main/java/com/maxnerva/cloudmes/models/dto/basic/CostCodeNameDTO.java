package com.maxnerva.cloudmes.models.dto.basic;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName CostCodeNameDTO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/13
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("费用代码信息查询dto")
@Data
public class CostCodeNameDTO {

    @ApiModelProperty("费用代码")
    private String costCode;

    @ApiModelProperty("部门名称")
    private String depName;
}
