package com.maxnerva.cloudmes.service.scrap.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.convert.NumberChineseFormatter;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.NumberUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.support.ExcelTypeEnum;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.excel.write.metadata.fill.FillConfig;
import com.alibaba.excel.write.metadata.fill.FillWrapper;
import com.alibaba.fastjson2.JSON;
import com.alibaba.nacos.api.naming.pojo.healthcheck.impl.Http;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.config.MinIOProperties;
import com.maxnerva.cloudmes.common.constant.BucketConstant;
import com.maxnerva.cloudmes.common.enums.ResultCode;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.common.utils.WebContextUtil;
import com.maxnerva.cloudmes.config.FlowNetUrlConfig;
import com.maxnerva.cloudmes.enums.CodeRuleEnum;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.enums.SteelScrapOperateType;
import com.maxnerva.cloudmes.excel.converter.LocalDateStringConverter;
import com.maxnerva.cloudmes.excel.converter.LocalDateTimeStringConverter;
import com.maxnerva.cloudmes.excel.handler.AddNoHandler;
import com.maxnerva.cloudmes.feign.basic.ICodeRuleClient;
import com.maxnerva.cloudmes.mapper.basic.SdsDepartmentConfigMapper;
import com.maxnerva.cloudmes.mapper.basic.SdsScrapSolidTypeConfigMapper;
import com.maxnerva.cloudmes.mapper.basic.SdsSteelMfgConfigMapper;
import com.maxnerva.cloudmes.mapper.basic.SdsSteelPaymentEndDateConfigMapper;
import com.maxnerva.cloudmes.mapper.scrap.*;
import com.maxnerva.cloudmes.models.dto.basic.CalcSteelPaymentOrderDeadlineDTO;
import com.maxnerva.cloudmes.models.dto.basic.FlownetResponse;
import com.maxnerva.cloudmes.models.dto.excel.scrap.SteelScrapShipHeaderByPaymentExportDTO;
import com.maxnerva.cloudmes.models.dto.excel.scrap.SteelScrapShipHeaderPaymentExportDTO;
import com.maxnerva.cloudmes.models.dto.scrap.PaymentOrderExcelRootDTO;
import com.maxnerva.cloudmes.models.dto.scrap.PaymentUploadDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelScrapShipHeaderByPaymentDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelScrapShipHeaderPaymentDTO;
import com.maxnerva.cloudmes.models.entity.basic.*;
import com.maxnerva.cloudmes.models.entity.scrap.*;
import com.maxnerva.cloudmes.models.vo.basic.FlowNetEmailVO;
import com.maxnerva.cloudmes.models.vo.scrap.*;
import com.maxnerva.cloudmes.service.basic.ISdsSteelPaymentEndDateConfigService;
import com.maxnerva.cloudmes.service.basic.impl.SdsFileDownloadLogService;
import com.maxnerva.cloudmes.service.scrap.ISdsSteelPaymentSalesSummaryService;
import com.maxnerva.cloudmes.service.scrap.ISdsSteelPaymentSplitInfoService;
import com.maxnerva.cloudmes.service.scrap.ISteelPaymentOrderService;
import com.maxnerva.cloudmes.system.feign.IUploadFileClient;
import com.maxnerva.cloudmes.system.models.dto.UploadFileRespDTO;
import com.maxnerva.cloudmes.system.models.vo.FileUploadVO;
import com.maxnerva.cloudmes.system.utils.DictLangUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class SteelPaymentOrderService implements ISteelPaymentOrderService {

    @Autowired
    SdsSteelScrapShipHeaderMapper steelScrapShipHeaderMapper;

    @Autowired
    SdsSteelScrapWeightInfoMapper steelScrapWeightInfoMapper;

    @Autowired
    SdsSteelMfgConfigMapper steelMfgConfigMapper;

    @Autowired
    ISdsSteelPaymentEndDateConfigService steelPaymentEndDateConfigService;

    @Autowired
    SdsSteelPaymentEndDateConfigMapper steelPaymentEndDateConfigMapper;

    @Autowired
    SdsSteelPaymentHeaderMapper steelPaymentHeaderMapper;

    @Autowired
    SdsScrapSolidTypeConfigMapper scrapSolidTypeConfigMapper;

    @Autowired
    SdsDepartmentConfigMapper departmentConfigMapper;

    @Autowired
    SdsSteelPaymentSplitInfoMapper steelPaymentSplitInfoMapper;

    @Autowired
    ICodeRuleClient codeRuleClient;

    @Autowired
    DictLangUtils dictLangUtils;

    @Autowired
    SdsSteelPaymentSalesSummaryMapper steelPaymentSalesSummaryMapper;

    @Autowired
    ISdsSteelPaymentSplitInfoService steelPaymentSplitInfoService;

    @Autowired
    ISdsSteelPaymentSalesSummaryService steelPaymentSalesSummaryService;

    @Autowired
    FlowNetUrlConfig flowNetUrlConfig;

    @Autowired
    SdsManagementMfgSendMailConfigMapper managementMfgSendMailConfigMapper;

    @Autowired
    IUploadFileClient uploadFileClient;

    @Autowired
    SdsSteelPaymentHeaderMapper sdsSteelPaymentHeaderMapper;

    @Autowired
    MinIOProperties minIOProperties;

    @Autowired
    SdsWeightPictureService sdsWeightPictureService;

    @Autowired
    SdsFileDownloadLogService sdsFileDownloadLogService;

    @Override
    public PageDataDTO<SteelScrapShipHeaderPaymentDTO> shipHeaderPageList(SteelScrapShipHeaderPaymentQueryVO vo, Boolean isPage) {
        vo.setStartDateTime(LocalDateTime.parse(vo.getStartDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd 00:00:00")), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        vo.setEndDateTime(LocalDateTime.parse(vo.getEndDate().plusDays(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd 00:00:00")), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        Page page = new Page();
        if (BooleanUtil.isTrue(isPage)) {
            page = PageHelper.startPage(vo.getPageIndex(), vo.getPageSize());
        }
        List<SteelScrapShipHeaderPaymentDTO> list = steelScrapShipHeaderMapper.selectPaymentPageList(vo);
        SdsSteelMfgConfig mfgConfig = steelMfgConfigMapper.selectOne(Wrappers.<SdsSteelMfgConfig>lambdaQuery()
                .eq(SdsSteelMfgConfig::getMfgCode, vo.getMfgCode())
                .last("limit 1")
        );

        list.forEach(item -> {
            item.setManFacturer(mfgConfig.getManFacturer());
        });
        return new PageDataDTO(page.getTotal(), list);
    }

    @Override
    public void exportShipHeaderPageList(SteelScrapShipHeaderPaymentQueryVO vo, HttpServletResponse response) {
        PageDataDTO<SteelScrapShipHeaderPaymentDTO> pageDataDTO = shipHeaderPageList(vo, Boolean.FALSE);
        List<SteelScrapShipHeaderPaymentExportDTO> exportDTOList = ListUtil.toList();
        pageDataDTO.getList().forEach(item -> {
            SteelScrapShipHeaderPaymentExportDTO dto = new SteelScrapShipHeaderPaymentExportDTO();
            BeanUtil.copyProperties(item, dto);
            exportDTOList.add(dto);
        });

        String fileName = "固废出货单待生成缴款单明细" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), SteelScrapShipHeaderPaymentExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getLocalCode()));
        }
    }

    @Override
    public PageDataDTO<SteelScrapShipHeaderByPaymentDTO> shipHeaderByPaymentPageList(SteelScrapShipHeaderByPaymentQueryVO vo, Boolean isPage) {
        Page page = new Page();
        if (BooleanUtil.isTrue(isPage)) {
            page = PageHelper.startPage(vo.getPageIndex(), vo.getPageSize());
        }
        List<SteelScrapShipHeaderByPaymentDTO> list = steelScrapShipHeaderMapper.selectByPaymentPageList(vo);
        Map<String, String> scrapDetailClassDictMap = dictLangUtils.getByType("SDS_SCRAP_SOLID");
        SdsSteelPaymentHeader steelPaymentHeader = steelPaymentHeaderMapper.selectOne(Wrappers.<SdsSteelPaymentHeader>lambdaQuery()
                .eq(SdsSteelPaymentHeader::getDocNo, vo.getPaymentDocNo())
                .last("limit 1")
        );
        list.forEach(item -> {
            item.setManFacturer(steelPaymentHeader.getManFacturer());
            item.setScrapDetailClassName(scrapDetailClassDictMap.get(item.getScrapDetailClass()));
            item.setTotalPrice(item.getScrapNetWeight().multiply(item.getPrice()));
        });
        return new PageDataDTO(page.getTotal(), list);
    }

    @Override
    public void exportShipHeaderByPaymentPageList(SteelScrapShipHeaderByPaymentQueryVO vo, HttpServletResponse response) {
        PageDataDTO<SteelScrapShipHeaderByPaymentDTO> pageDataDTO = shipHeaderByPaymentPageList(vo, Boolean.FALSE);
        List<SteelScrapShipHeaderByPaymentExportDTO> exportDTOList = ListUtil.toList();
        pageDataDTO.getList().forEach(item -> {
            SteelScrapShipHeaderByPaymentExportDTO dto = new SteelScrapShipHeaderByPaymentExportDTO();
            BeanUtil.copyProperties(item, dto);
            exportDTOList.add(dto);
        });

        String fileName = "固废缴款单关联出库明细" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), SteelScrapShipHeaderByPaymentExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getLocalCode()));
        }
    }

    @Override
    public List<PaymentUploadDTO> deleteFile(DeleteFileVO deleteFileVO) {
        // 锁单号
        sdsSteelPaymentHeaderMapper.update(null, Wrappers.<SdsSteelPaymentHeader>lambdaUpdate()
                .setSql("file_list = file_list")
                .eq(SdsSteelPaymentHeader::getDocNo, deleteFileVO.getDocNo())
        );

        SdsSteelPaymentHeader sdsSteelPaymentHeader = sdsSteelPaymentHeaderMapper.selectOne(Wrappers.<SdsSteelPaymentHeader>lambdaQuery()
                .eq(SdsSteelPaymentHeader::getDocNo, deleteFileVO.getDocNo())
        );

        String fileList = sdsSteelPaymentHeader.getFileList();
        if (StrUtil.isNotBlank(fileList)) {
            Set<Integer> deleteIdSet = deleteFileVO.getIdList().stream().collect(Collectors.toSet());
            List<PaymentUploadDTO> scrapFileDTOList = JSONUtil.toList(fileList, PaymentUploadDTO.class);
            List<PaymentUploadDTO> newScrapFileList = scrapFileDTOList.stream()
                    .filter(item -> !deleteIdSet.contains(item.getFileId())).collect(Collectors.toList());
            sdsSteelPaymentHeaderMapper.update(null, Wrappers.<SdsSteelPaymentHeader>lambdaUpdate()
                    .set(SdsSteelPaymentHeader::getFileList, CollUtil.isNotEmpty(newScrapFileList) ? JSONUtil.toJsonStr(newScrapFileList) : null)
                    .set(SdsSteelPaymentHeader::getLastEditor, WebContextUtil.getCurrentStaffCode())
                    .set(SdsSteelPaymentHeader::getLastEditedDt, LocalDateTime.now())
                    .eq(SdsSteelPaymentHeader::getDocNo, deleteFileVO.getDocNo())
            );
            newScrapFileList.forEach(item -> {
                item.setUrl(minIOProperties.getFileAddrForAuth(BucketConstant.CLOUD_SAAS, item.getUrl()));
            });
            return newScrapFileList;
        }
        return ListUtil.toList();
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public String createPaymentOrderByShipHeader(SteelScrapShipHeaderPaymentQueryVO vo) {
        PageDataDTO<SteelScrapShipHeaderPaymentDTO> pageDataDTO = shipHeaderPageList(vo, Boolean.FALSE);
        List<SteelScrapShipHeaderPaymentDTO> steelScrapShipHeaderPaymentDTOList = pageDataDTO.getList();

        if (CollUtil.isEmpty(steelScrapShipHeaderPaymentDTOList)) {
            throw new CloudmesException("该厂商在当前时间段里，没有已完成出货的出货单信息");
        }

        //产生盘点编码
        R<List<String>> result = codeRuleClient.getSerialNumber(CodeRuleEnum.SDS_SCRAP_PAYMENT_NO.getDictCode(), 1);
        if (result.getCode() != ResultCode.SUCCESS.getCode()) {
            throw new CloudmesException(SdsResultCode.CONNECT_BASIC_GET_SERIAL_NUMBER.getCode()
                    , MessageUtils.get(SdsResultCode.CONNECT_BASIC_GET_SERIAL_NUMBER.getLocalCode()));
        }
        List<String> inventoryPlanNoList = result.getData();
        String paymentDocNo = inventoryPlanNoList.get(0);

        LocalDate startDate = vo.getStartDate();
        LocalDate finishDate = vo.getEndDate();
        LocalDateTime actualStartDateTime = vo.getStartDateTime();
        LocalDateTime actualFinishDateTime = vo.getEndDateTime();

        BigDecimal sales = BigDecimal.ZERO;
        for (SteelScrapShipHeaderPaymentDTO scrapShipHeaderPaymentDTO : steelScrapShipHeaderPaymentDTOList) {
            sales = sales.add(scrapShipHeaderPaymentDTO.getPrice().multiply(scrapShipHeaderPaymentDTO.getScrapNetWeight()));
        }
        sales = sales.setScale(2, RoundingMode.HALF_UP);
        SdsSteelMfgConfig steelMfgConfig = steelMfgConfigMapper.selectOne(Wrappers.<SdsSteelMfgConfig>lambdaQuery()
                .eq(SdsSteelMfgConfig::getMfgCode, vo.getMfgCode())
                .last("limit 1")
        );

        BigDecimal salesPercentage = sales.divide(steelMfgConfig.getPrePayment(), 10, RoundingMode.DOWN);

        CalcSteelPaymentOrderDeadlineDTO calcSteelPaymentOrderDeadlineDTO = steelPaymentEndDateConfigService.calcPaymentOrderDeadline(vo.getMfgCode(), finishDate, salesPercentage);

        SdsSteelPaymentHeader steelPaymentHeader = new SdsSteelPaymentHeader();
        steelPaymentHeader.setId(null);
        steelPaymentHeader.setDocNo(paymentDocNo);
        steelPaymentHeader.setManFacturer(steelMfgConfig.getManFacturer());
        steelPaymentHeader.setBank(steelMfgConfig.getBank());
        steelPaymentHeader.setBankAccount(steelMfgConfig.getBankAccount());
        steelPaymentHeader.setCollectionCompany(steelMfgConfig.getCollectionCompany());
        steelPaymentHeader.setEndDate(calcSteelPaymentOrderDeadlineDTO.getEndDate());
        steelPaymentHeader.setEndDateTxt(calcSteelPaymentOrderDeadlineDTO.getEndDateTxt());
        steelPaymentHeader.setSales(sales);
        String salesTxt = NumberChineseFormatter.format(sales.doubleValue(), true, true);
        steelPaymentHeader.setSalesTxt(salesTxt);
        steelPaymentHeader.setStartDate(startDate);
        steelPaymentHeader.setStartDateTxt(startDate.format(DateTimeFormatter.ofPattern(steelMfgConfig.getPaymentOrderDateTemplate())));
        steelPaymentHeader.setFinishDate(finishDate);
        steelPaymentHeader.setFinishDateTxt(finishDate.format(DateTimeFormatter.ofPattern(steelMfgConfig.getPaymentOrderDateTemplate())));
        steelPaymentHeader.setPrePayment(steelMfgConfig.getPrePayment());
        steelPaymentHeader.setRemark(steelMfgConfig.getPaymentOrderRemark());
        steelPaymentHeader.setMfgCode(vo.getMfgCode());
        steelPaymentHeader.setIsSendMail("N");
        steelPaymentHeaderMapper.insert(steelPaymentHeader);

        // 出库单赋值缴款单号
        List<Integer> shipHeaderIdList = steelScrapShipHeaderPaymentDTOList.stream().map(item -> item.getId()).collect(Collectors.toList());
        steelScrapShipHeaderMapper.update(null, Wrappers.<SdsSteelScrapShipHeader>lambdaUpdate()
                .set(SdsSteelScrapShipHeader::getPaymentDocNo, paymentDocNo)
                .in(SdsSteelScrapShipHeader::getId, shipHeaderIdList)
        );

        // 根据开始和结束日期和厂商出库单中的废料类别将入废料厂数据塞缴款单号
        List<String> scrapDetailClassList = steelScrapShipHeaderPaymentDTOList.stream()
                .map(item -> item.getScrapDetailClass())
                .distinct().collect(Collectors.toList());
        List<SdsSteelScrapWeightInfo> steelScrapWeightInfoList = steelScrapWeightInfoMapper.selectList(Wrappers.<SdsSteelScrapWeightInfo>lambdaQuery()
                // !!!
                .select(SdsSteelScrapWeightInfo::getRubbishNetWeight, SdsSteelScrapWeightInfo::getId, SdsSteelScrapWeightInfo::getDepartmentCode, SdsSteelScrapWeightInfo::getScrapDetailClass)
                .in(SdsSteelScrapWeightInfo::getScrapDetailClass, scrapDetailClassList)
                .eq(SdsSteelScrapWeightInfo::getRubbishWeighFlag, "Y")
                .and(t -> t.eq(SdsSteelScrapWeightInfo::getPaymentDocNo, StrUtil.EMPTY).or().isNull(SdsSteelScrapWeightInfo::getPaymentDocNo))
                .ge(SdsSteelScrapWeightInfo::getRubbishWeighDt, actualStartDateTime)
                .lt(SdsSteelScrapWeightInfo::getRubbishWeighDt, actualFinishDateTime)
        );

        if (CollUtil.isEmpty(steelScrapWeightInfoList)) {
            throw new CloudmesException(String.format("%s到%s期间没有废料类别%s的入废料厂记录", startDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")),
                    finishDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")),
                    scrapDetailClassList.stream().collect(Collectors.joining(","))));
        }

        // 称重记录赋值缴款单号
        List<Integer> steelScrapWeightIdList = steelScrapWeightInfoList.stream().map(item -> item.getId()).collect(Collectors.toList());
        steelScrapWeightInfoMapper.update(null, Wrappers.<SdsSteelScrapWeightInfo>lambdaUpdate()
                .set(SdsSteelScrapWeightInfo::getPaymentDocNo, paymentDocNo)
                .in(SdsSteelScrapWeightInfo::getId, steelScrapWeightIdList)
        );

        BigDecimal totalNetWeight = steelScrapWeightInfoList.stream().map(item -> item.getRubbishNetWeight()).reduce(BigDecimal.ZERO, BigDecimal::add);

        List<SdsDepartmentConfig> departmentConfigList = departmentConfigMapper.selectList(Wrappers.<SdsDepartmentConfig>lambdaQuery());
        Map<String, SdsDepartmentConfig> departmentConfigMap = departmentConfigList.stream().collect(Collectors.toMap(k -> k.getDepartmentCode(), v -> v));

        // 入废料厂记录按厂部分组
        Map<String, List<SdsSteelScrapWeightInfo>> departmentCodeWeightInfoMap = steelScrapWeightInfoList.stream().collect(Collectors.groupingBy(SdsSteelScrapWeightInfo::getDepartmentCode));

        BigDecimal totalPercentage = BigDecimal.ONE;
        BigDecimal totalSales = sales;
        List<String> departmentCodeList = departmentCodeWeightInfoMap.keySet().stream().collect(Collectors.toList());
        List<SdsSteelPaymentSplitInfo> paymentSplitInfoList = ListUtil.toList();
        for (int i = 0; i < departmentCodeList.size(); i++) {
            String departmentCode = departmentCodeList.get(i);
            List<SdsSteelScrapWeightInfo> weightInfoList = departmentCodeWeightInfoMap.get(departmentCode);
            SdsDepartmentConfig departmentConfig = departmentConfigMap.get(departmentCode);
            String costCode = departmentConfig.getCostCode();
            BigDecimal departmentTotalNetWeight = weightInfoList.stream().map(item -> item.getRubbishNetWeight()).reduce(BigDecimal.ZERO, BigDecimal::add);
            BigDecimal percentage = departmentTotalNetWeight.divide(totalNetWeight, 4, RoundingMode.DOWN);
            if (i == departmentCodeList.size() - 1) {
                percentage = totalPercentage;
            }
            totalPercentage = totalPercentage.subtract(percentage);
            BigDecimal departmentSales = percentage.multiply(totalSales);
            SdsSteelPaymentSplitInfo steelPaymentSplitInfo = new SdsSteelPaymentSplitInfo();
            steelPaymentSplitInfo.setCostCode(costCode);
            steelPaymentSplitInfo.setDepartmentCode(departmentCode);
            steelPaymentSplitInfo.setInStoreNetWeight(departmentTotalNetWeight);
            steelPaymentSplitInfo.setInStorePercentage(percentage);
            steelPaymentSplitInfo.setSplitAccount(departmentSales);
            steelPaymentSplitInfo.setPaymentDocNo(paymentDocNo);
            steelPaymentSplitInfo.setId(null);
            paymentSplitInfoList.add(steelPaymentSplitInfo);
        }
        steelPaymentSplitInfoService.saveBatch(paymentSplitInfoList, 500);

        // 报废类别->ecus废料名称
        Map<String, String> scrapDetailClassScrapPartNameMap = steelScrapShipHeaderPaymentDTOList.stream().collect(Collectors.toMap(k -> k.getScrapDetailClass(), v -> v.getScrapPartName(), (l, r) -> l));
        Map<String, String> departmentCodeCostCodeMap = departmentConfigList.stream().collect(Collectors.toMap(k -> k.getDepartmentCode(), v -> v.getCostCode()));
        // 费用代码_报废类别->weightInfo[]
        Map<String, List<SdsSteelScrapWeightInfo>> weightInfoGroupMap = steelScrapWeightInfoList.stream().collect(Collectors.groupingBy((SdsSteelScrapWeightInfo k) ->
                StrUtil.concat(true, departmentCodeCostCodeMap.get(k.getDepartmentCode()), "_", k.getScrapDetailClass())));
        // 报废类别->总入废料厂净重
        Map<String, BigDecimal> scrapDetailClassTotalNetWeightMap = steelScrapWeightInfoList.stream()
                .collect(Collectors.groupingBy(SdsSteelScrapWeightInfo::getScrapDetailClass, Collectors.collectingAndThen(Collectors.toList(), list ->
                        list.stream().map(item -> item.getRubbishNetWeight()).reduce(BigDecimal.ZERO, BigDecimal::add))));
        List<SdsSteelPaymentSalesSummary> steelPaymentSalesSummaryList = ListUtil.toList();
        weightInfoGroupMap.values().forEach(weightInfoList -> {
            String scrapDetailClass = weightInfoList.get(0).getScrapDetailClass();
            BigDecimal inStoreNetWeight = weightInfoList.stream().map(item -> item.getRubbishNetWeight()).reduce(BigDecimal.ZERO, BigDecimal::add);
            String costCode = departmentCodeCostCodeMap.get(weightInfoList.get(0).getDepartmentCode());
            String scrapPartName = scrapDetailClassScrapPartNameMap.get(scrapDetailClass);
            SdsSteelPaymentSalesSummary steelPaymentSalesSummary = new SdsSteelPaymentSalesSummary();
            steelPaymentSalesSummary.setPaymentDocNo(paymentDocNo);
            steelPaymentSalesSummary.setCostCode(costCode);
            steelPaymentSalesSummary.setScrapPartName(scrapPartName);
            steelPaymentSalesSummary.setInStoreNetWeight(inStoreNetWeight);
            steelPaymentSalesSummary.setScrapDetailClass(weightInfoList.get(0).getScrapDetailClass());
            steelPaymentSalesSummaryList.add(steelPaymentSalesSummary);
        });

        Map<String, List<SdsSteelPaymentSalesSummary>> scrapDetailClassSalesSummaryGroupMap = steelPaymentSalesSummaryList
                .stream().collect(Collectors.groupingBy(SdsSteelPaymentSalesSummary::getScrapDetailClass));
        // 报废类别->总出货销售额
        Map<String, BigDecimal> scrapDetailClassShipTotalSales = steelScrapShipHeaderPaymentDTOList.stream().collect(Collectors.groupingBy(SteelScrapShipHeaderPaymentDTO::getScrapDetailClass, Collectors.collectingAndThen(
                Collectors.toList(), list -> list.stream().map(item -> item.getPrice().multiply(item.getScrapNetWeight())).reduce(BigDecimal.ZERO, BigDecimal::add)
        )));
        // 报废类别->总出货净重
        Map<String, BigDecimal> scrapDetailClassShipTotalNetWeight = steelScrapShipHeaderPaymentDTOList.stream().collect(Collectors.groupingBy(SteelScrapShipHeaderPaymentDTO::getScrapDetailClass, Collectors.collectingAndThen(
                Collectors.toList(), list -> list.stream().map(item -> item.getScrapNetWeight()).reduce(BigDecimal.ZERO, BigDecimal::add)
        )));
        scrapDetailClassSalesSummaryGroupMap.keySet().stream().forEach(scrapDetailClass -> {
            BigDecimal scrapDetailClassTotalNetWeight = scrapDetailClassTotalNetWeightMap.get(scrapDetailClass);
            BigDecimal totalSalesPercentage = BigDecimal.ONE;
            List<SdsSteelPaymentSalesSummary> list = scrapDetailClassSalesSummaryGroupMap.get(scrapDetailClass);
            BigDecimal totalShipAccount = scrapDetailClassShipTotalSales.get(scrapDetailClass);
            BigDecimal remainTotalShipAccount = totalShipAccount;
            BigDecimal totalShipNetWeight = scrapDetailClassShipTotalNetWeight.get(scrapDetailClass);
            BigDecimal remainTotalShipNetWeight = totalShipNetWeight;
            for (int i = 0; i < list.size(); i++) {
                SdsSteelPaymentSalesSummary steelPaymentSalesSummary = list.get(i);
                // 入库占比
                BigDecimal percentage = steelPaymentSalesSummary.getInStoreNetWeight().divide(scrapDetailClassTotalNetWeight, 4, RoundingMode.DOWN);
                if (i == list.size() - 1) {
                    percentage = totalSalesPercentage;
                }

//                BigDecimal splitShipAccount = percentage.multiply(totalShipAccount).setScale(2, RoundingMode.DOWN);
//                if (i == list.size() - 1) {
//                    splitShipAccount = remainTotalShipAccount;
//                }
                BigDecimal splitShipAccount = percentage.multiply(totalShipAccount);

//                BigDecimal splitShipNetWeight = percentage.multiply(totalShipNetWeight);
//                if (i == list.size() - 1) {
//                    splitShipNetWeight = remainTotalShipNetWeight;
//                }
                BigDecimal splitShipNetWeight = percentage.multiply(totalShipNetWeight);

                steelPaymentSalesSummary.setInStorePercentage(percentage);
                steelPaymentSalesSummary.setSplitShipAccount(splitShipAccount);
                steelPaymentSalesSummary.setSplitShipNetWeight(splitShipNetWeight);
                remainTotalShipAccount = remainTotalShipAccount.subtract(splitShipAccount);
                remainTotalShipNetWeight = remainTotalShipNetWeight.subtract(splitShipNetWeight);
                totalSalesPercentage = totalSalesPercentage.subtract(percentage);
            }

        });
        steelPaymentSalesSummaryService.saveBatch(steelPaymentSalesSummaryList, 500);


        return paymentDocNo;
    }

    @Override
    public void exportPaymentOrderExcel(PaymentOrderExcelExportVO vo, HttpServletResponse response) {
        SdsSteelPaymentHeader steelPaymentHeader = steelPaymentHeaderMapper.selectOne(Wrappers.<SdsSteelPaymentHeader>lambdaQuery()
                .eq(SdsSteelPaymentHeader::getDocNo, vo.getPaymentDocNo())
                .last("limit 1")
        );
        PaymentOrderExcelRootDTO paymentOrderExcelRootDTO = new PaymentOrderExcelRootDTO();
        BeanUtil.copyProperties(steelPaymentHeader, paymentOrderExcelRootDTO, "prePayment", "sales");
        DecimalFormat decimalFormat = new DecimalFormat();
        decimalFormat.applyPattern("#,##0.00");
        paymentOrderExcelRootDTO.setPrePayment(decimalFormat.format(steelPaymentHeader.getPrePayment()));
        paymentOrderExcelRootDTO.setSales(decimalFormat.format(steelPaymentHeader.getSales()));
        ExcelWriter excelWriter = null;
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setCharacterEncoding("utf-8");
            String fileName = URLEncoder.encode("西區廢料銷售繳款通知單", "UTF-8");
            response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xls");
            ClassPathResource classPathResource = new ClassPathResource("excel/template/export/sdsPaymentOrder.xls");
            InputStream inputStream = classPathResource.getInputStream();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            FillConfig fillConfig = FillConfig.builder().forceNewRow(Boolean.TRUE).build();
            //设置模板的sheet的名称
            Workbook workbook = WorkbookFactory.create(inputStream);
            workbook.setSheetName(0, "缴款单");
            //写到流里
            workbook.write(bos);
            byte[] bArray = bos.toByteArray();
            InputStream is = new ByteArrayInputStream(bArray);
            excelWriter = EasyExcel.write(response.getOutputStream())
                    .registerConverter(new LocalDateTimeStringConverter())
                    .registerConverter(new LocalDateStringConverter())
                    .withTemplate(is).excelType(ExcelTypeEnum.XLS).build();
            WriteSheet cartonSheet = EasyExcel.writerSheet(0).build();
            excelWriter.fill(paymentOrderExcelRootDTO, fillConfig, cartonSheet);

        } catch (Exception e) {
            log.error("西區廢料銷售繳款通知單:{}", e.getMessage(), e);
        } finally {
            // 关闭流
            if (excelWriter != null) {
                excelWriter.finish();
            }
        }
    }

    @Override
    public void uploadFile(PaymentFileUploadVO paymentFileUploadVO) {
        FileUploadVO fileUploadVO = new FileUploadVO();
        fileUploadVO.setBucketName("cloudsaas");
        fileUploadVO.setFiles(ListUtil.toList(paymentFileUploadVO.getFile()));
        R<List<UploadFileRespDTO>> result = uploadFileClient.uploadBatch(fileUploadVO);
        List<UploadFileRespDTO> uploadFileRespDTOList = result.getData();
        String url = uploadFileRespDTOList.get(0).getName();
        Integer id = uploadFileRespDTOList.get(0).getId();
        String filename = paymentFileUploadVO.getFile().getOriginalFilename();

        // 锁单号
        sdsSteelPaymentHeaderMapper.update(null, Wrappers.<SdsSteelPaymentHeader>lambdaUpdate()
                .setSql("file_list = file_list")
                .eq(SdsSteelPaymentHeader::getDocNo, paymentFileUploadVO.getDocNo())
        );
        SdsSteelPaymentHeader sdsSteelPaymentHeader = sdsSteelPaymentHeaderMapper.selectOne(Wrappers.<SdsSteelPaymentHeader>lambdaQuery()
                .eq(SdsSteelPaymentHeader::getDocNo, paymentFileUploadVO.getDocNo())
        );
        String fileList = sdsSteelPaymentHeader.getFileList();
        List<PaymentUploadDTO> paymentUploadDTOList = ListUtil.toList();
        if (!StrUtil.isBlank(fileList)) {
            paymentUploadDTOList = JSONUtil.toList(fileList, PaymentUploadDTO.class);
        } else {
            paymentUploadDTOList = ListUtil.toList();
        }
        PaymentUploadDTO paymentUploadDTO1 = new PaymentUploadDTO();
        paymentUploadDTO1.setFileName(filename);
        paymentUploadDTO1.setUrl(url);
        paymentUploadDTO1.setFileId(id);
        paymentUploadDTO1.setCreatedDt(LocalDateTime.now());
        paymentUploadDTO1.setCreator(WebContextUtil.getCurrentStaffCode());
        paymentUploadDTOList.add(paymentUploadDTO1);

        sdsSteelPaymentHeaderMapper.update(null, Wrappers.<SdsSteelPaymentHeader>lambdaUpdate()
                .set(SdsSteelPaymentHeader::getFileList, JSON.toJSONString(paymentUploadDTOList))
                .set(SdsSteelPaymentHeader::getLastEditor, WebContextUtil.getCurrentStaffCode())
                .set(SdsSteelPaymentHeader::getLastEditedDt, LocalDateTime.now())
                .eq(SdsSteelPaymentHeader::getDocNo, paymentFileUploadVO.getDocNo())
        );

    }

    @Override
    public void salesMailNotify() {
        List<SdsSteelMfgConfig> steelMfgConfigList = steelMfgConfigMapper.selectList(Wrappers.<SdsSteelMfgConfig>lambdaQuery());
        steelMfgConfigList.forEach(sdsSteelMfgConfig -> {
            SteelScrapShipHeaderPaymentQueryVO vo = new SteelScrapShipHeaderPaymentQueryVO();
            vo.setStartDate(LocalDate.now().withDayOfMonth(1));
            vo.setEndDate(LocalDate.now());
            vo.setMfgCode(sdsSteelMfgConfig.getMfgCode());
            PageDataDTO<SteelScrapShipHeaderPaymentDTO> pageDataDTO = shipHeaderPageList(vo, Boolean.FALSE);
            List<SteelScrapShipHeaderPaymentDTO> steelScrapShipHeaderPaymentDTOList = pageDataDTO.getList();
            BigDecimal sales = BigDecimal.ZERO;
            for (SteelScrapShipHeaderPaymentDTO scrapShipHeaderPaymentDTO : steelScrapShipHeaderPaymentDTOList) {
                sales = sales.add(scrapShipHeaderPaymentDTO.getPrice().multiply(scrapShipHeaderPaymentDTO.getScrapNetWeight()));
            }

            // 超过销售额的80%
            if (sales.compareTo(sdsSteelMfgConfig.getPrePayment().multiply(sdsSteelMfgConfig.getNotifyManagementRange())) >= 0) {
                SdsManagementMfgSendMailConfig managementMfgSendMailConfig = managementMfgSendMailConfigMapper.selectOne(Wrappers.<SdsManagementMfgSendMailConfig>lambdaQuery()
                        .eq(SdsManagementMfgSendMailConfig::getMfgCode, sdsSteelMfgConfig.getMfgCode())
                        .last("limit 1")
                );
                if (ObjectUtil.isNull(managementMfgSendMailConfig)) {
                    return;
                }
                FlowNetEmailVO flowNetEmailVO = new FlowNetEmailVO();
                flowNetEmailVO.setUserID(managementMfgSendMailConfig.getUserId());
                flowNetEmailVO.setPassword(managementMfgSendMailConfig.getPassWord());
                flowNetEmailVO.setMAILTO(managementMfgSendMailConfig.getToAddress());
                flowNetEmailVO.setCC(StrUtil.isNotEmpty(managementMfgSendMailConfig.getCcAddress()) ?
                        managementMfgSendMailConfig.getCcAddress() : StrUtil.EMPTY);
                String mailTitle = managementMfgSendMailConfig.getMailTitle();
                DecimalFormat decimalFormat = new DecimalFormat();
                decimalFormat.applyPattern("#,##0.00");
                String dateRangeStr = String.format("%s-%s", vo.getStartDate().format(DateTimeFormatter.ofPattern("yyyy/MM/dd")), vo.getEndDate().format(DateTimeFormatter.ofPattern("yyyy/MM/dd")));
                flowNetEmailVO.setSubject(String.format(mailTitle, sdsSteelMfgConfig.getManFacturer(), NumberUtil.decimalFormat("0.00%", sdsSteelMfgConfig.getNotifyManagementRange())));
                flowNetEmailVO.setBODY(String.format(managementMfgSendMailConfig.getMailContent(), dateRangeStr, sdsSteelMfgConfig.getManFacturer(), decimalFormat.format(sales), NumberUtil.decimalFormat("0.00%", sdsSteelMfgConfig.getNotifyManagementRange())));
                String flag = invokeFlowNetMailService(flowNetEmailVO);
//                Boolean isSendMailSuccess = StrUtil.equals(flag, "Success") ?
//                        Boolean.TRUE : Boolean.FALSE;
                log.info("固废本期销售额超出邮件通知 {}, {}", flowNetEmailVO.getBODY(), flag);
            }
        });
    }


    public String invokeFlowNetFileMailService(FlowNetEmailVO flowNetEmailVO) {
        FlownetResponse response;
        String result;
        String flowNetMailUrl = flowNetUrlConfig.getFileMailUrl();
        List<File> attachment = flowNetEmailVO.getAttachment();
        File[] fileArray = attachment.toArray(new File[0]);
        try {
            result = HttpUtil.createPost(flowNetMailUrl)
                    .header("Content-Type", "multipart/form-data")
                    .setConnectionTimeout(30 * 1000)
                    .setReadTimeout(180 * 1000)
                    .form("UserID", flowNetEmailVO.getUserID())
                    .form("Password", flowNetEmailVO.getPassword())
                    .form("MAILTO", flowNetEmailVO.getMAILTO())
                    .form("BODY", flowNetEmailVO.getBODY())
                    .form("Subject", flowNetEmailVO.getSubject())
                    .form("CC", flowNetEmailVO.getCC())
                    .form("Attachment", fileArray)
                    .execute()
                    .body();
            log.info("sendMailBatchToFlowNet：::requestJson={},url={},result={},current-time:{}",
                    JSONUtil.toJsonStr(flowNetEmailVO), flowNetMailUrl, result, System.currentTimeMillis());
            response = com.alibaba.fastjson.JSON.parseObject(result, FlownetResponse.class);
        } catch (Exception e) {
            log.error("sendMailBatchToFlowNet ERROR:{}", e.getMessage(), e);
            clearFileList(attachment);
            throw new CloudmesException("调用flownet失败");
        }
        return response.getFlag();
    }


    public String invokeFlowNetMailService(FlowNetEmailVO flowNetEmailVO) {
        FlownetResponse response;
        String result;
        String flowNetMailUrl = flowNetUrlConfig.getMailUrl();
        try {
            result = HttpUtil.createPost(flowNetMailUrl)
                    .header("Content-Type", "application/json;charset=UTF-8")
                    .setConnectionTimeout(30 * 1000)
                    .setReadTimeout(180 * 1000)
                    .body(JSONUtil.toJsonStr(flowNetEmailVO))
                    .execute()
                    .body();
            log.info("sendMailBatchToFlowNet：::requestJson={},url={},result={},current-time:{}",
                    JSONUtil.toJsonStr(flowNetEmailVO), flowNetMailUrl, result, System.currentTimeMillis());
            response = com.alibaba.fastjson.JSON.parseObject(result, FlownetResponse.class);
        } catch (Exception e) {
            log.error("sendMailBatchToFlowNet ERROR:{}", e.getMessage(), e);
            throw new CloudmesException("调用flownet失败");
        }
        return response.getFlag();
    }

    @Override
    public void paymentOrderUploadSendMail() {
        SdsSteelPaymentHeader sdsSteelPaymentHeader = sdsSteelPaymentHeaderMapper.selectOne(Wrappers.<SdsSteelPaymentHeader>lambdaQuery()
                .isNotNull(SdsSteelPaymentHeader::getFileList)
                .eq(SdsSteelPaymentHeader::getIsSendMail, "N")
                .orderByDesc(SdsSteelPaymentHeader::getCreatedDt)
                .last("limit 1")
        );
        if (ObjectUtil.isNull(sdsSteelPaymentHeader)) {
            return;
        }
        String fileList = sdsSteelPaymentHeader.getFileList();
        List<PaymentUploadDTO> currentFileList = JSONUtil.toList(fileList, PaymentUploadDTO.class);
        List<File> paymentFileList = getPaymentFileList(currentFileList);
        SdsManagementMfgSendMailConfig managementMfgSendMailConfig = managementMfgSendMailConfigMapper.selectOne(Wrappers.<SdsManagementMfgSendMailConfig>lambdaQuery()
                .eq(SdsManagementMfgSendMailConfig::getMfgCode, sdsSteelPaymentHeader.getMfgCode())
                .eq(SdsManagementMfgSendMailConfig::getSendType, "PAYMENT_ORDER_UPLOAD")
                .last("limit 1")
        );
        if (ObjectUtil.isNull(managementMfgSendMailConfig)) {
            return;
        }

        FlowNetEmailVO flowNetEmailVO = new FlowNetEmailVO();
        flowNetEmailVO.setUserID(managementMfgSendMailConfig.getUserId());
        flowNetEmailVO.setPassword(managementMfgSendMailConfig.getPassWord());
        flowNetEmailVO.setMAILTO(managementMfgSendMailConfig.getToAddress());
        flowNetEmailVO.setCC(StrUtil.isNotEmpty(managementMfgSendMailConfig.getCcAddress()) ?
                managementMfgSendMailConfig.getCcAddress() : StrUtil.EMPTY);
        String mailTitle = managementMfgSendMailConfig.getMailTitle();
        flowNetEmailVO.setSubject(String.format(mailTitle, sdsSteelPaymentHeader.getManFacturer()));

        //TODO
        flowNetEmailVO.setBODY("");
        flowNetEmailVO.setAttachment(paymentFileList);
        String flag = invokeFlowNetFileMailService(flowNetEmailVO);
        if (StrUtil.equals(flag, "Success")) {
            sdsSteelPaymentHeaderMapper.update(null, Wrappers.<SdsSteelPaymentHeader>lambdaUpdate()
                    .eq(SdsSteelPaymentHeader::getId, sdsSteelPaymentHeader.getId())
                    .set(SdsSteelPaymentHeader::getIsSendMail, "Y")
            );
            log.info("update -----------------------------");
        }
        clearFileList(paymentFileList);
        log.info("邮件通知 {}, {}", flowNetEmailVO.getBODY(), flag);
    }


    public List<File> getPaymentFileList(List<PaymentUploadDTO> currentFileList) {
        List<File> resFileList = ListUtil.toList();
        currentFileList.forEach(currentItem -> {
            File file = null;
            String fileAddr = minIOProperties.getFileAddr(BucketConstant.CLOUD_SAAS, currentItem.getUrl());
            String fileName = currentItem.getFileName();
            MultipartFile multipartFile = sdsFileDownloadLogService.handleHttpFileURLToMulitpartFile(fileAddr, fileName);
            String prefix = fileName.substring(fileName.lastIndexOf("."));
            try {
                File tempFile = File.createTempFile(fileName.split("\\.")[0], prefix);
                InputStream inputStream = multipartFile.getInputStream();
                Files.copy(inputStream, tempFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                file = new File(tempFile.getAbsolutePath());
                resFileList.add(file);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        return resFileList;
    }

    private void clearFileList(List<File> fileList) {
        fileList.forEach(file -> file.delete());
    }
}
