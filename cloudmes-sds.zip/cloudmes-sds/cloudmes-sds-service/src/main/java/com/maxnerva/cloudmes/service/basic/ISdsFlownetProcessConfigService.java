package com.maxnerva.cloudmes.service.basic;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.models.entity.basic.SdsFlownetProcessConfig;

/**
 * <p>
 * 危废flownet流程id配置表 服务类
 * </p>
 *
 * @author likun
 * @since 2025-07-01
 */
public interface ISdsFlownetProcessConfigService extends IService<SdsFlownetProcessConfig> {

}
