package com.maxnerva.cloudmes.models.dto.scrap;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @ClassName OutFactoryWeightDTO
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/2/26 上午 08:11
 * @Version 1.0
 **/
@Data
public class OutFactoryWeightDTO {

    @ApiModelProperty("托盘编码")
    private String bucketNo;

    @ApiModelProperty("托盘重量")
    private BigDecimal bucketWeight;

    @ApiModelProperty("产品重量")
    private BigDecimal grossWeight;

    @ApiModelProperty("净重")
    private BigDecimal netWeight;

    @ApiModelProperty("报废小类描述")
    private String scrapDetailClassDesc;

}
