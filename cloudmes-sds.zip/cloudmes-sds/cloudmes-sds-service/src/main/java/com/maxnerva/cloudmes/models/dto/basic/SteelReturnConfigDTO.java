package com.maxnerva.cloudmes.models.dto.basic;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName SteelReturnConfigDTO
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2024/12/25 上午 09:20
 * @Version 1.0
 **/
@ApiModel("钢桶是否返回dto")
@Data
public class SteelReturnConfigDTO {

    @ApiModelProperty(value = "钢桶编码")
    private String bucketNo;

    @ApiModelProperty(value = "是否返回")
    private String isReturn;
}
