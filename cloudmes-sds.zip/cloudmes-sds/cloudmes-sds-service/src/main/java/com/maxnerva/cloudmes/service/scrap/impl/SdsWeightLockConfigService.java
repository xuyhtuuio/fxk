package com.maxnerva.cloudmes.service.scrap.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.conditions.update.LambdaUpdateChainWrapper;
import com.maxnerva.cloudmes.common.utils.WebContextUtil;
import com.maxnerva.cloudmes.mapper.scrap.SdsWeightLockConfigMapper;
import com.maxnerva.cloudmes.models.entity.basic.SdsDepartmentConfig;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapWeightReject;
import com.maxnerva.cloudmes.models.entity.scrap.SdsWeightLockConfig;
import com.maxnerva.cloudmes.models.vo.scrap.SdsWeightLockConfigVO;
import com.maxnerva.cloudmes.service.scrap.ISdsWeightLockConfigService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

/**
 * @ClassName SdsWeightLockConfigService
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/2/14 上午 09:54
 * @Version 1.0
 **/

@Service
@Slf4j
public class SdsWeightLockConfigService implements ISdsWeightLockConfigService {

    @Autowired
    private SdsWeightLockConfigMapper sdsWeightLockConfigMapper;


    @Override
    public SdsWeightLockConfig getSdsWeightLock() {
        return sdsWeightLockConfigMapper.selectOne(null);
    }

    @Override
    public void editSdsWeightLockConfig(SdsWeightLockConfigVO vo) {
        sdsWeightLockConfigMapper.update(null, Wrappers.<SdsWeightLockConfig>lambdaUpdate()
                .set(SdsWeightLockConfig::getBeginLockDt, vo.getBeginLockDt())
                .set(SdsWeightLockConfig::getEndLockDt, vo.getEndLockDt())
                .set(SdsWeightLockConfig::getDescribe, vo.getDescribe())
        );
    }
}
