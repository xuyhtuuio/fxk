package com.maxnerva.cloudmes.controller.waste;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.enums.WasteDocTypeEnum;
import com.maxnerva.cloudmes.models.dto.waste.NoStorageApplyShipScanDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteProduceAndClearDocDTO;
import com.maxnerva.cloudmes.models.vo.waste.NoStorageApplyShipScanVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteInStoreDocQueryVO;
import com.maxnerva.cloudmes.service.waste.WasteInStoreService;
import com.maxnerva.cloudmes.service.waste.WasteProductAndClearService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @ClassName HazardousWasteNoStorageDocController
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/19
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "立产立清管理")
@Slf4j
@RestController
@RequestMapping("/hazardousWasteNoStorage")
public class HazardousWasteNoStorageDocController {

    @Resource
    private WasteProductAndClearService wasteProductAndClearService;

    @Resource
    private WasteInStoreService wasteInStoreService;

    @ApiOperation("立产立清列表")
    @PostMapping("/produceAndClearList")
    public R<PageDataDTO<WasteProduceAndClearDocDTO>> selectProduceAndClearList(@RequestBody WasteInStoreDocQueryVO queryVO){
        return R.ok(wasteProductAndClearService.selectProduceAndClearList(queryVO));
    }

    @ApiOperation("申请出库")
    @PostMapping("/applyShip")
    public R<Void> applyShip(@RequestBody List<Integer> idList){
        wasteInStoreService.applyShip(idList, WasteDocTypeEnum.NO_STORAGE.getDictCode());
        return R.ok();
    }

    @ApiOperation("申请出库扫描")
    @PostMapping("/applyShipScan")
    public R<NoStorageApplyShipScanDTO> applyShipScan(
            @RequestBody NoStorageApplyShipScanVO scanVO){
        return R.ok(wasteProductAndClearService.scanDocNo(scanVO));
    }

    @ApiOperation("导出")
    @PostMapping("/export")
    public R<Void> exportHazardousNoInStorageDoc(HttpServletResponse response,
                                            @RequestBody WasteInStoreDocQueryVO queryVO) {
        wasteProductAndClearService.exportProductAndClearInfo(response, queryVO);
        return R.ok();
    }
}
