package com.maxnerva.cloudmes.service.scrap;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelRemainingInventoryInfo;
import com.maxnerva.cloudmes.models.vo.scrap.SteelRemainingInventoryInfoCreateVO;

public interface ISdsSteelRemainingInventoryInfoService extends IService<SdsSteelRemainingInventoryInfo> {

    void create(SteelRemainingInventoryInfoCreateVO vo);

}
