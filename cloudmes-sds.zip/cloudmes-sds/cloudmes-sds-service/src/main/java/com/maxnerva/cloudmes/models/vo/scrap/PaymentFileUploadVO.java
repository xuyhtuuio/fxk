package com.maxnerva.cloudmes.models.vo.scrap;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * @ClassName PaymentFileUploadVO
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/3/11 上午 11:21
 * @Version 1.0
 **/
@Data
public class PaymentFileUploadVO {

    @ApiModelProperty("繳款单号")
    String docNo;

    @ApiModelProperty("文件")
    MultipartFile file;

    @ApiModelProperty("BU")
    String orgCode;
}
