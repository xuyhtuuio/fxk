package com.maxnerva.cloudmes.models.vo.waste;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @ClassName WasteInStoreWeightSubmitVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/16
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel(value = "入库称重提交VO")
@Data
public class WasteInStoreWeightSubmitVO {

    @ApiModelProperty(value = "单据号",required = true)
    private String docNo;

    @ApiModelProperty(value = "毛重", required = true)
    private BigDecimal grossWeight;
}
