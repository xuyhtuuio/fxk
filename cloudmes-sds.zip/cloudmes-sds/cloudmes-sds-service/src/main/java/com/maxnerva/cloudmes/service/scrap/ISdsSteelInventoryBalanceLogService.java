package com.maxnerva.cloudmes.service.scrap;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelInventoryBalanceLogDTO;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelInventoryBalanceLog;
import com.maxnerva.cloudmes.models.vo.scrap.SteelInventoryBalanceLogQueryVO;

import javax.servlet.http.HttpServletResponse;

public interface ISdsSteelInventoryBalanceLogService extends IService<SdsSteelInventoryBalanceLog> {

    PageDataDTO<SteelInventoryBalanceLogDTO> selectPageList(SteelInventoryBalanceLogQueryVO vo, Boolean isPage);

    void exportDetail(SteelInventoryBalanceLogQueryVO vo, HttpServletResponse response);
}
