package com.maxnerva.cloudmes.models.dto.basic;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel("Flownet返回实体")
@Data
public class FlownetResponse {

    @ApiModelProperty("返回数据")
    private FlownetResponseData data;

    @ApiModelProperty("成功：SUCCESS")
    private String flag;

    @ApiModelProperty("返回信息")
    private String msg;
}
