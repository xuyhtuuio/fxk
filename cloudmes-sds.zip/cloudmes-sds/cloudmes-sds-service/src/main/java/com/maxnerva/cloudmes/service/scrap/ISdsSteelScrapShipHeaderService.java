package com.maxnerva.cloudmes.service.scrap;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.models.dto.scrap.*;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapShipHeader;
import com.maxnerva.cloudmes.models.vo.scrap.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

public interface ISdsSteelScrapShipHeaderService extends IService<SdsSteelScrapShipHeader>  {

    PrintScrapShipmentApplyDTO printScrapShipmentApply(PrintScrapShipmentApplyVO vo);

    PageDataDTO<SteelScrapShipHeaderDTO> selectPageList(SteelScrapShipHeaderQueryVO vo, Boolean isPage);

    void exportDetail(SteelScrapShipHeaderQueryVO vo, HttpServletResponse response);

    void syncFullCarWeight();

    InScrapAreaInfoDTO inScrapAreaInfo(InScrapAreaInfoVO vo);

    void inScrapAreaSubmit(InScrapAreaSubmitVO vo);

    OutScrapAreaInfoDTO outScrapAreaInfo(OutScrapAreaInfoVO vo);

    void outScrapAreaSubmit(OutScrapAreaSubmitVO vo);

    List<String> getPictureList(String docNo);
}
