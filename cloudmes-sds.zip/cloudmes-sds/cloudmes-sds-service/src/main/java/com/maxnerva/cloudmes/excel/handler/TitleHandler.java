package com.maxnerva.cloudmes.excel.handler;

import com.alibaba.excel.write.handler.SheetWriteHandler;
import com.alibaba.excel.write.metadata.holder.WriteSheetHolder;
import com.alibaba.excel.write.metadata.holder.WriteWorkbookHolder;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;

public class TitleHandler implements SheetWriteHandler {

    Integer sheetIndex;
    String title;
    Integer mergeCol;

    public TitleHandler(Integer sheetIndex, String title, Integer mergeCol){
        this.sheetIndex = sheetIndex;
        this.title = title;
        this.mergeCol = mergeCol;
    }

    @Override
    public void beforeSheetCreate(WriteWorkbookHolder writeWorkbookHolder, WriteSheetHolder writeSheetHolder) {

    }

    @Override
    public void afterSheetCreate(WriteWorkbookHolder writeWorkbookHolder, WriteSheetHolder writeSheetHolder) {

        Workbook workbook = writeWorkbookHolder.getWorkbook();
        Sheet sheet = workbook.getSheetAt(sheetIndex);
        // 设置第一行标题
        Row row1 = sheet.createRow(0);
        row1.setHeight((short) 300);
        Cell row1Cell1 = row1.createCell(0);
        row1Cell1.setCellValue(title);
        CellStyle row1CellStyle = workbook.createCellStyle();
        row1CellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        row1CellStyle.setAlignment(HorizontalAlignment.CENTER);
        Font row1Font = workbook.createFont();
        row1Font.setBold(true);
//        row1Font.setFontName("方正小标宋_GBK");
        row1Font.setFontHeightInPoints((short) 12);
        row1CellStyle.setFont(row1Font);
        row1Cell1.setCellStyle(row1CellStyle);
        //合并单元格，起始行,结束行,起始列,结束列
        sheet.addMergedRegion(new CellRangeAddress(0, 1, 0, mergeCol));
    }
}
