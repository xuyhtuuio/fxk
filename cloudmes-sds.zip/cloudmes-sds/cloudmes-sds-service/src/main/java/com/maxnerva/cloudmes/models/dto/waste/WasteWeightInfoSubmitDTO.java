package com.maxnerva.cloudmes.models.dto.waste;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @ClassName WasteWeightInfoSubmitDTO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/14
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("产废称重信息dto")
@Data
public class WasteWeightInfoSubmitDTO {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "单号")
    private String docNo;

    @ApiModelProperty(value = "废物俗称")
    private String hazardousWasteName;

    @ApiModelProperty(value = "申请人部门")
    private String depName;

    @ApiModelProperty("年度产废剩余量")
    private BigDecimal remainWeight;

    @ApiModelProperty(value = "托盘重量")
    private BigDecimal palletWeight;

    @ApiModelProperty(value = "产废毛重")
    private BigDecimal applyGrossWeight;

    @ApiModelProperty(value = "产废净重")
    private BigDecimal applyNetWeight;

    @ApiModelProperty(value = "申请人费用代码")
    private String costCode;

    @ApiModelProperty(value = "SDS料号")
    private String hazardousWasteNo;

}
