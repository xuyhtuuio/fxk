package com.maxnerva.cloudmes.mapper.scrap;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.dto.scrap.SteelPaymentSplitInfoDTO;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelPaymentSplitInfo;
import com.maxnerva.cloudmes.models.vo.scrap.SteelPaymentSplitInfoQueryVO;

import java.util.List;

public interface SdsSteelPaymentSplitInfoMapper extends BaseMapper<SdsSteelPaymentSplitInfo> {

    List<SteelPaymentSplitInfoDTO> selectPageList(SteelPaymentSplitInfoQueryVO vo);

}
