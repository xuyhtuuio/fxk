package com.maxnerva.cloudmes.models.entity.basic;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 打印模板配置关系表
 * </p>
 *
 * @author likun
 * @since 2024-11-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="SdsPrintTemplateConfig对象", description="打印模板配置关系表")
public class SdsPrintTemplateConfig extends BaseEntity<SdsPrintTemplateConfig> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "打印类型")
    private String printType;

    @ApiModelProperty(value = "打印模板id")
    private Integer printTemplateId;

    @ApiModelProperty(value = "打印模板名称")
    private String printTemplateName;

    @ApiModelProperty(value = "份数")
    private Integer piece;

}
