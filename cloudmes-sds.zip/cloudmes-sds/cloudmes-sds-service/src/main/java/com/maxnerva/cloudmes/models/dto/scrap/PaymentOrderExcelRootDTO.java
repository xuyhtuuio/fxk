package com.maxnerva.cloudmes.models.dto.scrap;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class PaymentOrderExcelRootDTO {

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("缴款单号")
    private String docNo;

    @ApiModelProperty("厂商")
    private String manFacturer;

    @ApiModelProperty("合约预付款")
    private String prePayment;

    @ApiModelProperty("本期销售款")
    private String sales;

    @ApiModelProperty("缴款截止日期")
    private LocalDate endDate;

    @ApiModelProperty("收款公司")
    private String collectionCompany;

    @ApiModelProperty(value = "开始日期文本")
    private String startDateTxt;

    @ApiModelProperty(value = "结束日期文本")
    private String finishDateTxt;

    @ApiModelProperty("开户银行")
    private String bank;

    @ApiModelProperty("开户账号")
    private String bankAccount;

    @ApiModelProperty("缴款单备注")
    private String remark;

    @ApiModelProperty(value = "截止日期文本")
    private String endDateTxt;

    @ApiModelProperty(value = "本期销售款文本")
    private String salesTxt;

}
