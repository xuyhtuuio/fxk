package com.maxnerva.cloudmes.service.basic;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.models.dto.basic.HwDepartmentPartRelationDTO;
import com.maxnerva.cloudmes.models.dto.basic.WasteInfoBindDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsHwDepartmentPartRelation;
import com.maxnerva.cloudmes.models.vo.basic.HwDepartmentPartRelationQueryVO;
import com.maxnerva.cloudmes.models.vo.basic.WasteInfoBindSubmitVO;

import java.util.List;

/**
 * <p>
 * 部门对应危废种类 服务类
 * </p>
 *
 * @author likun
 * @since 2025-05-06
 */
public interface ISdsHwDepartmentPartRelationService extends IService<SdsHwDepartmentPartRelation> {

    PageDataDTO<HwDepartmentPartRelationDTO> selectPartRelationPage(HwDepartmentPartRelationQueryVO queryVO);

    List<WasteInfoBindDTO> selectBindWasteInfoList(String orgCode,String costCode,
                                                   String hazardousWasteName);

    void bindWasteInfo(List<WasteInfoBindSubmitVO> wasteInfoBindSubmitVOList);
}
