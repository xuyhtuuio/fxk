package com.maxnerva.cloudmes.models.dto.basic;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName BucketNoDTO
 * @Description TODO
 * @Author Likun
 * @Date 2024/11/5
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("托盘编码信息DTO")
@Data
public class BucketNoDTO {

    @ApiModelProperty("托盘编码")
    private String bucketNo;

    @ApiModelProperty("报废类别")
    private String scrapDetailClass;
}
