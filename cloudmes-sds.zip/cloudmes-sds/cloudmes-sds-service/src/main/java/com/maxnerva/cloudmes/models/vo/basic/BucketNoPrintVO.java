package com.maxnerva.cloudmes.models.vo.basic;

import com.maxnerva.cloudmes.models.vo.CommonPrintVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.*;
import java.math.BigDecimal;

/**
 * @ClassName BucketNoPrintVO
 * @Description TODO
 * @Author Likun
 * @Date 2024/11/5
 * @Version 1.0
 * @Since JDK 1.8
 **/
@EqualsAndHashCode(callSuper = true)
@ApiModel("托盘编码打印vo")
@Data
public class BucketNoPrintVO extends CommonPrintVO {

    @ApiModelProperty(value = "厂部")
    @NotEmpty(message = "厂部不能为空")
    @Size(min = 1,max = 1)
    private String factoryCode;

    @ApiModelProperty(value = "楼栋")
    @NotEmpty(message = "楼栋不能为空")
    @Size(min = 3,max = 3)
    private String building;

    @ApiModelProperty(value = "楼层")
    @NotNull(message = "楼层不能为空")
    @Min(1)
    @Max(9)
    private Integer storey;

    @ApiModelProperty(value = "报废类别")
    @NotEmpty(message = "报废类别不能为空")
    @Size(min = 2,max = 2)
    private String scrapType;

    @ApiModelProperty(value = "托盘重量")
    @NotNull(message = "托盘重量不能为空")
    private BigDecimal bucketWeight;

    @ApiModelProperty(value = "列印张数")
    @NotNull(message = "列印张数不能为空")
    private Integer piece;
}
