package com.maxnerva.cloudmes.models.vo.waste.report;

import com.maxnerva.cloudmes.models.vo.PageQueryVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @ClassName WasteInventoryOverdueWarnQueryVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/6/23
 * @Version 1.0
 * @Since JDK 1.8
 **/
@EqualsAndHashCode(callSuper = true)
@ApiModel("库存超期预警查询vo")
@Data
public class WasteInventoryOverdueWarnQueryVO extends PageQueryVO {

    @ApiModelProperty(value = "超期天数")
    private Integer overDueDays;

    @ApiModelProperty(value = "废物俗称")
    private String hazardousWasteName;

    @ApiModelProperty(value = "库存类型")
    private String docType;
}
