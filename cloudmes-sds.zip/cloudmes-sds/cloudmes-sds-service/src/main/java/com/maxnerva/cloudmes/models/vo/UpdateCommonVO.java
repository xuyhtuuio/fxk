package com.maxnerva.cloudmes.models.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName UpdateCommonVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/6/11
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("更新公共vo")
@Data
public class UpdateCommonVO {

    @ApiModelProperty("主键id")
    private Integer id;
}
