package com.maxnerva.cloudmes.mapper.waste;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.dto.waste.HazardousWasteDocInfoLogDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteDocInfoLog;
import com.maxnerva.cloudmes.models.vo.waste.HazardousWasteDocInfoLogQueryVO;

import java.util.List;

/**
 * <p>
 * 危废单据日志履历 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2025-05-14
 */
public interface SdsHazardousWasteDocInfoLogMapper extends BaseMapper<SdsHazardousWasteDocInfoLog> {

    List<HazardousWasteDocInfoLogDTO> selectDocInfoLogList(HazardousWasteDocInfoLogQueryVO queryVO);
}
