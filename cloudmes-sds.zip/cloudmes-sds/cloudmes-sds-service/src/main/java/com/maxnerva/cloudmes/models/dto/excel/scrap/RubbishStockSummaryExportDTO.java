package com.maxnerva.cloudmes.models.dto.excel.scrap;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("固废结余库存DTO")
@Data
public class RubbishStockSummaryExportDTO {
    @ApiModelProperty(value = "报废类别名")
    @ExcelProperty(value = "报废类别")
    private String scrapDetailClassName;

    @ApiModelProperty(value = "BU称重量")
    @ExcelProperty(value = "BU称重量")
    private BigDecimal buStockQty;

    @ApiModelProperty(value = "结余库存")
    @ExcelProperty(value = "结余库存")
    private BigDecimal summaryQty;

    @ApiModelProperty(value = "入库量")
    @ExcelProperty(value = "入库量")
    private BigDecimal inStockQty;

    @ApiModelProperty(value = "出库量")
    @ExcelProperty(value = "出库量")
    private BigDecimal outStockQty;
}
