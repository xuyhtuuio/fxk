package com.maxnerva.cloudmes.models.dto.scrap;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName HikvisionPictureDTO
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/1/2 下午 02:31
 * @Version 1.0
 **/

@Data
public class HikvisionPictureDTO {
    @ApiModelProperty(value = "图片路径")
    public String picUrl;

}
