package com.maxnerva.cloudmes.service.scrap.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.fastjson2.JSON;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.config.MinIOProperties;
import com.maxnerva.cloudmes.common.constant.BucketConstant;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.excel.handler.AddNoHandler;
import com.maxnerva.cloudmes.mapper.basic.SdsDepartmentConfigMapper;
import com.maxnerva.cloudmes.mapper.basic.SdsSteelBucketInfoMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelScrapWeightInfoMapper;
import com.maxnerva.cloudmes.models.dto.basic.MaterialClassDTO;
import com.maxnerva.cloudmes.models.dto.excel.basic.MaterialClassExportDTO;
import com.maxnerva.cloudmes.models.dto.excel.scrap.SteelScrapWeightInfoExportDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelScrapWeightInfoDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsDepartmentConfig;
import com.maxnerva.cloudmes.models.entity.basic.SdsSteelBucketInfo;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapWeightInfo;
import com.maxnerva.cloudmes.models.vo.scrap.SteelScrapWeightAcceptVO;
import com.maxnerva.cloudmes.models.vo.scrap.SteelScrapWeightInfoQueryOneVO;
import com.maxnerva.cloudmes.models.vo.scrap.SteelScrapWeightInfoQueryVO;
import com.maxnerva.cloudmes.models.vo.scrap.SteelScrapWeightUploadImageVO;
import com.maxnerva.cloudmes.service.scrap.ISdsSteelScrapWeightInfoService;
import com.maxnerva.cloudmes.system.utils.DictLangUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;

import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
public class SdsSteelScrapWeightInfoService extends ServiceImpl<SdsSteelScrapWeightInfoMapper, SdsSteelScrapWeightInfo> implements ISdsSteelScrapWeightInfoService {

    @Autowired
    private MinIOProperties minIOProperties;

    @Autowired
    private DictLangUtils dictLangUtils;

    @Autowired
    private SdsSteelBucketInfoMapper steelBucketInfoMapper;

    @Autowired
    private SdsDepartmentConfigMapper departmentConfigMapper;

    @Override
    public PageDataDTO<SteelScrapWeightInfoDTO> selectPageList(SteelScrapWeightInfoQueryVO vo, Boolean isPage) {
        Page page = new Page();
        if (BooleanUtil.isTrue(isPage)){
            page = PageHelper.startPage(vo.getPageIndex(), vo.getPageSize());
        }
        List<SdsSteelScrapWeightInfo> list = baseMapper.selectList(Wrappers.<SdsSteelScrapWeightInfo>lambdaQuery()
                .eq(SdsSteelScrapWeightInfo::getOrgCode, vo.getOrgCode())
                .eq(StrUtil.isNotBlank(vo.getBucketNo()), SdsSteelScrapWeightInfo::getBucketNo, vo.getBucketNo())
                .eq(StrUtil.isNotBlank(vo.getDepartmentCode()), SdsSteelScrapWeightInfo::getDepartmentCode, vo.getDepartmentCode())
                .eq(StrUtil.isNotBlank(vo.getPositionName()), SdsSteelScrapWeightInfo::getRfidPositionName, vo.getPositionName())
                .eq(StrUtil.isNotBlank(vo.getScrapDetailClass()), SdsSteelScrapWeightInfo::getScrapDetailClass, vo.getScrapDetailClass())
                .between(ObjectUtil.isNotNull(vo.getStartDateTime()) && ObjectUtil.isNotNull(vo.getEndDateTime()),
                        SdsSteelScrapWeightInfo::getWeighDt, vo.getStartDateTime(), vo.getEndDateTime())
                .orderByDesc(SdsSteelScrapWeightInfo::getId)
        );
        Map<String, Map<String, String>> dictMap = dictLangUtils.getByTypes(ListUtil.toList("SDS_ACCEPT_STATUS", "SDS_WEIGHT_STATUS", "SDS_SCRAP_SOLID", "SDS_SOLID_SCRAP_TYPE"));
        List<SdsDepartmentConfig> sdsDepartmentConfigList = departmentConfigMapper.selectList(Wrappers.<SdsDepartmentConfig>lambdaQuery()
                .select(SdsDepartmentConfig::getDepartmentCode, SdsDepartmentConfig::getDepartmentName)
                .eq(SdsDepartmentConfig::getOrgCode, vo.getOrgCode())
        );
        Map<String, String> departmentConfigMap = sdsDepartmentConfigList.stream().collect(Collectors.toMap(k -> k.getDepartmentCode(), v -> v.getDepartmentName()));

        List<SteelScrapWeightInfoDTO> result = ListUtil.toList();
        list.forEach(item -> {
            SteelScrapWeightInfoDTO dto = new SteelScrapWeightInfoDTO();
            BeanUtil.copyProperties(item, dto, "imageUrlList");
            if (StrUtil.isNotBlank(item.getImageUrlList())){
                List<String> imageUrlList = JSON.parseArray(item.getImageUrlList()).toList(String.class);
                imageUrlList = imageUrlList.stream().map(link -> minIOProperties.getFileAddr(BucketConstant.CLOUD_SAAS, link)).collect(Collectors.toList());
                dto.setImageUrlList(imageUrlList);
            }
            dto.setWeighFlagName(dictMap.get("SDS_WEIGHT_STATUS").get(dto.getWeighFlag()));
            dto.setRubbishWeighFlagName(dictMap.get("SDS_WEIGHT_STATUS").get(dto.getRubbishWeighFlag()));
            dto.setAcceptFlagName(dictMap.get("SDS_ACCEPT_STATUS").get(dto.getAcceptFlag()));
            dto.setScrapDetailClassName(dictMap.get("SDS_SCRAP_SOLID").get(dto.getScrapDetailClass()));
            dto.setIsScrapAreaName(BooleanUtil.isTrue(dto.getIsScrapArea()) ? "Y" : "N");
            dto.setDepartmentCodeName(departmentConfigMap.get(dto.getDepartmentCode()));
            dto.setScrapTypeName(dictMap.get("SDS_SOLID_SCRAP_TYPE").get(dto.getScrapType()));
            result.add(dto);
        });
        return new PageDataDTO(page.getTotal(), result);
    }

    @Override
    public void exportDetail(SteelScrapWeightInfoQueryVO vo, HttpServletResponse response) {
        PageDataDTO<SteelScrapWeightInfoDTO> pageDataDTO = selectPageList(vo, Boolean.FALSE);
        List<SteelScrapWeightInfoExportDTO> exportDTOList = ListUtil.toList();
        pageDataDTO.getList().forEach(item -> {
            SteelScrapWeightInfoExportDTO dto = new SteelScrapWeightInfoExportDTO();
            BeanUtil.copyProperties(item, dto);
            exportDTOList.add(dto);
        });

        String fileName = "固废称重记录" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), SteelScrapWeightInfoExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getLocalCode()));
        }
    }
}
