package com.maxnerva.cloudmes.models.entity.scrap;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 固废称重信息表
 * </p>
 *
 * @author baomidou
 * @since 2024-11-01
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("sds_steel_scrap_weight_info")
@ApiModel(value = "SdsSteelScrapWeightInfo对象", description = "固废称重信息表")
public class SdsSteelScrapWeightInfo extends BaseEntity<SdsSteelScrapWeightInfo> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("工厂组织")
    private String orgCode;

    @ApiModelProperty("托盘编码")
    private String bucketNo;

    @ApiModelProperty("托盘重量")
    private BigDecimal bucketWeight;

    @ApiModelProperty("单位")
    private String uom;

    @ApiModelProperty("毛重")
    private BigDecimal grossWeight;

    @ApiModelProperty("净重")
    private BigDecimal netWeight;

    @ApiModelProperty("称重时间")
    private LocalDateTime weighDt;

    @ApiModelProperty("称重员工")
    private String weighEmpNo;

    @ApiModelProperty("N 未称重，Y 已称重")
    private String weighFlag;

    @ApiModelProperty("图片列表")
    private String imageUrlList;

    @ApiModelProperty("N 未接收， Y 已接收")
    private String acceptFlag;

    @ApiModelProperty("接收时间")
    private LocalDateTime acceptDt;

    @ApiModelProperty("接收人")
    private String acceptEmpNo;

    @ApiModelProperty("报废大类")
    private String scrapClass;

    @ApiModelProperty("报废小类")
    private String scrapDetailClass;

    @ApiModelProperty("报废厂毛重")
    private BigDecimal rubbishGrossWeight;

    @ApiModelProperty("报废厂净重")
    private BigDecimal rubbishNetWeight;

    @ApiModelProperty("报废厂称重时间")
    private LocalDateTime rubbishWeighDt;

    @ApiModelProperty("报废厂称重人")
    private String rubbishWeighEmpNo;

    @ApiModelProperty("报废厂称重状态N/Y")
    private String rubbishWeighFlag;

    @ApiModelProperty(value = "是否进废料暂存区")
    private Boolean isScrapArea;

    @ApiModelProperty(value = "报废类型")
    private String scrapType;

    @ApiModelProperty(value = "厂部代码")
    private String departmentCode;

    @ApiModelProperty(value = "盘点单号")
    private String inventoryPlanNo;

    @ApiModelProperty(value = "缴款单号")
    private String paymentDocNo;

    @ApiModelProperty(value = "称重来源")
    private String source;

    @ApiModelProperty(value = "来源单号")
    private String sourceDocNo;
    
    @ApiModelProperty(value = "RFID称重位置")
    private String rfidPositionName;
}
