package com.maxnerva.cloudmes.models.vo.scrap;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.models.vo.CommonRequestVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@EqualsAndHashCode(callSuper = true)
@ApiModel("固废称重信息提交vo")
@Data
public class SteelScrapWeightSubmitVO extends CommonRequestVO {

    @ApiModelProperty(value = "托盘编码", required = true)
    private String bucketNo;

    @ApiModelProperty(value = "毛重", required = true)
    private BigDecimal grossWeight;

    @ApiModelProperty(value = "称重来源(外部系统传值)")
    private String source;

    @ApiModelProperty(value = "称重来源单号(外部系统单号)")
    private String sourceDocNo;

    @ApiModelProperty(value = "称重人(外部系统抛转)")
    private String weightEmpNo;

    @ApiModelProperty(value = "称重时间(外部系统)", required = true)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime weighDt;
    
    @ApiModelProperty(value = "RFID称重位置")
    private String positionName;

}
