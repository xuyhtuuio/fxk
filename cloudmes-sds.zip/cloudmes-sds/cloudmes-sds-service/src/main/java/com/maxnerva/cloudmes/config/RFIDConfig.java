package com.maxnerva.cloudmes.config;

import cn.hutool.core.collection.ListUtil;
import com.alibaba.nacos.common.utils.ConcurrentHashSet;
import com.maxnerva.cloudmes.component.RFIDSocketClient;
import com.maxnerva.cloudmes.models.entity.scrap.SdsRfidSteelConfig;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Component
@Data
@RefreshScope
public class RFIDConfig {
    // RFID_CARD 与实际编码对应关系
    private Map<String, String> cardLinkMap = new ConcurrentHashMap();

    // host+port -> RFID_CARD set
    private Map<String, Set<String>> rfidCardMap = new ConcurrentHashMap();

    // RFID 配置列表
    private List<SdsRfidSteelConfig> rfidSocketConfigDTOList = ListUtil.toList();

    // host+port -> RFID socket
    private Map<String, RFIDSocketClient> rfidSocketClientMap = new ConcurrentHashMap();

    // host+port 异步执行防误出标识，防止异步函数未结束重复执行
    private Set<String> rfidAsyncSymbolSet = new ConcurrentHashSet();

    // 秒
    @Value("${rfid-passingTime:}")
    private Long passingTime;

    private String LIGHT_GREEN_EXPIRED_KEY = "green#caec98c0-5d37-4e57-b20c-2bf6d315883f";

    private String uuid = UUID.randomUUID().toString();

    private String GET_SOCKET_PRIVILEGE_KEY = "socket#3a3ce126-ba69-46e9-91bd-39cf9ec1a00d";

    private String SOCKET_PRIVILEGE_UUID_KEY = "socket-uuid#68687afb-10fa-474e-af25-4efd7d110a4e";

    // RFID状态
    private String RFID_STATUS_KEY = "rfid-status#88e3408f-c340-4761-95b7-36a507770170";
}
