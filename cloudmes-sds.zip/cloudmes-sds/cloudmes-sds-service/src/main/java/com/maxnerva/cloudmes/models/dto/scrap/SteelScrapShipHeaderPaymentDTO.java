package com.maxnerva.cloudmes.models.dto.scrap;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class SteelScrapShipHeaderPaymentDTO {

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("申报单号")
    private String declareNumber;

    @ApiModelProperty("车牌")
    private String licenseCarNumber;

    @ApiModelProperty("厂商")
    private String manFacturer;

    @ApiModelProperty("废料名称")
    private String scrapPartName;

    @ApiModelProperty("废料料号")
    private String scrapPartNo;

    @ApiModelProperty("废料净重")
    private BigDecimal scrapNetWeight;

    @ApiModelProperty("缴款单号")
    private String paymentDocNo;

    @ApiModelProperty("出厂时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime leaveTime;

    @ApiModelProperty("废料类别")
    private String scrapDetailClass;

    @ApiModelProperty(value = "单价")
    private BigDecimal price;
}
