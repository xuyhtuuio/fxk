package com.maxnerva.cloudmes.models.dto.scrap;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class SteelPaymentHeaderDTO {
    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("缴款单号")
    private String docNo;

    @ApiModelProperty("厂商")
    private String manFacturer;

    @ApiModelProperty("合约预付款")
    private BigDecimal prePayment;

    @ApiModelProperty("本期销售款")
    private BigDecimal sales;

    @ApiModelProperty("缴款截止日期")
    private LocalDate endDate;

    @ApiModelProperty("收款公司")
    private String collectionCompany;

    @ApiModelProperty("繳款單文件列表")
    private List<PaymentUploadDTO> paymentFileList;

    @ApiModelProperty("开始日期")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate startDate;

    @ApiModelProperty("结束日期")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate finishDate;

    @ApiModelProperty(value = "创建人")
    private String creator;

    @ApiModelProperty(value = "是否发送邮件")
    private String isSendMail;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "创建时间")
    private LocalDateTime createdDt;
}
