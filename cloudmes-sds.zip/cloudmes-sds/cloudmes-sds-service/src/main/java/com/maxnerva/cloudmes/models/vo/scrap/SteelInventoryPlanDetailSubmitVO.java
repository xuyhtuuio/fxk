package com.maxnerva.cloudmes.models.vo.scrap;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class SteelInventoryPlanDetailSubmitVO {

    @ApiModelProperty(value = "盘点详情ID", required = true)
    private Integer id;

    @ApiModelProperty(value = "托盘编码", required = true)
    private String bucketNo;

    @ApiModelProperty(value = "毛重", required = true)
    private BigDecimal grossWeight;

}
