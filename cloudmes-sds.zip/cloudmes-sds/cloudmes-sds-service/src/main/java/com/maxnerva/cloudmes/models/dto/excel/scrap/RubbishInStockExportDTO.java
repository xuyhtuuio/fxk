package com.maxnerva.cloudmes.models.dto.excel.scrap;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.maxnerva.cloudmes.excel.converter.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("固废库存入库记录DTO")
@Data
public class RubbishInStockExportDTO {

    @ApiModelProperty(value = "厂部")
    @ExcelProperty(value = "厂部")
    private String departmentCodeName;

    @ApiModelProperty(value = "报废类别名")
    @ExcelProperty(value = "报废类别")
    private String scrapDetailClassName;

    @ApiModelProperty(value = "托盘编码")
    @ExcelProperty(value = "托盘编码")
    private String bucketNo;

    @ApiModelProperty(value = "托盘重量")
    @ExcelProperty(value = "托盘重量")
    private BigDecimal bucketWeight;

    @ApiModelProperty(value = "单位")
    @ExcelProperty(value = "单位")
    private String uom;

    @ApiModelProperty("报废厂毛重")
    @ExcelProperty(value = "废料厂毛重")
    private BigDecimal rubbishGrossWeight;

    @ApiModelProperty("报废厂净重")
    @ExcelProperty(value = "废料厂净重")
    private BigDecimal rubbishNetWeight;

    @ApiModelProperty("报废厂称重人")
    @ExcelProperty(value = "废料厂称重人")
    private String rubbishWeighEmpNo;

    @ApiModelProperty("报废厂称重时间")
    @ExcelProperty(value = "报废厂称重时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime rubbishWeighDt;
}
