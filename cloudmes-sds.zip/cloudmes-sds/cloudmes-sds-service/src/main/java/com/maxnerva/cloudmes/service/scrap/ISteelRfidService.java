package com.maxnerva.cloudmes.service.scrap;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.models.dto.scrap.RfidSteelIssueLogDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelRfidStatusDTO;
import com.maxnerva.cloudmes.models.entity.scrap.SdsRfidSteelConfig;
import com.maxnerva.cloudmes.models.vo.scrap.HandleSteelIssueVO;
import com.maxnerva.cloudmes.models.vo.scrap.RfidSteelIssueLogQueryVO;

import java.util.List;

/**
 * @ClassName ISteelRfidService
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2024/12/23 下午 01:33
 * @Version 1.0
 **/
public interface ISteelRfidService {

    Boolean getSocketPrivilege();

    Boolean hasSocketPrivilege();

    // 重连
    void reConnect();

    void disconnectAllConnect();

    // 灯光检测Job
    void notifyWarning();

    // 同步RFID数据Job
    void syncCardInfo();

    // 定时上报RFID状态
    void reportRfidStatus();

    PageDataDTO<RfidSteelIssueLogDTO> getSteelIssuePageList(RfidSteelIssueLogQueryVO vo, Boolean isPage);

    void handleSteelIssue(HandleSteelIssueVO vo);

    List<SteelRfidStatusDTO> getRfidStatus();

    List<SdsRfidSteelConfig> getAllRfidConfig();
}
