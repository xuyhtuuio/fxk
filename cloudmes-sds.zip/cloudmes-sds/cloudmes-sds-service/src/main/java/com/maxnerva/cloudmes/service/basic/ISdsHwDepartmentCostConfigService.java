package com.maxnerva.cloudmes.service.basic;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.models.dto.basic.CostCodeNameDTO;
import com.maxnerva.cloudmes.models.dto.basic.HwDepartmentCostConfigDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsHwDepartmentCostConfig;
import com.maxnerva.cloudmes.models.vo.basic.HwDepartmentCostConfigQueryVO;

import java.util.List;

/**
 * <p>
 * 危废费用部门配置表 服务类
 * </p>
 *
 * @author likun
 * @since 2025-05-06
 */
public interface ISdsHwDepartmentCostConfigService extends IService<SdsHwDepartmentCostConfig> {

    PageDataDTO<HwDepartmentCostConfigDTO> selectConfigPage(HwDepartmentCostConfigQueryVO queryVO);

    List<String> selectCostCodeListByOrgCode(String orgCode);

    List<CostCodeNameDTO> selectCostCodeNameListByOrgCode(String orgCode);
}
