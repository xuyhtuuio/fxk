package com.maxnerva.cloudmes.service.basic.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.mapper.basic.SdsHazardousWasteFlownetRequestLogMapper;
import com.maxnerva.cloudmes.models.entity.basic.SdsHazardousWasteFlownetRequestLog;
import com.maxnerva.cloudmes.service.basic.ISdsHazardousWasteFlownetRequestLogService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 危废flownet审核完成调用日志 服务实现类
 * </p>
 *
 * @author likun
 * @since 2025-06-09
 */
@Service
public class SdsHazardousWasteFlownetRequestLogServiceImpl extends ServiceImpl<SdsHazardousWasteFlownetRequestLogMapper, SdsHazardousWasteFlownetRequestLog> implements ISdsHazardousWasteFlownetRequestLogService {

}
