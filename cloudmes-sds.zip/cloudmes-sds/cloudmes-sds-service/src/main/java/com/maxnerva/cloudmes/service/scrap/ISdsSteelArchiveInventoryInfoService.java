package com.maxnerva.cloudmes.service.scrap;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelArchiveInventoryInfo;

public interface ISdsSteelArchiveInventoryInfoService extends IService<SdsSteelArchiveInventoryInfo> {
}
