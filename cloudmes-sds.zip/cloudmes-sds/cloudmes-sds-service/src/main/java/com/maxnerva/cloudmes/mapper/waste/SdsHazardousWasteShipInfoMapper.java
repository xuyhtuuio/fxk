package com.maxnerva.cloudmes.mapper.waste;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.dto.waste.TransferBindShipDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteDocShipInfoDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteShipInfo;
import com.maxnerva.cloudmes.models.vo.waste.TransferBindShipInfoQueryVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteDocShipInfoQueryVO;

import java.util.List;

/**
 * <p>
 * 出库单 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2025-05-16
 */
public interface SdsHazardousWasteShipInfoMapper extends BaseMapper<SdsHazardousWasteShipInfo> {

    List<WasteDocShipInfoDTO> selectDocShipInfoList(WasteDocShipInfoQueryVO queryVO);

    List<TransferBindShipDTO> selectTransferBindShipList(TransferBindShipInfoQueryVO queryVO);

}
