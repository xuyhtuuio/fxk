package com.maxnerva.cloudmes.models.entity.basic;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2025-01-06
 */
@TableName("sds_file_download_log")
@ApiModel(value = "SdsFileDownloadLog对象", description = "")
@Data
public class SdsFileDownloadLog extends BaseEntity<SdsFileDownloadLog> {

    private static final long serialVersionUID = 1L;

    private Integer id;

    private String fileName;

    private String link;

    private String type;

    private Integer fileId;
}
