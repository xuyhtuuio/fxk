package com.maxnerva.cloudmes.models.dto.excel.scrap;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.excel.converter.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("固废出货单DTO")
@Data
public class SteelScrapShipHeaderExportDTO {
    @ApiModelProperty("申报单号")
    @ExcelProperty(value = "申报单号")
    private String declareNumber;

    @ApiModelProperty("厂商")
    @ExcelProperty(value = "厂商")
    private String manFacturer;

    @ApiModelProperty("废料名称")
    @ExcelProperty(value = "废料名称")
    private String scrapPartName;

    @ApiModelProperty("关务代码")
    @ExcelProperty(value = "关务代码")
    private String customsCode;

    @ApiModelProperty("废料料号")
    @ExcelProperty(value = "废料料号")
    private String scrapPartNo;

    @ApiModelProperty("废料类别")
    @ExcelProperty(value = "废料类别")
    private String sdsScrapTypeName;

    @ApiModelProperty("区域代码")
    @ExcelProperty(value = "区域代码")
    private String areaCode;

    @ApiModelProperty("车牌")
    @ExcelProperty(value = "车牌")
    private String licenseCarNumber;

    @ApiModelProperty("司机")
    @ExcelProperty(value = "司机")
    private String driver;

    @ApiModelProperty("申请人")
    @ExcelProperty(value = "申请人")
    private String applyor;

    @ApiModelProperty("申请时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "申请时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime applyDt;

    @ApiModelProperty("空车重量")
    @ExcelProperty(value = "空车重量")
    private BigDecimal carWeight;

    @ApiModelProperty("进厂时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "进厂时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime entryTime;

    @ApiModelProperty("整车重量")
    @ExcelProperty(value = "整车重量")
    private BigDecimal fullCarWeight;

    @ApiModelProperty("出厂时间")
    @ExcelProperty(value = "出厂时间", converter = LocalDateTimeStringConverter.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime leaveTime;

    @ApiModelProperty("废料净重")
    @ExcelProperty(value = "废料净重")
    private BigDecimal scrapNetWeight;

    @ApiModelProperty("进出废料区状态")
    @ExcelProperty(value = "进出废料区状态")
    private String scrapAreaStatusName;

    @ApiModelProperty("进废料区时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "进废料区时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime inScrapAreaDt;

    @ApiModelProperty("进废料区放行人")
    @ExcelProperty(value = "进废料区放行人")
    private String inScrapAreaEmpNo;

    @ApiModelProperty(value = "出废料区时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "出废料区时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime outScrapAreaDt;

    @ApiModelProperty("出废料区放行人")
    @ExcelProperty(value = "出废料区放行人")
    private String outScrapAreaEmpNo;

    @ApiModelProperty("出货法人")
    @ExcelProperty(value = "出货法人")
    private String shippingCorporation;

    @ApiModelProperty("归属单位")
    @ExcelProperty(value = "归属单位")
    private String costCode;

    @ApiModelProperty("计量单位")
    @ExcelProperty(value = "计量单位")
    private String uom;

    @ApiModelProperty("备案号")
    @ExcelProperty(value = "备案号")
    private String filedNumber;

    @ApiModelProperty("关锁号")
    @ExcelProperty(value = "关锁号")
    private String lockNumber;

    @ApiModelProperty("车况-工具箱")
    @ExcelProperty(value = "车况-工具箱")
    private String carToolBox;

    @ApiModelProperty("车况-油箱")
    @ExcelProperty(value = "车况-油箱")
    private String carFuelTank;

    @ApiModelProperty("车况-钢圈")
    @ExcelProperty(value = "车况-钢圈")
    private String carSteelRing;

    @ApiModelProperty("车况-水箱")
    @ExcelProperty(value = "车况-水箱")
    private String carWaterTank;

    @ApiModelProperty("车况-备胎")
    @ExcelProperty(value = "车况-备胎")
    private String carSpareTire;

    @ApiModelProperty(value = "创建人")
    @ExcelProperty(value = "创建人")
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "创建时间")
    @ExcelProperty(value = "创建时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "修改人")
    @ExcelProperty(value = "修改人")
    private String lastEditor;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "修改时间")
    @ExcelProperty(value = "修改时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime lastEditedDt;
}
