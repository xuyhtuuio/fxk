package com.maxnerva.cloudmes.models.entity.scrap;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

/**
 * @ClassName SdsWeightLockConfig
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/2/14 上午 09:48
 * @Version 1.0
 **/

@TableName("sds_steel_scrap_weight_lock_config")
@ApiModel(value = "SdsWeightLockConfig对象", description = "称重锁定配置")
@Data
public class SdsWeightLockConfig extends BaseEntity<SdsWeightLockConfig>{

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("开始锁定时间")
    private LocalDateTime beginLockDt;


    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("结束锁定时间")
    private LocalDateTime endLockDt;

    @ApiModelProperty("描述")
    private String describe;

}
