package com.maxnerva.cloudmes.models.vo.waste;

import com.maxnerva.cloudmes.models.vo.CommonRequestVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @ClassName InStoreRejectWeightSubmitVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/19
 * @Version 1.0
 * @Since JDK 1.8
 **/
@EqualsAndHashCode(callSuper = true)
@ApiModel("入库拒收提交VO")
@Data
public class InStoreRejectWeightSubmitVO extends CommonRequestVO {

    @ApiModelProperty(value = "单号", required = true)
    private String docNo;

    @ApiModelProperty(value = "拒收人", required = true)
    private String operateEmpNo;

    @ApiModelProperty(value = "拒收备注", required = true)
    private String operateRemarkType;
}
