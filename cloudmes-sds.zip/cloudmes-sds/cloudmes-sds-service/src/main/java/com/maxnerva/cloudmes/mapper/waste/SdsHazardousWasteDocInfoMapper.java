package com.maxnerva.cloudmes.mapper.waste;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.dto.waste.HazardousWasteDocInfoDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteDocPrintDataDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteInStoreDocInfoDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteProduceAndClearDocDTO;
import com.maxnerva.cloudmes.models.dto.waste.report.WasteInventoryDTO;
import com.maxnerva.cloudmes.models.dto.waste.report.WasteInventoryDetailDTO;
import com.maxnerva.cloudmes.models.dto.waste.report.WasteInventoryOverdueWarnDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteDocInfo;
import com.maxnerva.cloudmes.models.vo.waste.HazardousWasteDocInfoQueryVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteInStoreDocQueryVO;
import com.maxnerva.cloudmes.models.vo.waste.report.WasteInventoryDetailQueryVO;
import com.maxnerva.cloudmes.models.vo.waste.report.WasteInventoryOverdueWarnQueryVO;
import com.maxnerva.cloudmes.models.vo.waste.report.WasteInventoryQueryVO;

import java.util.List;

/**
 * <p>
 * 产废单据表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2025-05-14
 */
public interface SdsHazardousWasteDocInfoMapper extends BaseMapper<SdsHazardousWasteDocInfo> {

    List<HazardousWasteDocInfoDTO> selectHazardousWasteDocInfoPage(HazardousWasteDocInfoQueryVO queryVO);

    WasteDocPrintDataDTO selectPrintDataById(Integer id);

    String getImageUrlList(Integer id);

    List<WasteInStoreDocInfoDTO> selectInStoreDocInfoList(WasteInStoreDocQueryVO queryVO);

    List<WasteProduceAndClearDocDTO> selectProduceAndClearDocList(WasteInStoreDocQueryVO queryVO);

    List<WasteInventoryDTO> selectWasteInventoryList(WasteInventoryQueryVO queryVO);

    List<WasteInventoryDetailDTO> selectWasteInventoryDetailList(WasteInventoryDetailQueryVO queryVO);

    List<WasteInventoryOverdueWarnDTO> selectWasteInventoryOverdueWarnList(WasteInventoryOverdueWarnQueryVO queryVO);
}
