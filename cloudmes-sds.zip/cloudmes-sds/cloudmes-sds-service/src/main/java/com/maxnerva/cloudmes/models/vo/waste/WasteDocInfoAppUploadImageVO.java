package com.maxnerva.cloudmes.models.vo.waste;

import com.maxnerva.cloudmes.models.vo.CommonRequestVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * @ClassName WasteDocInfoAppUploadImageVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/26
 * @Version 1.0
 * @Since JDK 1.8
 **/
@EqualsAndHashCode(callSuper = true)
@ApiModel(value = "危废车间上传图片VO")
@Data
public class WasteDocInfoAppUploadImageVO extends CommonRequestVO {

    @ApiModelProperty(value = "文件", required = true)
    private List<MultipartFile> files;

    @ApiModelProperty(value = "单号", required = true)
    private String docNo;
}
