package com.maxnerva.cloudmes.service.waste.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.enums.WasteDocTypeEnum;
import com.maxnerva.cloudmes.enums.WasteTransferDocTypeEnum;
import com.maxnerva.cloudmes.excel.handler.AddNoHandler;
import com.maxnerva.cloudmes.mapper.waste.SdsHazardousWasteShipInfoMapper;
import com.maxnerva.cloudmes.models.dto.excel.waste.WasteDocShipExportDTO;
import com.maxnerva.cloudmes.models.dto.waste.TransferBindShipDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteDocShipInfoDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteShipInfo;
import com.maxnerva.cloudmes.models.vo.waste.TransferBindShipInfoQueryVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteDocShipInfoQueryVO;
import com.maxnerva.cloudmes.service.waste.ISdsHazardousWasteShipInfoService;
import com.maxnerva.cloudmes.system.utils.DictLangUtils;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * <p>
 * 出库单 服务实现类
 * </p>
 *
 * @author likun
 * @since 2025-05-16
 */
@Slf4j
@Service
public class SdsHazardousWasteShipInfoServiceImpl extends ServiceImpl<SdsHazardousWasteShipInfoMapper, SdsHazardousWasteShipInfo> implements ISdsHazardousWasteShipInfoService {

    @Resource
    private DictLangUtils dictLangUtils;

    @Override
    public PageDataDTO<WasteDocShipInfoDTO> selectShipInfoPage(WasteDocShipInfoQueryVO queryVO) {
        if (queryVO.getPageIndex() != null && queryVO.getPageSize() != null
                && queryVO.getPageIndex() != 0 && queryVO.getPageSize() != 0) {
            Page page = PageHelper.startPage(queryVO.getPageIndex(), queryVO.getPageSize());
            List<WasteDocShipInfoDTO> wasteDocShipInfoDTOList = getDocShipInfoDTOList(queryVO);
            return new PageDataDTO<>(page.getTotal(), wasteDocShipInfoDTOList);
        } else {
            List<WasteDocShipInfoDTO> wasteDocShipInfoDTOList = getDocShipInfoDTOList(queryVO);
            return new PageDataDTO<>((long) wasteDocShipInfoDTOList.size(), wasteDocShipInfoDTOList);
        }
    }

    @Override
    public List<TransferBindShipDTO> selectTransferBindShipList(TransferBindShipInfoQueryVO queryVO) {
        String docType = queryVO.getDocType();
        switch (Objects.requireNonNull(WasteTransferDocTypeEnum.getByValue(docType))) {
            case NO_INSTORAGE_ORDER:
            case NO_INSTORAGE_SUPPLY_RECORD:
                docType = WasteDocTypeEnum.NO_STORAGE.getDictCode();
                break;
            case NORMAL_ORDER:
            case NORMAL_SUPPLY_RECORD:
                docType = WasteDocTypeEnum.STORAGE.getDictCode();
                break;
            default:
                break;
        }
        queryVO.setDocType(docType);
        return baseMapper.selectTransferBindShipList(queryVO);
    }

    @Override
    public void exportDocShip(HttpServletResponse response, WasteDocShipInfoQueryVO queryVO) {
        List<WasteDocShipExportDTO> exportDTOList = CollUtil.newArrayList();
        List<WasteDocShipInfoDTO> wasteDocShipInfoDTOList = getDocShipInfoDTOList(queryVO);
        wasteDocShipInfoDTOList.forEach(wasteDocShipInfoDTO -> {
            WasteDocShipExportDTO wasteDocShipExportDTO = new WasteDocShipExportDTO();
            BeanUtils.copyProperties(wasteDocShipInfoDTO, wasteDocShipExportDTO);
            exportDTOList.add(wasteDocShipExportDTO);
        });
        String fileName = "出库单信息" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), WasteDocShipExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.HAZARDOUS_WASTE_DOC_SHIP_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.HAZARDOUS_WASTE_DOC_SHIP_EXPORT_FAIL.getLocalCode()));
        }
    }

    @NotNull
    private List<WasteDocShipInfoDTO> getDocShipInfoDTOList(WasteDocShipInfoQueryVO queryVO) {
        List<WasteDocShipInfoDTO> wasteDocShipInfoDTOList = baseMapper.selectDocShipInfoList(queryVO);
        List<String> types = CollUtil.newArrayList();
        types.add("SDS_HAZARDOUS_WASTE_ENTRY_TYPE");
        types.add("SDS_WASTE_DOC_SHIP_INFO_STATUS");
        Map<String, Map<String, String>> data = dictLangUtils.getByTypes(types);
        Map<String, String> entryTypeMap = data.get("SDS_HAZARDOUS_WASTE_ENTRY_TYPE");
        Map<String, String> docStatusMap = data.get("SDS_WASTE_DOC_SHIP_INFO_STATUS");
        wasteDocShipInfoDTOList.forEach(wasteDocShipInfoDTO -> {
            wasteDocShipInfoDTO.setDocStatusName(docStatusMap.get(wasteDocShipInfoDTO.getDocStatus()));
            wasteDocShipInfoDTO.setDocTypeName(entryTypeMap.get(wasteDocShipInfoDTO.getDocType()));
        });
        return wasteDocShipInfoDTOList;
    }
}
