package com.maxnerva.cloudmes.models.dto.excel.scrap;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.maxnerva.cloudmes.excel.converter.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("固废废料厂拒收处理导出DTO")
@Data
public class SteelScrapWeightRejectExportDTO {
    @ExcelProperty(value = "工厂组织")
    @ApiModelProperty("工厂组织")
    private String orgCode;

    @ExcelProperty(value = "报废类别")
    @ApiModelProperty("报废小类名")
    private String scrapDetailClassName;

    @ExcelProperty(value = "厂部")
    @ApiModelProperty("厂部名称")
    private String departmentCodeName;

    @ExcelProperty(value = "状态")
    @ApiModelProperty("状态名")
    private String statusName;

    @ExcelProperty(value = "托盘编码")
    @ApiModelProperty("托盘编码")
    private String bucketNo;

    @ExcelProperty(value = "托盘重量")
    private BigDecimal bucketWeight;

    @ExcelProperty (value = "单位")
    @ApiModelProperty("单位")
    private String uom;

    @ExcelProperty(value = "固废重量")
    @ApiModelProperty("毛重")
    private BigDecimal grossWeight;

    @ExcelProperty(value = "固废净重")
    @ApiModelProperty("净重")
    private BigDecimal netWeight;

    @ExcelProperty(value = "称重人")
    @ApiModelProperty("称重人")
    private String weighEmpNo;

    @ExcelProperty(value = "称重时间", converter = LocalDateTimeStringConverter.class)
    @ApiModelProperty("称重时间")
    private LocalDateTime weighDt;

    @ExcelProperty(value = "废料厂重量")
    @ApiModelProperty("暂存区毛重")
    private BigDecimal rubbishGrossWeight;

    @ApiModelProperty("废料厂净重")
    @ExcelProperty(value = "废料厂净重")
    private BigDecimal rubbishNetWeight;

    @ApiModelProperty("废料厂称重人")
    @ExcelProperty(value = "废料厂称重人")
    private String rubbishWeighEmpNo;

    @ApiModelProperty("废料厂称重时间")
    @ExcelProperty(value = "废料厂称重时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime rubbishWeighDt;

    @ApiModelProperty("拒收原因")
    @ExcelProperty(value = "拒收原因")
    private String rejectReason;

    @ApiModelProperty("拒收人")
    @ExcelProperty(value = "拒收人")
    private String rejectEmpNo;

    @ApiModelProperty("拒收时间")
    @ExcelProperty(value = "拒收时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime rejectDt;

    @ApiModelProperty("处理人")
    @ExcelProperty(value = "处理人")
    private String handleEmpNo;

    @ApiModelProperty("处理时间")
    @ExcelProperty(value = "处理时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime handleDt;

    @ApiModelProperty("处理方式")
    @ExcelProperty(value = "处理方式")
    private String handleMethod;

    @ApiModelProperty(value = "详细原因备注")
    @ExcelProperty(value = "详细原因备注")
    private String reason;
}
