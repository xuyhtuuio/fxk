package com.maxnerva.cloudmes.models.dto.scrap;

import com.maxnerva.cloudmes.models.dto.CommonPrintDTO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class PrintScrapShipmentApplyDTO extends CommonPrintDTO {

    @ApiModelProperty(value = "打印信息")
    private SdsSteelScrapShipHeaderDTO data;

}
