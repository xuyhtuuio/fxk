package com.maxnerva.cloudmes.controller.plan;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.basic.FlownetResponse;
import com.maxnerva.cloudmes.models.dto.plan.PlanInfoAddLogDTO;
import com.maxnerva.cloudmes.models.vo.plan.PlanFlownetApprovalVO;
import com.maxnerva.cloudmes.models.vo.plan.PlanInfoAddLogQueryVO;
import com.maxnerva.cloudmes.models.vo.plan.PlanInfoAddLogSaveVO;
import com.maxnerva.cloudmes.models.vo.plan.PlanInfoAddLogUpdateVO;
import com.maxnerva.cloudmes.service.plan.ISdsHazardousWastePlanInfoAddLogService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @ClassName PlanInfoAddLogController
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/8
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "年度计划说明管理")
@Slf4j
@RestController
@RequestMapping("/planInfoAddLog")
public class PlanInfoAddLogController {

    @Resource
    private ISdsHazardousWastePlanInfoAddLogService sdsHazardousWastePlanInfoAddLogService;

    @ApiOperation("新增")
    @PostMapping("/save")
    public R<Void> savePlanInfoAddLog(@RequestBody PlanInfoAddLogSaveVO saveVO){
        sdsHazardousWastePlanInfoAddLogService.savePlanInfoAddLog(saveVO);
        return R.ok();
    }

    @ApiOperation("编辑")
    @PutMapping("/update")
    public R<Void> updatePlanInfoAddLog(@RequestBody PlanInfoAddLogUpdateVO updateVO){
        sdsHazardousWastePlanInfoAddLogService.updatePlanInfoAddLog(updateVO);
        return R.ok();
    }

    @ApiOperation("分页查询")
    @PostMapping("/list")
    public R<PageDataDTO<PlanInfoAddLogDTO>> selectPlanInfoAddLogList(@RequestBody PlanInfoAddLogQueryVO queryVO){
        return R.ok(sdsHazardousWastePlanInfoAddLogService.selectPlanInfoAddLogPage(queryVO));
    }
    @ApiOperation("删除")
    @DeleteMapping("/del/{id}")
    public R<Void> deletePlanInfoAddLog(@PathVariable("id") Integer id){
        sdsHazardousWastePlanInfoAddLogService.deletePlanInfoAddLog(id);
        return R.ok();
    }

    @ApiOperation("导出")
    @PostMapping("/export")
    public R<Void> exportPlanInfoAddLog(HttpServletResponse response,
                                     @RequestBody PlanInfoAddLogQueryVO queryVO) {
        sdsHazardousWastePlanInfoAddLogService.exportPlanInfoAddLog(response, queryVO);
        return R.ok();
    }

    @ApiOperation("Flownet审核完成调用服务节点")
    @PostMapping("/approvalCompleted")
    public R<Void> approvalCompleted(@RequestBody String jsonString) {
        log.info("Flownet input parameter=========》：::requestJson={}", jsonString);
        return sdsHazardousWastePlanInfoAddLogService.approvalCompleted(jsonString);
    }

    @ApiOperation(value = "Flownet审核完成")
    @PostMapping("/flownetApproval")
    public R<Void> flownetApproval(@RequestBody List<PlanFlownetApprovalVO> planFlownetApprovalVOList) {
        sdsHazardousWastePlanInfoAddLogService.flownetApproval(planFlownetApprovalVOList);
        return R.ok();
    }

    @ApiOperation(value = "送签")
    @GetMapping("/sendToSign")
    public R<FlownetResponse> sendToSign(HttpServletRequest request, Integer id) {
        return R.ok(sdsHazardousWastePlanInfoAddLogService.sendToSign(request, id));
    }

    @ApiOperation(value = "签核状态")
    @GetMapping("/approvalStatus")
    public R<FlownetResponse> approvalStatus(Integer id) {
        return R.ok(sdsHazardousWastePlanInfoAddLogService.approvalStatus(id));
    }
}
