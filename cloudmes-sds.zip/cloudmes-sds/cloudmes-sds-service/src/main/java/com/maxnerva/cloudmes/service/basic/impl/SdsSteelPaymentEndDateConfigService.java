package com.maxnerva.cloudmes.service.basic.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.convert.NumberChineseFormatter;
import cn.hutool.core.util.BooleanUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.mapper.basic.SdsSteelPaymentEndDateConfigMapper;
import com.maxnerva.cloudmes.models.dto.basic.CalcSteelPaymentOrderDeadlineDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsSteelPaymentEndDateConfig;
import com.maxnerva.cloudmes.service.basic.ISdsSteelPaymentEndDateConfigService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;

@Slf4j
@Service
public class SdsSteelPaymentEndDateConfigService extends ServiceImpl<SdsSteelPaymentEndDateConfigMapper, SdsSteelPaymentEndDateConfig> implements ISdsSteelPaymentEndDateConfigService {


    @Override
    public CalcSteelPaymentOrderDeadlineDTO calcPaymentOrderDeadline(String mfgCode, LocalDate startDate, BigDecimal nowPercentage) {

        List<SdsSteelPaymentEndDateConfig> deadlineList = baseMapper.selectList(Wrappers.<SdsSteelPaymentEndDateConfig>lambdaQuery()
                .eq(SdsSteelPaymentEndDateConfig::getMfgCode, mfgCode)
        );
        if (CollUtil.isEmpty(deadlineList)){
            return null;
        }

        deadlineList.sort(Comparator.comparing(SdsSteelPaymentEndDateConfig::getLeftPercentage));
        SdsSteelPaymentEndDateConfig deadline = null;
        CalcSteelPaymentOrderDeadlineDTO dto = new CalcSteelPaymentOrderDeadlineDTO();
        for (SdsSteelPaymentEndDateConfig subDeadline : deadlineList){
            if (BooleanUtil.isTrue(subDeadline.getIsLeftClose()) && BooleanUtil.isTrue(subDeadline.getIsRightClose())){
                if (nowPercentage.compareTo(subDeadline.getLeftPercentage()) >= 0 && nowPercentage.compareTo(subDeadline.getRightPercentage()) <= 0){
                    deadline = subDeadline;
                    break;
                }
            } else if (BooleanUtil.isTrue(subDeadline.getIsLeftClose()) && BooleanUtil.isFalse(subDeadline.getIsRightClose())){
                if (nowPercentage.compareTo(subDeadline.getLeftPercentage()) >= 0 && nowPercentage.compareTo(subDeadline.getRightPercentage()) < 0){
                    deadline = subDeadline;
                    break;
                }
            } else if (BooleanUtil.isFalse(subDeadline.getIsLeftClose()) && BooleanUtil.isTrue(subDeadline.getIsRightClose())){
                if (nowPercentage.compareTo(subDeadline.getLeftPercentage()) > 0 && nowPercentage.compareTo(subDeadline.getRightPercentage()) <= 0){
                    deadline = subDeadline;
                    break;
                }
            } else  if (BooleanUtil.isFalse(subDeadline.getIsLeftClose()) && BooleanUtil.isFalse(subDeadline.getIsRightClose())){
                if (nowPercentage.compareTo(subDeadline.getLeftPercentage()) > 0 && nowPercentage.compareTo(subDeadline.getRightPercentage()) < 0){
                    deadline = subDeadline;
                    break;
                }
            }
        }

        if ("0".equals(deadline.getEndDateType())){
            LocalDate endDate = startDate.plusDays(deadline.getNum());
            dto.setEndDate(endDate);
            dto.setEndDateTxt(String.format(deadline.getTemplate(), NumberChineseFormatter.format(deadline.getNum(), true, false)));
            return dto;
        } else if ("1".equals(deadline.getEndDateType())){
            LocalDate endDate = startDate.plusMonths(1).withDayOfMonth(deadline.getNum());
            dto.setEndDate(endDate);
            dto.setEndDateTxt(endDate.format(DateTimeFormatter.ofPattern(deadline.getTemplate())));
            return dto;
        }
        return null;
    }
}
