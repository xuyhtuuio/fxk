package com.maxnerva.cloudmes.models.dto.excel.scrap;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.NumberFormat;
import com.alibaba.excel.annotation.write.style.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("固废缴款单分账信息DTO")
@Data
public class SteelPaymentSplitInfoExportDTO {
    @ApiModelProperty("厂部名称")
    @ExcelProperty(value = "厂部名称")
    private String departmentCodeName;

    @ApiModelProperty("入库重量")
    @ExcelProperty(value = "入库重量")
    private BigDecimal inStoreNetWeight;

    @ApiModelProperty("入库占比")
    @ContentStyle(dataFormat = 10)
    @ExcelProperty(value = "入库占比")
    private BigDecimal inStorePercentage;

    @ApiModelProperty("分账金额")
    @ExcelProperty(value = "分账金额")
    private BigDecimal splitAccount;

    @ApiModelProperty("费用代码")
    @ExcelProperty(value = "费用代码")
    private String costCode;
}
