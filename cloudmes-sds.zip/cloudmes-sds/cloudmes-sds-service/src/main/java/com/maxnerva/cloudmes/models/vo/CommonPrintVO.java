package com.maxnerva.cloudmes.models.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName CommonPrintVO
 * @Description 打印公共请求vo
 * @Author Likun
 * @Date 2024/11/5
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("打印公共请求vo")
@Data
public class CommonPrintVO {

    @ApiModelProperty(value = "工厂组织",required = true)
    private String orgCode;

    @ApiModelProperty(value = "模板id")
    private String printTemplateId;

    @ApiModelProperty("打印类型")
    private String printType;
}
