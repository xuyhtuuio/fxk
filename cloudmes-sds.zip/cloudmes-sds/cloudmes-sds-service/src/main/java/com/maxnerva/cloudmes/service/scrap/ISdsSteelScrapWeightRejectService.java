package com.maxnerva.cloudmes.service.scrap;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelScrapWeightRejectDTO;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapWeightReject;
import com.maxnerva.cloudmes.models.vo.scrap.RubbishWeightRejectHandleSubmitVO;
import com.maxnerva.cloudmes.models.vo.scrap.RubbishWeightRejectQueryVO;

import javax.servlet.http.HttpServletResponse;

public interface ISdsSteelScrapWeightRejectService extends IService<SdsSteelScrapWeightReject> {

    PageDataDTO<SteelScrapWeightRejectDTO> selectPageList(RubbishWeightRejectQueryVO vo, Boolean isPage);

    void exportDetail(RubbishWeightRejectQueryVO vo, HttpServletResponse response);

    void handleSubmit(RubbishWeightRejectHandleSubmitVO vo);
}
