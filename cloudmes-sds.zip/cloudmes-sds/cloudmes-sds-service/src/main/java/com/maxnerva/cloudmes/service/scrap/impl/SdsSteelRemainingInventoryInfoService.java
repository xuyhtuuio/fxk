package com.maxnerva.cloudmes.service.scrap.impl;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelRemainingInventoryInfoMapper;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelRemainingInventoryInfo;
import com.maxnerva.cloudmes.models.vo.scrap.SteelRemainingInventoryInfoCreateVO;
import com.maxnerva.cloudmes.service.scrap.ISdsSteelRemainingInventoryInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class SdsSteelRemainingInventoryInfoService extends ServiceImpl<SdsSteelRemainingInventoryInfoMapper, SdsSteelRemainingInventoryInfo> implements ISdsSteelRemainingInventoryInfoService {

    @Override
    public void create(SteelRemainingInventoryInfoCreateVO vo) {
        SdsSteelRemainingInventoryInfo inventoryInfo = new SdsSteelRemainingInventoryInfo();
        BeanUtil.copyProperties(vo, inventoryInfo);
        baseMapper.insert(inventoryInfo);
    }
}
