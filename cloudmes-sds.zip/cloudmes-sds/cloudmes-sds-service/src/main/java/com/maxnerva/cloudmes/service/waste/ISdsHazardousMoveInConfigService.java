package com.maxnerva.cloudmes.service.waste;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.models.dto.waste.WasteMoveInConfigDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousMoveInConfig;

import java.util.List;

/**
 * <p>
 * 危废接受单位配置档 服务类
 * </p>
 *
 * @author likun
 * @since 2025-05-27
 */
public interface ISdsHazardousMoveInConfigService extends IService<SdsHazardousMoveInConfig> {

    List<WasteMoveInConfigDTO> selectMoveInConfigList();
}
