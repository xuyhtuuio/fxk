package com.maxnerva.cloudmes.models.dto.scrap;

import com.maxnerva.cloudmes.models.vo.excel.ExcelMergeCellValue;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Data
public class InventoryReportDTO {

    @ApiModelProperty(value = "报表内容")
    private List<List<ExcelMergeCellValue>> list;

    @ApiModelProperty(value = "报表头行数")
    private Integer headerRowNum;

    @ApiModelProperty(value = "暫存區與ECUS差異比例")
    private Map<String, BigDecimal> rubbishDiffPercentage;

    @ApiModelProperty(value = "各BU稱重與ECUS差異比例")
    private Map<String, BigDecimal> buDiffPercentage;

    @ApiModelProperty(value = "年")
    private String year;

    @ApiModelProperty(value = "月")
    private String month;
}
