package com.maxnerva.cloudmes.models.vo.basic;

import com.maxnerva.cloudmes.models.vo.PageQueryVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @ClassName MaterialClassQueryVO
 * @Description TODO
 * @Author Likun
 * @Date 2024/10/28
 * @Version 1.0
 * @Since JDK 1.8
 **/
@EqualsAndHashCode(callSuper = true)
@ApiModel("物料类别查询vo")
@Data
public class MaterialClassQueryVO extends PageQueryVO {

    @ApiModelProperty(value = "分类代码")
    private String classCode;

    @ApiModelProperty(value = "物料类别")
    private String className;
}
