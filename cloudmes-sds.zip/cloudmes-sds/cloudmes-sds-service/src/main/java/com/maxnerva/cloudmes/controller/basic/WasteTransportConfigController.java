package com.maxnerva.cloudmes.controller.basic;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.waste.WasteTransportConfigDTO;
import com.maxnerva.cloudmes.service.waste.ISdsHazardousTransportConfigService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName WasteTransportConfigController
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/28
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "危废运输单位配置管理")
@Slf4j
@RestController
@RequestMapping("/wasteTransportConfig")
public class WasteTransportConfigController {

    @Resource
    private ISdsHazardousTransportConfigService transportConfigService;

    @ApiOperation("查询危废运输单位配置列表")
    @GetMapping("/list")
    public R<List<WasteTransportConfigDTO>> selectTransportConfigList() {
        return R.ok(transportConfigService.selectTransferConfigList());
    }
}
