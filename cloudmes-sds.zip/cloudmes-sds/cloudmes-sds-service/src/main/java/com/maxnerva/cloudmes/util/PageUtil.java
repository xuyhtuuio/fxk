package com.maxnerva.cloudmes.util;

import cn.hutool.core.collection.CollUtil;
import com.github.pagehelper.Page;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;

import java.util.List;

/**
 * @ClassName PageUtil
 * @Description list分页工具类
 * @Author Cuiyunhao
 * @Date 2024/9/28
 * @Version 1.0
 * @Since JDK 1.8
 **/
public class PageUtil {

    /**
     * 对List 分页
     *
     * @param list      集合
     * @param pageIndex 页码
     * @param pageSize  每页数量
     * @return 分页体
     */
    public static PageDataDTO pageHelper(List list, Integer pageIndex, Integer pageSize) {
        Page page = new Page(pageIndex, pageSize);
        int total = list.size();
        page.setTotal(total);
        int startIndex = (pageIndex - 1) * pageSize;
        int endIndex = Math.min(startIndex + pageSize, total);
        if (startIndex > endIndex) {
            return new PageDataDTO<>(page.getTotal(), CollUtil.newArrayList());
        } else {
            return new PageDataDTO<>(page.getTotal(), list.subList(startIndex, endIndex));
        }
    }
}
