package com.maxnerva.cloudmes.models.vo.scrap;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class PaymentOrderExcelExportVO {

    @ApiModelProperty(value = "缴款通知单号", required = true)
    private String paymentDocNo;

}
