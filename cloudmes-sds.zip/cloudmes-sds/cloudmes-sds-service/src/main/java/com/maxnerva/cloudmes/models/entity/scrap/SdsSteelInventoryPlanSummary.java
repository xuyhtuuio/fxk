package com.maxnerva.cloudmes.models.entity.scrap;

import com.baomidou.mybatisplus.annotation.TableName;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2024-12-19
 */
@TableName("sds_steel_inventory_plan_summary")
@ApiModel(value = "SdsSteelInventoryPlanSummary对象", description = "")
@Data
public class SdsSteelInventoryPlanSummary extends BaseEntity<SdsSteelInventoryPlanSummary> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("单号")
    private String inventoryPlanNo;

    @ApiModelProperty("报废小类")
    private String scrapDetailClass;

    @ApiModelProperty("总净重")
    private BigDecimal totalNetWeight;

    @ApiModelProperty("盘点净重")
    private BigDecimal inventoryNetWeight;

    @ApiModelProperty("描述")
    private String description;

    @ApiModelProperty("盘点执行人")
    private String inventoryExecutorCode;

    @ApiModelProperty("平账量")
    private BigDecimal balanceWeight;

    @ApiModelProperty("平账人")
    private String balanceEmpNo;

    @ApiModelProperty("平账时间")
    private LocalDateTime balanceDt;

    @ApiModelProperty("平账备注")
    private String balanceRemark;

    @ApiModelProperty(value = "状态0未平账，1已平账")
    private String status;
}
