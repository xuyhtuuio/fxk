package com.maxnerva.cloudmes.models.dto.scrap;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


@EqualsAndHashCode(callSuper = true)
@Data
public class GenerateInventoryReportDTO extends InventoryReportDTO {

    private XSSFWorkbook workbook;
}
