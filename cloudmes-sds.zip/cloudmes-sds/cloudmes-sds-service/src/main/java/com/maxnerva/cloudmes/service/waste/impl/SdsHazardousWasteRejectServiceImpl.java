package com.maxnerva.cloudmes.service.waste.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.fastjson2.JSON;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.config.MinIOProperties;
import com.maxnerva.cloudmes.common.constant.BucketConstant;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.common.utils.WebContextUtil;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.enums.WasteDocInfoStatusEnum;
import com.maxnerva.cloudmes.enums.WasteDocOperateType;
import com.maxnerva.cloudmes.enums.WasteDocTypeEnum;
import com.maxnerva.cloudmes.excel.handler.AddNoHandler;
import com.maxnerva.cloudmes.mapper.plan.SdsHazardousWastePlanInfoMapper;
import com.maxnerva.cloudmes.mapper.waste.SdsHazardousWasteDocInfoMapper;
import com.maxnerva.cloudmes.mapper.waste.SdsHazardousWasteRejectMapper;
import com.maxnerva.cloudmes.models.dto.excel.waste.WasteDocRejectExportDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteInStoreRejectDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteDocInfo;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteDocInfoLog;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteReject;
import com.maxnerva.cloudmes.models.vo.waste.InStoreRejectWeightSubmitVO;
import com.maxnerva.cloudmes.models.vo.waste.InStoreWeightRejectHandleSubmitVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteDocInfoUploadImageVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteInStoreRejectQueryVO;
import com.maxnerva.cloudmes.service.waste.ISdsHazardousWasteDocInfoLogService;
import com.maxnerva.cloudmes.service.waste.ISdsHazardousWasteRejectService;
import com.maxnerva.cloudmes.system.feign.IUploadFileClient;
import com.maxnerva.cloudmes.system.models.dto.UploadFileRespDTO;
import com.maxnerva.cloudmes.system.models.vo.FileUploadVO;
import com.maxnerva.cloudmes.system.utils.DictLangUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.MimeTypeUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * <p>
 * 入库拒收处理表 服务实现类
 * </p>
 *
 * @author likun
 * @since 2025-05-16
 */
@Service
public class SdsHazardousWasteRejectServiceImpl extends ServiceImpl<SdsHazardousWasteRejectMapper, SdsHazardousWasteReject> implements ISdsHazardousWasteRejectService {

    @Resource
    private IUploadFileClient uploadFileClient;

    @Resource
    private MinIOProperties minIOProperties;

    @Resource
    private SdsHazardousWasteDocInfoMapper sdsHazardousWasteDocInfoMapper;

    @Resource
    private ISdsHazardousWasteDocInfoLogService sdsHazardousWasteDocInfoLogService;

    @Resource
    private SdsHazardousWastePlanInfoMapper sdsHazardousWastePlanInfoMapper;

    @Resource
    private DictLangUtils dictLangUtils;


    @Override
    public PageDataDTO<WasteInStoreRejectDTO> selectWasteInStoreRejectPage(WasteInStoreRejectQueryVO queryVO) {
        if (queryVO.getPageIndex() != null && queryVO.getPageSize() != null
                && queryVO.getPageIndex() != 0 && queryVO.getPageSize() != 0) {
            Page page = PageHelper.startPage(queryVO.getPageIndex(), queryVO.getPageSize());
            List<WasteInStoreRejectDTO> wasteInStoreRejectDTOList = getInStoreRejectDTOList(queryVO);
            return new PageDataDTO<>(page.getTotal(), wasteInStoreRejectDTOList);
        } else {
            List<WasteInStoreRejectDTO> wasteInStoreRejectDTOList = getInStoreRejectDTOList(queryVO);
            return new PageDataDTO<>((long) wasteInStoreRejectDTOList.size(), wasteInStoreRejectDTOList);
        }
    }

    @NotNull
    private List<WasteInStoreRejectDTO> getInStoreRejectDTOList(WasteInStoreRejectQueryVO queryVO) {
        List<WasteInStoreRejectDTO> wasteInStoreRejectDTOList = baseMapper.selectWasteInStoreRejectList(queryVO);
        List<String> types = CollUtil.newArrayList();
        types.add("SDS_IN_STORE_REJECT_STATUS");
        types.add("SDS_HAZARDOUS_WASTE_HANDLE_METHOD");
        types.add("SDS_HAZARDOUS_WASTE_REJECT_REASON");
        Map<String, Map<String, String>> data = dictLangUtils.getByTypes(types);
        Map<String, String> statusMap = data.get("SDS_IN_STORE_REJECT_STATUS");
        Map<String, String> handleMethodMap = data.get("SDS_HAZARDOUS_WASTE_HANDLE_METHOD");
        Map<String, String> rejectReasonMap = data.get("SDS_HAZARDOUS_WASTE_REJECT_REASON");
        wasteInStoreRejectDTOList.forEach(wasteInStoreRejectDTO -> {
            wasteInStoreRejectDTO.setStatusName(statusMap.get(wasteInStoreRejectDTO.getStatus()));
            wasteInStoreRejectDTO.setHandleMethodName(handleMethodMap.get(wasteInStoreRejectDTO.getHandleMethod()));
            wasteInStoreRejectDTO.setRejectReasonTypeName(rejectReasonMap.get(wasteInStoreRejectDTO.getRejectReasonType()));
        });
        return wasteInStoreRejectDTOList;
    }

    @Override
    public void uploadImage(WasteDocInfoUploadImageVO uploadImageVO) {
        Integer id = uploadImageVO.getId();
        FileUploadVO fileUploadVO = new FileUploadVO();
        fileUploadVO.setBucketName("cloudsaas");
        fileUploadVO.setFiles(uploadImageVO.getFiles());
        R<List<UploadFileRespDTO>> result = uploadFileClient.uploadBatch(fileUploadVO);
        List<UploadFileRespDTO> uploadFileRespDTOList = result.getData();
        List<String> urlList = uploadFileRespDTOList.stream().map(UploadFileRespDTO::getName)
                .collect(Collectors.toList());
        baseMapper.update(null, Wrappers.<SdsHazardousWasteReject>lambdaUpdate()
                .setSql("reject_image_list = reject_image_list")
                .eq(SdsHazardousWasteReject::getId, uploadImageVO.getId()));
        SdsHazardousWasteReject sdsHazardousWasteReject = baseMapper.selectById(id);
        String imageUrlListStr = sdsHazardousWasteReject.getRejectImageList();
        List<String> imageUrlList;
        if (StrUtil.isBlank(imageUrlListStr)) {
            imageUrlList = urlList;
        } else {
            imageUrlList = JSON.parseArray(imageUrlListStr, String.class);
            imageUrlList.addAll(urlList);
        }
        baseMapper.update(null, Wrappers.<SdsHazardousWasteReject>lambdaUpdate()
                .set(SdsHazardousWasteReject::getRejectImageList, JSON.toJSONString(imageUrlList))
                .set(SdsHazardousWasteReject::getLastEditor, WebContextUtil.getCurrentStaffCode())
                .set(SdsHazardousWasteReject::getLastEditedDt, LocalDateTime.now())
                .eq(SdsHazardousWasteReject::getId, id));
    }

    @Override
    public List<String> selectImageList(Integer id) {
        String imageUrl = baseMapper.getRejectImageUrlList(id);
        List<String> imageUrlList = CollUtil.newArrayList();
        if (StrUtil.isNotEmpty(imageUrl)) {
            List<String> imageList = JSON.parseArray(imageUrl).toList(String.class);
            imageUrlList = imageList.stream().map(link -> minIOProperties.getFileAddr(BucketConstant.CLOUD_SAAS, link))
                    .collect(Collectors.toList());
        }
        return imageUrlList;
    }

    @Override
    public void handleSubmit(InStoreWeightRejectHandleSubmitVO submitVO) {
        String currentStaffCode = WebContextUtil.getCurrentStaffCode();
        Integer id = submitVO.getId();
        String docNo = submitVO.getDocNo();
        baseMapper.update(null, Wrappers.<SdsHazardousWasteReject>lambdaUpdate()
                .eq(SdsHazardousWasteReject::getId, id)
                .set(SdsHazardousWasteReject::getHandleDt, LocalDateTime.now())
                .set(SdsHazardousWasteReject::getHandleEmpNo, currentStaffCode)
                .set(SdsHazardousWasteReject::getHandleMethod, submitVO.getHandleMethod())
                .set(SdsHazardousWasteReject::getStatus, "1")
                .set(SdsHazardousWasteReject::getLastEditor, currentStaffCode)
                .set(SdsHazardousWasteReject::getLastEditedDt, LocalDateTime.now()));
        SdsHazardousWasteDocInfo sdsHazardousWasteDocInfo = sdsHazardousWasteDocInfoMapper
                .selectOne(Wrappers.<SdsHazardousWasteDocInfo>lambdaQuery()
                        .eq(SdsHazardousWasteDocInfo::getDocNo, docNo)
                        .orderByDesc(SdsHazardousWasteDocInfo::getId)
                        .last("limit 1"));
        if (!submitVO.getOrgCode().equals(sdsHazardousWasteDocInfo.getOrgCode())) {
            throw new CloudmesException(SdsResultCode.ORG_CODE_IN_CONSISTEN_CAN_NOT_HANDLE.getCode(),
                    String.format(MessageUtils.get(SdsResultCode.ORG_CODE_IN_CONSISTEN_CAN_NOT_HANDLE.getLocalCode()),
                            submitVO.getOrgCode(),sdsHazardousWasteDocInfo.getOrgCode()));
        }
        SdsHazardousWasteDocInfoLog sdsHazardousWasteDocInfoLog = new SdsHazardousWasteDocInfoLog();
        BeanUtils.copyProperties(sdsHazardousWasteDocInfo, sdsHazardousWasteDocInfoLog);
        sdsHazardousWasteDocInfoLog.setId(null);
        sdsHazardousWasteDocInfoLog.setOperateType(WasteDocOperateType.IN_STORE_ERR_REJECT_HANDLE.getDictCode());
        sdsHazardousWasteDocInfoLog.setOperateMsg(WasteDocOperateType.IN_STORE_ERR_REJECT_HANDLE.getDictName());
        sdsHazardousWasteDocInfoLogService.save(sdsHazardousWasteDocInfoLog);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void rejectWeightInfo(InStoreRejectWeightSubmitVO submitVO) {
        String currentStaffCode = WebContextUtil.getCurrentStaffCode();
        String orgCode = submitVO.getOrgCode();
        String docNo = submitVO.getDocNo();
        SdsHazardousWasteDocInfo sdsHazardousWasteDocInfo = sdsHazardousWasteDocInfoMapper
                .selectOne(Wrappers.<SdsHazardousWasteDocInfo>lambdaQuery()
                        .eq(SdsHazardousWasteDocInfo::getDocNo, docNo)
                        .last("limit 1"));
        Optional.ofNullable(sdsHazardousWasteDocInfo)
                .orElseThrow(() -> new CloudmesException(SdsResultCode.WASTE_DOC_NOT_EXIST_CAN_NOT_REJECT.getCode(),
                        String.format(MessageUtils.get(SdsResultCode.WASTE_DOC_NOT_EXIST_CAN_NOT_REJECT.getLocalCode()),
                                docNo)));
        Optional.of(sdsHazardousWasteDocInfo)
                .filter(docInfo -> WasteDocTypeEnum.STORAGE.getDictCode().equals(docInfo.getDocType()))
                .orElseThrow(() -> new CloudmesException(SdsResultCode.DOC_IS_NOT_STORAGE_CAN_NOT_REJECT.getCode(),
                        String.format(MessageUtils.get(SdsResultCode.DOC_IS_NOT_STORAGE_CAN_NOT_REJECT.getLocalCode()),
                                docNo)));
        Optional.of(sdsHazardousWasteDocInfo)
                .filter(docInfo -> !WasteDocInfoStatusEnum.CREATED_SHIP_DOC.getDictCode().equals(docInfo.getDocStatus()))
                .orElseThrow(() -> new CloudmesException(SdsResultCode.DOC_HAVE_BEEN_CREATED_SHIP_INFO_CAN_NOT_REJECT
                        .getCode(), String.format(MessageUtils.get(SdsResultCode
                                .DOC_HAVE_BEEN_CREATED_SHIP_INFO_CAN_NOT_REJECT.getLocalCode()), docNo)));
        Long count = baseMapper.selectCount(Wrappers.<SdsHazardousWasteReject>lambdaQuery()
                        .eq(SdsHazardousWasteReject::getDocNo, docNo)
                        .last("limit 1"));
        if (count > 0) {
            throw new CloudmesException(SdsResultCode.DOC_HAVE_BEEN_REJECT.getCode(),
                    String.format(MessageUtils.get(SdsResultCode.DOC_HAVE_BEEN_REJECT.getLocalCode()), docNo));
        }
        sdsHazardousWasteDocInfoMapper.update(null, Wrappers.<SdsHazardousWasteDocInfo>lambdaUpdate()
                .eq(SdsHazardousWasteDocInfo::getId, sdsHazardousWasteDocInfo.getId())
                .set(SdsHazardousWasteDocInfo::getIsDeleted, Boolean.TRUE)
                .set(SdsHazardousWasteDocInfo::getLastEditor, currentStaffCode)
                .set(SdsHazardousWasteDocInfo::getLastEditedDt, LocalDateTime.now()));
        SdsHazardousWasteReject sdsHazardousWasteReject = new SdsHazardousWasteReject();
        BeanUtils.copyProperties(sdsHazardousWasteDocInfo, sdsHazardousWasteReject);
        sdsHazardousWasteReject.setId(null);
        sdsHazardousWasteReject.setRejectEmpNo(submitVO.getOperateEmpNo());
        sdsHazardousWasteReject.setRejectDt(LocalDateTime.now());
        sdsHazardousWasteReject.setRejectReasonType(submitVO.getOperateRemarkType());
        sdsHazardousWasteReject.setDocId(sdsHazardousWasteDocInfo.getId());
        baseMapper.insert(sdsHazardousWasteReject);
        SdsHazardousWasteDocInfoLog sdsHazardousWasteDocInfoLog = new SdsHazardousWasteDocInfoLog();
        BeanUtils.copyProperties(sdsHazardousWasteDocInfo, sdsHazardousWasteDocInfoLog);
        sdsHazardousWasteDocInfoLog.setId(null);
        sdsHazardousWasteDocInfoLog.setOperateType(WasteDocOperateType.IN_STORE_ERR_REJECT.getDictCode());
        sdsHazardousWasteDocInfoLog.setOperateMsg(WasteDocOperateType.IN_STORE_ERR_REJECT.getDictName());
        sdsHazardousWasteDocInfoLogService.save(sdsHazardousWasteDocInfoLog);
        String costCode = sdsHazardousWasteDocInfo.getCostCode();
        String hazardousWasteNo = sdsHazardousWasteDocInfo.getHazardousWasteNo();
        int year = LocalDate.now().getYear();
        sdsHazardousWastePlanInfoMapper.subtractUsedWeight(orgCode, costCode, String.valueOf(year), hazardousWasteNo,
                sdsHazardousWasteDocInfo.getApplyNetWeight(), currentStaffCode);
    }

    @Override
    public List<String> selectWasteImageList(Integer id) {
        String imageUrl = baseMapper.getWasteImageUrlList(id);
        List<String> imageUrlList = CollUtil.newArrayList();
        if (StrUtil.isNotEmpty(imageUrl)) {
            List<String> imageList = JSON.parseArray(imageUrl).toList(String.class);
            imageUrlList = imageList.stream().map(link -> minIOProperties.getFileAddr(BucketConstant.CLOUD_SAAS, link))
                    .collect(Collectors.toList());
        }
        return imageUrlList;
    }

    @Override
    public void exportDocRejectInfo(HttpServletResponse response, WasteInStoreRejectQueryVO queryVO) {
        List<WasteDocRejectExportDTO> exportDTOList = CollUtil.newArrayList();
        List<WasteInStoreRejectDTO> wasteInStoreRejectDTOList = getInStoreRejectDTOList(queryVO);
        wasteInStoreRejectDTOList.forEach(wasteInStoreRejectDTO -> {
            WasteDocRejectExportDTO wasteDocRejectExportDTO = new WasteDocRejectExportDTO();
            BeanUtils.copyProperties(wasteInStoreRejectDTO, wasteDocRejectExportDTO);
            exportDTOList.add(wasteDocRejectExportDTO);
        });
        String fileName = "入库拒收信息" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), WasteDocRejectExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.HAZARDOUS_WASTE_DOC_REJECT_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.HAZARDOUS_WASTE_DOC_REJECT_EXPORT_FAIL.getLocalCode()));
        }
    }
}
