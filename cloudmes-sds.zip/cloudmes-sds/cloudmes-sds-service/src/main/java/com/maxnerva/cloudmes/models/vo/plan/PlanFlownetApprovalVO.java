package com.maxnerva.cloudmes.models.vo.plan;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName PlanFlownetApprovalVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/6/9
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("flownet审核完成调用服务节点vo")
@Data
public class PlanFlownetApprovalVO {

    @ApiModelProperty(value = "json参数")
    private String jsonString;
}
