package com.maxnerva.cloudmes.models.dto.excel.scrap;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.excel.converter.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("固废盘点核账记录DTO")
@Data
public class SteelInventoryBalanceLogExportDTO {
    @ApiModelProperty("盘点单号")
    @ExcelProperty(value = "盘点单号")
    private String inventoryPlanNo;

    @ApiModelProperty("报废类别")
    @ExcelProperty(value = "报废类别")
    private String scrapDetailClassName;

    @ApiModelProperty("平账备注")
    @ExcelProperty(value = "平账备注")
    private String balanceRemark;

    @ApiModelProperty("库存总净重")
    @ExcelProperty(value = "库存总净重")
    private BigDecimal totalNetWeight;

    @ApiModelProperty("盘点净重")
    @ExcelProperty(value = "盘点净重")
    private BigDecimal inventoryNetWeight;

    @ApiModelProperty("平账量")
    @ExcelProperty(value = "平账量")
    private BigDecimal balanceWeight;

    @ApiModelProperty("平账类型")
    @ExcelProperty(value = "平账类型")
    private String balanceTypeName;

    @ApiModelProperty("平账人")
     @ExcelProperty(value = "平账人")
    private String balanceEmpNo;

    @ApiModelProperty("平账时间")
    @ExcelProperty(value = "平账时间", converter = LocalDateTimeStringConverter.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime balanceDt;
}
