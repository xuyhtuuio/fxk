package com.maxnerva.cloudmes.service.scrap.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.NumberUtil;
import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.excel.handler.AddNoHandler;
import com.maxnerva.cloudmes.mapper.basic.SdsDepartmentConfigMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelPaymentSplitInfoMapper;
import com.maxnerva.cloudmes.models.dto.excel.scrap.SteelPaymentHeaderExportDTO;
import com.maxnerva.cloudmes.models.dto.excel.scrap.SteelPaymentSplitInfoExportDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelPaymentHeaderDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelPaymentSplitInfoDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsDepartmentConfig;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelPaymentSplitInfo;
import com.maxnerva.cloudmes.models.vo.scrap.SteelPaymentSplitInfoQueryVO;
import com.maxnerva.cloudmes.service.scrap.ISdsSteelPaymentSplitInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;

import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
public class SdsSteelPaymentSplitInfoService extends ServiceImpl<SdsSteelPaymentSplitInfoMapper, SdsSteelPaymentSplitInfo> implements ISdsSteelPaymentSplitInfoService {

    @Autowired
    SdsDepartmentConfigMapper departmentConfigMapper;

    @Override
    public PageDataDTO<SteelPaymentSplitInfoDTO> selectPageList(SteelPaymentSplitInfoQueryVO vo, Boolean isPage) {
        Page page = new Page();
        if (BooleanUtil.isTrue(isPage)){
            page = PageHelper.startPage(vo.getPageIndex(), vo.getPageSize());
        }
        List<SteelPaymentSplitInfoDTO> list = baseMapper.selectPageList(vo);
        List<SdsDepartmentConfig> sdsDepartmentConfigList = departmentConfigMapper.selectList(Wrappers.<SdsDepartmentConfig>lambdaQuery()
                .select(SdsDepartmentConfig::getDepartmentCode, SdsDepartmentConfig::getDepartmentName)
        );
        Map<String, String> departmentConfigMap = sdsDepartmentConfigList.stream().collect(Collectors.toMap(k -> k.getDepartmentCode(), v -> v.getDepartmentName()));
        list.forEach(item -> {
            item.setDepartmentCodeName(departmentConfigMap.get(item.getDepartmentCode()));
            item.setInStorePercentageName(NumberUtil.decimalFormat("0.00%", item.getInStorePercentage()));
        });
        return new PageDataDTO(page.getTotal(), list);
    }

    @Override
    public void exportDetail(SteelPaymentSplitInfoQueryVO vo, HttpServletResponse response) {
        PageDataDTO<SteelPaymentSplitInfoDTO> pageDataDTO = selectPageList(vo, Boolean.FALSE);
        List<SteelPaymentSplitInfoExportDTO> exportDTOList = ListUtil.toList();
        pageDataDTO.getList().forEach(item -> {
            SteelPaymentSplitInfoExportDTO dto = new SteelPaymentSplitInfoExportDTO();
            BeanUtil.copyProperties(item, dto);
            exportDTOList.add(dto);
        });

        String fileName = "固废缴款单分账明细" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), SteelPaymentSplitInfoExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getLocalCode()));
        }
    }
}
