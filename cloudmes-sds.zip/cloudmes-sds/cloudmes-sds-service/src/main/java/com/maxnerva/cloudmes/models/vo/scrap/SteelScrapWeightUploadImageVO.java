package com.maxnerva.cloudmes.models.vo.scrap;

import com.maxnerva.cloudmes.models.vo.CommonRequestVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@ApiModel("固废称重上传图片vo")
@Data
public class SteelScrapWeightUploadImageVO extends CommonRequestVO {
    @ApiModelProperty(value = "文件", required = true)
    private List<MultipartFile> files;

    @ApiModelProperty(value = "托盘编码", required = true)
    private String bucketNo;
}
