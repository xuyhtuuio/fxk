package com.maxnerva.cloudmes.service.waste;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.models.dto.waste.WasteTransferDetailDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteTransferDetail;
import com.maxnerva.cloudmes.models.vo.waste.TransferDetailUploadImageVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteTransferDetailQueryVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteTransferDetailUpdateVO;

import java.util.List;

/**
 * <p>
 * 危废转移单明细 服务类
 * </p>
 *
 * @author likun
 * @since 2025-05-27
 */
public interface ISdsHazardousWasteTransferDetailService extends IService<SdsHazardousWasteTransferDetail> {

    List<WasteTransferDetailDTO> selectDetailList(WasteTransferDetailQueryVO queryVO);

    List<String> selectImageUrlList(Integer id);

    void uploadImage(TransferDetailUploadImageVO uploadImageVO);

    void updateDetail(WasteTransferDetailUpdateVO updateVO);

    void deleteDetail(Integer id);
}
