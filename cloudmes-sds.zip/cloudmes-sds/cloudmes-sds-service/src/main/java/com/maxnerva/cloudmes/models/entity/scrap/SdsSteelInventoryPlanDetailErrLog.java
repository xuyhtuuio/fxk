package com.maxnerva.cloudmes.models.entity.scrap;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 固废盘点记录
 * </p>
 *
 * @author baomidou
 * @since 2024-12-18
 */
@TableName("sds_steel_inventory_plan_detail_err_log")
@ApiModel(value = "SdsSteelInventoryPlanDetailErrLog对象", description = "固废盘点记录")
@Data
public class SdsSteelInventoryPlanDetailErrLog extends BaseEntity<SdsSteelInventoryPlanDetailErrLog> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("盘点单号")
    private String inventoryPlanNo;

    @ApiModelProperty("报废小类")
    private String scrapDetailClass;

    @ApiModelProperty("总净重")
    private BigDecimal totalNetWeight;

    @ApiModelProperty("净重")
    private BigDecimal netWeight;

    @ApiModelProperty("托盘编码")
    private String bucketNo;

    @ApiModelProperty("托盘重量")
    private BigDecimal bucketWeight;

    @ApiModelProperty("毛重")
    private BigDecimal grossWeight;
}
