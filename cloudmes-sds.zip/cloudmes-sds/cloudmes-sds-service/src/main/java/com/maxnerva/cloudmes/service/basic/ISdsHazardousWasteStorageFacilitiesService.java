package com.maxnerva.cloudmes.service.basic;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.models.entity.basic.SdsHazardousWasteStorageFacilities;

import java.util.List;

/**
 * <p>
 * 危废贮存设施表 服务类
 * </p>
 *
 * @author likun
 * @since 2025-05-14
 */
public interface ISdsHazardousWasteStorageFacilitiesService extends IService<SdsHazardousWasteStorageFacilities> {

    List<String> selectFacilitiesNameList();
}
