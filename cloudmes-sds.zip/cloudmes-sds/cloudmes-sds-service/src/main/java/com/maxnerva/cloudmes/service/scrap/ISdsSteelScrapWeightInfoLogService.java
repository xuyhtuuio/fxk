package com.maxnerva.cloudmes.service.scrap;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelScrapWeightInfoLogDTO;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapWeightInfoLog;
import com.maxnerva.cloudmes.models.vo.scrap.SteelScrapWeightLogQueryVO;

import javax.servlet.http.HttpServletResponse;

public interface ISdsSteelScrapWeightInfoLogService extends IService<SdsSteelScrapWeightInfoLog> {

    PageDataDTO<SteelScrapWeightInfoLogDTO> selectPageList(SteelScrapWeightLogQueryVO vo, Boolean isPage);

    void exportDetail(SteelScrapWeightLogQueryVO vo, HttpServletResponse response);
}
