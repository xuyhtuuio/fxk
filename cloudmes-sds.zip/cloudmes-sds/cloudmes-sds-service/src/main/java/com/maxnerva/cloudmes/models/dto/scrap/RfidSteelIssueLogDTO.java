package com.maxnerva.cloudmes.models.dto.scrap;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class RfidSteelIssueLogDTO {
    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("托盘编码")
    private String bucketNo;

    private String host;

    private String port;

    @ApiModelProperty("异常类型")
    private String issueType;

    @ApiModelProperty("异常描述")
    private String issueMessage;

    @ApiModelProperty("是否处理")
    private String handleFlag;

    @ApiModelProperty("处理人")
    private String handleEmpNo;

    @ApiModelProperty("处理时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime handleDt;

    @ApiModelProperty(value = "创建人")
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "创建时间")
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "修改人")
    private String lastEditor;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "修改时间")
    private LocalDateTime lastEditedDt;
}
