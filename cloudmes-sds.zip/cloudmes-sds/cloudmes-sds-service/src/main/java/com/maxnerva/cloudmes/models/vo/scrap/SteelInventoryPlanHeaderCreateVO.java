package com.maxnerva.cloudmes.models.vo.scrap;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class SteelInventoryPlanHeaderCreateVO {
    @ApiModelProperty("描述")
    private String description;

    @ApiModelProperty("盘点执行人")
    private String inventoryExecutorCode;

    @ApiModelProperty("报废小类")
    private String scrapDetailClass;
}
