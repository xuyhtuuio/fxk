package com.maxnerva.cloudmes.models.dto.scrap;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class SteelInventoryPlanDetailErrLogDTO {

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("盘点单号")
    private String inventoryPlanNo;

    @ApiModelProperty("报废小类")
    private String scrapDetailClass;

    @ApiModelProperty("报废小类名")
    private String scrapDetailClassName;

    @ApiModelProperty("总净重")
    private BigDecimal totalNetWeight;

    @ApiModelProperty("净重")
    private BigDecimal netWeight;

    @ApiModelProperty("托盘编码")
    private String bucketNo;

    @ApiModelProperty("托盘重量")
    private BigDecimal bucketWeight;

    @ApiModelProperty("毛重")
    private BigDecimal grossWeight;

    @ApiModelProperty(value = "创建人")
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "创建时间")
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "修改人")
    private String lastEditor;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "修改时间")
    private LocalDateTime lastEditedDt;
}
