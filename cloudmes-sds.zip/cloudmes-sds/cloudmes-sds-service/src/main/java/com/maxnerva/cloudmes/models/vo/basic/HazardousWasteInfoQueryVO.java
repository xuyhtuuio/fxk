package com.maxnerva.cloudmes.models.vo.basic;

import com.maxnerva.cloudmes.models.vo.PageQueryVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @ClassName HazardousWasteInfoQueryVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/7
 * @Version 1.0
 * @Since JDK 1.8
 **/
@EqualsAndHashCode(callSuper = true)
@ApiModel("危废信息查询vo")
@Data
public class HazardousWasteInfoQueryVO extends PageQueryVO {

    @ApiModelProperty(value = "废物俗称")
    private String hazardousWasteName;

    @ApiModelProperty(value = "废物代码")
    private String hazardousWasteCode;

    @ApiModelProperty(value = "废物类别")
    private String hazardousWasteCategory;
}
