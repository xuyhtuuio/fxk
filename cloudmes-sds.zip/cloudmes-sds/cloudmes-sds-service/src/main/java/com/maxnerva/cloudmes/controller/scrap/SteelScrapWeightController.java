package com.maxnerva.cloudmes.controller.scrap;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.scrap.SteelScrapWeightInfoDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelScrapWeightInfoLogDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SyncWmsScrapHandlePalletDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsRfidSteelBucketLink;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapWeightInfo;
import com.maxnerva.cloudmes.models.vo.scrap.*;
import com.maxnerva.cloudmes.service.scrap.ISdsSteelScrapWeightInfoLogService;
import com.maxnerva.cloudmes.service.scrap.ISdsSteelScrapWeightInfoService;
import com.maxnerva.cloudmes.service.scrap.ISdsSteelScrapWeightRejectService;
import com.maxnerva.cloudmes.service.scrap.ISteelScrapWeightService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Api(tags = "固废品称重管理")
@Slf4j
@RestController
@RequestMapping("/steelScrapWeight")
public class SteelScrapWeightController {

    @Autowired
    private ISdsSteelScrapWeightInfoService steelScrapWeightInfoService;

    @Autowired
    private ISteelScrapWeightService steelScrapWeightService;

    @Autowired
    private ISdsSteelScrapWeightInfoLogService steelScrapWeightInfoLogService;

    @Autowired
    private ISdsSteelScrapWeightRejectService steelScrapWeightRejectService;

    @ApiOperation("分页查询")
    @GetMapping("/getWeightInfoPageList")
    R<PageDataDTO<SteelScrapWeightInfoDTO>> selectPageList(SteelScrapWeightInfoQueryVO vo){
        return R.ok(steelScrapWeightInfoService.selectPageList(vo, Boolean.TRUE));
    }

    @ApiOperation("导出明细")
    @GetMapping("/exportWeightInfoDetail")
    void exportDetail(SteelScrapWeightInfoQueryVO vo, HttpServletResponse response){
        steelScrapWeightInfoService.exportDetail(vo, response);
    }

    @ApiOperation("称重提交")
    @PostMapping("/submitWeightInfo")
    R<SdsSteelScrapWeightInfo> submitWeightInfo(@RequestBody SteelScrapWeightSubmitVO vo){
        return R.ok(steelScrapWeightService.submitWeightInfo(vo));
    }

    @ApiOperation("查询并check能否接收")
    @GetMapping("/getCheckAcceptConfirm")
    R<SteelScrapWeightInfoDTO> getCheckAcceptConfirm(SteelScrapWeightInfoQueryOneVO vo){
        return R.ok(steelScrapWeightService.getCheckAcceptConfirm(vo));
    }

    @ApiOperation("接收确认")
    @PostMapping("/acceptConfirm")
    R acceptConfirm(@RequestBody SteelScrapWeightAcceptVO vo){
        steelScrapWeightService.acceptConfirm(vo);
        return R.ok();
    }

    @ApiOperation("查询并check能否上传图片")
    @GetMapping("/getCheckUploadImage")
    R<SteelScrapWeightInfoDTO> getCheckUploadImage(SteelScrapWeightInfoQueryOneVO vo){
        return R.ok(steelScrapWeightService.getCheckUploadImage(vo));
    }

    @ApiOperation("上传图片")
    @PostMapping("/uploadImage")
    R uploadImage(SteelScrapWeightUploadImageVO vo){
        log.info("uploadImage");
        steelScrapWeightService.uploadImage(vo);
        return R.ok();
    }

    @ApiOperation("分页查询LOG")
    @GetMapping("/getWeightInfoLogPageList")
    R<PageDataDTO<SteelScrapWeightInfoLogDTO>> getWeightInfoLogPageList(SteelScrapWeightLogQueryVO vo){
        return R.ok(steelScrapWeightInfoLogService.selectPageList(vo, Boolean.TRUE));
    }

    @ApiOperation("导出LOG明细")
    @GetMapping("/exportWeightInfoLogDetail")
    void exportWeightInfoLogDetail(SteelScrapWeightLogQueryVO vo, HttpServletResponse response){
        steelScrapWeightInfoLogService.exportDetail(vo, response);
    }

    @ApiOperation("RFID和钢桶编码对应关系")
    @GetMapping("/getRfidBucketNoLink")
    R<List<SdsRfidSteelBucketLink>> getRfidBucketNoLink(){
        return R.ok(steelScrapWeightService.getRfidBucketNoLink());
    }

    @ApiOperation("提供WMS抛转报废处理栈板")
    @PostMapping("/syncWmsScrapHandlePallet")
    R<SyncWmsScrapHandlePalletDTO> syncWmsScrapHandlePallet(@RequestBody SyncWmsScrapHandlePalletVO vo) {
        return R.ok(steelScrapWeightService.syncWmsScrapHandlePallet(vo));
    }
}
