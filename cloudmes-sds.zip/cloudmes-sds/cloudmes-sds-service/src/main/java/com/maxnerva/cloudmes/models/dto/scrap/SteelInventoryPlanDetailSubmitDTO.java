package com.maxnerva.cloudmes.models.dto.scrap;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class SteelInventoryPlanDetailSubmitDTO {

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("托盘编码")
    private String bucketNo;

    @ApiModelProperty("托盘重量")
    private BigDecimal bucketWeight;

    @ApiModelProperty("毛重")
    private BigDecimal grossWeight;

    @ApiModelProperty("净重")
    private BigDecimal netWeight;
}
