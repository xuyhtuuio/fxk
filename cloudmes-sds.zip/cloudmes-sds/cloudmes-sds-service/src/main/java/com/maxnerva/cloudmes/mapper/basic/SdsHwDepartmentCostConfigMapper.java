package com.maxnerva.cloudmes.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.dto.basic.CostCodeNameDTO;
import com.maxnerva.cloudmes.models.dto.basic.HwDepartmentCostConfigDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsHwDepartmentCostConfig;
import com.maxnerva.cloudmes.models.vo.basic.HwDepartmentCostConfigQueryVO;

import java.util.List;

/**
 * <p>
 * 危废费用部门配置表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2025-05-06
 */
public interface SdsHwDepartmentCostConfigMapper extends BaseMapper<SdsHwDepartmentCostConfig> {

    List<HwDepartmentCostConfigDTO> selectDepartmentCostConfigList(HwDepartmentCostConfigQueryVO queryVO);

    List<String> selectCostCodeListByOrgCode(String orgCode);

    List<CostCodeNameDTO> selectCostCodeNameInfo(String orgCode);
}
