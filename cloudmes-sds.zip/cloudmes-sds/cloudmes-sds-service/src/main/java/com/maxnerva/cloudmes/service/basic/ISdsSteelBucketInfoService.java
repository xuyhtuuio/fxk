package com.maxnerva.cloudmes.service.basic;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.models.dto.basic.BucketNoPrintDTO;
import com.maxnerva.cloudmes.models.dto.basic.SteelBucketDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsSteelBucketInfo;
import com.maxnerva.cloudmes.models.vo.basic.BucketNoPrintVO;
import com.maxnerva.cloudmes.models.vo.basic.SteelBucketQueryVO;
import com.maxnerva.cloudmes.models.vo.basic.SteelBucketSaveOrUpdateVO;
import com.maxnerva.cloudmes.models.vo.excel.ExcelImportVO;
import com.maxnerva.cloudmes.models.vo.excel.basic.SteelBucketExcelImportVO;

import javax.servlet.http.HttpServletResponse;

/**
 * <p>
 * 托盘信息表 服务类
 * </p>
 *
 * @author likun
 * @since 2024-10-28
 */
public interface ISdsSteelBucketInfoService extends IService<SdsSteelBucketInfo> {

    PageDataDTO<SteelBucketDTO> selectSteelBucketInfoPage(SteelBucketQueryVO queryVO);

    void saveSteelBucket(SteelBucketSaveOrUpdateVO steelBucketSaveOrUpdateVO);

    void updateSteelBucket(SteelBucketSaveOrUpdateVO steelBucketSaveOrUpdateVO);

    void deleteSteelBucket(Integer id);

    void importSteelBucket(SteelBucketExcelImportVO steelBucketExcelImportVO);

    void exportSteelBucket(HttpServletResponse response, SteelBucketQueryVO queryVO);

    BucketNoPrintDTO printBucketNoInfo(BucketNoPrintVO bucketNoPrintVO);
}
