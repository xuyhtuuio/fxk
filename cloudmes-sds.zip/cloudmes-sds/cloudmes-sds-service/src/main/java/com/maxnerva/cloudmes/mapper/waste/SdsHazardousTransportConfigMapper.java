package com.maxnerva.cloudmes.mapper.waste;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.dto.waste.WasteTransportConfigDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousTransportConfig;

import java.util.List;

/**
 * <p>
 * 危废运输单位配置档 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2025-05-27
 */
public interface SdsHazardousTransportConfigMapper extends BaseMapper<SdsHazardousTransportConfig> {

    List<WasteTransportConfigDTO> selectTransferConfigList();
}
