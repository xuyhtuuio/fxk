package com.maxnerva.cloudmes.service.scrap;

import com.maxnerva.cloudmes.models.entity.scrap.SdsWeightLockConfig;
import com.maxnerva.cloudmes.models.vo.scrap.SdsWeightLockConfigVO;

/**
 * @ClassName ISdsWeightLockConfigService
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/2/14 上午 09:53
 * @Version 1.0
 **/
public interface ISdsWeightLockConfigService {
    // 获取锁定配置
    SdsWeightLockConfig getSdsWeightLock();

    void editSdsWeightLockConfig(SdsWeightLockConfigVO sdsWeightLockConfigVO);
}
