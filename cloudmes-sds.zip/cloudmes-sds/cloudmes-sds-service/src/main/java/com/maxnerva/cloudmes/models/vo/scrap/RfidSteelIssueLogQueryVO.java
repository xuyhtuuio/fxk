package com.maxnerva.cloudmes.models.vo.scrap;

import com.maxnerva.cloudmes.models.vo.PageQueryVO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class RfidSteelIssueLogQueryVO extends PageQueryVO {

    @ApiModelProperty(value = "位置名称")
    private String positionName;

    @ApiModelProperty(value = "是否处理")
    private String handleFlag;
}
