package com.maxnerva.cloudmes.service.basic.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.mapper.basic.SdsSteelMfgConfigMapper;
import com.maxnerva.cloudmes.models.entity.basic.SdsSteelMfgConfig;
import com.maxnerva.cloudmes.service.basic.ISdsSteelMfgConfigService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class SdsSteelMfgConfigService extends ServiceImpl<SdsSteelMfgConfigMapper, SdsSteelMfgConfig> implements ISdsSteelMfgConfigService {


    @Override
    public List<SdsSteelMfgConfig> selectConfigList() {
        List<SdsSteelMfgConfig> configList = baseMapper.selectList(Wrappers.<SdsSteelMfgConfig>lambdaQuery());
        return configList;
    }
}
