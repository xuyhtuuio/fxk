package com.maxnerva.cloudmes.service.basic.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.mapper.basic.SdsScrapSolidTypeConfigMapper;
import com.maxnerva.cloudmes.models.dto.basic.SolidTypeConfigDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsScrapSolidTypeConfig;
import com.maxnerva.cloudmes.service.basic.ISdsScrapSolidTypeConfigService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 固废分类配置表 服务实现类
 * </p>
 *
 * @author likun
 * @since 2024-12-11
 */
@Service
public class SdsScrapSolidTypeConfigServiceImpl extends ServiceImpl<SdsScrapSolidTypeConfigMapper,
        SdsScrapSolidTypeConfig> implements ISdsScrapSolidTypeConfigService {

    @Override
    public SolidTypeConfigDTO selectSolidTypeByDetailClass(String scrapDetailClass) {
        return baseMapper.selectSolidTypeByDetailClass(scrapDetailClass);
    }
}
