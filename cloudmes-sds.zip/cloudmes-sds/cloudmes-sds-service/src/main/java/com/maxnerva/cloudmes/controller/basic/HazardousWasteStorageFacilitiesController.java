package com.maxnerva.cloudmes.controller.basic;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.service.basic.ISdsHazardousWasteStorageFacilitiesService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName HazardousWasteStorageFacilitiesController
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/15
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "危废贮存设施管理")
@Slf4j
@RestController
@RequestMapping("/hazardousWasteStorageFacilities")
public class HazardousWasteStorageFacilitiesController {

    @Resource
    private ISdsHazardousWasteStorageFacilitiesService sdsHazardousWasteStorageFacilitiesService;

    @ApiOperation("查询设施名称列表")
    @GetMapping("/facilitiesNameList")
    public R<List<String>> selectFacilitiesNameList(){
        return R.ok(sdsHazardousWasteStorageFacilitiesService.selectFacilitiesNameList());
    }
}
