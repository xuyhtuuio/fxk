package com.maxnerva.cloudmes.service.waste.impl;

import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.mapper.waste.SdsHazardousWasteDocInfoLogMapper;
import com.maxnerva.cloudmes.models.dto.waste.HazardousWasteDocInfoLogDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteDocInfoLog;
import com.maxnerva.cloudmes.models.vo.waste.HazardousWasteDocInfoLogQueryVO;
import com.maxnerva.cloudmes.service.waste.ISdsHazardousWasteDocInfoLogService;
import com.maxnerva.cloudmes.system.utils.DictLangUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 危废单据日志履历 服务实现类
 * </p>
 *
 * @author likun
 * @since 2025-05-14
 */
@Slf4j
@Service
public class SdsHazardousWasteDocInfoLogServiceImpl extends ServiceImpl<SdsHazardousWasteDocInfoLogMapper, SdsHazardousWasteDocInfoLog> implements ISdsHazardousWasteDocInfoLogService {

    @Resource
    private DictLangUtils dictLangUtils;

    @Override
    public PageDataDTO<HazardousWasteDocInfoLogDTO> selectDocInfoPage(HazardousWasteDocInfoLogQueryVO queryVO) {
        if (queryVO.getPageIndex() != null && queryVO.getPageSize() != null
                && queryVO.getPageIndex() != 0 && queryVO.getPageSize() != 0) {
            Page page = PageHelper.startPage(queryVO.getPageIndex(), queryVO.getPageSize());
            List<HazardousWasteDocInfoLogDTO> docInfoLogDTOList = getDocInfoLogDTOList(queryVO);
            return new PageDataDTO<>(page.getTotal(), docInfoLogDTOList);
        } else {
            List<HazardousWasteDocInfoLogDTO> docInfoLogDTOList = getDocInfoLogDTOList(queryVO);
            return new PageDataDTO<>((long) docInfoLogDTOList.size(), docInfoLogDTOList);
        }
    }

    private List<HazardousWasteDocInfoLogDTO> getDocInfoLogDTOList(HazardousWasteDocInfoLogQueryVO queryVO) {
        List<HazardousWasteDocInfoLogDTO> docInfoLogDTOList = baseMapper.selectDocInfoLogList(queryVO);
        List<String> types = CollUtil.newArrayList();
        types.add("SDS_HAZARDOUS_WASTE_ENTRY_TYPE");
        types.add("SDS_WASTE_DOC_INFO_STATUS");
        Map<String, Map<String, String>> data = dictLangUtils.getByTypes(types);
        Map<String, String> entryTypeMap = data.get("SDS_HAZARDOUS_WASTE_ENTRY_TYPE");
        Map<String, String> docStatusMap = data.get("SDS_WASTE_DOC_INFO_STATUS");
        docInfoLogDTOList.forEach(docInfoLogDTO -> {
            docInfoLogDTO.setDocTypeName(entryTypeMap.get(docInfoLogDTO.getDocType()));
            docInfoLogDTO.setDocStatusName(docStatusMap.get(docInfoLogDTO.getDocStatus()));
        });
        return docInfoLogDTOList;
    }
}
