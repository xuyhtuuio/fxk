package com.maxnerva.cloudmes.models.dto.waste;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName WasteDocPrintDataDTO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/14
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("产废条码打印数据dto")
@Data
public class WasteDocPrintDataDTO {

    @ApiModelProperty("单据号")
    private String docNo;

    @ApiModelProperty("费用代码")
    private String costCode;

    @ApiModelProperty("部门名称")
    private String depName;

    @ApiModelProperty("危废料号")
    private String hazardousWasteNo;

    @ApiModelProperty("废物俗称")
    private String hazardousWasteName;
}
