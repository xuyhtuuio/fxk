package com.maxnerva.cloudmes.mapper.plan;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.dto.plan.PlanInfoDTO;
import com.maxnerva.cloudmes.models.entity.plan.SdsHazardousWastePlanInfo;
import com.maxnerva.cloudmes.models.vo.plan.PlanInfoQueryVO;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.util.List;

/**
 * <p>
 * 年度计划表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2025-05-08
 */
public interface SdsHazardousWastePlanInfoMapper extends BaseMapper<SdsHazardousWastePlanInfo> {

    List<PlanInfoDTO> selectPlanInfoList(PlanInfoQueryVO queryVO);

    void addUsedWeight(@Param("id") Integer id,
                       @Param("netWeight") BigDecimal netWeight,
                       @Param("lastEditor") String lastEditor);

    void subtractUsedWeight(@Param("orgCode") String orgCode,
                            @Param("costCode") String costCode,
                            @Param("planYear") String planYear,
                            @Param("hazardousWasteNo") String hazardousWasteNo,
                            @Param("netWeight") BigDecimal netWeight,
                            @Param("lastEditor") String lastEditor);

    void addPlanWeight(@Param("docNo") String docNo,
                       @Param("planAddWeight") BigDecimal planAddWeight,
                       @Param("lastEditor") String lastEditor);
}
