package com.maxnerva.cloudmes.models.dto.waste;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName WasteFileDTO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/30
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("上传文件dto")
@Data
public class WasteFileDTO {

    @ApiModelProperty("文件名称")
    private String fileName;

    @ApiModelProperty("文件地址")
    private String fileUrl;

    @ApiModelProperty("文件id")
    private Integer fileId;

}
