package com.maxnerva.cloudmes.service.scrap.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.BooleanUtil;
import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.excel.handler.AddNoHandler;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelInventoryPlanDetailErrLogMapper;
import com.maxnerva.cloudmes.models.dto.excel.scrap.SteelInventoryPlanDetailErrLogExportDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelInventoryPlanDetailErrLogDTO;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelInventoryPlanDetailErrLog;
import com.maxnerva.cloudmes.models.vo.scrap.SteelInventoryPlanDetailErrLogQueryVO;
import com.maxnerva.cloudmes.service.scrap.ISdsSteelInventoryPlanDetailErrLogService;
import com.maxnerva.cloudmes.system.utils.DictLangUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;

import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class SdsSteelInventoryPlanDetailErrLogService extends ServiceImpl<SdsSteelInventoryPlanDetailErrLogMapper, SdsSteelInventoryPlanDetailErrLog> implements ISdsSteelInventoryPlanDetailErrLogService {

    @Autowired
    DictLangUtils dictLangUtils;


    public PageDataDTO<SteelInventoryPlanDetailErrLogDTO> selectPageList(SteelInventoryPlanDetailErrLogQueryVO vo, Boolean isPage) {
        Page page = new Page();
        if (BooleanUtil.isTrue(isPage)){
            page = PageHelper.startPage(vo.getPageIndex(), vo.getPageSize());
        }
        List<SdsSteelInventoryPlanDetailErrLog> steelInventoryPlanDetailErrLogList = baseMapper.selectList(Wrappers.<SdsSteelInventoryPlanDetailErrLog>lambdaQuery()
                .eq(SdsSteelInventoryPlanDetailErrLog::getInventoryPlanNo, vo.getInventoryPlanNo())
        );
        List<SteelInventoryPlanDetailErrLogDTO> result = ListUtil.toList();
        Map<String, Map<String, String>> dictMap = dictLangUtils.getByTypes(ListUtil.toList("SDS_SCRAP_SOLID"));
        steelInventoryPlanDetailErrLogList.forEach(item -> {
            SteelInventoryPlanDetailErrLogDTO dto = new SteelInventoryPlanDetailErrLogDTO();
            BeanUtil.copyProperties(item, dto);
            dto.setScrapDetailClassName(dictMap.get("SDS_SCRAP_SOLID").get(dto.getScrapDetailClass()));
            result.add(dto);
        });
        return new PageDataDTO(page.getTotal(), result);
    }

    @Override
    public void exportDetail(SteelInventoryPlanDetailErrLogQueryVO vo, HttpServletResponse response) {
        PageDataDTO<SteelInventoryPlanDetailErrLogDTO> pageDataDTO = selectPageList(vo, Boolean.FALSE);
        List<SteelInventoryPlanDetailErrLogExportDTO> exportDTOList = ListUtil.toList();
        pageDataDTO.getList().forEach(item -> {
            SteelInventoryPlanDetailErrLogExportDTO dto = new SteelInventoryPlanDetailErrLogExportDTO();
            BeanUtil.copyProperties(item, dto);
            exportDTOList.add(dto);
        });

        String fileName = "固废盘点记录" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), SteelInventoryPlanDetailErrLogExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getLocalCode()));
        }
    }
}
