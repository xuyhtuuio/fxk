package com.maxnerva.cloudmes.models.vo.waste;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @ClassName WasteInStoreConfirmVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/16
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel(value = "入库手动确认VO")
@Data
public class WasteInStoreConfirmVO {

    @ApiModelProperty(value = "Y 确认，N 拒收", required = true)
    private String handleConfirm;

    @ApiModelProperty(value = "单号", required = true)
    private String docNo;

    @ApiModelProperty(value = "毛重", required = true)
    private BigDecimal grossWeight;

    @ApiModelProperty(value = "拒收/接收人", required = true)
    private String operateEmpNo;

    @ApiModelProperty(value = "拒收/接收备注", required = true)
    private String operateRemarkType;
}
