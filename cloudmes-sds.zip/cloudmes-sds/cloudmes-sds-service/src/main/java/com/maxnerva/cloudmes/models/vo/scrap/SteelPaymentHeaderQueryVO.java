package com.maxnerva.cloudmes.models.vo.scrap;

import com.maxnerva.cloudmes.models.vo.PageQueryVO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class SteelPaymentHeaderQueryVO extends PageQueryVO {

    @ApiModelProperty(value = "缴款单号")
    private String docNo;

    @ApiModelProperty(value = "厂商代码")
    private String mfgCode;

}
