package com.maxnerva.cloudmes.service.scrap.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.mapper.basic.SdsSteelBucketInfoMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelInventoryPlanDetailErrLogMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelInventoryPlanDetailMapper;
import com.maxnerva.cloudmes.models.dto.scrap.SteelInventoryPlanDetailDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelInventoryPlanDetailSubmitDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsSteelBucketInfo;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelInventoryPlanDetail;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelInventoryPlanDetailErrLog;
import com.maxnerva.cloudmes.models.vo.scrap.SteelInventoryPlanDetailSubmitVO;
import com.maxnerva.cloudmes.service.scrap.ISdsSteelInventoryPlanDetailService;
import com.maxnerva.cloudmes.system.utils.DictLangUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Map;

@Slf4j
@Service
public class SdsSteelInventoryPlanDetailService extends ServiceImpl<SdsSteelInventoryPlanDetailMapper, SdsSteelInventoryPlanDetail> implements ISdsSteelInventoryPlanDetailService {

    @Autowired
    DictLangUtils dictLangUtils;

    @Autowired
    SdsSteelBucketInfoMapper steelBucketInfoMapper;

    @Autowired
    SdsSteelInventoryPlanDetailErrLogMapper steelInventoryPlanDetailErrLogMapper;

    @Override
    public SteelInventoryPlanDetailDTO selectOne(String inventoryPlanNo) {
        SdsSteelInventoryPlanDetail steelInventoryPlanDetail = baseMapper.selectOne(Wrappers.<SdsSteelInventoryPlanDetail>lambdaQuery()
                .eq(SdsSteelInventoryPlanDetail::getInventoryPlanNo, inventoryPlanNo)
                .last("limit 1")
        );
        Map<String, Map<String, String>> dictMap = dictLangUtils.getByTypes(ListUtil.toList("SDS_SCRAP_SOLID"));
        SteelInventoryPlanDetailDTO dto = new SteelInventoryPlanDetailDTO();
        BeanUtil.copyProperties(steelInventoryPlanDetail, dto);
        dto.setScrapDetailClassName(dictMap.get("SDS_SCRAP_SOLID").get(dto.getScrapDetailClass()));
        return dto;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public SteelInventoryPlanDetailSubmitDTO weightSubmit(SteelInventoryPlanDetailSubmitVO vo) {
        SdsSteelBucketInfo steelBucketInfo = steelBucketInfoMapper.selectOne(Wrappers.<SdsSteelBucketInfo>lambdaQuery()
                .eq(SdsSteelBucketInfo::getBucketNo, vo.getBucketNo())
                .last("limit 1")
        );
        if (ObjectUtil.isNull(steelBucketInfo)){
            throw new CloudmesException("未维护托盘信息，请维护");
        }

        SdsSteelInventoryPlanDetail steelInventoryPlanDetail = baseMapper.selectById(vo.getId());

        SteelInventoryPlanDetailSubmitDTO dto = new SteelInventoryPlanDetailSubmitDTO();
        BigDecimal netWeight = vo.getGrossWeight().subtract(steelBucketInfo.getBucketWeight());
        if (netWeight.compareTo(BigDecimal.ZERO) <= 0){
            throw new CloudmesException("净重不能小于0");
        }
        baseMapper.increaseInventoryWeight(vo.getId(), netWeight);

        SdsSteelInventoryPlanDetailErrLog steelInventoryPlanDetailErrLog = new SdsSteelInventoryPlanDetailErrLog();
        steelInventoryPlanDetailErrLog.setBucketNo(vo.getBucketNo());
        steelInventoryPlanDetailErrLog.setBucketWeight(steelBucketInfo.getBucketWeight());
        steelInventoryPlanDetailErrLog.setGrossWeight(vo.getGrossWeight());
        steelInventoryPlanDetailErrLog.setInventoryPlanNo(steelInventoryPlanDetail.getInventoryPlanNo());
        steelInventoryPlanDetailErrLog.setNetWeight(netWeight);
        steelInventoryPlanDetailErrLog.setScrapDetailClass(steelInventoryPlanDetail.getScrapDetailClass());
        steelInventoryPlanDetailErrLog.setTotalNetWeight(steelInventoryPlanDetail.getTotalNetWeight());
        steelInventoryPlanDetailErrLogMapper.insert(steelInventoryPlanDetailErrLog);

        dto.setBucketNo(vo.getBucketNo());
        dto.setBucketWeight(steelBucketInfo.getBucketWeight());
        dto.setGrossWeight(vo.getGrossWeight());
        dto.setNetWeight(netWeight);
        return dto;
    }
}
