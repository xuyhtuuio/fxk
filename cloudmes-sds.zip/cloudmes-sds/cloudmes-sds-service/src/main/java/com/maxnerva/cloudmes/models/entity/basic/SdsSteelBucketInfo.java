package com.maxnerva.cloudmes.models.entity.basic;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

/**
 * <p>
 * 托盘信息表
 * </p>
 *
 * @author likun
 * @since 2024-10-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="SdsSteelBucketInfo对象", description="托盘信息表")
public class SdsSteelBucketInfo extends BaseEntity<SdsSteelBucketInfo> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "组织")
    private String orgCode;

    @ApiModelProperty(value = "托盘编码")
    private String bucketNo;

    @ApiModelProperty(value = "托盘重量")
    private BigDecimal bucketWeight;

    @ApiModelProperty(value = "单位")
    private String uom;

    @ApiModelProperty(value = "托盘类别")
    private String bucketType;

    @ApiModelProperty(value = "承重下限")
    private BigDecimal weightLow;

    @ApiModelProperty(value = "承重上限")
    private BigDecimal weightUp;

    @ApiModelProperty(value = "是否启用")
    private String isEnable;

    @ApiModelProperty(value = "长")
    private BigDecimal length;

    @ApiModelProperty(value = "宽")
    private BigDecimal width;

    @ApiModelProperty(value = "高")
    private BigDecimal height;

    @ApiModelProperty(value = "容积")
    private BigDecimal volume;

    @ApiModelProperty(value = "报废大类")
    private String scrapClass;

    @ApiModelProperty(value = "报废小类")
    private String scrapDetailClass;

    @ApiModelProperty(value = "是否进废料暂存区")
    private Boolean isScrapArea;

    @ApiModelProperty(value = "报废类型")
    private String scrapType;

    @ApiModelProperty(value = "厂部代码")
    private String departmentCode;
}
