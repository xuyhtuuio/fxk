package com.maxnerva.cloudmes.models.dto.excel.scrap;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.excel.converter.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("固废称重记录日志DTO")
@Data
public class SteelScrapWeightInfoLogExportDTO {
    @ApiModelProperty("工厂组织")
    @ExcelProperty(value = "组织")
    private String orgCode;

    @ApiModelProperty("托盘编码")
    @ExcelProperty(value = "托盘编码")
    private String bucketNo;

    @ApiModelProperty("托盘重量")
    @ExcelProperty(value = "托盘重量")
    private BigDecimal bucketWeight;

    @ApiModelProperty("单位")
    @ExcelProperty(value = "单位")
    private String uom;

    @ApiModelProperty("毛重")
    @ExcelProperty(value = "毛重")
    private BigDecimal grossWeight;

    @ApiModelProperty("净重")
    @ExcelProperty(value = "净重")
    private BigDecimal netWeight;

    @ApiModelProperty("称重时间")
    @ExcelProperty(value = "称重时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime weighDt;

    @ApiModelProperty("称重员工")
    @ExcelProperty(value = "称重员工")
    private String weighEmpNo;

    @ApiModelProperty(value = "是否称重")
    @ExcelProperty(value = "是否称重")
    private String weighFlagName;

    @ApiModelProperty("是否接收")
    @ExcelProperty(value = "是否接收")
    private String acceptFlagName;

    @ApiModelProperty("接收时间")
    @ExcelProperty(value = "接收时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime acceptDt;

    @ApiModelProperty("接收人")
    @ExcelProperty(value = "接收人")
    private String acceptEmpNo;

    @ApiModelProperty("报废小类")
    @ExcelProperty(value = "报废小类")
    private String scrapDetailClassName;

    @ApiModelProperty("报废厂毛重")
    @ExcelProperty(value = "废料厂毛重")
    private BigDecimal rubbishGrossWeight;

    @ApiModelProperty("报废厂净重")
    @ExcelProperty(value = "废料厂净重")
    private BigDecimal rubbishNetWeight;

    @ApiModelProperty("报废厂称重时间")
    @ExcelProperty(value = "废料厂称重时间", converter = LocalDateTimeStringConverter.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime rubbishWeighDt;

    @ExcelProperty(value = "废料厂称重人")
    private String rubbishWeighEmpNo;

    @ApiModelProperty("废料厂是否称重")
    @ExcelProperty(value = "废料厂是否称重")
    private String rubbishWeighFlagName;

    @ApiModelProperty("操作类型")
    @ExcelProperty(value = "操作类型")
    private String operateMessage;

    @ApiModelProperty(value = "创建人")
    @ExcelProperty(value = "创建人")
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "创建时间")
    @ExcelProperty(value = "创建时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "修改人")
    @ExcelProperty(value = "修改人")
    private String lastEditor;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "修改时间")
    @ExcelProperty(value = "修改时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime lastEditedDt;
}
