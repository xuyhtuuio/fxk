package com.maxnerva.cloudmes.models.dto.scrap;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class SdsSteelScrapShipHeaderDTO {

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("申报单号")
    private String declareNumber;

    @ApiModelProperty("厂商")
    private String manFacturer;

    @ApiModelProperty("废料名称")
    private String scrapPartName;

    @ApiModelProperty("关务代码")
    private String customsCode;

    @ApiModelProperty("废料料号")
    private String scrapPartNo;

    @ApiModelProperty("废料类别")
    private String scrapType;

    @ApiModelProperty("区域代码")
    private String areaCode;

    @ApiModelProperty("车牌")
    private String licenseCarNumber;

    @ApiModelProperty("司机")
    private String driver;

    @ApiModelProperty("申请人")
    private String applyor;

    @ApiModelProperty("申请时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime applyDt;

    @ApiModelProperty("出货法人")
    private String shippingCorporation;

    @ApiModelProperty("归属单位")
    private String costCode;

    @ApiModelProperty("计量单位")
    private String uom;

    @ApiModelProperty("备案号")
    private String filedNumber;

    @ApiModelProperty("关锁号")
    private String lockNumber;

    @ApiModelProperty("车况-工具箱")
    private String carToolBox;

    @ApiModelProperty("车况-油箱")
    private String carFuelTank;

    @ApiModelProperty("车况-钢圈")
    private String carSteelRing;

    @ApiModelProperty("车况-水箱")
    private String carWaterTank;

    @ApiModelProperty("车况-备胎")
    private String carSpareTire;

    @ApiModelProperty("空车重量")
    private String carWeight;

    @ApiModelProperty("进厂时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime entryTime;

    @ApiModelProperty("空车称重人")
    private String carWeightEmp;

    @ApiModelProperty("空车称重时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime carWeightDt;

    @ApiModelProperty("單位")
    private String weightUom;

    @ApiModelProperty("整车重量")
    private String fullCarWeight;

    @ApiModelProperty("出厂时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime leaveTime;

    @ApiModelProperty("整車称重人")
    private String fullCarWeightEmp;

    @ApiModelProperty("整車称重时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime fullCarWeightDt;

    @ApiModelProperty("废料净重")
    private String scrapNetWeight;

    @ApiModelProperty("进出废料区状态（0未进，1已进，2已出）")
    private String scrapAreaStatus;

    @ApiModelProperty("进废料区时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime inScrapAreaDt;

    @ApiModelProperty("进废料区放行人")
    private String inScrapAreaEmpNo;

    @ApiModelProperty(value = "出废料区时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime outScrapAreaDt;

    @ApiModelProperty("出废料区放行人")
    private String outScrapAreaEmpNo;

}
