package com.maxnerva.cloudmes.service.waste;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.models.dto.waste.WasteMoveOutConfigDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousMoveOutConfig;

import java.util.List;

/**
 * <p>
 * 危废移出单位配置档 服务类
 * </p>
 *
 * @author likun
 * @since 2025-05-27
 */
public interface ISdsHazardousMoveOutConfigService extends IService<SdsHazardousMoveOutConfig> {

    List<WasteMoveOutConfigDTO> selectMoveOutConfigList();

}
