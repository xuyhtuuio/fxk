package com.maxnerva.cloudmes.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

/**
 * @author H7109018
 */
@Configuration
public class RestTemplateConfig {

    /**
     * 连接池的最大连接数默认为0
     */
    private final int maxTotalConnect = 1000;

    /**
     * 单个主机的最大连接数
     */
    private final int maxConnectPerRoute = 200;

    /**
     * 连接超时默认3s
     */
    private final int connectTimeout = 3_000;

    /**
     * 读取超时默认30s
     */
    private final int readTimeout = 180_000;

    /**
     * 创建HTTP客户端工厂
     *
     * @return
     */
    @Bean
    public RestTemplate restTemplate(ClientHttpRequestFactory factory) {
        return new RestTemplate(factory);
    }

    @Bean
    public ClientHttpRequestFactory simpleClientHttpRequestFactory() {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setReadTimeout(readTimeout);
        factory.setConnectTimeout(connectTimeout);
        return factory;
    }
}
