package com.maxnerva.cloudmes.enums;

/**
 * @ClassName CodeRuleEnum
 * @Description 编码规则枚举
 * @Author Likun
 * @Date 2024/11/5
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum CodeRuleEnum {

    /**
     *  编码规则
     */
    SDS_BUCKET_NO("SDS_BUCKET_NO","托盘编码"),
    SDS_SCRAP_INVENTORY_NO("SDS_SCRAP_INVENTORY_NO", "盘点单号"),
    SDS_SCRAP_PAYMENT_NO("SDS_SCRAP_PAYMENT_NO", "缴款单号"),
    SDS_WASTE_PLAN_DOC_NO("SDS_WASTE_PLAN_DOC_NO", "年度计划单号"),
    SDS_WASTE_PLAN_EXPLAIN_DOC_NO("SDS_WASTE_PLAN_EXPLAIN_DOC_NO", "年度计划说明单号"),
    SDS_WASTE_PRODUCT_DOC_NO("SDS_WASTE_PRODUCT_DOC_NO", "产废单号"),
    SDS_WASTE_SHIP_DOC_NO("SDS_WASTE_SHIP_DOC_NO", "出库单号"),
    SDS_WASTE_TRANSFER_DOC_NO("SDS_WASTE_TRANSFER_DOC_NO", "转移单号");

    private String dictCode;

    private String dictName;

    CodeRuleEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }
}
