package com.maxnerva.cloudmes.mapper.scrap;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelArchiveInventoryInfo;

public interface SdsSteelArchiveInventoryInfoMapper extends BaseMapper<SdsSteelArchiveInventoryInfo> {
}
