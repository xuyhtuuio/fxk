package com.maxnerva.cloudmes.models.entity.scrap;

import com.baomidou.mybatisplus.annotation.TableName;
import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName SdsHikPictureLog
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/1/4 上午 10:42
 * @Version 1.0
 **/

@TableName("sds_hik_picture_log")
@ApiModel(value = "SdsHikPictureLog对象", description = "")
@Data
public class SdsHikPictureLog extends BaseEntity<SdsHikPictureLog> {
    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("圖片路徑")
    private String picUrl;

    @ApiModelProperty("圖片名字")
    private String picName;

    @ApiModelProperty("文件ID")
    private Integer picId;

    @ApiModelProperty("当前位置code")
    private String areaCode;

    @ApiModelProperty("当前位置")
    private String areaName;

    @ApiModelProperty("当前位置类型")
    private String areaType;

    @ApiModelProperty("当前位置类型名称")
    private String areaTypeName;

    @ApiModelProperty("当前拍照单号")
    private String declareNumber;

}
