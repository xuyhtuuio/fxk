package com.maxnerva.cloudmes.enums;

public enum HikAreaCodeEnum {

    /**
     *  需拍照地区与地区编码对应
     */

    LOADING_WASTE_PACKAGING_MATERIALS_AREA("LOADING_WASTE_PACKAGING_MATERIALS_AREA","废料包材区装车"),
    SCRAP_FACTORY_SOUTH_ONE("SCRAP_FACTORY_SOUTH_ONE","废料厂南1"),
    SCRAP_FACTORY_SOUTH_THREE("SCRAP_FACTORY_SOUTH_THREE","废料厂南3"),

    SCRAP_FACTORY_NORTH_ONE("SCRAP_FACTORY_NORTH_ONE","废料厂北1"),
    SCRAP_FACTORY_NORTH_TWO("SCRAP_FACTORY_NORTH_TWO","废料厂北2"),
    SCRAP_FACTORY_NORTH_THREE("SCRAP_FACTORY_NORTH_THREE","废料厂北3"),
    SCRAP_FACTORY_NORTH_FOUR("SCRAP_FACTORY_NORTH_FOUR","废料厂北4");

    private String dictCode;

    private String dictName;

    HikAreaCodeEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

}
