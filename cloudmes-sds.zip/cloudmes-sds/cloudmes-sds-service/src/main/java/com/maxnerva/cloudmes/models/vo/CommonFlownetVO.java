package com.maxnerva.cloudmes.models.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.formula.functions.T;

/**
 * @ClassName CommonFlownetVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/7/1
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("通用flownet流程vo")
@Data
public class CommonFlownetVO {

    @ApiModelProperty("流程ID")
    private String businessProcessID;

    @ApiModelProperty("申請人工号")
    private String businessRequestor;

    @ApiModelProperty("申請人姓名")
    private String businessRequestorName;

    @ApiModelProperty("客制化单号")
    private String businessRequestNo;

    private String flownetFormID;

    private String flowableInstanceID;

    private String flownetFormStatus;

    private Object businessFormJson;
}
