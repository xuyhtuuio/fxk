package com.maxnerva.cloudmes.models.vo.scrap;

import com.maxnerva.cloudmes.models.vo.PageQueryVO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

@Data
public class SteelInventoryPlanHeaderQueryVO extends PageQueryVO {

    @ApiModelProperty("单号")
    private String inventoryPlanNo;

    @ApiModelProperty("状态")
    private String inventoryStatus;

    @ApiModelProperty("创建人")
    private String creator;

    @ApiModelProperty("报废小类")
    private String scrapDetailClass;

    @ApiModelProperty(value = "开始时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime startDateTime;

    @ApiModelProperty(value = "开始时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime endDateTime;
}
