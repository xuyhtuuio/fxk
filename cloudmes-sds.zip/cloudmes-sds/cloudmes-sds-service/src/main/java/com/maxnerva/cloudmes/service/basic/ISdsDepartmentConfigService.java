package com.maxnerva.cloudmes.service.basic;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.models.dto.basic.DepartmentConfigDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsDepartmentConfig;

import java.util.List;

/**
 * <p>
 * 厂部配置 服务类
 * </p>
 *
 * @author likun
 * @since 2024-12-11
 */
public interface ISdsDepartmentConfigService extends IService<SdsDepartmentConfig> {

    List<DepartmentConfigDTO> selectConfigList(String orgCode);

    List<DepartmentConfigDTO> selectConfigListNoBu();
}
