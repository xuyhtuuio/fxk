package com.maxnerva.cloudmes.mapstruct;

import java.util.List;

/**
 * @author likun
 * @version 1.0
 * @since jdk 8
 */
public interface BaseTwoMapper<Source, Target>{

    Target sourceToTarget(Source source);

    List<Target> sourceToTarget(List<Source> source);

    Source targetToSource(Target target);

    List<Source> targetToSource(List<Target> target);
}
