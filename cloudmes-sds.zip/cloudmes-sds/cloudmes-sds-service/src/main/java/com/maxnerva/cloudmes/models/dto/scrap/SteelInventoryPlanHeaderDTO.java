package com.maxnerva.cloudmes.models.dto.scrap;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class SteelInventoryPlanHeaderDTO {
    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("单号")
    private String inventoryPlanNo;

    @ApiModelProperty("描述")
    private String description;

    @ApiModelProperty("状态")
    private String inventoryStatus;

    @ApiModelProperty("状态名")
    private String inventoryStatusName;

    @ApiModelProperty("盘点执行人")
    private String inventoryExecutorCode;

    @ApiModelProperty("报废小类")
    private String scrapDetailClass;

    @ApiModelProperty("报废小类名")
    private String scrapDetailClassName;

    @ApiModelProperty(value = "创建人")
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "创建时间")
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "修改人")
    private String lastEditor;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "修改时间")
    private LocalDateTime lastEditedDt;
}
