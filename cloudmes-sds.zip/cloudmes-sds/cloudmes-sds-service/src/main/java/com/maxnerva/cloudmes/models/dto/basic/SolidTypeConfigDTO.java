package com.maxnerva.cloudmes.models.dto.basic;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName SolidTypeConfigDTO
 * @Description TODO
 * @Author Likun
 * @Date 2024/12/11
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("固废分类配置dto")
@Data
public class SolidTypeConfigDTO {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "报废小类")
    private String scrapDetailClass;

    @ApiModelProperty(value = "报废小类描述")
    private String scrapDetailClassDesc;

    @ApiModelProperty(value = "报废类型")
    private String scrapType;

    @ApiModelProperty(value = "是否贵重")
    private Boolean isValuable;

    @ApiModelProperty(value = "是否进废料暂存区")
    private Boolean isScrapArea;
}
