package com.maxnerva.cloudmes.service.waste;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.models.dto.waste.HazardousWasteDocInfoLogDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteDocInfoLog;
import com.maxnerva.cloudmes.models.vo.waste.HazardousWasteDocInfoLogQueryVO;

/**
 * <p>
 * 危废单据日志履历 服务类
 * </p>
 *
 * @author likun
 * @since 2025-05-14
 */
public interface ISdsHazardousWasteDocInfoLogService extends IService<SdsHazardousWasteDocInfoLog> {

    PageDataDTO<HazardousWasteDocInfoLogDTO> selectDocInfoPage(HazardousWasteDocInfoLogQueryVO queryVO);
}
