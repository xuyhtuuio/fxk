package com.maxnerva.cloudmes.models.dto.basic;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName DepartmentConfigDTO
 * @Description TODO
 * @Author Likun
 * @Date 2024/12/11
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("厂部配置dto")
@Data
public class DepartmentConfigDTO {

    @ApiModelProperty(value = "ID")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "厂部编码")
    private String departmentCode;

    @ApiModelProperty(value = "厂部名称")
    private String departmentName;
}
