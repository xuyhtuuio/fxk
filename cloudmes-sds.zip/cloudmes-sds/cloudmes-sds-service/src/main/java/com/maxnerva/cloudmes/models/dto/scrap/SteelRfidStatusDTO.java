package com.maxnerva.cloudmes.models.dto.scrap;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class SteelRfidStatusDTO {

    @ApiModelProperty(value = "位置")
    String positionName;

    @ApiModelProperty(value = "HOST")
    String host;

    @ApiModelProperty(value = "端口")
    String port;

    @ApiModelProperty(value = "连接状态 N, Y")
    String connectStatus = "N";

    @ApiModelProperty(value = "最近连接时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime lastConnectDateTime;

    @ApiModelProperty(value = "最近离线时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime lastDisConnectDateTime;
}
