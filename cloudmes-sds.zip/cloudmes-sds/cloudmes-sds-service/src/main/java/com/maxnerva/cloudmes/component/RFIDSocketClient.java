package com.maxnerva.cloudmes.component;


import cn.hutool.core.util.StrUtil;
import com.gg.reader.api.dal.GClient;
import com.gg.reader.api.dal.HandlerTagEpcLog;
import com.gg.reader.api.dal.HandlerTagEpcOver;
import com.gg.reader.api.dal.HandlerTcpDisconnected;
import com.gg.reader.api.protocol.gx.*;
import com.maxnerva.cloudmes.common.models.dto.DatasourceKeyDTO;
import com.maxnerva.cloudmes.common.utils.DSThreadLocalUtil;
import com.maxnerva.cloudmes.config.RFIDConfig;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.util.*;

@Data
@Slf4j
public class RFIDSocketClient {

    private String host = "10.67.184.71";
    private String port = "8160";
    private String positionName;
    private String lightStatus = "";

    private LocalDateTime lastConnectDateTime;

    private RFIDConfig rfidConfig;
    private Set<String> rfidCardSet = new HashSet();
    public RFIDSocketClient(String host, String port, String positionName,RFIDConfig rfidConfig){
        this.host = host;
        this.port = port;
        this.positionName = positionName;
        this.rfidConfig = rfidConfig;
    }
    private Boolean isConnected = false;

    private final GClient gClient = new GClient();

    public Boolean openClient() {
        if (gClient.openTcp(host + ":" + port, 5000)) {
            subscribeHandler(gClient);
            gClient.setSendHeartBeat(true);
            System.err.println("开始测试");
//            MsgAppGetReaderInfo getReaderInfo = new MsgAppGetReaderInfo();
//            gClient.sendSynMsg(getReaderInfo);
//            if (getReaderInfo.getRtCode() == 0) {
//                System.err.println("设备序列号：" + getReaderInfo.getReaderSerialNumber());
//                System.out.println(getReaderInfo.getTuYaShortUrl() + "123");
//            } else {
//                System.err.println("查询设备信息失败");
//            }
//            MsgBaseInventoryEpc msg = new MsgBaseInventoryEpc();
//            msg.setAntennaEnable(1L);
//            msg.setInventoryMode(1);
//            gClient.sendSynMsg(msg);
//            System.err.println("启动6c读卡=" + (msg.getRtCode() == 0 ? "成功" : "失败"));
            isConnected = true;
            lastConnectDateTime = LocalDateTime.now();
            rfidConfig.getRfidCardMap().put(StrUtil.concat(true, host, port), rfidCardSet);
            return Boolean.TRUE;
        } else {
            log.error("{}:{} 连接失败 =====", host, port);
            isConnected = false;
            return Boolean.FALSE;
        }
    }

    public void turnLight(String lightStatus) {
        if (lightStatus.equals(this.lightStatus)) {
            return;
        }
        // 1 绿灯   2 黄灯
        MsgAppSetGpo msgAppSetGpo = new MsgAppSetGpo();
        if ("1".equals(lightStatus)) {
            msgAppSetGpo.setGpo1(1);
            msgAppSetGpo.setGpo2(0);
        } else if ("2".equals(lightStatus)){
            msgAppSetGpo.setGpo1(0);
            msgAppSetGpo.setGpo2(1);
        } else if ("3".equals(lightStatus)){
            msgAppSetGpo.setGpo1(0);
            msgAppSetGpo.setGpo2(0);
        }
        gClient.sendSynMsg(msgAppSetGpo);
        if (0x00 == msgAppSetGpo.getRtCode()) {
            log.error("{}: turnLight {}", positionName, lightStatus);
            this.lightStatus = lightStatus;
        } else {
            log.error("{}: {}", positionName, msgAppSetGpo.getRtMsg());
        }
    }

    public void destroy() {
        gClient.close();
        isConnected = Boolean.FALSE;
        rfidConfig.getRfidCardMap().remove(StrUtil.concat(true, host, port));
    }

    private void subscribeHandler(final GClient gclient) {
        gclient.onTagEpcLog = new HandlerTagEpcLog() {
            public void log(String s, LogBaseEpcInfo logBaseEpcInfo) {
                if (logBaseEpcInfo.getResult() == 0) {
                    String epc = logBaseEpcInfo.getEpc();
                    System.out.println("epc   " + epc);
                    rfidCardSet.add(epc);
                } else {
                    System.err.println("false");
                }
            }
        };
        gclient.onTagEpcOver = new HandlerTagEpcOver() {
            public void log(String s, LogBaseEpcOver logBaseEpcOver) {
                System.err.println("==HandlerTagEpcOver==");
            }
        };
        gclient.onDisconnected = new HandlerTcpDisconnected() {
            @Override
            public void log(String s) {
                System.out.println("连接" + s + "已断开");
                gclient.close();//释放当前连接资源
                isConnected = false;
                rfidConfig.getRfidCardMap().get(StrUtil.concat(true, host, port)).clear();
            }
        };
    }
}
