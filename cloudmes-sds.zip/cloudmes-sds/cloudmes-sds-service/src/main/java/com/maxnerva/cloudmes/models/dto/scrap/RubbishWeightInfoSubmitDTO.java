package com.maxnerva.cloudmes.models.dto.scrap;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class RubbishWeightInfoSubmitDTO {
    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("托盘编码")
    private String bucketNo;

    @ApiModelProperty("托盘重量")
    private BigDecimal bucketWeight;

    @ApiModelProperty("毛重")
    private BigDecimal grossWeight;

    @ApiModelProperty("净重")
    private BigDecimal netWeight;

    @ApiModelProperty(value = "废料名称")
    private String scrapDetailClassName;

    @ApiModelProperty(value = "废料类别")
    private String scrapTypeName;

    @ApiModelProperty(value = "厂部代码名")
    private String departmentCodeName;

    @ApiModelProperty(value = "车间净重")
    private BigDecimal workshopNetWeight;

    @ApiModelProperty(value = "是否需要手动确认, Y/N")
    private String handleConfirm;

    @ApiModelProperty(value = "最近一次入库时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime rubbishWeighDt;
}
