package com.maxnerva.cloudmes.service.scrap;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.models.dto.scrap.SteelPaymentSalesSummaryDTO;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelPaymentSalesSummary;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

public interface ISdsSteelPaymentSalesSummaryService extends IService<SdsSteelPaymentSalesSummary> {

    List<SteelPaymentSalesSummaryDTO> selectList(String paymentDocNo);

    void exportDetail(String paymentDocNo, HttpServletResponse response);
}
