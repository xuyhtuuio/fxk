package com.maxnerva.cloudmes.models.dto.excel.waste.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.excel.converter.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @ClassName WasteInventoryDetailExportDTO
 * @Description TODO
 * @Author Likun
 * @Date 2025/6/20
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("危废库存详情导出DTO")
@Data
public class WasteInventoryDetailExportDTO {

    @ApiModelProperty(value = "申请单号")
    @ExcelProperty(value = "申请单号")
    private String docNo;

    @ApiModelProperty(value = "申请人")
    @ExcelProperty(value = "申请人")
    private String creator;

    @ApiModelProperty(value = "申请人费用代码")
    @ExcelProperty(value = "申请人费用代码")
    private String costCode;

    @ApiModelProperty(value = "申请人部门")
    @ExcelProperty(value = "申请人部门")
    private String depName;

    @ApiModelProperty(value = "产生时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "产生时间",converter = LocalDateTimeStringConverter.class)
    private LocalDateTime productionDate;

    @ApiModelProperty(value = "申请数量")
    @ExcelProperty(value = "申请数量")
    private BigDecimal applyQty;

    @ApiModelProperty(value = "产废毛重")
    @ExcelProperty(value = "产废毛重")
    private BigDecimal applyGrossWeight;

    @ApiModelProperty(value = "产废净重")
    @ExcelProperty(value = "产废净重")
    private BigDecimal applyNetWeight;

    @ApiModelProperty(value = "入库毛重")
    @ExcelProperty(value = "入库毛重")
    private BigDecimal instoreGrossWeight;

    @ApiModelProperty(value = "入库净重")
    @ExcelProperty(value = "入库净重")
    private BigDecimal instoreNetWeight;
}
