package com.maxnerva.cloudmes.models.vo.scrap;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @ClassName OutFactoryWeightVO
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/2/26 上午 08:06
 * @Version 1.0
 **/
@Data
public class OutFactoryWeightVO {

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("厂部")
    private String departmentCode;

    @ApiModelProperty("ECUS单号")
    private String declareNumber;

}
