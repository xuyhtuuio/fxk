package com.maxnerva.cloudmes.models.vo.plan;

import com.maxnerva.cloudmes.models.vo.PageQueryVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @ClassName PlanInfoAddLogQueryVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/12
 * @Version 1.0
 * @Since JDK 1.8
 **/
@EqualsAndHashCode(callSuper = true)
@ApiModel("年度计划说明查询vo")
@Data
public class PlanInfoAddLogQueryVO extends PageQueryVO {

    @ApiModelProperty("年度")
    private String planYear;

    @ApiModelProperty("废物俗称")
    private String hazardousWasteName;

    @ApiModelProperty("计划单号")
    private String planDocNo;

    @ApiModelProperty("单据状态")
    private String docStatus;
}
