package com.maxnerva.cloudmes.models.vo.scrap;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.models.vo.PageQueryVO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

@Data
public class RubbishOutStockQueryVO extends PageQueryVO {

    @ApiModelProperty(value = "报废类别")
    private String scrapDetailClass;

    @ApiModelProperty(value = "废料类别")
    private String scrapType;

    @ApiModelProperty(value = "开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime startDateTime;

    @ApiModelProperty(value = "结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime endDateTime;
}
