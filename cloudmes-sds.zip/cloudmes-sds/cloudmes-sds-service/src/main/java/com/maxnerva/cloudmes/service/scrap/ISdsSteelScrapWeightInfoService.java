package com.maxnerva.cloudmes.service.scrap;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelScrapWeightInfoDTO;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapWeightInfo;
import com.maxnerva.cloudmes.models.vo.scrap.SteelScrapWeightAcceptVO;
import com.maxnerva.cloudmes.models.vo.scrap.SteelScrapWeightInfoQueryOneVO;
import com.maxnerva.cloudmes.models.vo.scrap.SteelScrapWeightInfoQueryVO;
import com.maxnerva.cloudmes.models.vo.scrap.SteelScrapWeightUploadImageVO;

import javax.servlet.http.HttpServletResponse;

public interface ISdsSteelScrapWeightInfoService extends IService<SdsSteelScrapWeightInfo> {

    PageDataDTO<SteelScrapWeightInfoDTO> selectPageList(SteelScrapWeightInfoQueryVO vo, Boolean isPage);

    void exportDetail(SteelScrapWeightInfoQueryVO vo, HttpServletResponse response);
}
