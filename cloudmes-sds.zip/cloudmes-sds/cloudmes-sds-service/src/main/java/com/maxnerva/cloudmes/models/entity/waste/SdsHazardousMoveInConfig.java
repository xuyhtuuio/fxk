package com.maxnerva.cloudmes.models.entity.waste;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 危废接受单位配置档
 * </p>
 *
 * @author likun
 * @since 2025-05-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="SdsHazardousMoveInConfig对象", description="危废接受单位配置档")
public class SdsHazardousMoveInConfig extends BaseEntity<SdsHazardousMoveInConfig> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "单位")
    private String dept;

    @ApiModelProperty(value = "地址")
    private String address;

    @ApiModelProperty(value = "联系人")
    private String contact;

    @ApiModelProperty(value = "联系电话")
    private String phone;

    @ApiModelProperty(value = "许可证号")
    private String license;
}
