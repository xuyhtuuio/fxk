package com.maxnerva.cloudmes.excel.handler;

import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.ObjectUtil;
import com.alibaba.excel.metadata.CellData;
import com.alibaba.excel.metadata.Head;
import com.alibaba.excel.write.merge.AbstractMergeStrategy;
import com.alibaba.excel.write.metadata.holder.WriteSheetHolder;
import com.alibaba.excel.write.metadata.holder.WriteTableHolder;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellRangeAddress;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Slf4j
public class MergeHandler extends AbstractMergeStrategy {
    private List<List<Integer>> mergeList = ListUtil.toList();

    private Integer sheetIndex = 0;

    private List<List<List<Integer>>> sheetMergeList = null;

    Sheet nowSheet = null;

    Boolean isMerge = false;

    // 合并单元格，多个单元格只保留一个数据，防止加总时数据翻倍
    private Set<String> set = new HashSet();

    public MergeHandler(List<List<Integer>> mergeList){
        this.mergeList = mergeList;
    }

    public MergeHandler(List<List<List<Integer>>> mergeList, Boolean isSheet){
        this.sheetMergeList = mergeList;
    }

    @Override
    protected void merge(Sheet sheet, Cell cell, Head head, Integer relativeRowIndex) {
        if (ObjectUtil.isNotNull(sheetMergeList)){
            if (!sheet.equals(nowSheet)){
                nowSheet = sheet;
                isMerge = Boolean.FALSE;
                mergeList = sheetMergeList.get(sheetIndex);
                sheetIndex ++;
                set.clear();
            }
        }
        if (BooleanUtil.isFalse(isMerge)){
            mergeList.forEach(merge -> {
                CellRangeAddress cellRangeAddress = new CellRangeAddress(merge.get(0), merge.get(1), merge.get(2), merge.get(3));
                sheet.addMergedRegion(cellRangeAddress);

                if (merge.get(0) == merge.get(1) && merge.get(2) != merge.get(3)){
                    int j = merge.get(2) + 1;
                    for(;j <= merge.get(3); j ++){
                        set.add(merge.get(0).toString() + "-" + j);
                    }
                } else if (merge.get(2) == merge.get(3) && merge.get(0) != merge.get(1)){
                    int i = merge.get(0) + 1;
                    for (; i <= merge.get(1); i ++){
                        set.add(i + "-" + merge.get(2));
                    }
                } else {
                    for (int i = merge.get(0); i < merge.get(1); i ++){
                        int j = merge.get(2);
                        if (i == merge.get(0)){
                            j = merge.get(2) + 1;
                        }
                        for(;j <= merge.get(3); j ++){
                            sheet.getRow(i).getCell(j).setCellValue("");
                            set.add(i + "-" + j);
                        }
                    }
                }


            });
            isMerge = true;
        }
    }

    @Override
    public void afterCellDispose(WriteSheetHolder writeSheetHolder, WriteTableHolder writeTableHolder, List<CellData> cellDataList, Cell cell, Head head, Integer relativeRowIndex, Boolean isHead) {
        super.afterCellDispose(writeSheetHolder, writeTableHolder, cellDataList, cell, head, relativeRowIndex, isHead);
        if (set.contains(cell.getRowIndex() + "-" + cell.getColumnIndex())){
            cell.setCellValue("");
        }
    }
}