package com.maxnerva.cloudmes.models.vo.scrap;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class SyncWmsScrapHandlePalletVO {

    @ApiModelProperty(value = "BU", required = true)
    private String orgCode;

    @ApiModelProperty(value = "栈板编码", required = true)
    private String bucketNo;

    @ApiModelProperty(value = "废料毛重", required = true)
    private BigDecimal grossWeight;

    @ApiModelProperty(value = "报废品处理单号", required = true)
    private String scrapHandleDocNo;

    @ApiModelProperty(value = "WMS报废类别", required = true)
    private String wmsScrapType;

    @ApiModelProperty(value = "称重人", required = true)
    private String weighEmpNo;

    @ApiModelProperty(value = "称重时间", required = true)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime weighDt;

}
