package com.maxnerva.cloudmes.models.entity.scrap;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 固废废料销售汇总
 * </p>
 *
 * @author baomidou
 * @since 2025-01-11
 */
@TableName("sds_steel_payment_sales_summary")
@ApiModel(value = "SdsSteelPaymentSalesSummary对象", description = "固废废料销售汇总")
@Data
public class SdsSteelPaymentSalesSummary extends BaseEntity<SdsSteelPaymentSalesSummary> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("废料品名")
    private String scrapPartName;

    @ApiModelProperty("费用代码")
    private String costCode;

    @ApiModelProperty("入库重量")
    private BigDecimal inStoreNetWeight;

    @ApiModelProperty("入库占比")
    private BigDecimal inStorePercentage;

    @ApiModelProperty("按入库比例分得出货净重")
    private BigDecimal splitShipNetWeight;

    @ApiModelProperty("按入库比例分账金额")
    private BigDecimal splitShipAccount;

    @ApiModelProperty("报废类别")
    private String scrapDetailClass;

    @ApiModelProperty("缴款单号")
    private String paymentDocNo;
}
