package com.maxnerva.cloudmes.models.entity.basic;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 厂部配置
 * </p>
 *
 * @author likun
 * @since 2024-12-11
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="SdsDepartmentConfig对象", description="厂部配置")
public class SdsDepartmentConfig extends BaseEntity<SdsDepartmentConfig> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "ID")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "厂部编码")
    private String departmentCode;

    @ApiModelProperty(value = "厂部名称")
    private String departmentName;

    @ApiModelProperty(value = "费用代码")
    private String costCode;

    @ApiModelProperty(value = "BU名称，用于盘点报表")
    private String buName;
}
