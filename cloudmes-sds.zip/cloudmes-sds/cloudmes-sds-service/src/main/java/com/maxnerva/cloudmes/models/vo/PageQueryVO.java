package com.maxnerva.cloudmes.models.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName QueryVO
 * @Description 通用查询vo
 * @Author Likun
 * @Date 2022/7/21
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("通用分页查询vo")
@Data
public class PageQueryVO {

    @ApiModelProperty("页码")
    private Integer pageIndex;

    @ApiModelProperty("数量")
    private Integer pageSize;

    @ApiModelProperty("工厂组织")
    private String orgCode;

    @ApiModelProperty("工厂编码")
    private String plantCode;
}
