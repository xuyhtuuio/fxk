package com.maxnerva.cloudmes.config;

import cn.hutool.core.util.StrUtil;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import lombok.Data;
import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;
import org.redisson.config.SingleServerConfig;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * redisson配置信息
 * @author likun
 * @version 1.0
 * @Date 2024/05/29
 */
@Data
@Configuration
@ConfigurationProperties("cloudmes.lock")
public class RedissonConfig {

    private String address;

    private String password;

    private int database;

    private int timeout = 3000;
    private int connectionPoolSize = 64;
    private int connectionMinimumIdleSize=10;
    private int pingConnectionInterval = 60000;

    /**
     * 自动装配
     *
     */
    @Bean
    RedissonClient redissonSingle() {
        Config config = new Config();
        if(StrUtil.isEmpty(address)){
            throw new CloudmesException(SdsResultCode.REDISSON_ADDRESS_IS_EMPTY.getCode(),
                    MessageUtils.get(SdsResultCode.REDISSON_ADDRESS_IS_EMPTY.getLocalCode()));
        }
        SingleServerConfig serverConfig = config.useSingleServer()
                .setAddress(address)
                .setTimeout(this.timeout)
                .setDatabase(database)
                .setPingConnectionInterval(pingConnectionInterval)
                .setConnectionPoolSize(this.connectionPoolSize)
                .setConnectionMinimumIdleSize(this.connectionMinimumIdleSize);
        if(!StrUtil.isEmpty(this.password)) {
            serverConfig.setPassword(this.password);
        }
        return Redisson.create(config);
    }
}
