package com.maxnerva.cloudmes.models.vo.basic;

import com.maxnerva.cloudmes.models.vo.CommonRequestVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

/**
 * @ClassName SteelBucketSaveOrUpdateVO
 * @Description TODO
 * @Author Likun
 * @Date 2024/10/28
 * @Version 1.0
 * @Since JDK 1.8
 **/
@EqualsAndHashCode(callSuper = true)
@ApiModel("托盘信息新增/修改vo")
@Data
public class SteelBucketSaveOrUpdateVO extends CommonRequestVO {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "托盘编码")
    private String bucketNo;

    @ApiModelProperty(value = "托盘重量")
    private BigDecimal bucketWeight;

    @ApiModelProperty(value = "托盘类别")
    private String bucketType;

    @ApiModelProperty(value = "承重下限")
    private BigDecimal weightLow;

    @ApiModelProperty(value = "承重上限")
    private BigDecimal weightUp;

    @ApiModelProperty(value = "是否启用")
    private String isEnable;

    @ApiModelProperty(value = "长")
    private BigDecimal length;

    @ApiModelProperty(value = "宽")
    private BigDecimal width;

    @ApiModelProperty(value = "高")
    private BigDecimal height;

    @ApiModelProperty(value = "容积")
    private BigDecimal volume;

    @ApiModelProperty(value = "报废大类")
    private String scrapClass;

    @ApiModelProperty(value = "报废小类")
    private String scrapDetailClass;
}
