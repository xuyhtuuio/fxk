package com.maxnerva.cloudmes.service.waste.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import com.alibaba.excel.EasyExcel;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.excel.handler.AddNoHandler;
import com.maxnerva.cloudmes.mapper.waste.SdsHazardousWasteDocInfoMapper;
import com.maxnerva.cloudmes.models.dto.excel.waste.report.WasteInventoryDetailExportDTO;
import com.maxnerva.cloudmes.models.dto.excel.waste.report.WasteInventoryExportDTO;
import com.maxnerva.cloudmes.models.dto.excel.waste.report.WasteInventoryOverdueWarnExportDTO;
import com.maxnerva.cloudmes.models.dto.waste.report.WasteInventoryDTO;
import com.maxnerva.cloudmes.models.dto.waste.report.WasteInventoryDetailDTO;
import com.maxnerva.cloudmes.models.dto.waste.report.WasteInventoryOverdueWarnDTO;
import com.maxnerva.cloudmes.models.vo.waste.report.WasteInventoryDetailQueryVO;
import com.maxnerva.cloudmes.models.vo.waste.report.WasteInventoryOverdueWarnQueryVO;
import com.maxnerva.cloudmes.models.vo.waste.report.WasteInventoryQueryVO;
import com.maxnerva.cloudmes.service.waste.IWasteReportService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;

/**
 * @ClassName WasteReportServiceImpl
 * @Description TODO
 * @Author Likun
 * @Date 2025/6/20
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Slf4j
@Service
public class WasteReportServiceImpl implements IWasteReportService {

    @Resource
    private SdsHazardousWasteDocInfoMapper sdsHazardousWasteDocInfoMapper;

    @Override
    public PageDataDTO<WasteInventoryDTO> selectWasteInventoryPage(WasteInventoryQueryVO queryVO) {
        if (queryVO.getPageIndex() != null && queryVO.getPageSize() != null
                && queryVO.getPageIndex() != 0 && queryVO.getPageSize() != 0) {
            Page page = PageHelper.startPage(queryVO.getPageIndex(), queryVO.getPageSize());
            List<WasteInventoryDTO> wasteInventoryDTOList = sdsHazardousWasteDocInfoMapper
                    .selectWasteInventoryList(queryVO);
            return new PageDataDTO<>(page.getTotal(), wasteInventoryDTOList);
        } else {
            List<WasteInventoryDTO> wasteInventoryDTOList = sdsHazardousWasteDocInfoMapper
                    .selectWasteInventoryList(queryVO);
            return new PageDataDTO<>((long) wasteInventoryDTOList.size(), wasteInventoryDTOList);
        }
    }

    @Override
    public PageDataDTO<WasteInventoryDetailDTO> selectWasteInventoryDetailPage(WasteInventoryDetailQueryVO queryVO) {
        if (queryVO.getPageIndex() != null && queryVO.getPageSize() != null
                && queryVO.getPageIndex() != 0 && queryVO.getPageSize() != 0) {
            Page page = PageHelper.startPage(queryVO.getPageIndex(), queryVO.getPageSize());
            List<WasteInventoryDetailDTO> wasteInventoryDetailDTOList = sdsHazardousWasteDocInfoMapper
                    .selectWasteInventoryDetailList(queryVO);
            return new PageDataDTO<>(page.getTotal(), wasteInventoryDetailDTOList);
        } else {
            List<WasteInventoryDetailDTO> wasteInventoryDetailDTOList = sdsHazardousWasteDocInfoMapper
                    .selectWasteInventoryDetailList(queryVO);
            return new PageDataDTO<>((long) wasteInventoryDetailDTOList.size(), wasteInventoryDetailDTOList);
        }
    }

    @Override
    public void exportWasteInventory(HttpServletResponse response, WasteInventoryQueryVO queryVO) {
        List<WasteInventoryExportDTO> exportDTOList = CollUtil.newArrayList();
        List<WasteInventoryDTO> wasteInventoryDTOList = sdsHazardousWasteDocInfoMapper
                .selectWasteInventoryList(queryVO);
        wasteInventoryDTOList.forEach(wasteInventoryDTO -> {
            WasteInventoryExportDTO wasteInventoryExportDTO = new WasteInventoryExportDTO();
            BeanUtils.copyProperties(wasteInventoryDTO, wasteInventoryExportDTO);
            exportDTOList.add(wasteInventoryExportDTO);
        });
        String fileName = "危废库存报表" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), WasteInventoryExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.WASTE_INVENTORY_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.WASTE_INVENTORY_EXPORT_FAIL.getLocalCode()));
        }
    }

    @Override
    public void exportWasteInventoryDetail(HttpServletResponse response, WasteInventoryDetailQueryVO queryVO) {
        List<WasteInventoryDetailExportDTO> exportDTOList = CollUtil.newArrayList();
        List<WasteInventoryDetailDTO> wasteInventoryDetailDTOList = sdsHazardousWasteDocInfoMapper
                .selectWasteInventoryDetailList(queryVO);
        wasteInventoryDetailDTOList.forEach(wasteInventoryDetailDTO -> {
            WasteInventoryDetailExportDTO wasteInventoryDetailExportDTO = new WasteInventoryDetailExportDTO();
            BeanUtils.copyProperties(wasteInventoryDetailDTO, wasteInventoryDetailExportDTO);
            exportDTOList.add(wasteInventoryDetailExportDTO);
        });
        String fileName = "结余库存数据信息" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), WasteInventoryDetailExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.WASTE_INVENTORY_DETAIL_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.WASTE_INVENTORY_DETAIL_EXPORT_FAIL.getLocalCode()));
        }
    }

    @Override
    public PageDataDTO<WasteInventoryOverdueWarnDTO> selectWasteInventoryOverdueWarnPage(WasteInventoryOverdueWarnQueryVO queryVO) {
        if (queryVO.getPageIndex() != null && queryVO.getPageSize() != null
                && queryVO.getPageIndex() != 0 && queryVO.getPageSize() != 0) {
            Page page = PageHelper.startPage(queryVO.getPageIndex(), queryVO.getPageSize());
            List<WasteInventoryOverdueWarnDTO> inventoryOverdueWarnDTOList = sdsHazardousWasteDocInfoMapper
                    .selectWasteInventoryOverdueWarnList(queryVO);
            return new PageDataDTO<>(page.getTotal(), inventoryOverdueWarnDTOList);
        } else {
            List<WasteInventoryOverdueWarnDTO> inventoryOverdueWarnDTOList = sdsHazardousWasteDocInfoMapper
                    .selectWasteInventoryOverdueWarnList(queryVO);
            return new PageDataDTO<>((long) inventoryOverdueWarnDTOList.size(), inventoryOverdueWarnDTOList);
        }
    }

    @Override
    public void exportWasteInventoryOverdueWarnInfo(HttpServletResponse response, WasteInventoryOverdueWarnQueryVO queryVO) {
        List<WasteInventoryOverdueWarnExportDTO> exportDTOList = CollUtil.newArrayList();
        List<WasteInventoryOverdueWarnDTO> inventoryOverdueWarnDTOList = sdsHazardousWasteDocInfoMapper
                .selectWasteInventoryOverdueWarnList(queryVO);
        inventoryOverdueWarnDTOList.forEach(inventoryOverdueWarnDTO -> {
            WasteInventoryOverdueWarnExportDTO wasteInventoryOverdueWarnExportDTO = new WasteInventoryOverdueWarnExportDTO();
            BeanUtils.copyProperties(inventoryOverdueWarnDTO, wasteInventoryOverdueWarnExportDTO);
            exportDTOList.add(wasteInventoryOverdueWarnExportDTO);
        });
        String fileName = "库存超期预警信息" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), WasteInventoryOverdueWarnExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.WASTE_INVENTORY_OVERDUE_WARN_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.WASTE_INVENTORY_OVERDUE_WARN_EXPORT_FAIL.getLocalCode()));
        }
    }
}
