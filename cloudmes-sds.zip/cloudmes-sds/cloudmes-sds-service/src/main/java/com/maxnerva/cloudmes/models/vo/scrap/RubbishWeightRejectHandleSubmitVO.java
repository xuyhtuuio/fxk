package com.maxnerva.cloudmes.models.vo.scrap;

import com.maxnerva.cloudmes.models.vo.CommonRequestVO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class RubbishWeightRejectHandleSubmitVO extends CommonRequestVO {

    @ApiModelProperty(value = "ID", required = true)
    private Integer id;

    @ApiModelProperty(value = "处理方式", required = true)
    private String handleMethod;

    @ApiModelProperty(value = "详细原因备注（处理时填）", required = true)
    private String reason;
}
