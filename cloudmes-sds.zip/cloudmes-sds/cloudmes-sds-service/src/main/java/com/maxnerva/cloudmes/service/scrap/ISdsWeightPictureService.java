package com.maxnerva.cloudmes.service.scrap;

import org.springframework.web.multipart.MultipartFile;

/**
 * @ClassName ISdsWeightPictureCatchService
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/1/2 下午 02:14
 * @Version 1.0
 **/
public interface ISdsWeightPictureService {

    void catchHikvisionPictureJob();

    // 海康照片抓取
    String catchPicture(String areaCode) throws Exception;

    //将图片链接转化为File
    MultipartFile pictureLinkToMultipartFileHandler(String imageUrl, final String fileName);

}
