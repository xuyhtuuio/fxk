package com.maxnerva.cloudmes.models.entity.waste;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

/**
 * <p>
 * 出库单
 * </p>
 *
 * @author likun
 * @since 2025-05-16
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="SdsHazardousWasteShipInfo对象", description="出库单")
public class SdsHazardousWasteShipInfo extends BaseEntity<SdsHazardousWasteShipInfo> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "说明单号")
    private String docNo;

    @ApiModelProperty(value = "单据类型")
    private String docType;

    @ApiModelProperty(value = "单据状态")
    private String docStatus;

    @ApiModelProperty(value = "SDS危废料号")
    private String hazardousWasteNo;

    @ApiModelProperty(value = "废物俗称")
    private String hazardousWasteName;

    @ApiModelProperty(value = "危险废物")
    private String hazardousWaste;

    @ApiModelProperty(value = "废物形态")
    private String shape;

    @ApiModelProperty(value = "主要成分")
    private String rohs;

    @ApiModelProperty(value = "危险特性")
    private String toxicity;

    @ApiModelProperty(value = "包装类型")
    private String packType;

    @ApiModelProperty(value = "废物类别")
    private String hazardousWasteCategory;

    @ApiModelProperty(value = "废物代码")
    private String hazardousWasteCode;

    @ApiModelProperty(value = "出库数量")
    private BigDecimal docQty;

    @ApiModelProperty(value = "出库毛重")
    private BigDecimal docGrossWeight;

    @ApiModelProperty(value = "出库净重")
    private BigDecimal docNetWeight;

    @ApiModelProperty(value = "有无栈板")
    private String isPallet;

    @ApiModelProperty(value = "栈板重量")
    private BigDecimal palletWeight;

    @ApiModelProperty(value = "转移单号")
    private String transferDocNo;

}
