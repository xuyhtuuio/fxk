package com.maxnerva.cloudmes.models.dto.waste;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @ClassName TransferBindShipDTO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/27
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("危废转移单可绑定出库单信息dto")
@Data
public class TransferBindShipDTO {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "出库单号")
    private String shipDocNo;

    @ApiModelProperty(value = "单据类型")
    private String docType;

    @ApiModelProperty(value = "单据状态")
    private String docStatus;

    @ApiModelProperty(value = "SDS危废料号")
    private String hazardousWasteNo;

    @ApiModelProperty(value = "废物俗称")
    private String hazardousWasteName;

    @ApiModelProperty(value = "危险废物")
    private String hazardousWaste;

    @ApiModelProperty(value = "废物形态")
    private String shape;

    @ApiModelProperty(value = "主要成分")
    private String rohs;

    @ApiModelProperty(value = "危险特性")
    private String toxicity;

    @ApiModelProperty("包装类型")
    private String packType;

    @ApiModelProperty(value = "废物类别")
    private String hazardousWasteCategory;

    @ApiModelProperty(value = "废物代码")
    private String hazardousWasteCode;

    @ApiModelProperty(value = "包装数量")
    private BigDecimal applyQty;

    @ApiModelProperty(value = "预估转移数量")
    private BigDecimal preTransferQty;

    @ApiModelProperty(value = "转移单号")
    private String transferDocNo;
}
