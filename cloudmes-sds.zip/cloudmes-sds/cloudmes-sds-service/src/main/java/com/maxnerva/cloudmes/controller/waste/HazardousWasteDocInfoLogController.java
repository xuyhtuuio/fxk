package com.maxnerva.cloudmes.controller.waste;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.waste.HazardousWasteDocInfoLogDTO;
import com.maxnerva.cloudmes.models.vo.waste.HazardousWasteDocInfoLogQueryVO;
import com.maxnerva.cloudmes.service.waste.ISdsHazardousWasteDocInfoLogService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @ClassName HazardousWasteDocInfoLogController
 * @Description TODO
 * @Author Likun
 * @Date 2025/6/11
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "产废单单据日志管理")
@Slf4j
@RestController
@RequestMapping("/hazardousWasteDocInfoLog")
public class HazardousWasteDocInfoLogController {

    @Resource
    private ISdsHazardousWasteDocInfoLogService wasteDocInfoLogService;

    @ApiOperation("查询")
    @PostMapping("/list")
    public R<PageDataDTO<HazardousWasteDocInfoLogDTO>> selectDocInfoLogPage(
            @RequestBody HazardousWasteDocInfoLogQueryVO queryVO){
        return R.ok(wasteDocInfoLogService.selectDocInfoPage(queryVO));
    }
}
