package com.maxnerva.cloudmes.service.waste.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ObjectUtil;
import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.enums.ResultCode;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.common.utils.WebContextUtil;
import com.maxnerva.cloudmes.enums.*;
import com.maxnerva.cloudmes.excel.handler.AddNoHandler;
import com.maxnerva.cloudmes.feign.basic.ICodeRuleClient;
import com.maxnerva.cloudmes.mapper.plan.SdsHazardousWastePlanInfoMapper;
import com.maxnerva.cloudmes.mapper.waste.SdsHazardousWasteDocInfoMapper;
import com.maxnerva.cloudmes.mapper.waste.SdsHazardousWasteRejectMapper;
import com.maxnerva.cloudmes.models.dto.excel.waste.WasteInStoreExportDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteInStoreDocInfoDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteInStoreWeightSubmitDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteDocInfo;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteDocInfoLog;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteReject;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteShipInfo;
import com.maxnerva.cloudmes.models.vo.waste.WasteInStoreConfirmVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteInStoreDocQueryVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteWeightInfoSubmitVO;
import com.maxnerva.cloudmes.service.waste.ISdsHazardousWasteDocInfoLogService;
import com.maxnerva.cloudmes.service.waste.ISdsHazardousWasteShipInfoService;
import com.maxnerva.cloudmes.service.waste.WasteInStoreService;
import com.maxnerva.cloudmes.system.utils.DictLangUtils;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.util.MimeTypeUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @ClassName WasteInStoreServiceImpl
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/16
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Service
@Slf4j
public class WasteInStoreServiceImpl implements WasteInStoreService {

    @Resource
    private SdsHazardousWasteDocInfoMapper sdsHazardousWasteDocInfoMapper;

    @Resource
    private DictLangUtils dictLangUtils;

    @Resource
    private ICodeRuleClient codeRuleClient;

    @Resource
    private SdsHazardousWastePlanInfoMapper sdsHazardousWastePlanInfoMapper;

    @Resource
    private ISdsHazardousWasteDocInfoLogService sdsHazardousWasteDocInfoLogService;

    @Resource
    private PlatformTransactionManager transactionManager;

    @Resource
    private SdsHazardousWasteRejectMapper sdsHazardousWasteRejectMapper;

    @Resource
    private ISdsHazardousWasteShipInfoService sdsHazardousWasteShipInfoService;

    @Override
    public PageDataDTO<WasteInStoreDocInfoDTO> selectWasteInStorePage(WasteInStoreDocQueryVO queryVO) {
        if (queryVO.getPageIndex() != null && queryVO.getPageSize() != null
                && queryVO.getPageIndex() != 0 && queryVO.getPageSize() != 0) {
            Page page = PageHelper.startPage(queryVO.getPageIndex(), queryVO.getPageSize());
            List<WasteInStoreDocInfoDTO> wasteInStoreDocInfoDTOList = getWasteInStoreDocInfoDTOList(queryVO);
            return new PageDataDTO<>(page.getTotal(), wasteInStoreDocInfoDTOList);
        } else {
            List<WasteInStoreDocInfoDTO> wasteInStoreDocInfoDTOList = getWasteInStoreDocInfoDTOList(queryVO);
            return new PageDataDTO<>((long) wasteInStoreDocInfoDTOList.size(), wasteInStoreDocInfoDTOList);
        }
    }

    @NotNull
    private List<WasteInStoreDocInfoDTO> getWasteInStoreDocInfoDTOList(WasteInStoreDocQueryVO queryVO) {
        List<WasteInStoreDocInfoDTO> wasteInStoreDocInfoDTOList = sdsHazardousWasteDocInfoMapper
                .selectInStoreDocInfoList(queryVO);
        List<String> types = CollUtil.newArrayList();
        types.add("SDS_HAZARDOUS_WASTE_ENTRY_TYPE");
        types.add("SDS_WASTE_IN_STORE_DOC_STATUS");
        Map<String, Map<String, String>> data = dictLangUtils.getByTypes(types);
        Map<String, String> entryTypeMap = data.get("SDS_HAZARDOUS_WASTE_ENTRY_TYPE");
        Map<String, String> docStatusMap = data.get("SDS_WASTE_IN_STORE_DOC_STATUS");
        wasteInStoreDocInfoDTOList.forEach(wasteInStoreDocInfoDTO -> {
            wasteInStoreDocInfoDTO.setDocStatusName(docStatusMap.get(wasteInStoreDocInfoDTO.getDocStatus()));
            wasteInStoreDocInfoDTO.setDocTypeName(entryTypeMap.get(wasteInStoreDocInfoDTO.getDocType()));
        });
        return wasteInStoreDocInfoDTOList;
    }

    @Override
    public R<WasteInStoreWeightSubmitDTO> inStoreWeightSubmit(WasteWeightInfoSubmitVO submitVO) {
        log.info("wasteInStoreWeigh: {} {} start", submitVO.getDocNo(), submitVO.getGrossWeight());
        String currentStaffCode = WebContextUtil.getCurrentStaffCode();
        String docNo = submitVO.getDocNo();
        BigDecimal grossWeight = submitVO.getGrossWeight();
        WasteInStoreWeightSubmitDTO dto = new WasteInStoreWeightSubmitDTO();
        R<WasteInStoreWeightSubmitDTO> r = new R<>();
        r.setData(dto);
        dto.setDocNo(docNo);
        dto.setInstoreGrossWeight(grossWeight);
        SdsHazardousWasteDocInfo sdsHazardousWasteDocInfo = sdsHazardousWasteDocInfoMapper
                .selectOne(Wrappers.<SdsHazardousWasteDocInfo>lambdaQuery()
                        .eq(SdsHazardousWasteDocInfo::getDocNo, docNo)
                        .last("limit 1"));
        if (ObjectUtil.isNull(sdsHazardousWasteDocInfo)) {
            r.setCode(SdsResultCode.WASTE_DOC_NOT_EXIST.getCode());
            r.setMsg(String.format(MessageUtils.get(SdsResultCode.WASTE_DOC_NOT_EXIST.getLocalCode()),
                    docNo));
            return r;
        }
        dto.setId(sdsHazardousWasteDocInfo.getId());
        dto.setHazardousWasteName(sdsHazardousWasteDocInfo.getHazardousWasteName());
        dto.setDepName(sdsHazardousWasteDocInfo.getDepName());
        dto.setPalletWeight(sdsHazardousWasteDocInfo.getPalletWeight());
        dto.setCostCode(sdsHazardousWasteDocInfo.getCostCode());
        dto.setHazardousWasteNo(sdsHazardousWasteDocInfo.getHazardousWasteNo());
        dto.setApplyQty(sdsHazardousWasteDocInfo.getApplyQty());
        dto.setWorkshopNetWeight(sdsHazardousWasteDocInfo.getApplyNetWeight());
        if (WasteDocTypeEnum.NO_STORAGE.getDictCode().equals(sdsHazardousWasteDocInfo.getDocType())) {
            r.setCode(SdsResultCode.NO_STORAGE_DOC_CAN_NOT_IN_STORE.getCode());
            r.setMsg(MessageUtils.get(SdsResultCode.NO_STORAGE_DOC_CAN_NOT_IN_STORE.getLocalCode()));
            return r;
        }
        String docStatus = sdsHazardousWasteDocInfo.getDocStatus();
        if (!WasteDocInfoStatusEnum.APPLIED_FOR_STORAGE.getDictCode().equals(docStatus)) {
            r.setCode(SdsResultCode.DOC_HAVE_NOT_APPLIED_FOR_STORAGE_CAN_NOT_WEIGHT.getCode());
            r.setMsg(String.format(MessageUtils.get(SdsResultCode.DOC_HAVE_NOT_APPLIED_FOR_STORAGE_CAN_NOT_WEIGHT.getLocalCode()),
                    docNo));
            return r;
        }
        if (WasteDocInfoStatusEnum.IN_STORAGE.getDictCode().equals(docStatus)
                || WasteDocInfoStatusEnum.CREATED_SHIP_DOC.getDictCode().equals(docStatus)) {
            r.setCode(SdsResultCode.DOC_HAVE_BEEN_IN_STORED.getCode());
            r.setMsg(String.format(MessageUtils.get(SdsResultCode.DOC_HAVE_BEEN_IN_STORED.getLocalCode()),
                    docNo));
            return r;
        }
        if ("N".equals(sdsHazardousWasteDocInfo.getApplyWeighStatus())) {
            r.setCode(SdsResultCode.DOC_NOT_WEIGHT.getCode());
            r.setMsg(String.format(MessageUtils.get(SdsResultCode.DOC_NOT_WEIGHT.getLocalCode()),
                    docNo));
            return r;
        }
        BigDecimal palletWeight = sdsHazardousWasteDocInfo.getPalletWeight();
        BigDecimal netWeight = grossWeight.subtract(palletWeight);
        dto.setInstoreNetWeight(netWeight);
        if (netWeight.compareTo(BigDecimal.ZERO) <= 0) {
            r.setCode(SdsResultCode.NET_WEIGHT_CAN_NOT_LESS_THAN_ZERO.getCode());
            r.setMsg(String.format(MessageUtils.get(SdsResultCode.NET_WEIGHT_CAN_NOT_LESS_THAN_ZERO.getLocalCode()),
                    netWeight));
            return r;
        }
        Map<String, String> weightErrorDictMap = dictLangUtils.getByType("SDS_HAZARDOUS_WASTE_WEIGHT_ERROR");
        if (!weightErrorDictMap.containsKey(WasteDocOperateType.WASTE_IN_STORE_WEIGHT.getDictCode())) {
            r.setCode(SdsResultCode.UN_MAINTAIN_WEIGHT_ERROR.getCode());
            r.setMsg(MessageUtils.get(SdsResultCode.UN_MAINTAIN_WEIGHT_ERROR.getLocalCode()));
            return r;
        }
        BigDecimal weightError = new BigDecimal(weightErrorDictMap.get(WasteDocOperateType
                .WASTE_IN_STORE_WEIGHT.getDictCode()));
        if (sdsHazardousWasteDocInfo.getApplyNetWeight().subtract(netWeight).abs().compareTo(weightError) > 0) {
            r.setCode(SdsResultCode.NOT_WITHIN_ALLOWABLE_RANGE.getCode());
            r.setMsg(MessageUtils.get(SdsResultCode.NOT_WITHIN_ALLOWABLE_RANGE.getLocalCode()));
            dto.setHandleConfirm("Y");
            return r;
        }
        // 手动开启事务
        TransactionStatus transactionStatus = transactionManager.getTransaction(new DefaultTransactionDefinition());
        try {
            sdsHazardousWasteDocInfoMapper.update(null, Wrappers.<SdsHazardousWasteDocInfo>lambdaUpdate()
                    .eq(SdsHazardousWasteDocInfo::getId, sdsHazardousWasteDocInfo.getId())
                    .set(SdsHazardousWasteDocInfo::getDocStatus, WasteDocInfoStatusEnum.IN_STORAGE.getDictCode())
                    .set(SdsHazardousWasteDocInfo::getInstoreWeighStatus, "Y")
                    .set(SdsHazardousWasteDocInfo::getInstoreGrossWeight, grossWeight)
                    .set(SdsHazardousWasteDocInfo::getInstoreNetWeight, netWeight)
                    .set(SdsHazardousWasteDocInfo::getInstoreEmp, currentStaffCode)
                    .set(SdsHazardousWasteDocInfo::getInstoreDt, LocalDateTime.now())
                    .set(SdsHazardousWasteDocInfo::getAcceptFlag, "Y")
                    .set(SdsHazardousWasteDocInfo::getAcceptEmpNo, currentStaffCode)
                    .set(SdsHazardousWasteDocInfo::getAcceptDt, LocalDateTime.now())
                    .set(SdsHazardousWasteDocInfo::getLastEditor, currentStaffCode)
                    .set(SdsHazardousWasteDocInfo::getLastEditedDt, LocalDateTime.now()));
            dto.setHandleConfirm("N");
            //写称重sds_hazardous_waste_doc_info_log
            SdsHazardousWasteDocInfoLog sdsHazardousWasteDocInfoLog = new SdsHazardousWasteDocInfoLog();
            BeanUtils.copyProperties(sdsHazardousWasteDocInfo, sdsHazardousWasteDocInfoLog);
            sdsHazardousWasteDocInfoLog.setId(null);
            sdsHazardousWasteDocInfoLog.setDocStatus(WasteDocInfoStatusEnum.IN_STORAGE.getDictCode());
            sdsHazardousWasteDocInfoLog.setInstoreWeighStatus("Y");
            sdsHazardousWasteDocInfoLog.setInstoreGrossWeight(grossWeight);
            sdsHazardousWasteDocInfoLog.setInstoreNetWeight(netWeight);
            sdsHazardousWasteDocInfoLog.setInstoreEmp(currentStaffCode);
            sdsHazardousWasteDocInfoLog.setInstoreDt(LocalDateTime.now());
            sdsHazardousWasteDocInfoLog.setAcceptFlag("Y");
            sdsHazardousWasteDocInfoLog.setAcceptDt(LocalDateTime.now());
            sdsHazardousWasteDocInfoLog.setAcceptEmpNo(currentStaffCode);
            sdsHazardousWasteDocInfoLog.setOperateType(WasteDocOperateType.WASTE_IN_STORE_WEIGHT.getDictCode());
            sdsHazardousWasteDocInfoLog.setOperateMsg(WasteDocOperateType.WASTE_IN_STORE_WEIGHT.getDictName());
            sdsHazardousWasteDocInfoLogService.save(sdsHazardousWasteDocInfoLog);
            transactionManager.commit(transactionStatus);
        } catch (CloudmesException e) {
            transactionManager.rollback(transactionStatus);
            throw e;
        } catch (Exception e) {
            transactionManager.rollback(transactionStatus);
            e.printStackTrace();
            throw new CloudmesException(e.getMessage());
        }
        r.setCode(ResultCode.SUCCESS.getCode());
        r.setSuccess(Boolean.TRUE);
        r.setMsg(MessageUtils.get(ResultCode.SUCCESS.getLocalCode()));
        r.setData(dto);
        log.info("wasteInStoreWeight: {} {} {} {} end", docNo, grossWeight, r.getMsg(), r.getCode());
        return r;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void confirmInStoreWeightInfo(WasteInStoreConfirmVO confirmVO) {
        String docNo = confirmVO.getDocNo();
        BigDecimal grossWeight = confirmVO.getGrossWeight();
        String currentStaffCode = WebContextUtil.getCurrentStaffCode();
        SdsHazardousWasteDocInfo sdsHazardousWasteDocInfo = sdsHazardousWasteDocInfoMapper
                .selectOne(Wrappers.<SdsHazardousWasteDocInfo>lambdaQuery()
                        .eq(SdsHazardousWasteDocInfo::getDocNo, docNo)
                        .last("limit 1"));
        Optional.ofNullable(sdsHazardousWasteDocInfo)
                .orElseThrow(() -> new CloudmesException(SdsResultCode.WASTE_DOC_NOT_EXIST.getCode(),
                        String.format(MessageUtils.get(SdsResultCode.WASTE_DOC_NOT_EXIST.getLocalCode()),
                                docNo)));
        BigDecimal palletWeight = sdsHazardousWasteDocInfo.getPalletWeight();
        BigDecimal netWeight = grossWeight.subtract(palletWeight);
        if ("Y".equals(confirmVO.getHandleConfirm())) {
            sdsHazardousWasteDocInfoMapper.update(null, Wrappers.<SdsHazardousWasteDocInfo>lambdaUpdate()
                    .eq(SdsHazardousWasteDocInfo::getId, sdsHazardousWasteDocInfo.getId())
                    .set(SdsHazardousWasteDocInfo::getDocStatus, WasteDocInfoStatusEnum.IN_STORAGE.getDictCode())
                    .set(SdsHazardousWasteDocInfo::getInstoreWeighStatus, "Y")
                    .set(SdsHazardousWasteDocInfo::getInstoreGrossWeight, grossWeight)
                    .set(SdsHazardousWasteDocInfo::getInstoreNetWeight, netWeight)
                    .set(SdsHazardousWasteDocInfo::getInstoreEmp, currentStaffCode)
                    .set(SdsHazardousWasteDocInfo::getInstoreDt, LocalDateTime.now())
                    .set(SdsHazardousWasteDocInfo::getAcceptFlag, "Y")
                    .set(SdsHazardousWasteDocInfo::getAcceptEmpNo, currentStaffCode)
                    .set(SdsHazardousWasteDocInfo::getAcceptDt, LocalDateTime.now())
                    .set(SdsHazardousWasteDocInfo::getLastEditor, currentStaffCode)
                    .set(SdsHazardousWasteDocInfo::getLastEditedDt, LocalDateTime.now()));
            SdsHazardousWasteDocInfoLog sdsHazardousWasteDocInfoLog = new SdsHazardousWasteDocInfoLog();
            BeanUtils.copyProperties(sdsHazardousWasteDocInfo, sdsHazardousWasteDocInfoLog);
            sdsHazardousWasteDocInfoLog.setId(null);
            sdsHazardousWasteDocInfoLog.setDocStatus(WasteDocInfoStatusEnum.IN_STORAGE.getDictCode());
            sdsHazardousWasteDocInfoLog.setInstoreWeighStatus("Y");
            sdsHazardousWasteDocInfoLog.setInstoreGrossWeight(grossWeight);
            sdsHazardousWasteDocInfoLog.setInstoreNetWeight(netWeight);
            sdsHazardousWasteDocInfoLog.setInstoreEmp(currentStaffCode);
            sdsHazardousWasteDocInfoLog.setInstoreDt(LocalDateTime.now());
            sdsHazardousWasteDocInfoLog.setAcceptFlag("Y");
            sdsHazardousWasteDocInfoLog.setAcceptDt(LocalDateTime.now());
            sdsHazardousWasteDocInfoLog.setAcceptEmpNo(currentStaffCode);
            sdsHazardousWasteDocInfoLog.setOperateType(WasteDocOperateType.IN_STORE_ERR_ACCEPT.getDictCode());
            sdsHazardousWasteDocInfoLog.setOperateMsg(WasteDocOperateType.IN_STORE_ERR_ACCEPT.getDictName());
            sdsHazardousWasteDocInfoLogService.save(sdsHazardousWasteDocInfoLog);
        } else {
            Optional.of(sdsHazardousWasteDocInfo)
                    .filter(docInfo -> WasteDocTypeEnum.STORAGE.getDictCode().equals(docInfo.getDocType()))
                    .orElseThrow(() -> new CloudmesException(SdsResultCode.DOC_IS_NOT_STORAGE_CAN_NOT_REJECT.getCode(),
                            String.format(MessageUtils.get(SdsResultCode.DOC_IS_NOT_STORAGE_CAN_NOT_REJECT.getLocalCode()),
                                    docNo)));
            Optional.of(sdsHazardousWasteDocInfo)
                    .filter(docInfo -> !WasteDocInfoStatusEnum.CREATED_SHIP_DOC.getDictCode().equals(docInfo.getDocStatus()))
                    .orElseThrow(() -> new CloudmesException(SdsResultCode.DOC_HAVE_BEEN_CREATED_SHIP_INFO_CAN_NOT_REJECT
                            .getCode(), String.format(MessageUtils.get(SdsResultCode
                            .DOC_HAVE_BEEN_CREATED_SHIP_INFO_CAN_NOT_REJECT.getLocalCode()), docNo)));
            Long count = sdsHazardousWasteRejectMapper
                    .selectCount(Wrappers.<SdsHazardousWasteReject>lambdaQuery()
                            .eq(SdsHazardousWasteReject::getDocNo, docNo)
                            .last("limit 1"));
            if (count > 0) {
                throw new CloudmesException(SdsResultCode.DOC_HAVE_BEEN_REJECT.getCode(),
                        String.format(MessageUtils.get(SdsResultCode.DOC_HAVE_BEEN_REJECT.getLocalCode()), docNo));
            }
            sdsHazardousWasteDocInfoMapper.update(null, Wrappers.<SdsHazardousWasteDocInfo>lambdaUpdate()
                    .eq(SdsHazardousWasteDocInfo::getId, sdsHazardousWasteDocInfo.getId())
                    .set(SdsHazardousWasteDocInfo::getIsDeleted, Boolean.TRUE)
                    .set(SdsHazardousWasteDocInfo::getLastEditor, currentStaffCode)
                    .set(SdsHazardousWasteDocInfo::getLastEditedDt, LocalDateTime.now()));
            SdsHazardousWasteReject sdsHazardousWasteReject = new SdsHazardousWasteReject();
            BeanUtils.copyProperties(sdsHazardousWasteDocInfo, sdsHazardousWasteReject);
            sdsHazardousWasteReject.setId(null);
            sdsHazardousWasteReject.setRejectEmpNo(confirmVO.getOperateEmpNo());
            sdsHazardousWasteReject.setRejectDt(LocalDateTime.now());
            sdsHazardousWasteReject.setRejectReasonType(confirmVO.getOperateRemarkType());
            sdsHazardousWasteReject.setInstoreGrossWeight(grossWeight);
            sdsHazardousWasteReject.setInstoreNetWeight(netWeight);
            sdsHazardousWasteReject.setDocId(sdsHazardousWasteDocInfo.getId());
            sdsHazardousWasteRejectMapper.insert(sdsHazardousWasteReject);
            SdsHazardousWasteDocInfoLog sdsHazardousWasteDocInfoLog = new SdsHazardousWasteDocInfoLog();
            BeanUtils.copyProperties(sdsHazardousWasteDocInfo, sdsHazardousWasteDocInfoLog);
            sdsHazardousWasteDocInfoLog.setId(null);
            sdsHazardousWasteDocInfoLog.setInstoreGrossWeight(grossWeight);
            sdsHazardousWasteDocInfoLog.setInstoreNetWeight(netWeight);
            sdsHazardousWasteDocInfoLog.setOperateType(WasteDocOperateType.IN_STORE_ERR_REJECT.getDictCode());
            sdsHazardousWasteDocInfoLog.setOperateMsg(WasteDocOperateType.IN_STORE_ERR_REJECT.getDictName());
            sdsHazardousWasteDocInfoLogService.save(sdsHazardousWasteDocInfoLog);
            String orgCode = sdsHazardousWasteDocInfo.getOrgCode();
            String costCode = sdsHazardousWasteDocInfo.getCostCode();
            String hazardousWasteNo = sdsHazardousWasteDocInfo.getHazardousWasteNo();
            int year = LocalDate.now().getYear();
            sdsHazardousWastePlanInfoMapper.subtractUsedWeight(orgCode, costCode, String.valueOf(year), hazardousWasteNo,
                    sdsHazardousWasteDocInfo.getApplyNetWeight(), currentStaffCode);
        }
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void applyShip(List<Integer> idList, String docType) {
        String currentStaffCode = WebContextUtil.getCurrentStaffCode();
        List<SdsHazardousWasteDocInfo> sdsHazardousWasteDocInfoList = sdsHazardousWasteDocInfoMapper
                .selectList(Wrappers.<SdsHazardousWasteDocInfo>lambdaQuery()
                        .in(SdsHazardousWasteDocInfo::getId, idList));
        long count = sdsHazardousWasteDocInfoList.stream().map(SdsHazardousWasteDocInfo::getHazardousWasteNo)
                .distinct().count();
        if (count != 1) {
            throw new CloudmesException(SdsResultCode.SELECT_DOC_MUST_BE_A_HAZARDOUS_WASTE_MATERIAL.getCode(),
                    MessageUtils.get(SdsResultCode.SELECT_DOC_MUST_BE_A_HAZARDOUS_WASTE_MATERIAL.getLocalCode()));
        }
        BigDecimal totalApplyQty = sdsHazardousWasteDocInfoList.stream().map(SdsHazardousWasteDocInfo::getApplyQty)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal totalInStoreGrossWeight = sdsHazardousWasteDocInfoList.stream()
                .map(SdsHazardousWasteDocInfo::getInstoreGrossWeight)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal totalInStoreNetWeight = sdsHazardousWasteDocInfoList.stream()
                .map(SdsHazardousWasteDocInfo::getInstoreNetWeight)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        List<SdsHazardousWasteDocInfoLog> sdsHazardousWasteDocInfoLogList = CollUtil.newArrayList();
        for (SdsHazardousWasteDocInfo wasteDocInfo : sdsHazardousWasteDocInfoList) {
            String docNo = wasteDocInfo.getDocNo();
            String docStatus = wasteDocInfo.getDocStatus();
            if (!docType.equals(wasteDocInfo.getDocType())) {
                if (WasteDocTypeEnum.STORAGE.getDictCode().equals(docType)) {
                    throw new CloudmesException(SdsResultCode.DOC_NO_NOT_OF_STORAGE_DOC_TYPE.getCode(),
                            String.format(MessageUtils.get(SdsResultCode.DOC_NO_NOT_OF_STORAGE_DOC_TYPE.getLocalCode()),
                                    docNo));
                } else {
                    throw new CloudmesException(SdsResultCode.DOC_NO_NOT_OF_NO_STORAGE_DOC_TYPE.getCode(),
                            String.format(MessageUtils.get(SdsResultCode.DOC_NO_NOT_OF_NO_STORAGE_DOC_TYPE.getLocalCode()),
                                    docNo));
                }
            }
            if (!WasteDocInfoStatusEnum.IN_STORAGE.getDictCode().equals(docStatus)) {
                throw new CloudmesException(SdsResultCode.DOC_HAS_NOT_BEEN_IN_STORE_CAN_NOT_GENERATE_SHIP_DOC.getCode(),
                        String.format(MessageUtils.get(SdsResultCode.DOC_HAS_NOT_BEEN_IN_STORE_CAN_NOT_GENERATE_SHIP_DOC
                                .getLocalCode()), docNo));
            }
            SdsHazardousWasteDocInfoLog sdsHazardousWasteDocInfoLog = new SdsHazardousWasteDocInfoLog();
            BeanUtils.copyProperties(wasteDocInfo, sdsHazardousWasteDocInfoLog);
            sdsHazardousWasteDocInfoLog.setId(null);
            sdsHazardousWasteDocInfoLog.setDocStatus(WasteDocInfoStatusEnum.CREATED_SHIP_DOC.getDictCode());
            sdsHazardousWasteDocInfoLog.setOperateType(WasteDocOperateType.APPLY_SHIP.getDictCode());
            sdsHazardousWasteDocInfoLog.setOperateMsg(WasteDocOperateType.APPLY_SHIP.getDictName());
            sdsHazardousWasteDocInfoLogList.add(sdsHazardousWasteDocInfoLog);
        }
        SdsHazardousWasteDocInfo sdsHazardousWasteDocInfo = sdsHazardousWasteDocInfoList.get(0);
        SdsHazardousWasteShipInfo sdsHazardousWasteShipInfo = new SdsHazardousWasteShipInfo();
        BeanUtils.copyProperties(sdsHazardousWasteDocInfo, sdsHazardousWasteShipInfo);
        String serialNo;
        R<List<String>> result = codeRuleClient.getSerialNumber(CodeRuleEnum.SDS_WASTE_SHIP_DOC_NO
                .getDictCode(), 1);
        if (result.getCode() == ResultCode.SUCCESS.getCode()) {
            serialNo = result.getData().get(0);
        } else {
            throw new CloudmesException(SdsResultCode.CONNECT_BASIC_GET_SERIAL_NUMBER.getCode()
                    , MessageUtils.get(SdsResultCode.CONNECT_BASIC_GET_SERIAL_NUMBER.getLocalCode()));
        }
        sdsHazardousWasteShipInfo.setDocNo(serialNo);
        sdsHazardousWasteShipInfo.setDocStatus("0");
        sdsHazardousWasteShipInfo.setDocQty(totalApplyQty);
        sdsHazardousWasteShipInfo.setDocGrossWeight(totalInStoreGrossWeight);
        sdsHazardousWasteShipInfo.setDocNetWeight(totalInStoreNetWeight);
        sdsHazardousWasteShipInfoService.save(sdsHazardousWasteShipInfo);
        List<Integer> updateIdList = sdsHazardousWasteDocInfoList.stream().map(SdsHazardousWasteDocInfo::getId)
                .collect(Collectors.toList());
        sdsHazardousWasteDocInfoMapper.update(null, Wrappers.<SdsHazardousWasteDocInfo>lambdaUpdate()
                .in(SdsHazardousWasteDocInfo::getId, updateIdList)
                .set(SdsHazardousWasteDocInfo::getShipDocNo, serialNo)
                .set(SdsHazardousWasteDocInfo::getDocStatus, WasteDocInfoStatusEnum.CREATED_SHIP_DOC.getDictCode())
                .set(SdsHazardousWasteDocInfo::getLastEditor, currentStaffCode)
                .set(SdsHazardousWasteDocInfo::getLastEditedDt, LocalDateTime.now()));
        sdsHazardousWasteDocInfoLogList.forEach(sdsHazardousWasteDocInfoLog ->
                sdsHazardousWasteDocInfoLog.setShipDocNo(serialNo));
        sdsHazardousWasteDocInfoLogService.saveBatch(sdsHazardousWasteDocInfoLogList);
    }

    @Override
    public void exportInStoreDoc(HttpServletResponse response, WasteInStoreDocQueryVO queryVO) {
        List<WasteInStoreExportDTO> exportDTOList = CollUtil.newArrayList();
        List<WasteInStoreDocInfoDTO> wasteInStoreDocInfoDTOList = getWasteInStoreDocInfoDTOList(queryVO);
        wasteInStoreDocInfoDTOList.forEach(wasteInStoreDocInfoDTO -> {
            WasteInStoreExportDTO wasteInStoreExportDTO = new WasteInStoreExportDTO();
            BeanUtils.copyProperties(wasteInStoreDocInfoDTO, wasteInStoreExportDTO);
            exportDTOList.add(wasteInStoreExportDTO);
        });
        String fileName = "入库单信息" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), WasteInStoreExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.HAZARDOUS_WASTE_IN_STORE_DOC_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.HAZARDOUS_WASTE_IN_STORE_DOC_EXPORT_FAIL.getLocalCode()));
        }
    }
}
