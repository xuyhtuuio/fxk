package com.maxnerva.cloudmes.models.dto.excel.scrap;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.excel.converter.LocalDateStringConverter;
import com.maxnerva.cloudmes.excel.converter.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("固废缴款单DTO")
@Data
public class SteelPaymentHeaderExportDTO {

    @ApiModelProperty("缴款单号")
    @ExcelProperty(value = "缴款单号")
    private String docNo;

    @ApiModelProperty("厂商")
    @ExcelProperty(value = "厂商")
    private String manFacturer;

    @ApiModelProperty("合约预付款")
    @ExcelProperty(value = "合约预付款")
    private BigDecimal prePayment;

    @ApiModelProperty("本期销售款")
    @ExcelProperty(value = "本期销售款")
    private BigDecimal sales;

    @ApiModelProperty("缴款截止日期")
    @ExcelProperty(value = "缴款时限", converter = LocalDateStringConverter.class)
    private LocalDate endDate;

    @ApiModelProperty("收款公司")
    @ExcelProperty(value = "收款公司")
    private String collectionCompany;

    @ApiModelProperty("开始日期")
    @ExcelProperty(value = "开始日期", converter = LocalDateStringConverter.class)
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate startDate;

    @ApiModelProperty("结束日期")
    @ExcelProperty(value = "结束日期", converter = LocalDateStringConverter.class)
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate finishDate;

    @ApiModelProperty(value = "创建人")
    @ExcelProperty(value = "创建人")
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "创建时间")
    @ExcelProperty(value = "创建时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime createdDt;
}
