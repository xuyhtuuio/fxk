package com.maxnerva.cloudmes.models.dto.excel.waste.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;

/**
 * @ClassName WasteInventoryExportDTO
 * @Description TODO
 * @Author Likun
 * @Date 2025/6/20
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("危废库存导出DTO")
@Data
public class WasteInventoryExportDTO {

    @ApiModelProperty(value = "废料料号")
    @ExcelProperty(value = "废料料号")
    private String hazardousWasteNo;

    @ApiModelProperty(value = "废物俗称")
    @ExcelProperty(value = "废物俗称")
    private String hazardousWasteName;

    @ApiModelProperty(value = "结余库存(KG)")
    @ExcelProperty(value = "结余库存")
    private BigDecimal remainNetWeight;

    @ApiModelProperty(value = "产废重量(KG)")
    @ExcelProperty(value = "产废重量(KG)")
    private BigDecimal totalApplyNetWeight;

    @ApiModelProperty(value = "入库重量(KG)")
    @ExcelProperty(value = "入库重量(KG)")
    private BigDecimal totalInstoreNetWeight;

    @ApiModelProperty(value = "出库重量(KG)")
    @ExcelProperty(value = "出库重量(KG)")
    private BigDecimal shipNetWeight;

}
