package com.maxnerva.cloudmes.service.basic.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.google.common.collect.Sets;
import com.maxnerva.cloudmes.common.enums.ResultCode;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.excel.handler.AddNoHandler;
import com.maxnerva.cloudmes.excel.listener.basic.MaterialClassImportListener;
import com.maxnerva.cloudmes.mapper.basic.SdsMaterialClassMapper;
import com.maxnerva.cloudmes.models.dto.basic.MaterialClassDTO;
import com.maxnerva.cloudmes.models.dto.excel.basic.MaterialClassExportDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsMaterialClass;
import com.maxnerva.cloudmes.models.entity.basic.SdsSteelBucketInfo;
import com.maxnerva.cloudmes.models.vo.basic.MaterialClassQueryVO;
import com.maxnerva.cloudmes.models.vo.basic.MaterialClassSaveOrUpdateVO;
import com.maxnerva.cloudmes.models.vo.excel.ExcelImportVO;
import com.maxnerva.cloudmes.models.vo.excel.basic.MaterialClassImportVO;
import com.maxnerva.cloudmes.service.basic.ISdsMaterialClassService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * <p>
 * 物料类别信息 服务实现类
 * </p>
 *
 * @author likun
 * @since 2024-10-28
 */
@Slf4j
@Service
public class SdsMaterialClassServiceImpl extends ServiceImpl<SdsMaterialClassMapper, SdsMaterialClass>
        implements ISdsMaterialClassService {

    /**
     * excel类型
     */
    private static final Set<String> EXCEL_FILE_TYPE = Sets.newHashSet(".xlsx", ".xls");

    @Override
    public PageDataDTO<MaterialClassDTO> selectMaterialClassPage(MaterialClassQueryVO queryVO) {
        if (queryVO.getPageIndex() != null && queryVO.getPageSize() != null
                && queryVO.getPageIndex() != 0 && queryVO.getPageSize() != 0) {
            Page page = PageHelper.startPage(queryVO.getPageIndex(), queryVO.getPageSize());
            List<MaterialClassDTO> materialClassDTOList = baseMapper.selectMaterialClassList(queryVO);
            return new PageDataDTO<>(page.getTotal(), materialClassDTOList);
        } else {
            List<MaterialClassDTO> materialClassDTOList = baseMapper.selectMaterialClassList(queryVO);
            return new PageDataDTO<>((long) materialClassDTOList.size(), materialClassDTOList);
        }
    }

    @Override
    public void saveMaterialClass(MaterialClassSaveOrUpdateVO materialClassSaveOrUpdateVO) {
        String classCode = materialClassSaveOrUpdateVO.getClassCode();
        String orgCode = materialClassSaveOrUpdateVO.getOrgCode();
        Long count = baseMapper.selectCount(Wrappers.<SdsMaterialClass>lambdaQuery()
                .eq(SdsMaterialClass::getOrgCode, orgCode)
                .eq(SdsMaterialClass::getClassCode, classCode));
        if (count > 0) {
            throw new CloudmesException(SdsResultCode.CLASS_CODE_EXISTED_CAN_NOT_REPEAT.getCode(),
                    String.format(MessageUtils.get(SdsResultCode.CLASS_CODE_EXISTED_CAN_NOT_REPEAT.getLocalCode()),
                            classCode));
        }
        SdsMaterialClass sdsMaterialClass = new SdsMaterialClass();
        BeanUtils.copyProperties(materialClassSaveOrUpdateVO, sdsMaterialClass);
        baseMapper.insert(sdsMaterialClass);
    }

    @Override
    public void updateMaterialClass(MaterialClassSaveOrUpdateVO materialClassSaveOrUpdateVO) {
        String classCode = materialClassSaveOrUpdateVO.getClassCode();
        String orgCode = materialClassSaveOrUpdateVO.getOrgCode();
        Integer id = materialClassSaveOrUpdateVO.getId();
        SdsMaterialClass sdsMaterialClassDb = baseMapper.selectOne(Wrappers.<SdsMaterialClass>lambdaQuery()
                .eq(SdsMaterialClass::getOrgCode, orgCode)
                .eq(SdsMaterialClass::getClassCode, classCode));
        if (ObjectUtil.isNotNull(sdsMaterialClassDb)) {
            if (!id.equals(sdsMaterialClassDb.getId())) {
                throw new CloudmesException(SdsResultCode.CLASS_CODE_EXISTED_CAN_NOT_REPEAT.getCode(),
                        String.format(MessageUtils.get(SdsResultCode.CLASS_CODE_EXISTED_CAN_NOT_REPEAT.getLocalCode()),
                                classCode));
            }
        }
        SdsMaterialClass sdsMaterialClass = new SdsMaterialClass();
        BeanUtils.copyProperties(materialClassSaveOrUpdateVO, sdsMaterialClass);
        baseMapper.updateById(sdsMaterialClass);
    }

    @Override
    public void deleteMaterialClass(Integer id) {
        baseMapper.deleteById(id);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void importMaterialClass(ExcelImportVO excelImportVO) {
        MultipartFile file = excelImportVO.getFile();
        String orgCode = excelImportVO.getOrgCode();
        String originalFilename = file.getOriginalFilename();
        if (StrUtil.isEmpty(originalFilename)) {
            throw new CloudmesException(SdsResultCode.FILE_NOT_NULL.getCode(),
                    MessageUtils.get(SdsResultCode.FILE_NOT_NULL.getLocalCode()));
        }
        //获取文件后缀
        String fileSuffix = StrUtil.sub(originalFilename, StrUtil.lastIndexOfIgnoreCase(originalFilename, "."),
                originalFilename.length());
        if (!EXCEL_FILE_TYPE.contains(fileSuffix)) {
            throw new CloudmesException(SdsResultCode.WRONG_FILE_TYPE.getCode(),
                    MessageUtils.get(SdsResultCode.WRONG_FILE_TYPE.getLocalCode()));
        }
        MaterialClassImportListener materialClassImportListener = new MaterialClassImportListener();
        try {
            EasyExcel.read(new BufferedInputStream(file.getInputStream()), materialClassImportListener)
                    .head(MaterialClassImportVO.class).sheet().doReadSync();
        } catch (IOException e) {
            log.error("物料类别信息上传excel导入异常");
            throw new CloudmesException(SdsResultCode.EXCEL_PARSE_ERROR.getCode(),
                    MessageUtils.get(SdsResultCode.EXCEL_PARSE_ERROR.getLocalCode()));
        }
        List<MaterialClassImportVO> materialClassImportVOList = materialClassImportListener
                .getMaterialClassImportVOList();
        if (CollUtil.isEmpty(materialClassImportVOList)) {
            throw new CloudmesException(SdsResultCode.EXCEL_IMPORT_INFORMATION_IS_EMPTY.getCode(),
                    MessageUtils.get(SdsResultCode.EXCEL_IMPORT_INFORMATION_IS_EMPTY.getLocalCode()));
        }
        List<String> errorList = materialClassImportListener.getError();
        if (CollUtil.isNotEmpty(errorList)) {
            throw new CloudmesException(ResultCode.FAILURE.getCode(), errorList.toString());
        }
        Map<String, List<MaterialClassImportVO>> collect = materialClassImportVOList.stream()
                .collect(Collectors.groupingBy(MaterialClassImportVO::getClassCode));
        for (Map.Entry<String, List<MaterialClassImportVO>> entry : collect.entrySet()) {
            StringBuilder msg = new StringBuilder();
            String classCode = entry.getKey();
            List<MaterialClassImportVO> importVOList = entry.getValue();
            if (importVOList.size() > 1) {
                msg.append(String.format(MessageUtils.get(SdsResultCode
                        .CLASS_CODE_REPEAT.getLocalCode()), classCode));
            }
            if (msg.length() > 0) {
                msg.append(";");
                errorList.add(msg.toString());
            }
        }
        if (CollUtil.isNotEmpty(errorList)) {
            throw new CloudmesException(ResultCode.FAILURE.getCode(), errorList.toString());
        }
        List<SdsMaterialClass> sdsMaterialClassList = CollUtil.newArrayList();
        for (MaterialClassImportVO materialClassImportVO : materialClassImportVOList) {
            SdsMaterialClass sdsMaterialClass = new SdsMaterialClass();
            Long count = baseMapper.selectCount(Wrappers.<SdsMaterialClass>lambdaQuery()
                    .eq(SdsMaterialClass::getOrgCode, orgCode)
                    .eq(SdsMaterialClass::getClassCode, materialClassImportVO.getClassCode()));
            if (count > 0) {
                throw new CloudmesException(SdsResultCode.CLASS_CODE_EXISTED_CAN_NOT_REPEAT.getCode(),
                        String.format(MessageUtils.get(SdsResultCode.CLASS_CODE_EXISTED_CAN_NOT_REPEAT.getLocalCode()),
                                materialClassImportVO.getClassCode()));
            }
            BeanUtils.copyProperties(materialClassImportVO, sdsMaterialClass);
            sdsMaterialClass.setOrgCode(orgCode);
            sdsMaterialClassList.add(sdsMaterialClass);
        }
        this.saveBatch(sdsMaterialClassList);
    }

    @Override
    public void exportMaterialClass(HttpServletResponse response, MaterialClassQueryVO queryVO) {
        List<MaterialClassExportDTO> exportDTOList = CollUtil.newArrayList();
        List<MaterialClassDTO> materialClassDTOList = baseMapper.selectMaterialClassList(queryVO);
        materialClassDTOList.forEach(materialClassDTO -> {
            MaterialClassExportDTO materialClassExportDTO = new MaterialClassExportDTO();
            BeanUtils.copyProperties(materialClassDTO, materialClassExportDTO);
            exportDTOList.add(materialClassExportDTO);
        });
        String fileName = "物料类别信息" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), MaterialClassExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getLocalCode()));
        }
    }
}
