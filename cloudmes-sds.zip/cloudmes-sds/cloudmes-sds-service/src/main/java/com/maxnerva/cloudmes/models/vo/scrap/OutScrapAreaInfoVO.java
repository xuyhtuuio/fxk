package com.maxnerva.cloudmes.models.vo.scrap;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class OutScrapAreaInfoVO {

    @ApiModelProperty("申报单号")
    private String declareNumber;
}
