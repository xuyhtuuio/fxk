package com.maxnerva.cloudmes.models.vo.plan;

import com.maxnerva.cloudmes.models.vo.PageQueryVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @ClassName PlanInfoQueryVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/8
 * @Version 1.0
 * @Since JDK 1.8
 **/
@EqualsAndHashCode(callSuper = true)
@ApiModel("年度计划查询vo")
@Data
public class PlanInfoQueryVO extends PageQueryVO {

    @ApiModelProperty("年度")
    private String planYear;

    @ApiModelProperty("废物俗称")
    private String hazardousWasteName;

    @ApiModelProperty("费用代码")
    private String costCode;
}
