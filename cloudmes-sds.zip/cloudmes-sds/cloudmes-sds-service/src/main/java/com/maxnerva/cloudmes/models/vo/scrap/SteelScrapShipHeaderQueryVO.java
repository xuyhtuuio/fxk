package com.maxnerva.cloudmes.models.vo.scrap;

import com.maxnerva.cloudmes.models.vo.PageQueryVO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class SteelScrapShipHeaderQueryVO extends PageQueryVO {

    @ApiModelProperty("申报单号")
    private String declareNumber;

    @ApiModelProperty("废料类别")
    private String sdsScrapType;

    @ApiModelProperty("车牌")
    private String licenseCarNumber;

    @ApiModelProperty(value = "单据状态", required = true)
    private String scrapAreaStatus;

    @ApiModelProperty(value = "厂商代码")
    private String mfgCode;
}
