package com.maxnerva.cloudmes.models.vo.scrap;

import com.maxnerva.cloudmes.models.vo.PageQueryVO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class SteelInventoryPlanSummaryQueryVO extends PageQueryVO {

    @ApiModelProperty("单号")
    private String inventoryPlanNo;

    @ApiModelProperty("报废小类")
    private String scrapDetailClass;

    @ApiModelProperty(value = "状态", required = true)
    private String status;
}
