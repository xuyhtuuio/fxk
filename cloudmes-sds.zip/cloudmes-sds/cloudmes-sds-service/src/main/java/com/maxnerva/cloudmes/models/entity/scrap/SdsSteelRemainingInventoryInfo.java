package com.maxnerva.cloudmes.models.entity.scrap;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 每月结余库存表
 * </p>
 *
 * @author baomidou
 * @since 2025-03-20
 */
@EqualsAndHashCode(callSuper = true)
@TableName("sds_steel_remaining_inventory_info")
@ApiModel(value = "SdsSteelRemainingInventoryInfo对象", description = "每月结余库存表")
@Data
public class SdsSteelRemainingInventoryInfo extends BaseEntity<SdsSteelRemainingInventoryInfo> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("年yyyy")
    private String year;

    @ApiModelProperty("月MM")
    private String month;

    @ApiModelProperty("报废类别")
    private String scrapDetailClass;

    @ApiModelProperty("结余库存")
    private BigDecimal remainWeight;
}
