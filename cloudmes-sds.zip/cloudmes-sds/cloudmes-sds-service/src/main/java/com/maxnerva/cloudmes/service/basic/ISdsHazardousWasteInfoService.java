package com.maxnerva.cloudmes.service.basic;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.models.dto.basic.HazardousWasteInfoDTO;
import com.maxnerva.cloudmes.models.dto.basic.WasteInfoBindDTO;
import com.maxnerva.cloudmes.models.dto.basic.WasteNameInfoDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsHazardousWasteInfo;
import com.maxnerva.cloudmes.models.vo.basic.HazardousWasteInfoQueryVO;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * <p>
 * 危废物信息表 服务类
 * </p>
 *
 * @author likun
 * @since 2025-05-06
 */
public interface ISdsHazardousWasteInfoService extends IService<SdsHazardousWasteInfo> {

    PageDataDTO<HazardousWasteInfoDTO> selectWasteInfoPage(HazardousWasteInfoQueryVO queryVO);

    List<String> selectWastNameList();

    void exportHazardousWasteInfo(HttpServletResponse response, HazardousWasteInfoQueryVO queryVO);

    List<String> selectWastNameByOrgCodeAndCostCode(String orgCode, String costCode);

    WasteInfoBindDTO selectWasteInfoByWasteCode(String orgCode, String costCode,String hazardousWasteName);

    List<WasteNameInfoDTO> selectWasteNameInfoByOrgCodeAndCostCode(String orgCode, String costCode);

    List<WasteNameInfoDTO> selectWasteNameInfo();
}
