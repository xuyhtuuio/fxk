package com.maxnerva.cloudmes.service.scrap.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.fastjson2.JSON;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.config.MinIOProperties;
import com.maxnerva.cloudmes.common.constant.BucketConstant;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.common.utils.WebContextUtil;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.enums.SteelScrapOperateType;
import com.maxnerva.cloudmes.excel.handler.AddNoHandler;
import com.maxnerva.cloudmes.mapper.basic.SdsDepartmentConfigMapper;
import com.maxnerva.cloudmes.mapper.basic.SdsSteelBucketInfoMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelScrapWeightInfoLogMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelScrapWeightInfoMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelScrapWeightRejectMapper;
import com.maxnerva.cloudmes.models.dto.excel.scrap.SteelScrapShipHeaderExportDTO;
import com.maxnerva.cloudmes.models.dto.excel.scrap.SteelScrapWeightRejectExportDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelScrapShipHeaderDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelScrapWeightRejectDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsDepartmentConfig;
import com.maxnerva.cloudmes.models.entity.basic.SdsSteelBucketInfo;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapWeightInfo;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapWeightInfoLog;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapWeightReject;
import com.maxnerva.cloudmes.models.vo.scrap.RubbishWeightRejectHandleSubmitVO;
import com.maxnerva.cloudmes.models.vo.scrap.RubbishWeightRejectQueryVO;
import com.maxnerva.cloudmes.service.scrap.ISdsSteelScrapWeightRejectService;
import com.maxnerva.cloudmes.system.utils.DictLangUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.MimeTypeUtils;

import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
public class SdsSteelScrapWeightRejectService extends ServiceImpl<SdsSteelScrapWeightRejectMapper, SdsSteelScrapWeightReject> implements ISdsSteelScrapWeightRejectService {

    @Autowired
    DictLangUtils dictLangUtils;

    @Autowired
    SdsDepartmentConfigMapper departmentConfigMapper;

    @Autowired
    SdsSteelScrapWeightInfoMapper steelScrapWeightInfoMapper;

    @Autowired
    SdsSteelScrapWeightInfoLogMapper steelScrapWeightInfoLogMapper;

    @Autowired
    SdsSteelBucketInfoMapper steelBucketInfoMapper;

    @Autowired
    private MinIOProperties minIOProperties;

    @Override
    public PageDataDTO<SteelScrapWeightRejectDTO> selectPageList(RubbishWeightRejectQueryVO vo, Boolean isPage) {
        Page page = new Page();
        if (BooleanUtil.isTrue(isPage)){
            page = PageHelper.startPage(vo.getPageIndex(), vo.getPageSize());
        }
        List<SdsSteelScrapWeightReject> list = baseMapper.selectList(Wrappers.<SdsSteelScrapWeightReject>lambdaQuery()
                .eq(StrUtil.isNotBlank(vo.getBucketNo()), SdsSteelScrapWeightReject::getBucketNo, vo.getBucketNo())
                .eq(StrUtil.isNotBlank(vo.getScrapDetailClass()), SdsSteelScrapWeightReject::getScrapDetailClass, vo.getScrapDetailClass())
                .eq(StrUtil.isNotBlank(vo.getDepartmentCode()), SdsSteelScrapWeightReject::getDepartmentCode, vo.getDepartmentCode())
                .eq(!"2".equals(vo.getStatus()), SdsSteelScrapWeightReject::getStatus, vo.getStatus())
                        .between(ObjectUtil.isNotNull(vo.getStartDateTime()), SdsSteelScrapWeightReject::getRejectDt, vo.getStartDateTime(), vo.getEndDateTime())
                .orderByAsc(SdsSteelScrapWeightReject::getId)
        );
        List<SdsDepartmentConfig> sdsDepartmentConfigList = departmentConfigMapper.selectList(Wrappers.<SdsDepartmentConfig>lambdaQuery()
                .select(SdsDepartmentConfig::getDepartmentCode, SdsDepartmentConfig::getDepartmentName)
        );
        Map<String, String> departmentConfigMap = sdsDepartmentConfigList.stream().collect(Collectors.toMap(k -> k.getDepartmentCode(), v -> v.getDepartmentName()));

        Map<String, Map<String, String>> dictMap = dictLangUtils.getByTypes(ListUtil.toList("SDS_SOLID_REJECT_STATUS", "SDS_SCRAP_SOLID", "SDS_SOLID_SCRAP_REJECT_REASON"));
        List<SteelScrapWeightRejectDTO> result = ListUtil.toList();
        list.forEach(item -> {
            SteelScrapWeightRejectDTO dto = new SteelScrapWeightRejectDTO();
            BeanUtil.copyProperties(item, dto, "imageUrlList", "rejectImageList");
            if (StrUtil.isNotBlank(item.getImageUrlList())){
                List<String> imageUrlList = JSON.parseArray(item.getImageUrlList()).toList(String.class);
                imageUrlList = imageUrlList.stream().map(link -> minIOProperties.getFileAddr(BucketConstant.CLOUD_SAAS, link)).collect(Collectors.toList());
                dto.setImageUrlList(imageUrlList);
            }
            if (StrUtil.isNotBlank(item.getRejectImageList())){
                List<String> imageUrlList = JSON.parseArray(item.getRejectImageList()).toList(String.class);
                imageUrlList = imageUrlList.stream().map(link -> minIOProperties.getFileAddr(BucketConstant.CLOUD_SAAS, link)).collect(Collectors.toList());
                dto.setRejectImageList(imageUrlList);
            }
            dto.setScrapDetailClassName(dictMap.get("SDS_SCRAP_SOLID").get(item.getScrapDetailClass()));
            dto.setStatusName(dictMap.get("SDS_SOLID_REJECT_STATUS").get(item.getStatus()));
            dto.setRejectReason(dictMap.get("SDS_SOLID_SCRAP_REJECT_REASON").get(item.getRejectReasonType()));
            dto.setDepartmentCodeName(departmentConfigMap.get(item.getDepartmentCode()));
            result.add(dto);
        });
        return new PageDataDTO(page.getTotal(), result);
    }

    @Override
    public void exportDetail(RubbishWeightRejectQueryVO vo, HttpServletResponse response) {
        PageDataDTO<SteelScrapWeightRejectDTO> pageDataDTO = selectPageList(vo, Boolean.FALSE);
        List<SteelScrapWeightRejectExportDTO> exportDTOList = ListUtil.toList();
        pageDataDTO.getList().forEach(item -> {
            SteelScrapWeightRejectExportDTO dto = new SteelScrapWeightRejectExportDTO();
            BeanUtil.copyProperties(item, dto);
            exportDTOList.add(dto);
        });

        String fileName = "废料厂拒收记录" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), SteelScrapWeightRejectExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getLocalCode()));
        }
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void handleSubmit(RubbishWeightRejectHandleSubmitVO vo) {
        SdsSteelScrapWeightReject steelScrapWeightReject = baseMapper.selectById(vo.getId());

        baseMapper.update(null, Wrappers.<SdsSteelScrapWeightReject>lambdaUpdate()
                .set(SdsSteelScrapWeightReject::getHandleDt, LocalDateTime.now())
                .set(SdsSteelScrapWeightReject::getHandleEmpNo, WebContextUtil.getCurrentStaffCode())
                .set(SdsSteelScrapWeightReject::getHandleMethod, vo.getHandleMethod())
                .set(SdsSteelScrapWeightReject::getReason, vo.getReason())
                .set(SdsSteelScrapWeightReject::getStatus, "1")
                .eq(SdsSteelScrapWeightReject::getId, vo.getId())
        );
        SdsSteelScrapWeightInfo steelScrapWeightInfo = steelScrapWeightInfoMapper.selectOne(Wrappers.<SdsSteelScrapWeightInfo>lambdaQuery()
                .eq(SdsSteelScrapWeightInfo::getOrgCode, vo.getOrgCode())
                .eq(SdsSteelScrapWeightInfo::getBucketNo, steelScrapWeightReject.getBucketNo())
                .orderByDesc(SdsSteelScrapWeightInfo::getId)
                .last("limit 1")
        );
        SdsSteelScrapWeightInfoLog steelScrapWeightInfoLog = new SdsSteelScrapWeightInfoLog();
        BeanUtil.copyProperties(steelScrapWeightInfo, steelScrapWeightInfoLog);
        steelScrapWeightInfoLog.setId(null);
        steelScrapWeightInfoLog.setOperateType(SteelScrapOperateType.RUBBISH_ERR_HANDLE.getDictCode());
        steelScrapWeightInfoLog.setOperateMessage(SteelScrapOperateType.RUBBISH_ERR_HANDLE.getDictName());
        steelScrapWeightInfoLogMapper.insert(steelScrapWeightInfoLog);
    }
}
