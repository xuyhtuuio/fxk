package com.maxnerva.cloudmes.models.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName CommonRequestVO
 * @Description 公共请求VO
 * @Author Likun
 * @Date 2022/11/7
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("公共请求VO")
@Data
public class CommonRequestVO {

    @ApiModelProperty(value = "工厂组织")
    private String orgCode;
}
