package com.maxnerva.cloudmes.models.vo.waste;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName TransferBindShipInfoQueryVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/27
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel(value = "危废转移单可绑定出库单信息查询vo")
@Data
public class TransferBindShipInfoQueryVO {

    @ApiModelProperty("单据类型")
    private String docType;

    @ApiModelProperty(value = "废物俗称")
    private String hazardousWasteName;
}
