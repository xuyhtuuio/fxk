package com.maxnerva.cloudmes.models.dto.excel.scrap;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.excel.converter.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("固废待平账记录DTO")
@Data
public class SteelInventoryPlanSummaryExportDTO {

    @ApiModelProperty("单号")
    @ExcelProperty(value = "盘点单号")
    private String inventoryPlanNo;

    @ApiModelProperty("报废小类名")
    @ExcelProperty(value = "报废类别")
    private String scrapDetailClassName;

    @ApiModelProperty("描述")
    @ExcelProperty(value = "描述")
    private String description;

    @ApiModelProperty("盘点执行人")
    @ExcelProperty(value = "盘点执行人")
    private String inventoryExecutorCode;

    @ApiModelProperty("总净重")
    @ExcelProperty(value = "总净重")
    private BigDecimal totalNetWeight;

    @ApiModelProperty("盘点净重")
    @ExcelProperty(value = "盘点净重")
    private BigDecimal inventoryNetWeight;

    @ApiModelProperty(value = "待平账量")
    @ExcelProperty(value = "待平账量")
    private BigDecimal prepareNewWeight;

    @ApiModelProperty(value = "状态0未平账，1已平账")
    @ExcelProperty(value = "状态")
    private String statusName;

    @ApiModelProperty("平账量")
    @ExcelProperty(value = "平账量")
    private BigDecimal balanceWeight;

    @ApiModelProperty("平账人")
    @ExcelProperty(value = "平账人")
    private String balanceEmpNo;

    @ApiModelProperty("平账时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "平账时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime balanceDt;

    @ApiModelProperty("平账备注")
    @ExcelProperty(value = "平账备注")
    private String balanceRemark;

    @ApiModelProperty(value = "创建人")
    @ExcelProperty(value = "创建人")
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "创建时间")
    @ExcelProperty(value = "创建时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "修改人")
    @ExcelProperty(value = "修改人")
    private String lastEditor;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "修改时间")
    @ExcelProperty(value = "修改时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime lastEditedDt;
}
