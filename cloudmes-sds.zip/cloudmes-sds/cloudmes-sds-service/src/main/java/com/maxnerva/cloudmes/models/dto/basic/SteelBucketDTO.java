package com.maxnerva.cloudmes.models.dto.basic;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @ClassName SteelBucketDTO
 * @Description TODO
 * @Author Likun
 * @Date 2024/10/28
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("托盘信息dto")
@Data
public class SteelBucketDTO {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "组织")
    private String orgCode;

    @ApiModelProperty(value = "托盘编码")
    private String bucketNo;

    @ApiModelProperty(value = "托盘重量")
    private BigDecimal bucketWeight;

    @ApiModelProperty(value = "单位")
    private String uom;

    @ApiModelProperty(value = "托盘类别")
    private String bucketType;

    @ApiModelProperty(value = "托盘类别名称")
    private String bucketTypeName;

    @ApiModelProperty(value = "承重下限")
    private BigDecimal weightLow;

    @ApiModelProperty(value = "承重上限")
    private BigDecimal weightUp;

    @ApiModelProperty(value = "是否启用")
    private String isEnable;

    @ApiModelProperty(value = "长")
    private BigDecimal length;

    @ApiModelProperty(value = "宽")
    private BigDecimal width;

    @ApiModelProperty(value = "高")
    private BigDecimal height;

    @ApiModelProperty(value = "容积")
    private BigDecimal volume;

    @ApiModelProperty(value = "报废大类")
    private String scrapClass;

    @ApiModelProperty(value = "报废小类")
    private String scrapDetailClass;

    @ApiModelProperty(value = "报废大类名称")
    private String scrapClassName;

    @ApiModelProperty(value = "报废小类名称")
    private String scrapDetailClassName;

    @ApiModelProperty(value = "创建人")
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "创建时间")
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "修改人")
    private String lastEditor;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "修改时间")
    private LocalDateTime lastEditedDt;

    @ApiModelProperty(value = "是否进废料暂存区")
    private Boolean isScrapArea;

    @ApiModelProperty(value = "报废类型")
    private String scrapType;

    @ApiModelProperty(value = "厂部代码")
    private String departmentCode;

    @ApiModelProperty(value = "报废类型名称")
    private String scrapTypeName;

    @ApiModelProperty(value = "是否进废料暂存区名称")
    private String isScrapAreaName;
}
