package com.maxnerva.cloudmes.models.dto.excel.waste;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.excel.converter.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @ClassName WasteTransferExportDTO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/28
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("危废转移单导出DTO")
@Data
public class WasteTransferExportDTO {

    @ApiModelProperty(value = "说明单号")
    @ExcelProperty(value = "单号")
    private String docNo;

    @ApiModelProperty(value = "单据类型")
    @ExcelProperty(value = "单据类型")
    private String docTypeName;

    @ApiModelProperty(value = "单据状态")
    @ExcelProperty(value = "单据状态")
    private String docStatusName;

    @ApiModelProperty(value = "车牌号")
    @ExcelProperty(value = "车牌号")
    private String carNumber;

    @ApiModelProperty(value = "移出单位")
    @ExcelProperty(value = "移出单位")
    private String moveOutDept;

    @ApiModelProperty(value = "移出单位地址")
    @ExcelProperty(value = "移出单位地址")
    private String moveOutAddress;

    @ApiModelProperty(value = "移出单位联系人")
    @ExcelProperty(value = "移出单位联系人")
    private String moveOutContact;

    @ApiModelProperty(value = "移出单位联系电话")
    @ExcelProperty(value = "移出单位联系电话")
    private String moveOutPhone;

    @ApiModelProperty(value = "移出单位紧急联系电话")
    @ExcelProperty(value = "移出单位紧急联系电话")
    private String moveOutEmergencyContact;

    @ApiModelProperty(value = "接受单位")
    @ExcelProperty(value = "接受单位")
    private String moveInDept;

    @ApiModelProperty(value = "接受单位地址")
    @ExcelProperty(value = "接受单位地址")
    private String moveInAddress;

    @ApiModelProperty(value = "接受单位许可证号")
    @ExcelProperty(value = "接受单位许可证号")
    private String moveInLicense;

    @ApiModelProperty(value = "接受单位联系人")
    @ExcelProperty(value = "接受单位联系人")
    private String moveInContact;

    @ApiModelProperty(value = "接受单位联系电话")
    @ExcelProperty(value = "接受单位联系电话")
    private String moveInPhone;

    @ApiModelProperty(value = "运输单位")
    @ExcelProperty(value = "运输单位")
    private String transportDept;

    @ApiModelProperty(value = "运输方式名称")
    @ExcelProperty(value = "运输方式名称")
    private String transportModeName;

    @ApiModelProperty(value = "运输单位联系人")
    @ExcelProperty(value = "运输单位联系人")
    private String transportContact;

    @ApiModelProperty(value = "运输单位电话")
    @ExcelProperty(value = "运输单位电话")
    private String transportPhone;

    @ApiModelProperty(value = "运输单位地址")
    @ExcelProperty(value = "运输单位地址")
    private String transportAddress;

    @ApiModelProperty(value = "运输方式")
    @ExcelProperty(value = "运输方式")
    private String transportMode;

    @ApiModelProperty(value = "空车重量")
    @ExcelProperty(value = "空车重量")
    private BigDecimal carWeight;

    @ApiModelProperty(value = "整车重量")
    @ExcelProperty(value = "整车重量")
    private BigDecimal fullCarWeight;

    @ApiModelProperty(value = "到厂时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "到厂时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime entryTime;

    @ApiModelProperty(value = "离厂时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "离厂时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime leaveTime;

    @ApiModelProperty(value = "离厂人员")
    @ExcelProperty(value = "离厂人员")
    private String leaveEmp;

    @ApiModelProperty(value = "创建人")
    @ExcelProperty(value = "创建人")
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "创建时间")
    @ExcelProperty(value = "创建时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "修改人")
    @ExcelProperty(value = "修改人")
    private String lastEditor;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "修改时间", converter = LocalDateTimeStringConverter.class)
    @ApiModelProperty(value = "修改时间")
    private LocalDateTime lastEditedDt;

}
