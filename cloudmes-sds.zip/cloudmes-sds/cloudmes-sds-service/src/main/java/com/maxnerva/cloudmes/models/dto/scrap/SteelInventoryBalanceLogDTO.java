package com.maxnerva.cloudmes.models.dto.scrap;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class SteelInventoryBalanceLogDTO {
    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("盘点单号")
    private String inventoryPlanNo;

    @ApiModelProperty("报废小类")
    private String scrapDetailClass;

    @ApiModelProperty("报废小类名")
    private String scrapDetailClassName;

    @ApiModelProperty("平账备注")
    private String balanceRemark;

    @ApiModelProperty("总净重")
    private BigDecimal totalNetWeight;

    @ApiModelProperty("盘点净重")
    private BigDecimal inventoryNetWeight;

    @ApiModelProperty("平账量")
    private BigDecimal balanceWeight;

    @ApiModelProperty("0 入库，1 出库")
    private String balanceType;

    @ApiModelProperty("平账类型名")
    private String balanceTypeName;

    @ApiModelProperty("平账人")
    private String balanceEmpNo;

    @ApiModelProperty("平账时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime balanceDt;




}
