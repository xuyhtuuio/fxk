package com.maxnerva.cloudmes.models.vo.scrap;

import com.maxnerva.cloudmes.models.vo.CommonRequestVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

@ApiModel(value = "废料厂入库手动确认VO")
@Data
public class RubbishWeightInfoConfirmVO {

    @ApiModelProperty(value = "Y 确认，N 拒收", required = true)
    private String handleConfirm;

    @ApiModelProperty(value = "托盘编码", required = true)
    private String bucketNo;

    @ApiModelProperty(value = "毛重", required = true)
    private BigDecimal grossWeight;

    @ApiModelProperty(value = "拒收/接收人", required = true)
    private String operateEmpNo;

    @ApiModelProperty(value = "拒收/接收备注", required = true)
    private String operateRemarkType;
}
