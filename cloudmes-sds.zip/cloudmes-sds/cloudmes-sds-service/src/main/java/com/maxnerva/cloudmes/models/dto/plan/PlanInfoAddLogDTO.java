package com.maxnerva.cloudmes.models.dto.plan;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @ClassName PlanInfoAddLogDTO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/12
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("年度计划说明信息dto")
@Data
public class PlanInfoAddLogDTO {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "组织")
    private String orgCode;

    @ApiModelProperty(value = "说明单号")
    private String docNo;

    @ApiModelProperty(value = "年度")
    private String planYear;

    @ApiModelProperty(value = "计划单号")
    private String planDocNo;

    @ApiModelProperty(value = "费用代码")
    private String costCode;

    @ApiModelProperty(value = "部门名称")
    private String depName;

    @ApiModelProperty(value = "增加量（KG）")
    private BigDecimal planAddWeight;

    @ApiModelProperty(value = "本年度当前计划总量（KG）")
    private BigDecimal oldPlanWeight;

    @ApiModelProperty(value = "SDS危废料号")
    private String hazardousWasteNo;

    @ApiModelProperty(value = "单据状态")
    private String docStatus;

    @ApiModelProperty(value = "废物俗称")
    private String hazardousWasteName;

    @ApiModelProperty(value = "危险废物")
    private String hazardousWaste;

    @ApiModelProperty(value = "废物形态")
    private String shape;

    @ApiModelProperty(value = "主要成分")
    private String rohs;

    @ApiModelProperty(value = "危险特性")
    private String toxicity;

    @ApiModelProperty(value = "废物类别")
    private String hazardousWasteCategory;

    @ApiModelProperty(value = "废物代码")
    private String hazardousWasteCode;

    @ApiModelProperty(value = "废物包装规格")
    private String packagingType;

    @ApiModelProperty(value = "创建人")
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "创建时间")
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "修改人")
    private String lastEditor;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "修改时间")
    private LocalDateTime lastEditedDt;

    @ApiModelProperty("单据状态名称")
    private String docStatusName;

    @ApiModelProperty(value = "增量原因")
    private String incrementReason;

    @ApiModelProperty(value = "flownet返回url")
    private String flownetUrl;

    @ApiModelProperty(value = "flownet调用结果")
    private String flownetFlag;

    @ApiModelProperty(value = "flownet返回表单id")
    private String flownetFormId;

    @ApiModelProperty(value = "flownet返回描述")
    private String flownetMsg;

    @ApiModelProperty(value = "flownet审批结果")
    private String flownetApprovalResult;

    @ApiModelProperty(value = "flownet流程id")
    private String flownetProcessId;

}
