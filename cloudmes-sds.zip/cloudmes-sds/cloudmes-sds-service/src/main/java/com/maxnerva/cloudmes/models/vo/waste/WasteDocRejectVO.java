package com.maxnerva.cloudmes.models.vo.waste;

import com.maxnerva.cloudmes.models.vo.CommonRequestVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * @ClassName WasteDocRejectVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/26
 * @Version 1.0
 * @Since JDK 1.8
 **/
@EqualsAndHashCode(callSuper = true)
@ApiModel(value = "产废拒收VO")
@Data
public class WasteDocRejectVO extends CommonRequestVO {

    @ApiModelProperty(value = "单号", required = true)
    private String docNo;

    @ApiModelProperty(value = "拒收人", required = true)
    private String operateEmpNo;

    @ApiModelProperty(value = "拒收备注", required = true)
    private String operateRemarkType;

    @ApiModelProperty(value = "文件")
    private List<MultipartFile> files;
}
