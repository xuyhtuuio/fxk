package com.maxnerva.cloudmes.controller.scrap;

import com.alibaba.fastjson.JSON;
import com.hikvision.artemis.sdk.ArtemisHttpUtil;
import com.hikvision.artemis.sdk.config.ArtemisConfig;
import com.hikvision.artemis.sdk.constant.Constants;
import com.maxnerva.cloudmes.enums.HikAreaCodeEnum;
import com.maxnerva.cloudmes.service.scrap.impl.SdsWeightPictureService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

/**
 * @ClassName HikvisionPictureCatchController
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/1/2 下午 01:55
 * @Version 1.0
 **/


@Api(tags = "海康攝像圖片捕捉")
@Slf4j
@RestController
@RequestMapping("/hikvision")
public class HikvisionPictureCatchController {

    @Resource
    SdsWeightPictureService sdsWeightPictureService;


    @ApiOperation("定时照片捕捉")
    @PostMapping("/pictureCatch")
    public void pictureCatch() {
        sdsWeightPictureService.catchHikvisionPictureJob();
    }

//    @ApiOperation("定时照片捕捉")
//    @PostMapping("/pictureCatch")
//    public void pictureCatch() {
//        sdsWeightPictureService.catchHikvisionPictureJob(HikAreaCodeEnum.LOADING_WASTE_PACKAGING_MATERIALS_AREA.getDictCode());
//    }
}
