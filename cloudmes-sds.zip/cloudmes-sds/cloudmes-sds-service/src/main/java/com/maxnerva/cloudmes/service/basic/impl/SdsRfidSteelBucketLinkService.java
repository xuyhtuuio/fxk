package com.maxnerva.cloudmes.service.basic.impl;

import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.mapper.basic.SdsRfidSteelBucketLinkMapper;
import com.maxnerva.cloudmes.mapper.basic.SdsSteelBucketInfoMapper;
import com.maxnerva.cloudmes.models.entity.basic.SdsRfidSteelBucketLink;
import com.maxnerva.cloudmes.models.entity.basic.SdsSteelBucketInfo;
import com.maxnerva.cloudmes.models.vo.basic.RfidSteelBucketLinkBindVO;
import com.maxnerva.cloudmes.models.vo.basic.RfidSteelBucketLinkQueryVO;
import com.maxnerva.cloudmes.models.vo.basic.RfidSteelBucketLinkUnBindVO;
import com.maxnerva.cloudmes.service.basic.ISdsRfidSteelBucketLinkService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class SdsRfidSteelBucketLinkService extends ServiceImpl<SdsRfidSteelBucketLinkMapper, SdsRfidSteelBucketLink> implements ISdsRfidSteelBucketLinkService {

    @Autowired
    SdsSteelBucketInfoMapper steelBucketInfoMapper;

    @Override
    public List<SdsRfidSteelBucketLink> selectList(RfidSteelBucketLinkQueryVO vo) {

        SdsSteelBucketInfo sdsSteelBucketInfo = steelBucketInfoMapper.selectOne(Wrappers.<SdsSteelBucketInfo>lambdaQuery()
                .eq(SdsSteelBucketInfo::getBucketNo, vo.getBucketNo())
                .last("limit 1")
        );
        if (ObjectUtil.isNull(sdsSteelBucketInfo)) {
            throw new CloudmesException("托盘编码不存在");
        }

        List<SdsRfidSteelBucketLink> list = baseMapper.selectList(Wrappers.<SdsRfidSteelBucketLink>lambdaQuery()
                .eq(SdsRfidSteelBucketLink::getBucketNo, vo.getBucketNo())
        );
        return list;
    }

    @Override
    public void bindRfidCard(RfidSteelBucketLinkBindVO vo) {
        SdsRfidSteelBucketLink rfidSteelBucketLink = baseMapper.selectOne(Wrappers.<SdsRfidSteelBucketLink>lambdaQuery()
                .eq(SdsRfidSteelBucketLink::getRfidNo, vo.getRfidNo())
                .last("limit 1")
        );
        if (ObjectUtil.isNotNull(rfidSteelBucketLink)) {
            throw new CloudmesException(String.format("该RFID-CARD已经绑定实际托盘%s，不能重复绑定", rfidSteelBucketLink.getBucketNo()));
        }
        SdsRfidSteelBucketLink newRfidSteelBucketLink = new SdsRfidSteelBucketLink();
        newRfidSteelBucketLink.setBucketNo(vo.getBucketNo());
        newRfidSteelBucketLink.setRfidNo(vo.getRfidNo());
        baseMapper.insert(newRfidSteelBucketLink);
    }

    @Override
    public void deleteRfidCard(RfidSteelBucketLinkUnBindVO vo) {
        baseMapper.delete( Wrappers.<SdsRfidSteelBucketLink>lambdaQuery()
                .eq(SdsRfidSteelBucketLink::getBucketNo, vo.getBucketNo())
                .in(SdsRfidSteelBucketLink::getRfidNo, vo.getRfidNoList())
        );
    }
}
