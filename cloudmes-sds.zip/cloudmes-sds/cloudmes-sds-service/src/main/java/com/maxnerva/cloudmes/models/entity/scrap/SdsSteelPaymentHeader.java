package com.maxnerva.cloudmes.models.entity.scrap;

import com.baomidou.mybatisplus.annotation.TableName;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2025-01-08
 */
@TableName("sds_steel_payment_header")
@ApiModel(value = "SdsSteelPaymentOrder对象", description = "")
@Data
public class SdsSteelPaymentHeader extends BaseEntity<SdsSteelPaymentHeader> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("缴款单号")
    private String docNo;

    @ApiModelProperty("厂商")
    private String manFacturer;

    @ApiModelProperty("合约预付款")
    private BigDecimal prePayment;

    @ApiModelProperty("本期销售款")
    private BigDecimal sales;

    @ApiModelProperty("缴款截止日期")
    private LocalDate endDate;

    @ApiModelProperty("收款公司")
    private String collectionCompany;

    @ApiModelProperty("开始日期")
    private LocalDate startDate;

    @ApiModelProperty("结束日期")
    private LocalDate finishDate;

    @ApiModelProperty("开户银行")
    private String bank;

    @ApiModelProperty("开户账号")
    private String bankAccount;

    @ApiModelProperty("缴款单备注")
    private String remark;

    @ApiModelProperty(value = "截止日期文本")
    private String endDateTxt;

    @ApiModelProperty(value = "本期销售款文本")
    private String salesTxt;

    @ApiModelProperty(value = "开始日期文本")
    private String startDateTxt;

    @ApiModelProperty(value = "结束日期文本")
    private String finishDateTxt;

    @ApiModelProperty(value = "厂商代码")
    private String mfgCode;

    @ApiModelProperty(value = "文件列表")
    private String fileList;

    @ApiModelProperty(value = "是否发送邮件")
    private String isSendMail;
}
