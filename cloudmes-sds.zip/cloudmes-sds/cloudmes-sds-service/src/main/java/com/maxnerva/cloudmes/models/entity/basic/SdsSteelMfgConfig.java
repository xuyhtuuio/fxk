package com.maxnerva.cloudmes.models.entity.basic;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 固废厂商配置表
 * </p>
 *
 * @author baomidou
 * @since 2025-01-07
 */
@TableName("sds_steel_mfg_config")
@ApiModel(value = "SdsSteelMfgConfig对象", description = "固废厂商配置表")
@Data
public class SdsSteelMfgConfig extends BaseEntity<SdsSteelMfgConfig> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("厂商")
    private String manFacturer;

    @ApiModelProperty("厂商代码")
    private String mfgCode;

    @ApiModelProperty("合约预付款")
    private BigDecimal prePayment;

    @ApiModelProperty("收款公司")
    private String collectionCompany;

    @ApiModelProperty("开户银行")
    private String bank;

    @ApiModelProperty("开户账号")
    private String bankAccount;

    @ApiModelProperty("缴款单备注")
    private String paymentOrderRemark;

    @ApiModelProperty("缴款单日期模板")
    private String paymentOrderDateTemplate;

    @ApiModelProperty("通知经管本期销售额范围")
    private BigDecimal notifyManagementRange;
}
