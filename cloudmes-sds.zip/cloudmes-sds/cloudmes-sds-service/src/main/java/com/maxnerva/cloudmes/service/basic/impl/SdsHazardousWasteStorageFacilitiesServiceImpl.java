package com.maxnerva.cloudmes.service.basic.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.mapper.basic.SdsHazardousWasteStorageFacilitiesMapper;
import com.maxnerva.cloudmes.models.entity.basic.SdsHazardousWasteStorageFacilities;
import com.maxnerva.cloudmes.service.basic.ISdsHazardousWasteStorageFacilitiesService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 危废贮存设施表 服务实现类
 * </p>
 *
 * @author likun
 * @since 2025-05-14
 */
@Service
public class SdsHazardousWasteStorageFacilitiesServiceImpl extends ServiceImpl<SdsHazardousWasteStorageFacilitiesMapper, SdsHazardousWasteStorageFacilities> implements ISdsHazardousWasteStorageFacilitiesService {

    @Override
    public List<String> selectFacilitiesNameList() {
        return baseMapper.selectFacilitiesNameList();
    }
}
