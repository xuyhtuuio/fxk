package com.maxnerva.cloudmes.controller.basic;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.entity.basic.SdsSteelMfgConfig;
import com.maxnerva.cloudmes.service.basic.ISdsSteelMfgConfigService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Api(tags = "固废厂商配置")
@Slf4j
@RestController
@RequestMapping("/steelMfgConfig")
public class SteelMfgConfigController {

    @Autowired
    ISdsSteelMfgConfigService steelMfgConfigService;

    @ApiOperation("厂商信息查询")
    @GetMapping("/list")
    R<List<SdsSteelMfgConfig>> selectConfigList(){
        return R.ok(steelMfgConfigService.selectConfigList());
    }

}
