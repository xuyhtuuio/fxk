package com.maxnerva.cloudmes.service.waste;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.models.dto.waste.TransferBindShipDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteDocShipInfoDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteShipInfo;
import com.maxnerva.cloudmes.models.vo.waste.TransferBindShipInfoQueryVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteDocShipInfoQueryVO;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * <p>
 * 出库单 服务类
 * </p>
 *
 * @author likun
 * @since 2025-05-16
 */
public interface ISdsHazardousWasteShipInfoService extends IService<SdsHazardousWasteShipInfo> {

    PageDataDTO<WasteDocShipInfoDTO> selectShipInfoPage(WasteDocShipInfoQueryVO queryVO);

    List<TransferBindShipDTO> selectTransferBindShipList(TransferBindShipInfoQueryVO queryVO);

    void exportDocShip(HttpServletResponse response, WasteDocShipInfoQueryVO queryVO);
}
