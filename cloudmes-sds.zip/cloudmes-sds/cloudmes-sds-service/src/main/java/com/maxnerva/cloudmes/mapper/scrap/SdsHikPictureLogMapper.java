package com.maxnerva.cloudmes.mapper.scrap;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.entity.scrap.SdsHikPictureLog;

/**
 * @ClassName SdsHikPictureLogMapper.xml
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/1/4 上午 10:46
 * @Version 1.0
 **/
public interface SdsHikPictureLogMapper extends BaseMapper<SdsHikPictureLog> {
}
