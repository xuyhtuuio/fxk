package com.maxnerva.cloudmes.models.entity.scrap;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 固废称重RFID放误出LOG
 * </p>
 *
 * @author baomidou
 * @since 2024-12-30
 */
@TableName("sds_rfid_steel_issue_log")
@ApiModel(value = "SdsRfidSteelIssueLog对象", description = "固废称重RFID放误出LOG")
@Data
public class SdsRfidSteelIssueLog extends BaseEntity<SdsRfidSteelIssueLog> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("托盘编码")
    private String bucketNo;

    private String positionName;

    @ApiModelProperty("异常类型")
    private String issueType;

    @ApiModelProperty("异常描述")
    private String issueMessage;

    @ApiModelProperty("是否处理")
    private String handleFlag;

    @ApiModelProperty("处理人")
    private String handleEmpNo;

    @ApiModelProperty("处理时间")
    private LocalDateTime handleDt;
}
