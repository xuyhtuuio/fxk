package com.maxnerva.cloudmes.models.dto.basic;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDate;

@Data
public class CalcSteelPaymentOrderDeadlineDTO {


    @ApiModelProperty(value = "截止日期")
    private LocalDate endDate;

    @ApiModelProperty(value = "截止日期文本")
    private String endDateTxt;

}
