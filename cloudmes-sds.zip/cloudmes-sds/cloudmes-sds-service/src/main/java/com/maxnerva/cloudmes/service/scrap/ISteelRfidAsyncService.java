package com.maxnerva.cloudmes.service.scrap;


public interface ISteelRfidAsyncService {

    // 防误出异步执行
    public void dealWithRFID(String key);
}
