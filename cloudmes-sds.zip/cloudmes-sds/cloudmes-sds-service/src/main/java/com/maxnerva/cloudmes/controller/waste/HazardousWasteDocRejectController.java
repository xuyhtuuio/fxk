package com.maxnerva.cloudmes.controller.waste;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.waste.WasteInStoreRejectDTO;
import com.maxnerva.cloudmes.models.vo.waste.InStoreRejectWeightSubmitVO;
import com.maxnerva.cloudmes.models.vo.waste.InStoreWeightRejectHandleSubmitVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteDocInfoUploadImageVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteInStoreRejectQueryVO;
import com.maxnerva.cloudmes.service.waste.ISdsHazardousWasteRejectService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @ClassName HazardousWasteDocRejectController
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/19
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "入库拒收管理")
@Slf4j
@RestController
@RequestMapping("/hazardousWasteDocReject")
public class HazardousWasteDocRejectController {

    @Resource
    private ISdsHazardousWasteRejectService sdsHazardousWasteRejectService;

    @ApiOperation("查询入库拒收信息")
    @PostMapping("/inStoreRejectList")
    public R<PageDataDTO<WasteInStoreRejectDTO>> selectWasteInStoreRejectPage(@RequestBody WasteInStoreRejectQueryVO queryVO) {
        return R.ok(sdsHazardousWasteRejectService.selectWasteInStoreRejectPage(queryVO));
    }

    @ApiOperation("上传图片")
    @PostMapping("/uploadImage")
    public R<Void> uploadImage(WasteDocInfoUploadImageVO uploadImageVO) {
        sdsHazardousWasteRejectService.uploadImage(uploadImageVO);
        return R.ok();
    }

    @ApiOperation("查询图片列表")
    @GetMapping("/imageList")
    public R<List<String>> selectImageList(@RequestParam("id") Integer id) {
        return R.ok(sdsHazardousWasteRejectService.selectImageList(id));
    }

    @ApiOperation("处理提交")
    @PostMapping("/handleSubmit")
    public R<Void> handleSubmit(@RequestBody InStoreWeightRejectHandleSubmitVO submitVO) {
        sdsHazardousWasteRejectService.handleSubmit(submitVO);
        return R.ok();
    }

    @ApiOperation("拒收提交")
    @PostMapping("/rejectWeightInfo")
    public R<Void> rejectWeightInfo(@RequestBody InStoreRejectWeightSubmitVO submitVO) {
        sdsHazardousWasteRejectService.rejectWeightInfo(submitVO);
        return R.ok();
    }

    @ApiOperation("查询产废图片列表")
    @GetMapping("/wasteImageList")
    public R<List<String>> selectWasteImageList(@RequestParam("id") Integer id) {
        return R.ok(sdsHazardousWasteRejectService.selectWasteImageList(id));
    }

    @ApiOperation("导出")
    @PostMapping("/export")
    public R<Void> exportHazardousDocReject(HttpServletResponse response,
                                          @RequestBody WasteInStoreRejectQueryVO queryVO) {
        sdsHazardousWasteRejectService.exportDocRejectInfo(response, queryVO);
        return R.ok();
    }
}
