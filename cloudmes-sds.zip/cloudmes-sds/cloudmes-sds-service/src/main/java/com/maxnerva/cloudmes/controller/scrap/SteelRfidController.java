package com.maxnerva.cloudmes.controller.scrap;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.scrap.RfidSteelIssueLogDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelRfidStatusDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsRfidSteelBucketLink;
import com.maxnerva.cloudmes.models.entity.scrap.SdsRfidSteelConfig;
import com.maxnerva.cloudmes.models.vo.basic.RfidSteelBucketLinkBindVO;
import com.maxnerva.cloudmes.models.vo.basic.RfidSteelBucketLinkQueryVO;
import com.maxnerva.cloudmes.models.vo.basic.RfidSteelBucketLinkUnBindVO;
import com.maxnerva.cloudmes.models.vo.scrap.HandleSteelIssueVO;
import com.maxnerva.cloudmes.models.vo.scrap.RfidSteelIssueLogQueryVO;
import com.maxnerva.cloudmes.service.basic.ISdsRfidSteelBucketLinkService;
import com.maxnerva.cloudmes.service.scrap.ISteelRfidService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(tags = "固废RFID管理")
@Slf4j
@RestController
@RequestMapping("/steelRfid")
public class SteelRfidController {

    @Autowired
    ISteelRfidService steelRfidService;

    @Autowired
    ISdsRfidSteelBucketLinkService rfidSteelBucketLinkService;

    @ApiOperation("固废误出记录查询")
    @GetMapping("/getSteelIssuePageList")
    R<PageDataDTO<RfidSteelIssueLogDTO>> getSteelIssuePageList(RfidSteelIssueLogQueryVO vo){
        return R.ok(steelRfidService.getSteelIssuePageList(vo, Boolean.TRUE));
    }

    @ApiOperation("处理误出记录")
    @PostMapping("/handleSteelIssue")
    R handleSteelIssue(@RequestBody HandleSteelIssueVO vo) {
        steelRfidService.handleSteelIssue(vo);
        return R.ok();
    }

    @ApiOperation("查询RFID状态")
    @GetMapping("/getRfidStatus")
    R<List<SteelRfidStatusDTO>> getRfidStatus() {
        return R.ok(steelRfidService.getRfidStatus());
    }

    @ApiOperation("获取RFID配置列表")
    @GetMapping("/getAllRfidConfig")
    R<List<SdsRfidSteelConfig>> getAllRfidConfig() {
        return R.ok(steelRfidService.getAllRfidConfig());
    }

    @ApiOperation("查询RFID-CARD与实际托盘关系")
    @GetMapping("/getRfidCardLink")
    R<List<SdsRfidSteelBucketLink>> getRfidCardLink(RfidSteelBucketLinkQueryVO vo) {
        return R.ok(rfidSteelBucketLinkService.selectList(vo));
    }

    @ApiOperation("绑定RFID-CARD")
    @PostMapping("/bindRfidCard")
    R bindRfidCard(@RequestBody RfidSteelBucketLinkBindVO vo) {
        rfidSteelBucketLinkService.bindRfidCard(vo);
        return R.ok();
    }

    @ApiOperation("解除绑定RFID-CARD")
    @PostMapping("/deleteRfidCard")
    R deleteRfidCard(@RequestBody RfidSteelBucketLinkUnBindVO vo) {
        rfidSteelBucketLinkService.deleteRfidCard(vo);
        return R.ok();
    }
}
