package com.maxnerva.cloudmes.models.vo.waste;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.models.vo.PageQueryVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @ClassName WasteDocShipInfoQueryVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/21
 * @Version 1.0
 * @Since JDK 1.8
 **/
@EqualsAndHashCode(callSuper = true)
@ApiModel("危废出库单信息查询vo")
@Data
public class WasteDocShipInfoQueryVO extends PageQueryVO {

    @ApiModelProperty(value = "废物俗称")
    private String hazardousWasteName;

    @ApiModelProperty(value = "费用代码")
    private String costCode;

    @ApiModelProperty(value = "单据状态")
    private String docStatus;

    @ApiModelProperty("部门名称")
    private String depName;

    @ApiModelProperty("单号")
    private String docNo;

    @ApiModelProperty("开始时间")
    @JsonFormat(pattern="yyyy-MM-dd")
    private String startDate;

    @ApiModelProperty("结束时间")
    @JsonFormat(pattern="yyyy-MM-dd")
    private String endDate;

    @ApiModelProperty(value = "单据类型")
    private String docType;
}
