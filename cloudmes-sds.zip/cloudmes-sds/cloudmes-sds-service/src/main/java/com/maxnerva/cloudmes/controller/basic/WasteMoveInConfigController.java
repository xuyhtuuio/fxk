package com.maxnerva.cloudmes.controller.basic;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.waste.WasteMoveInConfigDTO;
import com.maxnerva.cloudmes.service.waste.ISdsHazardousMoveInConfigService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName WasteMoveInConfigController
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/28
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "危废接受单位配置管理")
@Slf4j
@RestController
@RequestMapping("/wasteMoveInConfig")
public class WasteMoveInConfigController {

    @Resource
    private ISdsHazardousMoveInConfigService inConfigService;

    @ApiOperation("查询危废接受单位配置列表")
    @GetMapping("/list")
    public R<List<WasteMoveInConfigDTO>> selectMoveInConfigList(){
        return R.ok(inConfigService.selectMoveInConfigList());
    }
}
