package com.maxnerva.cloudmes.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.dto.basic.SolidTypeConfigDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsScrapSolidTypeConfig;

/**
 * <p>SdsScrapSolidTypeConfigMapper.xml
 * 固废分类配置表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2024-12-11
 */
public interface SdsScrapSolidTypeConfigMapper extends BaseMapper<SdsScrapSolidTypeConfig> {

    SolidTypeConfigDTO selectSolidTypeByDetailClass(String scrapDetailClass);
}
