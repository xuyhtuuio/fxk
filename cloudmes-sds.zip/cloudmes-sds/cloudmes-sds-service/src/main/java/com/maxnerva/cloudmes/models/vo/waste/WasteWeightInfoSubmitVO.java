package com.maxnerva.cloudmes.models.vo.waste;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @ClassName WasteWeightInfoSubmitVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/14
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel(value = "产废称重提交VO")
@Data
public class WasteWeightInfoSubmitVO {

    @ApiModelProperty(value = "单据号",required = true)
    private String docNo;

    @ApiModelProperty(value = "毛重", required = true)
    private BigDecimal grossWeight;
}
