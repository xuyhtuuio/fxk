package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName WasteDocInfoStatusEnum
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/14
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum WasteDocInfoStatusEnum {


    CREATE("CREATE", "新建"),
    SIGNED("SIGNED", "已送签"),
    AUDITED("AUDITED", "已签核"),
    APPLIED_FOR_STORAGE("APPLIED_FOR_STORAGE", "已申请入库"),
    IN_STORAGE("IN_STORAGE", "已入库/已申请立产立清"),
    CREATED_SHIP_DOC("CREATED_SHIP_DOC", "已生成出库单");


    private String dictCode;

    private String dictName;

    WasteDocInfoStatusEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (WasteDocInfoStatusEnum wasteDocInfoStatusEnum : values()) {
            if (wasteDocInfoStatusEnum.getDictCode().equals(dictCode)) {
                return wasteDocInfoStatusEnum.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

    /**
     * 提前判断，用于解决
     * Case中出现的Constant expression required
     *
     * @param dictCode 值
     * @return wasteDocInfoStatusEnum
     */
    public static WasteDocInfoStatusEnum getByValue(String dictCode) {
        for (WasteDocInfoStatusEnum wasteDocInfoStatusEnum : values()) {
            if (wasteDocInfoStatusEnum.getDictCode().equals(dictCode)) {
                return wasteDocInfoStatusEnum;
            }
        }
        return null;
    }
}
