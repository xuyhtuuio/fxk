package com.maxnerva.cloudmes.models.entity.basic;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * RFID 钢桶编码对应关系
 * </p>
 *
 * @author baomidou
 * @since 2024-12-11
 */
@TableName("sds_rfid_steel_bucket_link")
@ApiModel(value = "SdsRfidSteelBucketLink对象", description = "RFID 钢桶编码对应关系")
@Data
public class SdsRfidSteelBucketLink extends BaseEntity<SdsRfidSteelBucketLink> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("BU")
    private Integer id;

    @ApiModelProperty("RFID编码")
    private String rfidNo;

    @ApiModelProperty("钢桶编码")
    private String bucketNo;
}
