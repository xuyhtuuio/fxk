package com.maxnerva.cloudmes.models.entity;

import lombok.Data;

@Data
public class BaseSearchField {
	private String name;
	private String searchType;
	private String val;
	private String val1;
}
