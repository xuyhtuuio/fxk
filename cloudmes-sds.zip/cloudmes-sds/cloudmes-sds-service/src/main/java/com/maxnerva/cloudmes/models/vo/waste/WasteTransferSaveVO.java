package com.maxnerva.cloudmes.models.vo.waste;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @ClassName WasteTransferSaveVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/27
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("危废转移单新增vo")
@Data
public class WasteTransferSaveVO {

    @ApiModelProperty("单头新增信息")
    private WasteTransferHeaderSaveVO headerVo;

    @ApiModelProperty("明细新增信息")
    private List<WasteTransferDetailSaveVO> detailList;
}
