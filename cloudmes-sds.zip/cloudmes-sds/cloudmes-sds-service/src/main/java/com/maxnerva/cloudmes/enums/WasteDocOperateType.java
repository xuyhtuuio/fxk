package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName WasteDocOperateType
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/14
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum WasteDocOperateType {

    WASTE_PRODUCT_WEIGH("WASTE_PRODUCT_WEIGH","产废称重"),
    WASTE_IN_STORE_WEIGH("WASTE_IN_STORE_WEIGH","产废入库称重"),
    WASTE_PRODUCT_PRINT("WASTE_PRODUCT_PRINT","产废条码列印"),
    WASTE_PRODUCT_UPLOAD_IMAGE("WASTE_PRODUCT_UPLOAD_IMAGE","产废上传图片"),
    WASTE_IN_STORE_WEIGHT("WASTE_IN_STORE_WEIGHT","入库称重"),
    IN_STORE_ERR_ACCEPT("IN_STORE_ERR_ACCEPT","入库接收确认"),
    IN_STORE_ERR_REJECT("IN_STORE_ERR_REJECT","危废入库拒收"),
    IN_STORE_ERR_REJECT_HANDLE("IN_STORE_ERR_REJECT_HANDLE","危废入库拒收处理"),
    WASTE_DOC_SIGN("WASTE_SIGN","产废单送签"),
    WASTE_DOC_AUDIT("WASTE_DOC_AUDIT","产废单审核"),
    WASTE_DOC_CANCEL("WASTE_DOC_CANCEL","产废单作废"),
    APPLY_SHIP("APPLY_SHIP","申请出库"),
    APPLY_IN_STORE("APPLY_IN_STORE","申请入库");


    private String dictCode;

    private String dictName;

    WasteDocOperateType(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (WasteDocOperateType wasteDocOperateType : values()) {
            if (wasteDocOperateType.getDictCode().equals(dictCode)) {
                return wasteDocOperateType.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

    /**
     * 提前判断，用于解决
     * Case中出现的Constant expression required
     *
     * @param dictCode 值
     * @return wasteDocOperateType
     */
    public static WasteDocOperateType getByValue(String dictCode) {
        for (WasteDocOperateType wasteDocOperateType : values()) {
            if (wasteDocOperateType.getDictCode().equals(dictCode)) {
                return wasteDocOperateType;
            }
        }
        return null;
    }
}
