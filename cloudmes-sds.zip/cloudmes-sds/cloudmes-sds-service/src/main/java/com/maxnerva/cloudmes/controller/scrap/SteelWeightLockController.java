package com.maxnerva.cloudmes.controller.scrap;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.scrap.SteelScrapWeightInfoDTO;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapWeightInfo;
import com.maxnerva.cloudmes.models.entity.scrap.SdsWeightLockConfig;
import com.maxnerva.cloudmes.models.vo.scrap.SdsWeightLockConfigVO;
import com.maxnerva.cloudmes.models.vo.scrap.SteelScrapWeightInfoQueryVO;
import com.maxnerva.cloudmes.models.vo.scrap.SteelScrapWeightSubmitVO;
import com.maxnerva.cloudmes.service.scrap.impl.SdsWeightLockConfigService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;

/**
 * @ClassName SteelWeightLockController
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/2/14 上午 09:26
 * @Version 1.0
 **/


@Api(tags = "称重锁定")
@Slf4j
@RestController
@RequestMapping("/weightLock")
public class SteelWeightLockController {

    @Autowired
    private SdsWeightLockConfigService sdsWeightLockConfigService;

    @ApiOperation("锁定查询")
    @GetMapping("/getWeightLockList")
    R<SdsWeightLockConfig> getWeightLockList(){
        return R.ok(sdsWeightLockConfigService.getSdsWeightLock());
    }

    @ApiOperation("编辑称重锁定")
    @PostMapping("/editWeightLock")
    R editLock(@RequestBody SdsWeightLockConfigVO vo){
        sdsWeightLockConfigService.editSdsWeightLockConfig(vo);
        return R.ok();
    }

}
