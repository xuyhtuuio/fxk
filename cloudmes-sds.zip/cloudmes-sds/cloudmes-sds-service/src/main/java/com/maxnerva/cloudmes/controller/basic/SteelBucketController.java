package com.maxnerva.cloudmes.controller.basic;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.basic.BucketNoPrintDTO;
import com.maxnerva.cloudmes.models.dto.basic.DepartmentConfigDTO;
import com.maxnerva.cloudmes.models.dto.basic.SolidTypeConfigDTO;
import com.maxnerva.cloudmes.models.dto.basic.SteelBucketDTO;
import com.maxnerva.cloudmes.models.vo.basic.BucketNoPrintVO;
import com.maxnerva.cloudmes.models.vo.basic.SteelBucketQueryVO;
import com.maxnerva.cloudmes.models.vo.basic.SteelBucketSaveOrUpdateVO;
import com.maxnerva.cloudmes.models.vo.excel.basic.SteelBucketExcelImportVO;
import com.maxnerva.cloudmes.service.basic.ISdsDepartmentConfigService;
import com.maxnerva.cloudmes.service.basic.ISdsScrapSolidTypeConfigService;
import com.maxnerva.cloudmes.service.basic.ISdsSteelBucketInfoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.List;

/**
 * @ClassName SteelBucketInfoController
 * @Description TODO
 * @Author Likun
 * @Date 2024/10/28
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "托盘信息管理")
@Slf4j
@RestController
@RequestMapping("/steelBucket")
public class SteelBucketController {

    @Resource
    private ISdsSteelBucketInfoService steelBucketInfoService;

    @Resource
    private ISdsScrapSolidTypeConfigService scrapSolidTypeConfigService;

    @Resource
    private ISdsDepartmentConfigService departmentConfigService;

    @ApiOperation("查询托盘信息")
    @PostMapping("/list")
    public R<PageDataDTO<SteelBucketDTO>> selectSteelBucketInfoPage(@RequestBody SteelBucketQueryVO queryVO) {
        return R.ok(steelBucketInfoService.selectSteelBucketInfoPage(queryVO));
    }

    @ApiOperation("新增托盘信息")
    @PostMapping("/save")
    public R<Void> saveSteelBucket(@RequestBody SteelBucketSaveOrUpdateVO saveOrUpdateVO) {
        steelBucketInfoService.saveSteelBucket(saveOrUpdateVO);
        return R.ok();
    }

    @ApiOperation("修改托盘信息")
    @PostMapping("/update")
    public R<Void> updateSteelBucket(@RequestBody SteelBucketSaveOrUpdateVO saveOrUpdateVO) {
        steelBucketInfoService.updateSteelBucket(saveOrUpdateVO);
        return R.ok();
    }

    @ApiOperation("删除")
    @DeleteMapping("/del/{id}")
    public R<Void> deleteSteelBucket(@PathVariable("id") Integer id) {
        steelBucketInfoService.deleteSteelBucket(id);
        return R.ok();
    }

    @ApiOperation("导出")
    @PostMapping("/export")
    public R<Void> exportSteelBucket(HttpServletResponse response,
                                     @RequestBody SteelBucketQueryVO queryVO) {
        steelBucketInfoService.exportSteelBucket(response, queryVO);
        return R.ok();
    }

    @ApiOperation("导入")
    @PostMapping("/import")
    public R<Void> importSteelBucket(SteelBucketExcelImportVO steelBucketExcelImportVO) {
        steelBucketInfoService.importSteelBucket(steelBucketExcelImportVO);
        return R.ok();
    }

    @ApiOperation("列印托盘信息")
    @PostMapping("/printBucketNoInfo")
    public R<BucketNoPrintDTO> printBucketNoInfo(@Valid @RequestBody BucketNoPrintVO bucketNoPrintVO){
        return R.ok(steelBucketInfoService.printBucketNoInfo(bucketNoPrintVO));
    }

    @ApiOperation("根据报废小类查询固废配置详情")
    @GetMapping("/solidConfigDetail")
    public R<SolidTypeConfigDTO> selectSolidTypeByDetailClass(
            @RequestParam("scrapDetailClass") String scrapDetailClass){
        return R.ok(scrapSolidTypeConfigService.selectSolidTypeByDetailClass(scrapDetailClass));
    }

    @ApiOperation("查询厂部配置列表")
    @GetMapping("/departmentConfigList")
    public R<List<DepartmentConfigDTO>> selectConfigList(@RequestParam("orgCode") String orgCode){
        return R.ok(departmentConfigService.selectConfigList(orgCode));
    }

    @ApiOperation("查询厂部配置列表（无BU）")
    @GetMapping("/departmentConfigListNoBu")
    public R<List<DepartmentConfigDTO>> selectConfigListNoBu(){
        return R.ok(departmentConfigService.selectConfigListNoBu());
    }
}
