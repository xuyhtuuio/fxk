package com.maxnerva.cloudmes.models.vo.waste;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * @ClassName TransferDetailUploadImageVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/27
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("危废单明细图片上传vo")
@Data
public class TransferDetailUploadImageVO {

    @ApiModelProperty(value = "文件", required = true)
    private List<MultipartFile> files;

    @ApiModelProperty(value = "单据信息主键id", required = true)
    private Integer id;
}
