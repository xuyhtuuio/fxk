package com.maxnerva.cloudmes.models.dto.plan;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @ClassName PlanInfoDTO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/8
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("年度计划信息dto")
@Data
public class PlanInfoDTO {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "组织")
    private String orgCode;

    @ApiModelProperty(value = "计划单号")
    @JsonProperty(value = "planDocNo")
    private String docNo;

    @ApiModelProperty(value = "年度")
    private String planYear;

    @ApiModelProperty(value = "费用代码")
    private String costCode;

    @ApiModelProperty(value = "部门名称")
    private String depName;

    @ApiModelProperty(value = "本年度原始计划量（KG）")
    private BigDecimal originalWeight;

    @ApiModelProperty(value = "本年度当前计划总量（KG）")
    private BigDecimal planWeight;

    @ApiModelProperty(value = "本年度已用计划量（KG）")
    private BigDecimal usedWeight;

    @ApiModelProperty(value = "SDS危废料号")
    private String hazardousWasteNo;

    @ApiModelProperty(value = "单据状态")
    private String docStatus;

    @ApiModelProperty(value = "废物俗称")
    private String hazardousWasteName;

    @ApiModelProperty(value = "危险废物")
    private String hazardousWaste;

    @ApiModelProperty(value = "废物形态")
    private String shape;

    @ApiModelProperty(value = "主要成分")
    private String rohs;

    @ApiModelProperty(value = "危险特性")
    private String toxicity;

    @ApiModelProperty(value = "废物类别")
    private String hazardousWasteCategory;

    @ApiModelProperty(value = "废物代码")
    private String hazardousWasteCode;

    @ApiModelProperty(value = "废物包装规格")
    private String packagingType;

    @ApiModelProperty(value = "创建人")
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "创建时间")
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "修改人")
    private String lastEditor;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "修改时间")
    private LocalDateTime lastEditedDt;

    @ApiModelProperty("单据状态名称")
    private String docStatusName;
}
