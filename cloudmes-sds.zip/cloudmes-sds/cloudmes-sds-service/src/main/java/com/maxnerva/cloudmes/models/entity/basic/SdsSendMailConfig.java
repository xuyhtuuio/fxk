package com.maxnerva.cloudmes.models.entity.basic;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 邮件配置表
 * </p>
 *
 * @author baomidou
 * @since 2025-01-06
 */
@TableName("sds_send_mail_config")
@ApiModel(value = "SdsSendMailConfig对象", description = "邮件配置表")
@Data
public class SdsSendMailConfig extends BaseEntity<SdsSendMailConfig> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键id")
    private Integer id;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("厂部")
    private String departmentCode;

    @ApiModelProperty("用户名")
    private String userId;

    @ApiModelProperty("密码")
    private String passWord;

    @ApiModelProperty("发送邮件类型,参考字典值")
    private String sendType;

    @ApiModelProperty("发件人邮箱")
    private String fromAddress;

    @ApiModelProperty("收件人邮箱")
    private String toAddress;

    @ApiModelProperty("抄送邮箱")
    private String ccAddress;

    @ApiModelProperty("主旨")
    private String mailTitle;

    @ApiModelProperty("内容")
    private String mailContent;

    @ApiModelProperty("邮件参数")
    private String mailRel;

    @ApiModelProperty("备注")
    private String remark;
}
