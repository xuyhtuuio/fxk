package com.maxnerva.cloudmes.service.scrap.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.fastjson2.JSON;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.config.MinIOProperties;
import com.maxnerva.cloudmes.common.constant.BucketConstant;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.excel.handler.AddNoHandler;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelScrapWeightInfoLogMapper;
import com.maxnerva.cloudmes.models.dto.excel.scrap.SteelScrapWeightInfoExportDTO;
import com.maxnerva.cloudmes.models.dto.excel.scrap.SteelScrapWeightInfoLogExportDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelScrapWeightInfoDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelScrapWeightInfoLogDTO;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapWeightInfoLog;
import com.maxnerva.cloudmes.models.vo.scrap.SteelScrapWeightLogQueryVO;
import com.maxnerva.cloudmes.service.scrap.ISdsSteelScrapWeightInfoLogService;
import com.maxnerva.cloudmes.system.utils.DictLangUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;

import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
public class SdsSteelScrapWeightInfoLogService extends ServiceImpl<SdsSteelScrapWeightInfoLogMapper, SdsSteelScrapWeightInfoLog> implements ISdsSteelScrapWeightInfoLogService {

    @Autowired
    private MinIOProperties minIOProperties;

    @Autowired
    private DictLangUtils dictLangUtils;

    @Override
    public PageDataDTO<SteelScrapWeightInfoLogDTO> selectPageList(SteelScrapWeightLogQueryVO vo, Boolean isPage) {
        Page page = new Page();
        if (BooleanUtil.isTrue(isPage)){
            page = PageHelper.startPage(vo.getPageIndex(), vo.getPageSize());
        }
        List<SdsSteelScrapWeightInfoLog> list = baseMapper.selectList(Wrappers.<SdsSteelScrapWeightInfoLog>lambdaQuery()
                .eq(SdsSteelScrapWeightInfoLog::getBucketNo, vo.getBucketNo())
                .orderByAsc(SdsSteelScrapWeightInfoLog::getId)
        );

        Map<String, Map<String, String>> dictMap = dictLangUtils.getByTypes(ListUtil.toList("SDS_ACCEPT_STATUS", "SDS_WEIGHT_STATUS", "SDS_SCRAP_SOLID", "SDS_SOLID_OPERATE_TYPE"));
        List<SteelScrapWeightInfoLogDTO> result = ListUtil.toList();
        list.forEach(item -> {
            SteelScrapWeightInfoLogDTO dto = new SteelScrapWeightInfoLogDTO();
            BeanUtil.copyProperties(item, dto, "imageUrlList");
            if (StrUtil.isNotBlank(item.getImageUrlList())){
                List<String> imageUrlList = JSON.parseArray(item.getImageUrlList()).toList(String.class);
                imageUrlList = imageUrlList.stream().map(link -> minIOProperties.getFileAddr(BucketConstant.CLOUD_SAAS, link)).collect(Collectors.toList());
                dto.setImageUrlList(imageUrlList);
            }
            dto.setWeighFlagName(dictMap.get("SDS_WEIGHT_STATUS").get(dto.getWeighFlag()));
            dto.setAcceptFlagName(dictMap.get("SDS_ACCEPT_STATUS").get(dto.getAcceptFlag()));
            dto.setRubbishWeighFlagName(dictMap.get("SDS_WEIGHT_STATUS").get(dto.getRubbishWeighFlag()));
            dto.setScrapDetailClassName(dictMap.get("SDS_SCRAP_SOLID").get(dto.getScrapDetailClass()));
            dto.setOperateMessage(dictMap.get("SDS_SOLID_OPERATE_TYPE").get(dto.getOperateType()));
            result.add(dto);
        });

        return new PageDataDTO(page.getTotal(), result);
    }

    @Override
    public void exportDetail(SteelScrapWeightLogQueryVO vo, HttpServletResponse response) {
        PageDataDTO<SteelScrapWeightInfoLogDTO> pageDataDTO = selectPageList(vo, Boolean.FALSE);
        List<SteelScrapWeightInfoLogExportDTO> exportDTOList = ListUtil.toList();
        pageDataDTO.getList().forEach(item -> {
            SteelScrapWeightInfoLogExportDTO dto = new SteelScrapWeightInfoLogExportDTO();
            BeanUtil.copyProperties(item, dto);
            exportDTOList.add(dto);
        });

        String fileName = "固废称重记录日志" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), SteelScrapWeightInfoLogExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getLocalCode()));
        }
    }
}
