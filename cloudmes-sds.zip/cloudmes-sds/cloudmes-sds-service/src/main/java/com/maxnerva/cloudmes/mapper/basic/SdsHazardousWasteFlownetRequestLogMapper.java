package com.maxnerva.cloudmes.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.entity.basic.SdsHazardousWasteFlownetRequestLog;

/**
 * <p>
 * 危废flownet审核完成调用日志 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2025-06-09
 */
public interface SdsHazardousWasteFlownetRequestLogMapper extends BaseMapper<SdsHazardousWasteFlownetRequestLog> {

}
