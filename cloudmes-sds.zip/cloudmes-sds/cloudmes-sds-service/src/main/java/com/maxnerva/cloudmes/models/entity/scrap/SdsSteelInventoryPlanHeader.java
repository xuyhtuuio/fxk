package com.maxnerva.cloudmes.models.entity.scrap;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 固废盘点单头
 * </p>
 *
 * @author baomidou
 * @since 2024-12-18
 */
@TableName("sds_steel_inventory_plan_header")
@ApiModel(value = "SdsSteelInventoryPlanHeader对象", description = "固废盘点单头")
@Data
public class SdsSteelInventoryPlanHeader extends BaseEntity<SdsSteelInventoryPlanHeader> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("单号")
    private String inventoryPlanNo;

    @ApiModelProperty("描述")
    private String description;

    @ApiModelProperty("状态")
    private String inventoryStatus;

    @ApiModelProperty("盘点执行人")
    private String inventoryExecutorCode;

    @ApiModelProperty("盘点执行人姓名")
    private String inventoryExecutorName;

    @ApiModelProperty("报废小类")
    private String scrapDetailClass;
}
