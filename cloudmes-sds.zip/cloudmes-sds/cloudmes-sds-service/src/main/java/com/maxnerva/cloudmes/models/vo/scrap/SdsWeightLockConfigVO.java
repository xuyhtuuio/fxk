package com.maxnerva.cloudmes.models.vo.scrap;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;
import java.util.Date;

/**
 * @ClassName SdsWeightLockConfigVO
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/2/14 上午 10:32
 * @Version 1.0
 **/
@Data
public class SdsWeightLockConfigVO {

    @ApiModelProperty("ID")
    private Integer id;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("开始锁定时间")
    private Date beginLockDt;


    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("结束锁定时间")
    private Date endLockDt;

    @ApiModelProperty("描述")
    private String describe;
}
