package com.maxnerva.cloudmes.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.entity.basic.SdsSteelMfgConfig;

public interface SdsSteelMfgConfigMapper extends BaseMapper<SdsSteelMfgConfig> {
}
