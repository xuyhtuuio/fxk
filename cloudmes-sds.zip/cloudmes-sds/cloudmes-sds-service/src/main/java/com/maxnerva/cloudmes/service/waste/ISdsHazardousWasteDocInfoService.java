package com.maxnerva.cloudmes.service.waste;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.waste.HazardousWasteDocInfoDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteDocPrintDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteWeightInfoSubmitDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteDocInfo;
import com.maxnerva.cloudmes.models.vo.waste.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * <p>
 * 产废单据表 服务类
 * </p>
 *
 * @author likun
 * @since 2025-05-14
 */
public interface ISdsHazardousWasteDocInfoService extends IService<SdsHazardousWasteDocInfo> {

    void saveWasteDocInfo(HazardousWasteDocInfoSaveVO saveVO);

    PageDataDTO<HazardousWasteDocInfoDTO> selectWasteDocInfoList(HazardousWasteDocInfoQueryVO queryVO);

    R<WasteWeightInfoSubmitDTO> submitWasteWeightInfo(WasteWeightInfoSubmitVO submitVO);

    WasteDocPrintDTO printWasteDocInfo(WasteDocInfoPrintVO printVO);

    void cancelWasteDocInfo(Integer id);

    void uploadImage(WasteDocInfoUploadImageVO uploadImageVO);

    List<String> selectImageList(Integer id);

    void auditWasteDocInfo(Integer id);

    void applyStorage(List<Integer> idList);

    void sign(Integer id);

    void uploadImgInApp(WasteDocInfoAppUploadImageVO imageVO);

    void rejectWasteDoc(WasteDocRejectVO rejectVO);


    void checkUploadImage(WasteDocInfoAppUploadCheckVO checkVO);

    void exportWasteDocInfo(HttpServletResponse response, HazardousWasteDocInfoQueryVO queryVO);
}
