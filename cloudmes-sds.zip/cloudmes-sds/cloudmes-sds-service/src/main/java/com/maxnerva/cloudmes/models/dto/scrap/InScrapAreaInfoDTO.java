package com.maxnerva.cloudmes.models.dto.scrap;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class InScrapAreaInfoDTO {

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("申报单号")
    private String declareNumber;

    @ApiModelProperty("车牌")
    private String licenseCarNumber;

    @ApiModelProperty("司机")
    private String driver;

    @ApiModelProperty("空车重量")
    private BigDecimal carWeight;

    @ApiModelProperty("空车称重人")
    private String carWeightEmp;

    @ApiModelProperty("进厂时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime entryTime;

    @ApiModelProperty("进出废料区状态（0未进，1已进，2已出）")
    private String scrapAreaStatus;

    @ApiModelProperty("进出废料区状态名")
    private String scrapAreaStatusName;

    @ApiModelProperty("废料名称")
    private String scrapPartName;

    @ApiModelProperty("废料类别")
    private String scrapType;
}
