package com.maxnerva.cloudmes.service.waste.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.mapper.waste.SdsHazardousTransportConfigMapper;
import com.maxnerva.cloudmes.models.dto.waste.WasteTransportConfigDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousTransportConfig;
import com.maxnerva.cloudmes.service.waste.ISdsHazardousTransportConfigService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 危废运输单位配置档 服务实现类
 * </p>
 *
 * @author likun
 * @since 2025-05-27
 */
@Slf4j
@Service
public class SdsHazardousTransportConfigServiceImpl extends ServiceImpl<SdsHazardousTransportConfigMapper, SdsHazardousTransportConfig> implements ISdsHazardousTransportConfigService {

    @Override
    public List<WasteTransportConfigDTO> selectTransferConfigList() {
        return baseMapper.selectTransferConfigList();
    }
}
