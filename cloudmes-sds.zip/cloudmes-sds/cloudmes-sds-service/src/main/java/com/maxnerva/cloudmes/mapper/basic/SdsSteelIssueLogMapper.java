package com.maxnerva.cloudmes.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.entity.basic.SdsSteelIssueLog;

/**
 * @ClassName SdsSteelIssueLogMapper
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2024/12/25 下午 01:26
 * @Version 1.0
 **/
public interface SdsSteelIssueLogMapper extends BaseMapper<SdsSteelIssueLog> {

}
