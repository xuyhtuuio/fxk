package com.maxnerva.cloudmes.models.entity.basic;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 危废贮存设施表
 * </p>
 *
 * @author likun
 * @since 2025-05-14
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="SdsHazardousWasteStorageFacilities对象", description="危废贮存设施表")
public class SdsHazardousWasteStorageFacilities extends BaseEntity<SdsHazardousWasteStorageFacilities> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "设施名称")
    private String facilitiesName;

    @ApiModelProperty(value = "设施编码")
    private String facilitiesCode;

    @ApiModelProperty(value = "设施类型")
    private String facilitiesType;

    @ApiModelProperty(value = "贮存能力(吨)")
    private String facilitiesCapacity;
}
