package com.maxnerva.cloudmes.models.vo.scrap;

import com.maxnerva.cloudmes.models.vo.CommonPrintVO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class PrintScrapShipmentApplyVO extends CommonPrintVO {
    @ApiModelProperty("申报单号")
    private String declareNumber;
}
