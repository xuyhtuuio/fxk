package com.maxnerva.cloudmes.mapper.plan;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.dto.plan.PlanInfoAddLogDTO;
import com.maxnerva.cloudmes.models.entity.plan.SdsHazardousWastePlanInfoAddLog;
import com.maxnerva.cloudmes.models.vo.plan.PlanInfoAddLogQueryVO;

import java.util.List;

/**
 * <p>
 * 年度计划说明表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2025-05-08
 */
public interface SdsHazardousWastePlanInfoAddLogMapper extends BaseMapper<SdsHazardousWastePlanInfoAddLog> {

    List<PlanInfoAddLogDTO> selectPlanInfoAddLogList(PlanInfoAddLogQueryVO queryVO);

    PlanInfoAddLogDTO selectPlanInfoAddLogById(Integer id);
}
