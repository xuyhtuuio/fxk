package com.maxnerva.cloudmes.service.scrap.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.lang.TypeReference;
import cn.hutool.core.map.MapUtil;
import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.NumberUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.extra.expression.ExpressionUtil;
import cn.hutool.json.JSONUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.common.utils.WebContextUtil;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.excel.handler.AddNoHandler;
import com.maxnerva.cloudmes.mapper.basic.SdsDepartmentConfigMapper;
import com.maxnerva.cloudmes.mapper.basic.SdsScrapSolidTypeConfigMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelArchiveInventoryInfoMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelRemainingInventoryInfoMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelScrapShipHeaderMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelScrapWeightInfoMapper;
import com.maxnerva.cloudmes.models.dto.excel.scrap.RubbishInStockExportDTO;
import com.maxnerva.cloudmes.models.dto.excel.scrap.RubbishOutStockExportDTO;
import com.maxnerva.cloudmes.models.dto.excel.scrap.RubbishStockSummaryExportDTO;
import com.maxnerva.cloudmes.models.dto.scrap.*;
import com.maxnerva.cloudmes.models.entity.basic.SdsDepartmentConfig;
import com.maxnerva.cloudmes.models.entity.basic.SdsFileDownloadLog;
import com.maxnerva.cloudmes.models.entity.basic.SdsScrapSolidTypeConfig;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelArchiveInventoryInfo;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelRemainingInventoryInfo;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapShipHeader;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapWeightInfo;
import com.maxnerva.cloudmes.models.vo.excel.ExcelMergeCellValue;
import com.maxnerva.cloudmes.models.vo.excel.SummaryExcelFormatVO;
import com.maxnerva.cloudmes.models.vo.scrap.RubbishInStockQueryVO;
import com.maxnerva.cloudmes.models.vo.scrap.RubbishOutStockQueryVO;
import com.maxnerva.cloudmes.models.vo.scrap.RubbishStockSummaryQueryVO;
import com.maxnerva.cloudmes.models.vo.scrap.SteelScrapInventoryReportQueryVO;
import com.maxnerva.cloudmes.service.basic.ISdsFileDownloadLogService;
import com.maxnerva.cloudmes.service.scrap.ISteelScrapReportService;
import com.maxnerva.cloudmes.system.utils.DictLangUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.checkerframework.checker.units.qual.A;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URLEncoder;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
@Service
public class SteelScrapReportService implements ISteelScrapReportService {

    @Autowired
    SdsSteelScrapWeightInfoMapper steelScrapWeightInfoMapper;

    @Autowired
    SdsSteelScrapShipHeaderMapper steelScrapShipHeaderMapper;

    @Autowired
    DictLangUtils dictLangUtils;

    @Autowired
    SdsScrapSolidTypeConfigMapper scrapSolidTypeConfigMapper;

    @Autowired
    SdsDepartmentConfigMapper departmentConfigMapper;

    @Autowired
    SdsSteelRemainingInventoryInfoMapper steelRemainingInventoryInfoMapper;

    @Autowired
    ISdsFileDownloadLogService fileDownloadLogService;

    @Autowired
    SdsSteelArchiveInventoryInfoMapper steelArchiveInventoryInfoMapper;

    @Override
    public PageDataDTO<RubbishInStockDTO> getRubbishInStock(RubbishInStockQueryVO vo, Boolean isPage) {
        Page page = new Page();
        if (BooleanUtil.isTrue(isPage)){
            page = PageHelper.startPage(vo.getPageIndex(), vo.getPageSize());
        }
        List<SdsSteelScrapWeightInfo> list = steelScrapWeightInfoMapper.selectList(Wrappers.<SdsSteelScrapWeightInfo>lambdaQuery()
                .select(SdsSteelScrapWeightInfo::getBucketNo, SdsSteelScrapWeightInfo::getScrapDetailClass, SdsSteelScrapWeightInfo::getBucketWeight,
                        SdsSteelScrapWeightInfo::getUom, SdsSteelScrapWeightInfo::getRubbishGrossWeight, SdsSteelScrapWeightInfo::getRubbishNetWeight,
                        SdsSteelScrapWeightInfo::getRubbishWeighEmpNo, SdsSteelScrapWeightInfo::getRubbishWeighDt, SdsSteelScrapWeightInfo::getDepartmentCode)
                .eq(StrUtil.isNotBlank(vo.getDepartmentCode()), SdsSteelScrapWeightInfo::getDepartmentCode, vo.getDepartmentCode())
                .eq(StrUtil.isNotBlank(vo.getBucketNo()), SdsSteelScrapWeightInfo::getBucketNo, vo.getBucketNo())
                .eq(StrUtil.isNotBlank(vo.getScrapType()), SdsSteelScrapWeightInfo::getScrapType, vo.getScrapType())
                .eq(StrUtil.isNotBlank(vo.getScrapDetailClass()), SdsSteelScrapWeightInfo::getScrapDetailClass, vo.getScrapDetailClass())
                .eq(SdsSteelScrapWeightInfo::getRubbishWeighFlag, "Y")
                .eq(StrUtil.isNotBlank(vo.getHasInArea()) && "N".equals(vo.getHasInArea()), SdsSteelScrapWeightInfo::getIsScrapArea, Boolean.FALSE)
                .eq(StrUtil.isNotBlank(vo.getHasInArea()) && "Y".equals(vo.getHasInArea()), SdsSteelScrapWeightInfo::getIsScrapArea, Boolean.TRUE)
                .between(ObjectUtil.isNotNull(vo.getStartDateTime()), SdsSteelScrapWeightInfo::getRubbishWeighDt, vo.getStartDateTime(), vo.getEndDateTime())
                .orderByAsc(SdsSteelScrapWeightInfo::getId)
        );
        Map<String, Map<String, String>> dictMap = dictLangUtils.getByTypes(ListUtil.toList("SDS_SCRAP_SOLID"));
        List<RubbishInStockDTO> result = ListUtil.toList();
        List<SdsDepartmentConfig> sdsDepartmentConfigList = departmentConfigMapper.selectList(Wrappers.<SdsDepartmentConfig>lambdaQuery()
                .select(SdsDepartmentConfig::getDepartmentCode, SdsDepartmentConfig::getDepartmentName)
        );
        Map<String, String> departmentConfigMap = sdsDepartmentConfigList.stream().collect(Collectors.toMap(k -> k.getDepartmentCode(), v -> v.getDepartmentName()));
        list.forEach(item -> {
            RubbishInStockDTO dto = new RubbishInStockDTO();
            BeanUtil.copyProperties(item, dto);
            dto.setDepartmentCodeName(departmentConfigMap.get(item.getDepartmentCode()));
            dto.setScrapDetailClassName(dictMap.get("SDS_SCRAP_SOLID").get(dto.getScrapDetailClass()));
            result.add(dto);
        });
        return new PageDataDTO(page.getTotal(), result);
    }

    @Override
    public void exportRubbishInStock(RubbishInStockQueryVO vo, HttpServletResponse response) {
        PageDataDTO<RubbishInStockDTO> pageDataDTO = getRubbishInStock(vo, Boolean.FALSE);
        List<RubbishInStockExportDTO> exportDTOList = ListUtil.toList();
        pageDataDTO.getList().forEach(item -> {
            RubbishInStockExportDTO dto = new RubbishInStockExportDTO();
            BeanUtil.copyProperties(item, dto);
            exportDTOList.add(dto);
        });

        String fileName = "固废库存入库" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), RubbishInStockExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getLocalCode()));
        }
    }

    @Override
    public PageDataDTO<RubbishOutStockDTO> getRubbishOutStock(RubbishOutStockQueryVO vo, Boolean isPage) {
        Page page = new Page();
        if (BooleanUtil.isTrue(isPage)){
            page = PageHelper.startPage(vo.getPageIndex(), vo.getPageSize());
        }
        List<SdsSteelScrapShipHeader> list = steelScrapShipHeaderMapper.selectList(Wrappers.<SdsSteelScrapShipHeader>lambdaQuery()
                .select(SdsSteelScrapShipHeader::getScrapDetailClass, SdsSteelScrapShipHeader::getDeclareNumber, SdsSteelScrapShipHeader::getCarWeight,
                        SdsSteelScrapShipHeader::getWeightUom, SdsSteelScrapShipHeader::getFullCarWeight, SdsSteelScrapShipHeader::getScrapNetWeight,
                        SdsSteelScrapShipHeader::getFullCarWeightDt, SdsSteelScrapShipHeader::getFullCarWeightEmp)
                .eq(StrUtil.isNotBlank(vo.getScrapDetailClass()), SdsSteelScrapShipHeader::getScrapDetailClass, vo.getScrapDetailClass())
                .eq(StrUtil.isNotBlank(vo.getScrapType()), SdsSteelScrapShipHeader::getSdsScrapType, vo.getScrapType())
                .isNotNull(SdsSteelScrapShipHeader::getScrapNetWeight)
                .between(ObjectUtil.isNotNull(vo.getStartDateTime()), SdsSteelScrapShipHeader::getEntryTime, vo.getStartDateTime(), vo.getEndDateTime())
                .orderByAsc(SdsSteelScrapShipHeader::getId)
        );
        List<RubbishOutStockDTO> result = ListUtil.toList();
        Map<String, Map<String, String>> dictMap = dictLangUtils.getByTypes(ListUtil.toList("SDS_SCRAP_SOLID"));
        list.forEach(item -> {
            RubbishOutStockDTO dto = new RubbishOutStockDTO();
            BeanUtil.copyProperties(item ,dto);
            dto.setScrapDetailClassName(dictMap.get("SDS_SCRAP_SOLID").get(dto.getScrapDetailClass()));
            result.add(dto);
        });
        return new PageDataDTO(page.getTotal(), result);
    }

    @Override
    public void exportRubbishOutStock(RubbishOutStockQueryVO vo, HttpServletResponse response) {
        PageDataDTO<RubbishOutStockDTO> pageDataDTO = getRubbishOutStock(vo, Boolean.FALSE);
        List<RubbishOutStockExportDTO> exportDTOList = ListUtil.toList();
        pageDataDTO.getList().forEach(item -> {
            RubbishOutStockExportDTO dto = new RubbishOutStockExportDTO();
            BeanUtil.copyProperties(item, dto);
            exportDTOList.add(dto);
        });

        String fileName = "固废库存出库" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), RubbishOutStockExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getLocalCode()));
        }
    }

    @Override
    public PageDataDTO<RubbishStockSummaryDTO> getRubbishStockSummary(RubbishStockSummaryQueryVO vo, Boolean isPage) {
        Page page = new Page();
        if (BooleanUtil.isTrue(isPage)){
            page = PageHelper.startPage(vo.getPageIndex(), vo.getPageSize());
        }
        List<SdsScrapSolidTypeConfig> scrapSolidTypeConfigList = scrapSolidTypeConfigMapper.selectList(Wrappers.<SdsScrapSolidTypeConfig>lambdaQuery()
                .eq(StrUtil.isNotBlank(vo.getScrapType()), SdsScrapSolidTypeConfig::getScrapType, vo.getScrapType())
                .eq(StrUtil.isNotBlank(vo.getScrapDetailClass()), SdsScrapSolidTypeConfig::getScrapDetailClass, vo.getScrapDetailClass())
                .orderByAsc(SdsScrapSolidTypeConfig::getScrapDetailClass)
        );
        List<String> scrapDetailClassList = scrapSolidTypeConfigList.stream().map(item -> item.getScrapDetailClass()).distinct().collect(Collectors.toList());
        List<ScrapDetailClassStockDTO> buStockList = steelScrapWeightInfoMapper.selectAllTotalBuScrapNetWeight(scrapDetailClassList, vo.getStartDateTime(), vo.getEndDateTime());
        Map<String, BigDecimal> buStockNetWeightMap = buStockList.stream().collect(Collectors.toMap(k -> k.getScrapDetailClass(), v -> v.getNetWeight()));
        List<ScrapDetailClassStockDTO> stockDTOList = steelScrapWeightInfoMapper.selectAllTotalScrapNetWeight(scrapDetailClassList, vo.getStartDateTime(), vo.getEndDateTime());
        Map<String, BigDecimal> stockNetWeightMap = stockDTOList.stream().collect(Collectors.toMap(k -> k.getScrapDetailClass(), v -> v.getNetWeight()));
        List<ScrapDetailClassStockDTO> shipDTOList = steelScrapShipHeaderMapper.selectAllTotalScrapNetWeight(scrapDetailClassList, vo.getStartDateTime(), vo.getEndDateTime());
        Map<String, BigDecimal> shipNetWeightMap = shipDTOList.stream().collect(Collectors.toMap(k -> k.getScrapDetailClass(), v -> v.getNetWeight()));
        List<RubbishStockSummaryDTO> result = ListUtil.toList();
        Map<String, Map<String, String>> dictMap = dictLangUtils.getByTypes(ListUtil.toList("SDS_SCRAP_SOLID"));
        scrapSolidTypeConfigList.forEach(item -> {
            RubbishStockSummaryDTO dto = new RubbishStockSummaryDTO();
            BigDecimal buStockNetWeight = BigDecimal.ZERO;
            BigDecimal stockNetWeight = BigDecimal.ZERO;
            BigDecimal shipNetWeight = BigDecimal.ZERO;
            if (buStockNetWeightMap.containsKey(item.getScrapDetailClass())){
                buStockNetWeight = buStockNetWeightMap.get(item.getScrapDetailClass());
            }
            if (stockNetWeightMap.containsKey(item.getScrapDetailClass())){
                stockNetWeight = stockNetWeightMap.get(item.getScrapDetailClass());
            }
            if (shipNetWeightMap.containsKey(item.getScrapDetailClass())){
                shipNetWeight = shipNetWeightMap.get(item.getScrapDetailClass());
            }
            dto.setBuStockQty(buStockNetWeight);
            dto.setInStockQty(stockNetWeight);
            dto.setOutStockQty(shipNetWeight);
            dto.setSummaryQty(stockNetWeight.subtract(shipNetWeight));
            dto.setScrapDetailClass(item.getScrapDetailClass());
            dto.setScrapDetailClassName(dictMap.get("SDS_SCRAP_SOLID").get(dto.getScrapDetailClass()));
            result.add(dto);
        });
        return new PageDataDTO(page.getTotal(), result);
    }

    @Override
    public void exportRubbishStockSummary(RubbishStockSummaryQueryVO vo, HttpServletResponse response) {
        PageDataDTO<RubbishStockSummaryDTO> pageDataDTO = getRubbishStockSummary(vo, Boolean.FALSE);
        List<RubbishStockSummaryExportDTO> exportDTOList = ListUtil.toList();
        pageDataDTO.getList().forEach(item -> {
            RubbishStockSummaryExportDTO dto = new RubbishStockSummaryExportDTO();
            BeanUtil.copyProperties(item, dto);
            exportDTOList.add(dto);
        });

        String fileName = "固废库存结余" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), RubbishStockSummaryExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.MATERIAL_CLASS_EXPORT_FAIL.getLocalCode()));
        }
    }

    private void addSummaryQty(List<BigDecimal> list, Integer index, BigDecimal qty) {
        if (list.size() <= index) {
            list.add(qty);
        } else {
            list.set(index, list.get(index).add(qty));
        }
    }

    @Override
    public InventoryReportDTO selectInventoryReport(SteelScrapInventoryReportQueryVO vo) {
        InventoryReportDTO inventoryReportDTO = new InventoryReportDTO();
        inventoryReportDTO.setHeaderRowNum(4);
        Map<String, BigDecimal> bakRubbishDiffPercentageMap = new HashMap<>();
        Map<String, BigDecimal> bakBuDiffPercentageMap = new HashMap<>();
        inventoryReportDTO.setRubbishDiffPercentage(bakRubbishDiffPercentageMap);
        inventoryReportDTO.setBuDiffPercentage(bakBuDiffPercentageMap);
        inventoryReportDTO.setYear(vo.getEndDate().format(DateTimeFormatter.ofPattern("yyyy")));
        inventoryReportDTO.setMonth(vo.getEndDate().format(DateTimeFormatter.ofPattern("MM")));

        Map<String, Map<String, String>> dictMap = dictLangUtils.getByTypes(ListUtil.toList("SDS_OUT_SHIP_CONFIG", "SDS_SCRAP_AREA_WEIGHT_ERROR"));
        Map<String, String> outShipPlantMap = dictMap.get("SDS_OUT_SHIP_CONFIG");
        String outShipPlantStr = outShipPlantMap.get("OUT");
        Map<String, String> weightErrorMap = dictMap.get("SDS_SCRAP_AREA_WEIGHT_ERROR");

        LocalDateTime displayStartDate = vo.getStartDate();
        LocalDateTime displayEndDate = vo.getEndDate();
        LocalDateTime startDate = vo.getStartDate();
        LocalDateTime endDate = vo.getEndDate();
        LocalDateTime beforeStartDate = endDate.plusMonths(-1).withDayOfMonth(1).withHour(0).withMinute(0).withSecond(0);
        LocalDateTime beforeEndDate = beforeStartDate.plusMonths(1);

        List<List<ExcelMergeCellValue>> result = ListUtil.toList();
        inventoryReportDTO.setList(result);

        List<SdsDepartmentConfig> departmentConfigList = departmentConfigMapper.selectList(Wrappers.emptyWrapper());
        Map<String, List<SdsDepartmentConfig>> buDepartmentCodeMap = departmentConfigList.stream()
                .collect(Collectors.groupingBy(SdsDepartmentConfig::getBuName));
        List<String> buNameList = departmentConfigList.stream()
                .map(item -> item.getBuName())
                .distinct()
                .sorted()
                .collect(Collectors.toList());

        List<SdsScrapSolidTypeConfig> scrapSolidTypeConfigList = scrapSolidTypeConfigMapper.selectList(Wrappers.<SdsScrapSolidTypeConfig>lambdaQuery()
                .isNotNull(SdsScrapSolidTypeConfig::getScrapPartNo)
        );
        List<String> ecusScrapTypeList = scrapSolidTypeConfigList.stream().map(item -> item.getEcusScrapType())
                .distinct().collect(Collectors.toList());
        // ecusScrapType -> SdsScrapSolidTypeConfig[]
        Map<String, List<SdsScrapSolidTypeConfig>> ecusScrapTypeSolidConfigGroup = scrapSolidTypeConfigList.stream()
                .collect(Collectors.groupingBy(SdsScrapSolidTypeConfig::getEcusScrapType));

        SdsSteelArchiveInventoryInfo beforeArchiveInventoryInfo = steelArchiveInventoryInfoMapper.selectOne(Wrappers.<SdsSteelArchiveInventoryInfo>lambdaQuery()
                .eq(SdsSteelArchiveInventoryInfo::getYear, beforeStartDate.format(DateTimeFormatter.ofPattern("yyyy")))
                .eq(SdsSteelArchiveInventoryInfo::getMonth, beforeStartDate.format(DateTimeFormatter.ofPattern("MM")))
                .orderByDesc(SdsSteelArchiveInventoryInfo::getId)
                .last("limit 1")
        );
        // 上月暫存區與ECUS差異比例

        Map<String, BigDecimal> beforeRubbishDiffPercentageMap;
        if (ObjectUtil.isNotNull(beforeArchiveInventoryInfo)) {
            String beforeRubbishDiffPercentageJson = beforeArchiveInventoryInfo.getRubbishDiffPercentage();
            beforeRubbishDiffPercentageMap = JSONUtil.toBean(beforeRubbishDiffPercentageJson,
                    new TypeReference<Map<String, BigDecimal>>() {}, false);
        } else {
            beforeRubbishDiffPercentageMap = new HashMap<>();
        }
        // 上月BU与Ecus差异比例

        Map<String, BigDecimal> beforeBuDiffPercentageMap;
        if (ObjectUtil.isNotNull(beforeArchiveInventoryInfo)) {
            String buDiffPercentageJson = beforeArchiveInventoryInfo.getBuDiffPercentage();
            beforeBuDiffPercentageMap = JSONUtil.toBean(buDiffPercentageJson,
                    new TypeReference<Map<String, BigDecimal>>() {}, false);
        } else {
            beforeBuDiffPercentageMap = new HashMap<>();
        }

        // 当月BU称重信息
        List<SdsSteelScrapWeightInfo> steelScrapWeightInfoList = steelScrapWeightInfoMapper.selectList(Wrappers.<SdsSteelScrapWeightInfo>lambdaQuery()
                .between(SdsSteelScrapWeightInfo::getWeighDt, startDate, endDate)
        );
        // 当月出货信息
        List<SdsSteelScrapShipHeader> steelScrapShipHeaderList = steelScrapShipHeaderMapper.selectList(Wrappers.<SdsSteelScrapShipHeader>lambdaQuery()
                .between(SdsSteelScrapShipHeader::getEntryTime, startDate, endDate)
        );

        // 上月BU称重信息
        List<SdsSteelScrapWeightInfo> beforeSteelScrapWeightInfoList = steelScrapWeightInfoMapper.selectList(Wrappers.<SdsSteelScrapWeightInfo>lambdaQuery()
                .between(SdsSteelScrapWeightInfo::getWeighDt, beforeStartDate, beforeEndDate)
        );
        // 上月出货信息
        List<SdsSteelScrapShipHeader> beforeSteelScrapShipHeaderList = steelScrapShipHeaderMapper.selectList(Wrappers.<SdsSteelScrapShipHeader>lambdaQuery()
                .between(SdsSteelScrapShipHeader::getEntryTime, beforeStartDate, beforeEndDate)
        );

        // 上月库存结余
        List<SdsSteelRemainingInventoryInfo> beforeRemainingInventoryInfoList = steelRemainingInventoryInfoMapper.selectList(Wrappers.<SdsSteelRemainingInventoryInfo>lambdaQuery()
                .eq(SdsSteelRemainingInventoryInfo::getYear, beforeStartDate.format(DateTimeFormatter.ofPattern("yyyy")))
                .eq(SdsSteelRemainingInventoryInfo::getMonth, beforeStartDate.format(DateTimeFormatter.ofPattern("MM")))
        );
        // 上月库存结余 scrapDetailClass -> 结余数量
        Map<String, BigDecimal> beforeRemainingInventoryQtyMap = beforeRemainingInventoryInfoList.stream()
                .collect(Collectors.groupingBy(SdsSteelRemainingInventoryInfo::getScrapDetailClass, Collectors.mapping(Function.identity(),
                        Collectors.collectingAndThen(Collectors.toList(), subList -> {
                            SdsSteelRemainingInventoryInfo sdsSteelRemainingInventoryInfo = subList.stream().max(Comparator.comparing(SdsSteelRemainingInventoryInfo::getId)).orElse(null);
                            if (ObjectUtil.isNotNull(sdsSteelRemainingInventoryInfo)) {
                                return sdsSteelRemainingInventoryInfo.getRemainWeight();
                            } else {
                                return null;
                            }
                        })

                )));

        // 本月库存结余
        List<SdsSteelRemainingInventoryInfo> remainingInventoryInfoList = steelRemainingInventoryInfoMapper.selectList(Wrappers.<SdsSteelRemainingInventoryInfo>lambdaQuery()
                .eq(SdsSteelRemainingInventoryInfo::getYear, endDate.format(DateTimeFormatter.ofPattern("yyyy")))
                .eq(SdsSteelRemainingInventoryInfo::getMonth, endDate.format(DateTimeFormatter.ofPattern("MM")))
        );
        // 本月库存结余 scrapDetailClass -> 结余数量
        Map<String, BigDecimal> remainingInventoryQtyMap = remainingInventoryInfoList.stream()
                .collect(Collectors.groupingBy(SdsSteelRemainingInventoryInfo::getScrapDetailClass, Collectors.mapping(Function.identity(),
                        Collectors.collectingAndThen(Collectors.toList(), subList -> {
                            SdsSteelRemainingInventoryInfo sdsSteelRemainingInventoryInfo = subList.stream().max(Comparator.comparing(SdsSteelRemainingInventoryInfo::getId)).orElse(null);
                            if (ObjectUtil.isNotNull(sdsSteelRemainingInventoryInfo)) {
                                return sdsSteelRemainingInventoryInfo.getRemainWeight();
                            } else {
                                return null;
                            }
                        })

                )));

        // 厂部 -> 称重数据列表
        Map<String, List<SdsSteelScrapWeightInfo>> departmentWeightGroup = steelScrapWeightInfoList.stream()
                .collect(Collectors.groupingBy(SdsSteelScrapWeightInfo::getDepartmentCode));

        List<List<ExcelMergeCellValue>> dataList = ListUtil.toList();

        List<ExcelMergeCellValue> totalSummaryList = ListUtil.toList();
        Map<String, Integer> totalSummaryCodeIndexMap = new HashMap<>();
        Map<Integer, String> totalSummaryExpressionMap = new HashMap<>();
        Set<Integer> totalAvgIndexSet = new HashSet<>();
        Map<Integer, Integer> totalSummaryIndexDivideCountMap = new HashMap<>();
        List<BigDecimal> totalSummaryQtyList = ListUtil.toList();
        List<Integer> totalSummarySummaryEmpty = ListUtil.toList();
        List<SummaryExcelFormatVO> totalSummaryFormat = ListUtil.toList();
        totalSummaryList.add(new ExcelMergeCellValue("匯總", 1, 2, IndexedColors.BLUE_GREY.getIndex()));

        // 使用毛重统计，电子危废
        Set<String> calcGrossWeightScrapTypeSet = new HashSet<>();
        calcGrossWeightScrapTypeSet.add("ELECTRICAL_PARTS");

        ecusScrapTypeList.forEach(ecusScrapType -> {

            // 报废料号信息列表
            List<SdsScrapSolidTypeConfig> subScrapSolidTypeConfigList = ecusScrapTypeSolidConfigGroup.get(ecusScrapType);
            subScrapSolidTypeConfigList.sort(Comparator.comparing(SdsScrapSolidTypeConfig::getEcusScrapDesc));
            List<String> totalScrapPartNoList = subScrapSolidTypeConfigList.stream()
                    .map(item -> item.getScrapPartNo())
                    .distinct().collect(Collectors.toList());
            List<ExcelMergeCellValue> firstDataRowList = ListUtil.toList();
            firstDataRowList.add(new ExcelMergeCellValue(ecusScrapType, totalScrapPartNoList.size(), 1));
            List<ExcelMergeCellValue> summaryList = ListUtil.toList();

            List<BigDecimal> summaryQtyList = ListUtil.toList();
            Map<String, Integer> summaryCodeIndexMap = new HashMap<>();
            Map<Integer, String> summaryExpressionMap = new HashMap<>();
            Map<Integer, Integer> summaryIndexDivideCountMap = new HashMap<>();
            List<Integer> summarySummaryEmpty = ListUtil.toList();
            List<SummaryExcelFormatVO> summaryFormat = ListUtil.toList();
            summaryList.add(new ExcelMergeCellValue("總計", 1, 2, IndexedColors.PALE_BLUE.getIndex()));


            for (int i = 0; i < subScrapSolidTypeConfigList.size(); i ++) {
                List<ExcelMergeCellValue> tmpSubDataList = ListUtil.toList();
                if (i == 0) {
                    tmpSubDataList = firstDataRowList;
                }
                final List<ExcelMergeCellValue> subDataList = tmpSubDataList;
                String scrapDetailClass = subScrapSolidTypeConfigList.get(i).getScrapDetailClass();
                String scrapPartNo = subScrapSolidTypeConfigList.get(i).getScrapPartNo();
                Boolean isScrapArea = subScrapSolidTypeConfigList.get(i).getIsScrapArea();
                String ecusScrapDesc = subScrapSolidTypeConfigList.get(i).getEcusScrapDesc();
                String scrapType = subScrapSolidTypeConfigList.get(i).getScrapType();

                Boolean isUseGrossWeight = calcGrossWeightScrapTypeSet.contains(scrapType);

                BigDecimal buTotalWeight = BigDecimal.ZERO;

                subDataList.add(new ExcelMergeCellValue(ecusScrapDesc, 1, 1));
                Integer index = 0;
//                Integer summaryIndex = 0;
                for (String buName : buNameList) {
                    List<SdsDepartmentConfig> subDepartmentCodeConfigList = buDepartmentCodeMap.get(buName);
                    List<String> subDepartmentCodeList = subDepartmentCodeConfigList.stream().map(item -> item.getDepartmentCode()).collect(Collectors.toList());
                    List<SdsSteelScrapWeightInfo> buWeightInfoList = steelScrapWeightInfoList.stream()
                            .filter(item -> !"OUT-SHIP".equals(item.getSource()))
                            .filter(item -> scrapDetailClass.equals(item.getScrapDetailClass()) && subDepartmentCodeList.contains(item.getDepartmentCode()))
                            .collect(Collectors.toList());
                    BigDecimal buWeight;
                    if (BooleanUtil.isTrue(isUseGrossWeight)) {
                        buWeight = buWeightInfoList.stream().map(item -> item.getGrossWeight()).reduce(BigDecimal.ZERO, BigDecimal::add);
                    } else {
                        buWeight = buWeightInfoList.stream().map(item -> item.getNetWeight()).reduce(BigDecimal.ZERO, BigDecimal::add);
                    }

                    subDataList.add(new ExcelMergeCellValue(buWeight, 1, 1));
                    addSummaryQty(summaryQtyList, index ++, buWeight);
                    buTotalWeight = buTotalWeight.add(buWeight);
                }

                // 本月剩余
                List<SdsSteelScrapWeightInfo> buWeightInfoList = steelScrapWeightInfoList.stream()
                        .filter(item -> !"OUT-SHIP".equals(item.getSource()))
                        .filter(item -> scrapDetailClass.equals(item.getScrapDetailClass()))
                        .collect(Collectors.toList());

                // 当月该料号出货数据列表 排除外发厂
                List<SdsSteelScrapShipHeader> shipList = steelScrapShipHeaderList.stream()
                        .filter(item -> scrapPartNo.equals(item.getScrapPartNo()))
                        .filter(item -> !outShipPlantStr.contains(item.getAreaCode()))
                        .collect(Collectors.toList());

                // 当月废料厂入库净重
                BigDecimal totalRubbishNetWeight;
                if (BooleanUtil.isTrue(isUseGrossWeight)) {
                    totalRubbishNetWeight = buWeightInfoList.stream()
                            .filter(item -> "Y".equals(item.getRubbishWeighFlag()))
                            .filter(item -> BooleanUtil.isTrue(item.getIsScrapArea()))
                            .map(item -> item.getRubbishGrossWeight())
                            .reduce(BigDecimal.ZERO, BigDecimal::add);
                } else {
                    totalRubbishNetWeight = buWeightInfoList.stream()
                            .filter(item -> "Y".equals(item.getRubbishWeighFlag()))
                            .filter(item -> BooleanUtil.isTrue(item.getIsScrapArea()))
                            .map(item -> item.getRubbishNetWeight())
                            .reduce(BigDecimal.ZERO, BigDecimal::add);
                }

                // 本月出货量 排除外发厂
                BigDecimal totalShipNetWeight = shipList.stream()
                        .map(item -> item.getScrapNetWeight())
                        .filter(item -> ObjectUtil.isNotNull(item))
                        .reduce(BigDecimal.ZERO, BigDecimal::add);

                BigDecimal buBeforeNotToRubbishWeight = BigDecimal.ZERO;
                if (BooleanUtil.isFalse(isScrapArea) && beforeRemainingInventoryQtyMap.containsKey(scrapDetailClass)) {
                    buBeforeNotToRubbishWeight = beforeRemainingInventoryQtyMap.get(scrapDetailClass);
                }
                // BU 总称重 A
                subDataList.add(new ExcelMergeCellValue(buTotalWeight, 1, 1));
                addSummaryQty(summaryQtyList, index ++, buTotalWeight);
                // BU暂存区已称重剩余废料 B
                subDataList.add(new ExcelMergeCellValue(buBeforeNotToRubbishWeight, 1, 1));
                addSummaryQty(summaryQtyList, index ++, buBeforeNotToRubbishWeight);
                // 盘点暂存区剩余废料 C
                BigDecimal beforeScrapAreaRemainQty = BigDecimal.ZERO;
                if (BooleanUtil.isTrue(isScrapArea) && beforeRemainingInventoryQtyMap.containsKey(scrapDetailClass)) {
                    beforeScrapAreaRemainQty = beforeRemainingInventoryQtyMap.get(scrapDetailClass);
                }
                subDataList.add(new ExcelMergeCellValue(beforeScrapAreaRemainQty, 1, 1));
                addSummaryQty(summaryQtyList, index ++, beforeScrapAreaRemainQty);
                // 暂存区入库量 D
                subDataList.add(new ExcelMergeCellValue(totalRubbishNetWeight, 1, 1));
                summaryCodeIndexMap.put("D", index);
                totalSummaryCodeIndexMap.put("D", index);
                addSummaryQty(summaryQtyList, index ++, totalRubbishNetWeight);
                // ECUS系統 E
                subDataList.add(new ExcelMergeCellValue(totalShipNetWeight, 1, 1));
                summaryCodeIndexMap.put("E", index);
                totalSummaryCodeIndexMap.put("E", index);
                addSummaryQty(summaryQtyList, index ++, totalShipNetWeight);

                // 本月BU剩餘量 O=A+B-E
                BigDecimal buRemainQty = BooleanUtil.isFalse(isScrapArea) ? buTotalWeight.add(buBeforeNotToRubbishWeight).subtract(totalShipNetWeight)
                        : BigDecimal.ZERO;
                subDataList.add(new ExcelMergeCellValue(buRemainQty, 1, 1));
                addSummaryQty(summaryQtyList, index ++, buRemainQty);
                // 本月暂存区剩余量 H=C+D-E
                BigDecimal nowMonthRubbishRemainQty = BooleanUtil.isTrue(isScrapArea) ? beforeScrapAreaRemainQty.add(totalRubbishNetWeight).subtract(totalShipNetWeight) : BigDecimal.ZERO;
                subDataList.add(new ExcelMergeCellValue(nowMonthRubbishRemainQty, 1, 1));
                addSummaryQty(summaryQtyList, index ++, nowMonthRubbishRemainQty);
                // 本月實物剩餘量 P
                BigDecimal actualRemainQty = BigDecimal.ZERO;
                if (remainingInventoryQtyMap.containsKey(scrapDetailClass)) {
                    actualRemainQty = remainingInventoryQtyMap.get(scrapDetailClass);
                }
                ExcelMergeCellValue actualRemainExcelValue = new ExcelMergeCellValue(actualRemainQty, 1, 1);
                actualRemainExcelValue.setCustomType("input");
                actualRemainExcelValue.setCustomMetaData(MapUtil
                        .builder("scrapDetailClass", scrapDetailClass)
                        .put("type", "number")
                        .put("year", endDate.format(DateTimeFormatter.ofPattern("yyyy")))
                        .put("month", endDate.format(DateTimeFormatter.ofPattern("MM")))
                        .map());
                subDataList.add(actualRemainExcelValue);
                addSummaryQty(summaryQtyList, index ++, actualRemainQty);
                // 该类别是否入暂存区
                ExcelMergeCellValue entryRubbishExcelValue = new ExcelMergeCellValue(BooleanUtil.isTrue(isScrapArea) ? "Y" : "N", 1, 1);
                entryRubbishExcelValue.setIsCenter(Boolean.TRUE);
                subDataList.add(entryRubbishExcelValue);
                addSummaryQty(summaryQtyList, index, BigDecimal.ZERO);
                summarySummaryEmpty.add(index);
                totalSummarySummaryEmpty.add(index);
                index ++;
                // 各BU稱重次數（Q）
                Long buWeightTotalNum = steelScrapWeightInfoList.stream()
                        .filter(item -> !"OUT-SHIP".equals(item.getSource()))
                        .filter(item -> scrapDetailClass.equals(item.getScrapDetailClass()))
                        .count();
                subDataList.add(new ExcelMergeCellValue(BigDecimal.valueOf(buWeightTotalNum), 1, 1));
                addSummaryQty(summaryQtyList, index ++, BigDecimal.valueOf(buWeightTotalNum));
                // 誤差範圍 R（包材|R|=|Q*2.5|;金屬|R|=|Q*5.5|）
                BigDecimal weightErrorRange = BigDecimal.ZERO;
                String weightErrorStr = weightErrorMap.get(scrapType);
                if (StrUtil.isNotBlank(weightErrorStr)) {
                    BigDecimal weightError = new BigDecimal(weightErrorStr);
                    weightErrorRange = weightError.multiply(BigDecimal.valueOf(buWeightTotalNum));
                }
                subDataList.add(new ExcelMergeCellValue(weightErrorRange, 1, 1));
                addSummaryQty(summaryQtyList, index ++, weightErrorRange);

                // 各BU稱重與暫存區入庫差異 (F=A-D)
                BigDecimal allBuRubbishWeightDifferenceQty = BooleanUtil.isTrue(isScrapArea) ? buTotalWeight.subtract(totalRubbishNetWeight) : BigDecimal.ZERO;
                subDataList.add(new ExcelMergeCellValue(allBuRubbishWeightDifferenceQty, 1, 1));
                summaryCodeIndexMap.put("F", index);
                totalSummaryCodeIndexMap.put("F", index);
                addSummaryQty(summaryQtyList, index ++, allBuRubbishWeightDifferenceQty);


                // 平均每棧板差異 (S=|F/Q|)
                BigDecimal avgPalletDifference;
                if (buWeightTotalNum > 0) {
                    avgPalletDifference = allBuRubbishWeightDifferenceQty.divide(BigDecimal.valueOf(buWeightTotalNum), 4, RoundingMode.HALF_UP).abs();
                } else {
                    avgPalletDifference = BigDecimal.ZERO;
                }
                subDataList.add(new ExcelMergeCellValue(avgPalletDifference, 1, 1));
                summaryIndexDivideCountMap.put(index,
                        summaryIndexDivideCountMap.containsKey(index) ? summaryIndexDivideCountMap.get(index) + 1 : 1
                );
                totalAvgIndexSet.add(index);
                addSummaryQty(summaryQtyList, index ++, avgPalletDifference);

                // 各BU稱重與暫存區入庫差異比例 (L)
                BigDecimal allBuRubbishWeightDifferencePercentage;
                if (totalRubbishNetWeight.compareTo(BigDecimal.ZERO) == 0) {
                    allBuRubbishWeightDifferencePercentage = BigDecimal.ZERO;
                } else {
                    allBuRubbishWeightDifferencePercentage = BooleanUtil.isTrue(isScrapArea) ?
                            allBuRubbishWeightDifferenceQty.divide(totalRubbishNetWeight, 4, RoundingMode.HALF_UP)
                            : BigDecimal.ZERO;
                }
                ExcelMergeCellValue allBuRubbishWeightDifferencePercentageExcelValue = new ExcelMergeCellValue(allBuRubbishWeightDifferencePercentage, 1, 1);
                allBuRubbishWeightDifferencePercentageExcelValue.setDataFormat((short) 10);
                allBuRubbishWeightDifferencePercentageExcelValue.setDataFormatName(NumberUtil.decimalFormat("0.00%", allBuRubbishWeightDifferencePercentage));
                subDataList.add(allBuRubbishWeightDifferencePercentageExcelValue);
                summaryFormat.add(new SummaryExcelFormatVO(index, (short) 10, "0.00%"));
                summaryExpressionMap.put(index, "F/D");
                totalSummaryExpressionMap.put(index, "F/D");
                totalSummaryFormat.add(new SummaryExcelFormatVO(index, (short) 10, "0.00%"));
                addSummaryQty(summaryQtyList, index ++, allBuRubbishWeightDifferencePercentage);



                // 盤點情況（若G＞0為盤虧顯示為綠；G＜0為盤盈顯示為紅）
                // 先算下G
                BigDecimal rubbishEcusDifferenceQty = BooleanUtil.isTrue(isScrapArea) ?
                        beforeScrapAreaRemainQty.add(totalRubbishNetWeight).subtract(totalShipNetWeight).subtract(actualRemainQty)
                        : BigDecimal.ZERO;
                ExcelMergeCellValue inventroyStatus = new ExcelMergeCellValue("", 1, 1);
                inventroyStatus.setIsCenter(Boolean.TRUE);
                if (rubbishEcusDifferenceQty.compareTo(BigDecimal.ZERO) > 0) {
                    inventroyStatus.setValue("盤虧");
                    inventroyStatus.setFontColor(IndexedColors.GREEN.index);
                    inventroyStatus.setHtmlFontColor("#67C23A");
                } else if (rubbishEcusDifferenceQty.compareTo(BigDecimal.ZERO) < 0) {
                    inventroyStatus.setValue("盤盈");
                    inventroyStatus.setFontColor(IndexedColors.RED.index);
                    inventroyStatus.setHtmlFontColor("#F56C6C");
                } else {
                    inventroyStatus.setValue("");
                }
                subDataList.add(inventroyStatus);
                summarySummaryEmpty.add(index);
                totalSummarySummaryEmpty.add(index);
                addSummaryQty(summaryQtyList, index ++, BigDecimal.ZERO);


                // 暂存区与ECUS差异 G=C+D-E-P
                subDataList.add(new ExcelMergeCellValue(rubbishEcusDifferenceQty, 1, 1));
                summaryCodeIndexMap.put("G", index);
                totalSummaryCodeIndexMap.put("G", index);
                addSummaryQty(summaryQtyList, index ++, rubbishEcusDifferenceQty);

                // 暫存區與ECUS差異比例 M=G/E*100%
                BigDecimal rubbishEcusDifferencePercentage;
                if (totalShipNetWeight.compareTo(BigDecimal.ZERO) == 0) {
                    rubbishEcusDifferencePercentage = BigDecimal.ZERO;
                } else {
                    rubbishEcusDifferencePercentage = BooleanUtil.isTrue(isScrapArea) ?
                            rubbishEcusDifferenceQty.divide(totalShipNetWeight, 4, RoundingMode.HALF_UP)
                            : BigDecimal.ZERO;
                }
                bakRubbishDiffPercentageMap.put(scrapDetailClass, rubbishEcusDifferencePercentage);
                ExcelMergeCellValue rubbishEcusDifferencePercentageExcelValue = new ExcelMergeCellValue(rubbishEcusDifferencePercentage, 1, 1);
                rubbishEcusDifferencePercentageExcelValue.setDataFormat((short) 10);
                rubbishEcusDifferencePercentageExcelValue.setDataFormatName(NumberUtil.decimalFormat("0.00%", rubbishEcusDifferencePercentage));
                subDataList.add(rubbishEcusDifferencePercentageExcelValue);
                summaryExpressionMap.put(index, "G/E");
                totalSummaryExpressionMap.put(index, "G/E");
                summaryFormat.add(new SummaryExcelFormatVO(index, (short) 10, "0.00%"));
                totalSummaryFormat.add(new SummaryExcelFormatVO(index, (short) 10, "0.00%"));
                addSummaryQty(summaryQtyList, index ++, rubbishEcusDifferencePercentage);


                // 上月差異比例 M
                BigDecimal beforeRubbishEcusDifferencePercentage;
                if (beforeRubbishDiffPercentageMap.containsKey(scrapDetailClass)) {
                    beforeRubbishEcusDifferencePercentage = beforeRubbishDiffPercentageMap.get(scrapDetailClass);
                } else {
                    beforeRubbishEcusDifferencePercentage = BigDecimal.ZERO;
                }
                ExcelMergeCellValue beforeRubbishEcusDifferencePercentageExcelValue = new ExcelMergeCellValue(beforeRubbishEcusDifferencePercentage, 1, 1);
                beforeRubbishEcusDifferencePercentageExcelValue.setDataFormat((short) 10);
                beforeRubbishEcusDifferencePercentageExcelValue.setDataFormatName(NumberUtil.decimalFormat("0.00%", beforeRubbishEcusDifferencePercentage));
                subDataList.add(beforeRubbishEcusDifferencePercentageExcelValue);
                summaryFormat.add(new SummaryExcelFormatVO(index, (short) 10, "0.00%"));
                totalSummaryFormat.add(new SummaryExcelFormatVO(index, (short) 10, "0.00%"));
                addSummaryQty(summaryQtyList, index ++, beforeRubbishEcusDifferencePercentage);



                // 平均車輛差異（T=|G/J|）
                BigDecimal avgCarDifference = BigDecimal.ZERO;
                if (shipList.size() > 0) {
                    avgCarDifference = rubbishEcusDifferenceQty.divide(BigDecimal.valueOf(shipList.size()), 4, RoundingMode.HALF_UP).abs();
                }
                ExcelMergeCellValue avgCarDifferenceExcelValue = new ExcelMergeCellValue<>(avgCarDifference, 1, 1);
                subDataList.add(avgCarDifferenceExcelValue);
                summaryIndexDivideCountMap.put(index,
                        summaryIndexDivideCountMap.containsKey(index) ? summaryIndexDivideCountMap.get(index) + 1 : 1
                );
                totalAvgIndexSet.add(index);
                addSummaryQty(summaryQtyList, index ++, avgCarDifference);

                // 各BU称重与ECUS差异 I=A+B-E-P
                BigDecimal everyBuEcusDifferenceQty = BooleanUtil.isFalse(isScrapArea) ? buTotalWeight.add(buBeforeNotToRubbishWeight).subtract(totalShipNetWeight).subtract(actualRemainQty) : BigDecimal.ZERO;
                subDataList.add(new ExcelMergeCellValue(everyBuEcusDifferenceQty, 1, 1));
                summaryCodeIndexMap.put("I", index);
                totalSummaryCodeIndexMap.put("I", index);
                addSummaryQty(summaryQtyList, index ++, everyBuEcusDifferenceQty);


                // 盤點情況 （若I＞0為盤虧顯示為綠；I＜0為盤盈顯示為紅）
                ExcelMergeCellValue buInventoryStatus = new ExcelMergeCellValue("", 1, 1);
                buInventoryStatus.setIsCenter(Boolean.TRUE);
                if (everyBuEcusDifferenceQty.compareTo(BigDecimal.ZERO) > 0) {
                    buInventoryStatus.setValue("盤虧");
                    buInventoryStatus.setFontColor(IndexedColors.GREEN.index);
                    buInventoryStatus.setHtmlFontColor("#67C23A");
                } else if (everyBuEcusDifferenceQty.compareTo(BigDecimal.ZERO) < 0) {
                    buInventoryStatus.setValue("盤盈");
                    buInventoryStatus.setFontColor(IndexedColors.RED.index);
                    buInventoryStatus.setHtmlFontColor("#F56C6C");
                } else {
                    buInventoryStatus.setValue("");
                }
                subDataList.add(buInventoryStatus);
                summarySummaryEmpty.add(index);
                totalSummarySummaryEmpty.add(index);
                addSummaryQty(summaryQtyList, index ++, BigDecimal.ZERO);


                // 各BU稱重與ECUS差異比例 N=I/E*100%
                BigDecimal everyBuEcusDifferencePercentage;
                if (totalShipNetWeight.compareTo(BigDecimal.ZERO) == 0) {
                    everyBuEcusDifferencePercentage = BigDecimal.ZERO;
                } else {
                    everyBuEcusDifferencePercentage = BooleanUtil.isFalse(isScrapArea) ?
                            everyBuEcusDifferenceQty.divide(totalShipNetWeight, 4, RoundingMode.HALF_UP)
                            : BigDecimal.ZERO;
                }
                bakBuDiffPercentageMap.put(scrapDetailClass, everyBuEcusDifferencePercentage);
                ExcelMergeCellValue everyBuEcusDifferencePercentageExcelValue = new ExcelMergeCellValue(everyBuEcusDifferencePercentage, 1, 1);
                everyBuEcusDifferencePercentageExcelValue.setDataFormat((short) 10);
                everyBuEcusDifferencePercentageExcelValue.setDataFormatName(NumberUtil.decimalFormat("0.00%", everyBuEcusDifferencePercentage));
                subDataList.add(everyBuEcusDifferencePercentageExcelValue);
                summaryFormat.add(new SummaryExcelFormatVO(index, (short) 10, "0.00%"));
                summaryExpressionMap.put(index, "I/E");
                totalSummaryExpressionMap.put(index, "I/E");
                totalSummaryFormat.add(new SummaryExcelFormatVO(index, (short) 10, "0.00%"));
                addSummaryQty(summaryQtyList, index ++, everyBuEcusDifferencePercentage);


                // 上月差異比例 N
                BigDecimal beforeEveryBuEcusDifferencePercentage;
                if (beforeBuDiffPercentageMap.containsKey(scrapDetailClass)) {
                    beforeEveryBuEcusDifferencePercentage = beforeBuDiffPercentageMap.get(scrapDetailClass);
                } else {
                    beforeEveryBuEcusDifferencePercentage = BigDecimal.ZERO;
                }
                ExcelMergeCellValue beforeEveryBuEcusDifferencePercentageExcelValue = new ExcelMergeCellValue(beforeEveryBuEcusDifferencePercentage, 1, 1);
                beforeEveryBuEcusDifferencePercentageExcelValue.setDataFormat((short) 10);
                beforeEveryBuEcusDifferencePercentageExcelValue.setDataFormatName(NumberUtil.decimalFormat("0.00%", beforeEveryBuEcusDifferencePercentage));
                subDataList.add(beforeEveryBuEcusDifferencePercentageExcelValue);
                summaryFormat.add(new SummaryExcelFormatVO(index, (short) 10, "0.00%"));
                totalSummaryFormat.add(new SummaryExcelFormatVO(index, (short) 10, "0.00%"));
                addSummaryQty(summaryQtyList, index ++, beforeEveryBuEcusDifferencePercentage);


                // 平均車輛差異(BU)（U=|I/J|）
                BigDecimal buAvgCarDifference = BigDecimal.ZERO;
                if (shipList.size() > 0) {
                    buAvgCarDifference = everyBuEcusDifferenceQty.divide(BigDecimal.valueOf(shipList.size()), 4, RoundingMode.HALF_UP).abs();
                }
                ExcelMergeCellValue buAvgCarDifferenceExcelValue = new ExcelMergeCellValue<>(buAvgCarDifference, 1, 1);
                subDataList.add(buAvgCarDifferenceExcelValue);
                summaryIndexDivideCountMap.put(index,
                        summaryIndexDivideCountMap.containsKey(index) ? summaryIndexDivideCountMap.get(index) + 1 : 1
                );
                totalAvgIndexSet.add(index);
                addSummaryQty(summaryQtyList, index ++, buAvgCarDifference);

                // ECUS系统出厂车辆数
                subDataList.add(new ExcelMergeCellValue(BigDecimal.valueOf(shipList.size()), 1, 1));
                addSummaryQty(summaryQtyList, index ++, BigDecimal.valueOf(shipList.size()));
                // 误差范围
                BigDecimal errorValue = BigDecimal.valueOf(shipList.size()).multiply(BigDecimal.valueOf(60));
                subDataList.add(new ExcelMergeCellValue(errorValue, 1, 1));
                addSummaryQty(summaryQtyList, index ++, errorValue);
                // 是否超出误差范围
                String hasMoreThenErrorValueRange = BooleanUtil.isTrue(isScrapArea)
                        ? rubbishEcusDifferenceQty.abs().compareTo(errorValue.abs()) > 0 ? "Y" : "N"
                        : everyBuEcusDifferenceQty.abs().compareTo(errorValue.abs()) > 0 ? "Y" : "N";
                ExcelMergeCellValue moreThenRangeExcelValue = new ExcelMergeCellValue(hasMoreThenErrorValueRange, 1, 1);
                moreThenRangeExcelValue.setIsCenter(Boolean.TRUE);
                subDataList.add(moreThenRangeExcelValue);
                addSummaryQty(summaryQtyList, index, BigDecimal.ZERO);
                summarySummaryEmpty.add(index);
                totalSummarySummaryEmpty.add(index);
                index ++;

                // 各BU称重与暂存区入库差异说明
                subDataList.add(new ExcelMergeCellValue("", 1, 1));
                addSummaryQty(summaryQtyList, index, BigDecimal.ZERO);
                summarySummaryEmpty.add(index);
                totalSummarySummaryEmpty.add(index);
                index ++;

                // 暂存区与东大门差异说明
                subDataList.add(new ExcelMergeCellValue("", 1, 1));
                addSummaryQty(summaryQtyList, index, BigDecimal.ZERO);
                summarySummaryEmpty.add(index);
                totalSummarySummaryEmpty.add(index);
                index ++;
                dataList.add(subDataList);
            }
            Map<String, Object> summaryCtx = new HashMap<>();
            summaryCodeIndexMap.keySet().forEach(code -> {
                Integer index = summaryCodeIndexMap.get(code);
                BigDecimal val = summaryQtyList.get(index);
                summaryCtx.put(code, val);
            });

            for (int i = 0; i < summaryQtyList.size(); i ++) {
                ExcelMergeCellValue excelMergeCellValue;
                if (summarySummaryEmpty.contains(i)) {
                    excelMergeCellValue = new ExcelMergeCellValue("", 1, 1, IndexedColors.PALE_BLUE.getIndex());
                    summaryList.add(excelMergeCellValue);
                    addSummaryQty(totalSummaryQtyList, i, BigDecimal.ZERO);
                } else if (summaryIndexDivideCountMap.containsKey(i)) {
                    BigDecimal divideValue = summaryQtyList.get(i).divide(BigDecimal.valueOf(summaryIndexDivideCountMap.get(i)), 4, RoundingMode.HALF_UP);
                    addSummaryQty(totalSummaryQtyList, i, divideValue);
                    excelMergeCellValue = new ExcelMergeCellValue(divideValue, 1, 1,  IndexedColors.PALE_BLUE.getIndex());
                    summaryList.add(excelMergeCellValue);
                } else if (summaryExpressionMap.containsKey(i)) {
                    Object calcResult = null;
                    try {
                        calcResult = ExpressionUtil.eval(summaryExpressionMap.get(i), summaryCtx);
                    } catch (Exception e) {
                        log.error("{} {}", summaryExpressionMap.get(i), JSONUtil.toJsonStr(summaryCtx), e);
                    }
                    if (ObjectUtil.isNull(calcResult)) {
                        calcResult = BigDecimal.ZERO;
                    }
                    addSummaryQty(totalSummaryQtyList, i, (BigDecimal) calcResult);
                    excelMergeCellValue = new ExcelMergeCellValue(calcResult, 1, 1,  IndexedColors.PALE_BLUE.getIndex());
                    summaryList.add(excelMergeCellValue);
                } else {
                    addSummaryQty(totalSummaryQtyList, i, summaryQtyList.get(i));
                    excelMergeCellValue = new ExcelMergeCellValue(summaryQtyList.get(i), 1, 1,  IndexedColors.PALE_BLUE.getIndex());
                    summaryList.add(excelMergeCellValue);
                }

                if (totalAvgIndexSet.contains(i)) {
                    totalSummaryIndexDivideCountMap.put(i,
                            totalSummaryIndexDivideCountMap.containsKey(i) ? totalSummaryIndexDivideCountMap.get(i) + 1 : 1);
                }

                int finalI = i;
                SummaryExcelFormatVO summaryExcelFormatVO = summaryFormat.stream()
                        .filter(item -> item.getSummaryIndex() == finalI)
                        .findFirst().orElse(null);
                if (ObjectUtil.isNotNull(summaryExcelFormatVO)) {
                    excelMergeCellValue.setDataFormat(summaryExcelFormatVO.getDataFormat());
                    if (excelMergeCellValue.getValue() instanceof BigDecimal) {
                        excelMergeCellValue.setDataFormatName(NumberUtil.decimalFormat(summaryExcelFormatVO.getFormat(), excelMergeCellValue.getValue()));
                    }
                }
            }



            dataList.add(summaryList);
        });

        // 外发厂，单独写这里
        List<ExcelMergeCellValue> outShipPlantRow = ListUtil.toList();
        outShipPlantRow.add(new ExcelMergeCellValue("外發廠", 1, 2));
        Integer summaryIndex = 0;
        BigDecimal outShipPlantBuTotalWeight = BigDecimal.ZERO;
        for (String buName : buNameList) {
            List<SdsDepartmentConfig> subDepartmentCodeConfigList = buDepartmentCodeMap.get(buName);
            List<String> subDepartmentCodeList = subDepartmentCodeConfigList.stream().map(item -> item.getDepartmentCode()).collect(Collectors.toList());
            // 外发厂BU称重先默认0
            List<SdsSteelScrapWeightInfo> buWeightInfoList = steelScrapWeightInfoList.stream()
                    .filter(item -> "OUT-SHIP".equals(item.getSource()))
                    .filter(item -> subDepartmentCodeList.contains(item.getDepartmentCode()))
                    .collect(Collectors.toList());
            BigDecimal buWeight = buWeightInfoList.stream().map(item -> item.getNetWeight()).reduce(BigDecimal.ZERO, BigDecimal::add);
            outShipPlantRow.add(new ExcelMergeCellValue(buWeight, 1, 1));
            addSummaryQty(totalSummaryQtyList, summaryIndex ++, buWeight);
            outShipPlantBuTotalWeight = outShipPlantBuTotalWeight.add(buWeight);
        }

        // 外发厂本月
        List<SdsSteelScrapWeightInfo> buWeightInfoList = steelScrapWeightInfoList.stream()
                .filter(item -> "OUT-SHIP".equals(item.getSource()))
                .collect(Collectors.toList());
        // 上月
        List<SdsSteelScrapWeightInfo> buBeforeWeightInfoList = beforeSteelScrapWeightInfoList.stream()
                .filter(item -> "OUT-SHIP".equals(item.getSource()))
                .collect(Collectors.toList());

        // 上月外发厂出货数据列表
        List<SdsSteelScrapShipHeader> beforeShipList = beforeSteelScrapShipHeaderList.stream()
                .filter(item -> outShipPlantStr.contains(item.getAreaCode()))
                .collect(Collectors.toList());
        // 上月外发厂出货量
        BigDecimal beforeTotalShipNetWeight = beforeShipList.stream()
                .map(item -> item.getScrapNetWeight())
                .filter(item -> ObjectUtil.isNotNull(item))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        // 当月外发厂出货数据列表
        List<SdsSteelScrapShipHeader> shipList = steelScrapShipHeaderList.stream()
                .filter(item -> outShipPlantStr.contains(item.getAreaCode()))
                .collect(Collectors.toList());

        // 本月外发厂出货量
        BigDecimal totalShipNetWeight = shipList.stream()
                .map(item -> item.getScrapNetWeight())
                .filter(item -> ObjectUtil.isNotNull(item))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        // BU 总称重
        outShipPlantRow.add(new ExcelMergeCellValue(outShipPlantBuTotalWeight, 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex ++, outShipPlantBuTotalWeight);
        // BU暂存区已称重剩余废料 （先默认0）
        outShipPlantRow.add(new ExcelMergeCellValue(BigDecimal.ZERO, 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex ++, BigDecimal.ZERO);
        // 盘点暂存区剩余废料 （先默认0）
        outShipPlantRow.add(new ExcelMergeCellValue(BigDecimal.ZERO, 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex ++, BigDecimal.ZERO);
        // 暂存区入库量
        outShipPlantRow.add(new ExcelMergeCellValue(BigDecimal.ZERO, 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex ++, BigDecimal.ZERO);
        // ECUS系統
        outShipPlantRow.add(new ExcelMergeCellValue(totalShipNetWeight, 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex ++, totalShipNetWeight);

        // 本月BU剩餘量 O=A+B-E
        BigDecimal buRemainQty = outShipPlantBuTotalWeight.add(BigDecimal.ZERO).subtract(totalShipNetWeight);
        outShipPlantRow.add(new ExcelMergeCellValue(buRemainQty, 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex ++, buRemainQty);
        // 本月暂存区剩余量 H=C+D-E
        BigDecimal nowMonthRubbishRemainQty = BigDecimal.ZERO;
        outShipPlantRow.add(new ExcelMergeCellValue(nowMonthRubbishRemainQty, 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex ++, nowMonthRubbishRemainQty);
        // 本月實物剩餘量 P
        BigDecimal actualRemainQty = BigDecimal.ZERO;
        outShipPlantRow.add(new ExcelMergeCellValue(actualRemainQty, 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex ++, BigDecimal.ZERO);

        // 该类别是否入暂存区
        outShipPlantRow.add(new ExcelMergeCellValue("", 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex, BigDecimal.ZERO);
        summaryIndex ++;

        // 各BU稱重次數（Q）
        Long buWeightTotalNum = steelScrapWeightInfoList.stream()
                .filter(item -> "OUT-SHIP".equals(item.getSource()))
                .count();
        outShipPlantRow.add(new ExcelMergeCellValue(BigDecimal.valueOf(buWeightTotalNum), 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex ++, BigDecimal.valueOf(buWeightTotalNum));
        // 誤差範圍 R（包材|R|=|Q*2.5|;金屬|R|=|Q*5.5|）
        BigDecimal weightErrorRange = BigDecimal.ZERO;
        outShipPlantRow.add(new ExcelMergeCellValue(weightErrorRange, 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex ++, weightErrorRange);
        // 各BU稱重與暫存區入庫差異 (F=A-D)
        BigDecimal allBuRubbishWeightDifferenceQty = BigDecimal.ZERO;
        outShipPlantRow.add(new ExcelMergeCellValue(allBuRubbishWeightDifferenceQty, 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex ++, allBuRubbishWeightDifferenceQty);

        // 平均每棧板差異 (S=|F/Q|)
        BigDecimal avgPalletDifference = BigDecimal.ZERO;
        outShipPlantRow.add(new ExcelMergeCellValue(avgPalletDifference, 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex ++, avgPalletDifference);

        // 各BU稱重與暫存區入庫差異比例 L
        outShipPlantRow.add(new ExcelMergeCellValue(BigDecimal.ZERO, 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex ++, BigDecimal.ZERO);
        // 盤點情況
        ExcelMergeCellValue inventroyStatus = new ExcelMergeCellValue("", 1, 1);
        inventroyStatus.setIsCenter(Boolean.TRUE);
        outShipPlantRow.add(inventroyStatus);
        addSummaryQty(totalSummaryQtyList, summaryIndex ++, BigDecimal.ZERO);
        // 暂存区与ECUS差异
        BigDecimal rubbishEcusDifferenceQty = BigDecimal.ZERO;
        outShipPlantRow.add(new ExcelMergeCellValue(rubbishEcusDifferenceQty, 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex ++, rubbishEcusDifferenceQty);
        // 暫存區與ECUS差異比例
        outShipPlantRow.add(new ExcelMergeCellValue(BigDecimal.ZERO, 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex ++, BigDecimal.ZERO);
        // 上月差異比例 M
        outShipPlantRow.add(new ExcelMergeCellValue(BigDecimal.ZERO, 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex ++, BigDecimal.ZERO);
        // 平均車輛差異
        outShipPlantRow.add(new ExcelMergeCellValue(BigDecimal.ZERO, 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex ++, BigDecimal.ZERO);
        // 各BU称重与ECUS差异
        BigDecimal everyBuEcusDifferenceQty = BigDecimal.ZERO;
        outShipPlantRow.add(new ExcelMergeCellValue(everyBuEcusDifferenceQty, 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex ++, everyBuEcusDifferenceQty);
        // 盤點情況 N
        ExcelMergeCellValue buInventroyStatus = new ExcelMergeCellValue("", 1, 1);
        buInventroyStatus.setIsCenter(Boolean.TRUE);
        outShipPlantRow.add(buInventroyStatus);
        addSummaryQty(totalSummaryQtyList, summaryIndex ++, BigDecimal.ZERO);
        // 各BU稱重與ECUS差異比例 N
        outShipPlantRow.add(new ExcelMergeCellValue(BigDecimal.ZERO, 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex ++, BigDecimal.ZERO);
        // 上月差異比例 N
        outShipPlantRow.add(new ExcelMergeCellValue(BigDecimal.ZERO, 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex ++, BigDecimal.ZERO);
        // 平均車輛差異 U
        outShipPlantRow.add(new ExcelMergeCellValue(BigDecimal.ZERO, 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex ++, BigDecimal.ZERO);
        // ECUS系统出厂车辆数
        outShipPlantRow.add(new ExcelMergeCellValue(BigDecimal.valueOf(shipList.size()), 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex ++, BigDecimal.valueOf(shipList.size()));
        // 误差范围
        BigDecimal errorValue = BigDecimal.valueOf(shipList.size()).multiply(BigDecimal.valueOf(60));
        outShipPlantRow.add(new ExcelMergeCellValue(errorValue, 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex ++, errorValue);
        // 是否超出误差范围
        ExcelMergeCellValue moreThenErrorValueRangeExcelValue = new ExcelMergeCellValue((rubbishEcusDifferenceQty.abs().compareTo(errorValue) > 0 || everyBuEcusDifferenceQty.abs().compareTo(errorValue) > 0) ? "Y" : "N", 1, 1);
        moreThenErrorValueRangeExcelValue.setIsCenter(Boolean.TRUE);
        outShipPlantRow.add(moreThenErrorValueRangeExcelValue);
        addSummaryQty(totalSummaryQtyList, summaryIndex, BigDecimal.ZERO);
        summaryIndex ++;
        // 各BU称重与暂存区入库差异说明
        outShipPlantRow.add(new ExcelMergeCellValue("", 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex, BigDecimal.ZERO);
        summaryIndex ++;
        // 暂存区与东大门差异说明
        outShipPlantRow.add(new ExcelMergeCellValue("", 1, 1));
        addSummaryQty(totalSummaryQtyList, summaryIndex, BigDecimal.ZERO);
        summaryIndex ++;

        dataList.add(outShipPlantRow);

        Map<String, Object> totalSummaryCtx = new HashMap<>();
        totalSummaryCodeIndexMap.keySet().forEach(code -> {
            Integer index = totalSummaryCodeIndexMap.get(code);
            BigDecimal val = totalSummaryQtyList.get(index);
            totalSummaryCtx.put(code, val);
        });

        for (int i = 0; i < totalSummaryQtyList.size(); i ++) {
            ExcelMergeCellValue excelMergeCellValue;
            if (totalSummarySummaryEmpty.contains(i)) {
                excelMergeCellValue = new ExcelMergeCellValue("", 1, 1, IndexedColors.BLUE_GREY.getIndex());
                totalSummaryList.add(excelMergeCellValue);
            } else if (totalSummaryIndexDivideCountMap.containsKey(i)) {
                BigDecimal divideValue = totalSummaryQtyList.get(i).divide(BigDecimal.valueOf(totalSummaryIndexDivideCountMap.get(i)), 4, RoundingMode.HALF_UP);
                excelMergeCellValue = new ExcelMergeCellValue(divideValue, 1, 1,  IndexedColors.BLUE_GREY.getIndex());
                totalSummaryList.add(excelMergeCellValue);
            } else if (totalSummaryExpressionMap.containsKey(i)) {
                Object calcResult = null;
                try {
                    calcResult = ExpressionUtil.eval(totalSummaryExpressionMap.get(i), totalSummaryCtx);
                } catch (Exception e) {
                    log.error("{} {}", totalSummaryExpressionMap.get(i), JSONUtil.toJsonStr(totalSummaryCtx), e);
                }
                if (ObjectUtil.isNull(calcResult)) {
                    calcResult = BigDecimal.ZERO;
                }
                excelMergeCellValue = new ExcelMergeCellValue(calcResult, 1, 1,  IndexedColors.BLUE_GREY.getIndex());
                totalSummaryList.add(excelMergeCellValue);
            } else {
                excelMergeCellValue = new ExcelMergeCellValue(totalSummaryQtyList.get(i), 1, 1,  IndexedColors.BLUE_GREY.getIndex());
                totalSummaryList.add(excelMergeCellValue);
            }

            int finalI = i;
            SummaryExcelFormatVO summaryExcelFormatVO = totalSummaryFormat.stream()
                    .filter(item -> item.getSummaryIndex() == finalI)
                    .findFirst().orElse(null);
            if (ObjectUtil.isNotNull(summaryExcelFormatVO)) {
                excelMergeCellValue.setDataFormat(summaryExcelFormatVO.getDataFormat());
                if (excelMergeCellValue.getValue() instanceof BigDecimal) {
                    excelMergeCellValue.setDataFormatName(NumberUtil.decimalFormat(summaryExcelFormatVO.getFormat(), excelMergeCellValue.getValue()));
                }
            }
        }
        dataList.add(totalSummaryList);
        // 除BU动态外，其它行加起来31行
        Integer totalColNum = 31 + buNameList.size();

        result.addAll(ListUtil.toList(getLine1(totalColNum, displayStartDate, displayEndDate), getLine2(totalColNum), getLine3(totalColNum)));
        result.add(getLine4(buNameList));
        result.addAll(dataList);

        preHandle(result, totalColNum);

        return inventoryReportDTO;
    }

    private GenerateInventoryReportDTO generateInventoryReport(SteelScrapInventoryReportQueryVO vo) {
        GenerateInventoryReportDTO dto = new GenerateInventoryReportDTO();
        XSSFWorkbook workbook = new XSSFWorkbook();
        dto.setWorkbook(workbook);
        Sheet sheet = workbook.createSheet("Sheet1");
        sheet.createFreezePane(2, 4, 2, 4);
        InventoryReportDTO inventoryReportDTO = selectInventoryReport(vo);
        BeanUtil.copyProperties(inventoryReportDTO, dto);
        List<List<ExcelMergeCellValue>> titleList = inventoryReportDTO.getList();
        Integer totalColNum = titleList.get(0).size();
        int index = 2;
        sheet.setColumnWidth(0, 15*256);
        sheet.setColumnWidth(1, 43*256);

        for (int i = 0; i < totalColNum - 28; i ++) {
            sheet.setColumnWidth(index, 15*256);
            index ++;
        }
        List<Integer> remainColWidth = ListUtil.toList(
                18,18,18,22,18,18,18,18,18,20,20,18,22,22,29,18,22,29,18,22,22,22,22,18,18,18,20,18,18
        );
        for (int i = 0; i < remainColWidth.size(); i ++) {
            sheet.setColumnWidth(index, remainColWidth.get(i) * 256);
            index ++;
        }

        for (int i = 0; i < titleList.size(); i ++) {
            List<ExcelMergeCellValue> rowDataList = titleList.get(i);
            Row row = sheet.createRow(i);
            if (i == 0) {
                row.setHeightInPoints((short) 22);
            } else if (i == 1) {
                row.setHeightInPoints((short) 22);
            } else if (i == 3) {
                row.setHeightInPoints((short) 58);
            }
            for (int j = 0; j < rowDataList.size(); j ++) {
                ExcelMergeCellValue data = rowDataList.get(j);
                if (data.getRowSpan() != 0 && data.getColSpan() != 0) {
                    if (data.getRowSpan() != 1 || data.getColSpan() != 1) {
                        CellRangeAddress cellRangeAddress = new CellRangeAddress(i, i + data.getRowSpan() -1, j, j + data.getColSpan() - 1);
                        sheet.addMergedRegion(cellRangeAddress);
                    }
                }
                Cell cell = row.createCell(j);
                if (data.getValue() instanceof BigDecimal) {
                    cell.setCellValue(((BigDecimal) data.getValue()).doubleValue());
                } else {
                    cell.setCellValue(StrUtil.toString(data.getValue()));
                }

                CellStyle style = workbook.createCellStyle();

                style.setBorderBottom(BorderStyle.THIN);
                style.setBorderLeft(BorderStyle.THIN);
                style.setBorderTop(BorderStyle.THIN);
                style.setBorderRight(BorderStyle.THIN);
                style.setTopBorderColor(IndexedColors.BLACK.index);
                style.setBottomBorderColor(IndexedColors.BLACK.index);
                style.setLeftBorderColor(IndexedColors.BLACK.index);
                style.setRightBorderColor(IndexedColors.BLACK.index);

                if (ObjectUtil.isNotNull(data.getBackgroundColor())) {
                    style.setFillForegroundColor(data.getBackgroundColor());
                    style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
                }

                if (ObjectUtil.isNotNull(data.getFontColor())) {
                    Font font = workbook.createFont();
                    font.setColor(data.getFontColor());
                    style.setFont(font);
                }

                if (BooleanUtil.isTrue(data.getIsCenter())) {
                    style.setAlignment(HorizontalAlignment.CENTER);
                    style.setVerticalAlignment(VerticalAlignment.CENTER);
                }

                if (i < 4 || j == 0) {
                    style.setAlignment(HorizontalAlignment.CENTER);
                    style.setVerticalAlignment(VerticalAlignment.CENTER);
                    Font font = workbook.createFont();
                    font.setBold(true);
                    if (i == 0) {
                        font.setFontHeightInPoints((short) 16);
                    }
                    style.setFont(font);
                    style.setWrapText(true);
                }
//                if (i >= 4 && (totalColNum - 3 == j || totalColNum - 12 == j)) {
//                    style.setAlignment(HorizontalAlignment.CENTER);
//                    style.setVerticalAlignment(VerticalAlignment.CENTER);
//                }
                if (ObjectUtil.isNotNull(data.getDataFormat())) {
                    style.setDataFormat(data.getDataFormat());
                }
                cell.setCellStyle(style);
            }
        }

        return dto;
    }

    @Override
    public void exportInventoryReport(SteelScrapInventoryReportQueryVO vo, HttpServletResponse response) {
        GenerateInventoryReportDTO generateInventoryReportDTO = generateInventoryReport(vo);
        XSSFWorkbook workbook = generateInventoryReportDTO.getWorkbook();
        OutputStream outputStream = null;
        try {
            String fileName = "盘点报表" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            outputStream = new BufferedOutputStream(response.getOutputStream());
            workbook.write(outputStream);
            outputStream.flush();
            outputStream.close();
        } catch (Exception e) {
            log.error("导出盘点报表失败", e);
        }
    }

    void preHandle(List<List<ExcelMergeCellValue>> titleList, Integer totalColNum) {
        Set<String> set = new HashSet();
        for (int i = 0; i < titleList.size(); i ++) {
            List<ExcelMergeCellValue> rowDataList = titleList.get(i);

            List<ExcelMergeCellValue> newRowDataList = ListUtil.toList();


            for (int j = 0; j < totalColNum;) {
                String k = String.valueOf(i) + "_" + String.valueOf(j);
                if (set.contains(k)) {
                    newRowDataList.add(new ExcelMergeCellValue("", 0, 0));
                    j ++;
                    continue;
                }
                ExcelMergeCellValue data = rowDataList.remove(0);
                newRowDataList.add(data);
                if (data.getColSpan() > 1 && data.getRowSpan() > 1) {
                    for (int n = 1; n < data.getColSpan(); n ++) {
                        newRowDataList.add(new ExcelMergeCellValue("", 0, 0));
                    }
                    for (int n = 0; n < data.getColSpan(); n ++) {
                        if (data.getRowSpan() > 1) {
                            for (int nr = 1; nr < data.getRowSpan(); nr ++) {
                                set.add(String.valueOf(i + nr) + "_" + String.valueOf(j + n));
                            }
                        }
                    }

                } else if (data.getColSpan() > 1) {
                    for (int n = 1; n < data.getColSpan(); n ++) {
                        newRowDataList.add(new ExcelMergeCellValue("", 0, 0));
                    }
                } else if (data.getRowSpan() > 1) {
                    for (int nr = 1; nr < data.getRowSpan(); nr ++) {
                        set.add(String.valueOf(i + nr) + "_" + String.valueOf(j));
                    }
                }


                j = j + data.getColSpan();


            }
            titleList.set(i, newRowDataList);
        }


    }

    // 接收单个元素
    @SafeVarargs
    public static <T> List<T> Rows(T... elements) {
        return new ArrayList<>(Arrays.asList(elements));
    }

    // 接收 List 和 单个元素
    public static <T> List<T> Rows(List<T> list, T element) {
        List<T> result = new ArrayList<>(list);
        result.add(element);
        return result;
    }

    // 接收多个 List 和 多个元素
    public static <T> List<T> Rows(List<T> list, T... elements) {
        List<T> result = new ArrayList<>(list);
        result.addAll(Arrays.asList(elements));
        return result;
    }

    private List<ExcelMergeCellValue> getLine1(Integer totalColNum, LocalDateTime startDate, LocalDateTime endDate) {
        List<ExcelMergeCellValue> line = ListUtil.toList();
        ExcelMergeCellValue title = new ExcelMergeCellValue(String.format("%s--%s廢料報告", startDate.format(DateTimeFormatter.ofPattern("yyyy年M月d日")), endDate.format(DateTimeFormatter.ofPattern("yyyy年M月d日"))), 1, totalColNum);
        line.add(title);
        return line;
    }

    private List<ExcelMergeCellValue> getLine2(Integer totalColNum) {

        ExcelMergeCellValue cell1 = new ExcelMergeCellValue("類別", 3, 1);
        ExcelMergeCellValue cell2 = new ExcelMergeCellValue("", 1, 1);
        ExcelMergeCellValue cell3 = new ExcelMergeCellValue("", 1, totalColNum - 23);
        ExcelMergeCellValue cell4 = new ExcelMergeCellValue("該類別是否入暫存區", 3, 1);
        ExcelMergeCellValue cell5 = new ExcelMergeCellValue("入暫存區廢料", 2, 10);
        ExcelMergeCellValue cell6 = new ExcelMergeCellValue("不入暫存區廢料", 2, 5);
        ExcelMergeCellValue cell7 = new ExcelMergeCellValue("ECUS與暫存區誤差", 2, 3);
        ExcelMergeCellValue cell8 = new ExcelMergeCellValue("各BU稱重與暫存區入庫差異說明", 3, 1);
        ExcelMergeCellValue cell9 = new ExcelMergeCellValue("暫存區與東大門差異說明", 3, 1);
        List<ExcelMergeCellValue> line = ListUtil.toList(
                cell1, cell2,
                cell3,cell4,
                cell5, cell6,
                cell7,
                cell8, cell9
        );
        return line;
    }

    private List<ExcelMergeCellValue> getLine3(Integer totalColNum) {
        ExcelMergeCellValue cell1 = new ExcelMergeCellValue("分類", 2, 1);
        ExcelMergeCellValue cell2 = new ExcelMergeCellValue("各BU   SDS系統稱重", 1, totalColNum - 30);
        ExcelMergeCellValue cell3 = new ExcelMergeCellValue("上月剩餘", 1, 2);
        ExcelMergeCellValue cell4 = new ExcelMergeCellValue("暫存區入庫量\n" +
                "(D)", 2, 1);
        ExcelMergeCellValue cell5 = new ExcelMergeCellValue("ECUS系統\n" +
                "(E)", 2, 1);
        ExcelMergeCellValue cell6 = new ExcelMergeCellValue("本月BU剩餘量（O=A+B-E)", 2, 1);
        ExcelMergeCellValue cell7 = new ExcelMergeCellValue("本月暫存區剩餘量（H=C+D-E)", 2, 1);
        ExcelMergeCellValue cell8 = new ExcelMergeCellValue("本月實物剩餘量（P）", 2, 1);
        List<ExcelMergeCellValue> line = ListUtil.toList(
                cell1,cell2,cell3,cell4, cell5, cell6, cell7, cell8
        );
        return line;
    }

    private List<ExcelMergeCellValue> getLine4(List<String> buNameList) {
        return Rows(
                buNameList.stream()
                        .map(buName -> new ExcelMergeCellValue(buName, 1, 1)).collect(Collectors.toList()),
                new ExcelMergeCellValue("各BU匯總\n" +
                        "(A)", 1, 1),
                new ExcelMergeCellValue("BU暫存區已稱重剩餘廢料（B）", 1, 1),
                new ExcelMergeCellValue("盤點暫存區剩餘廢料\n" +
                        "（C）", 1, 1),
                new ExcelMergeCellValue("各BU稱重次數（Q）", 1, 1),
                new ExcelMergeCellValue("誤差範圍R\n" +
                        "（包材|R|=|Q*2.5|;" + "金屬|R|=|Q*5.5|）", 1, 1),
                new ExcelMergeCellValue("各BU稱重與暫存區入庫差異\n" +
                "(F=A-D)", 1, 1),
                new ExcelMergeCellValue("平均每棧板差異\n" +
                        "(S=|F/Q|)", 1, 1),
                new ExcelMergeCellValue("各BU稱重與暫存區入庫差異比例\n" +
                        "（L=F/D*100%)", 1, 1),
                new ExcelMergeCellValue("盤點情況\n" +
                        "（若G＞0為盤虧顯示為綠；\n" +
                        "G＜0為盤盈顯示為紅）", 1, 1),
                new ExcelMergeCellValue("暫存區與ECUS差異\n" +
                        "(G=C+D-E-P)", 1, 1),
                new ExcelMergeCellValue("暫存區與ECUS差異比例\n" +
                        "(M=G/E*100%)", 1, 1),
                new ExcelMergeCellValue("上月差異比例（M）", 1, 1),
                new ExcelMergeCellValue("平均車輛差異\n" +
                        "（T=|G/J|）", 1, 1),
                new ExcelMergeCellValue("各BU稱重與ECUS差異\n" +
                        "（I=A+B-E-P）", 1, 1),
                new ExcelMergeCellValue("盤點情況\n" +
                        "（若I＞0為盤虧顯示為綠；\n" +
                        "I＜0為盤盈顯示為紅）", 1, 1),
                new ExcelMergeCellValue("各BU稱重與ECUS差異比例\n" +
                        "(N=I/E*100%)", 1, 1),
                new ExcelMergeCellValue("上月差異比例（N）", 1, 1),
                new ExcelMergeCellValue("平均車輛差異\n" +
                        "（U=|I/J|）", 1, 1),
                new ExcelMergeCellValue("ECUS系統出廠車輛數(J)", 1, 1),
                new ExcelMergeCellValue("誤差範圍(K=J*60)", 1, 1),
                new ExcelMergeCellValue("是否超出誤差範圍\n" +
                        "|G|>|K|;|I|>|K|", 1, 1)
        );
    }

    @Override
    public void archiveInventoryReport(SteelScrapInventoryReportQueryVO vo) {
        GenerateInventoryReportDTO dto = generateInventoryReport(vo);
        XSSFWorkbook workbook = dto.getWorkbook();
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            String fileName = "盘点报表" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
            workbook.write(outputStream);
            SdsFileDownloadLog fileDownloadLog = fileDownloadLogService.uploadFile("ARCHIVE_INVENTORY_REPORT", fileName, WebContextUtil.getCurrentStaffCode(), outputStream.toByteArray());
            SdsSteelArchiveInventoryInfo sdsSteelArchiveInventoryInfo = new SdsSteelArchiveInventoryInfo();
            sdsSteelArchiveInventoryInfo.setFilename(fileName);
            sdsSteelArchiveInventoryInfo.setLink(fileDownloadLog.getLink());
            sdsSteelArchiveInventoryInfo.setFileId(fileDownloadLog.getFileId());
            sdsSteelArchiveInventoryInfo.setYear(dto.getYear());
            sdsSteelArchiveInventoryInfo.setMonth(dto.getMonth());
            sdsSteelArchiveInventoryInfo.setBuDiffPercentage(JSONUtil.toJsonStr(dto.getBuDiffPercentage()));
            sdsSteelArchiveInventoryInfo.setRubbishDiffPercentage(JSONUtil.toJsonStr(dto.getRubbishDiffPercentage()));
            sdsSteelArchiveInventoryInfo.setTableData(JSONUtil.toJsonStr(dto.getList()));
            steelArchiveInventoryInfoMapper.insert(sdsSteelArchiveInventoryInfo);
        } catch (Exception e) {
            log.error("归档固废盘点报表异常", e);
        }
    }
}
