package com.maxnerva.cloudmes.models.entity.waste;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * <p>
 * 入库拒收处理表
 * </p>
 *
 * @author likun
 * @since 2025-05-16
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="SdsHazardousWasteReject对象", description="入库拒收处理表")
public class SdsHazardousWasteReject extends BaseEntity<SdsHazardousWasteReject> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "组织")
    private String orgCode;

    @ApiModelProperty(value = "废物俗称")
    private String hazardousWasteName;

    @ApiModelProperty(value = "申请部门")
    private String depName;

    @ApiModelProperty(value = "费用代码")
    private String costCode;

    @ApiModelProperty(value = "单据状态")
    private String status;

    @ApiModelProperty(value = "单号")
    private String docNo;

    @ApiModelProperty(value = "单据id")
    private Integer docId;

    @ApiModelProperty(value = "单据类型")
    private String docType;

    @ApiModelProperty(value = "SDS料号")
    private String hazardousWasteNo;

    @ApiModelProperty(value = "栈板重量")
    private BigDecimal palletWeight;

    @ApiModelProperty(value = "产废毛重")
    private BigDecimal applyGrossWeight;

    @ApiModelProperty(value = "产废净重")
    private BigDecimal applyNetWeight;

    @ApiModelProperty(value = "产废称重人")
    private String weightEmp;

    @ApiModelProperty(value = "产废称重时间")
    private LocalDateTime weightDt;

    @ApiModelProperty(value = "入库毛重")
    private BigDecimal instoreGrossWeight;

    @ApiModelProperty(value = "入库净重")
    private BigDecimal instoreNetWeight;

    @ApiModelProperty(value = "入库人")
    private String instoreEmp;

    @ApiModelProperty(value = "入库时间")
    private LocalDateTime instoreDt;

    @ApiModelProperty(value = "拒收原因")
    private String rejectReasonType;

    @ApiModelProperty(value = "拒收人")
    private String rejectEmpNo;

    @ApiModelProperty(value = "拒收时间")
    private LocalDateTime rejectDt;

    @ApiModelProperty(value = "处理人")
    private String handleEmpNo;

    @ApiModelProperty(value = "处理时间")
    private LocalDateTime handleDt;

    @ApiModelProperty(value = "处理时间")
    private String handleMethod;

    @ApiModelProperty(value = "产废图片")
    private String imageUrlList;

    @ApiModelProperty(value = "拒收图片")
    private String rejectImageList;
}
