package com.maxnerva.cloudmes.controller.plan;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.plan.PlanInfoDTO;
import com.maxnerva.cloudmes.models.vo.plan.PlanFlownetApprovalVO;
import com.maxnerva.cloudmes.models.vo.plan.PlanInfoQueryVO;
import com.maxnerva.cloudmes.models.vo.plan.PlanInfoSaveVO;
import com.maxnerva.cloudmes.models.vo.plan.PlanInfoUpdateVO;
import com.maxnerva.cloudmes.service.plan.ISdsHazardousWastePlanInfoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @ClassName PlanInfoController
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/8
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "年度计划管理")
@Slf4j
@RestController
@RequestMapping("/planInfo")
public class PlanInfoController {

    @Resource
    private ISdsHazardousWastePlanInfoService sdsHazardousWastePlanInfoService;

    @ApiOperation("新增")
    @PostMapping("/save")
    public R<Void> savePlanInfo(@RequestBody PlanInfoSaveVO planInfoSaveVO) {
        sdsHazardousWastePlanInfoService.savePlanInfo(planInfoSaveVO);
        return R.ok();
    }

    @ApiOperation("编辑")
    @PutMapping("/update")
    public R<Void> updatePlanInfo(@RequestBody PlanInfoUpdateVO planInfoUpdateVO) {
        sdsHazardousWastePlanInfoService.updatePlanInfo(planInfoUpdateVO);
        return R.ok();
    }

    @ApiOperation("分页查询")
    @PostMapping("/list")
    public R<PageDataDTO<PlanInfoDTO>> selectPlanInfoList(@RequestBody PlanInfoQueryVO queryVO) {
        return R.ok(sdsHazardousWastePlanInfoService.selectPlanInfoList(queryVO));
    }

    @ApiOperation("删除")
    @DeleteMapping("/del/{id}")
    public R<Void> deletePlanInfo(@PathVariable("id") Integer id) {
        sdsHazardousWastePlanInfoService.deletePlanInfo(id);
        return R.ok();
    }

    @ApiOperation("导出")
    @PostMapping("/export")
    public R<Void> exportPlanInfo(HttpServletResponse response,
                                  @RequestBody PlanInfoQueryVO queryVO) {
        sdsHazardousWastePlanInfoService.exportPlanInfo(response, queryVO);
        return R.ok();
    }


    @ApiOperation("Flownet审核完成调用服务节点")
    @PostMapping("/approvalCompleted")
    public R<Void> approvalCompleted(@RequestBody String jsonString) {
        log.info("Flownet input parameter=========》：::requestJson={}", jsonString);
        return sdsHazardousWastePlanInfoService.approvalCompleted(jsonString);
    }

    @ApiOperation(value = "Flownet审核完成")
    @PostMapping("/flownetApproval")
    public R<Void> flownetApproval(@RequestBody List<PlanFlownetApprovalVO> planFlownetApprovalVOList) {
        sdsHazardousWastePlanInfoService.flownetApproval(planFlownetApprovalVOList);
        return R.ok();
    }
}