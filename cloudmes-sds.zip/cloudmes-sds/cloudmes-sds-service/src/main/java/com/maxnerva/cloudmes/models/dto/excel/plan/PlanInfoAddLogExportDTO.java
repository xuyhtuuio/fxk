package com.maxnerva.cloudmes.models.dto.excel.plan;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.excel.converter.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @ClassName PlanInfoAddLogExportDTO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/13
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("年度计划说明导出DTO")
@Data
public class PlanInfoAddLogExportDTO {

    @ApiModelProperty(value = "组织")
    @ExcelProperty(value = "组织", index = 0)
    private String orgCode;

    @ApiModelProperty(value = "说明单号")
    @ExcelProperty(value = "说明单号", index = 1)
    private String docNo;

    @ApiModelProperty(value = "年度")
    @ExcelProperty(value = "年度", index = 2)
    private String planYear;

    @ApiModelProperty(value = "计划单号")
    @ExcelProperty(value = "计划单号", index = 3)
    private String planDocNo;

    @ApiModelProperty(value = "费用代码")
    @ExcelProperty(value = "费用代码", index = 4)
    private String costCode;

    @ApiModelProperty(value = "部门名称")
    @ExcelProperty(value = "部门名称", index = 5)
    private String depName;

    @ApiModelProperty(value = "增加量（KG）")
    @ExcelProperty(value = "增加量（KG）", index = 6)
    private BigDecimal planAddWeight;

    @ApiModelProperty(value = "本年度当前计划总量（KG）")
    @ExcelProperty(value = "本年度当前计划总量（KG）", index = 7)
    private BigDecimal oldPlanWeight;

    @ApiModelProperty(value = "SDS危废料号")
    @ExcelProperty(value = "SDS危废料号", index = 8)
    private String hazardousWasteNo;

    @ApiModelProperty(value = "废物俗称")
    @ExcelProperty(value = "废物俗称", index = 9)
    private String hazardousWasteName;

    @ApiModelProperty(value = "危险废物")
    @ExcelProperty(value = "危险废物", index = 10)
    private String hazardousWaste;

    @ApiModelProperty(value = "废物形态")
    @ExcelProperty(value = "废物形态", index = 11)
    private String shape;

    @ApiModelProperty(value = "主要成分")
    @ExcelProperty(value = "主要成分", index = 12)
    private String rohs;

    @ApiModelProperty(value = "危险特性")
    @ExcelProperty(value = "危险特性", index = 13)
    private String toxicity;

    @ApiModelProperty(value = "废物类别")
    @ExcelProperty(value = "废物类别", index = 14)
    private String hazardousWasteCategory;

    @ApiModelProperty(value = "废物代码")
    @ExcelProperty(value = "废物代码", index = 15)
    private String hazardousWasteCode;

    @ApiModelProperty(value = "废物包装规格")
    @ExcelProperty(value = "废物包装规格", index = 16)
    private String packagingType;

    @ApiModelProperty(value = "创建人")
    @ExcelProperty(value = "创建人", index = 17)
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "创建时间", index = 18, converter = LocalDateTimeStringConverter.class)
    @ApiModelProperty(value = "创建时间")
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "修改人")
    @ExcelProperty(value = "修改人", index = 19)
    private String lastEditor;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "修改时间", index = 20, converter = LocalDateTimeStringConverter.class)
    @ApiModelProperty(value = "修改时间")
    private LocalDateTime lastEditedDt;

    @ApiModelProperty("单据状态名称")
    @ExcelProperty(value = "单据状态", index = 21)
    private String docStatusName;

    @ApiModelProperty(value = "增量原因")
    @ExcelProperty(value = "增量原因", index = 22)
    private String incrementReason;
}
