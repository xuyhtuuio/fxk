package com.maxnerva.cloudmes.service.waste.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.fastjson2.JSON;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.config.MinIOProperties;
import com.maxnerva.cloudmes.common.constant.BucketConstant;
import com.maxnerva.cloudmes.common.enums.ResultCode;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.common.utils.WebContextUtil;
import com.maxnerva.cloudmes.enums.CodeRuleEnum;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.enums.WasteTransferDocStatusEnum;
import com.maxnerva.cloudmes.excel.handler.AddNoHandler;
import com.maxnerva.cloudmes.feign.basic.ICodeRuleClient;
import com.maxnerva.cloudmes.mapper.waste.SdsHazardousWasteShipInfoMapper;
import com.maxnerva.cloudmes.mapper.waste.SdsHazardousWasteTransferHeaderMapper;
import com.maxnerva.cloudmes.models.dto.excel.waste.WasteTransferExportDTO;
import com.maxnerva.cloudmes.models.dto.scrap.PaymentUploadDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteFileDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteTransferHeaderDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteTransferSaveDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteShipInfo;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteTransferDetail;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteTransferHeader;
import com.maxnerva.cloudmes.models.vo.waste.*;
import com.maxnerva.cloudmes.service.waste.ISdsHazardousWasteTransferDetailService;
import com.maxnerva.cloudmes.service.waste.ISdsHazardousWasteTransferHeaderService;
import com.maxnerva.cloudmes.system.feign.IUploadFileClient;
import com.maxnerva.cloudmes.system.models.dto.UploadFileRespDTO;
import com.maxnerva.cloudmes.system.models.vo.FileUploadVO;
import com.maxnerva.cloudmes.system.utils.DictLangUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.MimeTypeUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * 危废转移单单头 服务实现类
 * </p>
 *
 * @author likun
 * @since 2025-05-27
 */
@Slf4j
@Service
public class SdsHazardousWasteTransferHeaderServiceImpl extends ServiceImpl<SdsHazardousWasteTransferHeaderMapper, SdsHazardousWasteTransferHeader> implements ISdsHazardousWasteTransferHeaderService {

    @Resource
    private ISdsHazardousWasteTransferDetailService wasteTransferDetailService;

    @Resource
    private ICodeRuleClient codeRuleClient;

    @Resource
    private SdsHazardousWasteShipInfoMapper sdsHazardousWasteShipInfoMapper;

    @Resource
    private IUploadFileClient uploadFileClient;

    @Resource
    private MinIOProperties minIOProperties;

    @Resource
    private DictLangUtils dictLangUtils;

    @Override
    public PageDataDTO<WasteTransferHeaderDTO> getWasteTransferHeaderList(WasteTransferHeaderQueryVO queryVO) {
        if (queryVO.getPageIndex() != null && queryVO.getPageSize() != null
                && queryVO.getPageIndex() != 0 && queryVO.getPageSize() != 0) {
            Page page = PageHelper.startPage(queryVO.getPageIndex(), queryVO.getPageSize());
            List<WasteTransferHeaderDTO> wasteTransferHeaderDTOList = getTransferHeaderDTOList(queryVO);
            return new PageDataDTO<>(page.getTotal(), wasteTransferHeaderDTOList);
        } else {
            List<WasteTransferHeaderDTO> wasteTransferHeaderDTOList = getTransferHeaderDTOList(queryVO);
            return new PageDataDTO<>((long) wasteTransferHeaderDTOList.size(), wasteTransferHeaderDTOList);
        }
    }

    private List<WasteTransferHeaderDTO> getTransferHeaderDTOList(WasteTransferHeaderQueryVO queryVO) {
        List<WasteTransferHeaderDTO> wasteTransferHeaderDTOList = baseMapper.selectTransferHeaderList(queryVO);
        List<String> types = new ArrayList<>();
        types.add("SDS_HW_TRANSPORT_TYPE");
        types.add("SDS_HW_TRANSFER_DOC_STATUS");
        types.add("SDS_HW_TRANSFER_DOC_TYPE");
        Map<String, Map<String, String>> data = dictLangUtils.getByTypes(types);
        Map<String, String> transportTypeMap = data.get("SDS_HW_TRANSPORT_TYPE");
        Map<String, String> docStatusMap = data.get("SDS_HW_TRANSFER_DOC_STATUS");
        Map<String, String> docTypeMap = data.get("SDS_HW_TRANSFER_DOC_TYPE");
        wasteTransferHeaderDTOList.forEach(wasteTransferHeaderDTO -> {
            wasteTransferHeaderDTO.setTransportModeName(transportTypeMap.get(wasteTransferHeaderDTO.getTransportMode()));
            wasteTransferHeaderDTO.setDocStatusName(docStatusMap.get(wasteTransferHeaderDTO.getDocStatus()));
            wasteTransferHeaderDTO.setDocTypeName(docTypeMap.get(wasteTransferHeaderDTO.getDocType()));
        });
        return wasteTransferHeaderDTOList;
    }

    @Override
    public WasteTransferHeaderDTO selectHeaderById(Integer id) {
        return baseMapper.selectTransferHeaderById(id);
    }

    @Override
    public List<WasteFileDTO> selectFileUrlList(Integer id) {
        String fileUrl = baseMapper.selectFileUrl(id);
        List<WasteFileDTO> wasteFileDTOList = CollUtil.newArrayList();
        if (StrUtil.isNotEmpty(fileUrl)) {
            List<PaymentUploadDTO> paymentUploadDTOList = JSON.parseArray(fileUrl).toList(PaymentUploadDTO.class);
            for (PaymentUploadDTO paymentUploadDTO : paymentUploadDTOList) {
                WasteFileDTO wasteFileDTO = new WasteFileDTO();
                wasteFileDTO.setFileId(paymentUploadDTO.getFileId());
                wasteFileDTO.setFileName(paymentUploadDTO.getFileName());
                String url = paymentUploadDTO.getUrl();
                String fileAddr = minIOProperties.getFileAddr(BucketConstant.CLOUD_SAAS, url);
                wasteFileDTO.setFileUrl(fileAddr);
                wasteFileDTOList.add(wasteFileDTO);
            }
        }
        return wasteFileDTOList;
    }

    @Override
    public void uploadFile(TransferHeaderUploadFileVO vo) {
        String currentStaffCode = WebContextUtil.getCurrentStaffCode();
        Integer id = vo.getId();
        FileUploadVO fileUploadVO = new FileUploadVO();
        fileUploadVO.setBucketName("cloudsaas");
        fileUploadVO.setFiles(vo.getFiles());
        R<List<UploadFileRespDTO>> result = uploadFileClient.uploadBatch(fileUploadVO);
        List<UploadFileRespDTO> uploadFileRespDTOList = result.getData();
        List<PaymentUploadDTO> paymentUploadDTOList = CollUtil.newArrayList();
        for (UploadFileRespDTO uploadFileRespDTO : uploadFileRespDTOList) {
            PaymentUploadDTO paymentUploadDTO = new PaymentUploadDTO();
            paymentUploadDTO.setFileName(uploadFileRespDTO.getOriginalName());
            paymentUploadDTO.setUrl(uploadFileRespDTO.getName());
            paymentUploadDTO.setFileId(uploadFileRespDTO.getId());
            paymentUploadDTO.setCreatedDt(LocalDateTime.now());
            paymentUploadDTO.setCreator(currentStaffCode);
            paymentUploadDTOList.add(paymentUploadDTO);
        }
        baseMapper.update(null, Wrappers.<SdsHazardousWasteTransferHeader>lambdaUpdate()
                .setSql("file_url_list = file_url_list")
                .eq(SdsHazardousWasteTransferHeader::getId, vo.getId()));
        SdsHazardousWasteTransferHeader sdsHazardousWasteTransferHeader = baseMapper.selectById(id);
        String fileUrlListStr = sdsHazardousWasteTransferHeader.getFileUrlList();
        List<PaymentUploadDTO> paymentUploadDTOS = CollUtil.newArrayList();
        if (StrUtil.isNotEmpty(fileUrlListStr)) {
            paymentUploadDTOS = JSONUtil.toList(fileUrlListStr, PaymentUploadDTO.class);
            paymentUploadDTOS.addAll(paymentUploadDTOList);
        }else {
            paymentUploadDTOS = paymentUploadDTOList;
        }
        baseMapper.update(null, Wrappers.<SdsHazardousWasteTransferHeader>lambdaUpdate()
                .set(SdsHazardousWasteTransferHeader::getFileUrlList, JSON.toJSONString(paymentUploadDTOS))
                .set(SdsHazardousWasteTransferHeader::getLastEditor, currentStaffCode)
                .set(SdsHazardousWasteTransferHeader::getLastEditedDt, LocalDateTime.now())
                .eq(SdsHazardousWasteTransferHeader::getId, id));
    }

    @Override
    public void leaveConfirm(Integer id) {
        String currentStaffCode = WebContextUtil.getCurrentStaffCode();
        SdsHazardousWasteTransferHeader sdsHazardousWasteTransferHeader = baseMapper.selectById(id);
        String docStatus = sdsHazardousWasteTransferHeader.getDocStatus();
        if (!WasteTransferDocStatusEnum.UN_LEAVE_FACTORY.getDictCode().equals(docStatus)) {
            throw new CloudmesException(SdsResultCode.CAR_HAVE_BEEN_LEAVE_FACTORY.getCode(),
                    MessageUtils.get(SdsResultCode.CAR_HAVE_BEEN_LEAVE_FACTORY.getLocalCode()));
        }
        baseMapper.update(null, Wrappers.<SdsHazardousWasteTransferHeader>lambdaUpdate()
                .eq(SdsHazardousWasteTransferHeader::getId,id)
                .set(SdsHazardousWasteTransferHeader::getDocStatus,WasteTransferDocStatusEnum.LEAVE_FACTORY
                        .getDictCode())
                .set(SdsHazardousWasteTransferHeader::getLeaveEmp, currentStaffCode)
                .set(SdsHazardousWasteTransferHeader::getLeaveTime,LocalDateTime.now())
                .set(SdsHazardousWasteTransferHeader::getLastEditor, currentStaffCode)
                .set(SdsHazardousWasteTransferHeader::getLastEditedDt,LocalDateTime.now()));
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public WasteTransferSaveDTO saveTransferInfo(WasteTransferSaveVO saveVO) {
        WasteTransferHeaderSaveVO headerVo = saveVO.getHeaderVo();
        List<WasteTransferDetailSaveVO> detailList = saveVO.getDetailList();
        SdsHazardousWasteTransferHeader sdsHazardousWasteTransferHeader = new SdsHazardousWasteTransferHeader();
        BeanUtils.copyProperties(headerVo, sdsHazardousWasteTransferHeader);
        String serialNo;
        R<List<String>> result = codeRuleClient.getSerialNumber(CodeRuleEnum.SDS_WASTE_TRANSFER_DOC_NO
                .getDictCode(), 1);
        if (result.getCode() == ResultCode.SUCCESS.getCode()) {
            serialNo = result.getData().get(0);
        } else {
            throw new CloudmesException(SdsResultCode.CONNECT_BASIC_GET_SERIAL_NUMBER.getCode()
                    , MessageUtils.get(SdsResultCode.CONNECT_BASIC_GET_SERIAL_NUMBER.getLocalCode()));
        }
        sdsHazardousWasteTransferHeader.setDocNo(serialNo);
        baseMapper.insert(sdsHazardousWasteTransferHeader);
        if (CollUtil.isNotEmpty(detailList)) {
            List<SdsHazardousWasteTransferDetail> transferDetailList = CollUtil.newArrayList();
            for (WasteTransferDetailSaveVO wasteTransferDetailSaveVO : detailList) {
                SdsHazardousWasteTransferDetail sdsHazardousWasteTransferDetail = new SdsHazardousWasteTransferDetail();
                BeanUtils.copyProperties(wasteTransferDetailSaveVO, sdsHazardousWasteTransferDetail);
                sdsHazardousWasteTransferDetail.setTransferDocNo(serialNo);
                transferDetailList.add(sdsHazardousWasteTransferDetail);
            }
            wasteTransferDetailService.saveBatch(transferDetailList);
            List<String> shipDocNoList = transferDetailList.stream()
                    .map(SdsHazardousWasteTransferDetail::getShipDocNo)
                    .collect(Collectors.toList());
            //将转移单号绑定到出库单信息
            sdsHazardousWasteShipInfoMapper.update(null, Wrappers.<SdsHazardousWasteShipInfo>lambdaUpdate()
                    .in(SdsHazardousWasteShipInfo::getDocNo, shipDocNoList)
                    .set(SdsHazardousWasteShipInfo::getTransferDocNo, serialNo)
                    .set(SdsHazardousWasteShipInfo::getLastEditor, WebContextUtil.getCurrentStaffCode())
                    .set(SdsHazardousWasteShipInfo::getLastEditedDt, LocalDateTime.now()));
        }
        return WasteTransferSaveDTO.builder()
                .docNo(serialNo)
                .id(sdsHazardousWasteTransferHeader.getId())
                .build();
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void updateTransferInfo(WasteTransferHeaderUpdateVO updateVO) {
        String transferDocNo = updateVO.getTransferDocNo();
        SdsHazardousWasteTransferHeader sdsHazardousWasteTransferHeader = baseMapper
                .selectOne(Wrappers.<SdsHazardousWasteTransferHeader>lambdaQuery()
                .eq(SdsHazardousWasteTransferHeader::getDocNo, transferDocNo)
                .last("limit 1"));
        if (WasteTransferDocStatusEnum.LEAVE_FACTORY.getDictCode()
                .equals(sdsHazardousWasteTransferHeader.getDocStatus())) {
            throw new CloudmesException(SdsResultCode.LEAVE_FACTORY_CAN_NOT_UPDATE.getCode(),
                    MessageUtils.get(SdsResultCode.LEAVE_FACTORY_CAN_NOT_UPDATE.getLocalCode()));
        }
        List<WasteTransferDetailSaveVO> detailList = updateVO.getDetailList();
        List<SdsHazardousWasteTransferDetail> transferDetailList = CollUtil.newArrayList();
        for (WasteTransferDetailSaveVO wasteTransferDetailSaveVO : detailList) {
            SdsHazardousWasteTransferDetail sdsHazardousWasteTransferDetail = new SdsHazardousWasteTransferDetail();
            BeanUtils.copyProperties(wasteTransferDetailSaveVO, sdsHazardousWasteTransferDetail);
            sdsHazardousWasteTransferDetail.setTransferDocNo(transferDocNo);
            transferDetailList.add(sdsHazardousWasteTransferDetail);
        }
        wasteTransferDetailService.saveBatch(transferDetailList);
        List<String> shipDocNoList = transferDetailList.stream()
                .map(SdsHazardousWasteTransferDetail::getShipDocNo)
                .collect(Collectors.toList());
        //将转移单号绑定到出库单信息
        if (CollUtil.isNotEmpty(shipDocNoList)) {
            sdsHazardousWasteShipInfoMapper.update(null, Wrappers.<SdsHazardousWasteShipInfo>lambdaUpdate()
                    .in(SdsHazardousWasteShipInfo::getDocNo, shipDocNoList)
                    .set(SdsHazardousWasteShipInfo::getTransferDocNo, transferDocNo)
                    .set(SdsHazardousWasteShipInfo::getLastEditor, WebContextUtil.getCurrentStaffCode())
                    .set(SdsHazardousWasteShipInfo::getLastEditedDt, LocalDateTime.now()));
        }
    }

    @Override
    public void exportTransferInfo(HttpServletResponse response, WasteTransferHeaderQueryVO queryVO) {
        List<WasteTransferExportDTO> exportDTOList = CollUtil.newArrayList();
        List<WasteTransferHeaderDTO> wasteTransferHeaderDTOList = getTransferHeaderDTOList(queryVO);
        wasteTransferHeaderDTOList.forEach(wasteTransferHeaderDTO -> {
            WasteTransferExportDTO wasteTransferExportDTO = new WasteTransferExportDTO();
            BeanUtils.copyProperties(wasteTransferHeaderDTO, wasteTransferExportDTO);
            exportDTOList.add(wasteTransferExportDTO);
        });
        String fileName = "转移单信息" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), WasteTransferExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.HAZARDOUS_WASTE_DOC_TRANSFER_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.HAZARDOUS_WASTE_DOC_TRANSFER_EXPORT_FAIL.getLocalCode()));
        }
    }
}
