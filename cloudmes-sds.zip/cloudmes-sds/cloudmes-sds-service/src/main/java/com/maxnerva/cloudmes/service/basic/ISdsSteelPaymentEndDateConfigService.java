package com.maxnerva.cloudmes.service.basic;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.models.dto.basic.CalcSteelPaymentOrderDeadlineDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsSteelPaymentEndDateConfig;

import java.math.BigDecimal;
import java.time.LocalDate;

public interface ISdsSteelPaymentEndDateConfigService extends IService<SdsSteelPaymentEndDateConfig> {

    CalcSteelPaymentOrderDeadlineDTO calcPaymentOrderDeadline(String mfgCode, LocalDate startDate, BigDecimal nowPercentage);

}
