package com.maxnerva.cloudmes.models.vo.waste;

import com.maxnerva.cloudmes.models.vo.CommonRequestVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

/**
 * @ClassName HazardousWasteDocInfoSaveVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/14
 * @Version 1.0
 * @Since JDK 1.8
 **/
@EqualsAndHashCode(callSuper = true)
@ApiModel("产废单信息新增vo")
@Data
public class HazardousWasteDocInfoSaveVO extends CommonRequestVO {

    @ApiModelProperty(value = "单据类型")
    private String docType;

    @ApiModelProperty(value = "申请人费用代码")
    private String costCode;

    @ApiModelProperty(value = "申请人部门")
    private String depName;

    @ApiModelProperty(value = "SDS料号")
    private String hazardousWasteNo;

    @ApiModelProperty(value = "废物俗称")
    private String hazardousWasteName;

    @ApiModelProperty(value = "危险废物")
    private String hazardousWaste;

    @ApiModelProperty(value = "废物形态")
    private String shape;

    @ApiModelProperty(value = "主要成分")
    private String rohs;

    @ApiModelProperty(value = "危险特性")
    private String toxicity;

    @ApiModelProperty(value = "废物类别")
    private String hazardousWasteCategory;

    @ApiModelProperty(value = "废物代码")
    private String hazardousWasteCode;

    @ApiModelProperty(value = "废物包装规格")
    private String packagingType;

    @ApiModelProperty(value = "产生时间")
    private String productionDate;

    @ApiModelProperty(value = "包装类型")
    private String packType;

    @ApiModelProperty(value = "有无栈板")
    private String isPallet;

    @ApiModelProperty(value = "贮存设施")
    private String storageFacilities;

    @ApiModelProperty("包装数量")
    private BigDecimal applyQty;
}
