package com.maxnerva.cloudmes.models.entity.waste;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * <p>
 * 危废单据日志履历
 * </p>
 *
 * @author likun
 * @since 2025-05-14
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="SdsHazardousWasteDocInfoLog对象", description="危废单据日志履历")
public class SdsHazardousWasteDocInfoLog extends BaseEntity<SdsHazardousWasteDocInfoLog> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "组织")
    private String orgCode;

    @ApiModelProperty(value = "说明单号")
    private String docNo;

    @ApiModelProperty(value = "单据类型")
    private String docType;

    @ApiModelProperty(value = "单据状态")
    private String docStatus;

    @ApiModelProperty(value = "申请人费用代码")
    private String costCode;

    @ApiModelProperty(value = "申请人部门")
    private String depName;

    @ApiModelProperty(value = "SDS料号")
    private String hazardousWasteNo;

    @ApiModelProperty(value = "废物俗称")
    private String hazardousWasteName;

    @ApiModelProperty(value = "危险废物")
    private String hazardousWaste;

    @ApiModelProperty(value = "废物形态")
    private String shape;

    @ApiModelProperty(value = "主要成分")
    private String rohs;

    @ApiModelProperty(value = "危险特性")
    private String toxicity;

    @ApiModelProperty(value = "废物类别")
    private String hazardousWasteCategory;

    @ApiModelProperty(value = "废物代码")
    private String hazardousWasteCode;

    @ApiModelProperty(value = "废物包装规格")
    private String packagingType;

    @ApiModelProperty(value = "产生时间")
    private LocalDateTime productionDate;

    @ApiModelProperty(value = "包装类型")
    private String packType;

    @ApiModelProperty(value = "包装数量")
    private BigDecimal applyQty;

    @ApiModelProperty(value = "产废毛重")
    private BigDecimal applyGrossWeight;

    @ApiModelProperty(value = "产废净重")
    private BigDecimal applyNetWeight;

    @ApiModelProperty(value = "有无栈板")
    private String isPallet;

    @ApiModelProperty(value = "栈板重量")
    private BigDecimal palletWeight;

    @ApiModelProperty(value = "图片地址")
    private String imageUrlList;

    @ApiModelProperty(value = "产废称重人")
    private String weightEmp;

    @ApiModelProperty(value = "产废称重时间")
    private LocalDateTime weightDt;

    @ApiModelProperty(value = "签核人")
    private String approvedEmp;

    @ApiModelProperty(value = "签核时间")
    private LocalDateTime approvedDt;

    @ApiModelProperty(value = "申请入库人")
    private String applyInEmp;

    @ApiModelProperty(value = "申请入库时间")
    private LocalDateTime applyInDt;

    @ApiModelProperty(value = "入库毛重")
    private BigDecimal instoreGrossWeight;

    @ApiModelProperty(value = "入库净重")
    private BigDecimal instoreNetWeight;

    @ApiModelProperty(value = "入库人")
    private String instoreEmp;

    @ApiModelProperty(value = "入库时间")
    private LocalDateTime instoreDt;

    @ApiModelProperty(value = "产废称重状态")
    private String applyWeighStatus;

    @ApiModelProperty(value = "入库称重状态")
    private String instoreWeighStatus;

    @ApiModelProperty(value = "删除标记")
    private Boolean isDeleted;

    @ApiModelProperty("操作类型")
    private String operateType;

    @ApiModelProperty("操作类型描述")
    private String operateMsg;

    @ApiModelProperty("N 未接收， Y 已接收")
    private String acceptFlag;

    @ApiModelProperty("接收时间")
    private LocalDateTime acceptDt;

    @ApiModelProperty("接收人")
    private String acceptEmpNo;

    @ApiModelProperty("接收备注")
    private String acceptRemark;

    @ApiModelProperty("出库单号")
    private String shipDocNo;
}
