package com.maxnerva.cloudmes.models.vo.basic;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class RfidSteelBucketLinkQueryVO {

    @ApiModelProperty(value = "托盘编码", required = true)
    private String bucketNo;
}
