package com.maxnerva.cloudmes.models.dto.waste;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @ClassName WasteTransferSaveDTO
 * @Description TODO
 * @Author Likun
 * @Date 2025/6/3
 * @Version 1.0
 * @Since JDK 1.8
 **/
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel("危废转移单新增vo")
@Data
public class WasteTransferSaveDTO {

    @ApiModelProperty("转移单号")
    private String docNo;

    @ApiModelProperty("主键id")
    private Integer id;
}
