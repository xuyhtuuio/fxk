package com.maxnerva.cloudmes.models.entity.scrap;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 固废盘点详情
 * </p>
 *
 * @author baomidou
 * @since 2024-12-18
 */
@TableName("sds_steel_inventory_plan_detail")
@ApiModel(value = "SdsSteelInventoryPlanDetail对象", description = "固废盘点详情")
@Data
public class SdsSteelInventoryPlanDetail extends BaseEntity<SdsSteelInventoryPlanDetail> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("单号")
    private String inventoryPlanNo;

    @ApiModelProperty("报废小类")
    private String scrapDetailClass;

    @ApiModelProperty("总净重")
    private BigDecimal totalNetWeight;

    @ApiModelProperty("盘点净重")
    private BigDecimal inventoryNetWeight;
}
