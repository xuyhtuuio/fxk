package com.maxnerva.cloudmes.mapper.waste;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.dto.waste.WasteMoveOutConfigDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousMoveOutConfig;

import java.util.List;

/**
 * <p>
 * 危废移出单位配置档 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2025-05-27
 */
public interface SdsHazardousMoveOutConfigMapper extends BaseMapper<SdsHazardousMoveOutConfig> {

    List<WasteMoveOutConfigDTO> selectMoveOutConfigList();
}
