package com.maxnerva.cloudmes.models.vo.waste.report;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.models.vo.PageQueryVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

/**
 * @ClassName WasteInventoryDetailQueryVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/6/20
 * @Version 1.0
 * @Since JDK 1.8
 **/
@EqualsAndHashCode(callSuper = true)
@ApiModel("危废库存查询vo")
@Data
public class WasteInventoryDetailQueryVO extends WasteInventoryQueryVO {

    @ApiModelProperty("申请单号")
    private String docNo;

    @ApiModelProperty("费用代码")
    private String costCode;
}
