package com.maxnerva.cloudmes.models.vo.scrap;

import com.maxnerva.cloudmes.models.vo.CommonRequestVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@ApiModel("固废称重扫描托盘查询信息vo")
@Data
public class SteelScrapWeightInfoQueryOneVO extends CommonRequestVO {
    @ApiModelProperty(value = "托盘编码", required = true)
    private String bucketNo;
}
