package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName DocStatusEnum
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/8
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum WastePlanDocStatusEnum {


    CREATE("CREATE","新建"),
    AUDIT("AUDIT","审核"),
    SIGN("SIGN","送签"),
    REJECT("REJECT","驳回"),

    /**
     * 审批进度
     */
    APPROVAL_NOT_SEND("NOT_SEND","未送签"),
    APPROVAL_COMPLETED("COMPLETED","审核完成"),
    APPROVAL_SEND("SEND","已送签"),
    APPROVAL_REFUSED("REFUSED","拒签");

    private String dictCode;

    private String dictName;

    WastePlanDocStatusEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (WastePlanDocStatusEnum wastePlanDocStatusEnum : values()) {
            if (wastePlanDocStatusEnum.getDictCode().equals(dictCode)) {
                return wastePlanDocStatusEnum.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

    /**
     * 提前判断，用于解决
     * Case中出现的Constant expression required
     *
     * @param dictCode 值
     * @return wastePlanDocStatusEnum
     */
    public static WastePlanDocStatusEnum getByValue(String dictCode) {
        for (WastePlanDocStatusEnum wastePlanDocStatusEnum : values()) {
            if (wastePlanDocStatusEnum.getDictCode().equals(dictCode)) {
                return wastePlanDocStatusEnum;
            }
        }
        return null;
    }
}
