package com.maxnerva.cloudmes.models.entity.scrap;

import com.baomidou.mybatisplus.annotation.TableName;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2024-12-30
 */
@TableName("sds_rfid_steel_config")
@ApiModel(value = "SdsRfidConfig对象", description = "")
@Data
public class SdsRfidSteelConfig extends BaseEntity<SdsRfidSteelConfig> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    private String host;

    private String port;

    @ApiModelProperty("位置编码")
    private String positionName;

    @ApiModelProperty("位置名称")
    private String positionLabel;
}
