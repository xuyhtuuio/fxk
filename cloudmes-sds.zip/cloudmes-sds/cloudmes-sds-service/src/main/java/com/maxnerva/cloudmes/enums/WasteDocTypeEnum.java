package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName WasteDocTypeEnum
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/15
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum WasteDocTypeEnum {


    STORAGE("STORAGE","贮存"),
    NO_STORAGE("NO_STORAGE","立产立清");


    private String dictCode;

    private String dictName;

    WasteDocTypeEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (WasteDocTypeEnum wasteDocTypeEnum : values()) {
            if (wasteDocTypeEnum.getDictCode().equals(dictCode)) {
                return wasteDocTypeEnum.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

    /**
     * 提前判断，用于解决
     * Case中出现的Constant expression required
     *
     * @param dictCode 值
     * @return wasteDocTypeEnum
     */
    public static WasteDocTypeEnum getByValue(String dictCode) {
        for (WasteDocTypeEnum wasteDocTypeEnum : values()) {
            if (wasteDocTypeEnum.getDictCode().equals(dictCode)) {
                return wasteDocTypeEnum;
            }
        }
        return null;
    }
}
