package com.maxnerva.cloudmes.service.waste;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteInStoreRejectDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteReject;
import com.maxnerva.cloudmes.models.vo.waste.InStoreRejectWeightSubmitVO;
import com.maxnerva.cloudmes.models.vo.waste.InStoreWeightRejectHandleSubmitVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteDocInfoUploadImageVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteInStoreRejectQueryVO;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * <p>
 * 入库拒收处理表 服务类
 * </p>
 *
 * @author likun
 * @since 2025-05-16
 */
public interface ISdsHazardousWasteRejectService extends IService<SdsHazardousWasteReject> {

    PageDataDTO<WasteInStoreRejectDTO> selectWasteInStoreRejectPage(WasteInStoreRejectQueryVO queryVO);

    void uploadImage(WasteDocInfoUploadImageVO uploadImageVO);

    List<String> selectImageList(Integer id);

    void handleSubmit(InStoreWeightRejectHandleSubmitVO submitVO);

    void rejectWeightInfo(InStoreRejectWeightSubmitVO submitVO);

    List<String> selectWasteImageList(Integer id);

    void exportDocRejectInfo(HttpServletResponse response, WasteInStoreRejectQueryVO queryVO);
}
