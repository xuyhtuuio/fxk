package com.maxnerva.cloudmes.models.dto.excel.scrap;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.VerticalAlignment;

import java.math.BigDecimal;
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 9)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 30)
@ColumnWidth(25)
@HeadFontStyle(fontName = "微軟正黑體")
@ContentFontStyle(fontName = "微軟正黑體", fontHeightInPoints = 12)
@ApiModel("废料销售汇总DTO")
@ContentStyle(verticalAlignment = VerticalAlignment.CENTER)
@Data
public class SteelPaymentSalesSummaryExportDTO {

    @ApiModelProperty(value = "序号")
    @ExcelProperty(value = "序号")
    @ContentStyle(horizontalAlignment = HorizontalAlignment.CENTER, verticalAlignment = VerticalAlignment.CENTER)
    private String index;

    @ApiModelProperty(value = "废料品名")
    @ExcelProperty(value = "废料品名")
    @ColumnWidth(value = 40)
    @ContentStyle(horizontalAlignment = HorizontalAlignment.CENTER, verticalAlignment = VerticalAlignment.CENTER)
    private String scrapPartName ;

    @ApiModelProperty(value = "费用代码")
    @ExcelProperty(value = "收益代碼")
    @ContentStyle(horizontalAlignment = HorizontalAlignment.CENTER, verticalAlignment = VerticalAlignment.CENTER)
    private String costCode;

    @ApiModelProperty(value = "加總 - 數量(KG）")
    @ExcelProperty(value = "加總 - 數量(KG）")
    @ColumnWidth(value = 28)
    @ContentStyle(dataFormat = 43)
    private BigDecimal splitShipNetWeight;

    @ApiModelProperty(value = "加總 - 金額(RMB）")
    @ExcelProperty(value = "加總 - 金額(RMB）")
    @ColumnWidth(value = 28)
    @ContentStyle(dataFormat = 43)
    private BigDecimal splitShipAccount;

    @ApiModelProperty(value = "入库量")
    @ExcelProperty(value = "入库量")
    private BigDecimal inStoreNetWeight;

    @ApiModelProperty(value = "入库占比")
    @ExcelProperty(value = "入库占比")
    @ContentStyle(dataFormat = 10)
    private BigDecimal inStorePercentage;
}
