package com.maxnerva.cloudmes.mapper.scrap;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelInventoryPlanDetail;

import java.math.BigDecimal;

public interface SdsSteelInventoryPlanDetailMapper extends BaseMapper<SdsSteelInventoryPlanDetail> {

    void increaseInventoryWeight(Integer id, BigDecimal weight);
}
