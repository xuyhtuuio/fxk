package com.maxnerva.cloudmes.controller.basic;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.basic.HwDepartmentPartRelationDTO;
import com.maxnerva.cloudmes.models.dto.basic.WasteInfoBindDTO;
import com.maxnerva.cloudmes.models.vo.basic.HwDepartmentPartRelationQueryVO;
import com.maxnerva.cloudmes.models.vo.basic.WasteInfoBindSubmitVO;
import com.maxnerva.cloudmes.service.basic.ISdsHwDepartmentPartRelationService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName HwDepartmentPartRelationController
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/7
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "部门对应危废种类管理")
@Slf4j
@RestController
@RequestMapping("/hwDepartmentPartRelation")
public class HwDepartmentPartRelationController {

    @Resource
    private ISdsHwDepartmentPartRelationService sdsHwDepartmentPartRelationService;

    @ApiOperation("分页查询")
    @PostMapping("/list")
    public R<PageDataDTO<HwDepartmentPartRelationDTO>> selectPartRelationPage(
            @RequestBody HwDepartmentPartRelationQueryVO queryVO) {
        return R.ok(sdsHwDepartmentPartRelationService.selectPartRelationPage(queryVO));
    }

    @ApiOperation("查询绑定危废信息")
    @GetMapping("/bindWasteInfoList")
    public R<List<WasteInfoBindDTO>> selectBindWasteInfoList(@RequestParam("orgCode") String orgCode,
                                                             @RequestParam("costCode") String costCode,
                                                             @RequestParam("hazardousWasteName")
                                                             String hazardousWasteName){
       return R.ok(sdsHwDepartmentPartRelationService.selectBindWasteInfoList(orgCode, costCode, hazardousWasteName));
    }

    @ApiOperation("绑定危废信息")
    @PostMapping("/bindWasteInfo")
    public R<Void> bindWasteInfo(@RequestBody List<WasteInfoBindSubmitVO> wasteInfoBindSubmitVOList){
        sdsHwDepartmentPartRelationService.bindWasteInfo(wasteInfoBindSubmitVOList);
        return R.ok();
    }
}
