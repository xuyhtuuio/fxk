package com.maxnerva.cloudmes.models.vo.excel;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.VerticalAlignment;

import java.util.HashMap;
import java.util.Map;

@Data
public class ExcelMergeCellValue<T extends Object> {

    public ExcelMergeCellValue(T val){
        value = val;
    }

    public ExcelMergeCellValue(T val, Integer rowSpan, Integer colSpan){
        value = val;
        this.rowSpan = rowSpan;
        this.colSpan = colSpan;
    }

    public ExcelMergeCellValue(T val, Integer rowSpan, Integer colSpan, Short backgroundColor){
        value = val;
        this.rowSpan = rowSpan;
        this.colSpan = colSpan;
        this.backgroundColor = backgroundColor;
    }

    @ApiModelProperty(value = "行合并", required = true)
    private Integer rowSpan = 1;

    @ApiModelProperty(value = "列合并", required = true)
    private Integer colSpan = 1;

    @ApiModelProperty(value = "值", required = true)
    private T value;

    @ApiModelProperty(value = "背景")
    private Short backgroundColor;

    @ApiModelProperty(value = "文本颜色")
    private Short fontColor;

    @ApiModelProperty(value = "Html文本颜色")
    private String htmlFontColor;

    @ApiModelProperty(value = "数据格式dataFormat")
    private Short dataFormat;

    @ApiModelProperty(value = "数据格式转换（手动转换，用于输出前端报表）")
    private String dataFormatName;

    @ApiModelProperty(value = "自定义单元格类型")
    private String customType;

    @ApiModelProperty(value = "是否居中")
    private Boolean isCenter = Boolean.FALSE;

    @ApiModelProperty(value = "自定义单元格元数据")
    private Map<String, Object> customMetaData = new HashMap<>();
}
