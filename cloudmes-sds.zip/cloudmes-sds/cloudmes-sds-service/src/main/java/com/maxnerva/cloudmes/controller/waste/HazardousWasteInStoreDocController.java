package com.maxnerva.cloudmes.controller.waste;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.enums.WasteDocTypeEnum;
import com.maxnerva.cloudmes.models.dto.waste.WasteInStoreDocInfoDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteInStoreWeightSubmitDTO;
import com.maxnerva.cloudmes.models.vo.waste.WasteInStoreConfirmVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteInStoreDocQueryVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteWeightInfoSubmitVO;
import com.maxnerva.cloudmes.service.waste.WasteInStoreService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @ClassName HazardousWasteInstoreDocController
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/16
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "入库单管理")
@Slf4j
@RestController
@RequestMapping("/hazardousWasteInStoreDoc")
public class HazardousWasteInStoreDocController {

    @Resource
    private WasteInStoreService wasteInStoreService;

    @ApiOperation("查询入库单信息")
    @PostMapping("/inStoreList")
    public R<PageDataDTO<WasteInStoreDocInfoDTO>> selectWasteInStorePage(@RequestBody WasteInStoreDocQueryVO queryVO){
        return R.ok(wasteInStoreService.selectWasteInStorePage(queryVO));
    }

    @ApiOperation("称重提交")
    @PostMapping("/inStoreWeightSubmit")
    public R<WasteInStoreWeightSubmitDTO> inStoreWeightSubmit(@RequestBody WasteWeightInfoSubmitVO submitVO){
        return wasteInStoreService.inStoreWeightSubmit(submitVO);
    }

    @ApiOperation("接收确认/拒收")
    @PostMapping("/confirmInStoreWeightInfo")
    public R<Void> confirmInStoreWeightInfo(@RequestBody WasteInStoreConfirmVO confirmVO){
        wasteInStoreService.confirmInStoreWeightInfo(confirmVO);
        return R.ok();
    }

    @ApiOperation("申请出库")
    @PostMapping("/applyShip")
    public R<Void> applyShip(@RequestBody List<Integer> idList){
        wasteInStoreService.applyShip(idList, WasteDocTypeEnum.STORAGE.getDictCode());
        return R.ok();
    }

    @ApiOperation("导出")
    @PostMapping("/export")
    public R<Void> exportInStoreDoc(HttpServletResponse response,
                                                 @RequestBody WasteInStoreDocQueryVO queryVO) {
        wasteInStoreService.exportInStoreDoc(response, queryVO);
        return R.ok();
    }
}
