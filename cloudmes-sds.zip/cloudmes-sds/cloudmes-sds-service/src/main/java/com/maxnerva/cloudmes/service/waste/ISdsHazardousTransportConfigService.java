package com.maxnerva.cloudmes.service.waste;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.models.dto.waste.WasteTransportConfigDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousTransportConfig;

import java.util.List;

/**
 * <p>
 * 危废运输单位配置档 服务类
 * </p>
 *
 * @author likun
 * @since 2025-05-27
 */
public interface ISdsHazardousTransportConfigService extends IService<SdsHazardousTransportConfig> {

    List<WasteTransportConfigDTO> selectTransferConfigList();

}
