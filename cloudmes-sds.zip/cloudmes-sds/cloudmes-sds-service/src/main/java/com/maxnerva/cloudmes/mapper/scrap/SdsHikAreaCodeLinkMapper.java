package com.maxnerva.cloudmes.mapper.scrap;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.models.entity.scrap.SdsHikAreaCodeLink;

/**
 * @ClassName SdsHikAreaCodeLinkMapper
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/1/4 下午 03:25
 * @Version 1.0
 **/
public interface SdsHikAreaCodeLinkMapper extends BaseMapper<SdsHikAreaCodeLink> {
}
