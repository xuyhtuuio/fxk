package com.maxnerva.cloudmes.models.dto.excel.basic;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.excel.converter.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.time.LocalDateTime;

/**
 * @ClassName MaterialClassExportDTO
 * @Description TODO
 * @Author Likun
 * @Date 2024/10/28
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("物料类别信息导出DTO")
@Data
public class MaterialClassExportDTO {

    @ApiModelProperty(value = "组织")
    @ExcelProperty(value = "组织", index = 0)
    private String orgCode;

    @ApiModelProperty(value = "分类代码")
    @ExcelProperty(value = "分类代码", index = 1)
    private String classCode;

    @ApiModelProperty(value = "物料类别")
    @ExcelProperty(value = "物料类别", index = 2)
    private String className;

    @ApiModelProperty(value = "创建人")
    @ExcelProperty(value = "创建人", index = 3)
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "创建时间")
    @ExcelProperty(value = "创建时间", index = 4, converter = LocalDateTimeStringConverter.class)
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "修改人")
    @ExcelProperty(value = "修改人", index = 5)
    private String lastEditor;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "修改时间")
    @ExcelProperty(value = "修改时间", index = 6, converter = LocalDateTimeStringConverter.class)
    private LocalDateTime lastEditedDt;
}
