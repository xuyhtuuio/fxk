package com.maxnerva.cloudmes.models.entity.basic;

import com.maxnerva.cloudmes.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 签核课级配置关系表
 * </p>
 *
 * @author likun
 * @since 2025-05-14
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="SdsHazardousWasteCostAuditRelationConfig对象", description="签核课级配置关系表")
public class SdsHazardousWasteCostAuditRelationConfig extends BaseEntity<SdsHazardousWasteCostAuditRelationConfig> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty("组织")
    private String orgCode;

    @ApiModelProperty(value = "费用代码")
    private String costCode;

    @ApiModelProperty(value = "员工编码")
    private String staffCode;
}
