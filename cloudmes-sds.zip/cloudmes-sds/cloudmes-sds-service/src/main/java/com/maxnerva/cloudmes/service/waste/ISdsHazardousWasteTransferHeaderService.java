package com.maxnerva.cloudmes.service.waste;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteFileDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteTransferHeaderDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteTransferSaveDTO;
import com.maxnerva.cloudmes.models.entity.waste.SdsHazardousWasteTransferHeader;
import com.maxnerva.cloudmes.models.vo.waste.TransferHeaderUploadFileVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteTransferHeaderQueryVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteTransferHeaderUpdateVO;
import com.maxnerva.cloudmes.models.vo.waste.WasteTransferSaveVO;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * <p>
 * 危废转移单单头 服务类
 * </p>
 *
 * @author likun
 * @since 2025-05-27
 */
public interface ISdsHazardousWasteTransferHeaderService extends IService<SdsHazardousWasteTransferHeader> {

    PageDataDTO<WasteTransferHeaderDTO> getWasteTransferHeaderList(WasteTransferHeaderQueryVO queryVO);

    WasteTransferHeaderDTO selectHeaderById(Integer id);

    List<WasteFileDTO> selectFileUrlList(Integer id);

    void uploadFile(TransferHeaderUploadFileVO uploadFileVO);

    void leaveConfirm(Integer id);

    WasteTransferSaveDTO saveTransferInfo(WasteTransferSaveVO saveVO);

    void updateTransferInfo(WasteTransferHeaderUpdateVO updateVO);

    void exportTransferInfo(HttpServletResponse response, WasteTransferHeaderQueryVO queryVO);
}
