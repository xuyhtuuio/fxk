package com.maxnerva.cloudmes.controller.waste;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.waste.HazardousWasteDocInfoDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteDocPrintDTO;
import com.maxnerva.cloudmes.models.dto.waste.WasteWeightInfoSubmitDTO;
import com.maxnerva.cloudmes.models.vo.UpdateCommonVO;
import com.maxnerva.cloudmes.models.vo.waste.*;
import com.maxnerva.cloudmes.service.waste.ISdsHazardousWasteDocInfoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @ClassName HazardousWasteDocInfoController
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/15
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "产废单管理")
@Slf4j
@RestController
@RequestMapping("/hazardousWasteDocInfo")
public class HazardousWasteDocInfoController {

    @Resource
    private ISdsHazardousWasteDocInfoService sdsHazardousWasteDocInfoService;

    @ApiOperation("申请产废单")
    @PostMapping("/saveWasteDocInfo")
    public R<Void> saveWasteDocInfo(@RequestBody HazardousWasteDocInfoSaveVO saveVO) {
        sdsHazardousWasteDocInfoService.saveWasteDocInfo(saveVO);
        return R.ok();
    }

    @ApiOperation("查询产废单信息")
    @PostMapping("/docInfoList")
    public R<PageDataDTO<HazardousWasteDocInfoDTO>> selectWasteDocInfoList(
            @RequestBody HazardousWasteDocInfoQueryVO queryVO) {
        return R.ok(sdsHazardousWasteDocInfoService.selectWasteDocInfoList(queryVO));
    }

    @ApiOperation("产废称重提交")
    @PostMapping("/submitWasteWeightInfo")
    public R<WasteWeightInfoSubmitDTO> submitWasteWeightInfo(@RequestBody WasteWeightInfoSubmitVO submitVO) {
        return sdsHazardousWasteDocInfoService.submitWasteWeightInfo(submitVO);
    }

    @ApiOperation("产废条码列印")
    @PostMapping("/printWasteDocInfo")
    public R<WasteDocPrintDTO> printWasteDocInfo(@RequestBody WasteDocInfoPrintVO printVO) {
        return R.ok(sdsHazardousWasteDocInfoService.printWasteDocInfo(printVO));
    }

    @ApiOperation("作废")
    @PutMapping("/cancelWasteDocInfo")
    public R<Void> cancelWasteDocInfo(@RequestBody UpdateCommonVO commonVO) {
        sdsHazardousWasteDocInfoService.cancelWasteDocInfo(commonVO.getId());
        return R.ok();
    }

    @ApiOperation("上传图片")
    @PostMapping("/uploadImage")
    public R<Void> uploadImage(WasteDocInfoUploadImageVO uploadImageVO) {
        sdsHazardousWasteDocInfoService.uploadImage(uploadImageVO);
        return R.ok();
    }

    @ApiOperation("查询图片列表")
    @GetMapping("/selectImageList")
    public R<List<String>> selectImageList(@ApiParam("单据主键id") @RequestParam("id") Integer id) {
        return R.ok(sdsHazardousWasteDocInfoService.selectImageList(id));
    }

    @ApiOperation("签核")
    @PutMapping("/auditWasteDocInfo")
    public R<Void> auditWasteDocInfo(@RequestBody UpdateCommonVO commonVO) {
        sdsHazardousWasteDocInfoService.auditWasteDocInfo(commonVO.getId());
        return R.ok();
    }

    @ApiOperation("申请入库")
    @PostMapping("/applyStorage")
    public R<Void> applyStorage(@RequestBody List<Integer> idList) {
        sdsHazardousWasteDocInfoService.applyStorage(idList);
        return R.ok();
    }

    @ApiOperation("送签")
    @PutMapping("/sign")
    public R<Void> sign(@RequestBody UpdateCommonVO commonVO) {
        sdsHazardousWasteDocInfoService.sign(commonVO.getId());
        return R.ok();
    }

    @ApiOperation("危废车间上传图片")
    @PostMapping("/uploadImgInApp")
    public R<Void> uploadImgInApp(WasteDocInfoAppUploadImageVO uploadImageVO) {
        sdsHazardousWasteDocInfoService.uploadImgInApp(uploadImageVO);
        return R.ok();
    }

    @ApiOperation("危废拒收")
    @PostMapping("/rejectWasteDoc")
    public R<Void> rejectWasteDoc(WasteDocRejectVO rejectVO) {
        sdsHazardousWasteDocInfoService.rejectWasteDoc(rejectVO);
        return R.ok();
    }

    @ApiOperation("危废车间上传图片校验单号")
    @PostMapping("/checkUploadImage")
    public R<Void> checkUploadImage(@RequestBody WasteDocInfoAppUploadCheckVO checkVO) {
        sdsHazardousWasteDocInfoService.checkUploadImage(checkVO);
        return R.ok();
    }

    @ApiOperation("导出")
    @PostMapping("/export")
    public R<Void> exportWasteDocInfo(HttpServletResponse response,
                                    @RequestBody HazardousWasteDocInfoQueryVO queryVO) {
        sdsHazardousWasteDocInfoService.exportWasteDocInfo(response, queryVO);
        return R.ok();
    }
}
