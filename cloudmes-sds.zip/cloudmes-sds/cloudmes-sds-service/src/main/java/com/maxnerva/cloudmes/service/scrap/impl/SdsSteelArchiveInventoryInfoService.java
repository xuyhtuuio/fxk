package com.maxnerva.cloudmes.service.scrap.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelArchiveInventoryInfoMapper;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelArchiveInventoryInfo;
import com.maxnerva.cloudmes.service.scrap.ISdsSteelArchiveInventoryInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class SdsSteelArchiveInventoryInfoService extends ServiceImpl<SdsSteelArchiveInventoryInfoMapper, SdsSteelArchiveInventoryInfo> implements ISdsSteelArchiveInventoryInfoService {


}
