package com.maxnerva.cloudmes.models.dto.scrap;

import com.maxnerva.cloudmes.models.entity.basic.SdsScrapSolidTypeConfig;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapShipHeader;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName OutFactoryWeightResultDTO
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/2/26 上午 11:04
 * @Version 1.0
 **/
@Data
public class OutFactoryWeightResultDTO {
    @ApiModelProperty(value = "")
    private SdsSteelScrapShipHeader sdsSteelScrapShipHeader;


    @ApiModelProperty(value = "")
    private SdsScrapSolidTypeConfig sdsScrapSolidTypeConfig;
}
