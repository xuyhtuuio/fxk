package com.maxnerva.cloudmes.models.vo.scrap;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class HandleSteelIssueVO {

    @ApiModelProperty(value = "异常事件ID", required = true)
    private Integer id;

    @ApiModelProperty(value = "处理人", required = true)
    private String handleEmpNo;
}
