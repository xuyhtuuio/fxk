package com.maxnerva.cloudmes.service.scrap.impl;

import cn.hutool.Hutool;
import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.date.LocalDateTimeUtil;
import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.write.style.column.LongestMatchColumnWidthStyleStrategy;
import com.alibaba.fastjson2.JSON;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.common.constant.BucketConstant;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.common.utils.WebContextUtil;
import com.maxnerva.cloudmes.config.FlowNetUrlConfig;
import com.maxnerva.cloudmes.config.RFIDConfig;
import com.maxnerva.cloudmes.config.UploadConfig;
import com.maxnerva.cloudmes.config.WeighConfig;
import com.maxnerva.cloudmes.enums.BucketTypeEnum;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.enums.SteelScrapOperateType;
import com.maxnerva.cloudmes.excel.handler.AddNoHandler;
import com.maxnerva.cloudmes.mapper.basic.*;
import com.maxnerva.cloudmes.mapper.scrap.SdsRfidSteelIssueLogMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelScrapWeightInfoLogMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelScrapWeightInfoMapper;
import com.maxnerva.cloudmes.mapper.scrap.SdsSteelScrapWeightRejectMapper;
import com.maxnerva.cloudmes.models.dto.basic.BucketNoDTO;
import com.maxnerva.cloudmes.models.dto.basic.FlownetResponse;
import com.maxnerva.cloudmes.models.dto.excel.scrap.SteelScrapWeightInfoExportDTO;
import com.maxnerva.cloudmes.models.dto.excel.scrap.SteelScrapWeightRejectExportDTO;
import com.maxnerva.cloudmes.models.dto.scrap.*;
import com.maxnerva.cloudmes.models.dto.basic.SteelReturnConfigDTO;
import com.maxnerva.cloudmes.models.entity.basic.*;
import com.maxnerva.cloudmes.models.entity.scrap.SdsRfidSteelIssueLog;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapWeightInfo;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapWeightInfoLog;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapWeightReject;
import com.maxnerva.cloudmes.models.vo.basic.FlowNetEmailVO;
import com.maxnerva.cloudmes.mapper.scrap.*;
import com.maxnerva.cloudmes.models.dto.scrap.RubbishWeightInfoSubmitDTO;
import com.maxnerva.cloudmes.models.dto.basic.SteelReturnConfigDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelScrapWeightInfoDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsDepartmentConfig;
import com.maxnerva.cloudmes.models.entity.basic.SdsRfidSteelBucketLink;
import com.maxnerva.cloudmes.models.entity.basic.SdsSteelBucketInfo;
import com.maxnerva.cloudmes.models.entity.basic.SdsSteelIssueLog;
import com.maxnerva.cloudmes.models.entity.scrap.*;
import com.maxnerva.cloudmes.models.vo.scrap.*;
import com.maxnerva.cloudmes.service.basic.ISdsFileDownloadLogService;
import com.maxnerva.cloudmes.service.scrap.ISteelScrapWeightService;
import com.maxnerva.cloudmes.system.feign.IUploadFileClient;
import com.maxnerva.cloudmes.system.models.dto.UploadFileRespDTO;
import com.maxnerva.cloudmes.system.models.vo.FileUploadVO;
import com.maxnerva.cloudmes.system.utils.DictLangUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.util.MimeTypeUtils;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class SteelScrapWeightService implements ISteelScrapWeightService {

    // 拒收超过3小时未处理，不能继续车间称重。
    private final int REJECT_TIMEOUT_HOURS = 3;

    // 不需要入废料区的，成功后30分钟才能继续称重。
    private final int NOT_SCRAP_AREA_REPEAT_WEIGHT_MINUTE = 30;

    @Autowired
    private WeighConfig weighConfig;

    @Autowired
    private PlatformTransactionManager transactionManager;

    @Autowired
    DictLangUtils dictLangUtils;

    @Autowired
    SdsSteelScrapWeightInfoMapper steelScrapWeightInfoMapper;

    @Autowired
    SdsSteelScrapWeightInfoLogMapper steelScrapWeightInfoLogMapper;

    @Autowired
    SdsSteelBucketInfoMapper steelBucketInfoMapper;

    @Autowired
    IUploadFileClient uploadFileClient;

    @Autowired
    SdsSteelScrapWeightRejectMapper steelScrapWeightRejectMapper;

    @Autowired
    SdsRfidSteelBucketLinkMapper steelBucketLinkMapper;

    @Autowired
    RFIDConfig rfidConfig;

    @Autowired
    SdsSteelReturnConfigMapper sdsSteelReturnConfigMapper;

    @Autowired
    SdsSteelIssueLogMapper sdsSteelIssueLogMapper;

    @Autowired
    SdsRfidSteelIssueLogMapper rfidSteelIssueLogMapper;

    @Autowired
    SdsDepartmentConfigMapper departmentConfigMapper;

    @Autowired
    SdsSendMailConfigMapper sendMailConfigMapper;

    @Autowired
    FlowNetUrlConfig flowNetUrlConfig;

    @Autowired
    ISdsFileDownloadLogService fileDownloadLogService;

    @Autowired
    UploadConfig uploadConfig;

    @Autowired
    SdsWeightLockConfigMapper sdsWeightLockConfigMapper;

    @Autowired
    SdsSteelScrapShipHeaderService sdsSteelScrapShipHeaderService;

    @Autowired
    SdsSteelScrapShipHeaderMapper sdsSteelScrapShipHeaderMapper;

    @Autowired
    SdsScrapSolidTypeConfigMapper sdsScrapSolidTypeConfigMapper;

    @Autowired
    SdsSolidWmsConfigMapper solidWmsConfigMapper;

    @Autowired
    SdsScrapSolidTypeConfigMapper scrapSolidTypeConfigMapper;


    @Transactional(rollbackFor = Exception.class)
    @Override
    /**
     * WMS抛转栈板信息时，会是直接调用这个方法，修改时需要注意输入
     */
    public SdsSteelScrapWeightInfo submitWeightInfo(SteelScrapWeightSubmitVO vo) {
        vo.setBucketNo(vo.getBucketNo().trim().toUpperCase());
        String weightEmpNo = StrUtil.isNotBlank(vo.getWeightEmpNo()) ? vo.getWeightEmpNo() : WebContextUtil.getCurrentStaffCode();
        LocalDateTime weighDt = ObjectUtil.isNotNull(vo.getWeighDt()) ? vo.getWeighDt() : LocalDateTime.now();

        SdsWeightLockConfig sdsWeightLockConfig = sdsWeightLockConfigMapper.selectOne(null);
        LocalDateTime currentTime = LocalDateTime.now();
        if (currentTime.isAfter(sdsWeightLockConfig.getBeginLockDt()) && currentTime.isBefore(sdsWeightLockConfig.getEndLockDt())) {
            throw new CloudmesException(StrUtil.format("称重目前已锁定， 锁定时间： {} - {}", sdsWeightLockConfig.getBeginLockDt(), sdsWeightLockConfig.getEndLockDt()));
        }
        SdsSteelBucketInfo steelBucketInfo = steelBucketInfoMapper.selectOne(Wrappers.<SdsSteelBucketInfo>lambdaQuery()
                .eq(SdsSteelBucketInfo::getOrgCode, vo.getOrgCode())
                .eq(SdsSteelBucketInfo::getBucketNo, vo.getBucketNo())
                .last("limit 1")
        );
        if (ObjectUtil.isNull(steelBucketInfo)) {
            throw new CloudmesException("未维护托盘信息，请维护");
        }

        SdsSteelScrapWeightInfo steelScrapWeightInfo = steelScrapWeightInfoMapper.selectOne(Wrappers.<SdsSteelScrapWeightInfo>lambdaQuery()
                .eq(SdsSteelScrapWeightInfo::getOrgCode, vo.getOrgCode())
                .eq(SdsSteelScrapWeightInfo::getBucketNo, vo.getBucketNo())
                .orderByDesc(SdsSteelScrapWeightInfo::getId)
                .last("limit 1")
        );
        if (ObjectUtil.isNotNull(steelScrapWeightInfo)) {
            if ("Y".equals(steelScrapWeightInfo.getWeighFlag()) && "N".equals(steelScrapWeightInfo.getRubbishWeighFlag())) {
                throw new CloudmesException("此托盘废料厂还未接收，不能重复利用");
            }
        }

        SdsSteelScrapWeightReject steelScrapWeightReject = steelScrapWeightRejectMapper.selectOne(Wrappers.<SdsSteelScrapWeightReject>lambdaQuery()
                .eq(SdsSteelScrapWeightReject::getDepartmentCode, steelBucketInfo.getDepartmentCode())
                .eq(SdsSteelScrapWeightReject::getStatus, "0")
                .orderByAsc(SdsSteelScrapWeightReject::getId)
                .last("limit 1")
        );
        if (ObjectUtil.isNotNull(steelScrapWeightReject)) {
            if (LocalDateTimeUtil.between(steelScrapWeightReject.getCreatedDt(), LocalDateTime.now()).toHours() >= REJECT_TIMEOUT_HOURS) {
                throw new CloudmesException("存在大于3小时未处理的拒收记录，禁止该厂部车间称重");
            }
        }

        SdsSteelScrapWeightInfo newSteelScrapWeightInfo = new SdsSteelScrapWeightInfo();
        BeanUtil.copyProperties(steelBucketInfo, newSteelScrapWeightInfo);
        newSteelScrapWeightInfo.setId(null);
        newSteelScrapWeightInfo.setGrossWeight(vo.getGrossWeight());
        newSteelScrapWeightInfo.setNetWeight(vo.getGrossWeight().subtract(newSteelScrapWeightInfo.getBucketWeight()));
        newSteelScrapWeightInfo.setRfidPositionName(vo.getPositionName());
        if (newSteelScrapWeightInfo.getNetWeight().compareTo(BigDecimal.ZERO) <= 0) {
            throw new CloudmesException("称重异常，净重必须大于0");
        }
        newSteelScrapWeightInfo.setWeighDt(weighDt);
        newSteelScrapWeightInfo.setWeighEmpNo(weightEmpNo);
        SteelReturnConfigDTO steelReturnConfigDTO = new SteelReturnConfigDTO();
        steelReturnConfigDTO.setBucketNo(newSteelScrapWeightInfo.getBucketNo());
        steelReturnConfigDTO.setIsReturn("N");
        sdsSteelReturnConfigMapper.insertReturnRecord(steelReturnConfigDTO);
        newSteelScrapWeightInfo.setWeighFlag("Y");
        newSteelScrapWeightInfo.setAcceptFlag("N");
        newSteelScrapWeightInfo.setRubbishWeighFlag("N");
        newSteelScrapWeightInfo.setSource(vo.getSource());
        newSteelScrapWeightInfo.setSourceDocNo(vo.getSourceDocNo());
        if (BooleanUtil.isFalse(steelBucketInfo.getIsScrapArea())){
            newSteelScrapWeightInfo.setRubbishGrossWeight(vo.getGrossWeight());
            newSteelScrapWeightInfo.setRubbishNetWeight(vo.getGrossWeight().subtract(newSteelScrapWeightInfo.getBucketWeight()));
            newSteelScrapWeightInfo.setRubbishWeighDt(weighDt);
            newSteelScrapWeightInfo.setRubbishWeighEmpNo(weightEmpNo);
            newSteelScrapWeightInfo.setRubbishWeighFlag("Y");
            newSteelScrapWeightInfo.setAcceptEmpNo(weightEmpNo);
            newSteelScrapWeightInfo.setAcceptDt(weighDt);
            newSteelScrapWeightInfo.setAcceptFlag("Y");
            // 不入廢料區的物料，車間稱重30成功後，需要間隔30分鐘才允許再次稱重。
            if (ObjectUtil.isNotNull(steelScrapWeightInfo)) {
                if (LocalDateTimeUtil.between(steelScrapWeightInfo.getWeighDt(), LocalDateTime.now()).toMinutes() < NOT_SCRAP_AREA_REPEAT_WEIGHT_MINUTE) {
                    throw new CloudmesException("不入废料区托盘，车间称重成功后，需要间隔30分钟才能称重。");
                }
            }
        }
        steelScrapWeightInfoMapper.insert(newSteelScrapWeightInfo);
        SdsSteelScrapWeightInfoLog steelScrapWeightInfoLog = new SdsSteelScrapWeightInfoLog();
        BeanUtil.copyProperties(newSteelScrapWeightInfo, steelScrapWeightInfoLog);
        steelScrapWeightInfoLog.setId(null);
        steelScrapWeightInfoLog.setOperateType(SteelScrapOperateType.WEIGH.getDictCode());
        steelScrapWeightInfoLog.setOperateMessage(SteelScrapOperateType.WEIGH.getDictName());
        steelScrapWeightInfoLogMapper.insert(steelScrapWeightInfoLog);
        return newSteelScrapWeightInfo;
    }


    @Override
    public SteelScrapWeightInfoDTO getCheckAcceptConfirm(SteelScrapWeightInfoQueryOneVO vo) {
        SdsSteelBucketInfo steelBucketInfo = steelBucketInfoMapper.selectOne(Wrappers.<SdsSteelBucketInfo>lambdaQuery()
                .eq(SdsSteelBucketInfo::getOrgCode, vo.getOrgCode())
                .eq(SdsSteelBucketInfo::getBucketNo, vo.getBucketNo())
                .last("limit 1")
        );
        if (ObjectUtil.isNull(steelBucketInfo)) {
            throw new CloudmesException("未维护托盘信息，请维护");
        }
        SdsSteelScrapWeightInfo scrapWeightInfo = steelScrapWeightInfoMapper.selectOne(Wrappers.<SdsSteelScrapWeightInfo>lambdaQuery()
                .eq(SdsSteelScrapWeightInfo::getOrgCode, vo.getOrgCode())
                .eq(SdsSteelScrapWeightInfo::getBucketNo, vo.getBucketNo())
                .orderByDesc(SdsSteelScrapWeightInfo::getId)
                .last("limit 1")
        );
        if (ObjectUtil.isNull(scrapWeightInfo)) {
            throw new CloudmesException("该托盘没有称重记录");
        }
        Map<String, Map<String, String>> dictMap = dictLangUtils.getByTypes(ListUtil.toList("SDS_ACCEPT_STATUS", "SDS_WEIGHT_STATUS"));
        SteelScrapWeightInfoDTO dto = new SteelScrapWeightInfoDTO();
        BeanUtil.copyProperties(scrapWeightInfo, dto, "imageUrlList");
        dto.setWeighFlagName(dictMap.get("SDS_WEIGHT_STATUS").get(dto.getWeighFlag()));
        dto.setAcceptFlagName(dictMap.get("SDS_ACCEPT_STATUS").get(dto.getAcceptFlag()));
        return dto;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void acceptConfirm(SteelScrapWeightAcceptVO vo) {
        SdsSteelScrapWeightInfo scrapWeightInfo = steelScrapWeightInfoMapper.selectOne(Wrappers.<SdsSteelScrapWeightInfo>lambdaQuery()
                .eq(SdsSteelScrapWeightInfo::getOrgCode, vo.getOrgCode())
                .eq(SdsSteelScrapWeightInfo::getBucketNo, vo.getBucketNo())
                .orderByDesc(SdsSteelScrapWeightInfo::getId)
                .last("limit 1")
        );
        if (ObjectUtil.isNull(scrapWeightInfo)) {
            throw new CloudmesException("该托盘没有称重记录");
        }
        if ("Y".equals(scrapWeightInfo.getAcceptFlag())) {
            throw new CloudmesException(String.format("系统中不存在托盘编码%s未接收的记录", vo.getBucketNo()));
        }
        if ("N".equals(scrapWeightInfo.getWeighFlag())) {
            throw new CloudmesException(String.format("托盘编码%s还未称重，不允许接收", vo.getBucketNo()));
        }
        steelScrapWeightInfoMapper.update(null, Wrappers.<SdsSteelScrapWeightInfo>lambdaUpdate()
                .set(SdsSteelScrapWeightInfo::getAcceptFlag, "Y")
                .set(SdsSteelScrapWeightInfo::getAcceptDt, LocalDateTime.now())
                .set(SdsSteelScrapWeightInfo::getAcceptEmpNo, WebContextUtil.getCurrentStaffCode())
                .set(SdsSteelScrapWeightInfo::getLastEditor, WebContextUtil.getCurrentStaffCode())
                .set(SdsSteelScrapWeightInfo::getLastEditedDt, LocalDateTime.now())
                .eq(SdsSteelScrapWeightInfo::getId, scrapWeightInfo.getId())
        );
        SdsSteelScrapWeightInfoLog scrapWeightInfoLog = new SdsSteelScrapWeightInfoLog();
        BeanUtil.copyProperties(scrapWeightInfo, scrapWeightInfoLog);
        scrapWeightInfoLog.setId(null);
        scrapWeightInfoLog.setAcceptFlag("Y");
        scrapWeightInfoLog.setAcceptDt(LocalDateTime.now());
        scrapWeightInfoLog.setAcceptEmpNo(WebContextUtil.getCurrentStaffCode());
        scrapWeightInfoLog.setLastEditor(WebContextUtil.getCurrentStaffCode());
        scrapWeightInfoLog.setLastEditedDt(LocalDateTime.now());
        scrapWeightInfoLog.setOperateType(SteelScrapOperateType.ACCEPT.getDictCode());
        scrapWeightInfoLog.setOperateMessage(SteelScrapOperateType.ACCEPT.getDictName());
        steelScrapWeightInfoLogMapper.insert(scrapWeightInfoLog);
    }

    @Override
    public SteelScrapWeightInfoDTO getCheckUploadImage(SteelScrapWeightInfoQueryOneVO vo) {
        SdsSteelBucketInfo steelBucketInfo = steelBucketInfoMapper.selectOne(Wrappers.<SdsSteelBucketInfo>lambdaQuery()
                .eq(SdsSteelBucketInfo::getOrgCode, vo.getOrgCode())
                .eq(SdsSteelBucketInfo::getBucketNo, vo.getBucketNo())
                .last("limit 1")
        );
        if (ObjectUtil.isNull(steelBucketInfo)) {
            throw new CloudmesException("未维护托盘信息，请维护");
        }
        SdsSteelScrapWeightInfo steelScrapWeightInfo = steelScrapWeightInfoMapper.selectOne(Wrappers.<SdsSteelScrapWeightInfo>lambdaQuery()
                .eq(SdsSteelScrapWeightInfo::getOrgCode, vo.getOrgCode())
                .eq(SdsSteelScrapWeightInfo::getBucketNo, vo.getBucketNo())
                .orderByDesc(SdsSteelScrapWeightInfo::getId)
                .last("limit 1")
        );
        if (ObjectUtil.isNull(steelScrapWeightInfo)) {
            throw new CloudmesException("该托盘没有称重记录");
        }
//        if ("Y".equals(steelScrapWeightInfo.getAcceptFlag())) {
//            throw new CloudmesException("托盘已经接收，不能上传图片");
//        }
        Map<String, Map<String, String>> dictMap = dictLangUtils.getByTypes(ListUtil.toList("SDS_ACCEPT_STATUS", "SDS_WEIGHT_STATUS"));
        SteelScrapWeightInfoDTO dto = new SteelScrapWeightInfoDTO();
        BeanUtil.copyProperties(steelScrapWeightInfo, dto, "imageUrlList");
        dto.setWeighFlagName(dictMap.get("SDS_WEIGHT_STATUS").get(dto.getWeighFlag()));
        dto.setAcceptFlagName(dictMap.get("SDS_ACCEPT_STATUS").get(dto.getAcceptFlag()));
        return dto;
    }

    @Override
    public void uploadImage(SteelScrapWeightUploadImageVO vo) {
        SteelScrapWeightInfoQueryOneVO queryOneVO = new SteelScrapWeightInfoQueryOneVO();
        queryOneVO.setBucketNo(vo.getBucketNo());
        queryOneVO.setOrgCode(vo.getOrgCode());
        SteelScrapWeightInfoDTO scrapWeightInfoDTO = getCheckUploadImage(queryOneVO);

        FileUploadVO fileUploadVO = new FileUploadVO();
        fileUploadVO.setBucketName("cloudsaas");
        fileUploadVO.setFiles(vo.getFiles());
        R<List<UploadFileRespDTO>> result = uploadFileClient.uploadBatch(fileUploadVO);
        List<UploadFileRespDTO> uploadFileRespDTOList = result.getData();
        List<String> urlList = uploadFileRespDTOList.stream().map(UploadFileRespDTO::getName)
                .collect(Collectors.toList());

        // 锁单号
        steelScrapWeightInfoMapper.update(null, Wrappers.<SdsSteelScrapWeightInfo>lambdaUpdate()
                .setSql("image_url_list = image_url_list")
                .eq(SdsSteelScrapWeightInfo::getId, scrapWeightInfoDTO.getId())
        );
        SdsSteelScrapWeightInfo steelScrapWeightInfo = steelScrapWeightInfoMapper.selectById(scrapWeightInfoDTO.getId());

        String imageUrlListStr = steelScrapWeightInfo.getImageUrlList();
        List<String> imageUrlList = null;
        if (StrUtil.isBlank(imageUrlListStr)) {
            imageUrlList = urlList;
        } else {
            imageUrlList = JSON.parseArray(imageUrlListStr, String.class);
            imageUrlList.addAll(urlList);
        }
        steelScrapWeightInfoMapper.update(null, Wrappers.<SdsSteelScrapWeightInfo>lambdaUpdate()
                .set(SdsSteelScrapWeightInfo::getImageUrlList, JSON.toJSONString(imageUrlList))
                .eq(SdsSteelScrapWeightInfo::getId, steelScrapWeightInfo.getId())
        );
        SdsSteelScrapWeightInfoLog steelScrapWeightInfoLog = new SdsSteelScrapWeightInfoLog();
        BeanUtil.copyProperties(steelScrapWeightInfo, steelScrapWeightInfoLog);
        steelScrapWeightInfoLog.setId(null);
        steelScrapWeightInfoLog.setImageUrlList(JSON.toJSONString(imageUrlList));
        steelScrapWeightInfoLog.setOperateType(SteelScrapOperateType.UPLOAD_IMAGE.getDictCode());
        steelScrapWeightInfoLog.setOperateMessage(SteelScrapOperateType.UPLOAD_IMAGE.getDictName());
        steelScrapWeightInfoLogMapper.insert(steelScrapWeightInfoLog);
    }


    // 手动开启事务
    @Override
    public R<RubbishWeightInfoSubmitDTO> submitRubbishWeightInfo(RubbishWeightInfoSubmitVO vo) {
        log.info("rubbishWeight: {} {} start", vo.getBucketNo(), vo.getGrossWeight());
        vo.setBucketNo(vo.getBucketNo().trim().toUpperCase());
        RubbishWeightInfoSubmitDTO dto = new RubbishWeightInfoSubmitDTO();
        R<RubbishWeightInfoSubmitDTO> r = R.no();
        r.setData(dto);
        dto.setBucketNo(vo.getBucketNo());
        dto.setGrossWeight(vo.getGrossWeight());
        SdsSteelBucketInfo steelBucketInfo = steelBucketInfoMapper.selectOne(Wrappers.<SdsSteelBucketInfo>lambdaQuery()
                .eq(SdsSteelBucketInfo::getBucketNo, vo.getBucketNo())
                .last("limit 1")
        );
        if (ObjectUtil.isNull(steelBucketInfo)) {
            r.setMsg("未维护托盘信息，请维护");
            return r;
        }
        BigDecimal rubbishNetWeight = vo.getGrossWeight().subtract(steelBucketInfo.getBucketWeight());
        dto.setNetWeight(rubbishNetWeight);

        Map<String, Map<String, String>> dictMap = dictLangUtils.getByTypes(ListUtil.toList("SDS_SCRAP_SOLID", "SDS_SOLID_SCRAP_TYPE", "SDS_PALLET_SCRAP_CLASS_DETAIL"));
        List<SdsDepartmentConfig> sdsDepartmentConfigList = departmentConfigMapper.selectList(Wrappers.<SdsDepartmentConfig>lambdaQuery()
                .select(SdsDepartmentConfig::getDepartmentCode, SdsDepartmentConfig::getDepartmentName)
                .eq(SdsDepartmentConfig::getOrgCode, steelBucketInfo.getOrgCode())
        );
        Map<String, String> departmentConfigMap = sdsDepartmentConfigList.stream().collect(Collectors.toMap(k -> k.getDepartmentCode(), v -> v.getDepartmentName()));
        dto.setBucketWeight(steelBucketInfo.getBucketWeight());
        dto.setScrapDetailClassName(dictMap.get("SDS_SCRAP_SOLID").get(steelBucketInfo.getScrapDetailClass()));
        dto.setScrapTypeName(dictMap.get("SDS_SOLID_SCRAP_TYPE").get(steelBucketInfo.getScrapType()));
        dto.setDepartmentCodeName(departmentConfigMap.get(steelBucketInfo.getDepartmentCode()));

        if (BooleanUtil.isFalse(steelBucketInfo.getIsScrapArea())) {
            r.setMsg("此废料种类不能进废料暂存区，请联系管理员及厂部负责人确认");
            return r;
        }

        SdsSteelScrapWeightInfo steelScrapWeightInfo = steelScrapWeightInfoMapper.selectOne(Wrappers.<SdsSteelScrapWeightInfo>lambdaQuery()
                .eq(SdsSteelScrapWeightInfo::getBucketNo, vo.getBucketNo())
                .orderByDesc(SdsSteelScrapWeightInfo::getId)
                .last("limit 1")
        );
        if (ObjectUtil.isNotNull(steelScrapWeightInfo)) {
            dto.setWorkshopNetWeight(steelScrapWeightInfo.getNetWeight());
            dto.setRubbishWeighDt(steelScrapWeightInfo.getRubbishWeighDt());
            if ("Y".equals(steelScrapWeightInfo.getAcceptFlag())) {
                r.setMsg("系统中不存在该托盘未接收的记录");
                return r;
            }
            if ("N".equals(steelScrapWeightInfo.getWeighFlag())) {
                r.setMsg("托盘编码还未称重，不允许接收");
                return r;
            }
        } else {
            r.setMsg("托盘编码还未称重，不允许接收");
            return r;
        }

        Map<String, String> weightErrorDictMap = dictLangUtils.getByType("SDS_SCRAP_AREA_WEIGHT_ERROR");
        if (!weightErrorDictMap.containsKey(steelBucketInfo.getScrapType())) {
            r.setMsg("报废类型未维护称重误差");
            return r;
        }

        if (rubbishNetWeight.compareTo(BigDecimal.ZERO) <= 0) {
            r.setMsg("净重不能小于0");
            return r;
        }
        BigDecimal weightError = new BigDecimal(weightErrorDictMap.get(steelBucketInfo.getScrapType()));
        if (steelScrapWeightInfo.getNetWeight().subtract(rubbishNetWeight).abs().compareTo(weightError) > 0) {
            r.setMsg("不在容许的误差范围内，请找管理员确认是否接收");
            dto.setHandleConfirm("Y");
            dto.setId(steelScrapWeightInfo.getId());
            return r;
        }

        // 手动开启事务
        TransactionStatus transactionStatus = transactionManager.getTransaction(new DefaultTransactionDefinition());
        try {
            steelScrapWeightInfoMapper.update(null, Wrappers.<SdsSteelScrapWeightInfo>lambdaUpdate()
                    .set(SdsSteelScrapWeightInfo::getRubbishGrossWeight, vo.getGrossWeight())
                    .set(SdsSteelScrapWeightInfo::getRubbishNetWeight, rubbishNetWeight)
                    .set(SdsSteelScrapWeightInfo::getRubbishWeighDt, LocalDateTime.now())
                    .set(SdsSteelScrapWeightInfo::getRubbishWeighEmpNo, WebContextUtil.getCurrentStaffCode())
                    .set(SdsSteelScrapWeightInfo::getRubbishWeighFlag, "Y")
                    .set(SdsSteelScrapWeightInfo::getAcceptFlag, "Y")
                    .set(SdsSteelScrapWeightInfo::getAcceptEmpNo, WebContextUtil.getCurrentStaffCode())
                    .set(SdsSteelScrapWeightInfo::getAcceptDt, LocalDateTime.now())
                    .set(SdsSteelScrapWeightInfo::getLastEditor, WebContextUtil.getCurrentStaffCode())
                    .set(SdsSteelScrapWeightInfo::getLastEditedDt, LocalDateTime.now())
                    .eq(SdsSteelScrapWeightInfo::getId, steelScrapWeightInfo.getId())
            );
            steelScrapWeightInfo.setRubbishGrossWeight(vo.getGrossWeight());
            steelScrapWeightInfo.setRubbishNetWeight(rubbishNetWeight);
            steelScrapWeightInfo.setRubbishWeighDt(LocalDateTime.now());
            steelScrapWeightInfo.setRubbishWeighEmpNo(WebContextUtil.getCurrentStaffCode());
            steelScrapWeightInfo.setRubbishWeighFlag("Y");
            steelScrapWeightInfo.setAcceptEmpNo(WebContextUtil.getCurrentStaffCode());
            steelScrapWeightInfo.setAcceptDt(LocalDateTime.now());
            steelScrapWeightInfo.setAcceptFlag("Y");
            steelScrapWeightInfo.setLastEditedDt(LocalDateTime.now());
            steelScrapWeightInfo.setLastEditor(WebContextUtil.getCurrentStaffCode());
            dto.setNetWeight(steelScrapWeightInfo.getRubbishNetWeight());
            dto.setId(steelScrapWeightInfo.getId());
            dto.setHandleConfirm("N");
            SdsSteelScrapWeightInfoLog steelScrapWeightInfoLog = new SdsSteelScrapWeightInfoLog();
            BeanUtil.copyProperties(steelScrapWeightInfo, steelScrapWeightInfoLog);
            steelScrapWeightInfoLog.setId(null);
            steelScrapWeightInfoLog.setOperateType(SteelScrapOperateType.RUBBISH_WEIGH.getDictCode());
            steelScrapWeightInfoLog.setOperateMessage(SteelScrapOperateType.RUBBISH_WEIGH.getDictName());
            steelScrapWeightInfoLogMapper.insert(steelScrapWeightInfoLog);

            if ("pallet".equals(steelBucketInfo.getBucketType())) {
                SdsSteelScrapWeightInfo palletWeightInfo = new SdsSteelScrapWeightInfo();
                BeanUtil.copyProperties(steelBucketInfo, palletWeightInfo);
                String palletScrapDetailClass = dictMap.get("SDS_PALLET_SCRAP_CLASS_DETAIL").get("pallet");
                palletWeightInfo.setScrapDetailClass(palletScrapDetailClass);
                palletWeightInfo.setId(null);
                palletWeightInfo.setBucketWeight(BigDecimal.ZERO);
                palletWeightInfo.setGrossWeight(steelBucketInfo.getBucketWeight());
                palletWeightInfo.setNetWeight(steelBucketInfo.getBucketWeight());
                palletWeightInfo.setWeighDt(LocalDateTime.now());
                palletWeightInfo.setWeighEmpNo(WebContextUtil.getCurrentStaffCode());
                palletWeightInfo.setWeighFlag("Y");
                palletWeightInfo.setRubbishGrossWeight(steelBucketInfo.getBucketWeight());
                palletWeightInfo.setRubbishNetWeight(steelBucketInfo.getBucketWeight());
                palletWeightInfo.setRubbishWeighDt(LocalDateTime.now());
                palletWeightInfo.setRubbishWeighEmpNo(WebContextUtil.getCurrentStaffCode());
                palletWeightInfo.setRubbishWeighFlag("Y");
                palletWeightInfo.setAcceptEmpNo(WebContextUtil.getCurrentStaffCode());
                palletWeightInfo.setAcceptDt(LocalDateTime.now());
                palletWeightInfo.setAcceptFlag("Y");
                palletWeightInfo.setLastEditedDt(LocalDateTime.now());
                palletWeightInfo.setLastEditor(WebContextUtil.getCurrentStaffCode());
                palletWeightInfo.setBucketNo(palletWeightInfo.getBucketNo() + "-01");
                steelScrapWeightInfoMapper.insert(palletWeightInfo);

                SdsSteelScrapWeightInfoLog palletWeightInfoLog = new SdsSteelScrapWeightInfoLog();
                BeanUtil.copyProperties(palletWeightInfo, palletWeightInfoLog);
                palletWeightInfoLog.setId(null);
                palletWeightInfoLog.setOperateType(SteelScrapOperateType.RUBBISH_WEIGH.getDictCode());
                palletWeightInfoLog.setOperateMessage(SteelScrapOperateType.RUBBISH_WEIGH.getDictName());
                steelScrapWeightInfoLogMapper.insert(palletWeightInfoLog);
            }

            transactionManager.commit(transactionStatus);
        } catch (CloudmesException e) {
            transactionManager.rollback(transactionStatus);
            throw e;
        } catch (Exception e) {
            transactionManager.rollback(transactionStatus);
            e.printStackTrace();
            throw new CloudmesException(e.getMessage());
        }
        r = R.ok();
        r.setData(dto);
        log.info("rubbishWeight: {} {} {} {} end", vo.getBucketNo(), vo.getGrossWeight(), r.getMsg(), r.getCode());
        return r;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void confirmRubbishWeightInfo(RubbishWeightInfoConfirmVO vo) {
        SdsSteelBucketInfo steelBucketInfo = steelBucketInfoMapper.selectOne(Wrappers.<SdsSteelBucketInfo>lambdaQuery()
                .eq(SdsSteelBucketInfo::getBucketNo, vo.getBucketNo())
                .last("limit 1")
        );
        if (ObjectUtil.isNull(steelBucketInfo)) {
            throw new CloudmesException("未维护托盘信息，请维护");
        }
        if (BooleanUtil.isFalse(steelBucketInfo.getIsScrapArea())) {
            throw new CloudmesException("此废料种类不能进废料暂存区，请联系管理员及厂部负责人确认");
        }

        SdsSteelScrapWeightInfo steelScrapWeightInfo = steelScrapWeightInfoMapper.selectOne(Wrappers.<SdsSteelScrapWeightInfo>lambdaQuery()
                .eq(SdsSteelScrapWeightInfo::getBucketNo, vo.getBucketNo())
                .orderByDesc(SdsSteelScrapWeightInfo::getId)
                .last("limit 1")
        );
        if (ObjectUtil.isNotNull(steelScrapWeightInfo)) {
            if ("Y".equals(steelScrapWeightInfo.getAcceptFlag())) {
                throw new CloudmesException("系统中不存在该托盘未接收的记录");
            }
            if ("N".equals(steelScrapWeightInfo.getWeighFlag())) {
                throw new CloudmesException("托盘编码还未称重，不允许接收");
            }
        }
        Map<String, String> rejectTypeDict = dictLangUtils.getByType("SDS_SOLID_SCRAP_REJECT_REASON");
        Map<String, String> palletScrapDetailClassDict = dictLangUtils.getByType("SDS_PALLET_SCRAP_CLASS_DETAIL");
        if ("Y".equals(vo.getHandleConfirm())) {


            BigDecimal rubbishNetWeight = vo.getGrossWeight().subtract(steelBucketInfo.getBucketWeight());

            steelScrapWeightInfoMapper.update(null, Wrappers.<SdsSteelScrapWeightInfo>lambdaUpdate()
                    .set(SdsSteelScrapWeightInfo::getRubbishGrossWeight, vo.getGrossWeight())
                    .set(SdsSteelScrapWeightInfo::getRubbishNetWeight, rubbishNetWeight)
                    .set(SdsSteelScrapWeightInfo::getRubbishWeighDt, LocalDateTime.now())
                    .set(SdsSteelScrapWeightInfo::getRubbishWeighEmpNo, WebContextUtil.getCurrentStaffCode())
                    .set(SdsSteelScrapWeightInfo::getRubbishWeighFlag, "Y")
                    .set(SdsSteelScrapWeightInfo::getAcceptFlag, "Y")
                    .set(SdsSteelScrapWeightInfo::getAcceptEmpNo, WebContextUtil.getCurrentStaffCode())
                    .set(SdsSteelScrapWeightInfo::getAcceptDt, LocalDateTime.now())
                    .set(SdsSteelScrapWeightInfo::getLastEditor, WebContextUtil.getCurrentStaffCode())
                    .set(SdsSteelScrapWeightInfo::getLastEditedDt, LocalDateTime.now())
                    .eq(SdsSteelScrapWeightInfo::getId, steelScrapWeightInfo.getId())
            );
            steelScrapWeightInfo.setRubbishGrossWeight(vo.getGrossWeight());
            steelScrapWeightInfo.setRubbishNetWeight(rubbishNetWeight);
            steelScrapWeightInfo.setRubbishWeighDt(LocalDateTime.now());
            steelScrapWeightInfo.setRubbishWeighEmpNo(WebContextUtil.getCurrentStaffCode());
            steelScrapWeightInfo.setRubbishWeighFlag("Y");
            steelScrapWeightInfo.setAcceptEmpNo(WebContextUtil.getCurrentStaffCode());
            steelScrapWeightInfo.setAcceptDt(LocalDateTime.now());
            steelScrapWeightInfo.setAcceptFlag("Y");
            steelScrapWeightInfo.setLastEditedDt(LocalDateTime.now());
            steelScrapWeightInfo.setLastEditor(WebContextUtil.getCurrentStaffCode());
            SdsSteelScrapWeightInfoLog steelScrapWeightInfoLog = new SdsSteelScrapWeightInfoLog();
            BeanUtil.copyProperties(steelScrapWeightInfo, steelScrapWeightInfoLog);
            steelScrapWeightInfoLog.setId(null);
            steelScrapWeightInfoLog.setOperateType(SteelScrapOperateType.RUBBISH_ERR_ACCEPT.getDictCode());
            steelScrapWeightInfoLog.setOperateMessage(SteelScrapOperateType.RUBBISH_ERR_ACCEPT.getDictName());
            steelScrapWeightInfoLogMapper.insert(steelScrapWeightInfoLog);

            if ("pallet".equals(steelBucketInfo.getBucketType())) {
                SdsSteelScrapWeightInfo palletWeightInfo = new SdsSteelScrapWeightInfo();
                BeanUtil.copyProperties(steelBucketInfo, palletWeightInfo);
                palletWeightInfo.setScrapDetailClass(palletScrapDetailClassDict.get("pallet"));
                palletWeightInfo.setId(null);
                palletWeightInfo.setBucketWeight(BigDecimal.ZERO);
                palletWeightInfo.setGrossWeight(steelBucketInfo.getBucketWeight());
                palletWeightInfo.setNetWeight(steelBucketInfo.getBucketWeight());
                palletWeightInfo.setWeighDt(LocalDateTime.now());
                palletWeightInfo.setWeighEmpNo(WebContextUtil.getCurrentStaffCode());
                palletWeightInfo.setWeighFlag("Y");
                palletWeightInfo.setRubbishGrossWeight(steelBucketInfo.getBucketWeight());
                palletWeightInfo.setRubbishNetWeight(steelBucketInfo.getBucketWeight());
                palletWeightInfo.setRubbishWeighDt(LocalDateTime.now());
                palletWeightInfo.setRubbishWeighEmpNo(WebContextUtil.getCurrentStaffCode());
                palletWeightInfo.setRubbishWeighFlag("Y");
                palletWeightInfo.setAcceptEmpNo(WebContextUtil.getCurrentStaffCode());
                palletWeightInfo.setAcceptDt(LocalDateTime.now());
                palletWeightInfo.setAcceptFlag("Y");
                palletWeightInfo.setLastEditedDt(LocalDateTime.now());
                palletWeightInfo.setLastEditor(WebContextUtil.getCurrentStaffCode());
                palletWeightInfo.setBucketNo(palletWeightInfo.getBucketNo() + "-01");
                steelScrapWeightInfoMapper.insert(palletWeightInfo);

                SdsSteelScrapWeightInfoLog palletWeightInfoLog = new SdsSteelScrapWeightInfoLog();
                BeanUtil.copyProperties(palletWeightInfo, palletWeightInfoLog);
                steelScrapWeightInfoLog.setId(null);
                steelScrapWeightInfoLog.setOperateType(SteelScrapOperateType.RUBBISH_ERR_ACCEPT.getDictCode());
                steelScrapWeightInfoLog.setOperateMessage(SteelScrapOperateType.RUBBISH_ERR_ACCEPT.getDictName());
                steelScrapWeightInfoLogMapper.insert(steelScrapWeightInfoLog);
            }
        } else {
            SdsSteelScrapWeightInfoLog steelScrapWeightInfoLog = new SdsSteelScrapWeightInfoLog();
            BeanUtil.copyProperties(steelScrapWeightInfo, steelScrapWeightInfoLog);
            steelScrapWeightInfoLog.setId(null);
            steelScrapWeightInfoLog.setOperateType(SteelScrapOperateType.RUBBISH_ERR_REJECT.getDictCode());
            steelScrapWeightInfoLog.setOperateMessage(SteelScrapOperateType.RUBBISH_ERR_REJECT.getDictName());
            steelScrapWeightInfoLogMapper.insert(steelScrapWeightInfoLog);

            SdsSteelScrapWeightReject steelScrapWeightReject = new SdsSteelScrapWeightReject();
            BeanUtil.copyProperties(steelScrapWeightInfo, steelScrapWeightReject);
            steelScrapWeightReject.setId(null);
            steelScrapWeightReject.setStatus("0");
            steelScrapWeightReject.setRubbishGrossWeight(vo.getGrossWeight());
            BigDecimal rubbishNetWeight = vo.getGrossWeight().subtract(steelBucketInfo.getBucketWeight());
            steelScrapWeightReject.setRubbishNetWeight(rubbishNetWeight);
            steelScrapWeightReject.setRubbishWeighDt(LocalDateTime.now());
            steelScrapWeightReject.setRubbishWeighEmpNo(WebContextUtil.getCurrentStaffCode());
            steelScrapWeightReject.setRejectDt(LocalDateTime.now());
            steelScrapWeightReject.setRejectEmpNo(vo.getOperateEmpNo());
            steelScrapWeightReject.setRejectReasonType(vo.getOperateRemarkType());
            steelScrapWeightReject.setRejectReason(rejectTypeDict.get(vo.getOperateRemarkType()));
            steelScrapWeightReject.setActualScrapWeightInfoId(steelScrapWeightInfo.getId());
            steelScrapWeightRejectMapper.insert(steelScrapWeightReject);
            // 这里是还没有入库，所以拒收只删除一条，原托盘信息
            steelScrapWeightInfoMapper.delete(Wrappers.<SdsSteelScrapWeightInfo>lambdaQuery()
                    .eq(SdsSteelScrapWeightInfo::getId, steelScrapWeightInfo.getId())
            );
        }
    }

    @Override
    public List<SdsRfidSteelBucketLink> getRfidBucketNoLink() {
        List<SdsRfidSteelBucketLink> list = steelBucketLinkMapper.selectList(Wrappers.<SdsRfidSteelBucketLink>lambdaQuery());
        return list;
    }

    @Override
    public void catchSteelIssue(String issueType, String issueMessage, String currentBucketNo,
                                String positionName) {
        SdsRfidSteelIssueLog rfidSteelIssueLog = new SdsRfidSteelIssueLog();
        rfidSteelIssueLog.setId(null);
        rfidSteelIssueLog.setBucketNo(currentBucketNo);
        rfidSteelIssueLog.setIssueType(issueType);
        rfidSteelIssueLog.setIssueMessage(issueMessage);
        rfidSteelIssueLog.setHandleFlag("N");
        rfidSteelIssueLog.setPositionName(positionName);
        rfidSteelIssueLogMapper.insert(rfidSteelIssueLog);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void rejectWeightInfo(RejectWeightInfoVO vo) {
        List<String> imageUrlList = null;
        if (ObjectUtil.isNotNull(vo.getFiles())) {
            FileUploadVO fileUploadVO = new FileUploadVO();
            fileUploadVO.setBucketName("cloudsaas");
            fileUploadVO.setFiles(vo.getFiles());
            R<List<UploadFileRespDTO>> result = uploadFileClient.uploadBatch(fileUploadVO);
            List<UploadFileRespDTO> uploadFileRespDTOList = result.getData();
            List<String> urlList = uploadFileRespDTOList.stream().map(UploadFileRespDTO::getName)
                    .collect(Collectors.toList());
            imageUrlList = urlList;
        }

        SdsSteelBucketInfo steelBucketInfo = steelBucketInfoMapper.selectOne(Wrappers.<SdsSteelBucketInfo>lambdaQuery()
                .eq(SdsSteelBucketInfo::getBucketNo, vo.getBucketNo())
                .last("limit 1")
        );
        if (ObjectUtil.isNull(steelBucketInfo)) {
            throw new CloudmesException("该托盘编码不存在");
        }
        SdsSteelScrapWeightInfo steelScrapWeightInfo = steelScrapWeightInfoMapper.selectOne(Wrappers.<SdsSteelScrapWeightInfo>lambdaQuery()
                .eq(SdsSteelScrapWeightInfo::getBucketNo, vo.getBucketNo())
                .orderByDesc(SdsSteelScrapWeightInfo::getId)
                .last("limit 1")
        );
        Map<String, String> rejectTypeDict = dictLangUtils.getByType("SDS_SOLID_SCRAP_REJECT_REASON");
        if ("NOT_WEIGHT".equals(vo.getOperateRemarkType())) {
            // 栈板未称重 or 可重复使用的托盘未称重
            if (ObjectUtil.isNull(steelScrapWeightInfo) || ("bucket".equals(steelBucketInfo.getBucketType()) && "Y".equals(steelScrapWeightInfo.getRubbishWeighFlag()))) {
                SdsSteelScrapWeightInfoLog steelScrapWeightInfoLog = new SdsSteelScrapWeightInfoLog();
                BeanUtil.copyProperties(steelBucketInfo, steelScrapWeightInfoLog);
                steelScrapWeightInfoLog.setId(null);
                steelScrapWeightInfoLog.setOperateType(SteelScrapOperateType.RUBBISH_ERR_REJECT.getDictCode());
                steelScrapWeightInfoLog.setOperateMessage(rejectTypeDict.get(vo.getOperateRemarkType()));
                steelScrapWeightInfoLogMapper.insert(steelScrapWeightInfoLog);

                SdsSteelScrapWeightReject newSteelScrapWeightReject = new SdsSteelScrapWeightReject();
                BeanUtil.copyProperties(steelBucketInfo, newSteelScrapWeightReject);
                newSteelScrapWeightReject.setId(null);
                newSteelScrapWeightReject.setStatus("0");
                newSteelScrapWeightReject.setRejectDt(LocalDateTime.now());
                newSteelScrapWeightReject.setRejectEmpNo(vo.getOperateEmpNo());
                newSteelScrapWeightReject.setRejectReasonType(vo.getOperateRemarkType());
                newSteelScrapWeightReject.setRejectReason(rejectTypeDict.get(vo.getOperateRemarkType()));
                if (ObjectUtil.isNotNull(imageUrlList)) {
                    newSteelScrapWeightReject.setRejectImageList(JSON.toJSONString(imageUrlList));
                }
                steelScrapWeightRejectMapper.insert(newSteelScrapWeightReject);
                return;
            } else {
                if ("bucket".equals(steelBucketInfo.getBucketType())) {
                    throw new CloudmesException("该托盘为待废料厂接收状态，不能以厂部未称重方式拒收");
                } else if ("pallet".equals(steelBucketInfo.getBucketType())) {
                    throw new CloudmesException("栈板已经接收，不能以厂部未称重方式拒收");
                }
            }
        }

        if (ObjectUtil.isNull(steelScrapWeightInfo)) {
            throw new CloudmesException("托盘未在厂部称重");
        }

        SdsSteelScrapWeightInfoLog steelScrapWeightInfoLog = new SdsSteelScrapWeightInfoLog();
        BeanUtil.copyProperties(steelScrapWeightInfo, steelScrapWeightInfoLog);
        steelScrapWeightInfoLog.setId(null);
        steelScrapWeightInfoLog.setOperateType(SteelScrapOperateType.RUBBISH_ERR_REJECT.getDictCode());
        steelScrapWeightInfoLog.setOperateMessage(rejectTypeDict.get(vo.getOperateRemarkType()));
        steelScrapWeightInfoLogMapper.insert(steelScrapWeightInfoLog);

        // 未入废料厂，拒收
        if ("N".equals(steelScrapWeightInfo.getRubbishWeighFlag())) {

            // 这里是还没有入库，所以拒收只删除一条，原托盘信息
            steelScrapWeightInfoMapper.delete(Wrappers.<SdsSteelScrapWeightInfo>lambdaQuery()
                    .eq(SdsSteelScrapWeightInfo::getId, steelScrapWeightInfo.getId())
            );
        } else { //已入废料厂拒收
            // 已经入废料厂的，超过48小时不能拒收。
            if (LocalDateTimeUtil.between(steelScrapWeightInfo.getRubbishWeighDt(), LocalDateTime.now()).toHours() > 48) {
                throw new CloudmesException("已经入废料厂，超过48小时不能拒收");
            }
            List<Integer> deleteIdList = ListUtil.toList(steelScrapWeightInfo.getId());
            // 栈板类型的需要删除栈板
            if ("pallet".equals(steelBucketInfo.getBucketType())) {
                SdsSteelScrapWeightInfo palletScrapWeightInfo = steelScrapWeightInfoMapper.selectOne(Wrappers.<SdsSteelScrapWeightInfo>lambdaQuery()
                        .eq(SdsSteelScrapWeightInfo::getBucketNo, StrUtil.concat(true, vo.getBucketNo(), "-01"))
                        .last("limit 1")
                );
                if (ObjectUtil.isNotNull(palletScrapWeightInfo)) {
                    deleteIdList.add(palletScrapWeightInfo.getId());
                }
            }
            steelScrapWeightInfoMapper.delete(Wrappers.<SdsSteelScrapWeightInfo>lambdaQuery()
                    .in(SdsSteelScrapWeightInfo::getId, deleteIdList)
            );
        }

        SdsSteelScrapWeightReject steelScrapWeightReject = steelScrapWeightRejectMapper.selectOne(Wrappers.<SdsSteelScrapWeightReject>lambdaQuery()
                .eq(SdsSteelScrapWeightReject::getBucketNo, vo.getBucketNo())
                .orderByDesc(SdsSteelScrapWeightReject::getId)
                .last("limit 1")
        );
        if (ObjectUtil.isNotNull(steelScrapWeightReject)) {
            if (ObjectUtil.isNotNull(steelScrapWeightReject.getActualScrapWeightInfoId())) {
                if (steelScrapWeightInfo.getId().compareTo(steelScrapWeightReject.getActualScrapWeightInfoId()) < 0) {
                    throw new CloudmesException("拒收后不能重复拒收，请返回厂部处理，重新称重");
                }
            }
        }

        SdsSteelScrapWeightReject newSteelScrapWeightReject = new SdsSteelScrapWeightReject();
        BeanUtil.copyProperties(steelScrapWeightInfo, newSteelScrapWeightReject);
        newSteelScrapWeightReject.setId(null);
        newSteelScrapWeightReject.setStatus("0");
        newSteelScrapWeightReject.setRejectDt(LocalDateTime.now());
        newSteelScrapWeightReject.setRejectEmpNo(vo.getOperateEmpNo());
        newSteelScrapWeightReject.setRejectReasonType(vo.getOperateRemarkType());
        newSteelScrapWeightReject.setRejectReason(rejectTypeDict.get(vo.getOperateRemarkType()));
        newSteelScrapWeightReject.setActualScrapWeightInfoId(steelScrapWeightInfo.getId());
        if (ObjectUtil.isNotNull(imageUrlList)) {
            newSteelScrapWeightReject.setRejectImageList(JSON.toJSONString(imageUrlList));
        }
        steelScrapWeightRejectMapper.insert(newSteelScrapWeightReject);
    }

    @Override
    public void scrapRejectSendMail() {
        List<SdsSendMailConfig> sendMailConfigList = sendMailConfigMapper.selectList(Wrappers.<SdsSendMailConfig>lambdaQuery()
                .eq(SdsSendMailConfig::getSendType, "SCRAP_REJECT")
        );
        // 厂部->邮件信息
        Map<String, SdsSendMailConfig> sendMailConfigMap = sendMailConfigList.stream().collect(Collectors.toMap(k -> k.getDepartmentCode(), v -> v));

        List<SdsSteelScrapWeightReject> steelScrapWeightRejectList = steelScrapWeightRejectMapper.selectList(Wrappers.<SdsSteelScrapWeightReject>lambdaQuery()
                .eq(SdsSteelScrapWeightReject::getSendMailFlag, "N")
        );
        if (CollUtil.isEmpty(steelScrapWeightRejectList)) {
            return;
        }
        List<SdsDepartmentConfig> sdsDepartmentConfigList = departmentConfigMapper.selectList(Wrappers.<SdsDepartmentConfig>lambdaQuery()
                .select(SdsDepartmentConfig::getDepartmentCode, SdsDepartmentConfig::getDepartmentName)
        );
        Map<String, String> departmentConfigMap = sdsDepartmentConfigList.stream().collect(Collectors.toMap(k -> k.getDepartmentCode(), v -> v.getDepartmentName()));
        Map<String, Map<String, String>> dictMap = dictLangUtils.getByTypes(ListUtil.toList("SDS_SOLID_REJECT_STATUS", "SDS_SCRAP_SOLID", "SDS_SOLID_SCRAP_REJECT_REASON"));
        List<SteelScrapWeightRejectDTO> result = ListUtil.toList();
        steelScrapWeightRejectList.forEach(item -> {
            SteelScrapWeightRejectDTO dto = new SteelScrapWeightRejectDTO();
            BeanUtil.copyProperties(item, dto);
            dto.setScrapDetailClassName(dictMap.get("SDS_SCRAP_SOLID").get(item.getScrapDetailClass()));
            dto.setStatusName(dictMap.get("SDS_SOLID_REJECT_STATUS").get(item.getStatus()));
            dto.setRejectReason(dictMap.get("SDS_SOLID_SCRAP_REJECT_REASON").get(item.getRejectReasonType()));
            dto.setDepartmentCodeName(departmentConfigMap.get(item.getDepartmentCode()));
            result.add(dto);
        });

        // 厂部->[拒收列表]
        Map<String, List<SteelScrapWeightRejectDTO>> steelScrapWeightRejectMap = result.stream()
                .collect(Collectors.groupingBy(SteelScrapWeightRejectDTO::getDepartmentCode));

        steelScrapWeightRejectMap.keySet().stream().forEach(departmentCode -> {
            if (!sendMailConfigMap.containsKey(departmentCode)) {
                return;
            }

            List<SteelScrapWeightRejectDTO> departmentScrapRejectList = steelScrapWeightRejectMap.get(departmentCode);
            List<Integer> departmentScrapRejectIdList = departmentScrapRejectList.stream().map(item -> item.getId()).collect(Collectors.toList());
            List<SteelScrapWeightRejectExportDTO> exportList = ListUtil.toList();
            departmentScrapRejectList.forEach(item -> {
                SteelScrapWeightRejectExportDTO dto = new SteelScrapWeightRejectExportDTO();
                BeanUtil.copyProperties(item, dto);
                exportList.add(dto);
            });
            String fileName = "固废废料厂拒收明细" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
            try {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                EasyExcel.write(byteArrayOutputStream, SteelScrapWeightRejectExportDTO.class)
                        .sheet(fileName)
                        .doWrite(exportList);
                SdsFileDownloadLog wmsFileDownloadLog = fileDownloadLogService.uploadFile("SCRAP_REJECT", fileName, "WMS_JOB", byteArrayOutputStream.toByteArray());

                SdsSendMailConfig sendMailConfig = sendMailConfigMap.get(departmentCode);
                FlowNetEmailVO flowNetEmailVO = new FlowNetEmailVO();
                flowNetEmailVO.setUserID(sendMailConfig.getUserId());
                flowNetEmailVO.setPassword(sendMailConfig.getPassWord());
                flowNetEmailVO.setMAILTO(sendMailConfig.getToAddress());
                flowNetEmailVO.setCC(StrUtil.isNotEmpty(sendMailConfig.getCcAddress()) ?
                        sendMailConfig.getCcAddress() : StrUtil.EMPTY);
                String mailTitle = sendMailConfig.getMailTitle();
                flowNetEmailVO.setSubject(String.format(mailTitle, departmentConfigMap.get(departmentCode), exportList.size()));
                flowNetEmailVO.setBODY(String.format(sendMailConfig.getMailContent(), uploadConfig.getDownloadUrl() + "?id=" + wmsFileDownloadLog.getId()));
                String flag = invokeFlowNetMailService(flowNetEmailVO);
                Boolean isSendMailSuccess = StrUtil.equals(flag, "Success") ?
                        Boolean.TRUE : Boolean.FALSE;
                if (BooleanUtil.isTrue(isSendMailSuccess)) {
                    steelScrapWeightRejectMapper.update(null, Wrappers.<SdsSteelScrapWeightReject>lambdaUpdate()
                            .set(SdsSteelScrapWeightReject::getSendMailFlag, "Y")
                            .in(SdsSteelScrapWeightReject::getId, departmentScrapRejectIdList)
                    );
                }
            } catch (Exception e) {
                log.error("固废拒收邮件通知失败：{}", e.getMessage());
            }
        });

    }

    @Override
    public void timeOutToRubbishSendMail() {
        List<SdsSendMailConfig> sendMailConfigList = sendMailConfigMapper.selectList(Wrappers.<SdsSendMailConfig>lambdaQuery()
                .eq(SdsSendMailConfig::getSendType, "SCRAP_TIMEOUT_TO_RUBBISH")
        );
        // 厂部->邮件信息
        Map<String, SdsSendMailConfig> sendMailConfigMap = sendMailConfigList.stream().collect(Collectors.toMap(k -> k.getDepartmentCode(), v -> v));

        LocalDateTime now = LocalDateTime.now();
        LocalDateTime minDateTime = now.plusHours((-1) * weighConfig.getRubbishTimeout().longValue());
        List<SdsSteelScrapWeightInfo> steelScrapWeightInfoList = steelScrapWeightInfoMapper.selectList(Wrappers.<SdsSteelScrapWeightInfo>lambdaQuery()
                .eq(SdsSteelScrapWeightInfo::getIsScrapArea, Boolean.TRUE)
                .eq(SdsSteelScrapWeightInfo::getRubbishWeighFlag, "N")
                .lt(SdsSteelScrapWeightInfo::getWeighDt, minDateTime)
                .ge(SdsSteelScrapWeightInfo::getWeighDt, weighConfig.getRubbishStartDate())
        );
        Map<String, Map<String, String>> dictMap = dictLangUtils.getByTypes(ListUtil.toList("SDS_ACCEPT_STATUS", "SDS_WEIGHT_STATUS", "SDS_SCRAP_SOLID", "SDS_SOLID_SCRAP_TYPE"));
        List<SdsDepartmentConfig> sdsDepartmentConfigList = departmentConfigMapper.selectList(Wrappers.<SdsDepartmentConfig>lambdaQuery()
                .select(SdsDepartmentConfig::getDepartmentCode, SdsDepartmentConfig::getDepartmentName)
        );
        Map<String, String> departmentConfigMap = sdsDepartmentConfigList.stream().collect(Collectors.toMap(k -> k.getDepartmentCode(), v -> v.getDepartmentName()));

        List<SteelScrapWeightInfoDTO> result = ListUtil.toList();
        steelScrapWeightInfoList.forEach(item -> {
            SteelScrapWeightInfoDTO dto = new SteelScrapWeightInfoDTO();
            BeanUtil.copyProperties(item, dto);
            dto.setWeighFlagName(dictMap.get("SDS_WEIGHT_STATUS").get(dto.getWeighFlag()));
            dto.setRubbishWeighFlagName(dictMap.get("SDS_WEIGHT_STATUS").get(dto.getRubbishWeighFlag()));
            dto.setAcceptFlagName(dictMap.get("SDS_ACCEPT_STATUS").get(dto.getAcceptFlag()));
            dto.setScrapDetailClassName(dictMap.get("SDS_SCRAP_SOLID").get(dto.getScrapDetailClass()));
            dto.setIsScrapAreaName(BooleanUtil.isTrue(dto.getIsScrapArea()) ? "Y" : "N");
            dto.setDepartmentCodeName(departmentConfigMap.get(dto.getDepartmentCode()));
            dto.setScrapTypeName(dictMap.get("SDS_SOLID_SCRAP_TYPE").get(dto.getScrapType()));
            result.add(dto);
        });

        Map<String, List<SteelScrapWeightInfoDTO>> steelWeightDepartmentMap = result.stream()
                .collect(Collectors.groupingBy(SteelScrapWeightInfoDTO::getDepartmentCode));

        steelWeightDepartmentMap.keySet().stream().forEach(departmentCode -> {
            if (!sendMailConfigMap.containsKey(departmentCode)) {
                return;
            }
            List<SteelScrapWeightInfoDTO> steelScrapWeightInfoDTOList = steelWeightDepartmentMap.get(departmentCode);
            steelScrapWeightInfoDTOList.sort(Comparator.comparing(SteelScrapWeightInfoDTO::getWeighDt));
            List<SteelScrapWeightInfoExportDTO> exportDTOList = ListUtil.toList();
            steelScrapWeightInfoDTOList.forEach(item -> {
                SteelScrapWeightInfoExportDTO dto = new SteelScrapWeightInfoExportDTO();
                BeanUtil.copyProperties(item, dto);
                exportDTOList.add(dto);
            });

            String fileName = "固废厂部超时未入废料厂明细" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
            try {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                EasyExcel.write(byteArrayOutputStream, SteelScrapWeightInfoExportDTO.class)
                        .sheet(fileName)
                        .doWrite(exportDTOList);
                SdsFileDownloadLog wmsFileDownloadLog = fileDownloadLogService.uploadFile("SCRAP_TIMEOUT_TO_RUBBISH", fileName, "SDS_JOB", byteArrayOutputStream.toByteArray());

                SdsSendMailConfig sendMailConfig = sendMailConfigMap.get(departmentCode);
                FlowNetEmailVO flowNetEmailVO = new FlowNetEmailVO();
                flowNetEmailVO.setUserID(sendMailConfig.getUserId());
                flowNetEmailVO.setPassword(sendMailConfig.getPassWord());
                flowNetEmailVO.setMAILTO(sendMailConfig.getToAddress());
                flowNetEmailVO.setCC(StrUtil.isNotEmpty(sendMailConfig.getCcAddress()) ?
                        sendMailConfig.getCcAddress() : StrUtil.EMPTY);
                String mailTitle = sendMailConfig.getMailTitle();
                flowNetEmailVO.setSubject(String.format(mailTitle, departmentConfigMap.get(departmentCode), weighConfig.getRubbishTimeout().toString()));
                flowNetEmailVO.setBODY(String.format(sendMailConfig.getMailContent(), uploadConfig.getDownloadUrl() + "?id=" + wmsFileDownloadLog.getId()));
                String flag = invokeFlowNetMailService(flowNetEmailVO);
                Boolean isSendMailSuccess = StrUtil.equals(flag, "Success") ?
                        Boolean.TRUE : Boolean.FALSE;
            } catch (Exception e) {
                log.error("固废厂部超时未入废料厂通知失败：{}", e.getMessage());
            }

        });


    }

    @Override
    @Transactional
    public synchronized OutFactoryWeightDTO outSourcedFactoryWeight(OutFactoryWeightVO vo) {
        // 調用ECUS接口
        BcwInfoDTO bcwInfoDTO = sdsSteelScrapShipHeaderService.requestBcwInfo(vo.getDeclareNumber());
        Map<String, Map<String, String>> dictMap = dictLangUtils.getByTypes(ListUtil.toList("SDS_OUT_SHIP_CONFIG"));
        String outFactoryDict = dictMap.get("SDS_OUT_SHIP_CONFIG").get("OUT");
        ArrayList outFactoryList = new ArrayList<>(Arrays.asList(outFactoryDict.split(",")));
        if (ObjectUtil.isNull(bcwInfoDTO)) {
            throw new CloudmesException("此单号在ECUS中不存在");
        }
        if (!outFactoryList.contains(bcwInfoDTO.getKFB04())) {
            throw new CloudmesException(String.format("此%s不是外发厂单号，不能在此页面操作", vo.getDeclareNumber()));
        }
        // 更新或者插入header
        OutFactoryWeightResultDTO outFactoryWeightResultDTO = updateScrapShipHeaderByDeclareNumber(bcwInfoDTO, vo.getDeclareNumber());
        String bucketNo = vo.getDepartmentCode() + vo.getDeclareNumber();
        SdsSteelScrapWeightInfo sdsSteelScrapWeightInfo = steelScrapWeightInfoMapper.selectOne(Wrappers.<SdsSteelScrapWeightInfo>lambdaQuery()
                .eq(SdsSteelScrapWeightInfo::getBucketNo, bucketNo)
        );
        SdsSteelBucketInfo steelBucketInfo = steelBucketInfoMapper.selectOne(Wrappers.<SdsSteelBucketInfo>lambdaQuery()
                .eq(SdsSteelBucketInfo::getBucketNo, bucketNo)
        );
        if (ObjectUtil.isNotNull(sdsSteelScrapWeightInfo)) {
            throw new CloudmesException("此单号已存在，不能重复作业");
        }
        if (ObjectUtil.isNotNull(steelBucketInfo)) {
            throw new CloudmesException("该托盘编码已维护");
        }
        SdsSteelBucketInfo sdsSteelBucketInfo = new SdsSteelBucketInfo();
        sdsSteelBucketInfo.setBucketNo(bucketNo);
        sdsSteelBucketInfo.setOrgCode(vo.getOrgCode());
        sdsSteelBucketInfo.setIsScrapArea(outFactoryWeightResultDTO.getSdsScrapSolidTypeConfig().getIsScrapArea());
        sdsSteelBucketInfo.setBucketWeight(outFactoryWeightResultDTO.getSdsSteelScrapShipHeader().getCarWeight());
        sdsSteelBucketInfo.setUom("KG");
        sdsSteelBucketInfo.setBucketType("pallet");
        sdsSteelBucketInfo.setScrapClass(outFactoryWeightResultDTO.getSdsScrapSolidTypeConfig().getScrapClass());
        sdsSteelBucketInfo.setScrapDetailClass(outFactoryWeightResultDTO.getSdsScrapSolidTypeConfig().getScrapDetailClass());
        sdsSteelBucketInfo.setScrapType(outFactoryWeightResultDTO.getSdsScrapSolidTypeConfig().getScrapType());
        sdsSteelBucketInfo.setIsScrapArea(outFactoryWeightResultDTO.getSdsScrapSolidTypeConfig().getIsScrapArea());
        sdsSteelBucketInfo.setDepartmentCode(vo.getDepartmentCode());
        steelBucketInfoMapper.insert(sdsSteelBucketInfo);
        OutFactoryWeightDTO outFactoryWeightDTO = new OutFactoryWeightDTO();
        outFactoryWeightDTO.setBucketNo(bucketNo);
        outFactoryWeightDTO.setBucketWeight(outFactoryWeightResultDTO.getSdsSteelScrapShipHeader().getCarWeight());
        outFactoryWeightDTO.setGrossWeight(outFactoryWeightResultDTO.getSdsSteelScrapShipHeader().getFullCarWeight());
        outFactoryWeightDTO.setNetWeight(outFactoryWeightResultDTO.getSdsSteelScrapShipHeader().getScrapNetWeight());
        outFactoryWeightDTO.setScrapDetailClassDesc(outFactoryWeightResultDTO.getSdsScrapSolidTypeConfig().getScrapDetailClassDesc());
        SdsSteelScrapWeightInfo newSteelScrapWeightInfo = new SdsSteelScrapWeightInfo();
        newSteelScrapWeightInfo.setId(null);
        newSteelScrapWeightInfo.setBucketNo(bucketNo);
        newSteelScrapWeightInfo.setOrgCode(vo.getOrgCode());
        newSteelScrapWeightInfo.setBucketWeight(outFactoryWeightResultDTO.getSdsSteelScrapShipHeader().getCarWeight());
        newSteelScrapWeightInfo.setUom("KG");
        newSteelScrapWeightInfo.setGrossWeight(outFactoryWeightResultDTO.getSdsSteelScrapShipHeader().getFullCarWeight());
        newSteelScrapWeightInfo.setNetWeight(outFactoryWeightResultDTO.getSdsSteelScrapShipHeader().getScrapNetWeight());
        newSteelScrapWeightInfo.setWeighDt(LocalDateTime.now());
        newSteelScrapWeightInfo.setWeighEmpNo(WebContextUtil.getCurrentStaffCode());
        newSteelScrapWeightInfo.setWeighFlag("Y");
        newSteelScrapWeightInfo.setAcceptFlag("Y");
        newSteelScrapWeightInfo.setAcceptDt(LocalDateTime.now());
        newSteelScrapWeightInfo.setAcceptEmpNo(WebContextUtil.getCurrentStaffCode());
        newSteelScrapWeightInfo.setScrapDetailClass(outFactoryWeightResultDTO.getSdsScrapSolidTypeConfig().getScrapDetailClass());
        newSteelScrapWeightInfo.setScrapClass(outFactoryWeightResultDTO.getSdsScrapSolidTypeConfig().getScrapClass());
        newSteelScrapWeightInfo.setRubbishWeighFlag("Y");
        newSteelScrapWeightInfo.setRubbishGrossWeight(outFactoryWeightResultDTO.getSdsSteelScrapShipHeader().getFullCarWeight());
        newSteelScrapWeightInfo.setRubbishNetWeight(outFactoryWeightResultDTO.getSdsSteelScrapShipHeader().getScrapNetWeight());
        newSteelScrapWeightInfo.setRubbishWeighDt(LocalDateTime.now());
        newSteelScrapWeightInfo.setRubbishWeighEmpNo(WebContextUtil.getCurrentStaffCode());
        newSteelScrapWeightInfo.setIsScrapArea(outFactoryWeightResultDTO.getSdsScrapSolidTypeConfig().getIsScrapArea());
        newSteelScrapWeightInfo.setScrapType(outFactoryWeightResultDTO.getSdsScrapSolidTypeConfig().getScrapType());
        newSteelScrapWeightInfo.setDepartmentCode(vo.getDepartmentCode());
        newSteelScrapWeightInfo.setSource("OUT-SHIP");
        steelScrapWeightInfoMapper.insert(newSteelScrapWeightInfo);
        SdsSteelScrapWeightInfoLog steelScrapWeightInfoLog = new SdsSteelScrapWeightInfoLog();
        BeanUtil.copyProperties(newSteelScrapWeightInfo, steelScrapWeightInfoLog);
        steelScrapWeightInfoLog.setId(null);
        steelScrapWeightInfoLog.setOperateType(SteelScrapOperateType.OUTSOURCED_FACTORY_WEIGH.getDictCode());
        steelScrapWeightInfoLog.setOperateMessage(SteelScrapOperateType.OUTSOURCED_FACTORY_WEIGH.getDictName());
        steelScrapWeightInfoLogMapper.insert(steelScrapWeightInfoLog);
        return outFactoryWeightDTO;
    }


    public OutFactoryWeightResultDTO updateScrapShipHeaderByDeclareNumber(BcwInfoDTO bcwInfoDTO, String declareNumber) {
        SdsSteelScrapShipHeader steelScrapShipHeader = sdsSteelScrapShipHeaderMapper.selectOne(Wrappers.<SdsSteelScrapShipHeader>lambdaQuery()
                .eq(SdsSteelScrapShipHeader::getDeclareNumber, declareNumber)
                .last("limit 1")
        );
        String scrapPartNo = bcwInfoDTO.getBCW06();
        SdsScrapSolidTypeConfig sdsScrapSolidTypeConfig = sdsScrapSolidTypeConfigMapper.selectOne(Wrappers.<SdsScrapSolidTypeConfig>lambdaQuery()
                .eq(SdsScrapSolidTypeConfig::getScrapPartNo, scrapPartNo)
                .last("limit 1")
        );
        String scrapDetailClass = sdsScrapSolidTypeConfig.getScrapDetailClass();
        String sdsScrapType = sdsScrapSolidTypeConfig.getScrapType();
        if (StrUtil.isBlank(bcwInfoDTO.getBCW14())) {
            throw new CloudmesException("ECUS未维护废料净重");
        }
        if (ObjectUtil.isNull(steelScrapShipHeader)) {
            steelScrapShipHeader = new SdsSteelScrapShipHeader();
            steelScrapShipHeader.setDeclareNumber(bcwInfoDTO.getBCW01());
            steelScrapShipHeader.setManFacturer(bcwInfoDTO.getBCW37());
            steelScrapShipHeader.setScrapPartName(bcwInfoDTO.getBCW07());
            steelScrapShipHeader.setScrapPartNo(bcwInfoDTO.getBCW06());
            if (StrUtil.isBlank(steelScrapShipHeader.getScrapPartNo())) {
                throw new CloudmesException("同步ECUS废料料号为空，不能同步");
            }
            if (ObjectUtil.isNull(sdsScrapSolidTypeConfig)) {
                throw new CloudmesException(String.format("报废料号%s没有配置与报废类型的对应关系", steelScrapShipHeader.getScrapPartNo()));
            }
            steelScrapShipHeader.setSdsScrapType(sdsScrapType);
            steelScrapShipHeader.setScrapDetailClass(scrapDetailClass);
            steelScrapShipHeader.setCustomsCode(bcwInfoDTO.getBCW03());
            steelScrapShipHeader.setScrapType(bcwInfoDTO.getKXA03());
            steelScrapShipHeader.setAreaCode(bcwInfoDTO.getKFB04());
            steelScrapShipHeader.setLicenseCarNumber(bcwInfoDTO.getBCW051());
            steelScrapShipHeader.setDriver(bcwInfoDTO.getBCW052());
            steelScrapShipHeader.setApplyor(bcwInfoDTO.getBCW50());
            if (StrUtil.isNotBlank(bcwInfoDTO.getBCW02())) {
                steelScrapShipHeader.setApplyDt(LocalDateTimeUtil.parse(bcwInfoDTO.getBCW02(), DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'+08:00'")));
            }
            steelScrapShipHeader.setShippingCorporation(bcwInfoDTO.getKWY02());
            steelScrapShipHeader.setCostCode(bcwInfoDTO.getBCW10());
            steelScrapShipHeader.setUom(bcwInfoDTO.getGFE02());
            steelScrapShipHeader.setFiledNumber(bcwInfoDTO.getBCW29());
            steelScrapShipHeader.setLockNumber(bcwInfoDTO.getKFA06());
            steelScrapShipHeader.setCarToolBox(bcwInfoDTO.getKFA18());
            steelScrapShipHeader.setCarFuelTank(bcwInfoDTO.getKFA15());
            steelScrapShipHeader.setCarSteelRing(bcwInfoDTO.getKFA19());
            steelScrapShipHeader.setCarWaterTank(bcwInfoDTO.getKFA16());
            steelScrapShipHeader.setCarSpareTire(bcwInfoDTO.getKFA17());
            if (StrUtil.isNotBlank(bcwInfoDTO.getBCW11())) {
                steelScrapShipHeader.setCarWeight(new BigDecimal(bcwInfoDTO.getBCW11()));
            }
            if (StrUtil.isNotBlank(bcwInfoDTO.getBCW021())) {
                steelScrapShipHeader.setEntryTime(LocalDateTime.parse(bcwInfoDTO.getBCW021(), DateTimeFormatter.ofPattern("yyyyMMddHHmm")));
            }
            steelScrapShipHeader.setCarWeightEmp(bcwInfoDTO.getBCW39());
            steelScrapShipHeader.setCarWeightDt(steelScrapShipHeader.getEntryTime());

            steelScrapShipHeader.setWeightUom(bcwInfoDTO.getBCW16());
            if (StrUtil.isNotBlank(bcwInfoDTO.getBCW12())) {
                steelScrapShipHeader.setFullCarWeight(new BigDecimal(bcwInfoDTO.getBCW12()));
            }
            if (StrUtil.isNotBlank(bcwInfoDTO.getBCW023())) {
                steelScrapShipHeader.setLeaveTime(LocalDateTime.parse(bcwInfoDTO.getBCW023(), DateTimeFormatter.ofPattern("yyyyMMddHHmm")));
            }
            steelScrapShipHeader.setFullCarWeightEmp(bcwInfoDTO.getBCW40());
            steelScrapShipHeader.setFullCarWeightDt(steelScrapShipHeader.getLeaveTime());
            steelScrapShipHeader.setScrapAreaStatus("0");

            if (StrUtil.isNotBlank(bcwInfoDTO.getBCW17())) {
                steelScrapShipHeader.setPrice(new BigDecimal(bcwInfoDTO.getBCW17()));
            }
            steelScrapShipHeader.setMfgCode(bcwInfoDTO.getBCW04());
            steelScrapShipHeader.setScrapNetWeight(new BigDecimal(bcwInfoDTO.getBCW14()));
            sdsSteelScrapShipHeaderMapper.insert(steelScrapShipHeader);
            OutFactoryWeightResultDTO outFactoryWeightResultDTO = new OutFactoryWeightResultDTO();
            outFactoryWeightResultDTO.setSdsSteelScrapShipHeader(steelScrapShipHeader);
            outFactoryWeightResultDTO.setSdsScrapSolidTypeConfig(sdsScrapSolidTypeConfig);
            return outFactoryWeightResultDTO;
        } else {
            log.info("更新出货header ----------");
            sdsSteelScrapShipHeaderMapper.update(null, Wrappers.<SdsSteelScrapShipHeader>lambdaUpdate()
                    .set(SdsSteelScrapShipHeader::getManFacturer, bcwInfoDTO.getBCW37())
                    .set(SdsSteelScrapShipHeader::getScrapPartName, bcwInfoDTO.getBCW07())
                    .set(SdsSteelScrapShipHeader::getScrapPartNo, bcwInfoDTO.getBCW06())
                    .set(SdsSteelScrapShipHeader::getSdsScrapType, sdsScrapType)
                    .set(SdsSteelScrapShipHeader::getScrapDetailClass, scrapDetailClass)
                    .set(SdsSteelScrapShipHeader::getCustomsCode, bcwInfoDTO.getBCW03())
                    .set(SdsSteelScrapShipHeader::getScrapType, bcwInfoDTO.getKXA03())
                    .set(SdsSteelScrapShipHeader::getAreaCode, bcwInfoDTO.getKFB04())
                    .set(SdsSteelScrapShipHeader::getLicenseCarNumber, bcwInfoDTO.getBCW051())
                    .set(SdsSteelScrapShipHeader::getApplyor, bcwInfoDTO.getBCW50())
                    .set(SdsSteelScrapShipHeader::getDriver, bcwInfoDTO.getBCW052())
                    .set(SdsSteelScrapShipHeader::getShippingCorporation, bcwInfoDTO.getKWY02())
                    .set(SdsSteelScrapShipHeader::getCostCode, bcwInfoDTO.getBCW10())
                    .set(SdsSteelScrapShipHeader::getUom, bcwInfoDTO.getGFE02())
                    .set(SdsSteelScrapShipHeader::getFiledNumber, bcwInfoDTO.getBCW29())
                    .set(SdsSteelScrapShipHeader::getLockNumber, bcwInfoDTO.getKFA06())
                    .set(SdsSteelScrapShipHeader::getCarToolBox, bcwInfoDTO.getKFA18())
                    .set(SdsSteelScrapShipHeader::getCarFuelTank, bcwInfoDTO.getKFA15())
                    .set(SdsSteelScrapShipHeader::getCarSteelRing, bcwInfoDTO.getKFA19())
                    .set(SdsSteelScrapShipHeader::getCarWaterTank, bcwInfoDTO.getKFA16())
                    .set(SdsSteelScrapShipHeader::getCarSpareTire, bcwInfoDTO.getKFA17())
                    .set(SdsSteelScrapShipHeader::getCarWeightEmp, bcwInfoDTO.getBCW39())
                    .set(SdsSteelScrapShipHeader::getCarWeightDt, steelScrapShipHeader.getEntryTime())
                    .set(SdsSteelScrapShipHeader::getWeightUom, bcwInfoDTO.getBCW16())
                    .set(SdsSteelScrapShipHeader::getFullCarWeightEmp, bcwInfoDTO.getBCW40())
                    .set(SdsSteelScrapShipHeader::getFullCarWeightDt, steelScrapShipHeader.getLeaveTime())
                    .set(SdsSteelScrapShipHeader::getScrapAreaStatus, "0")
                    .set(SdsSteelScrapShipHeader::getMfgCode, bcwInfoDTO.getBCW04())
                    .set(StrUtil.isNotBlank(bcwInfoDTO.getBCW02()), SdsSteelScrapShipHeader::getApplyDt,
                            LocalDateTimeUtil.parse(bcwInfoDTO.getBCW02(), DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'+08:00'")))
                    .set(StrUtil.isNotBlank(bcwInfoDTO.getBCW11()), SdsSteelScrapShipHeader::getCarWeight, new BigDecimal(bcwInfoDTO.getBCW11()))
                    .set(StrUtil.isNotBlank(bcwInfoDTO.getBCW021()), SdsSteelScrapShipHeader::getEntryTime, LocalDateTime.parse(bcwInfoDTO.getBCW021(), DateTimeFormatter.ofPattern("yyyyMMddHHmm")))
                    .set(StrUtil.isNotBlank(bcwInfoDTO.getBCW12()), SdsSteelScrapShipHeader::getFullCarWeight, new BigDecimal(bcwInfoDTO.getBCW12()))
                    .set(StrUtil.isNotBlank(bcwInfoDTO.getBCW023()), SdsSteelScrapShipHeader::getLeaveTime, LocalDateTime.parse(bcwInfoDTO.getBCW023(), DateTimeFormatter.ofPattern("yyyyMMddHHmm")))
                    .set(StrUtil.isNotBlank(bcwInfoDTO.getBCW17()), SdsSteelScrapShipHeader::getPrice, new BigDecimal(bcwInfoDTO.getBCW17()))
                    .set(StrUtil.isNotBlank(bcwInfoDTO.getBCW14()), SdsSteelScrapShipHeader::getScrapNetWeight, new BigDecimal(bcwInfoDTO.getBCW14()))
                    .eq(SdsSteelScrapShipHeader::getDeclareNumber, declareNumber)
            );
            SdsSteelScrapShipHeader sdsSteelScrapShipHeader = sdsSteelScrapShipHeaderMapper.selectOne(Wrappers.<SdsSteelScrapShipHeader>lambdaQuery()
                    .eq(SdsSteelScrapShipHeader::getDeclareNumber, declareNumber)
                    .last("limit 1")
            );
            OutFactoryWeightResultDTO outFactoryWeightResultDTO = new OutFactoryWeightResultDTO();
            outFactoryWeightResultDTO.setSdsSteelScrapShipHeader(sdsSteelScrapShipHeader);
            outFactoryWeightResultDTO.setSdsScrapSolidTypeConfig(sdsScrapSolidTypeConfig);
            return outFactoryWeightResultDTO;
        }
    }
    
    @Transactional(rollbackFor = Exception.class)
    @Override
    public SyncWmsScrapHandlePalletDTO syncWmsScrapHandlePallet(SyncWmsScrapHandlePalletVO vo) {
        SyncWmsScrapHandlePalletDTO dto = new SyncWmsScrapHandlePalletDTO();
        SdsSolidWmsConfig solidWmsConfig = solidWmsConfigMapper.selectOne(Wrappers.<SdsSolidWmsConfig>lambdaQuery()
                .eq(SdsSolidWmsConfig::getOrgCode, vo.getOrgCode())
                .eq(SdsSolidWmsConfig::getScrapClass, vo.getWmsScrapType())
                .last("limit 1")
        );
        if (ObjectUtil.isNull(solidWmsConfig)) {
            dto.setMessage("未找到WMS与SDS的报废料号对应关系，不需要抛转SDS");
            return dto;
        }

        SdsDepartmentConfig departmentConfig = departmentConfigMapper.selectOne(Wrappers.<SdsDepartmentConfig>lambdaQuery()
                .eq(SdsDepartmentConfig::getOrgCode, vo.getOrgCode())
                .eq(SdsDepartmentConfig::getDepartmentCode, solidWmsConfig.getSdsDepartmentCode())
                .last("limit 1")
        );
        if (ObjectUtil.isNull(departmentConfig)) {
            throw new CloudmesException("WMS与SDS的报废料号对应关系中的部门在SDS中不存在");
        }
        SdsScrapSolidTypeConfig scrapSolidTypeConfig = scrapSolidTypeConfigMapper.selectOne(Wrappers.<SdsScrapSolidTypeConfig>lambdaQuery()
                .eq(SdsScrapSolidTypeConfig::getScrapDetailClass, solidWmsConfig.getSdsScrapDetailClass())
                .last("limit 1")
        );
        if (ObjectUtil.isNull(scrapSolidTypeConfig)) {
            throw new CloudmesException("WMS与SDS的报废料号对应关系中配置的SDS料号在SDS中不存在");
        }

        Map<String, String> palletWeightMap = dictLangUtils.getByType("SDS_ACCEPT_WMS_PALLET_WEIGHT");
        // 不配置默认15KG
        BigDecimal palletWeight = palletWeightMap.containsKey(vo.getOrgCode())
                ? new BigDecimal(palletWeightMap.get(vo.getOrgCode())) : BigDecimal.valueOf(15);

        SdsSteelBucketInfo sdsSteelBucketInfo = steelBucketInfoMapper.selectOne(Wrappers.<SdsSteelBucketInfo>lambdaQuery()
                .eq(SdsSteelBucketInfo::getBucketNo, vo.getBucketNo())
                .last("limit 1")
        );
        if (ObjectUtil.isNull(sdsSteelBucketInfo)) {
            sdsSteelBucketInfo = new SdsSteelBucketInfo();
            sdsSteelBucketInfo.setOrgCode(vo.getOrgCode());
            sdsSteelBucketInfo.setBucketNo(vo.getBucketNo());
            sdsSteelBucketInfo.setBucketType(BucketTypeEnum.PALLET.getDictCode());
            sdsSteelBucketInfo.setBucketWeight(palletWeight);
            sdsSteelBucketInfo.setScrapDetailClass(solidWmsConfig.getSdsScrapDetailClass());
            sdsSteelBucketInfo.setIsScrapArea(scrapSolidTypeConfig.getIsScrapArea());
            sdsSteelBucketInfo.setScrapType(scrapSolidTypeConfig.getScrapType());
            sdsSteelBucketInfo.setDepartmentCode(solidWmsConfig.getSdsDepartmentCode());
            steelBucketInfoMapper.insert(sdsSteelBucketInfo);
        }

        // 插入称重记录
        SteelScrapWeightSubmitVO steelScrapWeightSubmitVO = new SteelScrapWeightSubmitVO();
        steelScrapWeightSubmitVO.setGrossWeight(vo.getGrossWeight());
        steelScrapWeightSubmitVO.setOrgCode(vo.getOrgCode());
        steelScrapWeightSubmitVO.setBucketNo(vo.getBucketNo());
        steelScrapWeightSubmitVO.setSource("WMS");
        steelScrapWeightSubmitVO.setSourceDocNo(vo.getScrapHandleDocNo());
        steelScrapWeightSubmitVO.setWeightEmpNo(vo.getWeighEmpNo());
        steelScrapWeightSubmitVO.setWeighDt(vo.getWeighDt());
        submitWeightInfo(steelScrapWeightSubmitVO);

        dto.setMessage("OK");
        return dto;
    }

    public String invokeFlowNetMailService(FlowNetEmailVO flowNetEmailVO) {
        FlownetResponse response;
        String result;
        String flowNetMailUrl = flowNetUrlConfig.getMailUrl();
        try {
            result = HttpUtil.createPost(flowNetMailUrl)
                    .header("Content-Type", "application/json;charset=UTF-8")
                    .setConnectionTimeout(30 * 1000)
                    .setReadTimeout(180 * 1000)
                    .body(JSONUtil.toJsonStr(flowNetEmailVO))
                    .execute()
                    .body();
            log.info("sendMailBatchToFlowNet：::requestJson={},url={},result={},current-time:{}",
                    JSONUtil.toJsonStr(flowNetEmailVO), flowNetMailUrl, result, System.currentTimeMillis());
            response = com.alibaba.fastjson.JSON.parseObject(result, FlownetResponse.class);
        } catch (Exception e) {
            log.error("sendMailBatchToFlowNet ERROR:{}", e.getMessage(), e);
            throw new CloudmesException("调用flownet失败");
        }
        return response.getFlag();
    }

}
