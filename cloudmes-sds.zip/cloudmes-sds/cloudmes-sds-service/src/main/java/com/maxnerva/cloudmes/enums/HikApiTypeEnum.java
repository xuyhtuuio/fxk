package com.maxnerva.cloudmes.enums;

public enum HikApiTypeEnum {
    /**
     *  海康Api一览
     */

    /** 参数： cameraIndexCode */
    GET_PICTURE_ON_TIME("GET_PICTURE_ON_TIME","/api/video/v1/manualCapture"),

    /** 参数： name 地区名字   pageNo pageIndex beginTime  endTime*/
    SEARCH_AREA("SEARCH_AREA", "/api/resource/v2/camera/search");



    private String dictCode;

    private String dictName;

    HikApiTypeEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

}
