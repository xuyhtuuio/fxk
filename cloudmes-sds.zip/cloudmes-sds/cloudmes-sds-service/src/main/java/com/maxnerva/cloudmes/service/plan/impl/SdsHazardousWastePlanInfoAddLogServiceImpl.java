package com.maxnerva.cloudmes.service.plan.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.map.MapUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpStatus;
import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONConfig;
import cn.hutool.json.JSONUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.enums.ResultCode;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.common.utils.WebContextUtil;
import com.maxnerva.cloudmes.config.FlowNetUrlConfig;
import com.maxnerva.cloudmes.enums.CodeRuleEnum;
import com.maxnerva.cloudmes.enums.SdsResultCode;
import com.maxnerva.cloudmes.enums.WastePlanDocStatusEnum;
import com.maxnerva.cloudmes.excel.handler.AddNoHandler;
import com.maxnerva.cloudmes.feign.basic.ICodeRuleClient;
import com.maxnerva.cloudmes.mapper.basic.SdsFlownetProcessConfigMapper;
import com.maxnerva.cloudmes.mapper.basic.SdsHazardousWasteFlownetRequestLogMapper;
import com.maxnerva.cloudmes.mapper.plan.SdsHazardousWastePlanInfoAddLogMapper;
import com.maxnerva.cloudmes.mapper.plan.SdsHazardousWastePlanInfoMapper;
import com.maxnerva.cloudmes.models.dto.basic.FlownetErrorResponse;
import com.maxnerva.cloudmes.models.dto.basic.FlownetResponse;
import com.maxnerva.cloudmes.models.dto.basic.FlownetResponseData;
import com.maxnerva.cloudmes.models.dto.excel.plan.PlanInfoAddLogExportDTO;
import com.maxnerva.cloudmes.models.dto.plan.PlanInfoAddLogDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsFlownetProcessConfig;
import com.maxnerva.cloudmes.models.entity.basic.SdsHazardousWasteFlownetRequestLog;
import com.maxnerva.cloudmes.models.entity.plan.SdsHazardousWastePlanInfoAddLog;
import com.maxnerva.cloudmes.models.vo.CommonFlownetVO;
import com.maxnerva.cloudmes.models.vo.plan.*;
import com.maxnerva.cloudmes.service.datahub.DataHubService;
import com.maxnerva.cloudmes.service.plan.ISdsHazardousWastePlanInfoAddLogService;
import com.maxnerva.cloudmes.system.feign.IOrganizationClient;
import com.maxnerva.cloudmes.system.utils.DictLangUtils;
import jodd.util.StringUtil;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.MimeTypeUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.time.LocalDateTime;
import java.util.*;

/**
 * <p>
 * 年度计划说明表 服务实现类
 * </p>
 *
 * @author likun
 * @since 2025-05-08
 */
@Slf4j
@Service
public class SdsHazardousWastePlanInfoAddLogServiceImpl extends ServiceImpl<SdsHazardousWastePlanInfoAddLogMapper,
        SdsHazardousWastePlanInfoAddLog> implements ISdsHazardousWastePlanInfoAddLogService {

    @Resource
    private ICodeRuleClient codeRuleClient;

    @Resource
    private DictLangUtils dictLangUtils;

    @Resource
    private IOrganizationClient organizationClient;

    @Resource
    private DataHubService dataHubService;

    @Resource
    private SdsHazardousWasteFlownetRequestLogMapper sdsHazardousWasteFlownetRequestLogMapper;

    @Resource
    private SdsHazardousWastePlanInfoMapper sdsHazardousWastePlanInfoMapper;

    @Resource
    private SdsFlownetProcessConfigMapper sdsFlownetProcessConfigMapper;

    @Resource
    private FlowNetUrlConfig flowNetUrlConfig;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void savePlanInfoAddLog(PlanInfoAddLogSaveVO saveVO) {
        String orgCode = saveVO.getOrgCode();
        String planDocNo = saveVO.getPlanDocNo();
        List<String> docStatusList = CollUtil.newArrayList();
        docStatusList.add(WastePlanDocStatusEnum.CREATE.getDictCode());
        docStatusList.add(WastePlanDocStatusEnum.SIGN.getDictCode());
        Long count = baseMapper.selectCount(Wrappers.<SdsHazardousWastePlanInfoAddLog>lambdaQuery()
                .eq(SdsHazardousWastePlanInfoAddLog::getOrgCode, orgCode)
                .eq(SdsHazardousWastePlanInfoAddLog::getPlanDocNo, planDocNo)
                .in(SdsHazardousWastePlanInfoAddLog::getDocStatus, docStatusList));
        if (count > 0) {
            throw new CloudmesException(SdsResultCode.PLAN_DOC_NO_IN_ADD_LOG_UN_AUDITED_CAN_NOT_REPEAT_APPLY.getCode(),
                    String.format(MessageUtils.get(SdsResultCode.PLAN_DOC_NO_IN_ADD_LOG_UN_AUDITED_CAN_NOT_REPEAT_APPLY
                            .getLocalCode()), planDocNo));
        }
        SdsHazardousWastePlanInfoAddLog sdsHazardousWastePlanInfoAddLog = new SdsHazardousWastePlanInfoAddLog();
        BeanUtils.copyProperties(saveVO, sdsHazardousWastePlanInfoAddLog);
        HashMap<String, String> map = MapUtil.newHashMap();
        String simpleCode = organizationClient.getSimpleCodeByOrgCode(orgCode).getData();
        map.put("BU", simpleCode);
        String serialNo;
        R<List<String>> result = codeRuleClient.getSerialNumberAndParams(CodeRuleEnum.SDS_WASTE_PLAN_EXPLAIN_DOC_NO
                .getDictCode(), 1, map);
        if (result.getCode() == ResultCode.SUCCESS.getCode()) {
            serialNo = result.getData().get(0);
        } else {
            throw new CloudmesException(SdsResultCode.CONNECT_BASIC_GET_SERIAL_NUMBER.getCode()
                    , MessageUtils.get(SdsResultCode.CONNECT_BASIC_GET_SERIAL_NUMBER.getLocalCode()));
        }
        sdsHazardousWastePlanInfoAddLog.setDocNo(serialNo);
        sdsHazardousWastePlanInfoAddLog.setOldPlanWeight(saveVO.getPlanWeight());
        //获取送签流程id
        SdsFlownetProcessConfig flownetProcessConfig = sdsFlownetProcessConfigMapper
                .selectOne(Wrappers.<SdsFlownetProcessConfig>lambdaQuery()
                        .eq(SdsFlownetProcessConfig::getOrgCode, orgCode)
                        .eq(SdsFlownetProcessConfig::getDocType, "PLAN_INFO_ADD_LOG")
                        .last("limit 1"));
        if (ObjectUtil.isNull(flownetProcessConfig) || StringUtil.isEmpty(flownetProcessConfig.getFlownetProcessId())) {
            throw new CloudmesException(SdsResultCode.THE_DOCUMENT_CHECK_FLOW_IS_NOT_CONFIGURED.getCode()
                    , MessageUtils.get(SdsResultCode.THE_DOCUMENT_CHECK_FLOW_IS_NOT_CONFIGURED.getLocalCode()));
        }
        sdsHazardousWastePlanInfoAddLog.setFlownetProcessId(flownetProcessConfig.getFlownetProcessId());
        baseMapper.insert(sdsHazardousWastePlanInfoAddLog);
    }

    @Override
    public void updatePlanInfoAddLog(PlanInfoAddLogUpdateVO updateVO) {
        Integer id = updateVO.getId();
        BigDecimal planAddWeight = updateVO.getPlanAddWeight();
        SdsHazardousWastePlanInfoAddLog sdsHazardousWastePlanInfoAddLog = baseMapper.selectById(id);
        if (WastePlanDocStatusEnum.SIGN.getDictCode().equals(sdsHazardousWastePlanInfoAddLog.getDocStatus())||
                WastePlanDocStatusEnum.AUDIT.getDictCode().equals(sdsHazardousWastePlanInfoAddLog.getDocStatus())) {
            throw new CloudmesException(SdsResultCode.SIGN_OR_AUDIT_CAN_NOT_EDIT.getCode(),
                    MessageUtils.get(SdsResultCode.SIGN_OR_AUDIT_CAN_NOT_EDIT.getLocalCode()));
        }
        baseMapper.update(null, Wrappers.<SdsHazardousWastePlanInfoAddLog>lambdaUpdate()
                .eq(SdsHazardousWastePlanInfoAddLog::getId, id)
                .set(SdsHazardousWastePlanInfoAddLog::getPlanAddWeight, planAddWeight)
                .set(SdsHazardousWastePlanInfoAddLog::getLastEditor, WebContextUtil.getCurrentStaffCode())
                .set(SdsHazardousWastePlanInfoAddLog::getLastEditedDt, LocalDateTime.now()));
    }

    @Override
    public PageDataDTO<PlanInfoAddLogDTO> selectPlanInfoAddLogPage(PlanInfoAddLogQueryVO queryVO) {
        if (queryVO.getPageIndex() != null && queryVO.getPageSize() != null
                && queryVO.getPageIndex() != 0 && queryVO.getPageSize() != 0) {
            Page page = PageHelper.startPage(queryVO.getPageIndex(), queryVO.getPageSize());
            List<PlanInfoAddLogDTO> planInfoAddLogDTOList = getPlanInfoAddLogDTOList(queryVO);
            return new PageDataDTO<>(page.getTotal(), planInfoAddLogDTOList);
        } else {
            List<PlanInfoAddLogDTO> planInfoAddLogDTOList = getPlanInfoAddLogDTOList(queryVO);
            return new PageDataDTO<>((long) planInfoAddLogDTOList.size(), planInfoAddLogDTOList);
        }
    }

    @NotNull
    private List<PlanInfoAddLogDTO> getPlanInfoAddLogDTOList(PlanInfoAddLogQueryVO queryVO) {
        List<PlanInfoAddLogDTO> planInfoAddLogDTOList = baseMapper.selectPlanInfoAddLogList(queryVO);
        Map<String, String> docStatusMap = dictLangUtils.getByType("SDS_PLAN_INFO_DOC_STATUS");
        planInfoAddLogDTOList.forEach(planInfoAddLogDTO -> planInfoAddLogDTO.setDocStatusName(docStatusMap
                .get(planInfoAddLogDTO.getDocStatus())));
        return planInfoAddLogDTOList;
    }

    @Override
    public void deletePlanInfoAddLog(Integer id) {
        SdsHazardousWastePlanInfoAddLog sdsHazardousWastePlanInfoAddLog = baseMapper.selectById(id);
        String docStatus = sdsHazardousWastePlanInfoAddLog.getDocStatus();
        if (WastePlanDocStatusEnum.SIGN.getDictCode().equals(docStatus) ||
                WastePlanDocStatusEnum.AUDIT.getDictCode().equals(docStatus)) {
            throw new CloudmesException(SdsResultCode.PLAN_INFO_ADD_LOG_SIGNED_OR_AUDIT_CAN_NOT_DELETE.getCode(),
                    MessageUtils.get(SdsResultCode.PLAN_INFO_ADD_LOG_SIGNED_OR_AUDIT_CAN_NOT_DELETE.getLocalCode()));
        }
        baseMapper.deleteById(id);
    }

    @Override
    public void exportPlanInfoAddLog(HttpServletResponse response, PlanInfoAddLogQueryVO queryVO) {
        List<PlanInfoAddLogExportDTO> exportDTOList = CollUtil.newArrayList();
        List<PlanInfoAddLogDTO> planInfoAddLogDTOList = getPlanInfoAddLogDTOList(queryVO);
        planInfoAddLogDTOList.forEach(planInfoAddLogDTO -> {
            PlanInfoAddLogExportDTO planInfoAddLogExportDTO = new PlanInfoAddLogExportDTO();
            BeanUtils.copyProperties(planInfoAddLogDTO, planInfoAddLogExportDTO);
            exportDTOList.add(planInfoAddLogExportDTO);
        });
        String fileName = "年度计划说明信息" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
        try {
            response.setContentType(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8") + "\"");
            //将导出数据写入文件
            EasyExcel.write(response.getOutputStream(), PlanInfoAddLogExportDTO.class).sheet(fileName)
                    .registerWriteHandler(new AddNoHandler())
                    .doWrite(exportDTOList);
        } catch (Exception e) {
            throw new CloudmesException(SdsResultCode.PLAN_INFO_ADD_LOG_EXPORT_FAIL.getCode(),
                    MessageUtils.get(SdsResultCode.PLAN_INFO_ADD_LOG_EXPORT_FAIL.getLocalCode()));
        }
    }

    @Override
    public R<Void> approvalCompleted(String jsonString) {
        List<PlanFlownetApprovalVO> planFlownetApprovalVOList = CollUtil.newArrayList();
        PlanFlownetApprovalVO planFlownetApprovalVO = new PlanFlownetApprovalVO();
        planFlownetApprovalVO.setJsonString(jsonString);
        planFlownetApprovalVOList.add(planFlownetApprovalVO);
        HttpResponse httpResponse = dataHubService.flownetPlanInfoAddLogApprovalCompleted(planFlownetApprovalVOList);
        String body = httpResponse.body();
        if (StrUtil.isEmpty(body)) {
            throw new CloudmesException(SdsResultCode.FLOWNET_AN_EXCEPTION_OCCURS_WHEN_INTERFACE_INVOCATION_IS_APPROVED
                    .getCode(), MessageUtils.get(SdsResultCode
                    .FLOWNET_AN_EXCEPTION_OCCURS_WHEN_INTERFACE_INVOCATION_IS_APPROVED.getLocalCode()));
        }
        log.info("approvalCompleted jsonString:{}, call datahub return:{}", jsonString, body);
        if (httpResponse.getStatus() == HttpStatus.HTTP_OK) {
            JSONObject dataHubReturnInfo = JSON.parseObject(body);
            int code = dataHubReturnInfo.getInteger("code");
            String msg = dataHubReturnInfo.getString("msg");
            if (200 != code) {
                return R.no(code, msg);
            }
            return R.ok();
        }
        throw new CloudmesException(SdsResultCode.FLOWNET_AN_EXCEPTION_OCCURS_WHEN_INTERFACE_INVOCATION_IS_APPROVED
                .getCode(), MessageUtils.get(SdsResultCode
                .FLOWNET_AN_EXCEPTION_OCCURS_WHEN_INTERFACE_INVOCATION_IS_APPROVED.getLocalCode()));
    }

    @Transactional
    @Override
    public void flownetApproval(List<PlanFlownetApprovalVO> approvalVOList) {
        String jsonString = approvalVOList.get(0).getJsonString();
        JSONObject jsonObject = JSONObject.parseObject(jsonString);
        //审批状态
        String approvalStatus = jsonObject.getString("flownetFormStatus");
        //单号
        String docNo = jsonObject.getString("businessRequestNo");
        log.info("plan info add log flownetApproval datahub parameter=========》：::docNo={}", docNo);
        String currentStaffCode = WebContextUtil.getCurrentStaffCode();
        try {
            SdsHazardousWastePlanInfoAddLog sdsHazardousWastePlanInfoAddLog = baseMapper
                    .selectOne(Wrappers.<SdsHazardousWastePlanInfoAddLog>lambdaQuery()
                            .eq(SdsHazardousWastePlanInfoAddLog::getDocNo, docNo)
                            .last("limit 1"));
            Optional.ofNullable(sdsHazardousWastePlanInfoAddLog)
                    .orElseThrow(() -> new CloudmesException(SdsResultCode.NOT_FOUND_PLAN_INFO_ADD_LOG.getCode(),
                            MessageUtils.get(SdsResultCode.NOT_FOUND_PLAN_INFO_ADD_LOG.getLocalCode())));
            String status = "Approved".equals(approvalStatus) ? WastePlanDocStatusEnum.AUDIT.getDictCode() :
                    WastePlanDocStatusEnum.REJECT.getDictCode();
            sdsHazardousWastePlanInfoAddLog.setDocStatus(status);
            sdsHazardousWastePlanInfoAddLog.setFlownetMsg(jsonString);
            sdsHazardousWastePlanInfoAddLog.setFlownetApprovalResult(approvalStatus);
            baseMapper.updateById(sdsHazardousWastePlanInfoAddLog);
            //单据签核完成后，将增加量累加到年度计划的当前计划量中sds_hazardous_waste_plan_info表中的plan_weight中
            if (WastePlanDocStatusEnum.AUDIT.getDictCode().equals(status)) {
                String planDocNo = sdsHazardousWastePlanInfoAddLog.getPlanDocNo();
                sdsHazardousWastePlanInfoMapper.addPlanWeight(planDocNo, sdsHazardousWastePlanInfoAddLog
                        .getPlanAddWeight(), currentStaffCode);
            }
        } catch (Exception e) {
            log.info("plan info add log flownetApproval datahub paramete docNo:{}, exception:{}", docNo,
                    e.getMessage());
            throw new CloudmesException(e.getMessage());
        } finally {
            //产生调用记录
            SdsHazardousWasteFlownetRequestLog requestLog = new SdsHazardousWasteFlownetRequestLog();
            requestLog.setRequestJson(jsonString);
            sdsHazardousWasteFlownetRequestLogMapper.insert(requestLog);
        }
    }

    @Override
    public HashMap<String, String> sendToSign(HttpServletRequest request, Integer id) {
        PlanInfoAddLogDTO planInfoAddLogDTO = baseMapper.selectPlanInfoAddLogById(id);
        CommonFlownetVO commonFlownetVO = new CommonFlownetVO();
        commonFlownetVO.setBusinessProcessID(planInfoAddLogDTO.getFlownetProcessId());
        commonFlownetVO.setBusinessRequestor(planInfoAddLogDTO.getCreator());
        commonFlownetVO.setBusinessRequestorName("");
        commonFlownetVO.setBusinessRequestNo(planInfoAddLogDTO.getDocNo());
        commonFlownetVO.setFlownetFormID("");
        commonFlownetVO.setFlowableInstanceID("");
        commonFlownetVO.setFlownetFormStatus("NewCreate");
        PlanInfoAddLogFlownetJsonVO planInfoAddLogFlownetJsonVO = new PlanInfoAddLogFlownetJsonVO();
        BeanUtils.copyProperties(planInfoAddLogDTO, planInfoAddLogFlownetJsonVO);
        commonFlownetVO.setBusinessFormJson(planInfoAddLogFlownetJsonVO);
        String flownetCreateUrl = flowNetUrlConfig.getFlownetCreateUrl();
        FlownetResponse response;
        //调用Flownet接口
        String result;
        try {
            result = HttpUtil.createPost(flownetCreateUrl)
                    .header("Content-Type", "application/json;charset=UTF-8")
                    .setConnectionTimeout(30 * 1000)
                    .setReadTimeout(180 * 1000)
                    .body(JSONUtil.toJsonStr(commonFlownetVO, JSONConfig.create().setStripTrailingZeros(false)))
                    .execute()
                    .body();
            log.info("sendToSign：::requestJson={},url={},result={},current-time:{}", JSONUtil.toJsonStr(commonFlownetVO,
                            JSONConfig.create().setStripTrailingZeros(false)),
                    flownetCreateUrl, result, System.currentTimeMillis());
            response = JSON.parseObject(result, FlownetResponse.class);
        } catch (Exception e) {
            log.error("sendToSign ERROR:{}", e.getMessage(), e);
            throw new CloudmesException(SdsResultCode.FAILED_TO_CALL_FLOWNET.getCode(),
                    MessageUtils.get(SdsResultCode.FAILED_TO_CALL_FLOWNET.getLocalCode()));
        }
        if (!"SUCCESS".equals(response.getFlag())) {
            throw new CloudmesException(SdsResultCode.SIGN_A_FAILURE_TO_SEND.getCode(),
                    String.format(MessageUtils.get(SdsResultCode.SIGN_A_FAILURE_TO_SEND.getLocalCode()),
                            response.getMsg()));
        }
        //保存Flownet返回信息
        FlownetResponseData responseData = response.getData();
        baseMapper.update(null, Wrappers.<SdsHazardousWastePlanInfoAddLog>lambdaUpdate()
                .eq(SdsHazardousWastePlanInfoAddLog::getId, id)
                .set(SdsHazardousWastePlanInfoAddLog::getFlownetUrl, responseData.getURL())
                .set(SdsHazardousWastePlanInfoAddLog::getFlownetFlag, response.getFlag())
                .set(SdsHazardousWastePlanInfoAddLog::getFlownetFormId, responseData.getFlownetFormID())
                .set(SdsHazardousWastePlanInfoAddLog::getFlownetMsg, response.getMsg())
                .set(SdsHazardousWastePlanInfoAddLog::getDocStatus, WastePlanDocStatusEnum.SIGN.getDictCode())
                .set(SdsHazardousWastePlanInfoAddLog::getLastEditor, WebContextUtil.getCurrentStaffCode())
                .set(SdsHazardousWastePlanInfoAddLog::getLastEditedDt, LocalDateTime.now())
        );
        HashMap<String, String> map = new HashMap<>();
        map.put("url", responseData.getURL());
        return map;
    }

    @Override
    public FlownetResponse approvalStatus(Integer id) {
        SdsHazardousWastePlanInfoAddLog sdsHazardousWastePlanInfoAddLog = baseMapper.selectById(id);
        Map<String, Object> params = new HashMap<>();
        params.put("businessRequestNO", sdsHazardousWastePlanInfoAddLog.getDocNo());
        params.put("userId", sdsHazardousWastePlanInfoAddLog.getCreator());
        String flownetStatusUrl = flowNetUrlConfig.getFlownetStatusUrl();
        FlownetResponse response;
        FlownetErrorResponse errorResponse;
        String result;
        try {
            result = HttpUtil.createGet(flownetStatusUrl)
                    .header("Content-Type", "application/json;charset=UTF-8")
                    .setConnectionTimeout(30 * 1000)
                    .setReadTimeout(180 * 1000)
                    .form(params)
                    .execute()
                    .body();
            log.info("年度计划说明调用flownet签核状态接口-approvalStatus：::requestJson={},url={},result={},current-time:{}",
                    JSON.toJSONString(params), flownetStatusUrl, result, System.currentTimeMillis());
            response = JSON.parseObject(result, FlownetResponse.class);
            errorResponse = JSON.parseObject(result, FlownetErrorResponse.class);
        } catch (Exception e) {
            log.error("年度计划说明调用flownet签核状态接口-approvalStatus ERROR:{}", e.getMessage(), e);
            throw new CloudmesException(SdsResultCode.FAILED_TO_CALL_FLOWNET.getCode(),
                    MessageUtils.get(SdsResultCode.FAILED_TO_CALL_FLOWNET.getLocalCode()));
        }
        if (ObjectUtil.isNull(response.getFlag())) {
            //错误时的解析格式
            throw new CloudmesException(SdsResultCode.FLOWNET_RETURN_AN_EXCEPTION.getCode(),
                    String.format(MessageUtils.get(SdsResultCode.FLOWNET_RETURN_AN_EXCEPTION.getLocalCode()), errorResponse.getMsg()));
        }
        if (!"SUCCESS".equals(response.getFlag())) {
            throw new CloudmesException(SdsResultCode.FLOWNET_RETURN_AN_EXCEPTION.getCode(),
                    String.format(MessageUtils.get(SdsResultCode.FLOWNET_RETURN_AN_EXCEPTION.getLocalCode()), response.getMsg()));
        }
        return response;
    }
}
