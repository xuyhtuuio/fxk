package com.maxnerva.cloudmes.models.vo.excel.basic;

import com.maxnerva.cloudmes.models.vo.excel.ExcelImportVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @ClassName SteelBucketExcelImportVO
 * @Description TODO
 * @Author Likun
 * @Date 2024/11/5
 * @Version 1.0
 * @Since JDK 1.8
 **/
@EqualsAndHashCode(callSuper = true)
@ApiModel("托盘信息excel导入VO")
@Data
public class SteelBucketExcelImportVO extends ExcelImportVO {

    @ApiModelProperty(value = "托盘类别")
    private String bucketType;
}
