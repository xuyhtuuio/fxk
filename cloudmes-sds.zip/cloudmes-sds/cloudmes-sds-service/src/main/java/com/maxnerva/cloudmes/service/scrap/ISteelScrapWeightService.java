package com.maxnerva.cloudmes.service.scrap;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.scrap.OutFactoryWeightDTO;
import com.maxnerva.cloudmes.models.dto.scrap.RubbishWeightInfoSubmitDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SteelScrapWeightInfoDTO;
import com.maxnerva.cloudmes.models.dto.scrap.SyncWmsScrapHandlePalletDTO;
import com.maxnerva.cloudmes.models.entity.basic.SdsRfidSteelBucketLink;
import com.maxnerva.cloudmes.models.entity.scrap.SdsSteelScrapWeightInfo;
import com.maxnerva.cloudmes.models.vo.scrap.*;

import java.util.List;

public interface ISteelScrapWeightService {

    SdsSteelScrapWeightInfo submitWeightInfo(SteelScrapWeightSubmitVO vo);

    SteelScrapWeightInfoDTO getCheckAcceptConfirm(SteelScrapWeightInfoQueryOneVO vo);

    void acceptConfirm(SteelScrapWeightAcceptVO vo);

    SteelScrapWeightInfoDTO getCheckUploadImage(SteelScrapWeightInfoQueryOneVO vo);

    void uploadImage(SteelScrapWeightUploadImageVO vo);

    R<RubbishWeightInfoSubmitDTO> submitRubbishWeightInfo(RubbishWeightInfoSubmitVO vo);

    OutFactoryWeightDTO outSourcedFactoryWeight(OutFactoryWeightVO vo);

    void confirmRubbishWeightInfo(RubbishWeightInfoConfirmVO vo);
//    SdsSteelScrapWeightInfo submitRubbishWeightInfo(SteelScrapWeightSubmitVO vo);

    List<SdsRfidSteelBucketLink> getRfidBucketNoLink();

    void catchSteelIssue(String issueType, String issueMessage, String currentBucketNo, String positionName);

    void rejectWeightInfo(RejectWeightInfoVO vo);

    void scrapRejectSendMail();

    void timeOutToRubbishSendMail();

    SyncWmsScrapHandlePalletDTO syncWmsScrapHandlePallet(SyncWmsScrapHandlePalletVO vo);
}
