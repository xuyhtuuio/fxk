package com.maxnerva.cloudmes.models.dto.scrap;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName WeightLockDTO
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/2/14 上午 10:22
 * @Version 1.0
 **/

@Data
public class WeightLockDTO {

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("")
    private String orgCode;

    @ApiModelProperty("报废小类")
    private String scrapDetailClass;
}

