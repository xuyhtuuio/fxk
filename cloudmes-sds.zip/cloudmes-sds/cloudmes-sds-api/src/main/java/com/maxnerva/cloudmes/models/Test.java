package com.maxnerva.cloudmes.models;

/**
 * @ClassName Test
 * @Description TODO
 * @Author Likun
 * @Date 2024/8/2
 * @Version 1.0
 * @Since JDK 1.8
 **/
public class Test {
}
