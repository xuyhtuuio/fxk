package com.maxnerva.cloudmes.feign;

public class TestFeign {
}
