package com.maxnerva.cloudmes.service.wh.impl;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.entity.pkg.WmsPkgSfcInfoEntity;
import com.maxnerva.cloudmes.entity.wh.WmsPkgInfo;
import com.maxnerva.cloudmes.entity.wh.WmsPkgInfoLog;
import com.maxnerva.cloudmes.entity.wh.WmsUnLockSnRecord;
import com.maxnerva.cloudmes.mapper.pkg.WmsPkgSfcInfoMapper;
import com.maxnerva.cloudmes.mapper.wh.WmsPkgInfoLogMapper;
import com.maxnerva.cloudmes.mapper.wh.WmsPkgInfoMapper;
import com.maxnerva.cloudmes.mapper.wh.WmsUnLockSnRecordMapper;
import com.maxnerva.cloudmes.service.wh.IWmsUnLockSnRecordService;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * mes通知解锁sn记录表 服务实现类
 * </p>
 *
 * @author likun
 * @since 2024-08-07
 */
@Service
public class WmsUnLockSnRecordServiceImpl extends ServiceImpl<WmsUnLockSnRecordMapper, WmsUnLockSnRecord>
        implements IWmsUnLockSnRecordService {

    @Resource
    private WmsPkgSfcInfoMapper wmsPkgSfcInfoMapper;

    @Resource
    private WmsPkgInfoMapper wmsPkgInfoMapper;

    @Resource
    private WmsPkgInfoLogMapper wmsPkgInfoLogMapper;

    @Override
    public void unLockSn(String orgCode) {
        List<WmsUnLockSnRecord> wmsUnLockSnRecordList = baseMapper
                .selectList(Wrappers.<WmsUnLockSnRecord>lambdaQuery()
                        .eq(WmsUnLockSnRecord::getOrgCode,orgCode)
                        .eq(WmsUnLockSnRecord::getCompletedFlag, "0"));
        for (WmsUnLockSnRecord wmsUnLockSnRecord : wmsUnLockSnRecordList) {
            String snNo = wmsUnLockSnRecord.getPkgId();
            baseMapper.update(null, Wrappers.<WmsUnLockSnRecord>lambdaUpdate()
                    .eq(WmsUnLockSnRecord::getId, wmsUnLockSnRecord.getId())
                    .set(WmsUnLockSnRecord::getCompletedFlag, '1'));
            WmsPkgSfcInfoEntity wmsPkgSfcInfoEntityDb = wmsPkgSfcInfoMapper
                    .selectOne(Wrappers.<WmsPkgSfcInfoEntity>lambdaQuery()
                            .eq(WmsPkgSfcInfoEntity::getSnNo, snNo)
                            .eq(WmsPkgSfcInfoEntity::getOrgCode, orgCode)
                            .orderByDesc(WmsPkgSfcInfoEntity::getId)
                            .last("limit 1"));
            if (ObjectUtil.isNull(wmsPkgSfcInfoEntityDb)) {
                continue;
            }
            //修改pkg_sfc_info中SN的锁定状态为解锁
            wmsPkgSfcInfoMapper.update(null, Wrappers.<WmsPkgSfcInfoEntity>lambdaUpdate()
                    .eq(WmsPkgSfcInfoEntity::getId, wmsPkgSfcInfoEntityDb.getId())
                    .set(WmsPkgSfcInfoEntity::getLockStatus, 0));
            String pkgId = wmsPkgSfcInfoEntityDb.getPkgId();
            //判断pkg_sfc_info中的pkg_id中的SN是否全部是未锁状态，若全是未锁状态，修改pkg_info中此PKG的锁定状态为0
            Long count = wmsPkgSfcInfoMapper.selectCount(Wrappers.<WmsPkgSfcInfoEntity>lambdaQuery()
                    .eq(WmsPkgSfcInfoEntity::getOrgCode, orgCode)
                    .eq(WmsPkgSfcInfoEntity::getPkgId, pkgId)
                    .eq(WmsPkgSfcInfoEntity::getLockStatus, 1));
            if (count == 0) {
                WmsPkgInfo wmsPkgInfoDb = wmsPkgInfoMapper.selectOne(Wrappers.<WmsPkgInfo>lambdaQuery()
                        .eq(WmsPkgInfo::getOrgCode, orgCode)
                        .eq(WmsPkgInfo::getPkgId, pkgId)
                        .last("limit 1"));
                if (ObjectUtil.isNotNull(wmsPkgInfoDb)) {
                    wmsPkgInfoMapper.update(null, Wrappers.<WmsPkgInfo>lambdaUpdate()
                            .eq(WmsPkgInfo::getOrgCode, orgCode)
                            .eq(WmsPkgInfo::getPkgId, pkgId)
                            .set(WmsPkgInfo::getLockStatus, "0")
                            .set(WmsPkgInfo::getLockMessage, StrUtil.EMPTY));
                    WmsPkgInfoLog wmsPkgInfoLog = new WmsPkgInfoLog();
                    BeanUtils.copyProperties(wmsPkgInfoDb,wmsPkgInfoLog);
                    wmsPkgInfoLog.setId(null);
                    wmsPkgInfoLog.setTransactionType("MES_UN_LOCK");
                    wmsPkgInfoLog.setTransactionMessage("MES解锁");
                    wmsPkgInfoLog.setCreator("sysadmin");
                    wmsPkgInfoLog.setCreatedDt(LocalDateTime.now());
                    wmsPkgInfoLogMapper.insert(wmsPkgInfoLog);
                }
            }
        }
    }
}
