package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName SectionTypeEnum
 * @Description 管理方式枚举
 **/
public enum SectionTypeEnum {

    ELECTRONIC_SEGMENT("ELECTRONIC_SEGMENT","电子段"),
    ASSEMBLY_SECTION("ASSEMBLY_SECTION","组装段");

    private final String dictCode;

    private final String dictName;

    SectionTypeEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (SectionTypeEnum sectionTypeEnum : values()) {
            if (sectionTypeEnum.getDictCode().equals(dictCode)) {
                return sectionTypeEnum.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

    public static SectionTypeEnum getByValue(String dictCode) {
        for (SectionTypeEnum sectionTypeEnum : values()) {
            if (sectionTypeEnum.getDictCode().equals(dictCode)) {
                return sectionTypeEnum;
            }
        }
        return null;
    }
}
