package com.maxnerva.cloudmes.service.wo;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.NumberUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.config.Constants;
import com.maxnerva.cloudmes.entity.wo.WmsSapTransactionLog;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderDetail;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderHeader;
import com.maxnerva.cloudmes.mapper.wo.WmsWorkOrderDetailMapper;
import com.maxnerva.cloudmes.mapper.wo.WmsWorkOrderHeaderMapper;
import com.maxnerva.cloudmes.service.sap.material.MaterialRfcService;
import com.maxnerva.cloudmes.service.sap.wh.WhRfcService;
import com.maxnerva.cloudmes.service.sap.wh.model.TransferDto;
import com.maxnerva.cloudmes.service.sap.wo.WoRfcService;
import com.maxnerva.cloudmes.service.sap.wo.model.WorkOrderPostingDto;
import com.maxnerva.cloudmes.service.wo.model.PostingSap101ReturnDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

/**
 * @Description: 工单过账服务
 * @Author: Chao Zhang
 * @Date: 2022/09/12 09:18
 * @Version: 1.0
 */
@Service
@Slf4j
public class WoPostingService {

    @Autowired
    WmsWorkOrderDetailMapper workOrderDetailMapper;

    @Autowired
    MaterialRfcService materialRfcService;

    @Autowired
    WhRfcService whRfcService;

    @Autowired
    WoRfcService woRfcService;

    @Autowired
    WmsWorkOrderHeaderMapper workOrderHeaderMapper;

    /**
     * 工单detail备料量过账SAP 311
     */
    public void postingWoDetail311(String orgCode, String sapClientCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }
        //需过账311的wo detail list
        List<WmsWorkOrderDetail> woDetailList = workOrderDetailMapper.selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery().eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                //.eq(WmsWorkOrderDetail::getId, 16353)
                .apply(" stock_qty > post_to311_qty and work_order_no not like 'MERGE%'"));

        if (CollUtil.isEmpty(woDetailList)) {
            return;
        }

        woDetailList.forEach(w -> {
            if ("N".equalsIgnoreCase(Constants.continueJob)) {
                return;
            }
            BigDecimal postingQty = NumberUtil.sub(w.getStockQty(), w.getPostTo311Qty());
            try {

                TransferDto dto = setTransfer311Dto(w, postingQty, postDate);

                String s1 = materialRfcService.doGetMaterialValueType(sapClientCode, w.getPlantCode(), w.getPartNo(), w.getFromWarehouseCode());

                if (StringUtils.isNotBlank(s1)) {
                    dto.setValueType(s1);
                } else {
                    log.error("wo {}  value type not exist", JSONUtil.toJsonStr(w));
                    return;
                }

                String s = whRfcService.doTransfer(sapClientCode, dto);
                // update wo detail post 311 qty
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPostTo311Qty(w.getStockQty());
                updateDetail.setPostTo311ReturnMsg(s);
                updateDetail.setPostTo311LastDt(LocalDateTime.now());
                updateDetail.updateById();

                //write post log
                PostingSap101ReturnDto posrtingResult = new PostingSap101ReturnDto();
                posrtingResult.setDocNumber(s);

                writePostingLog(w, postingQty, posrtingResult, "311");

            } catch (Exception e) {
                log.error("wo posting 311 error  wo {} ,errorMsg:{}", JSONUtil.toJsonStr(w), e.getMessage());
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPostTo311ReturnMsg("last post311 Qty:"+postingQty+",sap result:"+e.getMessage());
                updateDetail.setPostTo311LastDt(LocalDateTime.now());
                updateDetail.updateById();
            }
        });


    }

    /**
     * 工单detail备料量过账SAP 261
     * SMT端工单 mrp_controller  in  ('J03')
     */
    public void postingWoDetail261(String orgCode, String sapClientCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }

        //需过账261的wo detail 群组 list
        List<WmsWorkOrderDetail> woNeedToPosting261List = workOrderDetailMapper.woNeedToPosting261(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
                .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
//                .eq(WmsWorkOrderDetail::getWorkOrderNo, "000400001613")
                .eq(WmsWorkOrderDetail::getMrpController, "J03")
        );

        if (CollUtil.isEmpty(woNeedToPosting261List)) {
            return;
        }

        List<String> workOrderNoList = woNeedToPosting261List.parallelStream()
                .map(WmsWorkOrderDetail::getWorkOrderNo)
                .distinct().collect(Collectors.toList());

        List<WmsWorkOrderHeader> ckdWoList =
                workOrderHeaderMapper.selectList(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                        .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                        .in(WmsWorkOrderHeader::getWorkOrderNo, workOrderNoList)
                        .in(WmsWorkOrderHeader::getWorkOrderType, Arrays.asList("CKD","MERGE")));

        woNeedToPosting261List.forEach(w -> {
            if ("N".equalsIgnoreCase(Constants.continueJob)) {
                return;
            }
            //过滤CKD工单
            if (CollUtil.isNotEmpty(ckdWoList)) {
                long count = ckdWoList.stream().filter(a -> a.getWorkOrderNo().equalsIgnoreCase(w.getWorkOrderNo())).count();
                if (count > 0) {
                    return;
                }
            }
            //可以过账 261 总量
            AtomicReference<BigDecimal> posting261TotalQty = new AtomicReference<>(NumberUtil.sub(w.getRequiredQuantity(), w.getPostTo261Qty()));

            //需要过账261群组中的物料
            List<WmsWorkOrderDetail> woItemDetailList =
                    workOrderDetailMapper.selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery().eq(WmsWorkOrderDetail::getWorkOrderNo, w.getWorkOrderNo()).eq(WmsWorkOrderDetail::getWorkOrderItem,
                            w.getWorkOrderItem()));

            woItemDetailList.forEach(s -> {

                //当前物料过账量
                BigDecimal post261Qty = NumberUtil.sub(s.getConsumeQty(), s.getPostTo261Qty());
                try {
                    if (post261Qty.compareTo(BigDecimal.ZERO) <= 0) {
                        return;
                    }

                    if (post261Qty.compareTo(posting261TotalQty.get()) <= 0) {
                        //小于过账总量
                        //return;

                    } else {
                        //大于过账总量
                        post261Qty = posting261TotalQty.get();

                    }

                    WorkOrderPostingDto input = setWorkOrderPosting261Dto(s, post261Qty, postDate);

                    if (StringUtils.isBlank(s.getValueType())) {
                        String valueTypeValue = materialRfcService.doGetMaterialValueType(sapClientCode, s.getPlantCode(), s.getPartNo(), s.getFromWarehouseCode());
                        input.setValueType(valueTypeValue);
                    } else {
                        input.setValueType(s.getValueType());
                    }


                    PostingSap101ReturnDto postingSap101ReturnDto = woRfcService.doWorkOrderPosting(sapClientCode, input);

                    posting261TotalQty.set(NumberUtil.sub(posting261TotalQty.get(), post261Qty));

                    log.info("wo posting 261：wo {} ,qty :{} , result:{}", JSONUtil.toJsonStr(s), post261Qty, postingSap101ReturnDto);

                    // update wo detail post 261 qty
                    WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                    updateDetail.setId(s.getId());
                    updateDetail.setPostTo261Qty(NumberUtil.add(s.getPostTo261Qty(), post261Qty));
                    updateDetail.setValueType(input.getValueType());
                    updateDetail.setPostTo261ReturnMsg(postingSap101ReturnDto.getDocNumber());
                    updateDetail.setPostTo261LastDt(LocalDateTime.now());
                    updateDetail.updateById();

                    //write post log
                    writePostingLog(s, post261Qty, postingSap101ReturnDto, "261");

                } catch (Exception e) {
                    log.info("wo posting 261 error：wo {} ,result:{}", JSONUtil.toJsonStr(s), e.getMessage());
                    WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                    updateDetail.setId(s.getId());
                    updateDetail.setPostTo261ReturnMsg("last post261 Qty:" + post261Qty + ",sap result:" + e.getMessage());
                    updateDetail.setPostTo261LastDt(LocalDateTime.now());
                    updateDetail.updateById();
                }
            });
        });
    }

    /**
     * 工单成品入库 101
     * 工单 process_type == BOARD 为滚工单入库，由SAP决定入库工单并返回
     */
    public void postingWoHeader101(String sapClientCode, String orgCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }

        //需过账101 的wo header list
        List<WmsWorkOrderHeader> needPosting101List = workOrderHeaderMapper.selectList(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                .apply(" inbound_qty > post_to101_qty"));

        if (CollUtil.isEmpty(needPosting101List)) {
            return;
        }

        needPosting101List.forEach(w -> {
            if ("N".equalsIgnoreCase(Constants.continueJob)) {
                return;
            }
            //工单过账量
            BigDecimal posting101Qty = NumberUtil.sub(w.getInboundQty(), w.getPostTo101Qty());
            try {

                //准备过账DTO
                WorkOrderPostingDto dto = setWorkOrderPosting101Dto(w, posting101Qty, postDate);

                if (StringUtils.isBlank(w.getValueType())) {
                    String valueTypeValue = materialRfcService.doGetMaterialValueType(sapClientCode, w.getPlantCode(), w.getPartNo(), w.getStorageLocation());
                    if (StrUtil.isNotEmpty(valueTypeValue)) {
                        dto.setValueType(valueTypeValue);
                        WmsWorkOrderHeader updateHeader = new WmsWorkOrderHeader();
                        updateHeader.setId(w.getId());
                        updateHeader.setValueType(valueTypeValue);
                        updateHeader.updateById();
                    } else {
                        WmsWorkOrderHeader updateHeader = new WmsWorkOrderHeader();
                        updateHeader.setId(w.getId());
                        updateHeader.setPostTo101Msg("value type not exist");
                        updateHeader.updateById();
                        return;
                    }
                } else {
                    dto.setValueType(w.getValueType());
                }
                //SAP 过账
                PostingSap101ReturnDto postingSap101ReturnDto = woRfcService.doWorkOrderPosting(sapClientCode, dto);
                log.info("post 101 result {}", JSONUtil.toJsonStr(postingSap101ReturnDto));

                //修改工单入库数量
                WmsWorkOrderHeader updateHeader = new WmsWorkOrderHeader();
                updateHeader.setId(w.getId());
                updateHeader.setPostTo101Qty(w.getInboundQty());
                updateHeader.setValueType(dto.getValueType());
                String result = String.format("last post Qty: %s ,sap result:[%s] [%s]", posting101Qty.toString(), postingSap101ReturnDto.getDocNumber(), postingSap101ReturnDto.getSapWo());
                updateHeader.setPostTo101Msg(result);
                updateHeader.updateById();

                //write posting log
                writePosting101Log(w, posting101Qty, postingSap101ReturnDto, result);

            } catch (Exception e) {
                //update SAP error result
                WmsWorkOrderHeader updateHeader = new WmsWorkOrderHeader();
                updateHeader.setId(w.getId());
                updateHeader.setPostTo101Msg("last post Qty:" + posting101Qty + ",sap result:" + e.getMessage());
                updateHeader.updateById();
            }
        });
    }

    private void writePosting101Log(WmsWorkOrderHeader w, BigDecimal posting101Qty, PostingSap101ReturnDto s, String result) {
        //write post log
        WmsSapTransactionLog log = new WmsSapTransactionLog();
        log.setOrgCode(w.getOrgCode());
        log.setPlantCode(w.getPlantCode());
        log.setPartNo(w.getPartNo());
        log.setFromWarehouseCode(w.getStorageLocation());
        log.setToWarehouseCode(w.getStorageLocation());
        log.setWorkOrderNo(w.getWorkOrderNo());
        log.setPostSapReturnMsg(s.getDocNumber());
        // log.setWmsWorkOrderDetailId(w.getId());
        log.setTransactionQty(posting101Qty);
        log.setUomCode("EA");
        log.setSapUomCode("EA");
        log.setPostType("101");
        log.setSapResult(s.getSapWo());
        log.setPostSapReturnDt(LocalDateTime.now());
        log.insert();

    }

    private WorkOrderPostingDto setWorkOrderPosting101Dto(WmsWorkOrderHeader w, BigDecimal posting101Qty, String postDate) {
        WorkOrderPostingDto dto = new WorkOrderPostingDto();
        dto.setPostDate(postDate);
        dto.setDocDate(postDate);

        dto.setUserName("WMS");
        dto.setHeaderText(w.getWorkOrderNo());
        dto.setMoveType("101");
        dto.setGmCode("01");
        dto.setPlant(w.getPlantCode());
        if (!"BOARD".equalsIgnoreCase(w.getProcessType())) {
            dto.setWorkOrderNo(w.getWorkOrderNo());
        }
        dto.setPartNo(w.getPartNo());
        if (StringUtils.isNotBlank(w.getPartVersion())) {
            dto.setPartVersion(w.getPartVersion());
        }
        dto.setQty(posting101Qty);
        dto.setUnit("EA");
        dto.setFromWarehouseName(w.getStorageLocation());
        return dto;
    }

    private WorkOrderPostingDto setWorkOrderPosting101Dto(WmsWorkOrderHeader w, String postDate) {
        //过账 101 总量
        BigDecimal posting101Qty = NumberUtil.sub(w.getInboundQty(), w.getPostTo101Qty());

        WorkOrderPostingDto dto = setWorkOrderPosting101Dto(w, posting101Qty, postDate);
        return dto;
    }


    private WorkOrderPostingDto setWorkOrderPosting261Dto(WmsWorkOrderDetail s, BigDecimal post261Qty, String postDate) {
        WorkOrderPostingDto input = new WorkOrderPostingDto();
        input.setPostDate(postDate);
        input.setDocDate(postDate);
        input.setUserName("WMS");
        input.setHeaderText("");
        input.setPlant(s.getPlantCode());
        input.setPartNo(s.getPartNo());
        input.setLongPartNo(s.getPartNo());
        input.setPartVersion(s.getPartVersion());
        input.setFromWarehouseName(s.getToWarehouseCode());
        input.setMoveType("261");
        input.setGmCode("03");
        input.setUnit("EA");
        input.setQty(post261Qty);
        input.setValueType(s.getValueType());

        input.setWorkOrderNo(s.getWorkOrderNo());
//        input.setWorkOrderItem(s.getItemNumber());
        input.setReservationNo(s.getReservationNumber());
        input.setReservationItem(s.getReservationItem());
        return input;
    }

    private void writePostingLog(WmsWorkOrderDetail w, BigDecimal postingQty, PostingSap101ReturnDto s, String postingType) {
        WmsSapTransactionLog log = new WmsSapTransactionLog();
        log.setOrgCode(w.getOrgCode());
        log.setPlantCode(w.getPlantCode());
        log.setPartNo(w.getPartNo());
        log.setFromWarehouseCode(w.getFromWarehouseCode());
        log.setToWarehouseCode(w.getToWarehouseCode());
        log.setWorkOrderNo(w.getWorkOrderNo());
        log.setWmsWorkOrderDetailId(w.getId());
        log.setTransactionQty(postingQty);
        log.setUomCode(w.getUomCode());
        log.setSapUomCode(w.getSapUomCode());
        log.setPostType(postingType);
        log.setPostSapReturnMsg(s.getDocNumber());
        log.setFromDocNo(w.getWorkOrderNo());
        log.setPostSapReturnFlag(1);
        log.setTransactionSapQty(postingQty);
        log.setTransactionDate(LocalDateTime.now());
        log.setCreator("WMS311Job");
        log.setCreatedDt(LocalDateTime.now());
        log.setValueType(w.getValueType());
        log.setSapResult(s.getSapWo());
        log.insert();
    }


    private TransferDto setTransfer311Dto(WmsWorkOrderDetail w, BigDecimal postingQty, String postDate) {
        TransferDto dto = new TransferDto();
        dto.setTransactionDate(postDate);
        dto.setDocDate(postDate);
        dto.setMoveType("311");
        dto.setGmCode("04");
        dto.setQty(postingQty.toString());
        dto.setUnit(w.getSapUomCode());
        //301 夸工厂转仓   04
        //311 同工厂转仓   04
        //309 料调        04
        dto.setFromPlant(w.getPlantCode());
        dto.setFromWarehouseName(w.getFromWarehouseCode());
        dto.setFromPartNo(w.getPartNo());
        if (StringUtils.isNotBlank(w.getPartVersion())) {
            dto.setFromPartVersion(w.getPartVersion());
            dto.setToPartVersion(w.getPartVersion());
        }
        dto.setToPlant(w.getPlantCode());
        dto.setToWarehouseName(w.getToWarehouseCode());
        dto.setToPartNo(w.getPartNo());
        return dto;
    }

    /**
     * 工单detail备料量过账SAP 261
     * 1.组装端工单 mrp_controller  in  ('J00','J01','J02')
     * 2. PartRelationship = M
     */
    public void postingWoDetail261InAssy(String orgCode, String sapClientCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }

        //需过账261的wo detail 群组 list
        List<WmsWorkOrderDetail> woNeedToPosting261List = workOrderDetailMapper.selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
                        .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                        .eq(WmsWorkOrderDetail::getPartRelationship, 'M')
//                        .eq(WmsWorkOrderDetail::getId, 94316)
                        .last(" and mrp_controller  in  ('J00','J01','J02') and stock_qty  > post_to261_qty")
                //.last(" and mrp_controller  in  ('J00','J01','J02') and stock_qty  > post_to261_qty and required_quantity  > post_to261_qty")
        );

        if (CollUtil.isEmpty(woNeedToPosting261List)) {
            return;
        }

        List<String> workOrderNoList = woNeedToPosting261List.parallelStream()
                .map(WmsWorkOrderDetail::getWorkOrderNo)
                .distinct().collect(Collectors.toList());

        List<WmsWorkOrderHeader> ckdWoList =
                workOrderHeaderMapper.selectList(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                        .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                        .in(WmsWorkOrderHeader::getWorkOrderNo, workOrderNoList)
                        .in(WmsWorkOrderHeader::getWorkOrderType, Arrays.asList("CKD","MERGE")));

        woNeedToPosting261List.forEach(w -> {

            //过滤CKD工单
            if (CollUtil.isNotEmpty(ckdWoList)) {
                long count = ckdWoList.stream().filter(a -> a.getWorkOrderNo().equalsIgnoreCase(w.getWorkOrderNo())).count();
                if (count > 0) {
                    return;
                }
            }

            //可以过账 261 总量
            //AtomicReference<BigDecimal> posting261TotalQty = new AtomicReference<>(NumberUtil.sub(w.getRequiredQuantity(), w.getPostTo261Qty()));

            //需要过账261群组中的物料
            //List<WmsWorkOrderDetail> woItemDetailList =
            //        workOrderDetailMapper.selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery().eq(WmsWorkOrderDetail::getWorkOrderNo, w.getWorkOrderNo()).eq(WmsWorkOrderDetail::getWorkOrderItem,
            //                w.getWorkOrderItem()));

            //当前物料过账量
            BigDecimal post261Qty = BigDecimal.ZERO;
            post261Qty = NumberUtil.sub(w.getStockQty(), w.getPostTo261Qty());

            try {
                if (post261Qty.compareTo(BigDecimal.ZERO) <= 0) {
                    return;
                }

                WorkOrderPostingDto input = setWorkOrderPosting261Dto(w, post261Qty, postDate);

                if (StringUtils.isBlank(w.getValueType())) {
                    String valueTypeValue = materialRfcService.doGetMaterialValueType(sapClientCode, w.getPlantCode(), w.getPartNo(), w.getFromWarehouseCode());
                    input.setValueType(valueTypeValue);
                } else {
                    input.setValueType(w.getValueType());
                }


                PostingSap101ReturnDto postingSap101ReturnDto = woRfcService.doWorkOrderPosting(sapClientCode, input);

                //posting261TotalQty.set(NumberUtil.sub(posting261TotalQty.get(), post261Qty));

                // update wo detail post 261 qty
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPostTo261Qty(NumberUtil.add(w.getPostTo261Qty(), post261Qty));
                updateDetail.setValueType(input.getValueType());
                updateDetail.setPostTo261ReturnMsg(postingSap101ReturnDto.getDocNumber());
                updateDetail.setPostTo261LastDt(LocalDateTime.now());
                updateDetail.updateById();

                //write post log
                writePostingLog(w, post261Qty, postingSap101ReturnDto, "261_Assy");

            } catch (Exception e) {
                log.info("wo posting 261 error：wo {} ,result:{}", JSONUtil.toJsonStr(w), e.getMessage());
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPostTo261ReturnMsg("last post261 Qty:" + post261Qty + ",sap result:" + e.getMessage());
                updateDetail.setPostTo261LastDt(LocalDateTime.now());
                updateDetail.updateById();
            }
        });
    }

    /**
     * 工单detail退料量過賬SAP 311
     */
    public void postingWoReturn311(String orgCode, String sapClientCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }
        //需过账311的wo detail list
        List<WmsWorkOrderDetail> woDetailList = workOrderDetailMapper.selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery().eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                //.eq(WmsWorkOrderDetail::getId, 57016)
                .apply(" return_qty  > post_return_to311_qty and work_order_no not like 'MERGE%'"));

        if (CollUtil.isEmpty(woDetailList)) {
            return;
        }

        woDetailList.forEach(w -> {
            if ("N".equalsIgnoreCase(Constants.continueJob)) {
                return;
            }
            BigDecimal postingQty = NumberUtil.sub(w.getReturnQty(), w.getPostReturnTo311Qty());
            try {
                if(postingQty.compareTo(BigDecimal.ZERO) <=0){
                    return;
                }
                //退料交換倉碼
                String from = w.getFromWarehouseCode();
                String to = w.getToWarehouseCode();
                w.setFromWarehouseCode(to);
                w.setToWarehouseCode(from);

                TransferDto dto = setTransfer311Dto(w, postingQty, postDate);

                String s1 = materialRfcService.doGetMaterialValueType(sapClientCode, w.getPlantCode(), w.getPartNo(), w.getFromWarehouseCode());

                if (StringUtils.isNotBlank(s1)) {
                    dto.setValueType(s1);
                } else {
                    WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                    updateDetail.setId(w.getId());
                    updateDetail.setPostReturn311Msg("value type not exist " + LocalDateTime.now());
                    updateDetail.updateById();
                    return;
                }

                String s = whRfcService.doTransfer(sapClientCode, dto);
                // update wo detail post 311 qty
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPostReturnTo311Qty(w.getReturnQty());
                updateDetail.setPostReturn311Msg(s + " - qty:" + postingQty + " -- " + LocalDateTime.now());
                updateDetail.updateById();

                //write post log
                PostingSap101ReturnDto posrtingResult = new PostingSap101ReturnDto();
                posrtingResult.setDocNumber(s);

                writePostingLog(w, postingQty, posrtingResult, "return_311");

            } catch (Exception e) {
                log.error("wo posting 311 error  wo {} ,errorMsg:{}", JSONUtil.toJsonStr(w), e.getMessage());
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPostReturn311Msg("last post311 Qty:" + postingQty + ",sap result:" + e.getMessage());
                updateDetail.setPostTo311LastDt(LocalDateTime.now());
                updateDetail.updateById();
            }
        });


    }

    /**
     * 工单detail备料量过账SAP 261
     * PTH
     */
    public void postingWoDetail261InPth(String orgCode, String sapClientCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }

        //需过账261的wo detail 群组 list
        List<WmsWorkOrderDetail> woNeedToPosting261List = workOrderDetailMapper.woNeedToPosting261PTH(orgCode);


        if (CollUtil.isEmpty(woNeedToPosting261List)) {
            return;
        }

        List<String> workOrderNoList = woNeedToPosting261List.parallelStream()
                .map(WmsWorkOrderDetail::getWorkOrderNo)
                .distinct().collect(Collectors.toList());

        List<WmsWorkOrderHeader> ckdWoList =
                workOrderHeaderMapper.selectList(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                        .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                        .in(WmsWorkOrderHeader::getWorkOrderNo, workOrderNoList)
                        .in(WmsWorkOrderHeader::getWorkOrderType, Arrays.asList("CKD","MERGE")));

        woNeedToPosting261List.forEach(w -> {

            if ("N".equalsIgnoreCase(Constants.continueJob)) {
                return;
            }
            //过滤CKD工单
            if (CollUtil.isNotEmpty(ckdWoList)) {
                long count = ckdWoList.stream().filter(a -> a.getWorkOrderNo().equalsIgnoreCase(w.getWorkOrderNo())).count();
                if (count > 0) {
                    return;
                }
            }

            //当前物料过账量
            BigDecimal post261Qty = BigDecimal.ZERO;

            post261Qty = NumberUtil.sub(w.getStockQty(), w.getPostTo261Qty());


            try {
                if (post261Qty.compareTo(BigDecimal.ZERO) <= 0) {
                    return;
                }

                WorkOrderPostingDto input = setWorkOrderPosting261Dto(w, post261Qty, postDate);

                if (StringUtils.isBlank(w.getValueType())) {
                    String valueTypeValue = materialRfcService.doGetMaterialValueType(sapClientCode, w.getPlantCode(), w.getPartNo(), w.getFromWarehouseCode());
                    input.setValueType(valueTypeValue);
                } else {
                    input.setValueType(w.getValueType());
                }


                PostingSap101ReturnDto postingSap101ReturnDto = woRfcService.doWorkOrderPosting(sapClientCode, input);

                //posting261TotalQty.set(NumberUtil.sub(posting261TotalQty.get(), post261Qty));

                // update wo detail post 261 qty
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPostTo261Qty(NumberUtil.add(w.getPostTo261Qty(), post261Qty));
                updateDetail.setValueType(input.getValueType());
                updateDetail.setPostTo261ReturnMsg(postingSap101ReturnDto.getDocNumber());
                updateDetail.setPostTo261LastDt(LocalDateTime.now());
                updateDetail.updateById();

                //write post log
                writePostingLog(w, post261Qty, postingSap101ReturnDto, "261_pth");

            } catch (Exception e) {
                log.info("wo posting 261 error：wo {} ,result:{}", JSONUtil.toJsonStr(w), e.getMessage());
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPostTo261ReturnMsg("last post261 Qty:" + post261Qty + ",sap result:" + e.getMessage());
                updateDetail.setPostTo261LastDt(LocalDateTime.now());
                updateDetail.updateById();
            }
        });

    }
}
