package com.maxnerva.cloudmes.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

@RefreshScope
@Component
@Data
public class AgileTcConfig {
    @Value("${agile-tc.url:}")
    private String agileTcUrl;

    @Value("${agile-tc.minDay:}")
    private Integer minDay;

    @Value("${agile-tc.expirationDay:}")
    private Integer expirationDay;

    @Value("${agile-tc.delayDay:}")
    private Integer delayDay;
}
