package com.maxnerva.cloudmes.service.datahub.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2024-01-19
 */
@Data
@ApiModel("WmsWorkOrderPrepareCkdShipDetailDTO")
public class WmsWorkOrderPrepareCkdShipDetailDTO {


    private Integer id;

    private String orgCode;

    private String plantCode;

    @ApiModelProperty("料号")
    private String partNo;

    @ApiModelProperty("打包序列号")
    private String serialNo;

    @ApiModelProperty("数量")
    private BigDecimal qty;

    @ApiModelProperty("工单")
    private String workOrderNo;

    @ApiModelProperty("厂商料号")
    private String supplierPartNo;

    @ApiModelProperty("厂商名")
    private String mfgName;

    @ApiModelProperty("项次")
    private String item;

    @ApiModelProperty("仓码")
    private String sapWarehouseCode;

    @ApiModelProperty("收货单号")
    private String receiveDocNo;

    @ApiModelProperty("原产国")
    private String placeOfOrigin1;

}
