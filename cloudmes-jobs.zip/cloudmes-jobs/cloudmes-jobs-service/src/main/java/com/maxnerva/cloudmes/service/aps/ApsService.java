package com.maxnerva.cloudmes.service.aps;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpStatus;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.entity.WmsSapPlant;
import com.maxnerva.cloudmes.entity.aps.WmsWorkOrderApsEntity;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderDetail;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderHeader;
import com.maxnerva.cloudmes.mapper.WmsSapPlantMapper;
import com.maxnerva.cloudmes.mapper.aps.NewWmsWorkOrderApsMapper;
import com.maxnerva.cloudmes.mapper.wo.WmsWorkOrderHeaderMapper;
import com.maxnerva.cloudmes.service.aps.model.ApsContentDto;
import com.maxnerva.cloudmes.service.aps.model.ApsRequestDto;
import com.maxnerva.cloudmes.service.aps.model.ApsRequestVO;
import com.maxnerva.cloudmes.service.aps.model.ApsResponseDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/11/09 10:32
 * @Version: 1.0
 */
@RefreshScope
@Service
@Slf4j
public class ApsService {

    @Resource
    NewWmsWorkOrderApsMapper newWmsWorkOrderApsMapper;
    @Resource
    WmsWorkOrderHeaderMapper wmsWorkOrderHeaderMapper;
    @Resource
    WmsSapPlantMapper wmsSapPlantMapper;

    @Value("${aps.service.url:}")
    private String apsServiceUrl;

    @Value("${connection.timeout:30000}")
    private int timeout;

    /**
     * 取APS 工单排配信息
     *
     * @param apsRequestVO
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public List<ApsContentDto> doGetApsInfolist(ApsRequestVO apsRequestVO) {

        //根据org_code去wms_sap_plant中查询对应的工厂
        List<WmsSapPlant> records = wmsSapPlantMapper.selectList(Wrappers.<WmsSapPlant>lambdaQuery()
                .eq(WmsSapPlant::getOrgCode, apsRequestVO.getOrgCode())
                .eq(WmsSapPlant::getIsEnable, true));

        List<ApsContentDto> content = new ArrayList<>();

        //如果工厂不为空
        if (CollectionUtil.isNotEmpty(records)) {
            for (WmsSapPlant wmsSapPlant : records) {
                //设置调用APS接口条件参数
                ApsRequestDto dto = new ApsRequestDto();
                dto.setPlant(wmsSapPlant.getFactoryCode());
                dto.setBeginDate(apsRequestVO.getBeginDate());
                dto.setEndDate(apsRequestVO.getEndDate());

                String url = apsServiceUrl + "/v1.0/production/aps_api/produced_info";

                HttpResponse httpResponse = HttpRequest.post(url)
                        .header("Content-Type", "application/json;charset=UTF-8")
                        .setConnectionTimeout(timeout)
                        .body(JSONUtil.toJsonStr(dto))
                        .execute();

                log.info("APS_result request : {}, response: {}", dto, httpResponse.body());

                Assert.isTrue(httpResponse.getStatus() == HttpStatus.HTTP_OK, "APS Service ACCESS ERROR");

                String body = httpResponse.body();

                ApsResponseDto apsResponseDto = JSONUtil.toBean(body, ApsResponseDto.class);

                Assert.isTrue(null != apsResponseDto && "success".equalsIgnoreCase(apsResponseDto.getMessage()), apsResponseDto.getMessage());

                content = apsResponseDto.getContent();

                //将数据插入wms_work_order_aps表前，需要先删除wms_work_order_aps表beginData所有大于等于今天的数据
                LambdaQueryWrapper<WmsWorkOrderApsEntity> lambdaQueryWrapper = new LambdaQueryWrapper();
                //获取当前时间
                Date nowDate = new Date();
                SimpleDateFormat sdfTime = new SimpleDateFormat("yyyy-MM-dd HH:ss");
                lambdaQueryWrapper.ge(WmsWorkOrderApsEntity::getApsDate, nowDate);
                lambdaQueryWrapper.eq(WmsWorkOrderApsEntity::getPlantCode, wmsSapPlant.getFactoryCode());
                newWmsWorkOrderApsMapper.delete(lambdaQueryWrapper);

                //将数据删除后，将结果插入到wms_work_order_aps表中
                for (ApsContentDto apsContentDto : content) {
                    WmsWorkOrderApsEntity wmsWorkOrderApsEntity = new WmsWorkOrderApsEntity();
                    BeanUtils.copyProperties(apsContentDto, wmsWorkOrderApsEntity);
                    LocalDate apsDate = LocalDate.parse(apsContentDto.getAPSDate(), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                    LocalDateTime beginTime = LocalDateTime.parse(apsContentDto.getBeginTime(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
                    LocalDateTime endTime = LocalDateTime.parse(apsContentDto.getEndTime(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));

                    wmsWorkOrderApsEntity.setApsNumber(apsContentDto.getItemID());
                    wmsWorkOrderApsEntity.setOrgCode(apsRequestVO.getOrgCode());
                    wmsWorkOrderApsEntity.setApsDate(apsDate);
                    wmsWorkOrderApsEntity.setBeginTime(beginTime);
                    wmsWorkOrderApsEntity.setEndTime(endTime);
                    wmsWorkOrderApsEntity.setPlantCode(apsContentDto.getPlant());
                    wmsWorkOrderApsEntity.setLineNo(apsContentDto.getLine());
                    wmsWorkOrderApsEntity.setPartNo(apsContentDto.getHHPN());
                    wmsWorkOrderApsEntity.setCardsPerPanel(new BigDecimal(apsContentDto.getCardsPerPanel()));
                    wmsWorkOrderApsEntity.setWorkOrderNo(apsContentDto.getWO());
                    wmsWorkOrderApsEntity.setWorkOrderQty(new BigDecimal(apsContentDto.getWOQty()));
                    wmsWorkOrderApsEntity.setApsQty(new BigDecimal(apsContentDto.getAPSQty()));
                    wmsWorkOrderApsEntity.setCreator("SystemAdmin");
                    wmsWorkOrderApsEntity.setCreatedDt(LocalDateTime.now());
                    //插入数据
                    newWmsWorkOrderApsMapper.insert(wmsWorkOrderApsEntity);
                }

                //从APS获取的数据，根据工单号去重
                List<String> workOrderNoList = content.stream().map(ApsContentDto::getWO)
                        .distinct().collect(Collectors.toList());
                String nowTime = sdfTime.format(nowDate);

                //循环工单号去重后的集合
                for (String workOrderNo : workOrderNoList) {
                    ApsContentDto apsContentDto = content.stream()
                            .filter(apsContent -> workOrderNo.equals(apsContent.getWO())
                                    //0823 去掉开始时间大于当前时间条件，取最小开始时间的一笔
//                                    && apsContent.getBeginTime().compareTo(nowTime) >= 0
                            )
                            .sorted(Comparator.comparing(ApsContentDto::getBeginTime))
                            .findFirst().orElse(null);

                    if (ObjectUtil.isNotNull(apsContentDto)) {
                        //根据工单查询，head表中是否存在数据
                        Integer headerId = wmsWorkOrderHeaderMapper.getWoHeaderId(apsContentDto.getPlant(), apsContentDto.getWO());
                        if (headerId != null) {
                            LocalDate apsDate = LocalDate.parse(apsContentDto.getAPSDate(), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                            LocalDateTime beginTime = LocalDateTime.parse(apsContentDto.getBeginTime(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
                            LocalDateTime endTime = LocalDateTime.parse(apsContentDto.getEndTime(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
                            //修改head表中字段值
                            wmsWorkOrderHeaderMapper.update(null, Wrappers.<WmsWorkOrderHeader>lambdaUpdate()
                                    .eq(WmsWorkOrderHeader::getId, headerId)
                                    .set(WmsWorkOrderHeader::getSyncApsLastDatetime, LocalDateTime.now())
                                    .set(WmsWorkOrderHeader::getApsWoScheduleDatetime, apsDate)
                                    .set(WmsWorkOrderHeader::getApsWoBeginDatetime, beginTime)
                                    .set(WmsWorkOrderHeader::getApsWoEndDatetime, endTime)
                                    .set(WmsWorkOrderHeader::getApsWoPriority, apsContentDto.getPriority()));
                        }
                    }
                }
            }
        }
        return content;
    }

}
