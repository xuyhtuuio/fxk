package com.maxnerva.cloudmes.controller;

import com.maxnerva.cloudmes.service.wh.IWmsPkgInfoService;
import com.maxnerva.cloudmes.service.wo.WorkOrderService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author hgx
 * @Description 不区分BU执行数据集成
 * @Date 2023/6/1
 */
@Api(tags = "数据集成调用接口")
@Slf4j
@RestController
@RequestMapping("/allDataIntegration")
public class AllDataIntegrationController {

    @Autowired
    private IWmsPkgInfoService wmsPkgInfoService;

    @Autowired
    private WorkOrderService workOrderService;

    /**
     * 过期锁料
     * 每天23:50执行一次
     */
    @ApiOperation("过期锁料")
    @GetMapping("/expireLockMaterial")
    public void expireLockMaterial() {
        log.info("expireLockMaterial start :" + System.currentTimeMillis());
        int i = wmsPkgInfoService.expireLockMaterial();
        log.info("expireLockMaterial update count：" + i);
        log.info("expireLockMaterial end :" + System.currentTimeMillis());
    }

    @ApiOperation("工单的锁料时间超过二十四小时解锁pkg")
    @GetMapping("/unLockMaterialAuto")
    public void unLockMaterialAuto() {
        log.info("unLockMaterialAuto start :" + System.currentTimeMillis());
        wmsPkgInfoService.unLockMaterialAuto();
        log.info("unLockMaterialAuto end :" + System.currentTimeMillis());
    }


    @ApiOperation("手动同步SFC 上料表和备料方向")
    @GetMapping("/syncBomFeeder")
    public void syncBomFeeder(@RequestParam(value = "orgCode") String orgCode,
                                     @RequestParam(value = "workOrderNo",required = false) String workOrderNo) {
        log.info("syncBomFeeder start :" + System.currentTimeMillis());
        workOrderService.syncBomFeederFromSfc(orgCode, workOrderNo);
        log.info("syncBomFeeder end :" + System.currentTimeMillis());
    }
}
