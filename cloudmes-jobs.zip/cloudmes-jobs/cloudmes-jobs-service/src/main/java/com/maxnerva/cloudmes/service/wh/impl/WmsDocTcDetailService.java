package com.maxnerva.cloudmes.service.wh.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.entity.doc.WmsDocTcDetail;
import com.maxnerva.cloudmes.mapper.doc.WmsDocTcDetailMapper;
import com.maxnerva.cloudmes.service.wh.IWmsDocTcDetailService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class WmsDocTcDetailService extends ServiceImpl<WmsDocTcDetailMapper, WmsDocTcDetail> implements IWmsDocTcDetailService {
}
