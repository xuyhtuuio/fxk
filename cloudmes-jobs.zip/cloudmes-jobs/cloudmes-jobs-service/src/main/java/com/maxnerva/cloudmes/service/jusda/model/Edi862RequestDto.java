package com.maxnerva.cloudmes.service.jusda.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/12/07 13:40
 * @Version: 1.0
 */
@Data
public class Edi862RequestDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String SiteName;
    private String CustomerName;
    private String CustomerSupplierNo;
    private String CustomerPartNo;
    private String Manufacture;
    private String ArrivalDT;
    private String OrderQty;
    private String IsBound;
    private String UOM;
    private String DocumentID;
    private String DocumentIDItem;
    private String ShipTo;
    private String FromRoleID;
    private String BUPlantCode;
    private String WorkOrderNo;
    private String InvoiceNo;
    private String SoType;
    private String SupplierName;
    private String SupplierPartNo;
    private String CustomerPo;
    private String CustomerPoItem;
    private String StockStatus;
    private String Reference1;
    private String Reference2;
    private String Reference3;
    private String Reference4;
    private String Reference5;
}
