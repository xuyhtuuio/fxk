package com.maxnerva.cloudmes.entity.mes;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @ClassName SfcCartonInfoDTO
 * @Description sfc箱号信息
 * @Author hej
 * @Date 2023/6/10
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Data
public class SfcCartonInfoVO implements Serializable {

    @ApiModelProperty(value = "栈板号")
    private String palletNo;

    @ApiModelProperty(value = "箱")
    private String cartonNo;

    @ApiModelProperty(value = "SN")
    private String snNo;

    @ApiModelProperty(value = "SN数量")
    private BigDecimal qty;

    @ApiModelProperty("单位")
    private String uomCode;

    @ApiModelProperty(value = "工单号")
    private String workerOrderNo;

    @ApiModelProperty(value = "成品料号")
    private String partNo;

    @ApiModelProperty("post_sfc_pass_station_flag")
    private String postSfcPassStationFlag;

    @ApiModelProperty("post_sfc_message")
    private String postSfcMessage;

    @ApiModelProperty("sync_sfc_extend_info_result")
    private String syncSfcExtendInfoResult;

    @ApiModelProperty("versionCode")
    private String versionCode;

    @ApiModelProperty("modelSerial")
    private String modelSerial;

    @ApiModelProperty("plantCode")
    private String plantCode;

    @ApiModelProperty(value = "工厂组织")
    private String orgCode;

}
