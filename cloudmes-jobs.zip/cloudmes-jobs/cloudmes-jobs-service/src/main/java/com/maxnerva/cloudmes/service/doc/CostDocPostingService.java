package com.maxnerva.cloudmes.service.doc;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.config.Constants;
import com.maxnerva.cloudmes.entity.doc.WmsCostIssueReturnDetail;
import com.maxnerva.cloudmes.entity.doc.WmsCostIssueReturnHeader;
import com.maxnerva.cloudmes.entity.doc.WmsCostRelation;
import com.maxnerva.cloudmes.mapper.basic.SysOrganizationMapper;
import com.maxnerva.cloudmes.mapper.doc.WmsCostIssueReturnDetailMapper;
import com.maxnerva.cloudmes.mapper.doc.WmsCostIssueReturnMapper;
import com.maxnerva.cloudmes.mapper.doc.WmsCostRelationMapper;
import com.maxnerva.cloudmes.service.sap.material.MaterialRfcService;
import com.maxnerva.cloudmes.service.sap.wh.WhRfcService;
import com.maxnerva.cloudmes.service.sap.wh.model.TransferDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Description 费领退过账SAP
 * @Author Likun
 * @Date 2022/8/30
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Service
@Slf4j
public class CostDocPostingService {

    @Autowired
    WmsCostIssueReturnMapper wmsCostIssueReturnHeader;

    @Autowired
    WmsCostIssueReturnDetailMapper wmsCostIssueReturnDetailMapper;

    @Autowired
    WhRfcService whRfcService;

    @Autowired
    MaterialRfcService materialRfcService;

    @Autowired
    SysOrganizationMapper sysOrganizationMapper;

    @Autowired
    WmsCostRelationMapper wmsCostRelationMapper;


    /**
     * 费领退单过账
     * 费领 201        03
     * 费退 202        03
     * 报废 551/z51    03
     */
    @Deprecated
    public void docTransferPostingDeprecated(String sapClientCode, String orgCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }

        //没有过账的费领退单头list
        List<WmsCostIssueReturnHeader> headerList = wmsCostIssueReturnHeader.selectList(Wrappers.<WmsCostIssueReturnHeader>lambdaQuery()
                .eq(WmsCostIssueReturnHeader::getOrgCode, orgCode)
                .eq(WmsCostIssueReturnHeader::getFlownetFlag, "SUCCESS")
                .eq(WmsCostIssueReturnHeader::getFlownetApprovalResult, "Approved")
                .isNull(WmsCostIssueReturnHeader::getPostSapReturnNumber));

        if (CollUtil.isEmpty(headerList)) {
            return;
        }

        headerList.forEach(h -> {

            //依据单头取单身list
            List<WmsCostIssueReturnDetail> details = wmsCostIssueReturnDetailMapper.selectList(Wrappers.<WmsCostIssueReturnDetail>lambdaQuery()
                    .eq(WmsCostIssueReturnDetail::getOrgCode, orgCode)
                    .eq(WmsCostIssueReturnDetail::getWmsCostIssueReturnId, h.getId()));

            if (CollUtil.isEmpty(details)) {
                WmsCostIssueReturnHeader header = new WmsCostIssueReturnHeader();
                header.setId(h.getId());
                header.setPostSapReturnMsg("detail not exist");
                header.setPostSapDatetime(LocalDateTime.now());
                header.setPostSapUser("WMS JOB");
                header.updateById();
                return;
            }

            try {

                List<TransferDto> transferDtos = new ArrayList<>();

                details.forEach(d -> {
                    TransferDto dto = new TransferDto();
                    dto.setTransactionDate(postDate);
                    dto.setDocDate(postDate);
                    dto.setGmCode("03");
                    dto.setMoveType(h.getMovementType());
                    dto.setCostCenter(h.getCostCode());
                    dto.setReasonCode(h.getReason());


                    //无版次取value_type from SAP
                    if (StringUtils.isBlank(d.getPartNoVersion())) {
                        try {
                            // 仓码 + 料号 取value type from sap
                            String s1 = materialRfcService.doGetMaterialValueType(sapClientCode, h.getPlantCode(), d.getPartNo(), d.getWarehouseCode());

                            if (StringUtils.isBlank(s1)) {

                                throw new RuntimeException("not found value type from SAP");
                            }
                            dto.setValueType(s1);

                        } catch (Exception e) {
                            //WmsCostIssueReturnHeader header = new WmsCostIssueReturnHeader();
                            //header.setId(h.getId());
                            //header.setPostSapReturnMsg(e.getMessage());
                            //header.setPostSapDatetime(LocalDateTime.now());
                            //header.setPostSapUser("WMS JOB");
                            //header.updateById();
                            throw new RuntimeException(e.getMessage());

                        }
                    }

                    switch (h.getType()) {
                        case "COST_ISSUE":
                            //费领
                            dto.setFromPlant(h.getPlantCode());
                            dto.setFromWarehouseName(d.getWarehouseCode());
                            dto.setFromPartNo(d.getPartNo());
                            if (StringUtils.isNotBlank(d.getPartNoVersion())) {
                                dto.setFromPartVersion(d.getPartNoVersion());
                            }
                            break;
                        case "COST_RETURN":
                            //费退
                            dto.setFromPlant(h.getPlantCode());
                            //dto.setToPlant(h.getPlantCode());
                            dto.setFromWarehouseName(d.getWarehouseCode());
                            dto.setFromPartNo(d.getPartNo());
                            if (StringUtils.isNotBlank(d.getPartNoVersion())) {
                                dto.setFromPartVersion(d.getPartNoVersion());
                            }
                            break;
                        case "COST_SCRAP":
                            //报废
                            dto.setFromPlant(h.getPlantCode());
                            dto.setFromWarehouseName(d.getWarehouseCode());
                            dto.setFromPartNo(d.getPartNo());
                            if (StringUtils.isNotBlank(d.getPartNoVersion())) {
                                dto.setFromPartVersion(d.getPartNoVersion());
                            }
                            break;
                        default:
                            WmsCostIssueReturnHeader header = new WmsCostIssueReturnHeader();
                            header.setId(h.getId());
                            header.setPostSapReturnMsg("不支持的单据类型");
                            header.setPostSapDatetime(LocalDateTime.now());
                            header.updateById();
                    }

                    dto.setQty(d.getQty().toString());
                    dto.setUnit(StringUtils.isNotBlank(d.getUomCode()) ? d.getUomCode() : "EA");
                    transferDtos.add(dto);

                });

                //posting
                String s = whRfcService.doBatchTransfer(sapClientCode, transferDtos);
                log.info("TransferPosting success content: %S , sap result: %s", JSONUtil.toJsonStr(transferDtos), s);

                // update
                WmsCostIssueReturnHeader header = new WmsCostIssueReturnHeader();
                header.setId(h.getId());
                header.setPostSapReturnNumber(s);
                header.setPostSapReturnMsg("OK");
                header.setPostSapDatetime(LocalDateTime.now());
                header.updateById();

            } catch (Exception e) {
                WmsCostIssueReturnHeader header = new WmsCostIssueReturnHeader();
                header.setId(h.getId());
                header.setPostSapReturnNumber(null);
                header.setPostSapReturnMsg(e.getMessage());
                header.setPostSapDatetime(LocalDateTime.now());
                header.updateById();
                log.error("TransferPosting doc: {} ,errorMsg:{}", JSONUtil.toJsonStr(h), e.getMessage());
            }
        });
    }

    /**
     * 费领退单过账
     * 费领 201        03
     * 费退 202        03
     * 报废 551/z51    03
     */
    public void costDocTransferPosting(String sapClientCode, String orgCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }
        List<WmsCostIssueReturnHeader> headers = wmsCostIssueReturnHeader.selectList(Wrappers.<WmsCostIssueReturnHeader>lambdaQuery()
                .eq(WmsCostIssueReturnHeader::getOrgCode, orgCode)
                .eq(WmsCostIssueReturnHeader::getFlownetFlag, "SUCCESS")
                .eq(WmsCostIssueReturnHeader::getFlownetApprovalResult, "Approved")
                .eq(WmsCostIssueReturnHeader::getIsDeleted, Boolean.FALSE)
                .last(" and (post_sap_return_number is null or post_sap_return_number = '0' or post_sap_return_number = '')"));
        if (CollUtil.isEmpty(headers)) {
            return;
        }
        for (WmsCostIssueReturnHeader header : headers) {
            if ("N".equalsIgnoreCase(Constants.continueJob)) {
                break;
            }
            //判断是否是整体过账
            if (header.getBulkPosting()) {//整体过账
                //校验明细是否可以过账(存在user_confirm_posting_flag = 'N'的就不过账)
                List<WmsCostIssueReturnDetail> details = wmsCostIssueReturnDetailMapper.selectList(Wrappers.<WmsCostIssueReturnDetail>lambdaQuery()
                        .eq(WmsCostIssueReturnDetail::getOrgCode, orgCode)
                        .eq(WmsCostIssueReturnDetail::getWmsCostIssueReturnId, header.getId())
                        .eq(WmsCostIssueReturnDetail::getIsDeleted, Boolean.FALSE));
                if (CollUtil.isEmpty(details)) {
                    continue;
                }
                long n = details.stream().filter(a -> a.getUserConfirmPostingFlag().equalsIgnoreCase("N")).count();
                if (n > 0) {
                    wmsCostIssueReturnHeader.update(null, Wrappers.<WmsCostIssueReturnHeader>lambdaUpdate()
                            .eq(WmsCostIssueReturnHeader::getId, header.getId())
                            .set(WmsCostIssueReturnHeader::getPostSapReturnMsg, "detail没有全部确认过账数量")
                            .set(WmsCostIssueReturnHeader::getPostSapDatetime, LocalDateTime.now()));
                    continue;
                }
                if ("CABG_VN".equals(orgCode)){
                    // CABG_VN LRR费退不过账
                    Long count = details.stream().filter(item -> StrUtil.isNotBlank(item.getLrrCartonNo())).count();
                    if (count > 0) {
                        if ("COST_RETURN".equals(header.getType())){
                            wmsCostIssueReturnHeader.update(null, Wrappers.<WmsCostIssueReturnHeader>lambdaUpdate()
                                    .eq(WmsCostIssueReturnHeader::getId, header.getId())
                                    .set(WmsCostIssueReturnHeader::getPostSapReturnNumber, "CABG_VN_LRR")
                                    .set(WmsCostIssueReturnHeader::getPostSapReturnMsg, "ok")
                                    .set(WmsCostIssueReturnHeader::getPostSapDatetime, LocalDateTime.now()));
                            continue;
                        }
                    }
                }
                //过账
                costDocTransferBulkPosting(header, details, sapClientCode, postDate);
            } else {//按明细过账
                //需要过账的detail list
                List<WmsCostIssueReturnDetail> details = wmsCostIssueReturnDetailMapper.selectList(Wrappers.<WmsCostIssueReturnDetail>lambdaQuery()
                        .eq(WmsCostIssueReturnDetail::getOrgCode, orgCode)
                        .eq(WmsCostIssueReturnDetail::getWmsCostIssueReturnId, header.getId())
                        .eq(WmsCostIssueReturnDetail::getUserConfirmPostingFlag, "Y")
                        .eq(WmsCostIssueReturnDetail::getIsDeleted, Boolean.FALSE)
                        .last(" and (post_sap_return_number is null or post_sap_return_number = '0' or post_sap_return_number = '')"));
                if (CollUtil.isEmpty(details)) {
                    continue;
                }
                if ("CABG_VN".equals(orgCode)){
                    // CABG_VN LRR费退不过账
                    Long count = details.stream().filter(item -> StrUtil.isNotBlank(item.getLrrCartonNo())).count();
                    if (count > 0) {
                        if ("COST_RETURN".equals(header.getType())){
                            List<Integer> idList = details.stream().map(item -> item.getId()).collect(Collectors.toList());
                            wmsCostIssueReturnDetailMapper.update(null, Wrappers.<WmsCostIssueReturnDetail>lambdaUpdate()
                                    .in(WmsCostIssueReturnDetail::getId, idList)
                                    .set(WmsCostIssueReturnDetail::getPostSapReturnNumber, "CABG_VN_LRR")
                                    .set(WmsCostIssueReturnDetail::getPostSapReturnMsg, "ok")
                                    .set(WmsCostIssueReturnDetail::getPostSapDatetime, LocalDateTime.now()));
                            wmsCostIssueReturnHeader.update(null, Wrappers.<WmsCostIssueReturnHeader>lambdaUpdate()
                                    .eq(WmsCostIssueReturnHeader::getId, header.getId())
                                    .set(WmsCostIssueReturnHeader::getPostSapReturnNumber, "CABG_VN_LRR")
                                    .set(WmsCostIssueReturnHeader::getPostSapReturnMsg, "ok")
                                    .set(WmsCostIssueReturnHeader::getPostSapDatetime, LocalDateTime.now()));
                            continue;
                        }
                    }
                }
                for (WmsCostIssueReturnDetail d : details) {
                    try {
                        TransferDto dto = new TransferDto();
                        dto.setTransactionDate(postDate);
                        dto.setDocDate(postDate);
                        dto.setGmCode("03");
                        dto.setMoveType(header.getMovementType());
                        dto.setCostCenter(header.getCostCode());
                        dto.setReasonCode(header.getReason());
                        dto.setHeaderText(header.getDocNo());
                        dto.setItemText(header.getDocDesc());
                        dto.setRefDocNo(header.getProjectName());
                        WmsCostRelation wmsCostRelation = wmsCostRelationMapper
                                .selectOne(Wrappers.<WmsCostRelation>lambdaQuery()
                                        .eq(WmsCostRelation::getReasonCode, header.getReason())
                                        .last("limit 1"));
                        if (ObjectUtil.isNotNull(wmsCostRelation)) {
                            dto.setAccountingSubjects(wmsCostRelation.getAccountingSubjects());
                        }

                        switch (header.getType()) {
                            case "COST_ISSUE":
                                //费领
                                dto.setFromPlant(header.getPlantCode());
                                dto.setFromWarehouseName(d.getWarehouseCode());
                                dto.setFromPartNo(d.getPartNo());
                                if (StringUtils.isNotBlank(d.getPartNoVersion())) {
                                    dto.setFromPartVersion(d.getPartNoVersion());
                                }
                                break;
                            case "COST_RETURN":
                                //费退
                                dto.setFromPlant(header.getPlantCode());
                                //dto.setToPlant(h.getPlantCode());
                                dto.setFromWarehouseName(d.getWarehouseCode());
                                dto.setFromPartNo(d.getPartNo());
                                if (StringUtils.isNotBlank(d.getPartNoVersion())) {
                                    dto.setFromPartVersion(d.getPartNoVersion());
                                }
                                break;
                            case "COST_SCRAP":
                                //报废
                                dto.setFromPlant(header.getPlantCode());
                                dto.setFromWarehouseName(d.getWarehouseCode());
                                dto.setFromPartNo(d.getPartNo());
                                if (StringUtils.isNotBlank(d.getPartNoVersion())) {
                                    dto.setFromPartVersion(d.getPartNoVersion());
                                }
                                break;
                            default:
                                WmsCostIssueReturnDetail udpateDtail = new WmsCostIssueReturnDetail();
                                udpateDtail.setId(d.getId());
                                udpateDtail.setPostSapReturnMsg("不支持的单据类型");
                                udpateDtail.setPostSapDatetime(LocalDateTime.now());
                                udpateDtail.updateById();
                        }

                        dto.setQty(d.getConfirmPostingQty().toString());
                        dto.setValueType(d.getValuationType());
                        dto.setUnit(StringUtils.isNotBlank(d.getUomCode()) ? d.getUomCode() : "EA");
                        List<TransferDto> dtos = new ArrayList<>();
                        dtos.add(dto);
                        //posting
                        String s = whRfcService.doBatchTransfer(sapClientCode, dtos);
                        log.info("TransferPosting success content: {} , sap result: {}", JSONUtil.toJsonStr(dtos), s);
                        wmsCostIssueReturnDetailMapper.update(null, Wrappers.<WmsCostIssueReturnDetail>lambdaUpdate()
                                .eq(WmsCostIssueReturnDetail::getId, d.getId())
                                .set(WmsCostIssueReturnDetail::getPostSapReturnNumber, s)
                                .set(WmsCostIssueReturnDetail::getPostSapReturnMsg, "ok")
                                .set(WmsCostIssueReturnDetail::getPostSapDatetime, LocalDateTime.now()));
                    } catch (Exception e) {
                        wmsCostIssueReturnDetailMapper.update(null, Wrappers.<WmsCostIssueReturnDetail>lambdaUpdate()
                                .eq(WmsCostIssueReturnDetail::getId, d.getId())
                                .set(WmsCostIssueReturnDetail::getPostSapReturnMsg, e.getMessage())
                                .set(WmsCostIssueReturnDetail::getPostSapDatetime, LocalDateTime.now()));
                        continue;
                    }
                    //校验该单是否全部过账完成
                    List<WmsCostIssueReturnDetail> detailList = wmsCostIssueReturnDetailMapper.selectList(Wrappers.<WmsCostIssueReturnDetail>lambdaQuery()
                            .eq(WmsCostIssueReturnDetail::getOrgCode, orgCode)
                            .eq(WmsCostIssueReturnDetail::getWmsCostIssueReturnId, header.getId())
                            .eq(WmsCostIssueReturnDetail::getIsDeleted, Boolean.FALSE)
                            .last(" and (post_sap_return_number is null or post_sap_return_number = '0' or post_sap_return_number = '')"));
                    if (CollUtil.isEmpty(detailList)) {
                        wmsCostIssueReturnHeader.update(null, Wrappers.<WmsCostIssueReturnHeader>lambdaUpdate()
                                .eq(WmsCostIssueReturnHeader::getId, header.getId())
                                .set(WmsCostIssueReturnHeader::getPostSapReturnNumber, "ok")
                                .set(WmsCostIssueReturnHeader::getPostSapReturnMsg, "ok")
                                .set(WmsCostIssueReturnHeader::getPostSapDatetime, LocalDateTime.now()));
                    }
                }
            }
        }
    }

    /**
     * 费领退、报废整体过账
     */
    private void costDocTransferBulkPosting(WmsCostIssueReturnHeader headerInfo, List<WmsCostIssueReturnDetail> details, String sapClientCode, String postDate) {
        //需要过账的detail list

        try {
            List<TransferDto> dtos = new ArrayList<>();

            details.forEach(d -> {
                TransferDto dto = new TransferDto();
                dto.setTransactionDate(postDate);
                dto.setDocDate(postDate);
                dto.setGmCode("03");
                dto.setMoveType(headerInfo.getMovementType());
                dto.setCostCenter(headerInfo.getCostCode());
                dto.setReasonCode(headerInfo.getReason());
                dto.setHeaderText(headerInfo.getDocNo());
                dto.setItemText(headerInfo.getDocDesc());
                dto.setRefDocNo(headerInfo.getProjectName());
                WmsCostRelation wmsCostRelation = wmsCostRelationMapper
                        .selectOne(Wrappers.<WmsCostRelation>lambdaQuery()
                                .eq(WmsCostRelation::getReasonCode, headerInfo.getReason())
                                .last("limit 1"));
                if (ObjectUtil.isNotNull(wmsCostRelation)) {
                    dto.setAccountingSubjects(wmsCostRelation.getAccountingSubjects());
                }

                switch (headerInfo.getType()) {
                    case "COST_ISSUE":
                        //费领
                        dto.setFromPlant(headerInfo.getPlantCode());
                        dto.setFromWarehouseName(d.getWarehouseCode());
                        dto.setFromPartNo(d.getPartNo());
                        if (StringUtils.isNotBlank(d.getPartNoVersion())) {
                            dto.setFromPartVersion(d.getPartNoVersion());
                        }
                        break;
                    case "COST_RETURN":
                        //费退
                        dto.setFromPlant(headerInfo.getPlantCode());
                        //dto.setToPlant(h.getPlantCode());
                        dto.setFromWarehouseName(d.getWarehouseCode());
                        dto.setFromPartNo(d.getPartNo());
                        if (StringUtils.isNotBlank(d.getPartNoVersion())) {
                            dto.setFromPartVersion(d.getPartNoVersion());
                        }
                        break;
                    case "COST_SCRAP":
                        //报废
                        dto.setFromPlant(headerInfo.getPlantCode());
                        dto.setFromWarehouseName(d.getWarehouseCode());
                        dto.setFromPartNo(d.getPartNo());
                        if (StringUtils.isNotBlank(d.getPartNoVersion())) {
                            dto.setFromPartVersion(d.getPartNoVersion());
                        }
                        break;
                    default:
                        WmsCostIssueReturnDetail udpateDtail = new WmsCostIssueReturnDetail();
                        udpateDtail.setId(d.getId());
                        udpateDtail.setPostSapReturnMsg("不支持的单据类型");
                        udpateDtail.setPostSapDatetime(LocalDateTime.now());
                        udpateDtail.updateById();
                }

                dto.setQty(d.getConfirmPostingQty().toString());
                dto.setValueType(d.getValuationType());
                dto.setUnit(StringUtils.isNotBlank(d.getUomCode()) ? d.getUomCode() : "EA");
                dtos.add(dto);
            });
            //posting
            String s = whRfcService.doBatchTransfer(sapClientCode, dtos);
            log.info("TransferPosting success content: {} , sap result: {}", JSONUtil.toJsonStr(dtos), s);
            if (StringUtils.isEmpty(s)) {
                wmsCostIssueReturnHeader.update(null, Wrappers.<WmsCostIssueReturnHeader>lambdaUpdate()
                        .eq(WmsCostIssueReturnHeader::getId, headerInfo.getId())
                        .set(WmsCostIssueReturnHeader::getPostSapReturnMsg, "SAP not response")
                        .set(WmsCostIssueReturnHeader::getPostSapDatetime, LocalDateTime.now()));
            } else {
                wmsCostIssueReturnHeader.update(null, Wrappers.<WmsCostIssueReturnHeader>lambdaUpdate()
                        .eq(WmsCostIssueReturnHeader::getId, headerInfo.getId())
                        .set(WmsCostIssueReturnHeader::getPostSapReturnNumber, s)
                        .set(WmsCostIssueReturnHeader::getPostSapReturnMsg, "ok")
                        .set(WmsCostIssueReturnHeader::getPostSapDatetime, LocalDateTime.now()));
            }
        } catch (Exception e) {
            wmsCostIssueReturnHeader.update(null, Wrappers.<WmsCostIssueReturnHeader>lambdaUpdate()
                    .eq(WmsCostIssueReturnHeader::getId, headerInfo.getId())
                    .set(WmsCostIssueReturnHeader::getPostSapReturnMsg, e.getMessage())
                    .set(WmsCostIssueReturnHeader::getPostSapDatetime, LocalDateTime.now()));
        }
    }

   /* public void costAllDocTransferPosting(String sapClientCode, String postDate) {
        List<String> orgCodeList = sysOrganizationMapper.selectAllOrgCode();
        for (String orgCode : orgCodeList) {
            if("EPDI".equalsIgnoreCase(orgCode)){
                continue;
            }
            log.info("costDocPostingService orgCode:{}, start :{}", orgCode, System.currentTimeMillis());
            costDocTransferPosting(sapClientCode, orgCode, postDate);
            log.info("costDocPostingService orgCode:{}, end :{}", orgCode, System.currentTimeMillis());
        }
    }*/
}
