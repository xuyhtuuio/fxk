package com.maxnerva.cloudmes.service.wh.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.date.LocalDateTimeUtil;
import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpStatus;
import cn.hutool.json.JSONConfig;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.write.style.column.LongestMatchColumnWidthStyleStrategy;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.config.AgileTcConfig;
import com.maxnerva.cloudmes.config.Constants;
import com.maxnerva.cloudmes.config.DataCenterConfig;
import com.maxnerva.cloudmes.config.GlobalCommonConfig;
import com.maxnerva.cloudmes.entity.basic.*;
import com.maxnerva.cloudmes.entity.doc.WmsDocReceive;
import com.maxnerva.cloudmes.entity.doc.WmsDocTcDetail;
import com.maxnerva.cloudmes.entity.doc.WmsDocTcHeader;
import com.maxnerva.cloudmes.entity.jusda.WmsJusdaBuContrastEntity;
import com.maxnerva.cloudmes.entity.jusda.WmsJusdaReceiptEntity;
import com.maxnerva.cloudmes.entity.qms.SyncQmsMsdLevelVO;
import com.maxnerva.cloudmes.entity.qms.SyncQmsValidVO;
import com.maxnerva.cloudmes.entity.qms.WmsSyncMfgMaterialFromQmsLog;
import com.maxnerva.cloudmes.entity.qms.WmsSyncMsdLevelFromQmsLog;
import com.maxnerva.cloudmes.entity.wh.WmsPkgInfo;
import com.maxnerva.cloudmes.entity.wh.WmsPkgInfoDTO;
import com.maxnerva.cloudmes.entity.wh.WmsPkgInfoLog;
import com.maxnerva.cloudmes.entity.wo.*;
import com.maxnerva.cloudmes.excel.dto.ExpiredPkgInfoExportDTO;
import com.maxnerva.cloudmes.excel.handler.FreezeAndFilterHandler;
import com.maxnerva.cloudmes.mapper.basic.BasicMaterialMapper;
import com.maxnerva.cloudmes.mapper.basic.SysDictMapper;
import com.maxnerva.cloudmes.mapper.basic.WmsMaterialClassExpiredConfigMapper;
import com.maxnerva.cloudmes.mapper.basic.WmsSapWarehouseCodeMapper;
import com.maxnerva.cloudmes.mapper.doc.WmsDocReceiveMapper;
import com.maxnerva.cloudmes.mapper.doc.WmsDocTcDetailMapper;
import com.maxnerva.cloudmes.mapper.doc.WmsDocTcHeaderMapper;
import com.maxnerva.cloudmes.mapper.jusda.WmsJusdaBuContrastMapper;
import com.maxnerva.cloudmes.mapper.jusda.WmsJusdaReceiptMapper;
import com.maxnerva.cloudmes.mapper.wh.WmsPkgInfoLogMapper;
import com.maxnerva.cloudmes.mapper.wh.WmsPkgInfoMapper;
import com.maxnerva.cloudmes.mapper.wo.*;
import com.maxnerva.cloudmes.service.basic.CodeRuleService;
import com.maxnerva.cloudmes.service.basic.IWmsFileDownloadLogService;
import com.maxnerva.cloudmes.service.qms.IWmsSyncMfgMaterialFromQmsLogService;
import com.maxnerva.cloudmes.service.qms.IWmsSyncMsdLevelFromQmsLogService;
import com.maxnerva.cloudmes.service.wh.IWmsDocTcDetailService;
import com.maxnerva.cloudmes.service.wh.IWmsDocTcHeaderService;
import com.maxnerva.cloudmes.service.wh.IWmsPkgInfoLogService;
import com.maxnerva.cloudmes.service.wh.IWmsPkgInfoService;
import com.maxnerva.cloudmes.service.wh.model.RequestAgileTcFileVO;
import com.maxnerva.cloudmes.service.wh.model.RequestAgileTcVO;
import com.maxnerva.cloudmes.service.wh.model.ResponseAgileTcDTO;
import com.maxnerva.cloudmes.service.wh.model.SyncInventoryForFiiDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Author hgx
 * @Description
 * @Date 2023/6/1
 */
@Service
@Slf4j
public class WmsPkgInfoServiceImpl extends ServiceImpl<WmsPkgInfoMapper, WmsPkgInfo> implements IWmsPkgInfoService {

    @Value("${download.url:}")
    private String downloadUrl;

    @Autowired
    private AgileTcConfig agileTcConfig;

    @Autowired
    private WmsPkgInfoMapper wmsPkgInfoMapper;

    @Autowired
    private WmsPkgInfoLogMapper wmsPkgInfoLogMapper;

    @Autowired
    private WmsWorkOrderPickTaskMapper wmsWorkOrderPickTaskMapper;

    @Autowired
    private WmsWorkOrderHeaderMapper wmsWorkOrderHeaderMapper;

    @Autowired
    private WmsWorkOrderDetailMapper wmsWorkOrderDetailMapper;

    @Autowired
    private IWmsPkgInfoLogService wmsPkgInfoLogService;

    @Autowired
    private WmsDocTcHeaderMapper wmsDocTcHeaderMapper;

    @Autowired
    private WmsDocTcDetailMapper wmsDocTcDetailMapper;

    @Autowired
    private WmsWorkOrderDetailShortageHeaderMapper wmsWorkOrderDetailShortageHeaderMapper;

    @Autowired
    private WmsWorkOrderDetailShortageDetailMapper wmsWorkOrderDetailShortageDetailMapper;

    @Autowired
    private CodeRuleService codeRuleService;

    @Autowired
    WmsJusdaReceiptMapper wmsJusdaReceiptMapper;

    @Autowired
    WmsDocReceiveMapper wmsDocReceiveMapper;

    @Autowired
    SysDictMapper sysDictMapper;

    @Autowired
    BasicMaterialMapper basicMaterialMapper;

    @Autowired
    IWmsFileDownloadLogService wmsFileDownloadLogService;

    @Autowired
    IWmsDocTcHeaderService wmsDocTcHeaderService;

    @Autowired
    IWmsDocTcDetailService wmsDocTcDetailService;

    @Autowired
    WmsJusdaBuContrastMapper wmsJusdaBuContrastMapper;

    @Autowired
    WmsMaterialClassExpiredConfigMapper wmsMaterialClassExpiredConfigMapper;

    @Resource
    private WmsWorkOrderPickLogMapper wmsWorkOrderPickLogMapper;

    @Resource
    private IWmsSyncMfgMaterialFromQmsLogService wmsSyncMfgMaterialFromQmsLogService;

    @Resource
    private IWmsSyncMsdLevelFromQmsLogService wmsSyncMsdLevelFromQmsLogService;

    @Autowired
    WmsSapWarehouseCodeMapper wmsSapWarehouseCodeMapper;

    @Autowired
    DataCenterConfig dataCenterConfig;

    @Resource
    GlobalCommonConfig globalCommonConfig;

    @Override
    public int expireLockMaterial() {
        List<WmsPkgInfo> wmsPkgInfoList = wmsPkgInfoMapper.selectList(Wrappers.<WmsPkgInfo>lambdaQuery()
                .eq(WmsPkgInfo::getLockStatus, "0")
                .gt(WmsPkgInfo::getCurrentQty, BigDecimal.ZERO)
                .eq(WmsPkgInfo::getControlMethod, "SN")
                .last(" and ( end_date - CURRENT_DATE ) <= 5"));
        wmsPkgInfoList.forEach(wmsPkgInfo -> {
            wmsPkgInfo.setLockStatus("3");
            wmsPkgInfo.setLockDate(LocalDateTime.now());
            wmsPkgInfo.setLockMessage("物料过期锁料");
            wmsPkgInfo.setTransactionType("EXPIRED_LOCK_MATERIAL");
            wmsPkgInfo.setTransactionMessage("物料过期锁料");
            wmsPkgInfoMapper.updateById(wmsPkgInfo);
            WmsPkgInfoLog wmsPkgInfoLog = new WmsPkgInfoLog();
            BeanUtils.copyProperties(wmsPkgInfo, wmsPkgInfoLog);
            wmsPkgInfoLog.setId(null);
            wmsPkgInfoLogMapper.insert(wmsPkgInfoLog);
        });
        return wmsPkgInfoList.size();
    }

    @Override
    public void unLockMaterialAuto() {
        List<WmsWorkOrderHeader> wmsWorkOrderHeaderList = wmsWorkOrderHeaderMapper
                .selectList(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                        .ne(WmsWorkOrderHeader::getWorkOrderType, "CKD")
//                        .eq(WmsWorkOrderHeader::getWorkOrderNo,"000100107268")
                        .isNotNull(WmsWorkOrderHeader::getLockWoDateTime));
        LocalDateTime now = LocalDateTime.now();
        //筛选工单锁料时间离当前时间超过二十四小时的工单
        wmsWorkOrderHeaderList = wmsWorkOrderHeaderList.stream()
                .filter(wmsWorkOrderHeader -> Duration.between(wmsWorkOrderHeader.getLockWoDateTime(),
                        now).toHours() >= 24)
                .collect(Collectors.toList());
        List<String> unLockPkgIdList = CollUtil.newArrayList();
        wmsWorkOrderHeaderList.forEach(wmsWorkOrderHeader -> {
            //工单号
            String workOrderNo = wmsWorkOrderHeader.getWorkOrderNo();
            //查询要解锁的工单
            List<WmsPkgInfo> wmsPkgInfoList = wmsPkgInfoMapper.selectList(Wrappers.<WmsPkgInfo>lambdaQuery()
                    .eq(WmsPkgInfo::getLockWorkOrderNo, workOrderNo)
                    .eq(WmsPkgInfo::getLockStatus, "1")
                    .gt(WmsPkgInfo::getCurrentQty, BigDecimal.ZERO)
            );
            List<WmsPkgInfoLog> wmsPkgInfoLogList = CollUtil.newArrayList();
            wmsPkgInfoList.forEach(wmsPkgInfo -> {
                wmsPkgInfo.setLockStatus("0");
                wmsPkgInfo.setLockWorkOrderNo("000-000");
                wmsPkgInfo.setLockWorkOrderItem(StrUtil.EMPTY);
                wmsPkgInfo.setLockQty(BigDecimal.ZERO);
                wmsPkgInfo.setWorkOrderToLocation(StrUtil.EMPTY);
                wmsPkgInfo.setFeederWorkOrderItem(StrUtil.EMPTY);
                wmsPkgInfo.setTransactionType("UN_LOCK_MATERIAL_AUTO");
                wmsPkgInfo.setTransactionMessage("工单锁料时间大于24小时自动解锁");
                wmsPkgInfoMapper.update(null, Wrappers.<WmsPkgInfo>lambdaUpdate()
                        .eq(WmsPkgInfo::getId, wmsPkgInfo.getId())
                        .set(WmsPkgInfo::getLockStatus, "0")
                        .set(WmsPkgInfo::getLockWorkOrderNo, "000-000")
                        .set(WmsPkgInfo::getLockWorkOrderItem, StrUtil.EMPTY)
                        .set(WmsPkgInfo::getLockQty, BigDecimal.ZERO)
                        .set(WmsPkgInfo::getWorkOrderToLocation, StrUtil.EMPTY)
                        .set(WmsPkgInfo::getFeederWorkOrderItem, StrUtil.EMPTY)
                        .set(WmsPkgInfo::getTransactionType, "UN_LOCK_MATERIAL_AUTO")
                        .set(WmsPkgInfo::getTransactionMessage, "工单锁料时间大于24小时自动解锁")
                        .set(WmsPkgInfo::getLastEditor, "sysadmin")
                        .set(WmsPkgInfo::getLastEditedDt, LocalDateTime.now()));
//                wmsPkgInfoMapper.updateById(wmsPkgInfo);
                WmsPkgInfoLog wmsPkgInfoLog = new WmsPkgInfoLog();
                BeanUtils.copyProperties(wmsPkgInfo, wmsPkgInfoLog);
                wmsPkgInfoLog.setId(null);
                wmsPkgInfoLog.setCreator("sysadmin");
                wmsPkgInfoLog.setCreatedDt(LocalDateTime.now());
                wmsPkgInfoLogList.add(wmsPkgInfoLog);
                unLockPkgIdList.add(wmsPkgInfo.getPkgId());
            });
            //新增条码履历
            wmsPkgInfoLogService.saveBatch(wmsPkgInfoLogList);
            //修改该工单已存在的捡料任务的捡料完成标识为Y
            wmsWorkOrderPickTaskMapper.update(null, Wrappers.<WmsWorkOrderPickTask>lambdaUpdate()
                    .eq(WmsWorkOrderPickTask::getWorkOrderNo, workOrderNo)
                    .eq(WmsWorkOrderPickTask::getTaskType, "ASSY")
                    .set(WmsWorkOrderPickTask::getTaskCompletedFlag, "Y"));
            //更新工单锁料时间为空,锁料量为0
            wmsWorkOrderHeader.setLockWoDateTime(null);
            wmsWorkOrderHeader.setLockWoPkgQty(BigDecimal.ZERO);
            wmsWorkOrderHeaderMapper.updateById(wmsWorkOrderHeader);
        });
        log.info("unLockMaterialAuto unlockPkg:{}", StrUtil.join(",", unLockPkgIdList));
    }

    @Override
    public void generateTcDoc(String orgCode) {
        // 延迟7天算过期
        LocalDate nowDate = LocalDate.now().plusDays(agileTcConfig.getDelayDay());
        // 三年內的才能特採
        LocalDate minDate = LocalDate.now().plusDays(agileTcConfig.getMinDay());
        LocalDateTime startDateTime = LocalDateTime.now();
        List<WmsMaterialClassExpiredConfig> materialClassExpiredConfigList = wmsMaterialClassExpiredConfigMapper.selectList(Wrappers.<WmsMaterialClassExpiredConfig>lambdaQuery()
                .eq(WmsMaterialClassExpiredConfig::getOrgCode, orgCode)
        );
        Map<String, Integer> expiredDayMap = materialClassExpiredConfigList.stream().collect(Collectors.toMap(k -> k.getClassCode(), v -> v.getExpiredDay()));
        while (true) {
            if (Constants.continueJob.equalsIgnoreCase("N")) {
                return;
            }
            try {
                // 延迟3秒，减少操作数据库频率
                Thread.sleep(3000);
            } catch (Exception e) {
                e.printStackTrace();
            }

            LocalDateTime now = LocalDateTime.now();
            // 执行时长超过25分钟，强行终止。
            long hours = LocalDateTimeUtil.between(startDateTime, now).toMinutes();
            if (hours > 25) {
                break;
            }
            WmsWorkOrderDetailShortageHeader wmsMaterialShortageHeader = wmsWorkOrderDetailShortageHeaderMapper.selectOne(Wrappers.<WmsWorkOrderDetailShortageHeader>lambdaQuery()
                    .eq(WmsWorkOrderDetailShortageHeader::getOrgCode, orgCode)
                    .eq(WmsWorkOrderDetailShortageHeader::getTcStatus, "0")
                    .orderByAsc(WmsWorkOrderDetailShortageHeader::getId)
                    .last("limit 1")
            );

            if (ObjectUtil.isNull(wmsMaterialShortageHeader)) {
                break;
            }

            List<WmsDocTcHeader> tcHeaderList = ListUtil.toList();
            List<List<WmsDocTcDetail>> tcDetailList = ListUtil.toList();
            wmsWorkOrderDetailShortageHeaderMapper.update(null, Wrappers.<WmsWorkOrderDetailShortageHeader>lambdaUpdate()
                    .set(WmsWorkOrderDetailShortageHeader::getTcStatus, "2")
                    .eq(WmsWorkOrderDetailShortageHeader::getId, wmsMaterialShortageHeader.getId())
            );

            List<String> workOrderNoList = JSON.parseArray(wmsMaterialShortageHeader.getWorkOrderNo(), String.class);
            workOrderNoList.forEach(workOrderNo -> {
                WmsWorkOrderHeader wmsWorkOrderHeader = wmsWorkOrderHeaderMapper.selectOne(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                        .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                        .eq(WmsWorkOrderHeader::getWorkOrderNo, workOrderNo)
                        .last("limit 1")
                );

                WmsJusdaBuContrastEntity wmsJusdaBuContrastEntity = wmsJusdaBuContrastMapper.selectOne(Wrappers.<WmsJusdaBuContrastEntity>lambdaQuery()
                        .eq(WmsJusdaBuContrastEntity::getOrgCode, wmsWorkOrderHeader.getOrgCode())
                        .eq(WmsJusdaBuContrastEntity::getPlantCode, wmsWorkOrderHeader.getPlantCode())
                        .eq(WmsJusdaBuContrastEntity::getMrpArea, wmsWorkOrderHeader.getMrpArea())
                        .last("limit 1")
                );
                String customer = StrUtil.EMPTY;
                if (ObjectUtil.isNotNull(wmsJusdaBuContrastEntity)) {
                    customer = wmsJusdaBuContrastEntity.getCustomer();
                }
                String plantCode = wmsWorkOrderHeader.getPlantCode();
                String materialShortageNo = wmsMaterialShortageHeader.getMaterialShortageNo();
                String operator = wmsMaterialShortageHeader.getCreator();
                // 如果该工单存在新建，已发送的特采单，不允许继续创建特采单
                WmsDocTcHeader tcHeader = wmsDocTcHeaderMapper.selectOne(Wrappers.<WmsDocTcHeader>lambdaQuery()
                        .eq(WmsDocTcHeader::getOrgCode, orgCode)
                        .eq(WmsDocTcHeader::getPlantCode, plantCode)
                        .eq(WmsDocTcHeader::getWorkOrderNo, workOrderNo)
                        .in(WmsDocTcHeader::getIdentify, ListUtil.toList("0", "2"))
                        .orderByDesc(WmsDocTcHeader::getId)
                        .last("limit 1")
                );
                if (ObjectUtil.isNotNull(tcHeader)) {
                    return;
                }
                // 同一个工单，单头的公共部分
                WmsDocTcHeader wmsDocTcHeader = new WmsDocTcHeader();
                wmsDocTcHeader.setIdentify("0");
                wmsDocTcHeader.setOrgCode(orgCode);
                wmsDocTcHeader.setPlantCode(plantCode);
                wmsDocTcHeader.setWorkOrderNo(workOrderNo);
                wmsDocTcHeader.setOperator(operator);
                wmsDocTcHeader.setCustomer(customer);
                wmsDocTcHeader.setFinishPartNo(wmsWorkOrderHeader.getPartNo());
                wmsDocTcHeader.setTcExpirationDate(LocalDateTime.now().plusDays(agileTcConfig.getExpirationDay()));
                wmsDocTcHeader.setCreatedDt(LocalDateTime.now());
                wmsDocTcHeader.setCreator("WMS-JOB");
                wmsDocTcHeader.setLastEditedDt(LocalDateTime.now());
                wmsDocTcHeader.setLastEditor("WMS-JOB");
                wmsDocTcHeader.setWithinThreeYears("Y");
                tcHeaderList.add(wmsDocTcHeader);
                List<WmsDocTcDetail> result = ListUtil.toList();
                tcDetailList.add(result);

                List<WmsWorkOrderDetailShortageDetail> shortageDetailList = wmsWorkOrderDetailShortageDetailMapper.selectList(Wrappers.<WmsWorkOrderDetailShortageDetail>lambdaQuery()
                        .eq(WmsWorkOrderDetailShortageDetail::getOrgCode, orgCode)
                        .eq(WmsWorkOrderDetailShortageDetail::getMaterialShortageNo, materialShortageNo)
                        .eq(WmsWorkOrderDetailShortageDetail::getWorkOrderNo, workOrderNo)
                );

                List<WmsWorkOrderDetail> workOrderDetailList = wmsWorkOrderDetailMapper.selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
                        .select(WmsWorkOrderDetail::getWorkOrderItem, WmsWorkOrderDetail::getPartNo, WmsWorkOrderDetail::getFromWarehouseCode)
                        .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                        .eq(WmsWorkOrderDetail::getWorkOrderNo, workOrderNo)
                        .eq(WmsWorkOrderDetail::getDeletedItem, "0")
                );
                // 群组+料号->仓码
                Map<String, String> warehouseCodeMap = workOrderDetailList.stream().collect(Collectors.toMap(k -> k.getWorkOrderItem() + k.getPartNo(), v -> v.getFromWarehouseCode()));

                shortageDetailList.sort(Comparator.comparing(WmsWorkOrderDetailShortageDetail::getWorkOrderItem)
                        .thenComparing(WmsWorkOrderDetailShortageDetail::getPartRelationShip));

                Set<String> pkgIdSet = new HashSet();

                WmsWorkOrderDetailShortageDetail mainDetail = null;
                BigDecimal assignedShortageQty = null;

                for (WmsWorkOrderDetailShortageDetail detail : shortageDetailList) {
                    if (ObjectUtil.isNull(mainDetail)) {
                        mainDetail = detail;
                        assignedShortageQty = mainDetail.getWmsItemAssignedShortageQty();
                    }
                    if (!detail.getWorkOrderItem().equals(mainDetail.getWorkOrderItem())) {
                        mainDetail = detail;
                        assignedShortageQty = mainDetail.getWmsItemAssignedShortageQty();
                    }

                    if (assignedShortageQty.compareTo(BigDecimal.ZERO) <= 0) {
                        continue;
                    }

                    String warehouseCode = warehouseCodeMap.get(detail.getWorkOrderItem() + detail.getPartNo());

                    if (ObjectUtil.isNull(warehouseCode)) {
                        continue;
                    }

                    List<WmsPkgInfoDTO> pkgInfoList = wmsPkgInfoMapper.selectExpiredAndNotTcPkgInfo(orgCode, plantCode, warehouseCode, detail.getPartNo(), minDate, nowDate);
                    for (WmsPkgInfoDTO pkgInfo : pkgInfoList) {
                        // 已被占用的PKG跳过
                        if (pkgIdSet.contains(pkgInfo.getPkgId())) {
                            continue;
                        }
                        // 没有物料分类的跳过
                        if (StrUtil.isBlank(pkgInfo.getClassCode())) {
                            continue;
                        }
                        // 没有有效期的跳过
                        Integer expiredDay = expiredDayMap.get(pkgInfo.getClassCode());
                        if (ObjectUtil.isNull(expiredDay)) {
                            continue;
                        }
                        LocalDate dateCode = pkgInfo.getDateCode();
                        // dateCode + 有效期 小于当天 跳过
                        if (dateCode.plusDays(expiredDay).compareTo(LocalDate.now()) < 0) {
                            continue;
                        }

                        if (assignedShortageQty.compareTo(BigDecimal.ZERO) > 0) {
                            WmsDocTcDetail wmsDocTcDetail = new WmsDocTcDetail();
                            wmsDocTcDetail.setOrgCode(orgCode);
                            wmsDocTcDetail.setPkgId(pkgInfo.getPkgId());
                            wmsDocTcDetail.setPlantCode(plantCode);
                            wmsDocTcDetail.setSupplierPartNo(pkgInfo.getSupplierPartNo());
                            wmsDocTcDetail.setMfgName(pkgInfo.getMfgName());
                            wmsDocTcDetail.setWmsNo(pkgInfo.getWmsNo());
                            wmsDocTcDetail.setPartNo(pkgInfo.getPartNo());
                            wmsDocTcDetail.setQty(pkgInfo.getCurrentQty());
                            wmsDocTcDetail.setOriginalDateCode(pkgInfo.getOriginalDateCode());
                            wmsDocTcDetail.setLotCode(pkgInfo.getLotCode());
                            wmsDocTcDetail.setEndDate(pkgInfo.getEndDate());
                            wmsDocTcDetail.setMaterialDesc(pkgInfo.getMaterialDesc());
                            wmsDocTcDetail.setClassCode(pkgInfo.getClassCode());
                            wmsDocTcDetail.setCreatedDt(LocalDateTime.now());
                            wmsDocTcDetail.setCreator("WMS-JOB");
                            wmsDocTcDetail.setLastEditedDt(LocalDateTime.now());
                            wmsDocTcDetail.setLastEditor("WMS-JOB");
                            result.add(wmsDocTcDetail);
                            pkgIdSet.add(pkgInfo.getPkgId());
                            assignedShortageQty = assignedShortageQty.subtract(pkgInfo.getCurrentQty());
//                            if (StrUtil.isBlank(wmsDocTcHeader.getOriginator())){
//                                wmsDocTcHeader.setOriginator(pkgInfo.getPurchaser());
//                            }
                        }
                    }
                }

            });
            // 查GR单号
            for (int i = 0; i < tcHeaderList.size(); i++) {
                List<WmsDocTcDetail> wmsDocTcDetailList = tcDetailList.get(i);
                if (CollUtil.isEmpty(wmsDocTcDetailList)) {
                    continue;
                }

                wmsDocTcDetailList.forEach(detail -> {
                    if (StrUtil.isBlank(detail.getWmsNo())) {
                        return;
                    }
                    WmsDocReceive wmsDocReceive = wmsDocReceiveMapper.selectOne(Wrappers.<WmsDocReceive>lambdaQuery()
                            .eq(WmsDocReceive::getOrgCode, detail.getOrgCode())
                            .eq(WmsDocReceive::getPlantCode, detail.getPlantCode())
                            .eq(WmsDocReceive::getDocNo, detail.getWmsNo())
                            .last("limit 1")
                    );
                    String grNo = StrUtil.EMPTY;
                    if (ObjectUtil.isNotNull(wmsDocReceive)) {
                        grNo = wmsDocReceive.getSapReturnNumber();
                    } else {
                        WmsJusdaReceiptEntity wmsJusdaReceiptEntity = wmsJusdaReceiptMapper.selectOne(Wrappers.<WmsJusdaReceiptEntity>lambdaQuery()
                                .eq(WmsJusdaReceiptEntity::getOrgCode, detail.getOrgCode())
                                .eq(WmsJusdaReceiptEntity::getPlantCode, detail.getPlantCode())
                                .eq(WmsJusdaReceiptEntity::getShipId, detail.getWmsNo())
                                .last("limit 1")
                        );
                        if (ObjectUtil.isNotNull(wmsJusdaReceiptEntity)) {
                            if ("VMI".equals(wmsJusdaReceiptEntity.getReceivedType())) {
                                grNo = wmsJusdaReceiptEntity.getSapReturnNumber();
                            }
                        }
                    }
                    detail.setGrNo(grNo);
                });
            }

            // 工单->特采单体
            Map<String, List<List<WmsDocTcDetail>>> tcDetailMap = tcHeaderList.stream().collect(Collectors.toMap(k -> k.getWorkOrderNo(), v -> ListUtil.toList()));
            // 根据工单+PKG的制造商料号汇总TC单数据
            for (int i = 0; i < tcHeaderList.size(); i++) {
                List<WmsDocTcDetail> wmsDocTcDetailList = tcDetailList.get(i);
                if (CollUtil.isEmpty(wmsDocTcDetailList)) {
                    continue;
                }
                Map<String, List<WmsDocTcDetail>> mfgPartNoTcDetailMap = wmsDocTcDetailList.stream().collect(Collectors.groupingBy(WmsDocTcDetail::getSupplierPartNo));
                for (List<WmsDocTcDetail> mfgTcDetailList : mfgPartNoTcDetailMap.values()) {
                    tcDetailMap.get(tcHeaderList.get(i).getWorkOrderNo()).add(mfgTcDetailList);
                }
            }

            List<WmsDocTcHeader> willInsertTcHeaderList = ListUtil.toList();
            List<WmsDocTcDetail> willInsertTcDetailList = ListUtil.toList();

            for (int i = 0; i < tcHeaderList.size(); i++) {
                WmsDocTcHeader wmsDocRootTcHeader = tcHeaderList.get(i);
                List<List<WmsDocTcDetail>> detailList = tcDetailMap.get(wmsDocRootTcHeader.getWorkOrderNo());
                if (CollUtil.isEmpty(detailList)) {
                    continue;
                }
                List<String> docNoList = ListUtil.toList();
                try {
                    HttpResponse httpResponse = codeRuleService.getSerialNumber("WMS_TC_DOC_NO", detailList.size());
                    String body = httpResponse.body();
                    if (httpResponse.getStatus() == HttpStatus.HTTP_OK) {
                        JSONObject jsonObject = JSONUtil.parseObj(body);
                        String code = jsonObject.getStr("code");
                        if (StringUtils.isNotBlank(code) && "200".equalsIgnoreCase(code)) {
                            List<String> data = (List<String>) jsonObject.getObj("data");
                            docNoList = data;
                        } else {
                            throw new RuntimeException("获取WMSTC单号失败，中断特采单生成");
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    log.error(e.getMessage());
                    continue;
                }

                for (int j = 0; j < detailList.size(); j++) {
                    List<WmsDocTcDetail> wmsDocTcDetailList = detailList.get(j);
                    if (CollUtil.isEmpty(wmsDocTcDetailList)) {
                        continue;
                    }
                    String docNo = docNoList.get(j);
                    WmsDocTcHeader wmsDocTcHeader = new WmsDocTcHeader();
                    BeanUtil.copyProperties(wmsDocRootTcHeader, wmsDocTcHeader);
                    wmsDocTcHeader.setDocNo(docNo);
                    List<GetMaterialPurchaseDTO> purchaseDTOList = basicMaterialMapper.getMaterialPurchase(wmsDocTcHeader.getOrgCode(), wmsDocTcHeader.getPlantCode(), wmsDocTcDetailList.get(0).getPartNo());
                    if (CollUtil.isNotEmpty(purchaseDTOList)) {
                        wmsDocTcHeader.setOriginator(purchaseDTOList.get(0).getPurchaser());
                    }
                    wmsDocTcDetailList.forEach(wmsDocTcDetail -> {
                        wmsDocTcDetail.setDocNo(wmsDocTcHeader.getDocNo());
                    });
                    List<ExpiredPkgInfoExportDTO> list = ListUtil.toList();
                    wmsDocTcDetailList.forEach(item -> {
                        ExpiredPkgInfoExportDTO dto = new ExpiredPkgInfoExportDTO();
                        BeanUtil.copyProperties(item, dto);
                        list.add(dto);
                    });

//                    String supplierPartNo = wmsDocTcDetailList.get(0).getSupplierPartNo();
                    String fileName = "特采PKG明细" + DateUtil.format(new Date(), "yyyy-MM-dd") + ".xlsx";
                    try {
                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                        EasyExcel.write(byteArrayOutputStream, ExpiredPkgInfoExportDTO.class)
                                .sheet(fileName)
                                .registerWriteHandler(new LongestMatchColumnWidthStyleStrategy())
                                .registerWriteHandler(new FreezeAndFilterHandler())
                                .doWrite(list);
                        WmsFileDownloadLog wmsFileDownloadLog = wmsFileDownloadLogService.uploadFile(orgCode, "SPECIAL_PKG_INFO_LIST", fileName, "WMS_JOB", byteArrayOutputStream.toByteArray());
                        wmsDocTcHeader.setFileName(fileName);
                        wmsDocTcHeader.setFileUrl(downloadUrl + "?id=" + wmsFileDownloadLog.getId());
                    } catch (Exception e) {
                        e.printStackTrace();
                        log.error(e.getMessage());
                        continue;
                    }
                    willInsertTcHeaderList.add(wmsDocTcHeader);
                    willInsertTcDetailList.addAll(wmsDocTcDetailList);
                }
            }
            wmsDocTcHeaderService.saveBatch(willInsertTcHeaderList, 500);
            wmsDocTcDetailService.saveBatch(willInsertTcDetailList, 500);
            wmsWorkOrderDetailShortageHeaderMapper.update(null, Wrappers.<WmsWorkOrderDetailShortageHeader>lambdaUpdate()
                    .set(WmsWorkOrderDetailShortageHeader::getTcStatus, "1")
                    .eq(WmsWorkOrderDetailShortageHeader::getId, wmsMaterialShortageHeader.getId())
            );
        }

    }

    @Override
    public void postTcDoc(String orgCode) {
        LocalDateTime startDateTime = LocalDateTime.now();
        List<SysDict> dictDepartMentList = sysDictMapper.selectDictList("WMS_DOC_TC_DEPARTMENT");
        Map<String, String> dictDepartMentMap = dictDepartMentList.stream()
                .collect(Collectors.toMap(k -> k.getDictCode(), v -> v.getDictName()));
        while (true) {
            if (Constants.continueJob.equalsIgnoreCase("N")) {
                return;
            }
            try {
                // 延迟3秒，减少操作数据库频率
                Thread.sleep(3000);
            } catch (Exception e) {
                e.printStackTrace();
            }

            LocalDateTime now = LocalDateTime.now();
            // 执行时长超过25分钟，强行终止。
            long hours = LocalDateTimeUtil.between(startDateTime, now).toMinutes();
            if (hours > 25) {
                break;
            }

            WmsDocTcHeader wmsDocTcHeader = wmsDocTcHeaderMapper.selectOne(Wrappers.<WmsDocTcHeader>lambdaQuery()
                    .eq(WmsDocTcHeader::getOrgCode, orgCode)
                    .eq(WmsDocTcHeader::getIdentify, "0")
                    .orderByAsc(WmsDocTcHeader::getId)
                    .last("limit 1")
            );
            if (ObjectUtil.isNull(wmsDocTcHeader)) {
                break;
            }
            wmsDocTcHeaderMapper.update(null, Wrappers.<WmsDocTcHeader>lambdaUpdate()
                    .set(WmsDocTcHeader::getIdentify, "4")
                    .eq(WmsDocTcHeader::getId, wmsDocTcHeader.getId())
            );

            List<WmsDocTcDetail> wmsDocTcDetailList = wmsDocTcDetailMapper.selectList(Wrappers.<WmsDocTcDetail>lambdaQuery()
                    .eq(WmsDocTcDetail::getOrgCode, orgCode)
                    .eq(WmsDocTcDetail::getDocNo, wmsDocTcHeader.getDocNo())
            );

            String partName = wmsDocTcDetailList.stream()
                    .map(item -> item.getClassCode()).distinct()
                    .collect(Collectors.joining(";"));

//            String GRNNo = wmsDocTcDetailList.stream()
//                    .map(item -> item.getGrNo())
//                    .distinct()
//                    .collect(Collectors.joining(";"));
            // Agile 不能增加GR栏位长度，就取一个GR抛转
            String GRNNo = wmsDocTcDetailList.stream()
                    .map(WmsDocTcDetail::getGrNo)
                    .filter(StrUtil::isNotBlank)
                    .findFirst().orElse(StrUtil.EMPTY);

            BigDecimal qty = wmsDocTcDetailList.stream().map(item -> item.getQty()).reduce(BigDecimal.ZERO, BigDecimal::add);
            String venderNumber = wmsDocTcDetailList.stream().map(item -> item.getSupplierPartNo())
                    .distinct().collect(Collectors.joining(";"));
            String vender = wmsDocTcDetailList.stream().map(item -> item.getMfgName())
                    .distinct().collect(Collectors.joining(";"));
            String HHPN = wmsDocTcDetailList.stream().map(item -> item.getPartNo())
                    .distinct().collect(Collectors.joining(";"));

            LocalDateTime createdDt = wmsDocTcHeader.getCreatedDt();
            LocalDateTime tcExpirationDate = wmsDocTcHeader.getTcExpirationDate();
            ZoneOffset currentZoneOffset = OffsetDateTime.now().getOffset();
            ZoneId targetZoneOffset = ZoneId.ofOffset("UTC", ZoneOffset.of("-06:00"));
            LocalDateTime targetCreatedDt = createdDt.atZone(currentZoneOffset).withZoneSameInstant(targetZoneOffset).toLocalDateTime();
            LocalDateTime targetTcExpirationDate = tcExpirationDate.atZone(currentZoneOffset).withZoneSameInstant(targetZoneOffset).toLocalDateTime();

            RequestAgileTcVO vo = new RequestAgileTcVO();
            vo.setDescription("D/C 過期");
            vo.setProductLine(orgCode);
//                vo.setOriginator(wmsDocTcHeader.getOperator());
            vo.setOriginator(wmsDocTcHeader.getOriginator());
            vo.setApplicationDepartment(dictDepartMentMap.get(orgCode));
            vo.setGRNNo(StrUtil.isNotBlank(GRNNo) ? GRNNo : "无");
            vo.setPartName(partName);
            vo.setQty(qty.toBigInteger().toString());
            vo.setVenderNumber(venderNumber);
            vo.setVender(vender);
            vo.setHHPN(HHPN);
            vo.setUsedClient(wmsDocTcHeader.getCustomer());
            vo.setMaterialType("OTHERS");
            vo.setOEMCase("NO");
            vo.setFitProduction(wmsDocTcHeader.getFinishPartNo());
            vo.setApplicantDeductionForecast("NO");
            vo.setLastAbnormDes("無");
            vo.setBadType("ELE|RAW_MATERIAL|D_C_EXPIRED");
            vo.setWaiveContent("物料延期（明细见附件）");
            vo.setWaiveReason("上線使用");
            vo.setTCStartDate(targetCreatedDt.format(DateTimeFormatter.ofPattern("MM/dd/yyyy hh:mm:ss a 'CST'", Locale.US)));
            vo.setTCExpirationDate(targetTcExpirationDate.format(DateTimeFormatter.ofPattern("MM/dd/yyyy hh:mm:ss a 'CST'", Locale.US)));
            vo.setCorrectAction("反馈供应商和客户");
            vo.setFinishDate(targetTcExpirationDate.format(DateTimeFormatter.ofPattern("MM/dd/yyyy hh:mm:ss a 'CST'", Locale.US)));
            vo.setWithinThreeYears(wmsDocTcHeader.getWithinThreeYears());
            RequestAgileTcFileVO fileVO = new RequestAgileTcFileVO();
            fileVO.setName(wmsDocTcHeader.getFileName());
            fileVO.setPath(wmsDocTcHeader.getFileUrl());
            vo.setFiles(ListUtil.toList(fileVO));
            HttpResponse httpResponse = requestAgileTc(vo);
            String body = httpResponse.body();

            if (httpResponse.getStatus() == HttpStatus.HTTP_OK) {
                ResponseAgileTcDTO responseAgileTcDTO = JSON.parseObject(body, ResponseAgileTcDTO.class);
                // 防止插入特殊字符报错
                String resMsg = StrUtil.isNotBlank(responseAgileTcDTO.getMsg()) ? responseAgileTcDTO.getMsg() : StrUtil.EMPTY;
                resMsg = StrUtil.replace(resMsg, "\u0000", "");
                if ("success".equals(responseAgileTcDTO.getResult())) {
                    wmsDocTcHeaderMapper.update(null, Wrappers.<WmsDocTcHeader>lambdaUpdate()
                            .set(WmsDocTcHeader::getIdentify, "2")
                            .set(WmsDocTcHeader::getPostMessage, JSONUtil.toJsonStr(vo))
                            .set(WmsDocTcHeader::getActualDocNo, responseAgileTcDTO.getNumber())
                            .set(WmsDocTcHeader::getPostReturnMessage, resMsg)
                            .set(WmsDocTcHeader::getPostDt, LocalDateTime.now())
                            .eq(WmsDocTcHeader::getId, wmsDocTcHeader.getId())
                    );
                } else {
                    wmsDocTcHeaderMapper.update(null, Wrappers.<WmsDocTcHeader>lambdaUpdate()
                            .set(WmsDocTcHeader::getIdentify, "3")
                            .set(WmsDocTcHeader::getPostMessage, JSONUtil.toJsonStr(vo))
                            .set(WmsDocTcHeader::getPostReturnMessage, resMsg)
                            .set(WmsDocTcHeader::getPostDt, LocalDateTime.now())
                            .eq(WmsDocTcHeader::getId, wmsDocTcHeader.getId())
                    );
                }
            } else {
                log.error(httpResponse.body());
                wmsDocTcHeaderMapper.update(null, Wrappers.<WmsDocTcHeader>lambdaUpdate()
                        .set(WmsDocTcHeader::getIdentify, "3")
                        .set(WmsDocTcHeader::getPostMessage, JSONUtil.toJsonStr(vo))
                        .set(WmsDocTcHeader::getPostReturnMessage, StrUtil.concat(true, Integer.toString(httpResponse.getStatus()), httpResponse.body()))
                        .set(WmsDocTcHeader::getPostDt, LocalDateTime.now())
                        .eq(WmsDocTcHeader::getId, wmsDocTcHeader.getId())
                );
            }

        }
    }


    @Override
    public void materialMfgSyncFromQms(List<SyncQmsValidVO> syncQmsValidVOList) {
        List<WmsSyncMfgMaterialFromQmsLog> wmsSyncMfgMaterialFromQmsLogList = CollUtil.newArrayList();
        for (SyncQmsValidVO syncQmsValidVO : syncQmsValidVOList) {
            WmsSyncMfgMaterialFromQmsLog wmsSyncMfgMaterialFromQmsLog = new WmsSyncMfgMaterialFromQmsLog();
            BeanUtils.copyProperties(syncQmsValidVO, wmsSyncMfgMaterialFromQmsLog);
            wmsSyncMfgMaterialFromQmsLog.setCreator("syncadmin");
            wmsSyncMfgMaterialFromQmsLog.setCreatedDt(LocalDateTime.now());
            wmsSyncMfgMaterialFromQmsLogList.add(wmsSyncMfgMaterialFromQmsLog);
            String mfg = syncQmsValidVO.getMfg();
            String mfgMaterialNo = syncQmsValidVO.getMfgMaterialNo();
            String orgCode = syncQmsValidVO.getOrgCode();
            String deadline = syncQmsValidVO.getDeadline();
            //更新pkg_info
            List<WmsPkgInfo> wmsPkgInfoList = wmsPkgInfoMapper.selectList(Wrappers.<WmsPkgInfo>lambdaQuery()
                    .eq(WmsPkgInfo::getOrgCode, orgCode)
                    .eq(WmsPkgInfo::getMfgName, mfg)
                    .eq(WmsPkgInfo::getSupplierPartNo, mfgMaterialNo)
                    .gt(WmsPkgInfo::getCurrentQty, BigDecimal.ZERO));
            List<WmsPkgInfoLog> wmsPkgInfoLogList = CollUtil.newArrayList();
            for (WmsPkgInfo wmsPkgInfo : wmsPkgInfoList) {
                Integer id = wmsPkgInfo.getId();
                LocalDate dateCode = wmsPkgInfo.getDateCode();
                LocalDate endDate = wmsPkgInfo.getEndDate();
                LocalDate calculateEndDate = dateCode.plusDays(Long.parseLong(deadline));
                String lockStatus = wmsPkgInfo.getLockStatus();
                WmsPkgInfoLog wmsPkgInfoLog = new WmsPkgInfoLog();
                BeanUtils.copyProperties(wmsPkgInfo, wmsPkgInfoLog);
                wmsPkgInfoLog.setId(null);
                wmsPkgInfoLog.setTransactionType("QMS_UPDATE_VALID_DATE");
                wmsPkgInfoLog.setTransactionMessage("qms更新有效期");
                wmsPkgInfoLog.setLockMessage(StrUtil.EMPTY);
                wmsPkgInfoLog.setCreator("syncadmin");
                wmsPkgInfoLog.setCreatedDt(LocalDateTime.now());
                wmsPkgInfoLog.setLastEditor("syncadmin");
                wmsPkgInfoLog.setLastEditedDt(LocalDateTime.now());
                if (calculateEndDate.isAfter(endDate)) {
                    //当前日期加延迟天数
                    LocalDate localDate = LocalDate.now().plusDays(Long.parseLong(globalCommonConfig.getDelayDay()));
                    baseMapper.update(null, Wrappers.<WmsPkgInfo>lambdaUpdate()
                            .eq(WmsPkgInfo::getId, id)
                            .set(WmsPkgInfo::getEndDate, calculateEndDate)
                            .set("3".equals(lockStatus) && calculateEndDate.isAfter(localDate),
                                    WmsPkgInfo::getLockStatus, "0"));
                    wmsPkgInfoLog.setEndDate(calculateEndDate);
                }
                wmsPkgInfoLogList.add(wmsPkgInfoLog);
            }
            //增加条码履历
            wmsPkgInfoLogService.saveBatch(wmsPkgInfoLogList);
            //更新pick_log
            List<WmsWorkOrderPickLog> wmsWorkOrderPickLogList = wmsWorkOrderPickLogMapper
                    .selectList(Wrappers.<WmsWorkOrderPickLog>lambdaQuery()
                            .eq(WmsWorkOrderPickLog::getOrgCode, orgCode)
                            .eq(WmsWorkOrderPickLog::getMfgName, mfg)
                            .eq(WmsWorkOrderPickLog::getSupplierPartNo, mfgMaterialNo)
                            .gt(WmsWorkOrderPickLog::getCurrentQty, BigDecimal.ZERO));
            for (WmsWorkOrderPickLog wmsWorkOrderPickLog : wmsWorkOrderPickLogList) {
                Integer id = wmsWorkOrderPickLog.getId();
                LocalDate dateCode = wmsWorkOrderPickLog.getDateCode();
                LocalDate endDate = wmsWorkOrderPickLog.getEndDate();
                //若计算后的endDate大于原来的日期,则更新截止日期
                LocalDate calculateEndDate = dateCode.plusDays(Long.parseLong(deadline));
                if (calculateEndDate.isAfter(endDate)) {
                    wmsWorkOrderPickLogMapper.update(null, Wrappers.<WmsWorkOrderPickLog>lambdaUpdate()
                            .eq(WmsWorkOrderPickLog::getId, id)
                            .set(WmsWorkOrderPickLog::getEndDate, calculateEndDate));
                }
            }
           /* wmsPkgInfoMapper.updatePkgEndDate(orgCode,mfg,mfgMaterialNo,new BigDecimal(deadline));
            wmsWorkOrderPickLogMapper.updatePkgEndDate(orgCode,mfg,mfgMaterialNo,new BigDecimal(deadline));*/
        }
        wmsSyncMfgMaterialFromQmsLogService.saveBatch(wmsSyncMfgMaterialFromQmsLogList);
    }

    @Override
    public void materialMfgLevel(List<SyncQmsMsdLevelVO> syncQmsMsdLevelVOList) {
        List<WmsSyncMsdLevelFromQmsLog> wmsSyncMsdLevelFromQmsLogList = CollUtil.newArrayList();
        syncQmsMsdLevelVOList = syncQmsMsdLevelVOList.stream()
                .filter(syncQmsMsdLevelVO -> !StrUtil.equals("N/A", syncQmsMsdLevelVO.getMsdLevel())
                        && !StrUtil.equals("0", syncQmsMsdLevelVO.getMsdLevel())).collect(Collectors.toList());
        for (SyncQmsMsdLevelVO syncQmsMsdLevelVO : syncQmsMsdLevelVOList) {
            WmsSyncMsdLevelFromQmsLog wmsSyncMsdLevelFromQmsLog = new WmsSyncMsdLevelFromQmsLog();
            BeanUtils.copyProperties(syncQmsMsdLevelVO, wmsSyncMsdLevelFromQmsLog);
            wmsSyncMsdLevelFromQmsLog.setCreator("syncadmin");
            wmsSyncMsdLevelFromQmsLog.setCreatedDt(LocalDateTime.now());
            wmsSyncMsdLevelFromQmsLogList.add(wmsSyncMsdLevelFromQmsLog);
            String mfgName = syncQmsMsdLevelVO.getMfg();
            String mfgMaterialCode = syncQmsMsdLevelVO.getMfgMaterialCode();
            String orgCode = syncQmsMsdLevelVO.getOrgCode();
            //更新pkg_info
            wmsPkgInfoMapper.update(null, Wrappers.<WmsPkgInfo>lambdaUpdate()
                    .eq(WmsPkgInfo::getOrgCode, orgCode)
                    .eq(WmsPkgInfo::getMfgName, mfgName)
                    .eq(WmsPkgInfo::getSupplierPartNo, mfgMaterialCode)
                    .eq(WmsPkgInfo::getPostMsdFlag, 3)
                    .set(WmsPkgInfo::getPostMsdFlag, 0));
            //更新pick_log
            wmsWorkOrderPickLogMapper.update(null, Wrappers.<WmsWorkOrderPickLog>lambdaUpdate()
                    .eq(WmsWorkOrderPickLog::getOrgCode, orgCode)
                    .eq(WmsWorkOrderPickLog::getMfgName, mfgName)
                    .eq(WmsWorkOrderPickLog::getSupplierPartNo, mfgMaterialCode)
                    .eq(WmsWorkOrderPickLog::getPostMsdFlag, 3)
                    .set(WmsWorkOrderPickLog::getPostMsdFlag, 0));
        }
        wmsSyncMsdLevelFromQmsLogService.saveBatch(wmsSyncMsdLevelFromQmsLogList);
    }

    private HttpResponse requestAgileTc(RequestAgileTcVO vo) {
        String url = agileTcConfig.getAgileTcUrl();
        log.info("requestAgileTc {}", JSONUtil.toJsonStr(vo));
        // System.out.println(StrUtil.replace(JSON.toJSONString(vo), "\u0000", "[?]"));
        // log.info("fastJson是否存在empty str {}", StrUtil.contains(JSON.toJSONString(vo), "\u0000"));
        // log.info("hutool是否存在empty str {}", StrUtil.contains(JSONUtil.toJsonStr(vo), "\u0000"));
        HttpResponse response = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(30 * 1000)
                .body(JSON.toJSONString(vo))
                .execute();
        return response;
    }

}
