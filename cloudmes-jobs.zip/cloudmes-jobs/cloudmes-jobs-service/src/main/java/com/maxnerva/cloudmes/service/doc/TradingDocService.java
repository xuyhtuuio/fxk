package com.maxnerva.cloudmes.service.doc;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpStatus;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.entity.WmsSapPlant;
import com.maxnerva.cloudmes.entity.doc.*;
import com.maxnerva.cloudmes.entity.jusda.WmsJusdaReceiptEntity;
import com.maxnerva.cloudmes.entity.trading.WmsTradingConfig;
import com.maxnerva.cloudmes.mapper.WmsSapPlantMapper;
import com.maxnerva.cloudmes.mapper.doc.*;
import com.maxnerva.cloudmes.mapper.jusda.WmsJusdaReceiptMapper;
import com.maxnerva.cloudmes.mapper.trading.WmsTradingConfigMapper;
import com.maxnerva.cloudmes.service.basic.CodeRuleService;
import com.maxnerva.cloudmes.service.sap.doc.DocRfcService;
import com.maxnerva.cloudmes.service.sap.doc.model.JitReceiptDto;
import com.maxnerva.cloudmes.service.sap.gr.GrRfcService;
import com.maxnerva.cloudmes.service.sap.gr.model.GrInfoDto;
import com.maxnerva.cloudmes.service.sap.po.PoRfcService;
import com.maxnerva.cloudmes.service.sap.po.model.MfrInfoDto;
import com.maxnerva.cloudmes.service.sap.po.model.PoItemInfoDto;
import com.sap.conn.jco.JCoException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static java.time.format.DateTimeFormatter.BASIC_ISO_DATE;

/**
 * @ClassName TradingDocService
 * @Description 内交单service
 * @Author Likun
 * @Date 2023/2/6
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Service
@Slf4j
public class TradingDocService {

    @Autowired
    private GrRfcService grRfcService;

    @Autowired
    private WmsTradingConfigMapper wmsTradingConfigMapper;

    @Autowired
    private WmsTradingDocImportRecordMapper wmsTradingDocImportRecordMapper;

    @Autowired
    private WmsDocTypeMapper wmsDocTypeMapper;

    @Autowired
    private WmsDocReceiveMapper wmsDocReceiveMapper;

    @Autowired
    private CodeRuleService codeRuleService;

    @Autowired
    private WmsSapPlantMapper wmsSapPlantMapper;

    @Autowired
    private PoRfcService poRfcService;

    @Autowired
    private WmsReceiveVendorCodeConfigMapper wmsReceiveVendorCodeConfigMapper;

    @Autowired
    private DocRfcService docRfcService;

    @Resource
    private WmsJusdaTradingDocImportRecordMapper wmsJusdaTradingDocImportRecordMapper;

    @Resource
    private WmsJusdaReceiptMapper wmsJusdaReceiptMapper;

    public void syncTradingDoc(String sapClientCode, String orgCode, String startDate, String endDate) {
        List<WmsTradingConfig> wmsTradingConfigList = wmsTradingConfigMapper
                .selectList(Wrappers.<WmsTradingConfig>lambdaQuery()
                        .eq(WmsTradingConfig::getFromOrgCode, orgCode));
        List<String> tradingToCodeList = wmsTradingConfigList.stream()
//                .filter(c -> !"BK1058TJ01".equals(c.getTradingToCode()))
                .map(WmsTradingConfig::getTradingToCode).collect(Collectors.toList());
        List<GrInfoDto> grInfoDtos = CollUtil.newArrayList();
        List<GrInfoDto> grInfoDtoLists = CollUtil.newArrayList();
        List<WmsSapPlant> wmsSapPlantList = wmsSapPlantMapper.selectList(Wrappers.<WmsSapPlant>lambdaQuery()
                .eq(WmsSapPlant::getOrgCode, orgCode));
        try {
            for (WmsSapPlant wmsSapPlant : wmsSapPlantList) {
                grInfoDtoLists = grRfcService.doGetGrInfo(sapClientCode, wmsSapPlant.getFactoryCode(), "CN09", startDate, endDate);
                grInfoDtos.addAll(grInfoDtoLists);
            }
        } catch (JCoException e) {
            log.error("doGetGrInfo error : {}", e.getMessage());
        }
        List<GrInfoDto> infoDtoList = grInfoDtos.stream().filter(a -> tradingToCodeList.contains(a.getTradingCode())).collect(Collectors.toList());
        //根据poNumber分组数据
        Map<String, List<GrInfoDto>> collect = infoDtoList.stream().collect(Collectors.groupingBy(GrInfoDto::getPoNumber));
        for (Map.Entry<String, List<GrInfoDto>> entry : collect.entrySet()) {
            //poNumber
            String poNumber = entry.getKey();
            //查询po信息
            List<PoItemInfoDto> poItemInfoDtoList = CollUtil.newArrayList();
            try {
                poItemInfoDtoList = poRfcService.doGetPoInfo(sapClientCode, poNumber, "x", "x");
            } catch (JCoException e) {
                log.error("doGetPoInfo error : {}", e.getMessage());
            }
            List<GrInfoDto> grInfoDtoList = entry.getValue();
            for (GrInfoDto grInfoDto : grInfoDtoList) {
                String grNumber = grInfoDto.getGrNumber();
                String returnGrNumber = grInfoDto.getReturnGrNumber();
                WmsTradingDocImportRecord wmsTradingDocImportRecord = new WmsTradingDocImportRecord();
                wmsTradingDocImportRecord.setOrgCode(orgCode);
                wmsTradingDocImportRecord.setPlantCode(grInfoDto.getPlantCode());
                wmsTradingDocImportRecord.setGrNumber(grNumber);
                wmsTradingDocImportRecord.setGrItem(grInfoDto.getGrItem());
                wmsTradingDocImportRecord.setTradingCode(grInfoDto.getTradingCode());
                WmsTradingConfig tradingConfig = wmsTradingConfigList.stream().filter(wmsTradingConfig -> grInfoDto.getTradingCode()
                                .equals(wmsTradingConfig.getTradingToCode()) && orgCode.equals(wmsTradingConfig.getFromOrgCode()))
                        .findFirst().orElse(null);
                assert tradingConfig != null;
                wmsTradingDocImportRecord.setTradingToOrgCode(tradingConfig.getTradingToOrgCode());
                wmsTradingDocImportRecord.setPartNo(grInfoDto.getPartNo());
                wmsTradingDocImportRecord.setPartDesc(grInfoDto.getPartDesc());
                wmsTradingDocImportRecord.setQty(grInfoDto.getQty());
                wmsTradingDocImportRecord.setPoNo(grInfoDto.getPoNumber());
                wmsTradingDocImportRecord.setPoItem(grInfoDto.getPoItem());
                wmsTradingDocImportRecord.setUomCode(grInfoDto.getBom());
                wmsTradingDocImportRecord.setWarehouseCode(grInfoDto.getWarehouseCode());
                //GrNumber和ReturnGrNumber不一致则返掉ReturnGrNumber的内交入收货单且不产生内交入收货单
                if (StringUtils.isEmpty(grNumber) || StringUtils.isEmpty(returnGrNumber)) {
                    wmsTradingDocImportRecord.setDocCreateMsg("grNumber或者returnGrNumber为空");
                } else {
                    if (!grInfoDto.getGrNumber().equals(grInfoDto.getReturnGrNumber())) {
                        //设置错误信息，避免生成收货单
                        wmsTradingDocImportRecord.setDocCreateMsg("返单");
                    }
                }
                wmsTradingDocImportRecord.setDocCreateFlag("N");
                wmsTradingDocImportRecord.setPlaceOfOrigin("CN");
                wmsTradingDocImportRecord.setCreatedDt(LocalDateTime.now());
                wmsTradingDocImportRecord.setCreator("sysadmin");
                wmsTradingDocImportRecord.setLastEditor("sysadmin");
                wmsTradingDocImportRecord.setLastEditedDt(LocalDateTime.now());
                wmsTradingDocImportRecord.setReturnGrNumber(returnGrNumber);
                String docCreateMsg = StrUtil.EMPTY;
                wmsTradingDocImportRecordMapper.insertTradingDocImportRecord(wmsTradingDocImportRecord);
                WmsTradingDocImportRecord wmsTradingDocImportRecordDb = wmsTradingDocImportRecordMapper.selectOne(Wrappers.<WmsTradingDocImportRecord>lambdaQuery()
                        .eq(WmsTradingDocImportRecord::getOrgCode, wmsTradingDocImportRecord.getOrgCode())
                        .eq(WmsTradingDocImportRecord::getPlantCode, wmsTradingDocImportRecord.getPlantCode())
                        .eq(WmsTradingDocImportRecord::getGrNumber, wmsTradingDocImportRecord.getGrNumber())
                        .eq(WmsTradingDocImportRecord::getGrItem, wmsTradingDocImportRecord.getGrItem())
                        .last("limit 1"));
                if ("Y".equals(wmsTradingDocImportRecordDb.getDocCreateFlag())) {
                    continue;
                }
                PoItemInfoDto itemInfoDto = poItemInfoDtoList.stream()
                        .filter(poItemInfoDto -> grInfoDto.getPoItem().equals(poItemInfoDto.getPoItem()))
                        .findFirst().orElse(null);
                if (ObjectUtil.isNotNull(itemInfoDto)) {
                    wmsTradingDocImportRecordDb.setPartVersion(itemInfoDto.getPartVersion());
                    wmsTradingDocImportRecordDb.setPoDocumentType(itemInfoDto.getDocType());
                    wmsTradingDocImportRecordDb.setPurchaseGroup(itemInfoDto.getPurchaseGroup());
                    wmsTradingDocImportRecordDb.setPurchaseOrg(itemInfoDto.getPurchaseOrg());
                    wmsTradingDocImportRecordDb.setMfgCode(itemInfoDto.getMfrCode());
                    wmsTradingDocImportRecordDb.setMfgPartNo(itemInfoDto.getMfrPartNo());
                    MfrInfoDto mfrInfoDto = null;
                    try {
                        mfrInfoDto = poRfcService.doGetMfrNameByCode(sapClientCode, itemInfoDto.getMfrCode());
                    } catch (JCoException e) {
                        log.error("doGetMfrNameByCode error : {}", e.getMessage());
                    }
                    if (ObjectUtil.isNull(mfrInfoDto) || StrUtil.isEmpty(mfrInfoDto.getMfrName())) {
                        docCreateMsg = docCreateMsg + "未找到mfrCode:" + itemInfoDto.getMfrCode() + "的制造商名称信息";
                    } else {
                        wmsTradingDocImportRecordDb.setMfgName(mfrInfoDto.getMfrName());
                    }
                } else {
                    docCreateMsg = docCreateMsg + "poNumber:" + poNumber + "poItem:" + grInfoDto.getPoItem() + "不存在";
                }
                if (StrUtil.isNotEmpty(docCreateMsg)) {
                    wmsTradingDocImportRecordDb.setDocCreateMsg(docCreateMsg);
                }
                wmsTradingDocImportRecordMapper.updateById(wmsTradingDocImportRecordDb);
            }
        }
        //查询导入记录中未建单成功并且没有错误信息的记录,准备新增内交入收货单
        List<WmsTradingDocImportRecord> tradingDocImportRecordList = wmsTradingDocImportRecordMapper.selectList(Wrappers.<WmsTradingDocImportRecord>lambdaQuery()
                .eq(WmsTradingDocImportRecord::getDocCreateFlag, "N")
                .isNull(WmsTradingDocImportRecord::getDocCreateMsg));
        for (WmsTradingDocImportRecord wmsTradingDocImportRecord : tradingDocImportRecordList) {
            Long count = wmsDocReceiveMapper.selectCount(Wrappers.<WmsDocReceive>lambdaQuery()
                    .eq(WmsDocReceive::getSapReturnNumber, wmsTradingDocImportRecord.getGrNumber()));
            if (count > 0) {
                wmsTradingDocImportRecord.setDocCreateMsg("内交单号已在WMS收货单中存在");
                wmsTradingDocImportRecord.setDocCreateFlag("N");
                wmsTradingDocImportRecordMapper.updateById(wmsTradingDocImportRecord);
                continue;
            }
            //新增内交入收货单
            WmsDocReceive wmsDocReceive = new WmsDocReceive();
            BeanUtils.copyProperties(wmsTradingDocImportRecord, wmsDocReceive);
            wmsDocReceive.setId(null);
            WmsDocType wmsDocTypeDb = wmsDocTypeMapper.selectOne(Wrappers.<WmsDocType>lambdaQuery()
                    .eq(WmsDocType::getDocTypeCode, "INNERRING_RECEIVE_DOC"));
            wmsDocReceive.setDocTypeCode("INNERRING_RECEIVE_DOC");
            wmsDocReceive.setSapWarehouseCode(wmsTradingDocImportRecord.getWarehouseCode());
            wmsDocReceive.setConfirmReceiptFlag(1);
            wmsDocReceive.setConfirmDocDate(LocalDateTime.now());
            wmsDocReceive.setDocQty(wmsTradingDocImportRecord.getQty());
            wmsDocReceive.setConfirmQty(wmsTradingDocImportRecord.getQty());
            wmsDocReceive.setWmsDocTypeId(wmsDocTypeDb.getId());
            wmsDocReceive.setDocCategoryCode(wmsDocTypeDb.getDocCategoryCode());
            wmsDocReceive.setDocCreateDate(LocalDate.now());
            wmsDocReceive.setPostingMethodName(wmsDocTypeDb.getPostingMethodName());
            wmsDocReceive.setPostingSapMethodFlag(wmsDocTypeDb.getPostingSapFlag());
            wmsDocReceive.setDocTypeName(wmsDocTypeDb.getDocTypeName());
            wmsDocReceive.setPostingQmsFlag(wmsDocTypeDb.getPostingQmsFlag());
            wmsDocReceive.setDocStatus("RECEIVED_COMPLETED");
            wmsDocReceive.setSapReturnMessage("OK");
            wmsDocReceive.setSapReturnNumber(wmsTradingDocImportRecord.getGrNumber());
            wmsDocReceive.setPlaceOfOrigin1("CN");
            wmsDocReceive.setWmsContent(JSONUtil.toJsonStr(wmsDocReceive));
            wmsDocReceive.setInspectResult("Y");
            String docNo = StrUtil.EMPTY;
            HttpResponse httpResponse = codeRuleService.getCodeRule(orgCode);
            String body = httpResponse.body();
            if (httpResponse.getStatus() == HttpStatus.HTTP_OK) {
                JSONObject jsonObject = JSONUtil.parseObj(body);
                String code = jsonObject.getStr("code");
                if (StringUtils.isNotBlank(code) && "200".equalsIgnoreCase(code)) {
                    List<String> data = (List<String>) jsonObject.getObj("data");
                    docNo = data.get(0);
                }
            }
            if (StrUtil.isEmpty(docNo)) {
                wmsTradingDocImportRecord.setDocCreateMsg("生成内交单号异常");
                wmsTradingDocImportRecord.setDocCreateFlag("N");
                wmsTradingDocImportRecordMapper.updateById(wmsTradingDocImportRecord);
                continue;
            } else {
                wmsTradingDocImportRecord.setDocCreateFlag("Y");
                wmsTradingDocImportRecordMapper.updateById(wmsTradingDocImportRecord);
            }
            wmsDocReceive.setDocNo(docNo);
            wmsDocReceiveMapper.insert(wmsDocReceive);
        }
        //筛选出grNumber和returnGrNumber不同的,执行返单
        List<GrInfoDto> newInfoDtoList = infoDtoList.stream().filter(a -> !a.getGrNumber().equals(a.getReturnGrNumber())).collect(Collectors.toList());
        for (GrInfoDto grInfoDto : newInfoDtoList) {
            wmsDocReceiveMapper.update(null, Wrappers.<WmsDocReceive>lambdaUpdate()
                    .eq(WmsDocReceive::getOrgCode, orgCode)
                    .eq(WmsDocReceive::getPlantCode, grInfoDto.getPlantCode())
                    .eq(WmsDocReceive::getSapReturnNumber, grInfoDto.getReturnGrNumber())
                    .eq(WmsDocReceive::getDocTypeCode, "INNERRING_RECEIVE_DOC")
                    .set(WmsDocReceive::getSapReturnNumber, grInfoDto.getReturnGrNumber() + "_" + grInfoDto.getGrNumber())
                    .set(WmsDocReceive::getDocStatus, "SHELF_COMPLETED"));
        }
    }

    public void outsourcingReceive(String sapClientCode, String orgCode, String startDate, String endDate) {
        List<WmsReceiveVendorCodeConfig> vendorCodeConfigList = wmsReceiveVendorCodeConfigMapper
                .selectList(Wrappers.<WmsReceiveVendorCodeConfig>lambdaQuery()
                        .eq(WmsReceiveVendorCodeConfig::getOrgCode, orgCode));
        //委外收货单LIST
        List<GrInfoDto> grInfoDtos = CollUtil.newArrayList();
        List<WmsSapPlant> wmsSapPlantList = wmsSapPlantMapper.selectList(Wrappers.<WmsSapPlant>lambdaQuery()
                .eq(WmsSapPlant::getOrgCode, orgCode));
        try {
            for (WmsSapPlant wmsSapPlant : wmsSapPlantList) {
                List<GrInfoDto> grInfoDtoLists = grRfcService.doGetGrInfo(sapClientCode, wmsSapPlant.getFactoryCode(), "CN09", startDate, endDate);
                grInfoDtos.addAll(grInfoDtoLists);
            }
        } catch (JCoException e) {
            log.error("doGetGrInfo error : {}", e.getMessage());
        }
        //保存委外收货单
        List<String> outVendorCodeList = vendorCodeConfigList.stream()
                .filter(v -> "OUTSOURCING_DOC".equals(v.getReceiveTypeCode()))
                .map(WmsReceiveVendorCodeConfig::getVendorCode)
                .collect(Collectors.toList());
        List<GrInfoDto> outInfoDtoList = grInfoDtos.stream().filter(a ->
                outVendorCodeList.contains(a.getTradingCode())).collect(Collectors.toList());
        for (GrInfoDto outInfoDto : outInfoDtoList) {
            Long count = wmsDocReceiveMapper.selectCount(Wrappers.<WmsDocReceive>lambdaQuery()
                    .eq(WmsDocReceive::getSapReturnNumber, outInfoDto.getGrNumber()));
            if (count > 0) {
                continue;
            }
            WmsReceiveVendorCodeConfig vendorCodeConfig = vendorCodeConfigList.stream()
                    .filter(v -> outInfoDto.getTradingCode().equals(v.getVendorCode())).findFirst().orElse(null);
            insertWmsDocReceive(orgCode, outInfoDto, vendorCodeConfig.getVendorName());
        }
    }

    private void insertWmsDocReceive(String orgCode, GrInfoDto grInfoDto, String placeOfOrigin1) {
        String docType = "OUTSOURCING_DOC";
        WmsDocReceive wmsDocReceive = new WmsDocReceive();
        wmsDocReceive.setId(null);
        WmsDocType wmsDocTypeDb = wmsDocTypeMapper.selectOne(Wrappers.<WmsDocType>lambdaQuery()
                .eq(WmsDocType::getDocTypeCode, docType));
        wmsDocReceive.setOrgCode(orgCode);
        wmsDocReceive.setDocCreateDate(LocalDate.now());
        wmsDocReceive.setDocStatus("SHELF_COMPLETED");
        wmsDocReceive.setWmsDocTypeId(wmsDocTypeDb.getId());
        wmsDocReceive.setDocTypeName(wmsDocTypeDb.getDocTypeName());
        wmsDocReceive.setDocTypeCode(docType);
        wmsDocReceive.setDocCategoryCode(wmsDocTypeDb.getDocCategoryCode());
        wmsDocReceive.setPostingMethodName(wmsDocTypeDb.getPostingMethodName());
        wmsDocReceive.setPostingSapMethodFlag(wmsDocTypeDb.getPostingSapFlag());
        wmsDocReceive.setPostingQmsFlag(wmsDocTypeDb.getPostingQmsFlag());
        wmsDocReceive.setSapWarehouseCode(grInfoDto.getWarehouseCode());
        wmsDocReceive.setConfirmReceiptFlag(1);
        wmsDocReceive.setPlantCode(grInfoDto.getPlantCode());
        wmsDocReceive.setPoNo(grInfoDto.getPoNumber());
        wmsDocReceive.setPoItem(grInfoDto.getPoItem());
        wmsDocReceive.setPartNo(grInfoDto.getPartNo());
        wmsDocReceive.setPartNoVersion(grInfoDto.getValueType());
        wmsDocReceive.setDocQty(grInfoDto.getQty());
        wmsDocReceive.setConfirmQty(grInfoDto.getQty());
        wmsDocReceive.setOperateQty(grInfoDto.getQty());
        wmsDocReceive.setUomCode(grInfoDto.getBom());
        wmsDocReceive.setPlaceOfOrigin1(placeOfOrigin1);
        wmsDocReceive.setIsForceInspect(Boolean.FALSE);
        wmsDocReceive.setSapReturnNumber(grInfoDto.getGrNumber());
        wmsDocReceive.setSapReturnMessage("OK");
        wmsDocReceive.setVendorCode(grInfoDto.getTradingCode());
        wmsDocReceive.setWmsContent(JSONUtil.toJsonStr(wmsDocReceive));
        wmsDocReceive.setInspectResult("Y");
        wmsDocReceive.setDocNo("RW" + grInfoDto.getGrNumber());
        wmsDocReceiveMapper.insert(wmsDocReceive);
    }

    public void pnReceive(String sapClientCode, String orgCode, String startDate, String endDate) {
        //包材收货单LIST
        List<JitReceiptDto> jitReceiptDtos = CollUtil.newArrayList();
        List<WmsSapPlant> wmsSapPlantList = wmsSapPlantMapper.selectList(Wrappers.<WmsSapPlant>lambdaQuery()
                .eq(WmsSapPlant::getOrgCode, orgCode));
        try {
            for (WmsSapPlant wmsSapPlant : wmsSapPlantList) {
                //包材收货单
                List<JitReceiptDto> jitReceiptDtoList = docRfcService.doGetJITReceipt(sapClientCode, wmsSapPlant.getFactoryCode(), startDate, endDate, "");
                jitReceiptDtos.addAll(jitReceiptDtoList);
            }
        } catch (Exception e) {
            log.error("doGetJITReceipt error : {}", e.getMessage());
        }
        //保存包材收货单
        for (JitReceiptDto jitReceiptDto : jitReceiptDtos) {
            Long count = wmsDocReceiveMapper.selectCount(Wrappers.<WmsDocReceive>lambdaQuery()
                    .eq(WmsDocReceive::getSapReturnNumber, jitReceiptDto.getReceiptNumber()));
            if (count > 0) {
                continue;
            }
            insertPnWmsDocReceive(orgCode, jitReceiptDto);
        }
    }

    private void insertPnWmsDocReceive(String orgCode, JitReceiptDto jitReceiptDto) {
        String docType = "PN_RECEIVE_DOC";
        WmsDocReceive wmsDocReceive = new WmsDocReceive();
        wmsDocReceive.setId(null);
        WmsDocType wmsDocTypeDb = wmsDocTypeMapper.selectOne(Wrappers.<WmsDocType>lambdaQuery()
                .eq(WmsDocType::getDocTypeCode, docType));
        wmsDocReceive.setOrgCode(orgCode);
        LocalDate localDate = getDocCreateDate(jitReceiptDto.getAsnDate());
        wmsDocReceive.setDocCreateDate(localDate);
        wmsDocReceive.setDocStatus("SHELF_COMPLETED");
        wmsDocReceive.setWmsDocTypeId(wmsDocTypeDb.getId());
        wmsDocReceive.setDocTypeName(wmsDocTypeDb.getDocTypeName());
        wmsDocReceive.setDocTypeCode(docType);
        wmsDocReceive.setDocCategoryCode(wmsDocTypeDb.getDocCategoryCode());
        wmsDocReceive.setPostingMethodName(wmsDocTypeDb.getPostingMethodName());
        wmsDocReceive.setPostingSapMethodFlag(wmsDocTypeDb.getPostingSapFlag());
        wmsDocReceive.setPostingQmsFlag(wmsDocTypeDb.getPostingQmsFlag());
        wmsDocReceive.setSapWarehouseCode(jitReceiptDto.getType());
        wmsDocReceive.setConfirmReceiptFlag(1);
        wmsDocReceive.setPlantCode(jitReceiptDto.getPlant());
        wmsDocReceive.setPoNo(jitReceiptDto.getPoNumber());
        wmsDocReceive.setPoItem(jitReceiptDto.getPoItem());
        String partNo = jitReceiptDto.getPartNo();
        int length = partNo.lastIndexOf("-");
        String partNoVersion = partNo.substring(length + 1);
        wmsDocReceive.setPartNo(partNo);
        wmsDocReceive.setPartNoVersion(partNoVersion);
        wmsDocReceive.setDocQty(jitReceiptDto.getQty());
        wmsDocReceive.setConfirmQty(jitReceiptDto.getQty());
        wmsDocReceive.setOperateQty(jitReceiptDto.getQty());
        wmsDocReceive.setUomCode(jitReceiptDto.getUnit());
        wmsDocReceive.setPlaceOfOrigin1("CN");
        wmsDocReceive.setIsForceInspect(Boolean.FALSE);
        wmsDocReceive.setSapReturnNumber(jitReceiptDto.getReceiptNumber());
        wmsDocReceive.setSapReturnMessage("OK");
        wmsDocReceive.setVendorCode(jitReceiptDto.getVendor());
        wmsDocReceive.setWmsContent(JSONUtil.toJsonStr(wmsDocReceive));
        wmsDocReceive.setInspectResult("Y");
        wmsDocReceive.setDocNo("RB" + jitReceiptDto.getReceiptNumber());
        wmsDocReceive.setCreatedDt(LocalDateTime.now());
        wmsDocReceiveMapper.insert(wmsDocReceive);
    }

    private LocalDate getDocCreateDate(String dateStr) {
        dateStr = dateStr.substring(0, 8);
        LocalDate localDate = LocalDate.parse(dateStr, BASIC_ISO_DATE);
        int year = localDate.getYear();
        if (2023 > year) {
            return LocalDate.now();
        }
        return localDate;
    }

    public void syncJusdaTradingDoc(String sapClientCode, String orgCode, String startDate, String endDate) {
        List<GrInfoDto> grInfoDtos = CollUtil.newArrayList();
        List<WmsSapPlant> wmsSapPlantList = wmsSapPlantMapper.selectList(Wrappers.<WmsSapPlant>lambdaQuery()
                .eq(WmsSapPlant::getOrgCode, orgCode));
        try {
            for (WmsSapPlant wmsSapPlant : wmsSapPlantList) {
                List<GrInfoDto> grInfoDtoLists = grRfcService.doGetGrInfo(sapClientCode, wmsSapPlant.getFactoryCode(),
                        "CN09", startDate, endDate);
                grInfoDtos.addAll(grInfoDtoLists);
            }
        } catch (JCoException e) {
            log.error("doGetGrInfo error : {}", e.getMessage());
        }
        //根据poNumber分组数据
        Map<String, List<GrInfoDto>> collect = grInfoDtos.stream()
                .collect(Collectors.groupingBy(GrInfoDto::getPoNumber));
        for (Map.Entry<String, List<GrInfoDto>> entry : collect.entrySet()) {
            //poNumber
            String poNumber = entry.getKey();
            if (!poNumber.startsWith("550")) {
                continue;
            }
            //查询po信息
            List<PoItemInfoDto> poItemInfoDtoList = CollUtil.newArrayList();
            try {
                poItemInfoDtoList = poRfcService.doGetPoInfo(sapClientCode, poNumber, "x", "x");
            } catch (JCoException e) {
                log.error("doGetPoInfo error : {}", e.getMessage());
            }
            List<GrInfoDto> grInfoDtoList = entry.getValue();
            for (GrInfoDto grInfoDto : grInfoDtoList) {
                String grNumber = grInfoDto.getGrNumber();
                Long count = wmsJusdaReceiptMapper.selectCount(Wrappers.<WmsJusdaReceiptEntity>lambdaQuery()
                        .eq(WmsJusdaReceiptEntity::getOrgCode, orgCode)
                        .eq(WmsJusdaReceiptEntity::getSapReturnNumber, grNumber));
                if (count > 0) {
                    continue;
                }
                String returnGrNumber = grInfoDto.getReturnGrNumber();
                WmsJusdaTradingDocImportRecord wmsJusdaTradingDocImportRecord = new WmsJusdaTradingDocImportRecord();
                wmsJusdaTradingDocImportRecord.setOrgCode(orgCode);
                wmsJusdaTradingDocImportRecord.setPlantCode(grInfoDto.getPlantCode());
                wmsJusdaTradingDocImportRecord.setGrNumber(grNumber);
                wmsJusdaTradingDocImportRecord.setGrItem(grInfoDto.getGrItem());
                wmsJusdaTradingDocImportRecord.setTradingCode(grInfoDto.getTradingCode());
                wmsJusdaTradingDocImportRecord.setPartNo(grInfoDto.getPartNo());
                wmsJusdaTradingDocImportRecord.setPartDesc(grInfoDto.getPartDesc());
                wmsJusdaTradingDocImportRecord.setQty(grInfoDto.getQty());
                wmsJusdaTradingDocImportRecord.setPoNo(grInfoDto.getPoNumber());
                wmsJusdaTradingDocImportRecord.setPoItem(grInfoDto.getPoItem());
                wmsJusdaTradingDocImportRecord.setUomCode(grInfoDto.getBom());
                wmsJusdaTradingDocImportRecord.setWarehouseCode(grInfoDto.getWarehouseCode());
                //GrNumber和ReturnGrNumber不一致则返掉ReturnGrNumber的内交入收货单且不产生内交入收货单
                if (StringUtils.isEmpty(grNumber) || StringUtils.isEmpty(returnGrNumber)) {
                    wmsJusdaTradingDocImportRecord.setDocCreateMsg("grNumber或者returnGrNumber为空");
                } else {
                    if (!grInfoDto.getGrNumber().equals(grInfoDto.getReturnGrNumber())) {
                        //设置错误信息，避免生成收货单
                        wmsJusdaTradingDocImportRecord.setDocCreateMsg("返单");
                    }
                }
                wmsJusdaTradingDocImportRecord.setDocCreateFlag("N");
                wmsJusdaTradingDocImportRecord.setPlaceOfOrigin("CN");
                wmsJusdaTradingDocImportRecord.setCreatedDt(LocalDateTime.now());
                wmsJusdaTradingDocImportRecord.setCreator("sysadmin");
                wmsJusdaTradingDocImportRecord.setLastEditor("sysadmin");
                wmsJusdaTradingDocImportRecord.setLastEditedDt(LocalDateTime.now());
                wmsJusdaTradingDocImportRecord.setReturnGrNumber(returnGrNumber);
                String docCreateMsg = StrUtil.EMPTY;
                wmsJusdaTradingDocImportRecordMapper.insertJusdaTradingDocImportRecord(wmsJusdaTradingDocImportRecord);
                WmsJusdaTradingDocImportRecord wmsJusdaTradingDocImportRecordDb = wmsJusdaTradingDocImportRecordMapper
                        .selectOne(Wrappers.<WmsJusdaTradingDocImportRecord>lambdaQuery()
                                .eq(WmsJusdaTradingDocImportRecord::getOrgCode, wmsJusdaTradingDocImportRecord.getOrgCode())
                                .eq(WmsJusdaTradingDocImportRecord::getPlantCode, wmsJusdaTradingDocImportRecord.getPlantCode())
                                .eq(WmsJusdaTradingDocImportRecord::getGrNumber, wmsJusdaTradingDocImportRecord.getGrNumber())
                                .eq(WmsJusdaTradingDocImportRecord::getGrItem, wmsJusdaTradingDocImportRecord.getGrItem())
                                .last("limit 1"));
                if ("Y".equals(wmsJusdaTradingDocImportRecord.getDocCreateFlag())) {
                    continue;
                }
                PoItemInfoDto itemInfoDto = poItemInfoDtoList.stream()
                        .filter(poItemInfoDto -> grInfoDto.getPoItem().equals(poItemInfoDto.getPoItem()))
                        .findFirst().orElse(null);
                if (ObjectUtil.isNotNull(itemInfoDto)) {
                    wmsJusdaTradingDocImportRecordDb.setPartVersion(itemInfoDto.getPartVersion());
                    wmsJusdaTradingDocImportRecordDb.setPoDocumentType(itemInfoDto.getDocType());
                    wmsJusdaTradingDocImportRecordDb.setPurchaseGroup(itemInfoDto.getPurchaseGroup());
                    wmsJusdaTradingDocImportRecordDb.setPurchaseOrg(itemInfoDto.getPurchaseOrg());
                    wmsJusdaTradingDocImportRecordDb.setMfgCode(itemInfoDto.getMfrCode());
                    wmsJusdaTradingDocImportRecordDb.setMfgPartNo(itemInfoDto.getMfrPartNo());
                    MfrInfoDto mfrInfoDto = null;
                    try {
                        mfrInfoDto = poRfcService.doGetMfrNameByCode(sapClientCode, itemInfoDto.getMfrCode());
                    } catch (JCoException e) {
                        log.error("doGetMfrNameByCode error : {}", e.getMessage());
                    }
                    if (ObjectUtil.isNull(mfrInfoDto) || StrUtil.isEmpty(mfrInfoDto.getMfrName())) {
                        docCreateMsg = docCreateMsg + "未找到mfrCode:" + itemInfoDto.getMfrCode() + "的制造商名称信息";
                    } else {
                        wmsJusdaTradingDocImportRecordDb.setMfgName(mfrInfoDto.getMfrName());
                    }
                } else {
                    docCreateMsg = docCreateMsg + "poNumber:" + poNumber + "poItem:" + grInfoDto.getPoItem() + "不存在";
                }
                if (StrUtil.isNotEmpty(docCreateMsg)) {
                    wmsJusdaTradingDocImportRecordDb.setDocCreateMsg(docCreateMsg);
                }
                wmsJusdaTradingDocImportRecordMapper.updateById(wmsJusdaTradingDocImportRecordDb);
            }
        }
        //查询导入记录中未建单成功并且没有错误信息的记录,准备新增内交入收货单
        List<WmsJusdaTradingDocImportRecord> jusdaTradingDocImportRecordList = wmsJusdaTradingDocImportRecordMapper
                .selectList(Wrappers.<WmsJusdaTradingDocImportRecord>lambdaQuery()
                        .eq(WmsJusdaTradingDocImportRecord::getDocCreateFlag, "N")
                        .isNull(WmsJusdaTradingDocImportRecord::getDocCreateMsg));
        for (WmsJusdaTradingDocImportRecord wmsJusdaTradingDocImportRecord : jusdaTradingDocImportRecordList) {
            Long count = wmsDocReceiveMapper.selectCount(Wrappers.<WmsDocReceive>lambdaQuery()
                    .eq(WmsDocReceive::getSapReturnNumber, wmsJusdaTradingDocImportRecord.getGrNumber()));
            if (count > 0) {
                wmsJusdaTradingDocImportRecord.setDocCreateMsg("内交单号已在WMS收货单中存在");
                wmsJusdaTradingDocImportRecord.setDocCreateFlag("N");
                wmsJusdaTradingDocImportRecordMapper.updateById(wmsJusdaTradingDocImportRecord);
                continue;
            }
            //新增jusda内交入收货单
            WmsDocReceive wmsDocReceive = new WmsDocReceive();
            BeanUtils.copyProperties(wmsJusdaTradingDocImportRecord, wmsDocReceive);
            wmsDocReceive.setId(null);
            WmsDocType wmsDocTypeDb = wmsDocTypeMapper.selectOne(Wrappers.<WmsDocType>lambdaQuery()
                    .eq(WmsDocType::getDocTypeCode, "JUSDA_TRADING_RECEIVE_DOC"));
            wmsDocReceive.setDocTypeCode("JUSDA_TRADING_RECEIVE_DOC");
            wmsDocReceive.setSapWarehouseCode(wmsJusdaTradingDocImportRecord.getWarehouseCode());
            wmsDocReceive.setConfirmReceiptFlag(1);
            wmsDocReceive.setConfirmDocDate(LocalDateTime.now());
            wmsDocReceive.setDocQty(wmsJusdaTradingDocImportRecord.getQty());
            wmsDocReceive.setConfirmQty(wmsJusdaTradingDocImportRecord.getQty());
            wmsDocReceive.setWmsDocTypeId(wmsDocTypeDb.getId());
            wmsDocReceive.setDocCategoryCode(wmsDocTypeDb.getDocCategoryCode());
            wmsDocReceive.setDocCreateDate(LocalDate.now());
            wmsDocReceive.setPostingMethodName(wmsDocTypeDb.getPostingMethodName());
            wmsDocReceive.setPostingSapMethodFlag(wmsDocTypeDb.getPostingSapFlag());
            wmsDocReceive.setDocTypeName(wmsDocTypeDb.getDocTypeName());
            wmsDocReceive.setPostingQmsFlag(wmsDocTypeDb.getPostingQmsFlag());
            wmsDocReceive.setDocStatus("RECEIVED_COMPLETED");
            wmsDocReceive.setSapReturnMessage("OK");
            wmsDocReceive.setSapReturnNumber(wmsJusdaTradingDocImportRecord.getGrNumber());
            wmsDocReceive.setPlaceOfOrigin1("CN");
            wmsDocReceive.setWmsContent(JSONUtil.toJsonStr(wmsDocReceive));
            wmsDocReceive.setInspectResult("Y");
            String docNo = StrUtil.EMPTY;
            HttpResponse httpResponse = codeRuleService.getCodeRule(orgCode);
            String body = httpResponse.body();
            if (httpResponse.getStatus() == HttpStatus.HTTP_OK) {
                JSONObject jsonObject = JSONUtil.parseObj(body);
                String code = jsonObject.getStr("code");
                if (StringUtils.isNotBlank(code) && "200".equalsIgnoreCase(code)) {
                    List<String> data = (List<String>) jsonObject.getObj("data");
                    docNo = data.get(0);
                }
            }
            if (StrUtil.isEmpty(docNo)) {
                wmsJusdaTradingDocImportRecord.setDocCreateMsg("生成内交单号异常");
                wmsJusdaTradingDocImportRecord.setDocCreateFlag("N");
                wmsJusdaTradingDocImportRecordMapper.updateById(wmsJusdaTradingDocImportRecord);
                continue;
            } else {
                wmsJusdaTradingDocImportRecord.setDocCreateFlag("Y");
                wmsJusdaTradingDocImportRecordMapper.updateById(wmsJusdaTradingDocImportRecord);
            }
            wmsDocReceive.setDocNo(docNo);
            wmsDocReceiveMapper.insert(wmsDocReceive);
        }
        //筛选出grNumber和returnGrNumber不同的,执行返单
        List<GrInfoDto> newInfoDtoList = grInfoDtos.stream().filter(a -> !a.getGrNumber().equals(a.getReturnGrNumber()))
                .collect(Collectors.toList());
        for (GrInfoDto grInfoDto : newInfoDtoList) {
            wmsDocReceiveMapper.update(null, Wrappers.<WmsDocReceive>lambdaUpdate()
                    .eq(WmsDocReceive::getOrgCode, orgCode)
                    .eq(WmsDocReceive::getPlantCode, grInfoDto.getPlantCode())
                    .eq(WmsDocReceive::getSapReturnNumber, grInfoDto.getReturnGrNumber())
                    .eq(WmsDocReceive::getDocTypeCode, "JUSDA_TRADING_RECEIVE_DOC")
                    .set(WmsDocReceive::getSapReturnNumber, grInfoDto.getReturnGrNumber() + "_" + grInfoDto.getGrNumber())
                    .set(WmsDocReceive::getDocStatus, "SHELF_COMPLETED"));
        }
    }
}
