package com.maxnerva.cloudmes.service.sap.trading.model;

import lombok.Data;

/**
 * 生成Trading number Dto
 */

@Data
public class GenerateTradingNumberDto {
    String sapClient;
    private String idn;  //pgiNo
    // private String pmode; // 1.Inbreeding,2.pgi
    private String tradingFromCode;  //?交出bu代?
    private String fromPlant; //?交出工厂
    private String deliveryType; //??默?ZLO
    private String salesOrg;  //?售??
    private String distriChan;  //配?通路
    private String division;  //?品部
    private String tradingToCode; //?交入bu代?
    private String giDate;  //默??天，用?可填?
    private String material;   //料?
    private String quantity;   //?量
    private String unit;     //?位
    private String location; //??
    private String batch; //版次
    private String clientId; //端口
    private String valueType;
    private String orgCode;
}