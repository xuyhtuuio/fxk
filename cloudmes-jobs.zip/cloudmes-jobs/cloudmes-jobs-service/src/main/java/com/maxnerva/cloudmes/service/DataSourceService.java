package com.maxnerva.cloudmes.service;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.entity.basic.WmsPlantCustomerConfig;
import com.maxnerva.cloudmes.mapper.basic.BasicMaterialMapper;
import com.maxnerva.cloudmes.mapper.basic.WmsPlantCustomerConfigMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName DataSourceService
 * @Description sfc, mes配置获取service
 * @Author Likun
 * @Date 2023/9/25
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Slf4j
@Service
public class DataSourceService {

    @Resource
    private WmsPlantCustomerConfigMapper wmsPlantCustomerConfigMapper;

    private List<WmsPlantCustomerConfig> customerConfigList;

    @Resource
    private BasicMaterialMapper basicMaterialMapper;

    @PostConstruct
    public void initCustomerConfigList() {
        customerConfigList = wmsPlantCustomerConfigMapper
                .selectList(Wrappers.lambdaQuery());
    }

    public String getDataSource(String orgCode, String mrpArea, String lineNo) {
        //默认MES
        String dataSource = "MES";
        WmsPlantCustomerConfig customerConfig = customerConfigList.stream()
                .filter(wmsPlantCustomerConfig ->
                        StrUtil.equals(orgCode, wmsPlantCustomerConfig.getOrgCode()) &&
                                StrUtil.equals(mrpArea, wmsPlantCustomerConfig.getMrpArea()))
                .findFirst().orElse(null);
        if (ObjectUtil.isNotNull(customerConfig)) {
            //判断remark是否包含线别信息,是则赋值数据源为MES
            if (StrUtil.isNotEmpty(lineNo) && StrUtil.isNotEmpty(customerConfig.getRemark())) {
                dataSource = customerConfig.getRemark().contains(lineNo) ? "MES" : customerConfig.getMesDataSource();
            } else {
                dataSource = customerConfig.getMesDataSource();
            }
        }
        return dataSource;
    }

    public String getDataSourceByOrgCodeAndPlantCode(String orgCode, String plantCode) {
        String dataSource = StrUtil.EMPTY;
        WmsPlantCustomerConfig customerConfig = customerConfigList.stream()
                .filter(wmsPlantCustomerConfig ->
                        StrUtil.equals(orgCode, wmsPlantCustomerConfig.getOrgCode()) &&
                                StrUtil.equals(plantCode, wmsPlantCustomerConfig.getPlantCode()))
                .findFirst().orElse(null);
        if (ObjectUtil.isNotNull(customerConfig)) {
            dataSource = customerConfig.getMesDataSource();
        }
        return dataSource;
    }

    public String getCmbDataSource(String orgCode, String plantCode, String productPartNo) {
        String dataSource = "SFC_E5T1";
        String customerName = basicMaterialMapper
                .selectCustomerNameByMaterialNo(orgCode, plantCode, productPartNo);
        if (StrUtil.isNotEmpty(customerName)) {
            WmsPlantCustomerConfig customerConfig = customerConfigList.stream()
                    .filter(wmsPlantCustomerConfig ->
                            StrUtil.equals(orgCode, wmsPlantCustomerConfig.getOrgCode()) &&
                                    StrUtil.equals(plantCode, wmsPlantCustomerConfig.getPlantCode())
                                    && wmsPlantCustomerConfig.getRemark().contains(customerName))
                    .findFirst().orElse(null);
            if (ObjectUtil.isNotNull(customerConfig)) {
                dataSource = customerConfig.getMesDataSource();
            }
        }
        return dataSource;
    }
}
