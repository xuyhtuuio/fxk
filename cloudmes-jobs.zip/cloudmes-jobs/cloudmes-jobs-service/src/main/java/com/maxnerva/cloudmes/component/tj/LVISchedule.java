package com.maxnerva.cloudmes.component.tj;

import cn.hutool.core.date.DateUtil;
import com.maxnerva.cloudmes.service.basic.PostingConfigService;
import com.maxnerva.cloudmes.service.doc.AdjustDocPostingService;
import com.maxnerva.cloudmes.service.doc.CostDocPostingService;
import com.maxnerva.cloudmes.service.doc.ReceiveDocPostingService;
import com.maxnerva.cloudmes.service.doc.TransferDocPostingService;
import com.maxnerva.cloudmes.service.mes.PostingMesService;
import com.maxnerva.cloudmes.service.sfc.PostingSfcService;
import com.maxnerva.cloudmes.service.wo.WmsBadPostingService;
import com.maxnerva.cloudmes.service.wo.WoPostingNewModeService;
import com.maxnerva.cloudmes.service.wo.WoPostingService;
import com.maxnerva.cloudmes.service.wo.WorkOrderService;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;

import java.time.LocalDateTime;
import java.util.Arrays;

/**
 * @author H7109018
 */
@ConditionalOnProperty(value = "cope.code", havingValue = "F_TJ")
@Component
@EnableScheduling
@Slf4j
public class LVISchedule {

    private static final String ORG_CODE = "LVI";
    private static final String SAP_CLIENT_CODE = "sap";
    private static final String DATE_FORMAT = "yyyyMMdd";
    private static String postDate = "N";

    @Autowired
    WorkOrderService workOrderService;

    @Autowired
    WoPostingService woPostingService;

    @Autowired
    ReceiveDocPostingService docPostingService;

    @Autowired
    TransferDocPostingService transferDocPostingService;

    @Autowired
    AdjustDocPostingService adjustDocPostingService;

    @Autowired
    CostDocPostingService costDocPostingService;

    @Autowired
    PostingSfcService postingSfcService;

    @Autowired
    PostingConfigService postingConfigService;

    @Autowired
    PostingMesService postingMesService;

    @Autowired
    WoPostingNewModeService woPostingNewModeService;

    @Autowired
    WmsBadPostingService wmsBadPostingService;

    /**
     * 修改过账时间
     * 频率：10分钟执行一次
     */
    @Scheduled(initialDelay = 5000, fixedDelay = 300000)
    public void updatePostDate() {
        String s = postingConfigService.getPostDate(ORG_CODE, null);
        postDate = s;
    }

    /**
     * 费领退及报废单过账SAP
     * 频率：5分钟执行一次
     */
    @Scheduled(initialDelay = 32000, fixedDelay = 600000)
    public void costDocPostingService() {
        log.info("costLVIDocPostingService start :" + System.currentTimeMillis());
        costDocPostingService.costDocTransferPosting(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("costLVIDocPostingService end :" + System.currentTimeMillis());
    }

    /**
     * 工单备料PKG信息抛SFC
     * 频率：10分钟执行一次
     */
    @Scheduled(initialDelay = 50000, fixedDelay = 600000)
    public void postingWoPreparePkgInfoToSFC() {
        log.info("postingUpShelfPkgInfoToSFC start :" + System.currentTimeMillis());
        postingSfcService.postingWoPreparePkgInfoToSFC(ORG_CODE);
        log.info("postingUpShelfPkgInfoToSFC end:" + System.currentTimeMillis());
    }

    /**
     * 同步MSD
     */
    @Scheduled(initialDelay = 70000, fixedDelay = 300000)
    public void syncMsd() {
        //pkg_info同步MSD
        log.info("syncMsdPkgInfo start :" + System.currentTimeMillis());
        postingMesService.syncMsdPkgInfo(ORG_CODE);
        log.info("syncMsdPkgInfo end :" + System.currentTimeMillis());

        //pick_log同步MSD
        log.info("syncMsdPickLog start :" + System.currentTimeMillis());
        postingMesService.syncMsdPickLog(ORG_CODE);
        log.info("syncMsdPickLog end :" + System.currentTimeMillis());

        //prepare_log同步MSD
        log.info("syncMsdPrepareLog start :" + System.currentTimeMillis());
        postingMesService.syncMsdPrepareLog(ORG_CODE);
        log.info("syncMsdPrepareLog end :" + System.currentTimeMillis());
    }

    /**
     * 工单备料量过账261
     * 频率：10分钟执行一次
     */
    @Scheduled(initialDelay = 15000, fixedDelay = 600000)
    public void postingWoDetail261NewModeTest() {
        //工单备料量过账261
        log.info("postingWoDetail261NewModeTest start :" + System.currentTimeMillis());
        woPostingNewModeService.postingWoDetail261NewMode(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoDetail261NewModeTest end :" + System.currentTimeMillis());

        //工单退料量过账262
        log.info("postingWoDetail262NewModeTest start :" + System.currentTimeMillis());
        woPostingNewModeService.postingWoDetail262NewMode(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoDetail262NewModeTest end :" + System.currentTimeMillis());

        //工单移出量过账 262
        log.info("postingWoRemove262NewModeTest start :" + System.currentTimeMillis());
        woPostingNewModeService.postingWoRemove262NewMode(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoRemove262NewModeTest end :" + System.currentTimeMillis());

        //工单移入量过账 261
        log.info("postingWoMoveIn261NewModeTest start :" + System.currentTimeMillis());
        woPostingNewModeService.postingWoMoveIn261NewMode(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoMoveIn261NewModeTest end :" + System.currentTimeMillis());

        //重工工单过账SAP 531
        log.info("postingWoDetail531NewMode start :" + System.currentTimeMillis());
        woPostingNewModeService.postingWoDetail531NewMode(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoDetail531NewMode end :" + System.currentTimeMillis());

        //不良品退料过账
        log.info("postingReturnBadGoods start :" + System.currentTimeMillis());
        wmsBadPostingService.postingReturnBadGoods(ORG_CODE, postDate);
        log.info("postingReturnBadGoods end :" + System.currentTimeMillis());

        //报废入库过账311
        log.info("postingScrap311 start :" + System.currentTimeMillis());
        woPostingNewModeService.postingScrap311(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingScrap311 end :" + System.currentTimeMillis());

        //不良品QMS领用过账到QMS仓码 311
        log.info("scrapPostingQmsWarehouseCodeBy311 start :" + System.currentTimeMillis());
        woPostingNewModeService.scrapPostingQmsWarehouseCodeBy311(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("scrapPostingQmsWarehouseCodeBy311 end :" + System.currentTimeMillis());

        //不良品QMS退回过账至指定仓码 311
        log.info("scrapPostingQmsReturnBy311 start :" + System.currentTimeMillis());
        woPostingNewModeService.scrapPostingQmsReturnBy311(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("scrapPostingQmsReturnBy311 end :" + System.currentTimeMillis());
    }

    /**
     * 收货单据确认且抛Q成功后转良品仓待验状态
     * 频率：5分钟执行一次
     */
    @Scheduled(initialDelay = 14000, fixedDelay = 600000)
    public void postingToBeInspected() {
        log.info("LVIpostingToBeInspected start :" + System.currentTimeMillis());
        docPostingService.docPostingToBeInspected(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("LVIpostingToBeInspected end :" + System.currentTimeMillis());
    }

    /**
     * 工单成品入库 101
     * 频率：10分钟执行一次
     */
    @Scheduled(initialDelay = 16000, fixedDelay = 600000)
    public void postingWoHeader101Test() {
        log.info("postingLviWoHeader101 start :" + System.currentTimeMillis());
        woPostingNewModeService.postingCmbWoHeader101(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingLviWnHeader101 end :" + System.currentTimeMillis());
    }

    /**
     * 料调单过账
     */
    @Scheduled(initialDelay = 17000, fixedDelay = 600000)
    public void docAdjustPosting() {
        log.info("docAdjustPosting start :" + System.currentTimeMillis());
        adjustDocPostingService.docAdjustPosting(SAP_CLIENT_CODE, ORG_CODE, Arrays.asList("5"), postDate);
        log.info("docAdjustPosting end :" + System.currentTimeMillis());
    }

    /**
     * 转仓单过账
     */
    @Scheduled(initialDelay = 130000, fixedDelay = 900000)
    public void docTransferPosting() {
        log.info("docTransferPosting start :" + System.currentTimeMillis());
        transferDocPostingService.docTransferPosting(SAP_CLIENT_CODE, ORG_CODE, Arrays.asList("5"), postDate);
        log.info("docTransferPosting end :" + System.currentTimeMillis());
    }

    /**
     * 转仓收货单，依据Q的结果判断是否需要转不良品仓
     */
    @Scheduled(initialDelay = 300000, fixedDelay = 900000)
    public void docTransferReceiveToRejectsWarehouse() {
        log.info("docTransferReceiveToRejectsWarehouse start :" + System.currentTimeMillis());
        docPostingService.docTransferReceiveToRejectsWarehouse(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("docTransferReceiveToRejectsWarehouse end :" + System.currentTimeMillis());
    }
}
