package com.maxnerva.cloudmes.entity.mes;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName PoSnBindVO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/22
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Data
@ApiModel("PO SN绑定参数对接")
public class PoSnBindVO {

    @ApiModelProperty(value = "4.3/4.20接收的PO单号")
    private String poNumber;

    @ApiModelProperty(value = "物流单号，默认为空")
    private String deliveryNumber;

    @ApiModelProperty(value = "4.3/4.20接收的detail_id")
    private String detailId;

    @ApiModelProperty(value = "条码SN")
    private String snCode;

    @ApiModelProperty(value = "条码SN绑定的固资")
    private String assetCode;

    @ApiModelProperty(value = "配送状态，默认：配送中")
    private String status;

    @ApiModelProperty(value = "4.3/4.20接收的estDeliveryDate")
    private String actArriveDate;

    @ApiModelProperty(value = "备注，默认为空")
    private String vendorMemo;

    @ApiModelProperty(value = "SN扫描出货时间")
    private String vendorOutStorageTime;

    @ApiModelProperty(value = "4.3/4.20接收的conf1")
    private String attr1;

    @ApiModelProperty(value = "4.3/4.20接收的conf2")
    private String attr2;

    @ApiModelProperty(value = "4.3/4.20接收的conf3")
    private String attr3;

    @ApiModelProperty(value = "4.3/4.20接收的conf4")
    private String attr4;

    @ApiModelProperty(value = "4.3/4.20接收的conf5")
    private String attr5;

    @ApiModelProperty(value = "SAP工厂")
    private String plantCode;

    @ApiModelProperty(value = "组织代码")
    private String orgCode;
}
