package com.maxnerva.cloudmes.service.datahub.impl;

import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.json.JSONUtil;
import com.maxnerva.cloudmes.config.DataHubUrlConfig;
import com.maxnerva.cloudmes.entity.spm.TransferDocToSpmVO;
import com.maxnerva.cloudmes.service.datahub.DataHubService;
import com.maxnerva.cloudmes.service.wo.model.JsonStringVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName DataHubServiceImpl
 * @Description 服务节点调用类
 * @Author Likun
 * @Date 2023/3/9
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Slf4j
@Service
public class DataHubServiceImpl implements DataHubService {

    @Resource
    private DataHubUrlConfig dataHubUrlConfig;

    @Override
    public HttpResponse vnCreatePo(JsonStringVO vnCreatePoVO) {
        String url = dataHubUrlConfig.getVnCreatePo();
        return HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(vnCreatePoVO))
                .execute();
    }

    @Override
    public HttpResponse saveWmsDocReceive(JsonStringVO jsonStringVO) {
        String url = dataHubUrlConfig.getSaveCkdDocReceive();
        return HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(jsonStringVO))
                .execute();
    }

    @Override
    public HttpResponse syncTransferToSpm(List<TransferDocToSpmVO> transferDocToSpmVOList) {
        String produceEadByWmsUrl = dataHubUrlConfig.getProduceEadByWmsUrl();
        return HttpRequest.post(produceEadByWmsUrl)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(transferDocToSpmVOList))
                .execute();
    }
}
