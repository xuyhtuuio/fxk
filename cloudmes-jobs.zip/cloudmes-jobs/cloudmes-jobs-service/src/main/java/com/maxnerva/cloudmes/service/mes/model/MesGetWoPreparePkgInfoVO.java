package com.maxnerva.cloudmes.service.mes.model;

import io.swagger.annotations.ApiModel;
import lombok.Data;

/**
 * @Author hgx
 * @Description 工单备料PKG信息抛MesVO
 * @Date 2023/9/18
 */
@ApiModel("工单备料PKG信息抛MesVO")
@Data
public class MesGetWoPreparePkgInfoVO {
    private String orgCode;
    private String pkgId;
}
