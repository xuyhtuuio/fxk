package com.maxnerva.cloudmes.service.doc;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.entity.doc.WmsDocJitReceiveGrRecord;

/**
 * <p>
 * JIT收货GR记录表 服务类
 * </p>
 *
 * @author likun
 * @since 2025-02-11
 */
public interface IWmsDocJitReceiveGrRecordService extends IService<WmsDocJitReceiveGrRecord> {

    void createJitDocReceive(String sapClientCode, String orgCode);
}
