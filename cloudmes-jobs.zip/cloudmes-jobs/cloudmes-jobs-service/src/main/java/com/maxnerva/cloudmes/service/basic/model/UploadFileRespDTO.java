package com.maxnerva.cloudmes.service.basic.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class UploadFileRespDTO {
    @ApiModelProperty("文件id")
    private Integer id;
    @ApiModelProperty("源文件名称")
    private String originalName;
    @ApiModelProperty("文件名称")
    private String name;
    @ApiModelProperty("域名")
    private String domain;
    @ApiModelProperty("文件地址")
    private String link;
    @ApiModelProperty("文件类型")
    private String fileType;
    @ApiModelProperty("文件大小")
    private long fileSize;
    @ApiModelProperty("备注")
    private String remark;

    public UploadFileRespDTO() {
    }
}
