package com.maxnerva.cloudmes.service.qms;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.entity.qms.WmsSyncMsdLevelFromQmsLog;

/**
 * <p>
 * 从qms同步msd等级表 服务类
 * </p>
 *
 * @author likun
 * @since 2024-11-28
 */
public interface IWmsSyncMsdLevelFromQmsLogService extends IService<WmsSyncMsdLevelFromQmsLog> {

}
