package com.maxnerva.cloudmes.service;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.date.LocalDateTimeUtil;
import cn.hutool.json.JSONUtil;
import com.maxnerva.cloudmes.entity.basic.BasicMaterialMfgEntity;
import org.apache.commons.lang3.LocaleUtils;
import org.apache.commons.lang3.StringUtils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/10/19 13:08
 * @Version: 1.0
 */
public class TTtest {


    public static String getDateValue(String key) {

        HashMap<String, String> t = new HashMap<>();
        t.put("1", "01");
        t.put("2", "02");
        t.put("3", "03");
        t.put("4", "04");
        t.put("5", "05");
        t.put("6", "06");
        t.put("7", "07");
        t.put("8", "08");
        t.put("9", "09");
        t.put("A", "10");
        t.put("B", "11");
        t.put("C", "12");
        t.put("D", "13");
        t.put("E", "14");
        t.put("F", "15");
        t.put("G", "16");
        t.put("H", "17");
        t.put("I", "18");
        t.put("J", "19");
        t.put("K", "20");
        t.put("L", "21");
        t.put("M", "22");
        t.put("N", "23");
        t.put("O", "24");
        t.put("P", "25");
        t.put("Q", "26");
        t.put("R", "27");
        t.put("S", "28");
        t.put("T", "29");
        t.put("U", "30");
        t.put("V", "31");

        return t.get(key);


    }

    /**
     * 根据具体年份周数获取日期范围
     *
     * @param year
     * @param week
     * @return
     */
    public static String getWeekDays(int year, int week) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        // 设置每周的开始日期
        cal.setFirstDayOfWeek(Calendar.MONDAY);
        cal.setMinimalDaysInFirstWeek(7);
        cal.set(Calendar.YEAR, year);
        cal.set(Calendar.WEEK_OF_YEAR, week);
        cal.set(Calendar.DAY_OF_WEEK, cal.getFirstDayOfWeek());
        String beginDate = sdf.format(cal.getTime());
        return beginDate;


    }

    public static LocalDate parseDate(String dateCode, String dateCodeFormat) {


        String yyyy = "";
        String mm = "";
        String dd = "";
        String ww = "";

        for (int i = 0; i < dateCodeFormat.length(); i++) {
            if ("Y".equalsIgnoreCase(String.valueOf(dateCodeFormat.charAt(i)))) {
                yyyy = yyyy + dateCode.charAt(i);
                continue;
            }

            if ("M".equalsIgnoreCase(String.valueOf(dateCodeFormat.charAt(i)))) {
                mm = mm + dateCode.charAt(i);
                continue;
            }

            if ("D".equalsIgnoreCase(String.valueOf(dateCodeFormat.charAt(i)))) {
                dd = dd + dateCode.charAt(i);
                continue;
            }

            if ("W".equalsIgnoreCase(String.valueOf(dateCodeFormat.charAt(i)))) {
                ww = ww + dateCode.charAt(i);
                continue;
            }
        }

        if (StringUtils.isNotBlank(yyyy)) {
            switch (yyyy.length()) {
                case 1:
                    String thisYear = String.valueOf(DateUtil.thisYear());
                    String tYear = StringUtils.left(thisYear, 3) + yyyy;
                    if (Integer.valueOf(thisYear) >= Integer.valueOf(tYear)) {
                        yyyy = StringUtils.left(String.valueOf(DateUtil.thisYear() - 10), 3) + yyyy;
                    } else {
                        yyyy = StringUtils.left(String.valueOf(DateUtil.thisYear()), 3) + yyyy;
                    }
                    break;
                case 2:
                    yyyy = "20" + yyyy;
                    break;
                case 4:
                    break;
            }
        }

        String parseDate = "";

        if (StringUtils.isNotBlank(ww)) {
            if (ww.length() == 1) {
                ww = getDateValue(ww);
            }

            parseDate = getWeekDays(Integer.valueOf(yyyy), Integer.valueOf(ww))
                    .replaceAll("-", "")
                    .replaceAll("//", "");
        }else{
            if (StringUtils.isNotBlank(mm)) {
                if (mm.length() == 1) {
                    mm = getDateValue(mm);
                }

            }

            if (StringUtils.isNotBlank(dd)) {
                if (dd.length() == 1) {
                    dd = getDateValue(dd);
                }
            }

            parseDate = yyyy + mm + dd;
        }




        LocalDate localDate = LocalDateTimeUtil.parseDate(parseDate, DatePattern.PURE_DATE_PATTERN);

        System.out.println(localDate);
        return localDate;


    }


    public static void main(String[] args) throws ParseException {

        //String dateCode = "2022";
        //String dateCodeFormat = "wwyy";
        //
        //LocalDate date = parseDate(dateCode, dateCodeFormat);
        //System.out.println(date);
        //
        //List<BasicMaterialMfgEntity> templateList = new ArrayList<>();
        //BasicMaterialMfgEntity template = new BasicMaterialMfgEntity();
        //template.setMfgName("a");
        //template.setMaterialNo("b");
        //template.setOrgCode("auth");
        //templateList.add(template);
        //
        //BasicMaterialMfgEntity template2 = new BasicMaterialMfgEntity();
        //template2.setMfgName("a");
        //template2.setMaterialNo("b");
        //template2.setOrgCode("auth1");
        //templateList.add(template2);
        //
        //System.out.println(JSONUtil.toJsonStr(templateList));
        //
        //List<BasicMaterialMfgEntity> tradeFilterList = templateList.stream().distinct().collect(Collectors.toList());
        //
        //List<BasicMaterialMfgEntity> tradeFilterList2 =
        //        templateList.stream().collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(item -> item.getMfgName()+ item.getMaterialNo()))),
        //                ArrayList::new));
        //
        //System.out.println(JSONUtil.toJsonStr(tradeFilterList));
        //System.out.println(JSONUtil.toJsonStr(tradeFilterList2));

//        LocalDate localDate = LocalDateTimeUtil.parseDate("", "MM-dd-yyyy");
//        System.out.println(localDate);

        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
        String currentDate = sdf.format(new Date());
        System.out.println(currentDate);
        DateFormat df = new SimpleDateFormat("MM-dd-yyyy");

        System.out.println(df.parse(currentDate));
    }
}
