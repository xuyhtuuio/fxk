package com.maxnerva.cloudmes.service.mes;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpStatus;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.entity.basic.RecommendDTO;
import com.maxnerva.cloudmes.entity.basic.WmsBin;
import com.maxnerva.cloudmes.entity.basic.WmsVehicle;
import com.maxnerva.cloudmes.entity.mes.InStoreFeignDTO;
import com.maxnerva.cloudmes.entity.pkg.WmsPkgSfcInfoEntity;
import com.maxnerva.cloudmes.entity.wh.WmsPkgInfo;
import com.maxnerva.cloudmes.entity.wh.WmsPkgInfoLog;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderHeader;
import com.maxnerva.cloudmes.mapper.basic.WmsBinMapper;
import com.maxnerva.cloudmes.mapper.basic.WmsVehicleMapper;
import com.maxnerva.cloudmes.mapper.wh.WmsPkgInfoLogMapper;
import com.maxnerva.cloudmes.mapper.wh.WmsPkgInfoMapper;
import com.maxnerva.cloudmes.mapper.wo.WmsWorkOrderHeaderMapper;
import com.maxnerva.cloudmes.service.mes.model.InStorageWoDTO;
import com.maxnerva.cloudmes.service.mes.model.ProductInStorageDTO;
import com.maxnerva.cloudmes.service.mes.model.ProductInStorageVO;
import com.maxnerva.cloudmes.service.sfc.model.SfcPalletInfoDto;
import com.maxnerva.cloudmes.service.wo.IWmsPkgSfcInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @ClassName ProductInStorageService
 * @Description TODO
 * @Author Likun
 * @Date 2023/6/20
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Slf4j
@Service
public class ProductInStorageService {

    @Resource
    private MesService mesService;

    @Resource
    private WmsPkgInfoMapper wmsPkgInfoMapper;

    @Resource
    private WmsWorkOrderHeaderMapper wmsWorkOrderHeaderMapper;

    @Resource
    private IWmsPkgSfcInfoService wmsPkgSfcInfoService;

    @Resource
    private WmsPkgInfoLogMapper wmsPkgInfoLogMapper;

    @Resource
    private WmsVehicleMapper wmsVehicleMapper;

    @Resource
    private WmsBinMapper wmsBinMapper;

    @Transactional(rollbackFor = Exception.class)
    public ProductInStorageDTO inStorage(ProductInStorageVO productInStorageVO) throws Exception {
        //工厂组织
        String orgCode = productInStorageVO.getOrgCode();
        //载具编码
        String vehicleCode = productInStorageVO.getVehicleCode();
        //储位编码
        String binCode = productInStorageVO.getBinCode();
        //SFC Barcode
        String barCode = productInStorageVO.getBarCode();
        String sapPlantCode = productInStorageVO.getPlantCode();
        //库区编码
        String areaCode = productInStorageVO.getAreaCode();
        if (StrUtil.isBlank(areaCode)) {
            throw new Exception("库区信息不存在");
        }
        //调用SFC接口取barcode信息
        List<SfcPalletInfoDto> sfcPalletInfoDtos = getSfcPalletInfoDtos(orgCode, barCode, sapPlantCode);
        //校验栈板信息中成品料号是否唯一
        List<String> partNoList = sfcPalletInfoDtos.stream().map(SfcPalletInfoDto::getProductPartNo).distinct()
                .collect(Collectors.toList());
        if (partNoList.size() > 1) {
            throw new Exception("成品料号不唯一");
        }
        //栈板数量
        BigDecimal palletQty = sfcPalletInfoDtos.stream().map(SfcPalletInfoDto::getSnQty)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        SfcPalletInfoDto sfcPalletInfoDto = sfcPalletInfoDtos.get(0);
        //栈板号
        String palletNo = sfcPalletInfoDto.getPalletNo();
        judgePkgIdLength(palletNo);
        //成品料号
        String productPartNo = sfcPalletInfoDto.getProductPartNo();
        //根据栈板号作为pkgid查找条码信息,判断是否存在
        WmsPkgInfo wmsPkgInfoDb = wmsPkgInfoMapper.selectOne(Wrappers.<WmsPkgInfo>lambdaQuery()
                .eq(WmsPkgInfo::getPkgId, palletNo)
                .eq(WmsPkgInfo::getOrgCode, orgCode)
                .last("limit 1"));
        if (ObjectUtil.isNotNull(wmsPkgInfoDb)) {
            if (wmsPkgInfoDb.getCurrentQty().compareTo(BigDecimal.ZERO) > 0) {
                throw new Exception("栈板已入库");
            }
            wmsPkgInfoDb.setPkgId(palletNo + "-" + "DEL" + RandomUtil.randomInt(4));
            wmsPkgInfoMapper.updateById(wmsPkgInfoDb);
        }
        String plantCode = StrUtil.EMPTY;
        String sapWarehouseCode = StrUtil.EMPTY;
        String partNoVersion = StrUtil.EMPTY;
        List<InStorageWoDTO> inStorageWoDTOList = CollUtil.newArrayList();
        Map<String, List<SfcPalletInfoDto>> collect = sfcPalletInfoDtos.stream()
                .collect(Collectors.groupingBy(SfcPalletInfoDto::getWorkerOrderNo));
        List<String> workOrderNoList = CollUtil.newArrayList();
        for (Map.Entry<String, List<SfcPalletInfoDto>> entry : collect.entrySet()) {
            InStorageWoDTO inStorageWoDTO = new InStorageWoDTO();
            String workOrderNo = entry.getKey();
            WmsWorkOrderHeader wmsWorkOrderHeaderDb = wmsWorkOrderHeaderMapper
                    .selectOne(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                            .eq(WmsWorkOrderHeader::getWorkOrderNo, workOrderNo)
//                            .eq(WmsWorkOrderHeader::getPartNo, productPartNo)
                            .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                            .last("limit 1"));
            if (ObjectUtil.isNull(wmsWorkOrderHeaderDb)) {
                throw new Exception("工单信息不存在");
            }
            if (!productPartNo.equals(wmsWorkOrderHeaderDb.getPartNo())) {
                throw new Exception("SFC成品料号与工单成品料号不匹配");
            }
            if ("ASSY".equals(wmsWorkOrderHeaderDb.getProcessType())
                    && "CLOSE".equals(wmsWorkOrderHeaderDb.getWorkOrderStatus())) {
                throw new Exception("工单是组装类型且是CLOSE状态，不能入库");
            }
            plantCode = wmsWorkOrderHeaderDb.getPlantCode();
            sapWarehouseCode = wmsWorkOrderHeaderDb.getStorageLocation();
            partNoVersion = wmsWorkOrderHeaderDb.getPartVersion();
            List<SfcPalletInfoDto> palletInfoDtoList = entry.getValue();
            BigDecimal totalSnQty = palletInfoDtoList.stream().map(SfcPalletInfoDto::getSnQty)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
            //工单需求数量
            BigDecimal workOrderQty = wmsWorkOrderHeaderDb.getWorkOrderQty();
            //工单入库数量
            BigDecimal inboundQty = wmsWorkOrderHeaderDb.getInboundQty();
            //工单需求数量-工单已入库数量
            BigDecimal subtract = workOrderQty.subtract(inboundQty);
            if (totalSnQty.compareTo(subtract) > 0) {
                throw new Exception("入库数量必须小于等于(工单需求数量-工单入库数量)");
            }
            List<WmsPkgSfcInfoEntity> wmsPkgSfcInfoList = CollUtil.newArrayList();
            //同步pallet信息到WmsPkgSfcInfo
            for (SfcPalletInfoDto palletInfoDto : palletInfoDtoList) {
                WmsPkgSfcInfoEntity wmsPkgSfcInfo = new WmsPkgSfcInfoEntity();
                wmsPkgSfcInfo.setOrgCode(orgCode);
                wmsPkgSfcInfo.setPalletNo(palletNo);
                wmsPkgSfcInfo.setCartonNo(palletInfoDto.getCartonNo());
                wmsPkgSfcInfo.setSnNo(palletInfoDto.getSnNo());
                wmsPkgSfcInfo.setQty(palletInfoDto.getSnQty());
                wmsPkgSfcInfo.setWorkerOrderNo(workOrderNo);
                wmsPkgSfcInfo.setMfgPartNo(palletInfoDto.getProductPartNo());
                wmsPkgSfcInfo.setUomCode(wmsWorkOrderHeaderDb.getUomCode());
                wmsPkgSfcInfo.setPartNo(palletInfoDto.getProductPartNo());
                wmsPkgSfcInfo.setPlantCode(plantCode);
                wmsPkgSfcInfo.setInStorageType("BY_PALLET");
                wmsPkgSfcInfo.setCreator("sysadmin");
                wmsPkgSfcInfo.setCreatedDt(LocalDateTime.now());
                wmsPkgSfcInfoList.add(wmsPkgSfcInfo);
            }
            wmsPkgSfcInfoService.saveBatch(wmsPkgSfcInfoList);
            //更新工单已入库数量
            wmsWorkOrderHeaderDb.setInboundQty(inboundQty.add(totalSnQty));
            wmsWorkOrderHeaderMapper.updateById(wmsWorkOrderHeaderDb);
            inStorageWoDTO.setWorkOrderNo(workOrderNo);
            inStorageWoDTO.setInBoundQty(totalSnQty);
            inStorageWoDTOList.add(inStorageWoDTO);
            workOrderNoList.add(workOrderNo);
        }
        //找到载具可用储位
        RecommendDTO recommendDTO = recommendBin(vehicleCode, binCode, orgCode, productPartNo);
        //palletNo上架
        WmsPkgInfo wmsPkgInfo = new WmsPkgInfo();
        wmsPkgInfo.setOrgCode(orgCode);
        wmsPkgInfo.setPkgId(palletNo);
        wmsPkgInfo.setPlantCode(plantCode);
        wmsPkgInfo.setSapWarehouseCode(sapWarehouseCode);
        wmsPkgInfo.setLocationCode(recommendDTO.getLocationCode());
        wmsPkgInfo.setBinCode(recommendDTO.getBinCode());
        wmsPkgInfo.setVehicleCode(vehicleCode);
        wmsPkgInfo.setPartNo(productPartNo);
        wmsPkgInfo.setPartVersion(partNoVersion);
        wmsPkgInfo.setOriginalQty(palletQty);
        wmsPkgInfo.setCurrentQty(palletQty);
        wmsPkgInfo.setDateCode(LocalDate.now());
        wmsPkgInfo.setOriginalDateCode(DateTimeFormatter.ofPattern("yyyy-MM-dd").format(LocalDate.now()));
        wmsPkgInfo.setLotCode(DateTimeFormatter.ofPattern("yyyy/MM/dd").format(LocalDate.now()));
        wmsPkgInfo.setShelfDate(LocalDateTime.now());
        wmsPkgInfo.setMfgPartNo(productPartNo);
        wmsPkgInfo.setSupplierPartNo(productPartNo);
        wmsPkgInfo.setMfgName("FOXCONN");
        wmsPkgInfo.setEffectiveDate(720);
        wmsPkgInfo.setEndDate(LocalDate.now().plusDays(720));
        wmsPkgInfo.setTransactionType("PRODUCT_IN_STORAGE");
        wmsPkgInfo.setTransactionMessage(StrUtil.join(",", workOrderNoList));
        wmsPkgInfo.setAreaCode(productInStorageVO.getAreaCode());
        wmsPkgInfo.setInStorageWorkOrder(JSONUtil.toJsonStr(inStorageWoDTOList));
        wmsPkgInfo.setInventoryAgeLastChangeDate(LocalDateTime.now());
        wmsPkgInfoMapper.insert(wmsPkgInfo);
        //上架记录计入条码履历
        WmsPkgInfoLog wmsPkgInfoLog = new WmsPkgInfoLog();
        BeanUtils.copyProperties(wmsPkgInfo, wmsPkgInfoLog);
        wmsPkgInfoLog.setId(null);
        wmsPkgInfoLogMapper.insert(wmsPkgInfoLog);
        return ProductInStorageDTO.builder()
                .locationCode(recommendDTO.getLocationCode())
                .binCode(recommendDTO.getBinCode())
                .palletNo(palletNo)
                .qty(palletQty)
                .inStorageWoDTOList(inStorageWoDTOList)
                .partNo(productPartNo)
                .vehicleCode(vehicleCode)
                .build();
    }

    private List<SfcPalletInfoDto> getSfcPalletInfoDtos(String orgCode, String barCode, String plantCode) {
        InStoreFeignDTO inStoreFeignDTO = new InStoreFeignDTO();
        inStoreFeignDTO.setBarcode(barCode);
        inStoreFeignDTO.setOrgCode(orgCode);
        System.out.println("get mes pallet content :" + JSONUtil.toJsonStr(inStoreFeignDTO));
        HttpResponse response = mesService.getInstoreProduct(inStoreFeignDTO);
        String body = response.body();
        if (StrUtil.isEmpty(body)) {
            System.out.println("mes pallet error");
        }
        List<SfcPalletInfoDto> sfcPalletInfoDtoList = CollUtil.newArrayList();
        if (response.getStatus() == HttpStatus.HTTP_OK) {
            JSONObject mesReturnInfo = JSONUtil.parseObj(body);
            String code = mesReturnInfo.getStr("code");
            if (StringUtils.isNotBlank(code) && "200".equalsIgnoreCase(code)) {
                sfcPalletInfoDtoList = JSONUtil.toList(JSONUtil.parseArray(mesReturnInfo.get("data")), SfcPalletInfoDto.class);
                System.out.println(sfcPalletInfoDtoList);
            }
        }
        long count = sfcPalletInfoDtoList.stream().filter(ObjectUtil::isNull).count();
        if (count > 0) {
            return CollUtil.newArrayList();
        }
        return sfcPalletInfoDtoList;
    }

    public void judgePkgIdLength(String pkgId) throws Exception {
        //判断条码长度不能小于10码
        if (pkgId.length() < 10) {
            throw new Exception("条码长度不能小于10码");
        }
    }

    public RecommendDTO recommendBin(String vehicleCode, String binCode, String orgCode, String partNo) throws Exception {
        WmsVehicle wmsVehicleDb = wmsVehicleMapper.selectOne(Wrappers.<WmsVehicle>lambdaQuery()
                .eq(WmsVehicle::getVehicleCode, vehicleCode)
                .eq(WmsVehicle::getOrgCode, orgCode));
        if (ObjectUtil.isNull(wmsVehicleDb)) {
            throw new Exception("载具编码不存在");
        }
        //库位编码
        String locationCode = wmsVehicleDb.getLocationCode();
        //推荐储位
        WmsBin recommendBin = null;
        //查询载具,储位对应的已启用的储位信息,如果储位值不为空,则找到储位中大于等于该储位上是否有空储位
        List<WmsBin> wmsBinDbList = wmsBinMapper.selectList(Wrappers.<WmsBin>lambdaQuery()
                .eq(WmsBin::getVehicleCode, vehicleCode)
                .eq(WmsBin::getOrgCode, orgCode)
                .ge(StrUtil.isNotEmpty(binCode), WmsBin::getBinCode, binCode)
                .eq(WmsBin::getIsEnable, Boolean.TRUE));
        //找到可用储位
        List<WmsBin> emptyBinList = getAvailableWmsBins(vehicleCode, orgCode, wmsBinDbList, partNo);
        //若可用储位不为空
        if (CollUtil.isNotEmpty(emptyBinList)) {
            //获取推荐的最小储位编码
            recommendBin = emptyBinList.stream()
                    .min(Comparator.comparing(WmsBin::getBinCode))
                    .orElse(null);
        } else {
            //如果后置储位没有可用储位,找到前置储位是否有可用储位
            if (StrUtil.isNotEmpty(binCode)) {
                List<WmsBin> wmsBinDbs = wmsBinMapper.selectList(Wrappers.<WmsBin>lambdaQuery()
                        .eq(WmsBin::getVehicleCode, vehicleCode)
                        .eq(WmsBin::getOrgCode, orgCode)
                        .lt(WmsBin::getBinCode, binCode)
                        .eq(WmsBin::getIsEnable, Boolean.TRUE));
                List<WmsBin> emptyBins = getAvailableWmsBins(vehicleCode, orgCode, wmsBinDbs, partNo);
                //获取推荐的最小储位编码
                recommendBin = emptyBins.stream()
                        .min(Comparator.comparing(WmsBin::getBinCode))
                        .orElse(null);
            }
        }
        if (ObjectUtil.isNull(recommendBin)) {
            throw new Exception("该载具下没有可用储位");
        }
        return RecommendDTO.builder()
                .binCode(recommendBin.getBinCode())
                .locationCode(locationCode)
                .build();
    }

    private List<WmsBin> getAvailableWmsBins(String vehicleCode, String orgCode, List<WmsBin> wmsBinDbList,
                                             String partNo) {
        List<WmsPkgInfo> wmsPkgInfoList = wmsPkgInfoMapper.selectUsedPkgInfos(vehicleCode, orgCode);
        return wmsBinDbList.stream().filter(wmsBin -> {
            //料号个数
            Integer materialCount = wmsBin.getMaterialCount();
            //pkgId个数
            Integer pkgIdCount = wmsBin.getPkgIdCount();
            //判断储位是否已满
            List<WmsPkgInfo> wmsPkgInfos = wmsPkgInfoList.stream()
                    .filter(wmsPkgInfo -> wmsBin.getBinCode().equals(wmsPkgInfo.getBinCode()))
                    .collect(Collectors.toList());
            long pkgCount = wmsPkgInfos.stream().map(WmsPkgInfo::getPkgId).distinct().count();
//            long partNoCount = wmsPkgInfos.stream().map(WmsPkgInfo::getPartNo).distinct().count();
            //判断料号种类是否符合要求
            List<String> partNoList = wmsPkgInfos.stream().map(WmsPkgInfo::getPartNo).distinct()
                    .collect(Collectors.toList());
            int partNoCount = CollUtil.isNotEmpty(partNoList) ? !partNoList.contains(partNo) ?
                    partNoList.size() + 1 : partNoList.size() : partNoList.size();
            if (pkgIdCount > (int) pkgCount && materialCount >= partNoCount) {
                return Boolean.TRUE;
            }
            return Boolean.FALSE;
        }).collect(Collectors.toList());
    }
}
