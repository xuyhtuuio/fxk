package com.maxnerva.cloudmes.entity.doc;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

/**
 * <p>
 * 收货SN清单信息
 * </p>
 *
 * @author likun
 * @since 2024-09-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsReceiveSnList对象", description="收货SN清单信息")
public class WmsReceiveSnList extends BaseEntity<WmsReceiveSnList> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "组织")
    private String orgCode;

    @ApiModelProperty(value = "来源单号")
    private String fromDocNo;

    @ApiModelProperty(value = "来源项次")
    private String fromDocItem;

    @ApiModelProperty(value = "sn")
    private String snNo;

    @ApiModelProperty(value = "料号")
    private String partNumber;

    @ApiModelProperty(value = "版次")
    private String partRev;

    @ApiModelProperty(value = "厂商")
    private String vendor;

    @ApiModelProperty(value = "厂商料号")
    private String vendorPn;

    @ApiModelProperty(value = "是否抛给MES")
    private String postMesFlag;

    @ApiModelProperty(value = "抛MES时间")
    private LocalDateTime postMesDt;
}
