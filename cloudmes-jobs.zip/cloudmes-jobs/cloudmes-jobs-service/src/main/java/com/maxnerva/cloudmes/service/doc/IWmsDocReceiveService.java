package com.maxnerva.cloudmes.service.doc;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.entity.doc.WmsDocReceive;

/**
 * <p>
 * 单据表 服务类
 * </p>
 *
 * @author likun
 * @since 2022-09-29
 */
public interface IWmsDocReceiveService extends IService<WmsDocReceive> {

}
