package com.maxnerva.cloudmes.service.datahub.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("查询PrepareCkdShipDetailVO")
public class ReWriteSyncReceiveStatusVO {

    @ApiModelProperty("id")
    private Integer id;

    @ApiModelProperty("收货单号")
    private String receiveDocNo;

    @ApiModelProperty("同步收货单结果：0：失败，1：成功")
    private String syncReceiveDocFlag;

    @ApiModelProperty("同步收货单结果描述")
    private String syncReceiveDocMsg;
}
