package com.maxnerva.cloudmes.entity.doc;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @Author hgx
 * @Description JIT收货单
 * @Date 2023/3/17 16:26
 */
@Data
public class WmsDocJitReceiveRecord extends BaseEntity<WmsDocJitReceiveRecord> {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "BU")
    private String plantCode;

    private Integer receiptType;

    private String receiptNumber;

    private String receiptItem;

    private String supplierName;

    private String partNo;

    private String poNumber;

    private String poItem;

    private BigDecimal qty;

    private String unit;

    private String customer;

    private String vendor;

    private String type;

    private String asnDate;

    private String dnNo;

    private String dnItem;

    private String companyCode;

    @ApiModelProperty(value = "建单标识(Y-成功 N-失败)")
    private String docCreateFlag;

    @ApiModelProperty(value = "建单信息")
    private String docCreateMsg;

    @ApiModelProperty(value = "料号版次")
    private String partVersion;

    @ApiModelProperty(value = "采购单号文件类型")
    private String poDocumentType;

    @ApiModelProperty(value = "采购员组")
    private String purchaseGroup;

    @ApiModelProperty(value = "采购员org")
    private String purchaseOrg;

    @ApiModelProperty(value = "制造商编码")
    private String mfgCode;

    @ApiModelProperty(value = "制造商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "制造商名称")
    private String mfgName;

    @ApiModelProperty(value = "仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "解析后POITEM")
    private String analysisPoItem;

}
