package com.maxnerva.cloudmes.mapper.wo;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderDetail;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderHeader;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.math.BigDecimal;
import java.util.List;

/**
 * <p>
 * 工单detail信息表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2022-08-30
 */
public interface WmsWorkOrderDetailMapper extends BaseMapper<WmsWorkOrderDetail> {

    /**
     * wo detail 需过账261的记录
     * 群组中消耗量汇总大于工单需求量
     *
     * @param wrapper
     * @return
     */
    @Select("select  work_order_no ,work_order_item ,sum(required_quantity) as  required_quantity ,sum(post_to311_qty) as post_to311_qty ,sum(consume_qty) as consume_qty,sum(post_to261_qty) as " +
            "post_to261_qty from wms_work_order_detail  ${ew.customSqlSegment} group by  work_order_no,work_order_item having sum(consume_qty) > sum(post_to261_qty)")
    List<WmsWorkOrderDetail> woNeedToPosting261(@Param(Constants.WRAPPER) LambdaQueryWrapper<WmsWorkOrderDetail> wrapper);

    /**
     * 新增工单detail信息
     *
     * @param workOrderDetail
     * @return
     */
    int insertWoDetailInfo(WmsWorkOrderDetail workOrderDetail);

    /**
     * @param wmsWorkOrderHeader
     * @return
     */
    int updateWoDetailMaterialType(WmsWorkOrderHeader wmsWorkOrderHeader);


    /**
     * wo detail 需过账261的记录组装端工单
     * PTH
     *
     * @return
     */
    @Select("select stock_qty ,post_to261_qty ,* from wms_work_order_detail wwod  where org_code = #{orgCode} and part_no  in  (select distinct  spare_part_no  from wms_bom_feeder " +
            "wbf where org_code = #{orgCode} and product_process  ='PTH') and  stock_qty > post_to261_qty ")
    List<WmsWorkOrderDetail> woNeedToPosting261PTH(@Param("orgCode") String orgCode);

    /**
     * 工单群组备料总量
     *
     * @return
     */
    @Select("select work_order_no,work_order_item ,sum(stock_qty) stock_total_qty,sum(required_pkg_qty)  required_pkg_qty ,sum(pick_qty)  pick_total_qty ,sum(pick_pkg_qty)  pick_pkg_total_qty  from wms_work_order_detail  ${ew.customSqlSegment} group by work_order_no,work_order_item")
    List<WmsWorkOrderDetail> woItemStockTotalQty(@Param(Constants.WRAPPER) LambdaQueryWrapper<WmsWorkOrderDetail> wrapper);

    BigDecimal getQty(@Param("workOrderNo") String workOrderNo,
                      @Param("workOrderItem") String workOrderItem,
                      @Param("partNo") String partNo);

    List<WmsWorkOrderDetail> select311deatil(@Param("orgCode") String orgCode);

    int updateMatrerialType(@Param("orgCode") String orgCode, @Param("workOrderNo") String workOrderNo);

    int updateMatrerialTypeToA(@Param("orgCode") String orgCode, @Param("workOrderNo") String workOrderNo);

    int updatePurchaseOrg(@Param("orgCode") String orgCode, @Param("workOrderNo") String workOrderNo);

    int updateJitMaterialFlag(@Param("orgCode") String orgCode,
                              @Param("workOrderNo") String workOrderNo,
                              @Param("purchaseOrgList") List<String> purchaseOrgList);

    List<String> selectPartNoList(@Param("orgCode") String orgCode, @Param("workOrderNo") String workOrderNo);

    int updatePartNoUseFlagAndDeleteItem(@Param("orgCode") String orgCode,
                                         @Param("workOrderNo") String workOrderNo,
                                         @Param("partNoList") List<String> partNoList);


    int updateAmScanModeAndMaterialGroup(@Param("orgCode") String orgCode,
                                         @Param("workOrderNo") String workOrderNo);

    List<WmsWorkOrderDetail> selectAmUpdateWoDetailInfo(@Param("orgCode") String orgCode);

    int updateAmWoDetailInfo(@Param("id") Integer id,
                             @Param("lossRatio") BigDecimal lossRatio);

    int update261WorkOrderDetailInfo(@Param("id") Integer id,
                                     @Param("valueType")String valueType,
                                     @Param("postTo261ReturnMsg")String postTo261ReturnMsg,
                                     @Param("postTo261Qty") BigDecimal postTo261Qty);

    List<WmsWorkOrderDetail> selectMixWoDetail(@Param("orgCode") String orgCode,
                                               @Param("workOrderNo") String workOrderNo);

    int updateMixWoDetail(@Param("orgCode") String orgCode,
                          @Param("workOrderNo") String workOrderNo);
}
