package com.maxnerva.cloudmes.service.basic;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.entity.basic.WmsPlantCustomerConfig;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author likun
 * @since 2023-09-25
 */
public interface IWmsPlantCustomerConfigService extends IService<WmsPlantCustomerConfig> {

}
