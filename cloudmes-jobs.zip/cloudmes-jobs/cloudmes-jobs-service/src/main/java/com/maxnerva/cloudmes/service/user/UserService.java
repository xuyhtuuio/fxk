package com.maxnerva.cloudmes.service.user;

import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/11/09 10:32
 * @Version: 1.0
 */
@Service
@Slf4j
public class UserService {

    @Value("${cloudmes.service.url}")
    private String serviceUrl;

    @Value("${cloudmes.service.copeCode:F_TJ}")
    private String copeCode;

    @Value("${cloudmes.service.loginType:1}")
    private int loginType;

    @Value("${cloudmes.service.username:qms_sync}")
    private String username;

    @Value("${cloudmes.service.password:123456}")
    private String password;


    public Map<String,String> getUserToken() {

        Map userDto = new HashMap();
        userDto.put("copeCode", copeCode);
        userDto.put("loginType", loginType);
        userDto.put("username", username);
        userDto.put("password", password);

        String url = serviceUrl + "/platform-user/platform/login";
        Map<String,String> headers = new HashMap<>();
        String uuid = UUID.randomUUID().toString();
        headers.put("uuid", uuid);
        HttpResponse response = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .header("uuid",uuid)
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(userDto))
                .execute();

        String body = response.body();

        JSONObject userInfo = JSONUtil.parseObj(body);

        String code = userInfo.getStr("code");
        if (StringUtils.isNotBlank(code) && "200".equalsIgnoreCase(code)) {
            String token = userInfo.getJSONObject("data").getStr("accessToken");
            headers.put("token", token);
            return headers;
        }

        return headers;


    }
}
