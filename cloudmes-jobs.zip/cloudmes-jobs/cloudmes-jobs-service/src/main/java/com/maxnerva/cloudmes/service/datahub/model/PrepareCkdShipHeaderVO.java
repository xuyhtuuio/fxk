package com.maxnerva.cloudmes.service.datahub.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
@ApiModel("查询PrepareCkdShipHeaderVO")
public class PrepareCkdShipHeaderVO {

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("创建PO：未抛：0，已抛：1")
    private String poPostSapFlag;

    @ApiModelProperty("创建DN/SO：未抛：0，已抛：1")
    private String dnPostSapFlag;

    @ApiModelProperty("同步收货单：未抛：0，已抛：1")
    private String syncReceiveDocFlag;

    @ApiModelProperty("是否收货：否：0，是：1")
    private String shipFlag;
}
