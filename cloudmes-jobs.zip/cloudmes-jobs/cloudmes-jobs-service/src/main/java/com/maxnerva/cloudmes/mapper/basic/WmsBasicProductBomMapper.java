package com.maxnerva.cloudmes.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.basic.WmsBasicProductBom;

/**
 * <p>
 * 同步basic产品bom表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2024-12-23
 */
public interface WmsBasicProductBomMapper extends BaseMapper<WmsBasicProductBom> {

}
