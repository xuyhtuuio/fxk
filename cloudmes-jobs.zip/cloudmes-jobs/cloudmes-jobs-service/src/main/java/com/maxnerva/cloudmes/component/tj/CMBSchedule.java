package com.maxnerva.cloudmes.component.tj;

import com.maxnerva.cloudmes.service.basic.PostingConfigService;
import com.maxnerva.cloudmes.service.doc.AdjustDocPostingService;
import com.maxnerva.cloudmes.service.doc.CostDocPostingService;
import com.maxnerva.cloudmes.service.doc.ReceiveDocPostingService;
import com.maxnerva.cloudmes.service.doc.TransferDocPostingService;
import com.maxnerva.cloudmes.service.jusda.JusdaService;
import com.maxnerva.cloudmes.service.outsourcing.IWmsOutsourcingSapTransactionLogService;
import com.maxnerva.cloudmes.service.sfc.PostingSfcService;
import com.maxnerva.cloudmes.service.wo.WoPostingNewModeService;
import com.sap.conn.jco.JCoException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Arrays;

/**
 * @author H7109018
 */
@ConditionalOnProperty(value = "cope.code", havingValue = "F_TJ")
@Component
@EnableScheduling
@Slf4j
public class CMBSchedule {

    private static final String ORG_CODE = "CMB";
    private static final String SAP_CLIENT_CODE = "sap";
    private static final String DATE_FORMAT = "yyyyMMdd";
    private static String postDate = "N";

    @Autowired
    CostDocPostingService costDocPostingService;

    @Autowired
    PostingConfigService postingConfigService;

    @Autowired
    ReceiveDocPostingService docPostingService;

    @Autowired
    WoPostingNewModeService woPostingNewModeService;

    @Autowired
    AdjustDocPostingService adjustDocPostingService;

    @Autowired
    TransferDocPostingService transferDocPostingService;

    @Autowired
    IWmsOutsourcingSapTransactionLogService wmsOutsourcingSapTransactionLogService;

    @Autowired
    PostingSfcService postingSfcService;

    @Autowired
    JusdaService jusdaService;

    /**
     * 修改过账时间
     * 频率：10分钟执行一次
     */
    @Scheduled(initialDelay = 5000, fixedDelay = 300000)
    public void updatePostDate() {
        String s = postingConfigService.getPostDate(ORG_CODE, null);
        postDate = s;
    }


    /**
     * 费领退及报废单过账SAP
     * 频率：5分钟执行一次
     */
    @Scheduled(initialDelay = 31000, fixedDelay = 600000)
    public void costDocPostingService() {
        log.info("costCMBDocPostingService start :" + System.currentTimeMillis());
        costDocPostingService.costDocTransferPosting(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("costCMBDocPostingService end :" + System.currentTimeMillis());
    }

    /**
     * 内交单过账
     */
    @Scheduled(initialDelay = 190000, fixedDelay = 600000)
    public void tradingPosting() {
        log.info("getTradingCMBStatus start :" + System.currentTimeMillis());
        String s = postingConfigService.getTradingStatus(ORG_CODE, null);
        log.info("getTradingCMBStatus status :" + s);
        log.info("getTradingCMBStatus end :" + System.currentTimeMillis());
        if ("N".equalsIgnoreCase(s)) {
            return;
        }
        //内交出过账
        log.info("tradingPosting start :" + System.currentTimeMillis());
        docPostingService.tradingPosting(ORG_CODE, postDate);
        log.info("tradingPosting end :" + System.currentTimeMillis());

        //PGI
        log.info("tradingPosting start :" + System.currentTimeMillis());
        docPostingService.tradingPGI(ORG_CODE, postDate);
        log.info("tradingPosting end :" + System.currentTimeMillis());

        //内交入过账
        log.info("doTradingInPosting start :" + System.currentTimeMillis());
        docPostingService.doTradingInPosting(ORG_CODE, postDate);
        log.info("doTradingInPosting end :" + System.currentTimeMillis());
    }

    /**
     * 收货单据确认收货后转良品仓待验状态
     */
    @Scheduled(initialDelay = 150000, fixedDelay = 900000)
    public void postingToBeInspected() {
        log.info("postingToBeInspected start :" + System.currentTimeMillis());
        docPostingService.docPostingToBeInspected(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("postingToBeInspected end :" + System.currentTimeMillis());
    }

    /**
     * 收货单据，QMS有返回结果后转良品仓良品状态
     */
    @Scheduled(initialDelay = 160000, fixedDelay = 900000)
    public void postingGoodProductStatus() {
        log.info("postingGoodProductStatus start :" + System.currentTimeMillis());
        docPostingService.docPostingGoodProductStatus(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("postingGoodProductStatus end :" + System.currentTimeMillis());
    }

    /**
     * 收货单据确认且不需要抛Q需要过账的直接入良品仓良品状态
     */
    @Scheduled(initialDelay = 140000, fixedDelay = 900000)
    public void docPostingToGoodProduct() {
        log.info("docPostingToGoodProduct start :" + System.currentTimeMillis());
        docPostingService.docPostingToGoodProduct(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("docPostingToGoodProduct end :" + System.currentTimeMillis());
    }

    /**
     * 工单备料量过账261
     * 频率：10分钟执行一次
     */
    @Scheduled(initialDelay = 15000, fixedDelay = 600000)
    public void postingWoDetail261NewModeTest() {
        //工单备料量过账261
        log.info("postingWoDetail261NewModeTest start :" + System.currentTimeMillis());
        woPostingNewModeService.postingWoDetail261NewMode(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoDetail261NewModeTest end :" + System.currentTimeMillis());

        //工单退料量过账262
        log.info("postingWoDetail262NewModeTest start :" + System.currentTimeMillis());
        woPostingNewModeService.postingWoDetail262NewMode(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoDetail262NewModeTest end :" + System.currentTimeMillis());

        //重工工单过账SAP 531
        log.info("postingWoDetail531NewMode start :" + System.currentTimeMillis());
        woPostingNewModeService.postingWoDetail531NewMode(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoDetail531NewMode end :" + System.currentTimeMillis());
    }

    /**
     * 工单成品入库 101
     * 频率：10分钟执行一次
     */
    @Scheduled(initialDelay = 16000, fixedDelay = 600000)
    public void postingWoHeader101Test() {
        log.info("postingCmbWoHeader101Test start :" + System.currentTimeMillis());
        woPostingNewModeService.postingCmbWoHeader101(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingCmbWoHeader101Test end :" + System.currentTimeMillis());
    }

    /**
     * 料调单过账
     */
    @Scheduled(initialDelay = 120000, fixedDelay = 600000)
    public void docAdjustPosting() {
        log.info("docAdjustPosting start :" + System.currentTimeMillis());
        adjustDocPostingService.docAdjustPosting(SAP_CLIENT_CODE, ORG_CODE, Arrays.asList("5"), postDate);
        log.info("docAdjustPosting end :" + System.currentTimeMillis());
    }

    /**
     * 转仓单过账
     */
    @Scheduled(initialDelay = 130000, fixedDelay = 900000)
    public void docTransferPosting() {
        log.info("docTransferPosting start :" + System.currentTimeMillis());
        transferDocPostingService.docTransferPosting(SAP_CLIENT_CODE, ORG_CODE, Arrays.asList("5"), postDate);
        log.info("docTransferPosting end :" + System.currentTimeMillis());
    }

    /**
     * CMB委外备料过账
     */
    @Scheduled(initialDelay = 200000, fixedDelay = 600000)
    public void doCmbBatchTransferOutsourcingPosted(){
        log.info("doCmbBatchTransferOutsourcingPosted start :" + System.currentTimeMillis());
        wmsOutsourcingSapTransactionLogService.doBatchTransferOutsourcingPosted(SAP_CLIENT_CODE,ORG_CODE,"");
        log.info("doCmbBatchTransferOutsourcingPosted end :" + System.currentTimeMillis());
    }

    /**
     * 回写DN、SN的绑定关系
     */
//    @Scheduled(initialDelay = 170000, fixedDelay = 600000)
    public void sendSnDnRelationshipToSfc() {
        log.info("cmbSendSnDnRelationshipToSfcStart :" + System.currentTimeMillis());
        postingSfcService.sendSnDnRelationshipToSfc(ORG_CODE);
        log.info("cmbSendSnDnRelationshipToSfcEnd:" + System.currentTimeMillis());
    }

    @Scheduled(initialDelay = 220000, fixedDelay = 600000)
    public void test() {
        log.info("cmbTestStart :" + System.currentTimeMillis());
        log.info("cmbTesteEnd:" + System.currentTimeMillis());
    }

    /**
     * 委外收货单过账
     */
    @Scheduled(initialDelay = 180000, fixedDelay = 600000)
    public void outsourcingPosting() throws JCoException {
        log.info("outsourcingPosting start :" + System.currentTimeMillis());
        docPostingService.outsourcingPosting(ORG_CODE, postDate);
        log.info("outsourcingPosting end :" + System.currentTimeMillis());
    }

    /**
     * jusda VMI 收货过账SAP
     */
    @Scheduled(initialDelay = 110000, fixedDelay = 600000)
    public void jusdaReceiveInfoPostingSAP() {
        log.info("jusdaReceiveInfoPostingSAP start :" + System.currentTimeMillis());
        jusdaService.jusdaReceiveInfoPostingSAP(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("jusdaReceiveInfoPostingSAP end:" + System.currentTimeMillis());
    }

    /**
     * 转仓收货单，依据Q的结果判断是否需要转不良品仓
     */
    @Scheduled(initialDelay = 300000, fixedDelay = 900000)
    public void docTransferReceiveToRejectsWarehouse() {
        log.info("docTransferReceiveToRejectsWarehouse start :" + System.currentTimeMillis());
        docPostingService.docTransferReceiveToRejectsWarehouse(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("docTransferReceiveToRejectsWarehouse end :" + System.currentTimeMillis());
    }

    /**
     * 961过账
     */
    @Scheduled(initialDelay = 21000, fixedDelay = 600000)
    public void postingWoDetail961Mode(){
        log.info("postingWoDetail961Mode start :" + System.currentTimeMillis());
        woPostingNewModeService.postingWoDetail961Mode(ORG_CODE,SAP_CLIENT_CODE,postDate);
        log.info("postingWoDetail961Mode end :" + System.currentTimeMillis());
    }

    /**
     * 工单备料PKG信息抛SFC
     */
    @Scheduled(initialDelay = 90000, fixedDelay = 300000)
    public void postingWoPreparePkgInfoToSFC() {
        log.info("postingWoPreparePkgInfoToSFC start :" + System.currentTimeMillis());
        postingSfcService.postingWoPreparePkgInfoToSFC(ORG_CODE);
        log.info("postingWoPreparePkgInfoToSFC end:" + System.currentTimeMillis());
    }

    @Scheduled(initialDelay = 90000, fixedDelay = 600000)
    public void containerDnPostSfc() {
        log.info("containerDnPostSfc start :" + System.currentTimeMillis());
        postingSfcService.containerDnPostSfc(ORG_CODE);
        log.info("containerDnPostSfc end:" + System.currentTimeMillis());
    }
}
