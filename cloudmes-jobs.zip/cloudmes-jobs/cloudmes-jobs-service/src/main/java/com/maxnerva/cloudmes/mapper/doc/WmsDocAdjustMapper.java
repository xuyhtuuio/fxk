package com.maxnerva.cloudmes.mapper.doc;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.doc.WmsDocAdjust;


/**
 * @author H7109018
 */
public interface WmsDocAdjustMapper extends BaseMapper<WmsDocAdjust> {

}
