package com.maxnerva.cloudmes.controller;

import cn.hutool.core.util.StrUtil;
import com.maxnerva.cloudmes.entity.wo.WmsBomFeeder;
import com.maxnerva.cloudmes.entity.wo.syncBomFeederFromSfcVO;
import com.maxnerva.cloudmes.service.jusda.JusdaService;
import com.maxnerva.cloudmes.service.prepare.wo.WoService;
import com.maxnerva.cloudmes.service.sfc.SfcStoredProcedureFactory;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Author hgx
 * @Description 工单接口(新)
 * @Date 2023/5/19
 */
@Api(tags = "工单接口(新)")
@Slf4j
@RestController
@RequestMapping("/wo")
public class WoController {

    @Resource
    private JusdaService jusdaService;
    @Resource
    private SfcStoredProcedureFactory sfcStoredProcedureFactory;

    @ApiOperation(value = "同步上料表")
    @GetMapping("/syncBomFeederFromSfc")
    public List<WmsBomFeeder> syncBomFeederFromSfc(@RequestParam(value = "sfcSite", required = true) String sfcSite,
                                                   @RequestParam(value = "partNo", required = true) String partNo,
                                                   @RequestParam(value = "lineNo", required = true) String lineNo) {
        log.info("syncWorkInfo start :" + System.currentTimeMillis());
        syncBomFeederFromSfcVO syncBomFeederFromSfcVO = new syncBomFeederFromSfcVO();
        syncBomFeederFromSfcVO.setSfcSite(sfcSite);
        syncBomFeederFromSfcVO.setLineNo(lineNo);
        syncBomFeederFromSfcVO.setPartNo(partNo);
        List<WmsBomFeeder> sfcBomFeederList = sfcStoredProcedureFactory.getWmsBomFeeder(syncBomFeederFromSfcVO.getSfcSite(),
                syncBomFeederFromSfcVO.getPartNo(), syncBomFeederFromSfcVO.getLineNo(), null,
                StrUtil.EMPTY, StrUtil.EMPTY);

        log.info("syncWorkInfo end :" + System.currentTimeMillis());
        return sfcBomFeederList;
    }

    /**
     * ASN上传抛JUSDA
     * 频率：10分钟执行一次
     */
    @ApiOperation("ASN上传抛JUSDA")
    @GetMapping("/wmsAsnPostJusda")
    public void asnPostJusda(@RequestParam("orgCode") String orgCode,
                             @RequestParam("postJusdaFlag") String postJusdaFlag) {
        log.info("ASN param postJusdaFlag：{}", postJusdaFlag);
        jusdaService.asnPostJusda(orgCode, postJusdaFlag);
    }

}
