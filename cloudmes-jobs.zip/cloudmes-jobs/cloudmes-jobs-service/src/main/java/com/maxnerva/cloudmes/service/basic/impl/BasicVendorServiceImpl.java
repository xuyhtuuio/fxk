package com.maxnerva.cloudmes.service.basic.impl;


import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.entity.basic.BasicVendor;
import com.maxnerva.cloudmes.mapper.basic.BasicVendorMapper;
import com.maxnerva.cloudmes.service.basic.IBasicVendorService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author ChaoZhang
 * @since 2021-06-09
 */
@Service
public class BasicVendorServiceImpl extends ServiceImpl<BasicVendorMapper, BasicVendor> implements IBasicVendorService {

}
