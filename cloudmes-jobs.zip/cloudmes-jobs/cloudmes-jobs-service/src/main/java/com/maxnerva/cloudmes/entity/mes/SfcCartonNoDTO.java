package com.maxnerva.cloudmes.entity.mes;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * @author hej
 */
@Data
@ApiModel("查询栈板信息入参")
public class SfcCartonNoDTO implements Serializable {

    @NotBlank(message = "箱号不能为空")
    @ApiModelProperty("cartonNo")
    private String cartonNo;

    @ApiModelProperty("plantCode")
    private String plantCode;

    @NotBlank(message = "orgCode不能为空")
    @ApiModelProperty("所属BU")
    private String orgCode;
}
