package com.maxnerva.cloudmes.service.basic.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.entity.basic.WmsPlantCustomerConfig;
import com.maxnerva.cloudmes.mapper.basic.WmsPlantCustomerConfigMapper;
import com.maxnerva.cloudmes.service.basic.IWmsPlantCustomerConfigService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author likun
 * @since 2023-09-25
 */
@Service
public class WmsPlantCustomerConfigServiceImpl extends ServiceImpl<WmsPlantCustomerConfigMapper, WmsPlantCustomerConfig>
        implements IWmsPlantCustomerConfigService {

}
