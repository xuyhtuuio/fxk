package com.maxnerva.cloudmes.entity.mes;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <p>
 * PKGINFO对外查询返回结果
 * </p>
 *
 * @author hej
 * @since 2023-01-13
 */
@Data
public class PkgIdVO implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("pkgId")
    private String pkgId;

    @ApiModelProperty("是否下线  true为下线（当前状态）、false为非下线状态")
    private Boolean offlineFlag;

    @ApiModelProperty("true/false（true为锁板，false为正常）")
    private Boolean lockFlag;

    @ApiModelProperty("状态")
    private String status;

    @ApiModelProperty("状态名称")
    private String statusName;

    @ApiModelProperty("工厂组织代码")
    private String orgCode;

}
