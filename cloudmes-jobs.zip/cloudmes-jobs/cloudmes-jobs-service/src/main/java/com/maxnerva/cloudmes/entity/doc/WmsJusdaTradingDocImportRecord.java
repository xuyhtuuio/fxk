package com.maxnerva.cloudmes.entity.doc;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

/**
 * <p>
 * jusda内交入收货单导入记录
 * </p>
 *
 * @author likun
 * @since 2025-01-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsJusdaTradingDocImportRecord对象", description="jusda内交入收货单导入记录")
public class WmsJusdaTradingDocImportRecord extends BaseEntity<WmsJusdaTradingDocImportRecord> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "gr单号")
    private String grNumber;

    @ApiModelProperty(value = "gr项次")
    private String grItem;

    @ApiModelProperty(value = "内交代码")
    private String tradingCode;

    @ApiModelProperty(value = "内交BU")
    private String tradingToOrgCode;

    @ApiModelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "料号描述")
    private String partDesc;

    @ApiModelProperty(value = "版次")
    private String partVersion;

    @ApiModelProperty(value = "数量")
    private BigDecimal qty;

    @ApiModelProperty(value = "po编码")
    private String poNo;

    @ApiModelProperty(value = "po项次")
    private String poItem;

    @ApiModelProperty(value = "po文件类型")
    private String poDocumentType;

    @ApiModelProperty(value = "制造商code")
    private String mfgCode;

    @ApiModelProperty(value = "制造商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "制造商名称")
    private String mfgName;

    @ApiModelProperty(value = "单位")
    private String uomCode;

    @ApiModelProperty(value = "仓码")
    private String warehouseCode;

    @ApiModelProperty(value = "建单标识(Y-成功 N-失败)")
    private String docCreateFlag;

    @ApiModelProperty(value = "建单信息")
    private String docCreateMsg;

    @ApiModelProperty(value = "原产国")
    private String placeOfOrigin;

    @ApiModelProperty(value = "采购组")
    private String purchaseGroup;

    @ApiModelProperty(value = "采购组织")
    private String purchaseOrg;

    @ApiModelProperty(value = "移动类型")
    private String movementType;

    @ApiModelProperty(value = "GR返单单号")
    private String returnGrNumber;

}
