package com.maxnerva.cloudmes.service.basic;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.entity.basic.WmsFileDownloadLog;

import javax.servlet.http.HttpServletResponse;

public interface IWmsFileDownloadLogService extends IService<WmsFileDownloadLog> {
    WmsFileDownloadLog uploadFile(String orgCode, String type, String fileName, String creator, byte[] bytes);
}
