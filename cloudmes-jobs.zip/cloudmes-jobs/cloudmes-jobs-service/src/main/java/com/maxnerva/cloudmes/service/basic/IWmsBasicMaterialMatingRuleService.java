package com.maxnerva.cloudmes.service.basic;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.entity.basic.WmsBasicMaterialMatingRule;

/**
 * <p>
 * 物料配套使用规则 服务类
 * </p>
 *
 * @author likun
 * @since 2024-12-23
 */
public interface IWmsBasicMaterialMatingRuleService extends IService<WmsBasicMaterialMatingRule> {

}
