package com.maxnerva.cloudmes.service.wo.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel("查询工单头部VO")
@Data
public class WorkOrderHeaderVO {

    @ApiModelProperty("orgCode")
    private String orgCode;

    @ApiModelProperty("工厂code")
    private String plant;

    @ApiModelProperty("工单号")
    private String workOrderNo;

    @ApiModelProperty("开始时间")
    private String startDate;

    @ApiModelProperty("结束时间")
    private String endDate;
}
