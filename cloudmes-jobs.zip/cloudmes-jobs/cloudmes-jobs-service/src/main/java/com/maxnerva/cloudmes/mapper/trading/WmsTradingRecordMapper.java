package com.maxnerva.cloudmes.mapper.trading;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.trading.WmsTradingRecordEntity;

/**
 * <p>
 * 内交单据表 Mapper 接口
 * </p>
 *
 * @author Chao Zhang
 * @since 2022-11-28
 */
public interface WmsTradingRecordMapper extends BaseMapper<WmsTradingRecordEntity> {

}
