package com.maxnerva.cloudmes.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/**
 * @ClassName DatahubConfig
 * @Description 服务节点地址配置类
 * @Author Likun
 * @Date 2023/9/25
 * @Version 1.0
 * @Since JDK 1.8
 **/
@RefreshScope
@Component
@Data
public class DataHubUrlConfig {

    @Value("${mesSystem.syncPkgInfo:}")
    private String syncPkgInfoUrl;

    @Value("${mesSystem.getFeedBom:}")
    private String feedBomUrl;

    @Value("${mesSystem.getInstoreProduct:}")
    private String instoreProductUrl;

    @Value("${mesSystem.inStorePassStation:}")
    private String inStorePassStationUrl;

    @Value("${mesSystem.syncMsd:}")
    private String syncMsdUrl;

    @Value("${mesSystem.queryPalletInfo:}")
    private String queryPalletInfoUrl;

    @Value("${mesSystem.queryPkgId:}")
    private String queryPkgIdUrl;

    @Value("${mesSystem.returnPkgInfo:}")
    private String returnPkgInfoUrl;

    @Value("${mesSystem.getBurnValue:}")
    private String getBurnValueUrl;

    @Value("${mesSystem.sendSnDnRelationShipToMesUrl:}")
    private String sendSnDnRelationShipToMesUrl;

    @Value("${mesSystem.shippingPassStationUrl:}")
    private String shippingPassStationUrl;

    @Value("${mesSystem.sfcWoInfoUrl:}")
    public String sfcWoInfoUrl;

    @Value("${mesSystem.sfcErrorDescUrl:}")
    public String sfcErrorDescUrl;

    @Value("${mesSystem.woNoByPkgIdUrl:}")
    public String woNoByPkgIdUrl;

    @Value("${vnJobsSystem.vnCreatePo:}")
    public String vnCreatePo;

    @Value("${vnJobsSystem.saveCkdDocReceive:}")
    public String saveCkdDocReceive;

    @Value("${mesSystem.syncComponentSnUrl:}")
    public String syncComponentSnUrl;

    @Value("${spmSystem.produceEADByWMS:}")
    public String produceEadByWmsUrl;

    @Value("${mesSystem.receivePoSnData:}")
    public String receivePoSnData;
}