package com.maxnerva.cloudmes.controller;

import com.maxnerva.cloudmes.entity.R;
import com.maxnerva.cloudmes.entity.wo.WoOrderVO;
import com.maxnerva.cloudmes.service.sap.wo.WoRfcService;
import com.maxnerva.cloudmes.service.sap.wo.model.SapWoHeaderDto;
import com.maxnerva.cloudmes.service.wo.WorkOrderService;
import com.maxnerva.cloudmes.service.wo.model.WorkOrderHeaderVO;
import com.sap.conn.jco.JCoException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @ClassName WorkOrderController
 * @Description 工单接口
 * @Author Likun
 * @Date 2023/4/13
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "工单接口")
@Slf4j
@RestController
@RequestMapping("/workOrder")
public class WorkOrderController {

    @Autowired
    private WorkOrderService workOrderService;

    @Autowired
    private WoRfcService woRfcService;

    @ApiOperation(value = "同步工单信息")
    @PostMapping("/sync")
    public R<Void> syncWorkOrderInfo(@RequestBody WoOrderVO woOrderVO) {
        log.info("syncWorkInfo start :" + System.currentTimeMillis());
        workOrderService.syncWorkOrderInfo(woOrderVO);
        log.info("syncWorkInfo end :" + System.currentTimeMillis());
        return R.ok();
    }

    @ApiOperation(value = "qms查询工单头信息")
    @PostMapping("/getWoHeaderInfo")
    public R<List<SapWoHeaderDto>> getWoHeaderInfo(@RequestBody WorkOrderHeaderVO workOrderHeaderVO) throws JCoException {
        List<SapWoHeaderDto> woHeaderDtoList = woRfcService.doGetWorkOrderHeaderNoStatus(workOrderHeaderVO.getOrgCode(), workOrderHeaderVO.getPlant(),
                workOrderHeaderVO.getWorkOrderNo(), workOrderHeaderVO.getStartDate(), workOrderHeaderVO.getEndDate());
        return R.ok(woHeaderDtoList);
    }
}
