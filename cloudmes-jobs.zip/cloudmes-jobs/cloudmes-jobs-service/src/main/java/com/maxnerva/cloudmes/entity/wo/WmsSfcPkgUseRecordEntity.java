package com.maxnerva.cloudmes.entity.wo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * 
 * </p>
 *
 * @author Chao Zhang
 * @since 2023-01-11
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("wms_sfc_pkg_use_record")
public class WmsSfcPkgUseRecordEntity extends Model<WmsSfcPkgUseRecordEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * BU
     */
    @TableField("org_code")
    private String orgCode;

    /**
     * 条码
     */
    @TableField("pkg_id")
    private String pkgId;

    /**
     * SFC PKG上线时间
     */
    @TableField("sfc_online_datetime")
    private String sfcOnlineDatetime;

    /**
     * 成品料号
     */
    @TableField("finish_product_no")
    private String finishProductNo;

    /**
     * 物料料号
     */
    @TableField("part_no")
    private String partNo;

    /**
     * 线别
     */
    @TableField("line_name")
    private String lineName;

    /**
     * 供应商
     */
    @TableField("vendor")
    private String vendor;

    /**
     * D/C
     */
    @TableField("date_code")
    private String dateCode;

    /**
     * L/C
     */
    @TableField("lot_no")
    private String lotNo;

    /**
     * 制造商料号
     */
    @TableField("mfg_pn")
    private String mfgPn;

    /**
     * 入工单状态 0：初始、失败，1：成功
     */
    @TableField("in_wo_flag")
    private String inWoFlag;

    /**
     * PKG入261工单号
     */
    @TableField("in_wo")
    private String inWo;

    /**
     * PKG入261工单时间
     */
    @TableField("in_wo_datetime")
    private LocalDateTime inWoDatetime;

    /**
     * PKG入261工单信息
     */
    @TableField("in_wo_message")
    private String inWoMessage;

    /**
     * 创建人
     */
    @TableField("creator")
    private String creator;

    /**
     * 创建人员工id，冗余字段
     */
    @TableField("creator_id")
    private Integer creatorId;

    /**
     * 创建时间
     */
    @TableField("created_dt")
    private LocalDateTime createdDt;

    /**
     * 修改人
     */
    @TableField("last_editor")
    private String lastEditor;

    /**
     * 修改人员工id，冗余字段
     */
    @TableField("last_editor_id")
    private Integer lastEditorId;

    /**
     * 修改时间
     */
    @TableField("last_edited_dt")
    private LocalDateTime lastEditedDt;


    @Override
    public Serializable pkVal() {
        return this.id;
    }

}
