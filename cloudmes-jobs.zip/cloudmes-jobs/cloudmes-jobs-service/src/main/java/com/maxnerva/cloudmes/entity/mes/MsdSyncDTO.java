package com.maxnerva.cloudmes.entity.mes;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * <p>
 * PKG同步MSD信息
 * </p>
 *
 * @author hej
 * @since 2023-09-12
 */
@Data
@ApiModel(value = "MsdSyncDTO", description = "MsdSyncDTO")
public class MsdSyncDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("pkgId")
    private String pkgId;

    @ApiModelProperty("父pkgId")
    private String parentPkgId;

    @ApiModelProperty("零件料号")
    private String componentNo;

    @ApiModelProperty("当前数量(可用数量)")
    private BigDecimal currentQty;

    @ApiModelProperty("制造商名称")
    private String mfgName;

    @ApiModelProperty("制造商料号")
    private String mfgPn;

    @ApiModelProperty("原始datecode  解析D/C")
    private String dateCode;

    @ApiModelProperty("批次号")
    private String lotNo;

    @ApiModelProperty("组织代码")
    private String orgCode;

    @ApiModelProperty("SAP工厂")
    private String plantCode;

}
