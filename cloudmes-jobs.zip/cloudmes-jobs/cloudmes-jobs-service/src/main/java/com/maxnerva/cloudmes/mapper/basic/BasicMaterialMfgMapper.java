package com.maxnerva.cloudmes.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.basic.BasicMaterialMfgEntity;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 制造商料号表	 Mapper 接口
 * </p>
 *
 * @author Chao Zhang
 * @since 2022-11-19
 */
public interface BasicMaterialMfgMapper extends BaseMapper<BasicMaterialMfgEntity> {

    int insertMaterialMfg(BasicMaterialMfgEntity insert);

    BasicMaterialMfgEntity selectMaterialMfg(@Param("orgCode") String orgCode, @Param("plantCode") String plantCode,
                                             @Param("partNo") String partNo, @Param("mfgName") String mfgName,
                                             @Param("mfgPartNo") String mfgPartNo);
}
