package com.maxnerva.cloudmes.service.aps.model;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2023/06/09 08:33
 * @Version: 1.0
 */
@Data
public class ApsResponseDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String message;
    private List<ApsContentDto> content;

}
