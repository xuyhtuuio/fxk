package com.maxnerva.cloudmes.service.sap.material.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @author H7109018
 */
@Data
public class MaterialInfoDto implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * 工厂
     */
    private String plant;

    /**
     * 料号
     */
    private String partNo;

    /**
     * 版次
     */
    private String partVersion;

    /**
     * 描述
     */
    private String partDesc;

    /**
     * ABC type
     */
    private String materialType;

    /**
     * ABC type
     */
    private String buyer;

    /**
     * 单位
     */
    private String unit;

    /**
     * 采购人
     */
    private String buyerName;

    /**
     * 联系方式
     */
    private String contact;

    /**
     * level等
     */
    private String level;

    //原物料，成品，半成品
    private String productType;
}
