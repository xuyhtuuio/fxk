package com.maxnerva.cloudmes.service.wo.model;

import com.maxnerva.cloudmes.entity.wo.WmsCreatePoDnConfig;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderPrepareCkdShipDetail;
import lombok.Data;

import java.util.List;

@Data
public class SaveCkdDocReceiveVO {
    private String orgCode;
    private String poNo;
    private WmsCreatePoDnConfig wmsCreatePoDnConfig;
    private List<WmsWorkOrderPrepareCkdShipDetail> shipDetail;
}
