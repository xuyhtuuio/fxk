package com.maxnerva.cloudmes.service.datahub.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
@ApiModel("查询PrepareCkdShipDetailVO")
public class PrepareCkdShipDetailVO {

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("序列号list")
    private List<String> serialNoList;
}
