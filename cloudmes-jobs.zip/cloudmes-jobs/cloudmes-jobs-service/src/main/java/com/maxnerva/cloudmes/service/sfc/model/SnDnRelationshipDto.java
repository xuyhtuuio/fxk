package com.maxnerva.cloudmes.service.sfc.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.PrintStream;
import java.io.Serializable;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/09/20 09:09
 * @Version: 1.0
 */
@Data
public class SnDnRelationshipDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * sn
     */
    private String sn;
    /**
     * PO
     */
    private String po;
    /**
     * SFC 工站
     */
    private String SfcWorkstation;
    /**
     * 出HUB的臨時PO
     */
    private String temporaryPoOfHub;
    /**
     * DN
     */
    private String dn;

    @ApiModelProperty("成品料号")
    private String productNo;

    @ApiModelProperty("出厂地")
    private String destination;

    @ApiModelProperty("出货时间，格式：yyyy-MM-dd HH:mm:ss")
    private String shippingDt;

    @ApiModelProperty("客户")
    private String customer;

    @ApiModelProperty("载具号(预留)")
    private String vehicleNo;

    @ApiModelProperty("运输方式")
    private String transportType;

    @ApiModelProperty("WMS出货单号")
    private String wmsNo;

    @ApiModelProperty("客户料号")
    private String cusNo;
}
