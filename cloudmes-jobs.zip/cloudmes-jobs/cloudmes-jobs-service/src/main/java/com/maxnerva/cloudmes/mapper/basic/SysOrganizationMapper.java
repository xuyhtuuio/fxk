package com.maxnerva.cloudmes.mapper.basic;

import java.util.List;

/**
 * @ClassName SysOrganizationMapper
 * @Description TODO
 * @Author Likun
 * @Date 2023/4/15
 * @Version 1.0
 * @Since JDK 1.8
 **/
public interface SysOrganizationMapper {

    List<String> selectAllOrgCode();
}
