package com.maxnerva.cloudmes.service.basic;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpStatus;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.alibaba.fastjson.JSON;
import com.maxnerva.cloudmes.entity.basic.MaterialMatingBomDTO;
import com.maxnerva.cloudmes.entity.basic.MaterialMatingBomQueryVO;
import com.maxnerva.cloudmes.entity.basic.ProductBomFeignDTO;
import com.maxnerva.cloudmes.entity.basic.ProductBomQueryVO;
import com.maxnerva.cloudmes.entity.jusda.WmsJusdaInventory;
import com.maxnerva.cloudmes.service.user.UserService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @ClassName BasicService
 * @Description TODO
 * @Author Likun
 * @Date 2024/12/20
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Service
@Slf4j
public class BasicService {


    @Value("${cloudmes.service.url}")
    private String basicServiceUrl;

    @Autowired
    UserService userService;

    public List<ProductBomFeignDTO> selectMixFlagList(ProductBomQueryVO queryVO){
        Map<String,String> headers = userService.getUserToken();
        String userToken = headers.get("token");
        String uuid = headers.get("uuid");
        if (StringUtils.isBlank(userToken)) {
            log.error("selectMixFlagList get user token error");
        }
        String url = basicServiceUrl + "/cloudmes-basic/feign/productBom/selectMixFlagList";
        HttpResponse response = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .header("Authorization", userToken)
                .header("uuid",uuid)
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(queryVO))
                .execute();
        String body = response.body();
        List<ProductBomFeignDTO> productBomFeignDTOList = CollUtil.newArrayList();
        if (response.getStatus() == HttpStatus.HTTP_OK) {
            JSONObject jsonObject = JSONUtil.parseObj(body);
            String code = jsonObject.getStr("code");
            if (StrUtil.isNotEmpty(code) && "200".equalsIgnoreCase(code)) {
                String data = jsonObject.getStr("data");
                productBomFeignDTOList = JSON.parseArray(data, ProductBomFeignDTO.class);
            }
        }
        return productBomFeignDTOList;
    }


    public List<MaterialMatingBomDTO> selectMaterialMatingBom(MaterialMatingBomQueryVO queryVO){
        Map<String,String> headers = userService.getUserToken();
        String userToken = headers.get("token");
        String uuid = headers.get("uuid");
        if (StringUtils.isBlank(userToken)) {
            log.error("selectMaterialMatingBom get user token error");
        }
        String url = basicServiceUrl + "/cloudmes-basic/feign/mating/queryList";
        HttpResponse response = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .header("Authorization", userToken)
                .header("uuid",uuid)
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(queryVO))
                .execute();
        String body = response.body();
        List<MaterialMatingBomDTO> materialMatingBomDTOList = CollUtil.newArrayList();
        if (response.getStatus() == HttpStatus.HTTP_OK) {
            JSONObject jsonObject = JSONUtil.parseObj(body);
            String code = jsonObject.getStr("code");
            if (StrUtil.isNotEmpty(code) && "200".equalsIgnoreCase(code)) {
                String data = jsonObject.getStr("data");
                materialMatingBomDTOList = JSON.parseArray(data, MaterialMatingBomDTO.class);
            }
        }
        return materialMatingBomDTOList;
    }
}
