package com.maxnerva.cloudmes.service.mes.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * <p>
 * PKG信息表
 * </p>
 *
 * @author hej
 * @since 2023-01-30
 */
@Data
@ApiModel(value = "PkgInfoScanDTO", description = "pgk扫描信息")
public class PkgInfoDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    @NotBlank(message = "pgkId不能为空")
    @ApiModelProperty("pkgId")
    private String pkgId;

    @ApiModelProperty("来源(0:自建 1:WMS)")
    private Integer sourceType;

    @ApiModelProperty("零件料号ID")
    private Integer componentId;

    @ApiModelProperty("零件料号")
    private String componentNo;

    @ApiModelProperty("零件料号版次")
    private String componentVersion;

    @ApiModelProperty("物料类别ID")
    private Integer categoryId;

    @ApiModelProperty("物料类别编码")
    private String categoryCode;

    @NotNull(message = "原始数量不能为空")
    @ApiModelProperty("原始数量")
    private BigDecimal originalQty;

    @NotNull(message = "当前数量不能为空")
    @ApiModelProperty("当前数量(可用数量)")
    private BigDecimal currentQty;

    @ApiModelProperty("消耗数量")
    private BigDecimal consumeQty;

    @ApiModelProperty("关联SN数量,关联SN后加1,解除关联-1")
    private BigDecimal linkQty;

    @ApiModelProperty("制造商名称")
    private String mfgName;

    @ApiModelProperty("制造商料号")
    private String mfgPn;

    @ApiModelProperty("制造商料号版次")
    private String mfgPnVersion;

    @ApiModelProperty("解析datecode  解析D/C")
    private String dateCode;

    @ApiModelProperty("批次号")
    private String lotNo;

    @ApiModelProperty("原产国")
    private String placeOfOrigin;

    @ApiModelProperty("锁定状态")
    private String lockStatus;

    @ApiModelProperty("锁定时间")
    private LocalDateTime lockDate;

    @ApiModelProperty("锁定原因")
    private String lockMessage;

    @ApiModelProperty("开封标记(Y/N)")
    private Boolean openFlag;

    @ApiModelProperty("最近一次开封时间")
    private LocalDateTime lastOpenTime;

    @ApiModelProperty("最近一次封装时间")
    private LocalDateTime lastPackTime;

    @ApiModelProperty("关联SN标记(Y/N)")
    private Boolean linkFlag;

    @ApiModelProperty("状态(开封,上线,下线,封装)")
    private String status;

    @NotBlank(message = "组织代码不能为空")
    @ApiModelProperty("组织代码")
    private String orgCode;

    @ApiModelProperty("有效期")
    private Integer effectiveDate;

    @ApiModelProperty("有效期截止日期")
    private String endDate;

    @ApiModelProperty("SAP工单号")
    private String sapWoNo;

    @ApiModelProperty("储位")
    private String binCode;

    @ApiModelProperty("载具")
    private String vehicleCode;

    @ApiModelProperty("烧录值")
    private String burnValue;

    @ApiModelProperty("产品料号")
    private String productNo;

    @ApiModelProperty("工厂")
    private String plantCode;

    @ApiModelProperty("轨道号")
    private String feederNo;

    @ApiModelProperty("机台号")
    private String machineCode;

    @ApiModelProperty("烧录开始时间")
    private String burnDatetime;
}
