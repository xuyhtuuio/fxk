package com.maxnerva.cloudmes.mapper.doc;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.doc.ReceiveSnPostToMesDTO;
import com.maxnerva.cloudmes.entity.doc.WmsReceiveSnList;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 收货SN清单信息 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2024-09-03
 */
public interface WmsReceiveSnListMapper extends BaseMapper<WmsReceiveSnList> {

    List<ReceiveSnPostToMesDTO> selectReceiveSnPostToMesInfo(@Param("orgCode") String orgCode);
}
