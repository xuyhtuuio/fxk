package com.maxnerva.cloudmes.entity.mes;

import com.maxnerva.cloudmes.service.sfc.model.WarehousingPassSnStationDto;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName PassSnStationDTO
 * @Description TODO
 * @Author Likun
 * @Date 2023/10/11
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("入库过站DTO")
@Data
public class PassSnStationVO {

    @ApiModelProperty("工厂组织")
    private String orgCode;

    @ApiModelProperty("工厂")
    private String plantCode;

    @ApiModelProperty("数据来源")
    private String dataSource;

    @ApiModelProperty("sn")
    private String sn;
}
