package com.maxnerva.cloudmes.mapper.jusda;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.jusda.WmsJusdaInventory;

public interface WmsJusdaInventoryMapper extends BaseMapper<WmsJusdaInventory> {
}
