package com.maxnerva.cloudmes.mapper.doc;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.doc.WmsDocJitReceiveRecord;
import com.maxnerva.cloudmes.entity.doc.WmsTradingDocImportRecord;


public interface WmsDocJitReceiveRecordMapper extends BaseMapper<WmsDocJitReceiveRecord> {

    int insertJitReceiveRecord(WmsDocJitReceiveRecord wmsDocJitReceiveRecord);
}
