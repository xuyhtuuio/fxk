package com.maxnerva.cloudmes.service.sap.po.model;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author H7109018
 */
@Data
public class DnInfoDto implements Serializable {

    private static final long serialVersionUID = -1L;

    private String dnNo;
    private String custPoNo;
    private String custCode;
    private String shipToNo;
    private Double sapTotalQty;
    private String shipCity;
    private String dnCreateTime;
    List<DnDetailInfoDto> dnDetailInfoDtos;

}
