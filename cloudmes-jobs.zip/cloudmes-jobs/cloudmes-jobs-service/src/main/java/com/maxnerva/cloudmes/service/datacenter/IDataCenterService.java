package com.maxnerva.cloudmes.service.datacenter;

import com.maxnerva.cloudmes.entity.datacenter.WmsPostFiiLog;

import java.time.LocalDateTime;

public interface IDataCenterService {

    /**
     * 生成待抛转出货数据 for fii
     */
    public void syncShipInfoForFii(String orgCode, LocalDateTime localDateTime);

    /**
     * 生成待抛转库存数据 for Fii
     */
    void syncInventoryForFii(String orgCode, LocalDateTime localDateTime);


    /**
     * 生成待抛转GR数据 for Fii
     */
    WmsPostFiiLog syncGrInfoForFii(String orgCode, LocalDateTime localDateTime, LocalDateTime beginDateTime, LocalDateTime endDateTime);



}
