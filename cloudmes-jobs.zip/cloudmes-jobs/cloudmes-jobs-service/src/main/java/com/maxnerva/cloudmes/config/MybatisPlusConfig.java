package com.maxnerva.cloudmes.config;

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.extension.plugins.MybatisPlusInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.OptimisticLockerInnerInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.PaginationInnerInterceptor;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * @Description: mybatis plus config
 * @Author: Chao Zhang
 * @Date: 2021/01/14
 * @Version: 1.0
 */
@Configuration
@MapperScan("com.maxnerva.cloudmes.mapper")
@EnableTransactionManagement
public class MybatisPlusConfig {


}