package com.maxnerva.cloudmes.service.outsourcing.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.config.Constants;
import com.maxnerva.cloudmes.entity.outsourcing.WmsOutsourcingSapTransactionLog;
import com.maxnerva.cloudmes.mapper.outsourcing.WmsOutsourcingSapTransactionLogMapper;
import com.maxnerva.cloudmes.service.outsourcing.IWmsOutsourcingSapTransactionLogService;
import com.maxnerva.cloudmes.service.sap.po.PoRfcService;
import com.maxnerva.cloudmes.service.sap.po.model.TransferOutsourcingDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * 委外过账清单 服务实现类
 * </p>
 *
 * @author likun
 * @since 2023-12-05
 */
@Slf4j
@Service
public class WmsOutsourcingSapTransactionLogServiceImpl extends ServiceImpl<WmsOutsourcingSapTransactionLogMapper,
        WmsOutsourcingSapTransactionLog> implements IWmsOutsourcingSapTransactionLogService {

    @Resource
    private PoRfcService poRfcService;

    @Resource
    private WmsOutsourcingSapTransactionLogMapper wmsOutsourcingSapTransactionLogMapper;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void doBatchTransferOutsourcingPosted(String sapClientCode, String orgCode, String postDate) {
        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }
        List<WmsOutsourcingSapTransactionLog> outsourcingSapTransactionLogList = wmsOutsourcingSapTransactionLogMapper
                .selectList(Wrappers.<WmsOutsourcingSapTransactionLog>lambdaQuery()
                        .eq(WmsOutsourcingSapTransactionLog::getOrgCode, orgCode)
                        .eq(WmsOutsourcingSapTransactionLog::getPostSapReturnFlag, 0)
                        .gt(WmsOutsourcingSapTransactionLog::getStockQty, BigDecimal.ZERO));
        Map<String, List<WmsOutsourcingSapTransactionLog>> map = outsourcingSapTransactionLogList.stream()
                .collect(Collectors.groupingBy(WmsOutsourcingSapTransactionLog::getOutsourcingPostingNo));
        String date = DateTimeFormatter.ofPattern("yyyyMMdd").format(LocalDate.now());
        for (Map.Entry<String, List<WmsOutsourcingSapTransactionLog>> entry : map.entrySet()) {
            if ("N".equalsIgnoreCase(Constants.continueJob)) {
                break;
            }
            List<WmsOutsourcingSapTransactionLog> sapTransactionLogList = entry.getValue();
            Map<String, List<WmsOutsourcingSapTransactionLog>> poMap = sapTransactionLogList.stream()
                    .collect(Collectors.groupingBy(WmsOutsourcingSapTransactionLog::getPoNo));
            for (Map.Entry<String, List<WmsOutsourcingSapTransactionLog>> listEntry : poMap.entrySet()) {
                List<WmsOutsourcingSapTransactionLog> sapTransactionLogListByPoNo = listEntry.getValue();
                //sap过账清单
                List<TransferOutsourcingDto> transferOutsourcingDtoList = CollUtil.newArrayList();
                for (WmsOutsourcingSapTransactionLog sapTransactionLog : sapTransactionLogListByPoNo) {
                    TransferOutsourcingDto transferOutsourcingDto = new TransferOutsourcingDto();
                    transferOutsourcingDto.setTransactionDate(date);
                    transferOutsourcingDto.setDocDate(date);
                    transferOutsourcingDto.setMoveType(sapTransactionLog.getPostType());
                    transferOutsourcingDto.setPlantCode(sapTransactionLog.getPlantCode());
                    transferOutsourcingDto.setWarehouseCode(sapTransactionLog.getSapWarehouseCode());
                    transferOutsourcingDto.setPartNo(sapTransactionLog.getPartNo());
                    transferOutsourcingDto.setPartNoVersion(sapTransactionLog.getPartVersion());
                    transferOutsourcingDto.setVendorCode(sapTransactionLog.getVendorCode());
                    transferOutsourcingDto.setQty(sapTransactionLog.getTransactionQty().toString());
                    transferOutsourcingDto.setBom(sapTransactionLog.getUomCode());
                    transferOutsourcingDto.setPoNo(sapTransactionLog.getPoNo());
                    String poItem = sapTransactionLog.getPoItem();
                    transferOutsourcingDto.setPoItem(poItem.substring(0, poItem.indexOf("-")));
                    transferOutsourcingDtoList.add(transferOutsourcingDto);
                }
                String sapReturnNumber;
                List<Integer> idList = sapTransactionLogListByPoNo.stream()
                        .map(WmsOutsourcingSapTransactionLog::getId).collect(Collectors.toList());
                try {
                    log.info("doBatchTransferOutsourcing request:{}", JSONUtil.toJsonStr(transferOutsourcingDtoList));
                    sapReturnNumber = poRfcService.doBatchTransferOutsourcing(sapClientCode, transferOutsourcingDtoList);
                    log.info("doBatchTransferOutsourcing response:{}", sapReturnNumber);
                    if (StrUtil.isNotEmpty(sapReturnNumber)) {
                        wmsOutsourcingSapTransactionLogMapper.update(null, Wrappers.<WmsOutsourcingSapTransactionLog>lambdaUpdate()
                                .in(WmsOutsourcingSapTransactionLog::getId, idList)
                                .set(WmsOutsourcingSapTransactionLog::getPostSapReturnFlag, 1)
                                .set(WmsOutsourcingSapTransactionLog::getPostSapReturnMsg, sapReturnNumber)
                                .set(WmsOutsourcingSapTransactionLog::getPostSapReturnDt, LocalDateTime.now())
                                .set(WmsOutsourcingSapTransactionLog::getLastEditor, "sysadmin")
                                .set(WmsOutsourcingSapTransactionLog::getLastEditedDt, LocalDateTime.now()));
                    }
                } catch (Exception e) {
                    String message = e.getMessage();
                    log.error("doBatchTransferOutsourcing error:{}", message);
                    wmsOutsourcingSapTransactionLogMapper.update(null, Wrappers.<WmsOutsourcingSapTransactionLog>lambdaUpdate()
                            .in(WmsOutsourcingSapTransactionLog::getId, idList)
                            .set(WmsOutsourcingSapTransactionLog::getPostSapReturnFlag, 2)
                            .set(WmsOutsourcingSapTransactionLog::getPostSapReturnMsg, message)
                            .set(WmsOutsourcingSapTransactionLog::getPostSapReturnDt, LocalDateTime.now())
                            .set(WmsOutsourcingSapTransactionLog::getLastEditor, "sysadmin")
                            .set(WmsOutsourcingSapTransactionLog::getLastEditedDt, LocalDateTime.now()));
                }
            }
        }
    }
}
