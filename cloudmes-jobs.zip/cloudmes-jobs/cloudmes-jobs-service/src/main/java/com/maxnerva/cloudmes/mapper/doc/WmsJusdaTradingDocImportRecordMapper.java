package com.maxnerva.cloudmes.mapper.doc;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.doc.WmsJusdaTradingDocImportRecord;

/**
 * <p>
 * jusda内交入收货单导入记录 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2025-01-03
 */
public interface WmsJusdaTradingDocImportRecordMapper extends BaseMapper<WmsJusdaTradingDocImportRecord> {

    int insertJusdaTradingDocImportRecord(WmsJusdaTradingDocImportRecord wmsJusdaTradingDocImportRecord);
}
