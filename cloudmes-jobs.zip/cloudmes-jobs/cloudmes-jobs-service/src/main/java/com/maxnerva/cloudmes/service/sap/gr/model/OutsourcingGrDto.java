package com.maxnerva.cloudmes.service.sap.gr.model;

import com.microsoft.schemas.office.office.STInsetMode;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 委外收货 DTO
 *
 * @author H7109018
 */
@Data
public class OutsourcingGrDto implements Serializable {

    private static final long serialVersionUID = -1L;

    /**
     * 收货 & doc date
     */
    private String docDate;

    private String headerTxt;

    /**
     * 默认 01
     */
    private String gmCode;

    private List<OutsourcingGrItemDto> items;


}
