package com.maxnerva.cloudmes.service.sap.wo.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/12/14 10:20
 * @Version: 1.0
 */
@Data
public class BaoGongDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String workOrderNo;
    private String unit;
    private String postDate;
    private int qty;
}
