package com.maxnerva.cloudmes.mapper.doc;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.doc.WmsDocReceive;
import com.maxnerva.cloudmes.service.datacenter.model.SelectGrInfoForFiiDTO;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * 单据表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2022-09-29
 */
public interface WmsDocReceiveMapper extends BaseMapper<WmsDocReceive> {
    List<SelectGrInfoForFiiDTO> selectGrInfoForFii(String orgCode, LocalDateTime beginDateTime, LocalDateTime endDateTime);
}
