package com.maxnerva.cloudmes.service.wo;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.LocalDateTimeUtil;
import cn.hutool.core.util.NumberUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.entity.WmsSapPlant;
import com.maxnerva.cloudmes.entity.alarm.WmsDeclareFilingAlarmRecord;
import com.maxnerva.cloudmes.entity.assyprepare.WmsAssyLocationConfig;
import com.maxnerva.cloudmes.entity.basic.*;
import com.maxnerva.cloudmes.entity.wh.WmsPkgInfo;
import com.maxnerva.cloudmes.entity.wh.WmsPkgInfoLog;
import com.maxnerva.cloudmes.entity.wo.*;
import com.maxnerva.cloudmes.mapper.WmsSapPlantMapper;
import com.maxnerva.cloudmes.mapper.alarm.WmsDeclareFilingAlarmRecordMapper;
import com.maxnerva.cloudmes.mapper.assyprepare.WmsAssyLocationConfigMapper;
import com.maxnerva.cloudmes.mapper.basic.BasicMaterialMapper;
import com.maxnerva.cloudmes.mapper.basic.SysDictMapper;
import com.maxnerva.cloudmes.mapper.wh.WmsPkgInfoMapper;
import com.maxnerva.cloudmes.mapper.wo.*;
import com.maxnerva.cloudmes.service.DataSourceService;
import com.maxnerva.cloudmes.service.basic.BasicService;
import com.maxnerva.cloudmes.service.basic.IWmsBasicMaterialMatingRuleService;
import com.maxnerva.cloudmes.service.basic.IWmsBasicProductBomService;
import com.maxnerva.cloudmes.service.prepare.wo.WoService;
import com.maxnerva.cloudmes.service.sap.material.MaterialRfcService;
import com.maxnerva.cloudmes.service.sap.material.model.MaterialStandardPriceDto;
import com.maxnerva.cloudmes.service.sap.wh.WhRfcService;
import com.maxnerva.cloudmes.service.sap.wh.model.MaterialStockInfoDto;
import com.maxnerva.cloudmes.service.sap.wo.WoRfcService;
import com.maxnerva.cloudmes.service.sap.wo.model.SapWoDetailDto;
import com.maxnerva.cloudmes.service.sap.wo.model.SapWoHeaderDto;
import com.maxnerva.cloudmes.service.sfc.SfcStoredProcedureFactory;
import com.maxnerva.cloudmes.service.sfc.model.SfcWoUsePkgInfoDto;
import com.maxnerva.cloudmes.service.wh.IWmsPkgInfoLogService;
import com.maxnerva.cloudmes.service.wo.model.BurnInfoNewDTO;
import com.sap.conn.jco.JCoException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

/**
 * @ClassName IWoService
 * @Description 工单管理service
 * @Author Likun
 * @Date 2022/8/30
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Service
@Slf4j
public class WorkOrderService {

    @Autowired
    WmsSapPlantMapper sapPlantMapper;

    @Autowired
    WoRfcService woRfcService;

    @Autowired
    WhRfcService whRfcService;

    @Autowired
    WmsWorkOrderHeaderMapper workOrderHeaderMapper;

    @Autowired
    WmsWarehouseRelationMapper warehouseRelationMapper;

    @Autowired
    IWmsWorkOrderDetailService wmsWorkOrderDetailService;

    @Autowired
    WmsWorkOrderDetailMapper workOrderDetailMapper;

    @Autowired
    IWmsWorkOrderVehicleRecordService wmsWorkOrderVehicleRecordService;

    @Autowired
    SfcStoredProcedureFactory bomFeederFactory;

    @Autowired
    IWmsBomFeederService iWmsBomFeederService;

    @Autowired
    BasicMaterialMapper basicMaterialMapper;

    @Autowired
    SfcStoredProcedureFactory sfcStoredProcedureFactory;

    @Autowired
    WmsSfcPkgUseRecordMapper wmsSfcPkgUseRecordMapper;

    @Autowired
    WmsWorkOrderPrepareLogMapper wmsWorkOrderPrepareLogMapper;

    @Autowired
    WmsWorkOrderDetailInStorageMapper wmsWorkOrderDetailInStorageMapper;

    @Autowired
    WoService newWorkOrderService;

    @Autowired
    DataSourceService dataSourceService;

    @Autowired
    IWmsPkgBurnInfoService wmsPkgBurnInfoService;

    @Autowired
    WmsDeclareFilingAlarmRecordMapper wmsDeclareFilingAlarmRecordMapper;

    @Autowired
    SysDictMapper sysDictMapper;

    @Autowired
    WmsAssyLocationConfigMapper wmsAssyLocationConfigMapper;

    @Autowired
    MaterialRfcService materialRfcService;

    @Resource
    BasicService basicService;

    @Resource
    IWmsBasicMaterialMatingRuleService wmsBasicMaterialMatingRuleService;

    @Resource
    IWmsBasicProductBomService wmsBasicProductBomService;

    @Resource
    WmsPkgInfoMapper wmsPkgInfoMapper;

    @Resource
    IWmsPkgInfoLogService wmsPkgInfoLogService;

    @Resource
    WmsWorkOrderPickTaskMapper wmsWorkOrderPickTaskMapper;

    /**
     * 同步工单header
     */
    public void syncSapWorkOrderHeader(String orgCode, String startDate, String endDate) {
        List<WmsSapPlant> plantList = sapPlantMapper.selectList(Wrappers.<WmsSapPlant>lambdaQuery()
                .eq(StringUtils.isNotBlank(orgCode), WmsSapPlant::getOrgCode, orgCode));

        plantList.forEach(p -> {
            String sectionType = p.getSectionType();
            List<SapWoHeaderDto> sapWoHeaderDtoList = null;

            try {
                sapWoHeaderDtoList = woRfcService.doGetWorkOrderHeader(p.getErpInterface(), p.getFactoryCode(), "", startDate, endDate);
            } catch (JCoException e) {
                log.error("syncSapWorkOrderHeader error : {}", e.getMessage());
            }
            sapWoHeaderDtoList.forEach(sapWoHeaderDto -> {
                if ("ELECTRONIC_SEGMENT".equalsIgnoreCase(sectionType)) {
                    if ("OTHER".equalsIgnoreCase(sapWoHeaderDto.getStatus())) {
                        return;
                    }
                } else if ("ASSEMBLY_SECTION".equalsIgnoreCase(sectionType)) {
                    if ("OTHER".equalsIgnoreCase(sapWoHeaderDto.getStatus())) {
                        sapWoHeaderDto.setStatus("REL");
                    }
                }
                WmsWorkOrderHeader wmsWorkOrderHeader = new WmsWorkOrderHeader();
                wmsWorkOrderHeader.setOrgCode(p.getOrgCode());
                wmsWorkOrderHeader.setWorkOrderNo(sapWoHeaderDto.getWorkOrderNo());
                wmsWorkOrderHeader.setPlantCode(sapWoHeaderDto.getPlant());
                wmsWorkOrderHeader.setWorkOrderType(sapWoHeaderDto.getWorkOrderType());
                wmsWorkOrderHeader.setPartNo(sapWoHeaderDto.getPartNo());
                if ("Y".equalsIgnoreCase(p.getEnableVersion())) {
                    wmsWorkOrderHeader.setPartVersion(sapWoHeaderDto.getPartVersion());
                } else {
                    wmsWorkOrderHeader.setPartVersion(null);
                }
                wmsWorkOrderHeader.setPartDesc(null);
                wmsWorkOrderHeader.setLineNo(sapWoHeaderDto.getLineNo());
                if ("CKD".equalsIgnoreCase(sapWoHeaderDto.getLineNo())) {
                    wmsWorkOrderHeader.setWorkOrderType("CKD");
                }
                wmsWorkOrderHeader.setScheduledDate(sapWoHeaderDto.getPlanStartDate());
                wmsWorkOrderHeader.setWorkOrderQty(sapWoHeaderDto.getQty());
                //20230625  E1T1工厂默认工单的板端类型为板段的工单
//                if ("E1T1".equalsIgnoreCase(p.getFactoryCode())) {
//                    wmsWorkOrderHeader.setProcessType("BOARD");
//                } else {
//                if (StringUtils.isNotBlank(p.getBoardProcessType()) && p.getBoardProcessType().contains(sapWoHeaderDto.getLineNo())) {
                if (p.getBoardProcessType().contains(sapWoHeaderDto.getWorkOrderType()) || "ALL".equalsIgnoreCase(p.getBoardProcessType())) {
                    wmsWorkOrderHeader.setProcessType("ASSY");
                } else {
                    String processType = "BOARD";
                    BasicMaterialEntity basicMaterialEntity = basicMaterialMapper.selectMaterialInfo(
                            wmsWorkOrderHeader.getOrgCode(), wmsWorkOrderHeader.getPlantCode(),
                            wmsWorkOrderHeader.getPartNo(), CollUtil.newArrayList());
                    if (ObjectUtil.isNotNull(basicMaterialEntity)) {
                        String materialGroup = basicMaterialEntity.getMaterialGroup();
                        if (StrUtil.isNotEmpty(materialGroup) && p.getBoardProcessType().contains(materialGroup)) {
                            processType = "ASSY";
                        }
                    }
                    wmsWorkOrderHeader.setProcessType(processType);
                }
               /* } else {
                    wmsWorkOrderHeader.setProcessType("ASSY");
                }*/
//                }
                wmsWorkOrderHeader.setStorageLocation(sapWoHeaderDto.getToWarehouseName());
                wmsWorkOrderHeader.setWorkOrderStatus(sapWoHeaderDto.getStatus());
                wmsWorkOrderHeader.setVirtualFlag(sapWoHeaderDto.getVirtualFlag());
                wmsWorkOrderHeader.setCreator("sysadmin");
                wmsWorkOrderHeader.setLastEditor("sysadmin");
                wmsWorkOrderHeader.setCreatedDt(LocalDateTime.now());
                wmsWorkOrderHeader.setLastEditedDt(LocalDateTime.now());
                wmsWorkOrderHeader.setApsWoScheduleDatetime(sapWoHeaderDto.getPlanStartDate());
                LocalTime startLocalTime = LocalTime.of(0, 0, 0);
                wmsWorkOrderHeader.setApsWoBeginDatetime(LocalDateTime.of(sapWoHeaderDto.getPlanStartDate(), startLocalTime));
                LocalTime endLocalTime = LocalTime.of(23, 59, 59);
                wmsWorkOrderHeader.setApsWoEndDatetime(LocalDateTime.of(sapWoHeaderDto.getPlanStartDate(), endLocalTime));
                log.info("wo_header_info : {}", JSONUtil.toJsonStr(wmsWorkOrderHeader));
                int insert = workOrderHeaderMapper.insertWoHeaderInfo(wmsWorkOrderHeader);
                BasicMaterialEntity basicMaterialEntity = basicMaterialMapper.selectMaterialInfo(
                        wmsWorkOrderHeader.getOrgCode(), wmsWorkOrderHeader.getPlantCode(),
                        wmsWorkOrderHeader.getPartNo(), Arrays.asList("G5003", "G5006"));
                if (ObjectUtil.isNotNull(basicMaterialEntity)) {
                    //新增或修改备案预警记录
                    insertOrUpdateDeclareFilingRecord(orgCode, wmsWorkOrderHeader, basicMaterialEntity);
                }
            });
        });
        log.info("数据集成调用成功--syncSapWorkOrderHeader");
    }

    public void insertOrUpdateDeclareFilingRecord(String orgCode, WmsWorkOrderHeader wmsWorkOrderHeader,
                                                  BasicMaterialEntity basicMaterialEntity) {
        WmsDeclareFilingAlarmRecord wmsDeclareFilingAlarmRecordDb = wmsDeclareFilingAlarmRecordMapper
                .selectOne(Wrappers.<WmsDeclareFilingAlarmRecord>lambdaQuery()
                        .eq(WmsDeclareFilingAlarmRecord::getOrgCode, orgCode)
                        .eq(WmsDeclareFilingAlarmRecord::getPlantCode, wmsWorkOrderHeader.getPlantCode())
                        .eq(WmsDeclareFilingAlarmRecord::getPartNo, wmsWorkOrderHeader.getPartNo())
                        .last("limit 1"));
        if (ObjectUtil.isNull(wmsDeclareFilingAlarmRecordDb)) {
            WmsDeclareFilingAlarmRecord wmsDeclareFilingAlarmRecord = new WmsDeclareFilingAlarmRecord();
            wmsDeclareFilingAlarmRecord.setOrgCode(wmsWorkOrderHeader.getOrgCode());
            wmsDeclareFilingAlarmRecord.setPlantCode(wmsWorkOrderHeader.getPlantCode());
            wmsDeclareFilingAlarmRecord.setPartNo(wmsWorkOrderHeader.getPartNo());
            wmsDeclareFilingAlarmRecord.setScheduleDate(wmsWorkOrderHeader.getScheduledDate());
            wmsDeclareFilingAlarmRecord.setMaterialGroup(basicMaterialEntity.getMaterialGroup());
            wmsDeclareFilingAlarmRecord.setCreatedDt(LocalDateTime.now());
            wmsDeclareFilingAlarmRecord.setCreator("sysadmin");
            wmsDeclareFilingAlarmRecord.setLastEditor("sysadmin");
            wmsDeclareFilingAlarmRecord.setLastEditedDt(LocalDateTime.now());
            wmsDeclareFilingAlarmRecordMapper.insert(wmsDeclareFilingAlarmRecord);
        } else {
            if (wmsDeclareFilingAlarmRecordDb.getIsDeleted()) {
                LocalDate createdDate = wmsDeclareFilingAlarmRecordDb.getCreatedDt().toLocalDate();
                LocalDate startDate = LocalDate.now().minusDays(3);
                LocalDate endDate = LocalDate.now().plusDays(2);
                if (createdDate.isBefore(startDate) || createdDate.isAfter(endDate)) {
                    wmsDeclareFilingAlarmRecordMapper.update(null,
                            Wrappers.<WmsDeclareFilingAlarmRecord>lambdaUpdate()
                                    .eq(WmsDeclareFilingAlarmRecord::getId, wmsDeclareFilingAlarmRecordDb.getId())
                                    .set(WmsDeclareFilingAlarmRecord::getIsDeleted, Boolean.FALSE)
                                    .set(WmsDeclareFilingAlarmRecord::getFilingStatus, "0")
                                    .set(WmsDeclareFilingAlarmRecord::getLastEditor, "sysadmin")
                                    .set(WmsDeclareFilingAlarmRecord::getLastEditedDt, LocalDateTime.now()));
                }
            }
        }
    }

    /**
     * 同步工单Detail
     */
    public void syncSapWorkOrderDetail(String orgCode, String workOrderNo, String sapClientCode) {
        List<WmsWorkOrderHeader> wmsWorkOrderHeaders = workOrderHeaderMapper.selectList(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                .eq(StringUtils.isNotBlank(workOrderNo), WmsWorkOrderHeader::getWorkOrderNo, workOrderNo)
                .eq(StringUtils.isBlank(workOrderNo), WmsWorkOrderHeader::getDownloadDetailFlag, 0));

        List<WmsWarehouseRelation> wmsWarehouseRelations = warehouseRelationMapper.selectList(Wrappers.<WmsWarehouseRelation>lambdaQuery()
                        .eq(WmsWarehouseRelation::getOrgCode, orgCode)
//                .eq(WmsWarehouseRelation::getChangeType, "WO_PREPARE")
        );
        List<WmsSapPlant> wmsSapPlantList = sapPlantMapper.selectList(Wrappers.<WmsSapPlant>lambdaQuery()
                .eq(WmsSapPlant::getOrgCode, orgCode));
        wmsWorkOrderHeaders.forEach(w -> {
            //先解锁工单下的条码
            unLockMaterial(w.getWorkOrderNo(), orgCode);
            // get SAP WO detail
            List<SapWoDetailDto> sapWoDetailDtoList = null;
            //查询同厂商信息
            ProductBomQueryVO queryVO = new ProductBomQueryVO();
            queryVO.setProductNo(w.getPartNo());
            queryVO.setOrgCode(orgCode);
            List<ProductBomFeignDTO> productBomFeignDTOList = basicService.selectMixFlagList(queryVO);
            List<WmsBasicProductBom> wmsBasicProductBomList = CollUtil.newArrayList();
            productBomFeignDTOList.forEach(productBomFeignDTO -> {
                WmsBasicProductBom wmsBasicProductBom = new WmsBasicProductBom();
                BeanUtils.copyProperties(productBomFeignDTO, wmsBasicProductBom);
                wmsBasicProductBom.setId(null);
                wmsBasicProductBom.setWorkOrderNo(w.getWorkOrderNo());
                wmsBasicProductBom.setCreator("sysadmin");
                wmsBasicProductBom.setCreatedDt(LocalDateTime.now());
                wmsBasicProductBomList.add(wmsBasicProductBom);
            });
            wmsBasicProductBomService.remove(Wrappers.<WmsBasicProductBom>lambdaQuery()
                    .eq(WmsBasicProductBom::getOrgCode, orgCode)
                    .eq(WmsBasicProductBom::getWorkOrderNo, w.getWorkOrderNo()));
            wmsBasicProductBomService.saveBatch(wmsBasicProductBomList);
            //查询配套信息
            MaterialMatingBomQueryVO matingBomQueryVO = new MaterialMatingBomQueryVO();
            matingBomQueryVO.setProductNo(w.getPartNo());
            matingBomQueryVO.setOrgCode(orgCode);
            List<MaterialMatingBomDTO> materialMatingBomDTOList = basicService
                    .selectMaterialMatingBom(matingBomQueryVO);
            List<WmsBasicMaterialMatingRule> wmsBasicMaterialMatingRuleList = CollUtil.newArrayList();
            materialMatingBomDTOList.forEach(materialMatingBomDTO -> {
                WmsBasicMaterialMatingRule wmsBasicMaterialMatingRule = new WmsBasicMaterialMatingRule();
                BeanUtils.copyProperties(materialMatingBomDTO, wmsBasicMaterialMatingRule);
                wmsBasicMaterialMatingRule.setId(null);
                wmsBasicMaterialMatingRule.setWorkOrderNo(w.getWorkOrderNo());
                wmsBasicMaterialMatingRule.setCreator("sysadmin");
                wmsBasicMaterialMatingRule.setCreatedDt(LocalDateTime.now());
                wmsBasicMaterialMatingRuleList.add(wmsBasicMaterialMatingRule);
            });
            wmsBasicMaterialMatingRuleService.remove(Wrappers.<WmsBasicMaterialMatingRule>lambdaQuery()
                    .eq(WmsBasicMaterialMatingRule::getOrgCode, orgCode)
                    .eq(WmsBasicMaterialMatingRule::getWorkOrderNo, w.getWorkOrderNo()));
            wmsBasicMaterialMatingRuleService.saveBatch(wmsBasicMaterialMatingRuleList);
            try {
                sapWoDetailDtoList = woRfcService.doGetWoDetail(sapClientCode, w.getPlantCode(), w.getWorkOrderNo());
            } catch (JCoException e) {
                log.error("syncSapWorkOrderDetail error :{} ", e.getMessage());
            }

            if (CollUtil.isEmpty(sapWoDetailDtoList)) {
                return;
            }
            String changeType = StrUtil.equals("CKD", w.getWorkOrderType()) ? "CKD" : "WO_PREPARE";
            sapWoDetailDtoList.forEach(q -> {
                Optional<WmsWarehouseRelation> first =
                        wmsWarehouseRelations.stream().filter(a -> a.getFromWarehouseCode().equalsIgnoreCase(q.getFromWarehouse())
                                && a.getPlantCode().equalsIgnoreCase(q.getPlant())
                                && StrUtil.equalsIgnoreCase(a.getChangeType(), changeType)).findFirst();
                if (first.isPresent()) {
                    q.setToWarehouse(first.get().getToWarehouseCode());
                } else {
                    q.setToWarehouse("xx");
                }
            });

            Map<String, List<SapWoDetailDto>> collect = sapWoDetailDtoList.stream()
                    .collect(Collectors.groupingBy(SapWoDetailDto::getMovementType));
            for (Map.Entry<String, List<SapWoDetailDto>> entry : collect.entrySet()) {
                String key = entry.getKey();
                if ("531".equals(key)) {
                    List<SapWoDetailDto> woDetailDtos = entry.getValue();
                    addWoDetailInStorage(woDetailDtos, orgCode);
                } else if ("261".equals(key)) {
                    sapWoDetailDtoList = entry.getValue();
                }
            }
            //整理工单
            List<WmsWorkOrderDetail> wmsWorkOrderDetails = arrangeWoDetails(w.getOrgCode(), w.getPartNo(),
                    sapWoDetailDtoList);

            log.info("wo_detail :{} ", JSONUtil.toJsonStr(wmsWorkOrderDetails));
            //查询wms已存在工单的工单明细的料号
            List<String> partNoList = workOrderDetailMapper.selectPartNoList(orgCode, w.getWorkOrderNo());
            log.info("partNoList :{} ", JSONUtil.toJsonStr(partNoList));
            //过滤下载sap工单的料号
            List<String> sapPartNoList = wmsWorkOrderDetails.stream().map(WmsWorkOrderDetail::getPartNo).distinct()
                    .collect(Collectors.toList());
            log.info("sapPartNoList :{} ", JSONUtil.toJsonStr(sapPartNoList));
            wmsWorkOrderDetails.forEach(a -> {
                        int i = workOrderDetailMapper.insertWoDetailInfo(a);
                    }
            );
            if (CollUtil.isNotEmpty(partNoList)) {
                //更新sap已做了删除标记的料号的删除标识和料号使用标识
                List<String> updateDeletePartNoList = wmsWorkOrderDetails.stream()
                        .filter(wmsWorkOrderDetail -> "1".equals(wmsWorkOrderDetail.getDeletedItem()))
                        .map(WmsWorkOrderDetail::getPartNo).collect(Collectors.toList());
                if (CollUtil.isNotEmpty(updateDeletePartNoList)) {
                    log.info("woSyncSapWorkOrderDetail {} updateDeletePartNoList {}", w.getWorkOrderNo(),
                            JSONUtil.toJsonStr(updateDeletePartNoList));
                    int j = workOrderDetailMapper.updatePartNoUseFlagAndDeleteItem(orgCode, w.getWorkOrderNo(),
                            updateDeletePartNoList);
                    log.info("woSyncSapWorkOrderDetail {} updateDeletePartNoListCount {}", w.getWorkOrderNo(), j);
                }
                //将在wms有，sap没有的料号的料号可用标识更新为不可用
                List<String> updatePartNoList = CollUtil.subtractToList(partNoList, sapPartNoList);
                if (CollUtil.isNotEmpty(updatePartNoList)) {
                    log.info("woSyncSapWorkOrderDetail {} updatePartNoList {}", w.getWorkOrderNo(),
                            JSONUtil.toJsonStr(updatePartNoList));
                    int j = workOrderDetailMapper.updatePartNoUseFlagAndDeleteItem(orgCode, w.getWorkOrderNo(),
                            updatePartNoList);
                    log.info("woSyncSapWorkOrderDetail {} updatePartNoUseFlagCount {}", w.getWorkOrderNo(), j);
                }
            }
            if (!StrUtil.equals("CKD", w.getWorkOrderType())) {
                workOrderDetailMapper.updateWoDetailMaterialType(w);
            }
            WmsWorkOrderHeader wmsWorkOrderHeader = new WmsWorkOrderHeader();
            wmsWorkOrderHeader.setId(w.getId());
            wmsWorkOrderHeader.setMrpArea(sapWoDetailDtoList.get(0).getMrpArea());
            wmsWorkOrderHeader.setMrpController(sapWoDetailDtoList.get(0).getMrpController());

            wmsWorkOrderHeader.setDownloadDetailFlag(1);
            wmsWorkOrderHeader.setDownloadDetailDt(LocalDateTime.now());
            //工单header数据来源为N的时候更新数据源栏位,根据mrpArea+orgCode查询数据来源,若找到数据来源则更新
            //20240111 加上CMB组织查询数据源逻辑
            if (StrUtil.equals("N", w.getMesDataSource())) {
                String dataSource;
                if ("CMB".equals(orgCode)) {
                    dataSource = dataSourceService.getCmbDataSource(orgCode, w.getPlantCode(), w.getPartNo());
                } else {
                    dataSource = dataSourceService.getDataSource(orgCode, wmsWorkOrderHeader.getMrpArea(),
                            w.getLineNo());
                }
                if (StrUtil.isNotEmpty(dataSource)) {
                    wmsWorkOrderHeader.setMesDataSource(dataSource);
                }
            }
            wmsWorkOrderHeader.updateById();

            //修改wo detail PN scan mode
            modifyWoPnMaterialScanMode(orgCode, w.getWorkOrderNo());

            //更新工单明细物料类型   20230111 CKD工单物料类型默认B
            if (StrUtil.equals("CKD", w.getWorkOrderType())) {
                workOrderDetailMapper.update(null, Wrappers.<WmsWorkOrderDetail>lambdaUpdate()
                        .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                        .eq(WmsWorkOrderDetail::getWorkOrderNo, w.getWorkOrderNo())
                        .set(WmsWorkOrderDetail::getMaterialType, "B"));
            } else {
                modifyWoMaterialType(orgCode, w.getWorkOrderNo());
            }

            //更新工单明细备料总量
            modifyWoStockTotalQty(orgCode, w.getWorkOrderNo());

            //更新工单明细三锡三剂的管控方式和对应的料号群组
            workOrderDetailMapper.updateAmScanModeAndMaterialGroup(orgCode, w.getWorkOrderNo());

            WmsSapPlant sapPlant = wmsSapPlantList.stream()
                    .filter(wmsSapPlant -> w.getPlantCode().equals(wmsSapPlant.getFactoryCode()))
                    .findFirst().orElse(null);
            List<String> purchaseOrgList = CollUtil.newArrayList();
            if (ObjectUtil.isNotNull(sapPlant)) {
                String jitBuyerCode = sapPlant.getJitBuyerCode();
                purchaseOrgList = StrUtil.split(jitBuyerCode, ",");
            }
            //更新工单明细采购组织以及JIT物料标识
            updatePurchaseOrg(orgCode, w.getWorkOrderNo(), purchaseOrgList);
            //先将捡料量=0的群组&&群组备料量=0的混料对应栏位还原
            workOrderDetailMapper.updateMixWoDetail(orgCode,w.getWorkOrderNo());
            //查询可能需要更新混料标记的工单明细 过滤掉捡料量>0的群组 or 群组备料量>0
            List<WmsWorkOrderDetail> wmsWorkOrderDetailList = workOrderDetailMapper
                    .selectMixWoDetail(orgCode, w.getWorkOrderNo());
            wmsWorkOrderDetailList.forEach(a -> {
                //若按照鸿海料号找同厂商表，将标记类型（T）、标记（basic的mix_flag）塞到工单detail中；
                //若按照鸿海料号找配套表，将标记类型（P）、塞到工单detail中
                //若工单中鸿海料号既有T，又有P，则标记类型取P
                String markerType = StrUtil.EMPTY;
                String mark = StrUtil.EMPTY;
                boolean updateFlag = Boolean.FALSE;
                String matingGroup = StrUtil.EMPTY;
                ProductBomFeignDTO bomFeignDTO = productBomFeignDTOList.stream()
                        .filter(productBomFeignDTO -> a.getPartNo()
                                .equals(productBomFeignDTO.getMaterialNo())).findFirst().orElse(null);
                if (ObjectUtil.isNotNull(bomFeignDTO)) {
                    markerType = "T";
                    mark = bomFeignDTO.getMixFlag();
                    updateFlag = Boolean.TRUE;
                }
                MaterialMatingBomDTO matingBomDTO = materialMatingBomDTOList.stream()
                        .filter(materialMatingBomDTO -> a.getPartNo()
                                .equals(materialMatingBomDTO.getComponentNo())).findFirst().orElse(null);
                if (ObjectUtil.isNotNull(matingBomDTO)) {
                    markerType = "P";
                    mark = null;
                    updateFlag = StrUtil.isNotEmpty(matingBomDTO.getMatingGroup()) ? Boolean.TRUE :
                            Boolean.FALSE;
                    matingGroup = matingBomDTO.getMatingGroup();
                }
                //更新工单明细标记类型,标记,配套组
                if (updateFlag) {
                    workOrderDetailMapper.update(null, Wrappers.<WmsWorkOrderDetail>lambdaUpdate()
                            .eq(WmsWorkOrderDetail::getId, a.getId())
                            .set(WmsWorkOrderDetail::getMarkerType, markerType)
                            .set(WmsWorkOrderDetail::getMark, mark)
                            .set(WmsWorkOrderDetail::getMatingGroup, matingGroup));
                }
            });
        });


    }

    /**
     * 整理工单信息
     */
    private List<WmsWorkOrderDetail> arrangeWoDetails(String orgCode, String finishedGoodsPartNo,
                                                      List<SapWoDetailDto> details) {
        //查询料号是否剪角物料
        List<String> partNoList = details.stream().map(SapWoDetailDto::getPartNo).collect(Collectors.toList());
        List<BasicMaterialEntity> materialEntityList = basicMaterialMapper.selectMaterialList(orgCode, partNoList);
        //workorderitem 分组
        details.sort(Comparator.comparing(SapWoDetailDto::getWorkOrderItem).reversed().thenComparing(SapWoDetailDto::getRequestQty).reversed());
        Map<String, List<SapWoDetailDto>> woItemGroup = details.stream().collect(Collectors.groupingBy(SapWoDetailDto::getWorkOrderItem));
        List<WmsWorkOrderDetail> t = new ArrayList<>();
        woItemGroup.forEach((key, itemList) -> {
            log.info("woItemGroup :{} ", JSONUtil.toJsonStr(itemList));
            BigDecimal groupReqQty = itemList.stream().map(SapWoDetailDto::getRequestQty).reduce(BigDecimal.ZERO, BigDecimal::add);
            itemList.sort(Comparator.comparing(SapWoDetailDto::getRequestQty).reversed());
            String tempPartNo = "";
            for (int i = 0; i < itemList.size(); i++) {
                tempPartNo = String.join(itemList.get(i).getPartNo(), "--");
                WmsWorkOrderDetail wmsWorkOrderDetail = new WmsWorkOrderDetail();
                wmsWorkOrderDetail.setOrgCode(orgCode);
                wmsWorkOrderDetail.setReservationNumber(itemList.get(i).getReservationNumber());
                wmsWorkOrderDetail.setReservationItem(itemList.get(i).getReservationItem());
                wmsWorkOrderDetail.setPlantCode(itemList.get(i).getPlant());
                wmsWorkOrderDetail.setWorkOrderNo(itemList.get(i).getWorkOrderNo());
                wmsWorkOrderDetail.setWorkOrderItem(itemList.get(i).getWorkOrderItem());
                wmsWorkOrderDetail.setPartNo(itemList.get(i).getPartNo());
                wmsWorkOrderDetail.setMaterialDescription(itemList.get(i).getPartDesc());
                wmsWorkOrderDetail.setPartVersion(itemList.get(i).getPartVersion());
                wmsWorkOrderDetail.setMaterialType("X");
                wmsWorkOrderDetail.setMainPartNo(itemList.get(0).getPartNo());
                wmsWorkOrderDetail.setMainPartVersion(itemList.get(0).getPartVersion());
                if (i == 0) {
                    wmsWorkOrderDetail.setPartRelationship("M");
                    wmsWorkOrderDetail.setRequiredQuantitySap(groupReqQty.setScale(0, RoundingMode.UP));
                    /*wmsWorkOrderDetail.setRequiredQuantity(("K".equalsIgnoreCase(StringUtils.left(itemList.get(i).getUnit(), 1)) ?
                            NumberUtil.mul(groupReqQty, 1000) : groupReqQty).setScale(0, RoundingMode.UP));*/
                    //20240422 需求量不再单独做单位换算
                    wmsWorkOrderDetail.setRequiredQuantity(groupReqQty.setScale(0, RoundingMode.UP));
                } else {
                    if (tempPartNo.contains(itemList.get(i).getPartNo())) {
                        continue;
                    }
                    wmsWorkOrderDetail.setPartRelationship("S");
                    wmsWorkOrderDetail.setRequiredQuantitySap(BigDecimal.ZERO);
                    wmsWorkOrderDetail.setRequiredQuantity(BigDecimal.ZERO);
                }
                wmsWorkOrderDetail.setCustomerMaterialNo(StrUtil.EMPTY);
                wmsWorkOrderDetail.setUomCode(itemList.get(i).getUnit());
                wmsWorkOrderDetail.setSapUomCode(itemList.get(i).getUnit());
                wmsWorkOrderDetail.setFromWarehouseCode(itemList.get(i).getFromWarehouse());
                wmsWorkOrderDetail.setToWarehouseCode(itemList.get(i).getToWarehouse());
                //TODO 无用删除
                //wmsWorkOrderDetail.setToWarehouseTypeCode("a");
                wmsWorkOrderDetail.setMaterialManager("aa");
                wmsWorkOrderDetail.setFinishGoodsNo(finishedGoodsPartNo);
                wmsWorkOrderDetail.setMaterialPreparationOperationFlag(1);
                wmsWorkOrderDetail.setMrpArea(itemList.get(i).getMrpArea());
                wmsWorkOrderDetail.setMrpController(itemList.get(i).getMrpController());
                wmsWorkOrderDetail.setItemNumber(itemList.get(i).getSapItemNumber());
                wmsWorkOrderDetail.setCreator("sysadmin");
                wmsWorkOrderDetail.setLastEditor("sysadmin");
                wmsWorkOrderDetail.setCreatedDt(LocalDateTime.now());
                wmsWorkOrderDetail.setLastEditedDt(LocalDateTime.now());
                int finalI = i;
                BasicMaterialEntity materialEntity = materialEntityList.stream().filter(a ->
                        a.getMaterialNo().equalsIgnoreCase(itemList.get(finalI).getPartNo())).findFirst().orElse(null);
                if (ObjectUtil.isNotNull(materialEntity)) {
                    wmsWorkOrderDetail.setCutOffFlag(materialEntity.getCuttingFlag() ? "Y" : "N");
                }
                //填充删除标记
                String deleteFlag = itemList.get(i).getDeleteFlag();
                wmsWorkOrderDetail.setDeletedItem(StrUtil.equals("X", deleteFlag) ? "1" : "0");
                t.add(wmsWorkOrderDetail);
            }
        });
        log.info("arrangeWoDetailInfo: {}", JSONUtil.toJsonStr(t));
        return t;
    }

    /**
     * 同步工单BomFeeder
     */
    public void syncBomFeederFromSfc(String orgCode, String workOrderNo) {
        //没有同步bom feeder的工单，若指定工单号则强制更新
        List<WmsWorkOrderHeader> woHeaderList = workOrderHeaderMapper.selectList(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                .notIn(WmsWorkOrderHeader::getWorkOrderType, Arrays.asList("CKD", "MERGE"))
                .eq(StringUtils.isNotBlank(workOrderNo), WmsWorkOrderHeader::getWorkOrderNo, workOrderNo)
                .eq(StringUtils.isBlank(workOrderNo), WmsWorkOrderHeader::getSyncBomFeederFlag, 0));

        if (CollUtil.isEmpty(woHeaderList)) {
            return;
        }

        woHeaderList.forEach(w -> {
            //from sfc 取bom feeder
//            String sfcSite = SfcSiteService.getSfcSite(orgCode, w.getPlantCode());
//            String sfcSite = orgCode + "_" + w.getPlantCode();
//            String dataSource = dataSourceService.getDataSource(orgCode, w.getMrpArea());
            String dataSource = StrUtil.isNotEmpty(w.getMesDataSource()) ? w.getMesDataSource() : "MES";
            List<WmsBomFeeder> sfcBomFeederList = bomFeederFactory.getWmsBomFeeder(orgCode, w.getPartNo(),
                    w.getLineNo(), null, orgCode, dataSource);
            log.info("sfcBomFeederList dataSource:{},woNo:{},partNo:{},lineNo:{}, result:{},",
                    dataSource, w.getWorkOrderNo(), w.getPartNo(), w.getLineNo(), JSONUtil.toJsonStr(sfcBomFeederList));
            //查询烧录清单
            List<BurnInfoNewDTO> burnInfoNewDTOList;
            try {
                burnInfoNewDTOList = wmsPkgBurnInfoService.getBurnedInfo(orgCode, w.getPartNo());
            } catch (Exception e) {
                log.info("syncBomFeederFromSfc wo:{},getBurnedInfo error:{}", w.getWorkOrderNo(), e.getMessage());
                return;
            }
            //修改烧录值
            updateWoDetailBurnInfo(w, burnInfoNewDTOList);
            if (CollUtil.isEmpty(sfcBomFeederList)) {
                workOrderHeaderMapper.update(null, Wrappers.<WmsWorkOrderHeader>lambdaUpdate().eq(WmsWorkOrderHeader::getId, w.getId()).set(WmsWorkOrderHeader::getSyncBomFeederFlag, 1));
                return;
            }
            AtomicReference<Boolean> goBackFlag = new AtomicReference<>(Boolean.FALSE);
            for (WmsBomFeeder s : sfcBomFeederList) {
                if (ObjectUtil.isNull(s)) {
                    continue;
                }
                s.setLineNo(StrUtil.isEmpty(s.getLineNo()) ? "ALL" : w.getLineNo());
                s.setPickedQty(ObjectUtil.isNull(s.getPickedQty()) ? BigDecimal.ZERO : s.getPickedQty());
                s.setOrgCode(orgCode);
                s.setWorkOrderNo(w.getWorkOrderNo());
                s.setMaterialProductProcess(s.getProductProcess());
                s.setProductProcessCategory(s.distinctByKey());
                //默认全是不合盘物料
                s.setMergeFlag("N");
                BurnInfoNewDTO burnInfoNewDTO = burnInfoNewDTOList.stream().filter(burn ->
                        StrUtil.equals(s.getSparePartNo(), burn.getPartNo())).findFirst().orElse(null);
                if (ObjectUtil.isNull(burnInfoNewDTO)) {
                    if ("SMT".equalsIgnoreCase(s.getProductProcess())) {
                        s.setWorkOrderToLocation(s.distinctByKey());
                        s.setWorkOrderItem(s.getMachineCode() + "-" + s.getFeederNo());
                        s.setIsBurn(Boolean.FALSE);
                    } else {
                        s.setWorkOrderToLocation(s.getProductProcess());
                        s.setWorkOrderItem(s.getMachineCode() + "-" + s.getKeyPartNo());
                        s.setIsBurn(Boolean.FALSE);
                    }
                } else {
                    if ("SMT".equalsIgnoreCase(s.getProductProcess())) {
                        s.setWorkOrderItem(s.getMachineCode() + "-" + s.getFeederNo());
                    } else {
                        s.setWorkOrderItem(s.getMachineCode() + "-" + s.getKeyPartNo());
                    }
                    s.setWorkOrderToLocation("BURN");
                    s.setProductProcess("BURN");
                    s.setIsBurn(Boolean.TRUE);
                    s.setBurnValue(burnInfoNewDTO.getBurnValue());
                }

                //合盘项
                if (s.getPickedQty().compareTo(BigDecimal.valueOf(30)) > 0 && !"BURN".equalsIgnoreCase(s.getProductProcess())) {
                    if ("BOARD".equalsIgnoreCase(w.getProcessType()) && w.getWorkOrderQty().compareTo(BigDecimal.valueOf(500)) >= 0) {
                        s.setWorkOrderToLocation("MARGE");
                        s.setProductProcess("MARGE");
                        s.setMergeFlag("Y");
                    }
                }
                s.setPlantCode(w.getPlantCode());
                if ("000".equalsIgnoreCase(s.getFeederNo()) || "N/A".equalsIgnoreCase(s.getFeederNo())) {
                    s.setRequestQty(w.getWorkOrderQty());
                } else {
                    if (ObjectUtil.isNull(s.getCardsPerPanel()) || s.getCardsPerPanel().compareTo(BigDecimal.ZERO) == 0) {
                        goBackFlag.set(Boolean.TRUE);
                        break;
                    }
                    s.setRequestQty(NumberUtil.div(NumberUtil.mul(w.getWorkOrderQty(), s.getPickedQty()), s.getCardsPerPanel()));
                }
//                s.setRequestQty(NumberUtil.div(NumberUtil.mul(w.getWorkOrderQty(), s.getPickedQty()), s.getCardsPerPanel()));
                if (!"M".equalsIgnoreCase(s.getPartNoType())) {
                    s.setRequestQty(BigDecimal.ZERO);
                }
                s.setCreator("sysadmin");
                s.setLastEditor("sysadmin");
                s.setCreatedDt(LocalDateTime.now());
                s.setLastEditedDt(LocalDateTime.now());
            }
            if (goBackFlag.get()) {
                return;
            }
            //删除相同orgCode & workOrderNo的资料
            boolean remove = iWmsBomFeederService.remove(Wrappers.<WmsBomFeeder>lambdaQuery().eq(WmsBomFeeder::getOrgCode, w.getOrgCode()).eq(WmsBomFeeder::getWorkOrderNo, w.getWorkOrderNo()));

            //保存bom feeder
            boolean b = iWmsBomFeederService.saveBatch(sfcBomFeederList, 500);
            if (b) {
                workOrderHeaderMapper.update(null, Wrappers.<WmsWorkOrderHeader>lambdaUpdate().eq(WmsWorkOrderHeader::getId, w.getId()).set(WmsWorkOrderHeader::getSyncBomFeederFlag, 1));
                //回写工单detail
                newWorkOrderService.writeWoDetailInfo(orgCode, w.getWorkOrderNo());
            }
            //save  WmsWorkOrderVehicleRecord
            Set<WmsBomFeeder> wms = new TreeSet<>((o1, o2) -> o1.getWorkOrderToLocation().compareTo(o2.getWorkOrderToLocation()));
            wms.addAll(sfcBomFeederList);
            log.info(JSONUtil.toJsonStr(wms));
            wms.forEach(a -> {

                log.info(JSONUtil.toJsonStr(a));
                List<WmsWorkOrderVehicleRecord> list =
                        wmsWorkOrderVehicleRecordService.list(Wrappers.<WmsWorkOrderVehicleRecord>lambdaQuery()
                                .eq(WmsWorkOrderVehicleRecord::getOrgCode, orgCode)
                                .eq(WmsWorkOrderVehicleRecord::getWorkOrderNo, w.getWorkOrderNo())
                                .eq(WmsWorkOrderVehicleRecord::getWorkOrderToLocation, a.getWorkOrderToLocation()));

                if (CollUtil.isEmpty(list)) {
                    WmsWorkOrderVehicleRecord t = new WmsWorkOrderVehicleRecord();
                    t.setProductCategory(a.getProductProcess());
                    t.setWorkOrderNo(w.getWorkOrderNo());
                    t.setWorkOrderToLocation(a.getWorkOrderToLocation());
                    t.setOrgCode(orgCode);
                    t.setCreator("sysadmin");
                    t.setLastEditor("sysadmin");
                    t.setCreatedDt(LocalDateTime.now());
                    t.setLastEditedDt(LocalDateTime.now());
                    t.insert();
                }
            });
            workOrderHeaderMapper.update(null, Wrappers.<WmsWorkOrderHeader>lambdaUpdate().eq(WmsWorkOrderHeader::getId, w.getId()).set(WmsWorkOrderHeader::getSyncWorkOrderLocationFlag, 1));
            //删除bom feeder PN scan mode
            delBomFeederPnMaterialScanMode(orgCode, w.getWorkOrderNo());
        });
    }

    /**
     * wo detail从烧录清单取烧录值
     */
    private void updateWoDetailBurnInfo(WmsWorkOrderHeader workOrderHeader, List<BurnInfoNewDTO> burnInfoNewDTOList) {
        String orgCode = workOrderHeader.getOrgCode();
        String workOrderNo = workOrderHeader.getWorkOrderNo();
        List<WmsWorkOrderDetail> wmsWorkOrderDetailList = workOrderDetailMapper.selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
                .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                .eq(WmsWorkOrderDetail::getWorkOrderNo, workOrderNo));
        if (CollUtil.isEmpty(wmsWorkOrderDetailList)) {
            return;
        }
        for (BurnInfoNewDTO burnInfo : burnInfoNewDTOList) {
            workOrderDetailMapper.update(null, Wrappers.<WmsWorkOrderDetail>lambdaUpdate()
                    .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                    .eq(WmsWorkOrderDetail::getWorkOrderNo, workOrderNo)
                    .eq(WmsWorkOrderDetail::getPartNo, burnInfo.getPartNo())
                    .set(WmsWorkOrderDetail::getIsBurn, Boolean.TRUE)
                    .set(WmsWorkOrderDetail::getBurnValue, burnInfo.getBurnValue()));
        }
    }

    public void modifyWoPnMaterialScanMode(String orgCode, String workOrderNo) {
        String sql = " and material_no in (select part_no  from wms_work_order_detail wwod where org_code  = '" + orgCode + "' and work_order_no  = '" + workOrderNo + "')";

        QueryWrapper<BasicMaterialEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("distinct material_no").lambda()
                .eq(BasicMaterialEntity::getOrgCode, orgCode)
                .eq(BasicMaterialEntity::getScanMode, "PN")
                .last(sql);

        List<BasicMaterialEntity> pnList = basicMaterialMapper.selectList(queryWrapper);

        if (CollUtil.isNotEmpty(pnList)) {

            List<String> collect = pnList.stream().map(a -> a.getMaterialNo()).collect(Collectors.toList());

            workOrderDetailMapper.update(null, Wrappers.<WmsWorkOrderDetail>lambdaUpdate()
                    .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                    .eq(WmsWorkOrderDetail::getWorkOrderNo, workOrderNo)
                    .in(WmsWorkOrderDetail::getPartNo, collect)
                    .set(WmsWorkOrderDetail::getScanMode, "PN"));
        }


    }

    public void delBomFeederPnMaterialScanMode(String orgCode, String workOrderNo) {
        String sql = " and material_no in (select spare_part_no from wms_bom_feeder where org_code  = '" + orgCode + "' and work_order_no  = '" + workOrderNo + "')";

        QueryWrapper<BasicMaterialEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("distinct material_no").lambda()
                .eq(BasicMaterialEntity::getOrgCode, orgCode)
                .eq(BasicMaterialEntity::getScanMode, "PN")
                .last(sql);

        List<BasicMaterialEntity> pnList = basicMaterialMapper.selectList(queryWrapper);

        if (CollUtil.isNotEmpty(pnList)) {

            List<String> collect = pnList.stream().map(a -> a.getMaterialNo()).collect(Collectors.toList());

            iWmsBomFeederService.remove(Wrappers.<WmsBomFeeder>lambdaUpdate()
                    .eq(WmsBomFeeder::getOrgCode, orgCode)
                    .eq(WmsBomFeeder::getWorkOrderNo, workOrderNo)
                    .in(WmsBomFeeder::getKeyPartNo, collect));
        }


    }


    public void syncWorkOrderValueType() throws JCoException {

        List<MaterialStockInfoDto> materialStockInfoDtos = whRfcService.doGetStockInfo("sap", "F6T1", null, null, null);
        System.out.println(JSONUtil.toJsonStr(materialStockInfoDtos));


    }

    public void modifyWoMaterialType(String orgCode, String workOrderNo) {
        int i = workOrderDetailMapper.updateMatrerialType(orgCode, workOrderNo);
        log.info("workOrderNo:{},update count:{}", workOrderNo, i);
        //群组包含A物料则该群组全改为A
        int j = workOrderDetailMapper.updateMatrerialTypeToA(orgCode, workOrderNo);
        log.info("workOrderNo:{},update A count:{}", workOrderNo, j);
    }

    public void syncSfcWoUsePkgInfo(String orgCode, String startDateTime) {
        List<SfcWoUsePkgInfoDto> sfcPkgList = sfcStoredProcedureFactory.getSfcWoUsePkgInfo(orgCode, startDateTime);

        if (CollUtil.isEmpty(sfcPkgList)) {
            return;
        }
        sfcPkgList.forEach(a -> {
            WmsSfcPkgUseRecordEntity insertSfcDto = new WmsSfcPkgUseRecordEntity();
            insertSfcDto.setOrgCode(orgCode);
            insertSfcDto.setPkgId(a.getPKGID());
            insertSfcDto.setSfcOnlineDatetime(a.getWorkTime());
            insertSfcDto.setFinishProductNo(a.getProductNo());
            insertSfcDto.setPartNo(a.getKeyPartNo());
            insertSfcDto.setLineName(a.getLineName());
            insertSfcDto.setVendor(a.getVendor());
            insertSfcDto.setDateCode(a.getDateCode());
            insertSfcDto.setLotNo(a.getLotNo());
            insertSfcDto.setMfgPn(a.getMfgPn());
            insertSfcDto.setFinishProductNo(a.getProductNo());
            insertSfcDto.setCreatedDt(LocalDateTime.now());
            insertSfcDto.setCreator("wmsjob");
            insertSfcDto.setLastEditedDt(LocalDateTime.now());
            wmsSfcPkgUseRecordMapper.insertSfcPkgUseInfo(insertSfcDto);
        });
    }

    public void syncWoDetailUseQty(String orgCode) {
        List<WmsSfcPkgUseRecordEntity> sfcList = wmsSfcPkgUseRecordMapper.selectList(Wrappers.<WmsSfcPkgUseRecordEntity>lambdaQuery()
                .eq(WmsSfcPkgUseRecordEntity::getOrgCode, orgCode)
                .eq(WmsSfcPkgUseRecordEntity::getInWoFlag, "0")
                .orderByAsc(WmsSfcPkgUseRecordEntity::getOrgCode)
                .orderByAsc(WmsSfcPkgUseRecordEntity::getSfcOnlineDatetime));
        sfcList.forEach(a -> {
            String pkgId = a.getPkgId();
            List<String> workOrderNoList = CollUtil.newArrayList();
            List<WmsWorkOrderPrepareLog> pkgLogs;
            pkgLogs = wmsWorkOrderPrepareLogMapper.selectList(Wrappers.<WmsWorkOrderPrepareLog>lambdaQuery()
                    .eq(WmsWorkOrderPrepareLog::getOrgCode, orgCode)
                    .eq(WmsWorkOrderPrepareLog::getPkgId, pkgId)
                    .last("and current_qty > consume_qty"));
            if (CollUtil.isEmpty(pkgLogs)) {
                //判断条码是否以MH结尾,是则截取MH前的字符串去查询
                if (pkgId.endsWith("MH")) {
                    pkgLogs = wmsWorkOrderPrepareLogMapper.selectList(Wrappers.<WmsWorkOrderPrepareLog>lambdaQuery()
                            .eq(WmsWorkOrderPrepareLog::getOrgCode, orgCode)
                            .eq(WmsWorkOrderPrepareLog::getPkgId, pkgId.substring(0, pkgId.lastIndexOf("MH")))
                            .last("and current_qty > consume_qty"));
                }
                if (CollUtil.isEmpty(pkgLogs)) {
                    //PKGid 不可用
                    wmsSfcPkgUseRecordMapper.update(null, Wrappers.<WmsSfcPkgUseRecordEntity>lambdaUpdate()
                            .eq(WmsSfcPkgUseRecordEntity::getId, a.getId())
                            .set(WmsSfcPkgUseRecordEntity::getInWoFlag, 2)
                            .set(WmsSfcPkgUseRecordEntity::getInWoMessage, "非sfc使用的备料pkgId"));
                    return;
                }
            }
            for (WmsWorkOrderPrepareLog pkgLog : pkgLogs) {
                //条码备料量
                BigDecimal currentQty = pkgLog.getCurrentQty();
                //复制条码备料量,便于计算实际消耗量
                BigDecimal copyCurrentQty = currentQty;
                BigDecimal pkgLogConsumeQty = pkgLog.getConsumeQty();
                String workOrderNo = pkgLog.getWorkOrderNo();
                workOrderNoList.add(workOrderNo);
                List<WmsWorkOrderDetail> workOrderDetailList = workOrderDetailMapper.selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
                        .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                        .eq(WmsWorkOrderDetail::getWorkOrderNo, workOrderNo)
                        .eq(WmsWorkOrderDetail::getPartNo, pkgLog.getPartNo())
                );
                for (WmsWorkOrderDetail wmsWorkOrderDetail : workOrderDetailList) {
                    if (currentQty.compareTo(BigDecimal.ZERO) <= 0) {
                        break;
                    }
                    String workOrderItem = wmsWorkOrderDetail.getWorkOrderItem();
                    //消耗量
                    BigDecimal consumeQty = wmsWorkOrderDetail.getConsumeQty();
                    String partNo = wmsWorkOrderDetail.getPartNo();
                    List<WmsWorkOrderDetail> wmsWorkOrderDetailList = workOrderDetailMapper
                            .selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
                                    .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                                    .eq(WmsWorkOrderDetail::getWorkOrderNo, workOrderNo)
                                    .eq(WmsWorkOrderDetail::getWorkOrderItem, workOrderItem));
                    //总消耗量
                    BigDecimal totalConsumeQty = wmsWorkOrderDetailList.stream()
                            .map(WmsWorkOrderDetail::getConsumeQty)
                            .reduce(BigDecimal.ZERO, BigDecimal::add);
                    //主料号
                    WmsWorkOrderDetail mainWorkOrderDetail = wmsWorkOrderDetailList.stream()
                            .filter(v -> "M".equals(v.getPartRelationship()))
                            .findFirst().orElse(null);
                    //需求总量
                    assert mainWorkOrderDetail != null;
                    BigDecimal requiredQuantity = mainWorkOrderDetail.getRequiredQuantity();
                    if (totalConsumeQty.compareTo(requiredQuantity) >= 0) {
                        a.setInWoFlag("3");
                        a.setInWoDatetime(LocalDateTime.now());
                        a.setInWoMessage("工单超发");
                        a.setInWo(workOrderNo);
                        wmsSfcPkgUseRecordMapper.updateById(a);
                        return;
                    }
                    //群组下其他料号的消耗量汇总
                    BigDecimal otherConsumeQty = wmsWorkOrderDetailList.stream().filter(v -> !partNo.equals(v.getPartNo()))
                            .map(WmsWorkOrderDetail::getConsumeQty)
                            .reduce(BigDecimal.ZERO, BigDecimal::add);
                    //料号可用消耗量(需求总量-群组其他料号总消耗量-料号消耗量)
                    BigDecimal availableConsumeQty = requiredQuantity.subtract(otherConsumeQty).subtract(consumeQty);
                    BigDecimal subtract = currentQty.subtract(availableConsumeQty);
                    if (subtract.compareTo(BigDecimal.ZERO) > 0) {
                        wmsWorkOrderDetail.setConsumeQty(consumeQty.add(availableConsumeQty));
                        currentQty = subtract;
                    } else if (subtract.compareTo(BigDecimal.ZERO) == 0) {
                        wmsWorkOrderDetail.setConsumeQty(consumeQty.add(availableConsumeQty));
                        currentQty = BigDecimal.ZERO;
                    } else if (subtract.compareTo(BigDecimal.ZERO) < 0) {
                        wmsWorkOrderDetail.setConsumeQty(consumeQty.add(currentQty));
                        currentQty = BigDecimal.ZERO;
                    }
                    //更新工单明细消耗量
                    workOrderDetailMapper.updateById(wmsWorkOrderDetail);
                }
                pkgLog.setConsumeQty(pkgLogConsumeQty.add(copyCurrentQty.subtract(currentQty)));
                wmsWorkOrderPrepareLogMapper.updateById(pkgLog);
            }
            a.setInWoFlag("1");
            a.setInWoDatetime(LocalDateTime.now());
            a.setInWoMessage("OK");
            a.setInWo(StrUtil.join(",", workOrderNoList));
            wmsSfcPkgUseRecordMapper.updateById(a);
        });
    }

    public String getSyncStartTime(String orgCode) {
        return wmsSfcPkgUseRecordMapper.getSyncStartTime(orgCode);
    }

    /**
     * 工单从小到大按料号进行分配
     * 多余的分到最大的工单
     */
    public void divideMergeOrderPrepare(String orgCode) {
        //查找需要分配的合备工单detail
        List<WmsWorkOrderDetail> mergeDetailList = workOrderDetailMapper.selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
                .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                .likeRight(WmsWorkOrderDetail::getWorkOrderNo, "MERGE")
                .last(" and stock_qty != allocated_stock_qty"));
        //根据工单号分组
        Map<String, List<WmsWorkOrderDetail>> collectMap = mergeDetailList.stream().collect(Collectors.groupingBy(mergeDetail -> mergeDetail.getWorkOrderNo()));
        collectMap.forEach((orderNo, mergeWorkOrderDetailList) -> {
            //header
            WmsWorkOrderHeader mergeHeader = workOrderHeaderMapper.selectOne(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                    .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                    .eq(WmsWorkOrderHeader::getWorkOrderNo, orderNo));
            //待分配工单号list
            List<String> orderItemList = Arrays.asList(mergeHeader.getMergeOrderItem().split(","));
            Collections.sort(orderItemList);

            mergeWorkOrderDetailList.forEach(mergeDetail -> {
                //工单群组
                String orderItem = mergeDetail.getWorkOrderItem();
                //备料量
                BigDecimal stockQty = mergeDetail.getStockQty();
                //已分配备料量
                BigDecimal allocatedStockQty = mergeDetail.getAllocatedStockQty();
                //剩余可分配备料量
                BigDecimal toStockQty = stockQty.subtract(allocatedStockQty);
                String partNo = mergeDetail.getPartNo();
                //待分配工单detail
                List<WmsWorkOrderDetail> orderDetailList = workOrderDetailMapper.selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
                        .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                        .eq(WmsWorkOrderDetail::getPartNo, partNo)
                        .in(WmsWorkOrderDetail::getWorkOrderNo, orderItemList)
                        .orderByAsc(WmsWorkOrderDetail::getWorkOrderNo)
                        .orderByAsc(WmsWorkOrderDetail::getId));
                for (int i = 0; i < orderDetailList.size(); i++) {
                    if (toStockQty.compareTo(BigDecimal.ZERO) == 0) {
                        break;
                    }
                    WmsWorkOrderDetail detail = orderDetailList.get(i);
                    if (i != orderDetailList.size() - 1) {     //不是最后一个就挨着分
                        //来源工单群组
                        List<WmsWorkOrderDetail> dList = workOrderDetailMapper.selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
                                .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                                .eq(WmsWorkOrderDetail::getWorkOrderNo, detail.getWorkOrderNo())
                                .eq(WmsWorkOrderDetail::getWorkOrderItem, orderItem));
                        //群组总需求量
                        BigDecimal totalRequiredQty = dList.stream()
                                .map(WmsWorkOrderDetail::getRequiredQuantity)
                                .reduce(BigDecimal.ZERO, BigDecimal::add);
                        //群组总备料量
                        BigDecimal totalStockQty = dList.stream()
                                .map(WmsWorkOrderDetail::getStockQty)
                                .reduce(BigDecimal.ZERO, BigDecimal::add);
                        BigDecimal needQty = totalRequiredQty.subtract(totalStockQty);
                        if (needQty.compareTo(BigDecimal.ZERO) > 0) {
                            //实际分配数量
                            BigDecimal qty = needQty.compareTo(toStockQty) > 0 ? toStockQty : needQty;
                            detail.setStockQty(detail.getStockQty().add(qty));
                            workOrderDetailMapper.updateById(detail);
                            allocatedStockQty = allocatedStockQty.add(qty);
                            toStockQty = toStockQty.subtract(qty);
                            //更新工单明细备料总量
                            modifyWoStockTotalQty(orgCode, detail.getWorkOrderNo());
                        }
                    } else {
                        //剩余可分配全部放最后一个
                        detail.setStockQty(detail.getStockQty().add(toStockQty));
                        workOrderDetailMapper.updateById(detail);
                        allocatedStockQty = allocatedStockQty.add(toStockQty);
                        //更新工单明细备料总量
                        modifyWoStockTotalQty(orgCode, detail.getWorkOrderNo());
                    }
                }
                workOrderDetailMapper.update(null, Wrappers.<WmsWorkOrderDetail>lambdaUpdate()
                        .eq(WmsWorkOrderDetail::getId, mergeDetail.getId())
                        .set(WmsWorkOrderDetail::getAllocatedStockQty, allocatedStockQty));
//                mergeDetail.setAllocatedStockQty(allocatedStockQty);
//                workOrderDetailMapper.updateById(mergeDetail);
            });
        });

    }

    /**
     * 只退到最大工单号
     */
    public void divideMergeOrderReturn(String orgCode) {
        //查找需要分配的合备工单detail
        List<WmsWorkOrderDetail> mergeDetailList = workOrderDetailMapper.selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
                .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                .likeRight(WmsWorkOrderDetail::getWorkOrderNo, "MERGE")
                .last(" and return_qty != allocated_return_qty"));
        //根据工单号分组
        Map<String, List<WmsWorkOrderDetail>> collectMap = mergeDetailList.stream().collect(Collectors.groupingBy(mergeDetail -> mergeDetail.getWorkOrderNo()));
        collectMap.forEach((orderNo, mergeWorkOrderDetailList) -> {
            //header
            WmsWorkOrderHeader mergeHeader = workOrderHeaderMapper.selectOne(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                    .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                    .eq(WmsWorkOrderHeader::getWorkOrderNo, orderNo));
            //待分配工单号
            String returnOrderNo = mergeHeader.getMergeOrderMaxNo();

            mergeWorkOrderDetailList.forEach(mergeDetail -> {
                //退料量
                BigDecimal returnQty = mergeDetail.getReturnQty();

                String partNo = mergeDetail.getPartNo();
                List<WmsWorkOrderDetail> wmsWorkOrderDetailList = workOrderDetailMapper.selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
                        .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                        .eq(WmsWorkOrderDetail::getPartNo, partNo)
                        .eq(WmsWorkOrderDetail::getWorkOrderNo, returnOrderNo)
                        .orderByAsc(WmsWorkOrderDetail::getId));
                //退到id最大的一条
                WmsWorkOrderDetail orderDetail = wmsWorkOrderDetailList.get(wmsWorkOrderDetailList.size() - 1);
                orderDetail.setReturnQty(returnQty);
                workOrderDetailMapper.updateById(orderDetail);
                mergeDetail.setAllocatedReturnQty(returnQty);
                workOrderDetailMapper.updateById(mergeDetail);
            });
        });
    }

    public void modifyWoStockTotalQty(String orgCode, String workOrderNo) {
        List<WmsWorkOrderDetail> workOrderDetailList = workOrderDetailMapper.woItemStockTotalQty(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
                        .eq(WmsWorkOrderDetail::getWorkOrderNo, workOrderNo)
                        .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                //.eq(WmsWorkOrderDetail::getWorkOrderItem, "00000147-A3")
        );

        workOrderDetailList.forEach(a -> {
            workOrderDetailMapper.update(null, Wrappers.<WmsWorkOrderDetail>lambdaUpdate()
                    .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                    .eq(WmsWorkOrderDetail::getWorkOrderNo, a.getWorkOrderNo())
                    .eq(WmsWorkOrderDetail::getWorkOrderItem, a.getWorkOrderItem())
                    .eq(WmsWorkOrderDetail::getPartRelationship, "M")
                    .set(WmsWorkOrderDetail::getStockTotalQty, a.getStockTotalQty())
                    .set(WmsWorkOrderDetail::getRequiredPkgQty, a.getRequiredPkgQty())
                    .set(WmsWorkOrderDetail::getPickTotalQty, a.getPickTotalQty())
                    .set(WmsWorkOrderDetail::getPickPkgTotalQty, a.getPickPkgTotalQty())
            );
        });

        workOrderDetailMapper.update(null, Wrappers.<WmsWorkOrderDetail>lambdaUpdate()
                .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                .eq(WmsWorkOrderDetail::getWorkOrderNo, workOrderNo)
                //.eq(WmsWorkOrderDetail::getWorkOrderItem, a.getWorkOrderItem())
                .eq(WmsWorkOrderDetail::getPartRelationship, "S")
                .set(WmsWorkOrderDetail::getStockTotalQty, 0)
                .set(WmsWorkOrderDetail::getRequiredPkgQty, 0)
                .set(WmsWorkOrderDetail::getPickTotalQty, 0)
                .set(WmsWorkOrderDetail::getPickPkgTotalQty, 0)
                .set(WmsWorkOrderDetail::getRequiredQuantitySap, 0)
                .set(WmsWorkOrderDetail::getRequiredQuantity, 0)
        );
    }

    public void addWoDetailInStorage(List<SapWoDetailDto> sapWoDetailDtoList, String orgCode) {
        log.info("wo detail inStorage:{} ", JSONUtil.toJsonStr(sapWoDetailDtoList));
        sapWoDetailDtoList.forEach(a -> {
                    WmsWorkOrderDetailInStorage wmsWorkOrderDetailInStorage = new WmsWorkOrderDetailInStorage();
                    wmsWorkOrderDetailInStorage.setOrgCode(orgCode);
                    wmsWorkOrderDetailInStorage.setPlantCode(a.getPlant());
                    wmsWorkOrderDetailInStorage.setWorkOrderNo(a.getWorkOrderNo());
                    wmsWorkOrderDetailInStorage.setWorkOrderItem(a.getWorkOrderItem());
                    wmsWorkOrderDetailInStorage.setSapWarehouseCode(a.getFromWarehouse());
                    wmsWorkOrderDetailInStorage.setPartNo(a.getPartNo());
                    wmsWorkOrderDetailInStorage.setMaterialDescription(a.getPartDesc());
                    wmsWorkOrderDetailInStorage.setPartVersion(a.getPartVersion());
                    wmsWorkOrderDetailInStorage.setRequiredQuantitySap(a.getRequestQty().setScale(0, RoundingMode.UP));
                    wmsWorkOrderDetailInStorage.setRequiredQuantity(a.getRequestQty().setScale(0, RoundingMode.UP));
                    wmsWorkOrderDetailInStorage.setUomCode(a.getUnit());
                    wmsWorkOrderDetailInStorage.setMovementType(a.getMovementType());
                    wmsWorkOrderDetailInStorage.setReservationNumber(a.getReservationNumber());
                    wmsWorkOrderDetailInStorage.setReservationItem(a.getReservationItem());
                    wmsWorkOrderDetailInStorage.setMrpArea(a.getMrpArea());
                    wmsWorkOrderDetailInStorage.setMrpController(a.getMrpController());
                    wmsWorkOrderDetailInStorage.setItemNumber(a.getSapItemNumber());
                    int i = wmsWorkOrderDetailInStorageMapper.insertWoDetailInStorageInfo(wmsWorkOrderDetailInStorage);
                }
        );
    }

    /**
     * 同步工单header
     */
    public void syncWorkOrderHeader(String orgCode, String plantCode, String workOrderNo) {
        List<WmsSapPlant> plantList = sapPlantMapper.selectList(Wrappers.<WmsSapPlant>lambdaQuery()
                .eq(StringUtils.isNotBlank(orgCode), WmsSapPlant::getOrgCode, orgCode)
                .eq(WmsSapPlant::getFactoryCode, plantCode));

        plantList.forEach(p -> {

            List<SapWoHeaderDto> sapWoHeaderDtoList = null;

            try {
                sapWoHeaderDtoList = woRfcService.doGetWorkOrderHeader(p.getErpInterface(), p.getFactoryCode(), workOrderNo, "", "");
            } catch (JCoException e) {
                log.error("syncSapWorkOrderHeader error : {}", e.getMessage());
            }

            sapWoHeaderDtoList.forEach(sapWoHeaderDto -> {
                WmsWorkOrderHeader wmsWorkOrderHeader = new WmsWorkOrderHeader();
                wmsWorkOrderHeader.setOrgCode(p.getOrgCode());
                wmsWorkOrderHeader.setWorkOrderNo(sapWoHeaderDto.getWorkOrderNo());
                wmsWorkOrderHeader.setPlantCode(sapWoHeaderDto.getPlant());
                wmsWorkOrderHeader.setWorkOrderType(sapWoHeaderDto.getWorkOrderType());
                wmsWorkOrderHeader.setPartNo(sapWoHeaderDto.getPartNo());
                if ("Y".equalsIgnoreCase(p.getEnableVersion())) {
                    wmsWorkOrderHeader.setPartVersion(sapWoHeaderDto.getPartVersion());
                } else {
                    wmsWorkOrderHeader.setPartVersion(null);
                }
                wmsWorkOrderHeader.setPartDesc(null);
                wmsWorkOrderHeader.setLineNo(sapWoHeaderDto.getLineNo());
                if ("CKD".equalsIgnoreCase(sapWoHeaderDto.getLineNo())) {
                    wmsWorkOrderHeader.setWorkOrderType("CKD");
                }
                wmsWorkOrderHeader.setScheduledDate(sapWoHeaderDto.getPlanStartDate());
                wmsWorkOrderHeader.setWorkOrderQty(sapWoHeaderDto.getQty());
                if (StringUtils.isNotBlank(p.getBoardProcessType()) && p.getBoardProcessType().contains(sapWoHeaderDto.getProcessType())) {
                    wmsWorkOrderHeader.setProcessType("BOARD");
                } else {
                    wmsWorkOrderHeader.setProcessType("ASSY");
                }

                wmsWorkOrderHeader.setStorageLocation(sapWoHeaderDto.getToWarehouseName());
                wmsWorkOrderHeader.setWorkOrderStatus(sapWoHeaderDto.getStatus());
                log.info("wo header info : {}", JSONUtil.toJsonStr(wmsWorkOrderHeader));
                int insert = workOrderHeaderMapper.insertWoHeaderInfo(wmsWorkOrderHeader);
            });
        });
    }

    @Transactional(rollbackFor = Exception.class)
    public void syncWorkOrderInfo(WoOrderVO woOrderVO) {
        String orgCode = woOrderVO.getOrgCode();
        String workOrderNo = woOrderVO.getWorkOrderNo();
        String plantCode = woOrderVO.getPlantCode();
        //同步工单header
        syncWorkOrderHeader(orgCode, plantCode, workOrderNo);
        //同步工单明细
        syncSapWorkOrderDetail(orgCode, workOrderNo, "sap");
        //同步上料表
        syncBomFeederFromSfc(orgCode, workOrderNo);
    }

    public void syncPrepareLogBurnFlagTest(String orgCode, String workOrderNo) {
        List<WmsWorkOrderPrepareLog> wmsWorkOrderPrepareLogList = wmsWorkOrderPrepareLogMapper.selectList(Wrappers.<WmsWorkOrderPrepareLog>lambdaQuery()
                .eq(WmsWorkOrderPrepareLog::getOrgCode, orgCode)
                .eq(WmsWorkOrderPrepareLog::getWorkOrderNo, workOrderNo));

        for (WmsWorkOrderPrepareLog prepareLog : wmsWorkOrderPrepareLogList) {
            WmsWorkOrderDetail workOrderDetail = workOrderDetailMapper.selectOne(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
                    .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                    .eq(WmsWorkOrderDetail::getWorkOrderNo, workOrderNo)
                    .eq(WmsWorkOrderDetail::getWorkOrderItem, prepareLog.getWorkOrderItem())
                    .eq(WmsWorkOrderDetail::getPartNo, prepareLog.getPartNo())
                    .last("limit 1"));
            if (ObjectUtil.isNotNull(workOrderDetail)) {
                prepareLog.setBurnFlag(workOrderDetail.getIsBurn() ? "Y" : "N");
                wmsWorkOrderPrepareLogMapper.updateById(prepareLog);
            }
        }
    }

    public void updatePurchaseOrg(String orgCode, String workOrderNo, List<String> purchaseOrgList) {
        int i = workOrderDetailMapper.updatePurchaseOrg(orgCode, workOrderNo);
        log.info("workOrderNo:{},updatePurchaseOrg count:{}", workOrderNo, i);
        if (CollUtil.isNotEmpty(purchaseOrgList)) {
            int j = workOrderDetailMapper.updateJitMaterialFlag(orgCode, workOrderNo, purchaseOrgList);
            log.info("workOrderNo:{},updateJitMaterialFlag count:{}", workOrderNo, j);
        }
    }

    public void updateAmWoDetailStockInfo(String orgCode) {
        List<WmsWorkOrderDetail> wmsWorkOrderDetailList = workOrderDetailMapper
                .selectAmUpdateWoDetailInfo(orgCode);
        List<SysDict> sysDictList = sysDictMapper.selectDictList("WMS-AM-CLASS-SAP");
        List<SysDict> newSysDictList = sysDictList.stream().filter(sysDict -> orgCode
                .equals(StrUtil.split(sysDict.getDictCode(), "-").get(0))).collect(Collectors.toList());
        if (CollUtil.isEmpty(newSysDictList)) {
            return;
        }
        for (WmsWorkOrderDetail wmsWorkOrderDetail : wmsWorkOrderDetailList) {
            Integer id = wmsWorkOrderDetail.getId();
            String materialGroup = wmsWorkOrderDetail.getMaterialGroup();
            /*SysDict sysDictDb = sysDictList.stream().filter(sysDict -> StrUtil.equals(materialGroup,
                            sysDict.getDictCode()))
                    .findFirst().orElse(new SysDict());*/
            SysDict sysDictDb = newSysDictList.stream().filter(sysDict -> StrUtil.equals(materialGroup,
                            StrUtil.split(sysDict.getDictCode(), "-").get(1)))
                    .findFirst().orElse(new SysDict());
            if (ObjectUtil.isNull(sysDictDb)) {
                continue;
            }
            //损耗比率
            BigDecimal lossRatio = StrUtil.isNotEmpty(sysDictDb.getDictName()) ?
                    new BigDecimal(sysDictDb.getDictName())
                            .divide(new BigDecimal(100), 2, RoundingMode.HALF_UP)
                    : BigDecimal.ZERO;
            //更新工单明细stock_qty,stock_total_qty,add_pkg_id_qty,add_pkg_id_total_qty
            workOrderDetailMapper.updateAmWoDetailInfo(id, lossRatio);
        }
    }

    public void syncAssyBomFeederInfoToWoDetail(String orgCode, String workOrderNo) {
        List<WmsWorkOrderHeader> woHeaderList = workOrderHeaderMapper.selectList(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                .notIn(WmsWorkOrderHeader::getWorkOrderType, Arrays.asList("CKD", "MERGE"))
                .eq(StringUtils.isNotBlank(workOrderNo), WmsWorkOrderHeader::getWorkOrderNo, workOrderNo)
                .eq(StringUtils.isBlank(workOrderNo), WmsWorkOrderHeader::getSyncBomFeederFlag, 0));
        if (CollUtil.isEmpty(woHeaderList)) {
            return;
        }
        woHeaderList.forEach(w -> {
            List<WmsAssyLocationConfig> wmsAssyLocationConfigList = wmsAssyLocationConfigMapper
                    .selectList(Wrappers.<WmsAssyLocationConfig>lambdaQuery()
                            .eq(WmsAssyLocationConfig::getOrgCode, w.getOrgCode())
                            .eq(WmsAssyLocationConfig::getPlantCode, w.getPlantCode())
                            .eq(WmsAssyLocationConfig::getProductPartNo, w.getPartNo())
                            .eq(WmsAssyLocationConfig::getLineNo, w.getLineNo()));
            if (CollUtil.isEmpty(wmsAssyLocationConfigList)) {
                workOrderHeaderMapper.update(null, Wrappers.<WmsWorkOrderHeader>lambdaUpdate()
                        .eq(WmsWorkOrderHeader::getId, w.getId()).set(WmsWorkOrderHeader::getSyncBomFeederFlag, 1));
                return;
            }
            List<WmsWorkOrderDetail> wmsWorkOrderDetailList = workOrderDetailMapper
                    .selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
                            .eq(WmsWorkOrderDetail::getOrgCode, w.getOrgCode())
                            .eq(WmsWorkOrderDetail::getWorkOrderNo, w.getWorkOrderNo()));
            if (CollUtil.isEmpty(wmsWorkOrderDetailList)) {
                workOrderHeaderMapper.update(null, Wrappers.<WmsWorkOrderHeader>lambdaUpdate()
                        .eq(WmsWorkOrderHeader::getId, w.getId()).set(WmsWorkOrderHeader::getSyncBomFeederFlag, 1));
                return;
            }
            //获取上料表料号
            List<String> sparePartNoList = wmsAssyLocationConfigList.stream()
                    .map(WmsAssyLocationConfig::getSparePartNo).collect(Collectors.toList());
            //根据工单群组分组
            Map<String, List<WmsWorkOrderDetail>> collect = wmsWorkOrderDetailList.stream()
                    .sorted(Comparator.comparing(WmsWorkOrderDetail::getPartRelationship))
                    .collect(Collectors.groupingBy(WmsWorkOrderDetail::getWorkOrderItem));
            for (Map.Entry<String, List<WmsWorkOrderDetail>> entry : collect.entrySet()) {
                List<WmsWorkOrderDetail> wmsWorkOrderDetails = entry.getValue();
                String workOrderItem = entry.getKey();
                WmsWorkOrderDetail workOrderDetail = wmsWorkOrderDetails.stream()
                        .filter(wmsWorkOrderDetail -> sparePartNoList
                                .contains(wmsWorkOrderDetail.getPartNo())).findFirst().orElse(null);
                if (ObjectUtil.isNull(workOrderDetail)) {
                    continue;
                }
                String partNo = workOrderDetail.getPartNo();
                WmsAssyLocationConfig assyLocationConfig = wmsAssyLocationConfigList.stream()
                        .filter(wmsAssyLocationConfig -> partNo.equals(wmsAssyLocationConfig.getSparePartNo()))
                        .findFirst().orElse(null);
                if (ObjectUtil.isNull(assyLocationConfig)) {
                    continue;
                }
                workOrderDetailMapper.update(null, Wrappers.<WmsWorkOrderDetail>lambdaUpdate()
                        .eq(WmsWorkOrderDetail::getOrgCode, w.getOrgCode())
                        .eq(WmsWorkOrderDetail::getWorkOrderNo, w.getWorkOrderNo())
                        .eq(WmsWorkOrderDetail::getWorkOrderItem, workOrderItem)
                        .set(WmsWorkOrderDetail::getMaterialProductType, assyLocationConfig.getLineCategory()));
            }
            workOrderHeaderMapper.update(null, Wrappers.<WmsWorkOrderHeader>lambdaUpdate()
                    .eq(WmsWorkOrderHeader::getId, w.getId()).set(WmsWorkOrderHeader::getSyncBomFeederFlag, 1));
        });
    }

    public void syncWorkDetailMaterialStandardPrice(String orgCode, String sapClientCode) {
        List<WmsWorkOrderDetail> detailIdList = workOrderDetailMapper.selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
                .select(WmsWorkOrderDetail::getId)
                .not(i -> i.likeRight(WmsWorkOrderDetail::getWorkOrderNo, "CKD"))
                .eq(WmsWorkOrderDetail::getCurrency, "")
                .gt(WmsWorkOrderDetail::getCreatedDt, LocalDateTime.now().plusMonths(-1))
                .lt(WmsWorkOrderDetail::getCreatedDt, LocalDateTime.now().plusMonths(1))
                .and(i -> i.ne(WmsWorkOrderDetail::getStockQty, BigDecimal.ZERO).or().eq(WmsWorkOrderDetail::getPartRelationship, "M"))
                .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
        );
        if (CollectionUtil.isEmpty(detailIdList)) {
            return;
        }
        LocalDateTime startDateTime = LocalDateTime.now();

        for (WmsWorkOrderDetail item : detailIdList) {
            try {
                LocalDateTime now = LocalDateTime.now();
                // 执行时长超过25分钟，强行终止。
                long hours = LocalDateTimeUtil.between(startDateTime, now).toMinutes();
                if (hours > 25) {
                    break;
                }
                Integer detailId = item.getId();
                WmsWorkOrderDetail detail = workOrderDetailMapper.selectById(detailId);
                String valueType = detail.getValueType();
                if (com.baomidou.mybatisplus.core.toolkit.StringUtils.isBlank(valueType)) {
                    try {
                        valueType = materialRfcService.doGetMaterialValueType(sapClientCode, detail.getPlantCode(), detail.getPartNo(), detail.getFromWarehouseCode());
                    } catch (Exception e) {
                        log.error(e.getMessage());
                    }
                }
                if (com.baomidou.mybatisplus.core.toolkit.StringUtils.isBlank(valueType)) {
                    continue;
                }
                MaterialStandardPriceDto priceDTO = null;
                try {
                    priceDTO = materialRfcService.doGetMaterialStandardPrice(sapClientCode, detail.getPlantCode(), "", detail.getPartNo(), valueType);
                } catch (Exception e) {
                    log.error(e.getMessage());
                }
                if (ObjectUtil.isNull(priceDTO)) {
                    continue;
                }
                //单价保留5位小数
                BigDecimal unitPrice = priceDTO.getStandardPrice().divide(priceDTO.getPriceUnit(), 5, RoundingMode.HALF_UP);

                log.info("工单{}，料号{}, {}, 标价{}, 标数{} 币{}", detail.getWorkOrderNo(), detail.getPartNo(), valueType, priceDTO.getStandardPrice(), priceDTO.getPriceUnit(), priceDTO.getCurrency());
                workOrderDetailMapper.update(null, Wrappers.<WmsWorkOrderDetail>lambdaUpdate()
                        .set(WmsWorkOrderDetail::getUnitPrice, unitPrice)
                        .set(WmsWorkOrderDetail::getCurrency, priceDTO.getCurrency())
                        .eq(WmsWorkOrderDetail::getId, detailId)
                );
                try {
                    // 延迟3秒，减少操作数据库频率
                    Thread.sleep(3000);
                } catch (Exception e) {
                }
            } catch (Exception e) {
                log.error("sync wo price err {}", item.getId());
            }
        }
    }

    public void unLockMaterial(String workOrderNo, String orgCode) {
        List<WmsPkgInfo> wmsPkgInfoList = wmsPkgInfoMapper.selectList(Wrappers.<WmsPkgInfo>lambdaQuery()
                .eq(WmsPkgInfo::getLockWorkOrderNo, workOrderNo)
                .eq(WmsPkgInfo::getOrgCode, orgCode));
        wmsPkgInfoMapper.update(null, Wrappers.<WmsPkgInfo>lambdaUpdate()
                .eq(WmsPkgInfo::getLockWorkOrderNo, workOrderNo)
                .eq(WmsPkgInfo::getOrgCode, orgCode)
                .set(WmsPkgInfo::getLockStatus, "0")
                .set(WmsPkgInfo::getLockWorkOrderNo, "000-000")
                .set(WmsPkgInfo::getLockWorkOrderItem, StrUtil.EMPTY)
                .set(WmsPkgInfo::getLockQty, BigDecimal.ZERO)
                .set(WmsPkgInfo::getWorkOrderToLocation, StrUtil.EMPTY)
                .set(WmsPkgInfo::getFeederWorkOrderItem, StrUtil.EMPTY)
                .set(WmsPkgInfo::getLastEditor, "sysadmin")
                .set(WmsPkgInfo::getLastEditedDt, LocalDateTime.now())
                .set(WmsPkgInfo::getLockMessage, StrUtil.EMPTY));
        //插入条码履历
        List<WmsPkgInfoLog> wmsPkgInfoLogList = CollUtil.newArrayList();
        for (WmsPkgInfo wmsPkgInfo : wmsPkgInfoList) {
            WmsPkgInfoLog wmsPkgInfoLog = new WmsPkgInfoLog();
            BeanUtils.copyProperties(wmsPkgInfo, wmsPkgInfoLog);
            wmsPkgInfoLog.setId(null);
            wmsPkgInfoLog.setTransactionType("UN_LOCK_WORK_ORDER");
            wmsPkgInfoLog.setTransactionMessage("工单解锁");
            wmsPkgInfoLogList.add(wmsPkgInfoLog);
        }
        wmsPkgInfoLogService.saveBatch(wmsPkgInfoLogList);
        //更新工单明细的料号可用标识为可用
        workOrderDetailMapper.update(null, Wrappers.<WmsWorkOrderDetail>lambdaUpdate()
                .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                .eq(WmsWorkOrderDetail::getWorkOrderNo, workOrderNo)
                .set(WmsWorkOrderDetail::getPartNoUseFlag, "Y")
                .set(WmsWorkOrderDetail::getLastEditedDt, LocalDateTime.now())
                .set(WmsWorkOrderDetail::getLastEditor, "sysadmin"));
        //修改该工单已存在的捡料任务的捡料完成标识为Y
        wmsWorkOrderPickTaskMapper.update(null, Wrappers.<WmsWorkOrderPickTask>lambdaUpdate()
                .eq(WmsWorkOrderPickTask::getWorkOrderNo, workOrderNo)
                .eq(WmsWorkOrderPickTask::getTaskType, "ASSY")
                .set(WmsWorkOrderPickTask::getTaskCompletedFlag, "Y")
                .set(WmsWorkOrderPickTask::getLastEditor, "sysadmin")
                .set(WmsWorkOrderPickTask::getLastEditedDt, LocalDateTime.now()));
        //工单header锁料总盘数清空
        workOrderHeaderMapper.update(null, Wrappers.<WmsWorkOrderHeader>lambdaUpdate()
                .eq(WmsWorkOrderHeader::getWorkOrderNo, workOrderNo)
                .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                .set(WmsWorkOrderHeader::getLockWoPkgQty, BigDecimal.ZERO)
                .set(WmsWorkOrderHeader::getLastEditor, "sysadmin")
                .set(WmsWorkOrderHeader::getLastEditedDt, LocalDateTime.now()));
    }
}
