package com.maxnerva.cloudmes.service.jusda.model;

import lombok.Data;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2023/04/21 18:15
 * @Version: 1.0
 */
@Data
public class AsnRequestDto {
    private String senderID;
    private String receiverID;
    private String msgType;
    private String docID;
    private RequestContentDto requestContent;
}
