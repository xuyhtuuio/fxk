package com.maxnerva.cloudmes.service.sap.wo;

import cn.hutool.core.date.LocalDateTimeUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.entity.WmsSapPlant;
import com.maxnerva.cloudmes.mapper.WmsSapPlantMapper;
import com.maxnerva.cloudmes.service.sap.util.SapPoolFactory;
import com.maxnerva.cloudmes.service.sap.wo.model.BaoGongDto;
import com.maxnerva.cloudmes.service.sap.wo.model.SapWoDetailDto;
import com.maxnerva.cloudmes.service.sap.wo.model.SapWoHeaderDto;
import com.maxnerva.cloudmes.service.sap.wo.model.WorkOrderPostingDto;
import com.maxnerva.cloudmes.service.wo.model.PostingSap101ReturnDto;
import com.sap.conn.jco.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author H7109018
 */
@Slf4j
@Service
public class WoRfcService {

    @Autowired
    SapPoolFactory sapPoolFactory;

    @Autowired
    WmsSapPlantMapper wmsSapPlantMapper;

    /**
     * get SAP WO header info
     *
     * @param plant
     * @param startDate 最后修改开始时间 10位
     * @param endDate   最后修改结束时间 10位
     * @return
     */
    public List<SapWoHeaderDto> doGetWorkOrderHeader(String sapClient, String plant, String workOrderNo, String startDate, String endDate) throws JCoException {

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        // SAP wo header interface
        JCoFunction function = pool.getRepository().getFunction("Z_PPFM004");

        JCoParameterList input = function.getImportParameterList();
        input.setValue("PLANT", plant);
        if (StringUtils.isNotBlank(workOrderNo)) {
            input.setValue("AUFNR", workOrderNo);
        } else {
            input.setValue("STARTDATE", startDate.replaceAll("-", "").replaceAll("/", ""));
            input.setValue("ENDDATE", endDate.replaceAll("-", "").replaceAll("/", ""));
        }


        function.execute(pool);

        JCoParameterList exportlist = function.getTableParameterList();
        JCoTable sapReturnWoHeaders = exportlist.getTable("ITAB");
        log.info("sapReturnWoHeaders : {}", sapReturnWoHeaders);

        List<SapWoHeaderDto> woHeaders = new ArrayList<>();

        if (sapReturnWoHeaders != null && sapReturnWoHeaders.getNumRows() > 0) {
            SapWoHeaderDto header;
            for (int i = 0, rows = sapReturnWoHeaders.getNumRows(); i < rows; i++) {
                sapReturnWoHeaders.setRow(i);
                header = new SapWoHeaderDto();
                header.setWorkOrderNo(sapReturnWoHeaders.getString("AUFNR"));
                if (!plant.equalsIgnoreCase(sapReturnWoHeaders.getString("WERKS"))) {
                    continue;
                }
                header.setPlant(plant);
                header.setPartVersion(sapReturnWoHeaders.getString("REVLV"));
                header.setWorkOrderType(sapReturnWoHeaders.getString("AUART"));
                header.setToWarehouseName(sapReturnWoHeaders.getString("LGORT"));
                header.setPartNo(sapReturnWoHeaders.getString("MATNR"));
                header.setWorkOrderType(sapReturnWoHeaders.getString("AUART"));
                header.setQty(sapReturnWoHeaders.getBigDecimal("GAMNG"));
                header.setPlanStartDate(LocalDateTimeUtil.parseDate(sapReturnWoHeaders.getString("GSTRP"), "yyyy-MM-dd"));

                String workOrderStatus = "REL";

                if (sapReturnWoHeaders.getString("STTXT").contains("TECO") || sapReturnWoHeaders.getString("STTXT").contains("CLSD")) {
                    workOrderStatus = "CLOSE";
                } else {
//                    if (!sapReturnWoHeaders.getString("STTXT").contains("REL")) {
//                        continue;
//                    }
                    if (sapReturnWoHeaders.getString("STTXT").contains("REL")) {
                        workOrderStatus = "REL";
                    } else {
                        workOrderStatus = "OTHER";
                    }
                    if (sapReturnWoHeaders.getString("STTXT").contains("DLFL")) {
                        workOrderStatus = "DElETE";
                    }
                }
                header.setStatus(workOrderStatus);
//                header.setLineNo(sapReturnWoHeaders.getString("FEVOR"));
                header.setLineNo(sapReturnWoHeaders.getString("ZPRODN"));
                header.setProcessType(sapReturnWoHeaders.getString("DISPO"));
                header.setVirtualFlag(sapReturnWoHeaders.getString("ZMD_NO"));
                woHeaders.add(header);
            }

            sapReturnWoHeaders.clear();

        }

        return woHeaders;
    }

    /**
     * get SAP download WO detail info
     *
     * @param plant
     * @param woNumber
     * @return
     */
    public List<SapWoDetailDto> doGetWoDetail(String sapClient, String plant, String woNumber) throws JCoException {

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        // SAP wo detail interface
        JCoFunction function = pool.getRepository().getFunction("Z_PPFM005");

        JCoParameterList input = function.getImportParameterList();
        input.setValue("PLANT", plant);
        input.setValue("NUMBER", woNumber);

        function.execute(pool);

        JCoTable sapWoDetails = function.getTableParameterList().getTable("COMPONENT1");
        log.info("sapWoDetails : {}", sapWoDetails);

        JCoTable positionInfo = function.getTableParameterList().getTable("POSITION");
        String mrpArea = null;
        if (positionInfo != null && positionInfo.getNumRows() > 0) {
            positionInfo.setRow(0);
            mrpArea = positionInfo.getString("MRP_AREA");
        }

        JCoTable headerInfo = function.getTableParameterList().getTable("HEADER");
        String mrpController = null;
        if (headerInfo != null && headerInfo.getNumRows() > 0) {
            headerInfo.setRow(0);
            mrpController = headerInfo.getString("MRP_CONTROLLER");
        }

        List<SapWoDetailDto> sapWoDetailList = new ArrayList<>();

        if (sapWoDetails != null && sapWoDetails.getNumRows() > 0) {
            SapWoDetailDto detail;
            for (int i = 0, rows = sapWoDetails.getNumRows(); i < rows; i++) {
                sapWoDetails.setRow(i);
                //过滤不需要辅料的料号
                if ("X".equalsIgnoreCase(sapWoDetails.getString("DUMPS"))) {
                    continue;
                }
                detail = new SapWoDetailDto();
                detail.setMrpArea(mrpArea);
                detail.setMrpController(mrpController);
                detail.setReservationNumber(sapWoDetails.getString("RESERVATION_NUMBER"));
                detail.setReservationItem(sapWoDetails.getString("RESERVATION_ITEM"));
                detail.setPlant(sapWoDetails.getString("PROD_PLANT"));
                detail.setWorkOrderNo(sapWoDetails.getString("ORDER_NUMBER"));
                detail.setSapItemNumber(sapWoDetails.getString("ITEM_NUMBER"));
                /*String workOrderItem;
                if (StringUtils.isNotBlank(sapWoDetails.getString("ALPGR"))) {
                    workOrderItem = sapWoDetails.getString("STLNR") + "-" + sapWoDetails.getString("ALPGR");
                } else {
                    workOrderItem = sapWoDetails.getString("STLNR") + "-" + sapWoDetails.getString("MATERIAL");
                }
                detail.setWorkOrderItem(workOrderItem);*/
                String workOrderItem = sapWoDetails.getString("ITEM_NUMBER") + "-" + sapWoDetails.getString("STLNR");
                detail.setWorkOrderItem(workOrderItem);
                detail.setPartNo(sapWoDetails.getString("MATERIAL"));
                detail.setPartVersion(sapWoDetails.getString("BATCH"));
                detail.setSystemStatus(sapWoDetails.getString("SYSTEM_STATUS"));
                detail.setPartDesc(sapWoDetails.getString("MATERIAL_DESCRIPTION"));
                detail.setFromWarehouse(sapWoDetails.getString("STORAGE_LOCATION"));
                detail.setRequestQty(sapWoDetails.getBigDecimal("REQ_QUAN"));
                detail.setUnit(sapWoDetails.getString("BASE_UOM"));
                detail.setMovementType(sapWoDetails.getString("MOVEMENT_TYPE"));
                detail.setDeleteFlag(sapWoDetails.getString("DELETION_INDICATOR"));
                detail.setMaterialGroup(sapWoDetails.getString("MATKL"));
                sapWoDetailList.add(detail);
            }

            sapWoDetails.clear();

        }

        return sapWoDetailList;

    }

    /**
     * 工單備料及反轉、工單入庫及反轉
     * 261/262 ， 101/102  , 961/962 , 531
     *
     * @return
     */
    public PostingSap101ReturnDto doWorkOrderPosting(String sapClient, WorkOrderPostingDto dto) throws JCoException, RuntimeException {
        log.info("POST_WO_{}_PART_{} GetSapPool", dto.getWorkOrderNo(), dto.getPartNo());
        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        // SAP wo header interface
        log.info("POST_WO_{}_PART_{} GetSapFunc", dto.getWorkOrderNo(), dto.getPartNo());
        JCoFunction function = pool.getRepository().getFunction("Z_PPFM006");

        JCoStructure header = function.getImportParameterList().getStructure("GOODSMVT_HEADER");
        header.setValue("PSTNG_DATE", dto.getPostDate().replaceAll("/", "").replaceAll("-", ""));
        header.setValue("DOC_DATE", dto.getDocDate().replaceAll("/", "").replaceAll("-", ""));
        header.setValue("PR_UNAME", dto.getUserName());
        header.setValue("HEADER_TXT", dto.getHeaderText());

        JCoTable item = function.getImportParameterList().getTable("GOODSMVT_ITEMS");

        item.appendRow();

//      JCoTable item = function.getTableParameterList().getTable("GOODSMVT_ITEMS");
        item.setRow(0);
        item.setValue("PLANT", dto.getPlant());
        item.setValue("STGE_LOC", dto.getFromWarehouseName());
        item.setValue("MATERIAL", dto.getPartNo());
//        item.setValue("MATERIAL_LONG", dto.getPartNo());
        if (StrUtil.isNotBlank(dto.getPartVersion())) {
            item.setValue("BATCH", dto.getPartVersion());
        }
        item.setValue("MOVE_TYPE", dto.getMoveType());
        item.setValue("ENTRY_QNT", dto.getQty());
        item.setValue("ENTRY_UOM", dto.getUnit());
        if (StringUtils.isNotBlank(dto.getValueType())) {
            item.setValue("VAL_TYPE", dto.getValueType());
        }

        //滚工单入库不需要
        if (StrUtil.isNotBlank(dto.getWorkOrderNo())) {
            item.setValue("ORDERID", dto.getWorkOrderNo());
        }

        //滚工单入库不需要
        if (StrUtil.isNotBlank(dto.getWorkOrderItem())) {
            item.setValue("ORDER_ITNO", dto.getWorkOrderItem());
        }

        //滚工单入库不需要
        if (StrUtil.isNotBlank(dto.getReservationNo())) {
            item.setValue("RESERV_NO", dto.getReservationNo());
        }
        //滚工单入库不需要
        if (StrUtil.isNotBlank(dto.getReservationItem())) {
            item.setValue("RES_ITEM", dto.getReservationItem());
        }


        item.setValue("MATERIAL_LONG", dto.getPartNo());

        //SAP可以依据MOVE_TYPE 自行判断
        //JCoStructure code = function.getTableParameterList().getStructure("GOODSMVT_CODE");
        //code.setValue("GM_CODE", dto.getGmCode());
        log.info("POST_WO_{}_PART_{} ExecFunc", dto.getWorkOrderNo(), dto.getPartNo());
        function.execute(pool);
        log.info("POST_WO_{}_PART_{} ExecEnd", dto.getWorkOrderNo(), dto.getPartNo());
        JCoParameterList exportlist = function.getExportParameterList();

        //获取49单号
        String transferNo = String.valueOf(exportlist.getValue("MATERIAL_DOC"));
        log.info("POST_WO_{}_PART_{} SapNo {}", dto.getWorkOrderNo(), dto.getPartNo(), transferNo);
        if (StringUtils.isBlank(transferNo)) {
            //如果49单号为空，即过账失败，获取失败原因，失败原因在表return或者表item中获取
            String errorMessage = "SAP " + dto.getMoveType() + " error,the reason is：";

            JCoTable getretTable = function.getExportParameterList().getTable("RETURNS");

            if (getretTable != null && getretTable.getNumRows() > 0) {
                getretTable.setRow(0);
                errorMessage = errorMessage + " / " + getretTable.getString("MESSAGE");
            }

            throw new RuntimeException(errorMessage);

        } else {

            PostingSap101ReturnDto result = new PostingSap101ReturnDto();
            result.setDocNumber(transferNo);

            JCoTable getretTable = function.getExportParameterList().getTable("RETURNS");

            String woInfo = "";

            if (getretTable != null && getretTable.getNumRows() > 0) {
                for (int i = 0, rows = getretTable.getNumRows(); i < rows; i++) {
                    getretTable.setRow(i);
                    woInfo = woInfo + "," + getretTable.getString("MESSAGE");
                }
            }
            result.setSapWo(woInfo);
            log.info("doWorkOrderPosting end:{}", System.currentTimeMillis());

            return result;
        }


    }


    public String doWorkOrderBaoGong(String sapClient, BaoGongDto inEntity) throws JCoException {


        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        // SAP wo header interface
        JCoFunction function = pool.getRepository().getFunction("Z_PPFM007");

        JCoTable timeTickets = function.getTableParameterList().getTable("ATHDRLEVELS");
        timeTickets.appendRow();
        timeTickets.setRow(0);
        //工单
        timeTickets.setValue("ORDERID", inEntity.getWorkOrderNo());
        //时间
        timeTickets.setValue("POSTG_DATE", inEntity.getPostDate());
        //数量
        timeTickets.setValue("YIELD", inEntity.getQty());
        //单位
        timeTickets.setValue("CONF_QUAN_UNIT", inEntity.getUnit());

        function.execute(pool);

        JCoTable messageTable = function.getTableParameterList().getTable("DETAIL_RETURN");

        if (messageTable != null && messageTable.getNumRows() == 0) {
            log.error("doWorkOrderBaoGong SAP接口调用没有返回值");
            return "SAP didn't respond";
        }

        messageTable.setRow(0);
        String type = messageTable.getString("TYPE");

        if (StringUtils.isNotBlank(type) && ("I".equalsIgnoreCase(type) || "S".equalsIgnoreCase(type))) {
            return "OK";
        } else {
            return messageTable.getString("MESSAGE");
        }
    }

    /**
     * qms调用查询工单信息，去掉SAP的状态过滤
     *
     * @param plant
     * @param startDate 最后修改开始时间 10位
     * @param endDate   最后修改结束时间 10位
     * @return
     */
    public List<SapWoHeaderDto> doGetWorkOrderHeaderNoStatus(String orgCode, String plant, String workOrderNo, String startDate, String endDate) throws JCoException {
        WmsSapPlant wmsSapPlant = wmsSapPlantMapper.selectOne(Wrappers.<WmsSapPlant>lambdaQuery()
                .eq(WmsSapPlant::getOrgCode, orgCode)
                .eq(WmsSapPlant::getFactoryCode, plant)
                .last("limit 1"));
        JCoDestination pool = sapPoolFactory.getSapPool(wmsSapPlant.getErpInterface());
        // SAP wo header interface
        JCoFunction function = pool.getRepository().getFunction("Z_PPFM004");
        JCoParameterList input = function.getImportParameterList();
        input.setValue("PLANT", plant);
        if (StringUtils.isNotBlank(workOrderNo)) {
            input.setValue("AUFNR", workOrderNo);
        } else {
            input.setValue("STARTDATE", startDate.replaceAll("-", "").replaceAll("/", ""));
            input.setValue("ENDDATE", endDate.replaceAll("-", "").replaceAll("/", ""));
        }
        function.execute(pool);
        JCoParameterList exportlist = function.getTableParameterList();
        JCoTable sapReturnWoHeaders = exportlist.getTable("ITAB");
        log.info("sapReturnWoHeaders : {}", sapReturnWoHeaders);

        List<SapWoHeaderDto> woHeaders = new ArrayList<>();

        if (sapReturnWoHeaders != null && sapReturnWoHeaders.getNumRows() > 0) {
            SapWoHeaderDto header;
            for (int i = 0, rows = sapReturnWoHeaders.getNumRows(); i < rows; i++) {
                sapReturnWoHeaders.setRow(i);
                header = new SapWoHeaderDto();
                header.setWorkOrderNo(sapReturnWoHeaders.getString("AUFNR"));
                if (!plant.equalsIgnoreCase(sapReturnWoHeaders.getString("WERKS"))) {
                    continue;
                }
                header.setPlant(plant);
                header.setPartVersion(sapReturnWoHeaders.getString("REVLV"));
                header.setWorkOrderType(sapReturnWoHeaders.getString("AUART"));
                header.setToWarehouseName(sapReturnWoHeaders.getString("LGORT"));
                header.setPartNo(sapReturnWoHeaders.getString("MATNR"));
                header.setWorkOrderType(sapReturnWoHeaders.getString("AUART"));
                header.setQty(sapReturnWoHeaders.getBigDecimal("GAMNG"));
                header.setPlanStartDate(LocalDateTimeUtil.parseDate(sapReturnWoHeaders.getString("GSTRP"), "yyyy-MM-dd"));

                String workOrderStatus = "REL";

                if (sapReturnWoHeaders.getString("STTXT").contains("TECO") || sapReturnWoHeaders.getString("STTXT").contains("CLSD")) {
                    workOrderStatus = "CLOSE";
                } else {
//                    if (!sapReturnWoHeaders.getString("STTXT").contains("REL")) {
//                        continue;
//                    }
                    if (sapReturnWoHeaders.getString("STTXT").contains("DLFL")) {
                        workOrderStatus = "DElETE";
                    }
                }
                header.setStatus(workOrderStatus);
                header.setLineNo(sapReturnWoHeaders.getString("FEVOR"));
                header.setProcessType(sapReturnWoHeaders.getString("DISPO"));
                woHeaders.add(header);
            }
            sapReturnWoHeaders.clear();
        }
        return woHeaders;
    }

}
