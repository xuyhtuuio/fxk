package com.maxnerva.cloudmes.entity.deliver;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@ApiModel("")
public class WmsShippingToSfcLog {
    private Integer id;

    private String pkgId;

    @ApiModelProperty("箱号")
    private String cartonNo;

    @ApiModelProperty("抛sfc时间")
    private LocalDateTime toSfcDate;

    @ApiModelProperty("sfc返回结果")
    private String toSfcResult;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("抛sfc数据")
    private String toSfcData;

    @ApiModelProperty("类型")
    private String type;
}
