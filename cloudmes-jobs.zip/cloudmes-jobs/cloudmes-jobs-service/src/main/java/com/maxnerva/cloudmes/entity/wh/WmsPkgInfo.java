package com.maxnerva.cloudmes.entity.wh;

import com.baomidou.mybatisplus.annotation.FieldStrategy;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>
 *
 * </p>
 *
 * @author likun
 * @since 2022-08-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value = "WmsPkgInfo对象", description = "条码采集信息表")
public class WmsPkgInfo extends Model<WmsPkgInfo> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    @TableId
    private Integer id;

    @ApiModelProperty(value = "BU（业务单元）;")
    private String orgCode;

    @ApiModelProperty(value = "pkg")
    private String pkgId;

    @ApiModelProperty(value = "父pkg")
    private String parentPkgId;

    @ApiModelProperty(value = "工厂编码,sap工厂编码;")
    private String plantCode;

    @ApiModelProperty(value = "sap仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "库位编码")
    private String locationCode;

    @ApiModelProperty(value = "储位编码")
    private String binCode;

    @ApiModelProperty(value = "载具编码")
    private String vehicleCode;

    @ApiModelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "鸿海料号版次;")
    private String partVersion;

    @ApiModelProperty(value = "制造商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "制造商名称")
    private String mfgName;

    @ApiModelProperty(value = "客户料号")
    private String customerPartNo;

    @ApiModelProperty(value = "客户料号版次")
    private String customerVersion;

    @ApiModelProperty(value = "供应商料号")
    private String supplierPartNo;

    @ApiModelProperty(value = "供应商版次")
    private String supplierVersion;

    @ApiModelProperty(value = "原始数量;")
    private BigDecimal originalQty;

    @ApiModelProperty(value = "当前数量(在库数量);")
    private BigDecimal currentQty;

    @ApiModelProperty(value = "交易数量;")
    private BigDecimal transactionQty;

    @ApiModelProperty(value = "解析datecode  解析D/C")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate dateCode;

    @ApiModelProperty(value = "原始datecode 原始D/C")
    private String originalDateCode;

    @ApiModelProperty(value = "批次号")
    private String lotCode;

    @ApiModelProperty(value = "上架时间，记录第一次产生条码信息的时间;")
    private LocalDateTime shelfDate;

    @ApiModelProperty(value = "wms单号")
    private String wmsNo;

    @ApiModelProperty(value = "锁定状态,参考字典值")
    private String lockStatus;

    @ApiModelProperty(value = "锁定时间;")
    private LocalDateTime lockDate;

    @ApiModelProperty(value = "lock原因")
    @TableField(updateStrategy = FieldStrategy.IGNORED)
    private String lockMessage;

    @ApiModelProperty(value = "工单,暂未启用")
    private String workOrder;

    @ApiModelProperty(value = "异动类型，取字典值编码")
    private String transactionType;

    @ApiModelProperty(value = "异动类型字典值")
    private String transactionMessage;

    @ApiModelProperty(value = "有效时长，单位天;")
    private Integer effectiveDate;

    @ApiModelProperty(value = "有效期截止时间")
    private LocalDate endDate;

    @ApiModelProperty(value = "是否抛转到sfc标识(0-否，1-是);")
    private Integer wmsToSfcFlag;

    @ApiModelProperty(value = "sfc返回信息")
    private String sfcMessage;

    @ApiModelProperty(value = "抛转到sfc日期;")
    private LocalDateTime sfcDate;

    @ApiModelProperty(value = "assetId，mes_sn; sfc需要")
    private String assetId;

    @ApiModelProperty(value = "dn单号，出货用，暂未启用")
    private String dnNo;

    @ApiModelProperty(value = "库区编码")
    private String areaCode;

    @ApiModelProperty(value = "来源项次")
    private String sourceLine;

    @ApiModelProperty(value = "检验状态")
    private String inspectionStatus;

    @ApiModelProperty(value = "管控方式")
    private String controlMethod;

    @ApiModelProperty(value = "基本单位")
    private String basicUnit;

    @ApiModelProperty(value = "物料编码")
    private String materialCode;

    @ApiModelProperty(value = "盘点计划")
    private String inventoryPlan;

    @ApiModelProperty(value = "制造商版次")
    private String mfgVersion;

    @ApiModelProperty(value = "原产国1")
    private String placeOfOrigin1;

    @ApiModelProperty(value = "原产国2")
    private String placeOfOrigin2;

    @ApiModelProperty(value = "制程分类 SMT PTH ASSY")
    @TableField(updateStrategy = FieldStrategy.IGNORED)
    private String productProcess;

    @ApiModelProperty(value = "工单位置信息")
    @TableField(updateStrategy = FieldStrategy.IGNORED)
    private String workOrderToLocation;

    @ApiModelProperty(value = "上料表群组")
    @TableField(updateStrategy = FieldStrategy.IGNORED)
    private String feederWorkOrderItem;

    @ApiModelProperty(value = "锁料工单, 锁料用")
    @TableField(updateStrategy = FieldStrategy.IGNORED)
    private String lockWorkOrderNo;

    @ApiModelProperty(value = "锁定数量")
    private BigDecimal lockQty;

    @ApiModelProperty(value = "锁定类型")
    private String lockType;

    @ApiModelProperty(value = "成品入库工单信息")
    private String inStorageWorkOrder;

    @ApiModelProperty(value = "jusda栈板号")
    private String palletNo;

    @ApiModelProperty(value = "MSD等级")
    private Integer msdLevel;

    @ApiModelProperty(value = "物料类型(关联sys_dict)")
    private String materialType;

    @ApiModelProperty(value = "烧录值")
    private String burnValue;

    @ApiModelProperty(value = "ipn")
    private String iPn;

    @ApiModelProperty(value = "产品系列")
    private String modelSerial;

    @ApiModelProperty(value = "成品料号")
    private String modelNameSfc;

    @ApiModelProperty(value = "库龄最后异动时间")
    private LocalDateTime inventoryAgeLastChangeDate;

    /**
     * 创建时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(hidden = true)
    private LocalDateTime createdDt;

    @ApiModelProperty(hidden = true)
    private String creator;

    /**
     * 最后修改人
     */
    @ApiModelProperty(hidden = true)
    private String lastEditor;

    /**
     * 最后一次编辑时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(hidden = true)
    private LocalDateTime lastEditedDt;

    @ApiModelProperty("工单群组")
    @TableField(updateStrategy = FieldStrategy.IGNORED)
    private String lockWorkOrderItem;

    @ApiModelProperty("同步msd标识")
    private Integer postMsdFlag;

    @ApiModelProperty("同步msd信息描述")
    private String postMsdMsg;

    @ApiModelProperty("同步msd时间")
    private LocalDateTime postMsdDateTime;
}
