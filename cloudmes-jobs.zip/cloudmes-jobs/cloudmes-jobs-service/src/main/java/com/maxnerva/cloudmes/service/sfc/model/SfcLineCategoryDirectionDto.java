package com.maxnerva.cloudmes.service.sfc.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/09/03 08:58
 * @Version: 1.0
 */
@Data
public class SfcLineCategoryDirectionDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String workOrderNo;

    @ApiModelProperty(value = "AB面")
    private String lineCategory;

    @ApiModelProperty(value = "机台方向（13、 24）")
    private String machineDirection;

    public String displayName() {
        return this.lineCategory + "-" + this.machineDirection;

    }
}
