package com.maxnerva.cloudmes.controller.tj;

import cn.hutool.core.date.DateUtil;
import com.maxnerva.cloudmes.common.response.Result;
import com.maxnerva.cloudmes.service.basic.PostingConfigService;
import com.maxnerva.cloudmes.service.doc.CostDocPostingService;
import com.maxnerva.cloudmes.service.doc.ReceiveDocPostingService;
import com.maxnerva.cloudmes.service.jusda.JusdaService;
import com.maxnerva.cloudmes.service.wo.WorkOrderService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;

/**
 * @author H7109018
 */
@Api(tags = "LX数据集成调用接口")
@Slf4j
@RestController
@RequestMapping("/LXDataIntegration")
public class LXDataIntegrationController {

    private static final String ORG_CODE = "LX";
    private static final String SAP_CLIENT_CODE = "sap";
    private static final String DATE_FORMAT = "yyyyMMdd";
    private static String postDate = "N";

    @Autowired
    CostDocPostingService costDocPostingService;

    @Autowired
    PostingConfigService postingConfigService;

    @Autowired
    ReceiveDocPostingService docPostingService;

    @Autowired
    WorkOrderService workOrderService;

    @Autowired
    JusdaService jusdaService;

    /**
     * 修改过账时间
     * 频率：10分钟执行一次
     */
    @ApiOperation("修改过账时间")
    @GetMapping("/updatePostDate")
    public void updatePostDate() {
        String s = postingConfigService.getPostDate(ORG_CODE, null);
        postDate = s;
        log.info(">>>>>>>>>LX过账时间:{}",postDate);
    }


    /**
     * 费领退及报废单过账SAP
     * 频率：5分钟执行一次
     */
    @ApiOperation("费领退及报废单过账SAP")
    @GetMapping("/costDocPostingService")
    public void costDocPostingService() {
        log.info("costDocPostingService start :" + System.currentTimeMillis());
        costDocPostingService.costDocTransferPosting(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("costDocPostingService end :" + System.currentTimeMillis());
    }

    /**
     * 收货确认并上架完成后，收货单抛QMS
     * 频率：5分钟执行一次
     */
    @ApiOperation("收货确认并上架完成后，收货单抛QMS")
    @GetMapping("/docReceivePostQms")
    public void docReceivePostQms() {
        log.info("docReceivePostQms start :" + System.currentTimeMillis());
        docPostingService.docReceivePostQms(ORG_CODE, null);
        log.info("docReceivePostQms end :" + System.currentTimeMillis());
    }

    /**
     * 同步SAP workOrder header info,
     * 频率：60分钟执行一次
     */
    @ApiOperation("同步SAP workOrder header info")
    @GetMapping("/syncSapWorkOrderHeader")
    public Result syncSapWorkOrderHeader() {
        log.info("syncSapWorkOrderHeader start :" + System.currentTimeMillis());
        String startDate = DateUtil.format(LocalDateTime.now().plusDays(-3), DATE_FORMAT);
        String endDate = DateUtil.format(LocalDateTime.now().plusDays(2), DATE_FORMAT);
        workOrderService.syncSapWorkOrderHeader(ORG_CODE, startDate, endDate);
        log.info("syncSapWorkOrderHeader end :" + System.currentTimeMillis());
        return Result.success();
    }

    /**
     * 同步SAP workOrder detail info,
     * 频率：30分钟执行一次
     */
    @ApiOperation("同步SAP workOrder detail info")
    @GetMapping("/syncSapWorkOrderDetail")
    public void syncSapWorkOrderDetail() {
        log.info("syncSapWorkOrderDetail " + ORG_CODE + "start :" + System.currentTimeMillis());
        workOrderService.syncSapWorkOrderDetail(ORG_CODE, null, SAP_CLIENT_CODE);
        log.info("syncSapWorkOrderDetail " + ORG_CODE + "end :" + System.currentTimeMillis());
    }

    /**
     * 同步SFC 上料表和备料方向
     * 频率：30分钟执行一次
     */
    @ApiOperation("同步SFC 上料表和备料方向")
    @GetMapping("/syncBomFeederFromSfc")
    public void syncBomFeederFromSfc() {
        log.info("syncBomFeederFromSfc start :" + System.currentTimeMillis());
        workOrderService.syncBomFeederFromSfc(ORG_CODE, null);
        log.info("syncBomFeederFromSfc end :" + System.currentTimeMillis());
    }

    /**
     * ASN上传抛JUSDA
     * 频率：10分钟执行一次
     */
    @ApiOperation("ASN上传抛JUSDA")
    @GetMapping("/asnPostJusda")
    public void asnPostJusda() {
        log.info("asnPostJusda start :" + System.currentTimeMillis());
        jusdaService.asnPostJusda(ORG_CODE, "0");
        log.info("asnPostJusda end:" + System.currentTimeMillis());
    }
}
