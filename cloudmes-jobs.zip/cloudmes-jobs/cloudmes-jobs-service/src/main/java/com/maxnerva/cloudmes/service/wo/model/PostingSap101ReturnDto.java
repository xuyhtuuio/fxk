package com.maxnerva.cloudmes.service.wo.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @ClassName SapWoDetailVO
 * @Description 工单detail下载vo
 * @Author Likun
 * @Date 2022/8/30
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("posting 101 result")
@Data
public class PostingSap101ReturnDto implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("docNumber")
    private String docNumber;

    @ApiModelProperty("sap入库工单号")
    private String sapWo;

    @ApiModelProperty("数量")
    private String qty;

}
