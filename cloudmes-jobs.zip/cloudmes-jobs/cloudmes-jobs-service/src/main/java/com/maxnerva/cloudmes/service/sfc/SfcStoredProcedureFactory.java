package com.maxnerva.cloudmes.service.sfc;

import cn.hutool.core.collection.CollUtil;
import com.maxnerva.cloudmes.entity.wo.WmsBomFeeder;
import com.maxnerva.cloudmes.service.sfc.model.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author H7109018
 */
@Slf4j
@Service
public class SfcStoredProcedureFactory {

    /**
     * 自动注入策略接口的实现
     */
    @Autowired
    Map<String, SfcStoredProcedureService> sfcSpServiceMap = new ConcurrentHashMap<>(3);

    public List<WmsBomFeeder> getWmsBomFeeder(String orgCode, String partNo, String lineNo, String processType,
                                              String plantCode, String dataSource) {

        SfcStoredProcedureService sfcService = sfcSpServiceMap.get(dataSource);
        Assert.notNull(sfcService, "init SfcStoredProcedureService error");

        if (StringUtils.isBlank(lineNo)) {
            lineNo = "ALL";
        }

        List<WmsBomFeeder> wmsBomFeeder = sfcService.getWmsBomFeeder(partNo, lineNo, processType, orgCode, plantCode);
        return wmsBomFeeder;


    }

    /**
     * 抛PKG info资料给SFC
     *
     * @param orgCode
     * @param postPkgInfoToSfcDto
     * @return
     */
    public String postingSfcPkgInfo(String orgCode, PostPkgInfoToSfcDto postPkgInfoToSfcDto,
                                    String plantCode, String dataSource) {

        SfcStoredProcedureService sfcService = sfcSpServiceMap.get(dataSource);
        Assert.notNull(sfcService, "init SfcStoredProcedureService error");

        String s = sfcService.postingSfcPkgInfo(postPkgInfoToSfcDto, orgCode, plantCode);

        return s;


    }

    /**
     * from SFC 取成品入库栈板信息
     *
     * @param orgCode
     * @param barcode
     * @return
     */
    public List<SfcPalletInfoDto> getSfcPalletInfo(String orgCode, String barcode,
                                                   String plantCode, String dataSource) {

        SfcStoredProcedureService sfcService = sfcSpServiceMap.get(dataSource);
        Assert.notNull(sfcService, "init SfcStoredProcedureService error");

        List<SfcPalletInfoDto> result = sfcService.getSfcPalletInfo(barcode, orgCode, plantCode);
        if (CollUtil.isNotEmpty(result)) {
            result.forEach(a -> {
                if (a.getWorkerOrderNo().contains("-")) {
                    int i = a.getWorkerOrderNo().indexOf("-");
                    a.setWorkerOrderNo(a.getWorkerOrderNo().substring(0, i));
                }
            });
        }
        return result;

    }

    /**
     * 退料時返回該PKGID中接料的清單 DEL
     *
     * @param orgCode
     * @param pkgId
     * @return
     */
    public List<PkgLinkListDto> getPkgLinkList(String orgCode, String pkgId) {

        SfcStoredProcedureService sfcService = sfcSpServiceMap.get(orgCode);
        Assert.notNull(sfcService, "init SfcStoredProcedureService error");

        List<PkgLinkListDto> pkgLinkList = sfcService.getPkgLinkList(pkgId);

        return pkgLinkList;

    }

    /**
     * 回写DN、SN的绑定关系  (只EPD6需要)
     * workordestation INSTORE
     *
     * @param orgCode
     * @param snDnRelationshipDto
     * @return
     */
    public String sendSnDnRelationshipToSfc(String orgCode, String mrpArea, String dataSource, String plantCode,
                                            SnDnRelationshipDto snDnRelationshipDto) {
        //查成品出货单，出货数量等于计划出货数量的DN单，再抛给SFC
        SfcStoredProcedureService sfcService = sfcSpServiceMap.get(dataSource);
        Assert.notNull(sfcService, "init SfcStoredProcedureService error");

        String s = sfcService.sendSnDnRelationshipToSfc(orgCode, plantCode, mrpArea, snDnRelationshipDto);

        return s;

    }

    /**
     * WMS退料时调用此接口, 需要清除零数盘的丝印,LCR状态 及物料下线(SMT,PTH)
     *
     * @param orgCode
     * @param pkgId
     * @param currentQty
     * @return
     */
    public String clearPkgStatusToSfc(String orgCode, String pkgId, String currentQty,
                                      String plantCode, String dataSource) {

        SfcStoredProcedureService sfcService = sfcSpServiceMap.get(dataSource);
        Assert.notNull(sfcService, "init SfcStoredProcedureService error");

        String s = sfcService.clearPkgStatusToSfc(pkgId, currentQty, orgCode, plantCode);

        return s;

    }

    /**
     * 取PKG 状态值
     *
     * @param orgCode
     * @param pkgStatusInfoDto
     * @return
     */
    public PkgStatusInfoDto getPkgStatusInfo(String orgCode, PkgStatusInfoDto pkgStatusInfoDto,
                                             String plantCode, String dataSource) {

        SfcStoredProcedureService sfcService = sfcSpServiceMap.get(dataSource);
        Assert.notNull(sfcService, "init SfcStoredProcedureService error");

        PkgStatusInfoDto pkgStatusInfo = sfcService.getPkgStatusInfo(pkgStatusInfoDto, orgCode, plantCode);

        return pkgStatusInfo;
    }

    /**
     * 入库sn 回写SFC过账工站
     *
     * @param orgCode
     * @param warehousingPassSnStationDto
     * @return
     */
    public String warehousingPassSnStation(String orgCode, WarehousingPassSnStationDto warehousingPassSnStationDto,
                                           String plantCode, String dataSource) {

        SfcStoredProcedureService sfcService = sfcSpServiceMap.get(dataSource);
        Assert.notNull(sfcService, "init SfcStoredProcedureService error");

        String result = sfcService.doWarehousingPassSnStation(warehousingPassSnStationDto, orgCode, plantCode);

        return result;
    }

    /**
     * 取SFC SN的扩展信息 DEL
     *
     * @param dataSource 数据来源
     * @param sn      条码
     * @return 扩展信息
     */
    public Map getSfcExtendInfoBySn(String dataSource, String sn) {

        SfcStoredProcedureService sfcService = sfcSpServiceMap.get(dataSource);
        Assert.notNull(sfcService, "init getSfcExtendInfoBySn error");

        Map sfcExtendInfoBySn = sfcService.getSfcExtendInfoBySn(sn);


        return sfcExtendInfoBySn;
    }

    public String insertAmazonLog(String orgCode, InsertAmazonLogDto amazonLogDto) {
        SfcStoredProcedureService sfcService = sfcSpServiceMap.get(orgCode);
        Assert.notNull(sfcService, "init insertAmazonLog error");
        String result = sfcService.insertAmazonLog(amazonLogDto);
        return result;
    }

    public String sendProductShippingToSfc(String dataSource, PostProductShippingToSfcDto toSfcDto) {

        SfcStoredProcedureService sfcService = sfcSpServiceMap.get(dataSource);
        Assert.notNull(sfcService, "init sendProductShippingToSfc error");

        String s = sfcService.sendProductShippingToSfc(toSfcDto);

        return s;
    }

    /**
     * 按时间取SFC pkg上线使用信息 DEL
     *
     * @param orgCode
     * @param startDateTime
     * @return
     */
    public List<SfcWoUsePkgInfoDto> getSfcWoUsePkgInfo(String orgCode, String startDateTime) {

        SfcStoredProcedureService sfcService = sfcSpServiceMap.get(orgCode);
        Assert.notNull(sfcService, "init getSfcWoUsePkgInfo error");

        List<SfcWoUsePkgInfoDto> pkgLinkList = sfcService.getSfcWoUsePkgInfo(startDateTime);

        return pkgLinkList;

    }

    public Map getPkgRelation(String orgCode, String pkgId) {
        SfcStoredProcedureService sfcService = sfcSpServiceMap.get(orgCode);
        Assert.notNull(sfcService, "init getPkgRelation error");
        Map sfcPkgRelation = sfcService.getPkgRelation(pkgId);
        return sfcPkgRelation;
    }

    public SfcWoDto getSfcWoInfo(String dataSorce, String orgCode, String sn) {
        log.info("getSfcWoInfo param：sn:{}，dataSorce:{}", sn, dataSorce);
        SfcStoredProcedureService sfcService = sfcSpServiceMap.get(dataSorce);
        Assert.notNull(sfcService, "init getSfcWoInfo error");
        return sfcService.getSfcWoInfo(sn);
    }

    /**
     * from SFC 取成品入库栈板信息By 箱号
     *
     * @param orgCode  工厂组织
     * @param cartonNo 箱号
     * @return 取成品入库栈板信息
     */
    public List<SfcCartonInfoDTO> getSfcPalletInfoByCartonNo(String orgCode, String cartonNo,
                                                             String plantCode, String dataSource) {

        SfcStoredProcedureService sfcService = sfcSpServiceMap.get(dataSource);
        Assert.notNull(sfcService, "init getSfcPalletInfoByCartonNo error");
        return sfcService.getSfcPalletInfoByCartonNo(cartonNo, orgCode, plantCode);

    }

    public String getSfcErrorDesc(String orgCode, String plantCode, String dataSource, String errorCode) {
        log.info("getSfcWoInfo param：errorCode:{}，dataSource:{}", errorCode, dataSource);
        SfcStoredProcedureService sfcService = sfcSpServiceMap.get(dataSource);
        Assert.notNull(sfcService, "init getSfcErrorDesc error");
        String sfcErrorDesc = sfcService.getSfcErrorDesc(orgCode, plantCode, errorCode);
        return sfcErrorDesc;
    }

    public String getWoNoByPkgId(String orgCode, String plantCode, String pkgId, String dataSource) {
        SfcStoredProcedureService sfcService = sfcSpServiceMap.get(dataSource);
        Assert.notNull(sfcService, "init getWoNoByPkgId error");
        return sfcService.getWoNoByPkgId(orgCode, plantCode, pkgId);
    }

    public List<SfcBurnValueDto> getSFCBurnValue(String sfcSite, String productPartNo) {
        SfcStoredProcedureService sfcService = sfcSpServiceMap.get(sfcSite);
        Assert.notNull(sfcService, "init getSFCBurnValue error");
        List<SfcBurnValueDto> sfcBurnValueDtoList = sfcService.getSFCBurnValue(productPartNo);
        return sfcBurnValueDtoList;
    }

    public List<String> getSFCPkgId(String orgCode, String dataSorce, String pkgId, String plantCode) {
        SfcStoredProcedureService sfcService = sfcSpServiceMap.get(dataSorce);
        Assert.notNull(sfcService, "init getSFCPkgId error");
        return sfcService.getSFCPkgId(orgCode, plantCode, pkgId);
    }
}
