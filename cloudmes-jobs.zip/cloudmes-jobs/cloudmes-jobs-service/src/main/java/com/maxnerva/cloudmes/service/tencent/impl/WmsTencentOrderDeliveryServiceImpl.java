package com.maxnerva.cloudmes.service.tencent.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.entity.tencent.WmsTencentOrderDelivery;
import com.maxnerva.cloudmes.mapper.tencent.WmsTencentOrderDeliveryMapper;
import com.maxnerva.cloudmes.service.tencent.IWmsTencentOrderDeliveryService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * <p>
 * MES腾讯订单配送信息表 服务实现类
 * </p>
 *
 * @author likun
 * @since 2025-05-20
 */
@Slf4j
@Service
public class WmsTencentOrderDeliveryServiceImpl extends ServiceImpl<WmsTencentOrderDeliveryMapper, WmsTencentOrderDelivery> implements IWmsTencentOrderDeliveryService {

}
