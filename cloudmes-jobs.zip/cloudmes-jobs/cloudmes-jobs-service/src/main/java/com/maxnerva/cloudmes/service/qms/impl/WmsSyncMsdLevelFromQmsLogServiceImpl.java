package com.maxnerva.cloudmes.service.qms.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.entity.qms.WmsSyncMsdLevelFromQmsLog;
import com.maxnerva.cloudmes.mapper.qms.WmsSyncMsdLevelFromQmsLogMapper;
import com.maxnerva.cloudmes.service.qms.IWmsSyncMsdLevelFromQmsLogService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 从qms同步msd等级表 服务实现类
 * </p>
 *
 * @author likun
 * @since 2024-11-28
 */
@Service
public class WmsSyncMsdLevelFromQmsLogServiceImpl extends ServiceImpl<WmsSyncMsdLevelFromQmsLogMapper,
        WmsSyncMsdLevelFromQmsLog> implements IWmsSyncMsdLevelFromQmsLogService {

}
