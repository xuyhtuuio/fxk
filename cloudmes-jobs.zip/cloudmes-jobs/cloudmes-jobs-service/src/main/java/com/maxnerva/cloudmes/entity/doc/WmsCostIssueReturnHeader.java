package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * 
 * </p>
 *
 * @author Chao Zhang
 * @since 2022-12-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("wms_cost_issue_return_header")
public class WmsCostIssueReturnHeader extends Model<WmsCostIssueReturnHeader> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 费领/退单号
     */
    @TableField("doc_no")
    private String docNo;

    /**
     * 单据类型
     */
    @TableField("type")
    private String type;

    /**
     * 单据状态（NOT_DELIVERY：待出货；DELIVERY_COMPLETED：出货完成；NOT_RECEIVED：待收货；RECEIVED_COMPLETED：收货完成；NOT_SHELF：待上架；关闭：CLOSED）
     */
    @TableField("status")
    private String status;

    /**
     * 审批进度（NOT_SEND：未送签；COMPLETED：审核完成；SEND：已送签；REFUSED：拒签）
     */
    @TableField("approval_progress")
    private String approvalProgress;

    /**
     * 单据日期
     */
    @TableField("doc_date")
    private LocalDateTime docDate;

    /**
     * 费用代码
     */
    @TableField("cost_code")
    private String costCode;

    /**
     * 申请部门id
     */
    @TableField("apply_dept_id")
    private Integer applyDeptId;

    /**
     * 领料类型
     */
    @TableField("issue_type")
    private String issueType;

    /**
     * 领料区分
     */
    @TableField("issue_diff")
    private String issueDiff;

    /**
     * 费用吸收
     */
    @TableField("cost_absorb")
    private String costAbsorb;

    /**
     * 申请人工号
     */
    @TableField("apply_staff_code")
    private String applyStaffCode;

    /**
     * 申请人姓名
     */
    @TableField("apply_staff_name")
    private String applyStaffName;

    /**
     * 申请人分机
     */
    @TableField("apply_staff_extension")
    private String applyStaffExtension;

    /**
     * 所属bu
     */
    @TableField("org_code")
    private String orgCode;

    /**
     * 创建人
     */
    @TableField("creator")
    private String creator;

    /**
     * 创建人id
     */
    @TableField("creator_id")
    private Integer creatorId;

    /**
     * 创建时间
     */
    @TableField("created_dt")
    private Long createdDt;

    /**
     * 最后编辑人
     */
    @TableField("last_editor")
    private String lastEditor;

    /**
     * 最后编辑人id
     */
    @TableField("last_editor_id")
    private Integer lastEditorId;

    /**
     * 最后编辑时间
     */
    @TableField("last_edited_dt")
    private Long lastEditedDt;

    /**
     * 0=正常、1=删除
     */
    @TableField("is_deleted")
    private Boolean isDeleted;

    /**
     * 理由
     */
    @TableField("reason")
    private String reason;

    /**
     * 异动类型
     */
    @TableField("movement_type")
    private String movementType;

    /**
     * 说明
     */
    @TableField("doc_desc")
    private String docDesc;

    /**
     * 成本中心
     */
    @TableField("doc_type")
    private String docType;

    /**
     * 客户名称
     */
    @TableField("customer_name")
    private String customerName;

    /**
     * 报废类别
     */
    @TableField("scrap_category")
    private String scrapCategory;

    /**
     * 报废类型
     */
    @TableField("scrap_type")
    private String scrapType;

    /**
     * 报废区分
     */
    @TableField("scrap_diff")
    private String scrapDiff;

    /**
     * 专案名称
     */
    @TableField("project_name")
    private String projectName;

    /**
     * SAP工厂
     */
    @TableField("plant_code")
    private String plantCode;

    /**
     * 费领退分类（正常/RMA/報廢）
     */
    @TableField("cost_classify")
    private String costClassify;

    /**
     * 索赔单号
     */
    @TableField("claim_no")
    private String claimNo;

    /**
     * 总金额
     */
    @TableField("total_price")
    private String totalPrice;

    /**
     * 币别
     */
    @TableField("coin_type")
    private String coinType;

    /**
     * flownet返回URL
     */
    @TableField("flownet_url")
    private String flownetUrl;

    /**
     * flownet调用结果,SUCCESS
     */
    @TableField("flownet_flag")
    private String flownetFlag;

    /**
     * flownet返回表单id
     */
    @TableField("flownet_form_id")
    private String flownetFormId;

    /**
     * flownet返回描述，Approved:同意
     */
    @TableField("flownet_msg")
    private String flownetMsg;

    /**
     * flownet审批结果
     */
    @TableField("flownet_approval_result")
    private String flownetApprovalResult;

    /**
     * 申请部门名称
     */
    @TableField("apply_dept_name")
    private String applyDeptName;

    @TableField("post_sap_return_number")
    private String postSapReturnNumber;

    @TableField("post_sap_return_msg")
    private String postSapReturnMsg;

    @TableField("post_sap_datetime")
    private LocalDateTime postSapDatetime;

    @TableField("post_sap_user")
    private String postSapUser;

    /**
     * 专案编码
     */
    @TableField("project_code")
    private String projectCode;

    /**
     * 是否整体过账
     */
    @TableField("bulk_posting")
    private Boolean bulkPosting;

    @Override
    public Serializable pkVal() {
        return this.id;
    }

}
