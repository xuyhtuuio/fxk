package com.maxnerva.cloudmes.service.wo.impl;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpStatus;
import cn.hutool.json.JSONUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.util.StringUtil;
import com.maxnerva.cloudmes.entity.wo.WmsPkgBurnInfo;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderHeader;
import com.maxnerva.cloudmes.mapper.wo.WmsPkgBurnInfoMapper;
import com.maxnerva.cloudmes.mapper.wo.WmsWorkOrderHeaderMapper;
import com.maxnerva.cloudmes.service.mes.MesService;
import com.maxnerva.cloudmes.service.wo.IWmsPkgBurnInfoService;
import com.maxnerva.cloudmes.service.wo.model.BurnInfoNewDTO;
import com.maxnerva.cloudmes.service.wo.model.GetBurnValueVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author hgx
 * @Description 烧录信息
 * @Date 2023/9/5
 */
@Slf4j
@Service
public class WmsPkgBurnInfoServiceImpl extends ServiceImpl<WmsPkgBurnInfoMapper, WmsPkgBurnInfo> implements IWmsPkgBurnInfoService {

    @Resource
    private MesService mesService;

    @Resource
    private WmsWorkOrderHeaderMapper wmsWorkOrderHeaderMapper;


    @Override
    public List<BurnInfoNewDTO> getBurnedInfo(String orgCode, String finishedProductPartNo) {
        WmsWorkOrderHeader wmsWorkOrderHeader = wmsWorkOrderHeaderMapper.selectOne(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                .eq(WmsWorkOrderHeader::getPartNo, finishedProductPartNo)
                .last("limit 1"));
        if (ObjectUtil.isNull(wmsWorkOrderHeader)) {
            throw new RuntimeException("no wo header of part no is:" + finishedProductPartNo);
        }
        GetBurnValueVO vo = new GetBurnValueVO();
        vo.setFinishedProductPartNo(finishedProductPartNo);
        vo.setOrgCode(orgCode);
        HttpResponse httpResponse = mesService.getBurnValue(vo);
        if (httpResponse.getStatus() != HttpStatus.HTTP_OK) {
            throw new RuntimeException("call MES fail");
        }
        log.info("getBurnedInfo request:{}, return:{}", JSONUtil.toJsonStr(vo), httpResponse.body());
        String body = httpResponse.body();
        if (StrUtil.isEmpty(body)) {
            throw new RuntimeException("MES return is empty");
        }
        JSONObject dataHubReturnInfo = JSON.parseObject(body);
        int code = dataHubReturnInfo.getInteger("code");
        String msg = dataHubReturnInfo.getString("msg");
        if (200 != code) {
            throw new RuntimeException("MES return error:"+msg);
        }
        String data = dataHubReturnInfo.getString("data");
        if (StringUtil.isEmpty(data)) {
            return new ArrayList<BurnInfoNewDTO>();
        }
        return JSON.parseArray(data, BurnInfoNewDTO.class);
    }
}
