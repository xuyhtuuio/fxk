package com.maxnerva.cloudmes.service.sap.doc.model;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @Author hgx
 * @Description JIT收货单
 * @Date 2023/3/17 16:26
 */
@Data
public class JitReceiptDto {

    private String buName;

    private String plant;

    private Integer receiptType;

    private String receiptNumber;

    private String receiptItem;

    private String supplierName;

    private String partNo;

    private String poNumber;

    private String poItem;

    private BigDecimal qty;

    private String unit;

    private String customer;

    private String vendor;

    private String type;

    private String asnDate;

    private String dnNo;

    private String dnItem;

    private String companyCode;
}
