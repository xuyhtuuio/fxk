package com.maxnerva.cloudmes.service.sfc.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/09/20 08:49
 * @Version: 1.0
 */
@Data
public class SnSfcExtendInfoDto implements Serializable {

    private static final long serialVersionUID = 1L;
    private String SN;
    //成品料号
    private String modelName;
    //料号版次
    private String rev;
    //料号系列
    private String modelSerial;
    //客户料号
    private String IPN;
    //assetID
    private String assetidAddress;

}
