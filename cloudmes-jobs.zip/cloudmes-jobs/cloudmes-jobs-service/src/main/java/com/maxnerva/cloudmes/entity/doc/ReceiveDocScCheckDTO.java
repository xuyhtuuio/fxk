package com.maxnerva.cloudmes.entity.doc;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@ApiModel("协作云check请求体")
@Data
public class ReceiveDocScCheckDTO {
    @ApiModelProperty(value = "来源系统 默认WMS")
    private String fromSystem;

    @ApiModelProperty(value = "BU", required = true)
    private String bu;

    @ApiModelProperty(value = "PO", required = true)
    private String poNumber;

    @ApiModelProperty(value = "厂商代码", required = true)
    private String vendorCode;

    @ApiModelProperty(value = "厂商名称", required = true)
    private String vendorName;

    @ApiModelProperty(value = "厂商料号，料号数组")
    List<ScCheckPartNoDTO> partNumberList;

    @ApiModelProperty(value = "默认ig-admin-0001")
    private String createUserId;
}
