package com.maxnerva.cloudmes.mapper.deliver;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.deliver.DnPostSfcDTO;
import com.maxnerva.cloudmes.entity.deliver.WmsDocProductShipHeader;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface WmsProductShipHeaderMapper extends BaseMapper<WmsDocProductShipHeader> {

    List<DnPostSfcDTO> selectPostSfcDnList(@Param("orgCode") String orgCode);
}
