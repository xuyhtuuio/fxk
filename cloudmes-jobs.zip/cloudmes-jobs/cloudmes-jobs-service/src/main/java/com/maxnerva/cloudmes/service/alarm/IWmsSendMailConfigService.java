package com.maxnerva.cloudmes.service.alarm;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.entity.alarm.WmsSendMailConfig;

/**
 * <p>
 * 邮件配置表 服务类
 * </p>
 *
 * @author likun
 * @since 2023-12-19
 */
public interface IWmsSendMailConfigService extends IService<WmsSendMailConfig> {

}
