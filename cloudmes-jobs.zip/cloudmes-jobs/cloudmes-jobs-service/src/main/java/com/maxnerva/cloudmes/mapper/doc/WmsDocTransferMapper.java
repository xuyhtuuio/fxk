package com.maxnerva.cloudmes.mapper.doc;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.doc.WmsDocTransfer;

import java.util.List;


/**
 * @author H7109018
 */
public interface WmsDocTransferMapper extends BaseMapper<WmsDocTransfer> {

    List<WmsDocTransfer> selectSyncTransferDoc(String orgCode);
}
