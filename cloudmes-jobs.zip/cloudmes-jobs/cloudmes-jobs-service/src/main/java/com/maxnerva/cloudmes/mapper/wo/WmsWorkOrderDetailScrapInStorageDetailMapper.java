package com.maxnerva.cloudmes.mapper.wo;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.scrap.WmsWorkOrderDetailScrapInStorageDetailEntity;

import java.util.List;

/**
 * <p>
 * 工单明细报废单入库明细表 Mapper 接口
 * </p>
 *
 * @author Chao Zhang
 * @since 2023-07-07
 */
public interface WmsWorkOrderDetailScrapInStorageDetailMapper extends BaseMapper<WmsWorkOrderDetailScrapInStorageDetailEntity> {

    List<WmsWorkOrderDetailScrapInStorageDetailEntity> selectPostFlownetList(String orgCode);
}
