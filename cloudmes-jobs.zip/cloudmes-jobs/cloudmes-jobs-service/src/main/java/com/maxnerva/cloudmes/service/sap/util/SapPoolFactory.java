package com.maxnerva.cloudmes.service.sap.util;

import com.sap.conn.jco.JCoDestination;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @Description:
 * @Package: com.foxconn.cesbg.service.finishedProduct
 * @ClassName: StockInService
 * @Author: Chao Zhang
 * @Date: 2021/11/16
 * @Version: 1.0
 */
@Service
public class SapPoolFactory {

    /**
     * 自动注入策略接口的实现
     */
    @Autowired
    Map<String, SapPoolService> sapPoolServiceMap = new ConcurrentHashMap<>(10);

    public JCoDestination getSapPool(String clientId) {
        SapPoolService sapPoolService = sapPoolServiceMap.get("sap");
        return sapPoolService.getSapPool(clientId);
    }

    public JCoDestination getSapPool() {
        return getSapPool("sap");
    }
}
