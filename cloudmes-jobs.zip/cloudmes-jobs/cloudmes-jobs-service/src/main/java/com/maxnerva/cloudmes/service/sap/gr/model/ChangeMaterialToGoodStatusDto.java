package com.maxnerva.cloudmes.service.sap.gr.model;

import lombok.Data;

/**
 * @author H7109018
 */
@Data
public class ChangeMaterialToGoodStatusDto {
	private String partNo;
	private String Plant;
	private String toWarehouseName;
	private String qty;
	private String grNumber;
	private String grDate;
}
