package com.maxnerva.cloudmes.entity.scrap;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.time.LocalDate;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author Chao Zhang
 * @since 2023-10-31
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("wms_bad_product_in_storage")
public class WmsBadProductInStorageEntity extends Model<WmsBadProductInStorageEntity> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @TableField("doc_no")
    private String docNo;

    /**
     * BU
     */
    @TableField("org_code")
    private String orgCode;

    /**
     * 工厂
     */
    @TableField("plant_code")
    private String plantCode;

    /**
     * 操作类型（不良退料：BAD_RETURN；不良置換：BAD_REPLACEMENT；拆解不良：POOR_DISASSEMBLY；制程报废：PROCESS_SCRAP）
     */
    @TableField("operation_type")
    private String operationType;

    /**
     * 料号
     */
    @TableField("part_no")
    private String partNo;

    /**
     * 制造商名称
     */
    @TableField("mfg_name")
    private String mfgName;

    /**
     * 制造商料号
     */
    @TableField("mfg_part_no")
    private String mfgPartNo;

    /**
     * PN\SN退料时为料件SN，PKGID退料时为PKGID
     */
    @TableField("pkg_id")
    private String pkgId;

    /**
     * 数量
     */
    @TableField("qty")
    private BigDecimal qty;

    /**
     * 工单号
     */
    @TableField("work_order_no")
    private String workOrderNo;

    /**
     * 不良原因
     */
    @TableField("bad_reason")
    private String badReason;

    /**
     * 物料来源（页面新增时：来料不良：BAD_SOURCE_MATERIAL；制程分类：PROCESS_CLASSIFY）
     */
    @TableField("material_source")
    private String materialSource;

    /**
     * IQC判定人
     */
    @TableField("iqc_person")
    private String iqcPerson;

    /**
     * 复判结果
     */
    @TableField("repeat_result")
    private String repeatResult;

    /**
     * 退料次数
     */
    @TableField("return_count")
    private String returnCount;

    /**
     * Vendor_OSV
     */
    @TableField("vendor_osv")
    private String vendorOsv;

    /**
     * SQE_OSV
     */
    @TableField("sqe_osv")
    private String sqeOsv;

    /**
     * 库存状态
     */
    @TableField("inventory_status")
    private String inventoryStatus;

    /**
     * 出库日期
     */
    @TableField("ship_date")
    private LocalDate shipDate;

    /**
     * 物控
     */
    @TableField("material_control")
    private String materialControl;

    /**
     * 对策回复人
     */
    @TableField("responder")
    private String responder;

    /**
     * 处理对策
     */
    @TableField("deal_method")
    private String dealMethod;

    /**
     * 物料类型
     */
    @TableField("material_type")
    private String materialType;

    /**
     * 创建人
     */
    @TableField("creator")
    private String creator;

    /**
     * 创建人员工id，冗余字段
     */
    @TableField("creator_id")
    private Integer creatorId;

    /**
     * 创建时间
     */
    @TableField("created_dt")
    private LocalDateTime createdDt;

    /**
     * 修改人
     */
    @TableField("last_editor")
    private String lastEditor;

    /**
     * 修改人员工id，冗余字段
     */
    @TableField("last_editor_id")
    private Integer lastEditorId;

    /**
     * 修改时间
     */
    @TableField("last_edited_dt")
    private LocalDateTime lastEditedDt;

    /**
     * 不良品仓码
     */
    @TableField("bad_warehouse_code")
    private String badWarehouseCode;

    /**
     * 单据状态（0：新建；1：已入库；2：已置换）
     */
    @TableField("status")
    private String status;

    /**
     * 入库操作人
     */
    @TableField("in_storage_operator")
    private String inStorageOperator;

    /**
     * 入库时间
     */
    @TableField("in_storage_dt")
    private LocalDateTime inStorageDt;

    /**
     * 置换操作人
     */
    @TableField("replace_operator")
    private String replaceOperator;

    /**
     * 置换时间
     */
    @TableField("replace_dt")
    private LocalDateTime replaceDt;

    /**
     * 入库数量
     */
    @TableField("in_storage_qty")
    private BigDecimal inStorageQty;

    /**
     * 置换PKGID
     */
    @TableField("replace_pkg_id")
    private String replacePkgId;

    /**
     * 良品仓码
     */
    @TableField("good_warehouse_code")
    private String goodWarehouseCode;

    /**
     * 不良代码
     */
    @TableField("bad_reason_code")
    private String badReasonCode;

    /**
     * SFC-PKGID，SN退料时从SFC获取
     */
    @TableField("sfc_pkg_id")
    private String sfcPkgId;

    /**
     * 退料方式
     */
    @TableField("return_method")
    private String returnMethod;

    /**
     * PN/SN退料时SN对应PKGID
     */
    @TableField("sn_pkg_id")
    private String snPkgId;

    /**
     * 解析datecode  解析D/C
     */
    @TableField("date_code")
    private LocalDate dateCode;

    /**
     * 原始datecode 原始D/C
     */
    @TableField("original_date_code")
    private String originalDateCode;

    /**
     * 批次号
     */
    @TableField("lot_code")
    private String lotCode;

    /**
     * 原产国1
     */
    @TableField("place_of_origin1")
    private String placeOfOrigin1;

    /**
     * 过账数量
     */
    @TableField("post_sap_qty")
    private BigDecimal postSapQty;

    /**
     * 过账单号
     */
    @TableField("post_sap_no")
    private String postSapNo;

    /**
     * 过账时间
     */
    @TableField("post_sap_date")
    private LocalDateTime postSapDate;

    @TableField("post_sap_msg")
    private String postSapMsg;

    /**
     * 抛QMS时间
     */
    @TableField("post_qms_date")
    private LocalDateTime postQmsDate;

    /**
     * 外观检验结果标识(成功：Y，失败：N)
     */
    @TableField("qms_return_wg_result")
    private String qmsReturnWgResult;

    /**
     * 外观检验结果描述
     */
    @TableField("qms_return_wg_msg")
    private String qmsReturnWgMsg;

    /**
     * QMS初判结果返回时间
     */
    @TableField("qms_return_wg_date")
    private LocalDateTime qmsReturnWgDate;

    /**
     * QMS返回是否结案（是：Y，否：N）
     */
    @TableField("qms_return_is_close")
    private String qmsReturnIsClose;

    /**
     * 是否做OSV
     */
    @TableField("qms_return_is_do_osv")
    private String qmsReturnIsDoOsv;

    /**
     * OSV结果
     */
    @TableField("qms_return_osv_result")
    private String qmsReturnOsvResult;

    /**
     * OSV结果描述
     */
    @TableField("qms_return_osv_msg")
    private String qmsReturnOsvMsg;

    /**
     * QMS返回OSV结果时间
     */
    @TableField("qms_return_osv_date")
    private LocalDateTime qmsReturnOsvDate;

    /**
     * 是否在库（是：Y，否：N）
     */
    @TableField("is_in_stock")
    private String isInStock;

    /**
     * 领用下架标识（0：初始，1：待下架，2：已下架）
     */
    @TableField("issue_flag")
    private String issueFlag;

    /**
     * 领用下架人
     */
    @TableField("issue_by")
    private String issueBy;

    /**
     * 领用下架时间
     */
    @TableField("issue_date_time")
    private LocalDateTime issueDateTime;

    /**
     * 归还上架标识（0：初始，1：待上架，2：已上架）
     */
    @TableField("return_flag")
    private String returnFlag;

    /**
     * 归还上架人
     */
    @TableField("return_by")
    private String returnBy;

    /**
     * 归还上架时间
     */
    @TableField("return_date_time")
    private LocalDateTime returnDateTime;

    /**
     * 领用仓码
     */
    @TableField("issue_warehouse_code")
    private String issueWarehouseCode;

    /**
     * 领用过账时间
     */
    @TableField("issue_post_date_time")
    private LocalDateTime issuePostDateTime;

    /**
     * 领用过账单号
     */
    @TableField("issue_post_no")
    private String issuePostNo;

    /**
     * 领用过账信息
     */
    @TableField("issue_post_msg")
    private String issuePostMsg;

    /**
     * 归还仓码
     */
    @TableField("return_warehouse_code")
    private String returnWarehouseCode;

    /**
     * 归还过账时间
     */
    @TableField("return_post_date_time")
    private LocalDateTime returnPostDateTime;

    /**
     * 归还过账单号
     */
    @TableField("return_post_no")
    private String returnPostNo;

    /**
     * 归还过账信息
     */
    @TableField("return_post_msg")
    private String returnPostMsg;

    /**
     * 领用下架名称
     */
    @TableField("issue_flag_name")
    private String issueFlagName;

    /**
     * 归还上架标识名称
     */
    @TableField("return_flag_name")
    private String returnFlagName;

    /**
     * 入库时间
     */
    @TableField("in_storage_date")
    private LocalDate inStorageDate;

    /**
     * 申请领用人
     */
    @TableField("apply_issue_by")
    private String applyIssueBy;

    /**
     * 申请领用时间
     */
    @TableField("apply_issue_date")
    private LocalDateTime applyIssueDate;

    /**
     * 申请归还人
     */
    @TableField("apply_return_by")
    private String applyReturnBy;

    /**
     * 申请归还时间
     */
    @TableField("apply_return_date")
    private LocalDateTime applyReturnDate;

    @TableField("part_version")
    private String partVersion;


    @Override
    public Serializable pkVal() {
        return this.id;
    }

}
