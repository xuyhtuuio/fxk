package com.maxnerva.cloudmes.service.datacenter.model;

import com.fasterxml.jackson.annotation.JsonAlias;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class GetJusdaInventoryDTO {

    @ApiModelProperty(value = "SITE")
    private String site;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "mrpArea")
    private String mrpArea;

    @ApiModelProperty(value = "customerPartNo")
    @JsonAlias("CustomerPartNo")
    private String customerPartNo;

    @ApiModelProperty(value = "supplierPartNo")
    @JsonAlias("SupplierPartNo")
    private String supplierPartNo;

    @ApiModelProperty(value = "manufactureName")
    @JsonAlias("ManufactureName")
    private String manufactureName;

    @ApiModelProperty(value = "工厂")
    private String sapPlantCode;

    @ApiModelProperty(value = "仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "HubInvQty")
    @JsonAlias("HubInvQty")
    private BigDecimal hubInvQty;

    @ApiModelProperty(value = "qty")
    @JsonAlias("Qty")
    private BigDecimal qty;

    @ApiModelProperty(value = "uom")
    @JsonAlias("UOM")
    private String uom;
}
