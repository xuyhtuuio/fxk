package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * <p>
 * 制造商料号表
 * </p>
 *
 * @author Chao Zhang
 * @since 2022-11-19
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("basic_sys.basic_material_mfg")
public class BasicMaterialMfgEntity extends Model<BasicMaterialMfgEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 物料ID
     */
    @TableField("material_id")
    private Integer materialId;

    /**
     * 制造商料号
     */
    @TableField("mfg_material_code")
    private String mfgMaterialCode;

    /**
     * 制造商料号名称
     */
    @TableField("mfg_material_name")
    private String mfgMaterialName;

    /**
     * 制造商版次
     */
    @TableField("mfg_material_version")
    private String mfgMaterialVersion;

    /**
     * 制造商原始料号
     */
    @TableField("mfg_original_material")
    private String mfgOriginalMaterial;

    /**
     * 有效期（天）
     */
    @TableField("valid_period")
    private Integer validPeriod;

    /**
     * 有效期开始时间
     */
    @TableField("start_valid_date")
    private LocalDate startValidDate;

    /**
     * 有效期结束时间
     */
    @TableField("end_valid_date")
    private LocalDate endValidDate;

    /**
     * 生产日期格式
     */
    @TableField("datecode_format")
    private String datecodeFormat;

    /**
     * MSD等级
     */
    @TableField("msd_level")
    private String msdLevel;

    /**
     * 备注
     */
    @TableField("remark")
    private String remark;

    /**
     * 创建人code
     */
    @TableField("creator")
    private String creator;

    /**
     * 创建人id
     */
    @TableField("creator_id")
    private Integer creatorId;

    /**
     * 创建时间
     */
    @TableField("created_dt")
    private Long createdDt;

    /**
     * 最后一次编辑人code
     */
    @TableField("last_editor")
    private String lastEditor;

    /**
     * 最后一次编辑人id
     */
    @TableField("last_editor_id")
    private Integer lastEditorId;

    /**
     * 最后一次编辑时间
     */
    @TableField("last_edited_dt")
    private Long lastEditedDt;

    @TableField("org_code")
    private String orgCode;

    /**
     * 是否删除
     */
    @TableField("is_deleted")
    private Boolean isDeleted;

    /**
     * 制造商名称
     */
    @TableField("mfg_name")
    private String mfgName;

    /**
     * 物料编码
     */
    @TableField("material_no")
    private String materialNo;

    /**
     * 包装数量
     */
    @TableField("pack_qty")
    private Integer packQty;


    @Override
    public Serializable pkVal() {
        return this.id;
    }

}
