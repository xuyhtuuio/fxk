package com.maxnerva.cloudmes.mapper.wo;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderDetailInStorage;

/**
 * <p>
 * 工单明细531入库信息表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2023-03-01
 */
public interface WmsWorkOrderDetailInStorageMapper extends BaseMapper<WmsWorkOrderDetailInStorage> {

    /**
     * 新增工单detail instorage信息
     *
     * @param wmsWorkOrderDetailInStorage
     * @return
     */
    int insertWoDetailInStorageInfo(WmsWorkOrderDetailInStorage wmsWorkOrderDetailInStorage);

}
