package com.maxnerva.cloudmes.service.mes;

import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.json.JSONUtil;
import com.maxnerva.cloudmes.config.DataHubUrlConfig;
import com.maxnerva.cloudmes.entity.mes.*;
import com.maxnerva.cloudmes.service.mes.model.ComponentImportDTO;
import com.maxnerva.cloudmes.service.mes.model.PkgInfoDTO;
import com.maxnerva.cloudmes.service.sfc.model.*;
import com.maxnerva.cloudmes.service.wo.model.GetBurnValueVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName MesService
 * @Description mesService
 * @Author Likun
 * @Date 2023/2/22
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Service
@Slf4j
public class MesService {

    @Resource
    private DataHubUrlConfig dataHubUrlConfig;

    public HttpResponse postingWoPreparePkgInfoToMes(List<PkgInfoDTO> pkgInfoDTOList) {
        String url = dataHubUrlConfig.getSyncPkgInfoUrl();
        HttpResponse response = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(pkgInfoDTOList))
                .execute();
        return response;
    }

    public HttpResponse getFeedBom(FeedBomFeignDTO feedBomFeignDTO) {
        String url = dataHubUrlConfig.getFeedBomUrl();
        HttpResponse response = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(feedBomFeignDTO))
                .execute();
        return response;
    }

    public HttpResponse getInstoreProduct(InStoreFeignDTO inStoreFeignDTO) {
        String url = dataHubUrlConfig.getInstoreProductUrl();
        HttpResponse response = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(inStoreFeignDTO))
                .execute();
        return response;
    }

    public HttpResponse inStorePassStation(InStorePassStationDTO inStorePassStationDTO) {
        String url = dataHubUrlConfig.getInStorePassStationUrl();
        HttpResponse response = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(inStorePassStationDTO))
                .execute();
        return response;
    }

    public HttpResponse syncMsd(MsdSyncDTO msdSyncDTO) {
        String url = dataHubUrlConfig.getSyncMsdUrl();
        HttpResponse response = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(msdSyncDTO))
                .execute();
        return response;
    }

    public HttpResponse queryPkgId(PkgIdDTO pkgIdDTO) {
        String url = dataHubUrlConfig.getQueryPkgIdUrl();
        HttpResponse response = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(pkgIdDTO))
                .execute();
        return response;
    }

    public HttpResponse queryPalletInfo(SfcCartonNoDTO sfcCartonNoDTO) {
        String url = dataHubUrlConfig.getQueryPalletInfoUrl();
        HttpResponse response = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(sfcCartonNoDTO))
                .execute();
        return response;
    }

    public HttpResponse returnPkgInfo(PkgInfoReturnDTO pkgInfoReturnDTO) {
        String url = dataHubUrlConfig.getReturnPkgInfoUrl();
        HttpResponse response = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(pkgInfoReturnDTO))
                .execute();
        return response;
    }

    public HttpResponse getBurnValue(GetBurnValueVO getBurnValueVO) {
        String url = dataHubUrlConfig.getGetBurnValueUrl();
        return HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(getBurnValueVO))
                .execute();
    }

    public HttpResponse receiveShippingData(SendSnDnRelationShipToMesVO sendSnDnRelationShipToMesVO) {
        String url = dataHubUrlConfig.getSendSnDnRelationShipToMesUrl();
        HttpResponse response = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(sendSnDnRelationShipToMesVO))
                .execute();
        return response;
    }

    public HttpResponse shippingPassStation(PostProductShippingToSfcDto postProductShippingToSfcDto) {
        String url = dataHubUrlConfig.getShippingPassStationUrl();
        HttpResponse response = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(postProductShippingToSfcDto))
                .execute();
        return response;
    }

    public HttpResponse getSfcWoInfo(MesWoInfoVo mesWoInfoVo) {
        String url = dataHubUrlConfig.getSfcWoInfoUrl();
        HttpResponse response = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(mesWoInfoVo))
                .execute();
        return response;
    }

    public HttpResponse getSfcErrorDesc(MesErrorDescVo mesErrorDescVo) {
        String url = dataHubUrlConfig.getSfcErrorDescUrl();
        HttpResponse response = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(mesErrorDescVo))
                .execute();
        return response;
    }

    public HttpResponse getWoNoByPkgId(WoNoByPkgIdVo woNoByPkgIdVo) {
        String url = dataHubUrlConfig.getWoNoByPkgIdUrl();
        HttpResponse response = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(woNoByPkgIdVo))
                .execute();
        return response;
    }

    public HttpResponse postingReceiveSnToMes(List<ComponentImportDTO> componentImportDTOList) {
        String url = dataHubUrlConfig.getSyncComponentSnUrl();
        HttpResponse response = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(componentImportDTOList))
                .execute();
        return response;
    }

    public HttpResponse postPoSnDataToMes(List<PoSnBindVO> poSnBindVOList){
        String url = dataHubUrlConfig.getReceivePoSnData();
        HttpResponse response = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(poSnBindVOList))
                .execute();
        return response;
    }
}
