package com.maxnerva.cloudmes.entity.datacenter;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * WMS抛FII数据日志
 * </p>
 *
 * @author baomidou
 * @since 2024-11-28
 */
@TableName("wms_post_fii_log")
@ApiModel(value = "WmsPostFiiLog对象", description = "WMS抛FII数据日志")
@Data
public class WmsPostFiiLog extends BaseEntity<WmsPostFiiLog> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("抛转数据类型")
    private String postType;

    @ApiModelProperty("查询参数")
    private String queryContent;

    @ApiModelProperty("请求参数")
    private String requestContent;

    @ApiModelProperty("响应参数")
    private String responseContent;

    @ApiModelProperty(value = "抛转状态 1 全成功，2 存在未成功数据")
    private String status;
}
