package com.maxnerva.cloudmes.entity.doc;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName ReceiveSnPostToMesDTO
 * @Description TODO
 * @Author Likun
 * @Date 2024/9/3
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("物料SN抛MES")
@Data
public class ReceiveSnPostToMesDTO {

    @ApiModelProperty("id")
    private Integer id;

    @ApiModelProperty("组织")
    private String orgCode;

    @ApiModelProperty("SN")
    private String snNo;

    @ApiModelProperty("料号")
    private String partNo;

    @ApiModelProperty("制造商名称")
    private String mfgName;

    @ApiModelProperty("制造商料号")
    private String mfgPartNo;

    @ApiModelProperty("原产国")
    private String placeOfOrigin1;
}
