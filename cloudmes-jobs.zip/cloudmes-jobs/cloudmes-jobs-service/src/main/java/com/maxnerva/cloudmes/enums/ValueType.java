package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

public enum ValueType {
    /**
     * 调整单单据类型
     */
    E5T1_ROH("ROH", "COSTRM"),
    E5T1_HALB("HALB", "COSTSG"),
    E5T1_FERT("FERT", "COSTFG");

    private String dictCode;

    private String dictName;

    ValueType(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public void setDictCode(String dictCode) {
        this.dictCode = dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public void setDictName(String dictName) {
        this.dictName = dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (ValueType valueType : values()) {
            if (valueType.getDictCode().equals(dictCode)) {
                return valueType.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }
}
