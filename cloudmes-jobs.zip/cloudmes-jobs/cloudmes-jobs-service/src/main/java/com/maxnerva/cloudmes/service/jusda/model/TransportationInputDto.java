package com.maxnerva.cloudmes.service.jusda.model;

import lombok.Data;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2023/04/21 18:17
 * @Version: 1.0
 */
@Data
public class TransportationInputDto {
    private ShipAddressDto shipFromAddress;
    private ShipAddressDto shipToAddress;
    private String carrierCompanyCode;
    private String shippingMode;
    private String loadingPort;
    private String destinationPort;
    private String masterBill;
    private String houseBill;
    private String containerNo;
    private String packageType;
}
