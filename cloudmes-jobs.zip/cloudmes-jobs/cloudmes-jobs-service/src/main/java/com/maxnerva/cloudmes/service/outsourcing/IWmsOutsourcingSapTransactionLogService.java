package com.maxnerva.cloudmes.service.outsourcing;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.entity.outsourcing.WmsOutsourcingSapTransactionLog;

/**
 * <p>
 * 委外过账清单 服务类
 * </p>
 *
 * @author likun
 * @since 2023-12-05
 */
public interface IWmsOutsourcingSapTransactionLogService extends IService<WmsOutsourcingSapTransactionLog> {

    void doBatchTransferOutsourcingPosted(String sapClientCode, String orgCode, String postDate);
}
