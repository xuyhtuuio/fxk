package com.maxnerva.cloudmes.entity.basic;

import lombok.Data;

@Data
public class GetProductFlagDTO {

    private String orgCode;

    private String plantCode;

    private String materialNo;

    private Boolean productFlag;
}
