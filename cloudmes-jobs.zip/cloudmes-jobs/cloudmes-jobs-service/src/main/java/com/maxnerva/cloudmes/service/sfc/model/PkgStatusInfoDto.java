package com.maxnerva.cloudmes.service.sfc.model;

import lombok.Data;

import java.io.Serializable;
import java.security.PrivateKey;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/09/19 16:50
 * @Version: 1.0
 */
@Data
public class PkgStatusInfoDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * pkg id
     */
    private String pkgId;

    /**
     * 当前数量
     */
    private String remainQty;

    /**
     * OK/错误信息
     */
    private String result;

    /**
     * 丝印结果： NA(不需要比对丝印)，Y(已比对丝印)，N (未比对丝印)
     */
    private String topMarking;

    /**
     * MSD结果： NA(非MSD物料)，剩余小时数
     */
    private String msdValue;

    /**
     * LCR结果 ：  NA(不需要测值)，Y(已测值)，N (未测值)
     */
    private String lcrValue;

    /**
     * MSD是否开封 ：  NA(非MSD物料)，Y(已开封)，N (未开封)
     */
    private String msdOpen;

    /**
     * 是否在线 ：  Y(在线使用中)，N (下线状态)
     */
    private String isOnline;

}
