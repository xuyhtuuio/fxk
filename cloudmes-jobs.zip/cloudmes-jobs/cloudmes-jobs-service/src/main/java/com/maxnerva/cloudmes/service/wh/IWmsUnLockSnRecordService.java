package com.maxnerva.cloudmes.service.wh;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.entity.wh.WmsUnLockSnRecord;

/**
 * <p>
 * mes通知解锁sn记录表 服务类
 * </p>
 *
 * @author likun
 * @since 2024-08-07
 */
public interface IWmsUnLockSnRecordService extends IService<WmsUnLockSnRecord> {

    void unLockSn(String orgCode);
}
