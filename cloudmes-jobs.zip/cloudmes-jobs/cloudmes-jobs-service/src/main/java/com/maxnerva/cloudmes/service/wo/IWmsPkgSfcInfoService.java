package com.maxnerva.cloudmes.service.wo;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.entity.pkg.WmsPkgSfcInfoEntity;

/**
 * @ClassName IWmsPkgSfcInfoService
 * @Description sfc info
 * @Author Likun
 * @Date 2023/6/10
 * @Version 1.0
 * @Since JDK 1.8
 **/
public interface IWmsPkgSfcInfoService extends IService<WmsPkgSfcInfoEntity> {
}
