package com.maxnerva.cloudmes.service.alarm.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.entity.alarm.WmsSendMailConfig;
import com.maxnerva.cloudmes.mapper.alarm.WmsSendMailConfigMapper;
import com.maxnerva.cloudmes.service.alarm.IWmsSendMailConfigService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 邮件配置表 服务实现类
 * </p>
 *
 * @author likun
 * @since 2023-12-19
 */
@Service
public class WmsSendMailConfigServiceImpl extends ServiceImpl<WmsSendMailConfigMapper, WmsSendMailConfig> implements IWmsSendMailConfigService {

}
