package com.maxnerva.cloudmes.entity.wo;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * (WmsWorkOrderPrepareCkdShipDetail)实体类
 *
 * @author hgx
 * @since 2024-01-30
 */

@ApiModel("WmsWorkOrderPrepareCkdShipDetail实体类")
@Data
public class WmsWorkOrderPrepareCkdShipDetail extends BaseEntity<WmsWorkOrderPrepareCkdShipDetail> {
 
   
    @ApiModelProperty("id")
    private Integer id;
   
    @ApiModelProperty("orgCode")
    private String orgCode;
   
    @ApiModelProperty("plantCode")
    private String plantCode;
   
    @ApiModelProperty("料号")
    private String partNo;
   
    @ApiModelProperty("打包序列号")
    private String serialNo;
   
    @ApiModelProperty("数量")
    private BigDecimal qty;
   
    @ApiModelProperty("工单")
    private String workOrderNo;
   
    @ApiModelProperty("厂商料号")
    private String supplierPartNo;
   
    @ApiModelProperty("厂商名")
    private String mfgName;
   
    @ApiModelProperty("po项次")
    private String item;
   
    @ApiModelProperty("仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "原产国")
    private String placeOfOrigin1;
}

