package com.maxnerva.cloudmes.service.qms.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.entity.qms.WmsSyncMfgMaterialFromQmsLog;
import com.maxnerva.cloudmes.mapper.qms.WmsSyncMfgMaterialFromQmsLogMapper;
import com.maxnerva.cloudmes.service.qms.IWmsSyncMfgMaterialFromQmsLogService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 从qms同步有效期log表 服务实现类
 * </p>
 *
 * @author likun
 * @since 2024-11-27
 */
@Slf4j
@Service
public class WmsSyncMfgMaterialFromQmsLogServiceImpl extends ServiceImpl<WmsSyncMfgMaterialFromQmsLogMapper,
        WmsSyncMfgMaterialFromQmsLog> implements IWmsSyncMfgMaterialFromQmsLogService {

}
