package com.maxnerva.cloudmes.entity.wo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>
 * 同步aps工单header信息表;從APS同步
 * </p>
 *
 * @author likun
 * @since 2022-08-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value = "WmsWorkOrderAps对象", description = "同步aps工单header信息表")
public class WmsWorkOrderAps extends BaseEntity<WmsWorkOrderAps> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id;")
    private Integer id;

    @ApiModelProperty(value = "工单号，aufnr;工单编号")
    private String workOrderNo;

    @ApiModelProperty(value = "BU（业务单元）")
    private String orgCode;

    @ApiModelProperty(value = "sap工厂，werks;工厂")
    private String plantCode;

    @ApiModelProperty(value = "aps单号")
    private String apsNumber;

    @ApiModelProperty(value = "工单类型，auart;//工单类型")
    private String workOrderType;

    @ApiModelProperty(value = "成品料号，matnr;//料號")
    private String partNo;

    @ApiModelProperty(value = "线别")
    private String lineNo;

    @ApiModelProperty(value = "版本标识，revlv;//版本标识、修订版本")
    private String reversionLevel;

    @ApiModelProperty(value = "计划日期")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate scheduledDate;

    @ApiModelProperty(value = "计划开始时间，gstrs;//计划开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime scheduledStart;

    @ApiModelProperty(value = "计划结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime scheduledEnd;

    @ApiModelProperty(value = "工单数量")
    private BigDecimal workOrderQty;

    @ApiModelProperty(value = "数量;")
    private BigDecimal quantity;

    @ApiModelProperty(value = "连板数;")
    private BigDecimal cardsPerPanel;

    @ApiModelProperty(value = "上次更改时间，aedat;//上次更改时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate lastChangeTime;

    @ApiModelProperty(value = "更改人的姓名，aenam;//更改人的姓名")
    private String nameChange;

    @ApiModelProperty(value = "料号群组，matkl;//物料组别")
    private String materialGroup;

    @ApiModelProperty(value = "料号描述，maktx;//物料描述")
    private String materialDescription;

    @ApiModelProperty(value = "计划结束时间，gltrs;//计划结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate scheduledFinish;

    @ApiModelProperty(value = "存储位置，lgort;//存储位置")
    private String storageLocation;

    @ApiModelProperty(value = "下载detail标识;")
    private Integer downloadDetailFlag;

    @ApiModelProperty(value = "下載detail信息")
    private String downloadDetailMsg;

    @ApiModelProperty(value = "下载detail的时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime downloadDetailDt;
}
