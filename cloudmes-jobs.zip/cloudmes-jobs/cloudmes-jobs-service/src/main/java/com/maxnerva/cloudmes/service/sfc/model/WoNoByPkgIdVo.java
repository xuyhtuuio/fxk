package com.maxnerva.cloudmes.service.sfc.model;

import io.swagger.annotations.ApiModel;
import lombok.Data;

@ApiModel("根据PKGID获取工单号")
@Data
public class WoNoByPkgIdVo {
    private String orgCode;
    private String sn;
}
