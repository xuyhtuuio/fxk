package com.maxnerva.cloudmes.service.mes.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName ProductInstorageVO
 * @Description 成品入库vo
 * @Author Likun
 * @Date 2022/11/16
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("成品入库vo")
@Data
public class ProductInStorageVO {

    @ApiModelProperty("载具编码")
    private String vehicleCode;

    @ApiModelProperty("储位编码")
    private String binCode;

    @ApiModelProperty("SFC Barcode")
    private String barCode;

    @ApiModelProperty("工厂组织")
    private String orgCode;

    @ApiModelProperty("库区编码")
    private String areaCode;

    @ApiModelProperty("工厂编码")
    private String plantCode;
}
