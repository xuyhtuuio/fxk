package com.maxnerva.cloudmes.service.wo;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderVehicleRecord;

/**
 * <p>
 * 工单绑定载具记录表 服务类
 * </p>
 *
 * @author likun
 * @since 2022-09-03
 */
public interface IWmsWorkOrderVehicleRecordService extends IService<WmsWorkOrderVehicleRecord> {

}
