package com.maxnerva.cloudmes.service.mes;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpStatus;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.entity.basic.BasicMaterialMfgEntity;
import com.maxnerva.cloudmes.entity.deliver.WmsDocProductShipDetail;
import com.maxnerva.cloudmes.entity.deliver.WmsDocProductShipHeader;
import com.maxnerva.cloudmes.entity.deliver.WmsShipPkgBindRecord;
import com.maxnerva.cloudmes.entity.doc.ReceiveSnPostToMesDTO;
import com.maxnerva.cloudmes.entity.doc.WmsReceiveSnList;
import com.maxnerva.cloudmes.entity.mes.MsdSyncDTO;
import com.maxnerva.cloudmes.entity.mes.PoSnBindVO;
import com.maxnerva.cloudmes.entity.pkg.WmsPkgSfcInfoEntity;
import com.maxnerva.cloudmes.entity.tencent.DeliverySnBindDTO;
import com.maxnerva.cloudmes.entity.wh.WmsPkgInfo;
import com.maxnerva.cloudmes.entity.wo.WmsPkgBurnInfo;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderHeader;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderPickLog;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderPrepareLog;
import com.maxnerva.cloudmes.mapper.basic.BasicMaterialMfgMapper;
import com.maxnerva.cloudmes.mapper.deliver.WmsProductShipDetailMapper;
import com.maxnerva.cloudmes.mapper.deliver.WmsProductShipHeaderMapper;
import com.maxnerva.cloudmes.mapper.deliver.WmsShipPkgBindRecordMapper;
import com.maxnerva.cloudmes.mapper.doc.WmsReceiveSnListMapper;
import com.maxnerva.cloudmes.mapper.pkg.WmsPkgSfcInfoMapper;
import com.maxnerva.cloudmes.mapper.tencent.WmsTencentDeliverySnBindRecordMapper;
import com.maxnerva.cloudmes.mapper.tencent.WmsTencentOrderDeliveryMapper;
import com.maxnerva.cloudmes.mapper.wh.WmsPkgInfoMapper;
import com.maxnerva.cloudmes.mapper.wo.WmsPkgBurnInfoMapper;
import com.maxnerva.cloudmes.mapper.wo.WmsWorkOrderHeaderMapper;
import com.maxnerva.cloudmes.mapper.wo.WmsWorkOrderPickLogMapper;
import com.maxnerva.cloudmes.mapper.wo.WmsWorkOrderPrepareLogMapper;
import com.maxnerva.cloudmes.service.DataSourceService;
import com.maxnerva.cloudmes.service.mes.model.ComponentImportDTO;
import com.maxnerva.cloudmes.service.mes.model.PkgInfoDTO;
import com.maxnerva.cloudmes.service.sfc.SfcStoredProcedureFactory;
import com.maxnerva.cloudmes.service.sfc.model.WarehousingPassSnStationDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @ClassName PostingMesService
 * @Description TODO
 * @Author Likun
 * @Date 2023/2/22
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Slf4j
@Service
public class PostingMesService {

    @Autowired
    WmsWorkOrderPrepareLogMapper wmsWorkOrderPrepareLogMapper;

    @Autowired
    MesService mesService;

    @Resource
    private WmsPkgSfcInfoMapper wmsPkgSfcInfoMapper;

    @Resource
    private SfcStoredProcedureFactory sfcStoredProcedureFactory;

    @Resource
    private WmsPkgInfoMapper wmsPkgInfoMapper;

    @Resource
    private BasicMaterialMfgMapper basicMaterialMfgMapper;

    @Resource
    private WmsWorkOrderPickLogMapper wmsWorkOrderPickLogMapper;

    @Resource
    private WmsWorkOrderHeaderMapper wmsWorkOrderHeaderMapper;

    @Resource
    private DataSourceService dataSourceService;

    @Resource
    private WmsPkgBurnInfoMapper wmsPkgBurnInfoMapper;

    @Resource
    private WmsReceiveSnListMapper wmsReceiveSnListMapper;

    @Resource
    private WmsShipPkgBindRecordMapper wmsShipPkgBindRecordMapper;

    @Resource
    private WmsProductShipDetailMapper wmsProductShipDetailMapper;

    @Resource
    private WmsProductShipHeaderMapper wmsProductShipHeaderMapper;

    @Resource
    private WmsTencentDeliverySnBindRecordMapper wmsTencentDeliverySnBindRecordMapper;

    @Resource
    private WmsTencentOrderDeliveryMapper wmsTencentOrderDeliveryMapper;

    /**
     * 工单备料PKG信息抛Mes
     *
     * @param orgCode
     */
    public void postingWoPreparePkgInfoToMes(String orgCode, String workOrderNo) {
        //已经上架，没有被锁的，没有抛SFC的pkg list
        List<WmsWorkOrderPrepareLog> pkgInfos =
                wmsWorkOrderPrepareLogMapper.selectList(Wrappers.<WmsWorkOrderPrepareLog>lambdaQuery()
                        .eq(WmsWorkOrderPrepareLog::getOrgCode, orgCode)
                        .gt(WmsWorkOrderPrepareLog::getCurrentQty, BigDecimal.ZERO)
                        .eq(StringUtils.isNotBlank(workOrderNo), WmsWorkOrderPrepareLog::getWorkOrderNo, workOrderNo)
                        .last(" and post_to_mes_flag = 0 and wms_to_sfc_flag = true and( burn_flag = 'N' or (burn_flag = 'Y' and burn_value is not null))"));
        if (CollUtil.isEmpty(pkgInfos)) {
            return;
        }
        pkgInfos.forEach(pkg -> {
            PkgInfoDTO p = new PkgInfoDTO();
            p.setPkgId(pkg.getPkgId());
            p.setSourceType(1);
            p.setComponentNo(pkg.getPartNo());
            p.setOriginalQty(pkg.getOriginalQty());
            p.setCurrentQty(pkg.getCurrentQty());
            p.setMfgName(pkg.getMfgName());
            String supplierPartNo = pkg.getSupplierPartNo();
            p.setMfgPn(StrUtil.isBlank(supplierPartNo) ? pkg.getMfgPartNo() : supplierPartNo);
            p.setLotNo(pkg.getLotNo());
            /*LocalDate dateCode = pkg.getDateCode();
            p.setDateCode(ObjectUtil.isNotNull(dateCode) ?
                    dateCode.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) : StrUtil.EMPTY);*/
            String originalDateCode = pkg.getOriginalDateCode();
            p.setDateCode(originalDateCode);
            p.setPlaceOfOrigin(pkg.getPlaceOfOrigin1());
            p.setOrgCode(orgCode);
            p.setEffectiveDate(pkg.getEffectiveDate());
            LocalDate endDate = pkg.getEndDate();
            p.setEndDate(ObjectUtil.isNotNull(endDate) ?
                    endDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) : StrUtil.EMPTY);
            p.setSapWoNo(pkg.getWorkOrderNo());
            p.setBinCode(pkg.getBinCode());
            p.setVehicleCode(pkg.getVehicleCode());
            p.setBurnValue(pkg.getBurnValue());
            p.setProductNo(pkg.getProductPartNo());
            p.setPlantCode(pkg.getPlantCode());
            p.setFeederNo(pkg.getFeederNo());
            p.setMachineCode(pkg.getMachineCode());
            List<PkgInfoDTO> pkgInfoDTOList = CollUtil.newArrayList();
            pkgInfoDTOList.add(p);
            HttpResponse httpResponse = mesService.postingWoPreparePkgInfoToMes(pkgInfoDTOList);
            String body = httpResponse.body();
            if (StrUtil.isEmpty(body)) {
                WmsWorkOrderPrepareLog updatePkgInfo = new WmsWorkOrderPrepareLog();
                updatePkgInfo.setId(pkg.getId());
                updatePkgInfo.setPostToMesFlag(3);
                updatePkgInfo.setPostToMesDt(LocalDateTime.now());
                updatePkgInfo.setPostToMesReturnMessage("调用mes异常");
                updatePkgInfo.updateById();
                return;
            }
            log.info("to mes content :{} return :{}", JSONUtil.toJsonStr(p), body);
            if (httpResponse.getStatus() == HttpStatus.HTTP_OK) {
                JSONObject mesReturnInfo = JSONUtil.parseObj(body);
                String code = mesReturnInfo.getStr("code");
                String msg = mesReturnInfo.getStr("msg");
                if (StringUtils.isNotBlank(code) && "200".equalsIgnoreCase(code)) {
                    WmsWorkOrderPrepareLog updatePkgInfo = new WmsWorkOrderPrepareLog();
                    updatePkgInfo.setId(pkg.getId());
                   /* //如果有烧录值,则将标识改为4,正常将标识修改为1
                    updatePkgInfo.setPostToMesFlag(StrUtil.isNotEmpty(pkg.getBurnValue()) ? 4 : 1);*/
                    updatePkgInfo.setPostToMesFlag(1);
                    updatePkgInfo.setPostToMesDt(LocalDateTime.now());
                    updatePkgInfo.setPostToMesReturnMessage(msg);
                    updatePkgInfo.updateById();
                } else {
                    WmsWorkOrderPrepareLog updatePkgInfo = new WmsWorkOrderPrepareLog();
                    updatePkgInfo.setId(pkg.getId());
                    updatePkgInfo.setPostToMesFlag(3);
                    updatePkgInfo.setPostToMesDt(LocalDateTime.now());
                    updatePkgInfo.setPostToMesReturnMessage(msg);
                    updatePkgInfo.updateById();
                }
            }
        });
    }

    public void postMesPassSnStation(String orgCode) {
        List<WmsPkgSfcInfoEntity> pkgInfos =
                wmsPkgSfcInfoMapper.selectList(Wrappers.<WmsPkgSfcInfoEntity>lambdaQuery().eq(WmsPkgSfcInfoEntity::getOrgCode, orgCode)
                                .eq(WmsPkgSfcInfoEntity::getPostSfcPassStationFlag, "M")
//                        .eq(WmsPkgSfcInfoEntity::getSnNo,"1A625Q50032110N")
//                        .eq(WmsPkgSfcInfoEntity::getWorkerOrderNo,"000100063714")
                );

        if (CollUtil.isEmpty(pkgInfos)) {
            return;
        }

        pkgInfos.forEach(pkg -> {
            try {
                WarehousingPassSnStationDto p = new WarehousingPassSnStationDto();
                p.setSn(pkg.getSnNo());
                p.setUserName("WMS");
                p.setLine("");
                p.setSection("WMS");
                p.setWStation("INSTORE");
                p.setBadCode("N/A");
                p.setMyGroup("INSTORE");
                //获取sfcSite  根据组织+工厂
//                String sfcSite = SfcSiteService.getSfcSite(orgCode, pkg.getPlantCode());
                WmsWorkOrderHeader wmsWorkOrderHeaderDb = wmsWorkOrderHeaderMapper.selectOne(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                        .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                        .eq(WmsWorkOrderHeader::getWorkOrderNo, pkg.getWorkerOrderNo())
                        .last("limit 1"));
//                String dataSource = dataSourceService.getDataSource(orgCode, wmsWorkOrderHeaderDb.getMrpArea());
                String dataSource = wmsWorkOrderHeaderDb.getMesDataSource();
                String s = sfcStoredProcedureFactory.warehousingPassSnStation(orgCode, p, pkg.getPlantCode(), dataSource);
                log.info("warehousingPassSnStation to SFC content :{} return :{}", JSONUtil.toJsonStr(p), s);

                if (StringUtils.isNotBlank(s) && "OK".equalsIgnoreCase(s)) {
                    WmsPkgSfcInfoEntity updatePkgInfo = new WmsPkgSfcInfoEntity();
                    updatePkgInfo.setId(pkg.getId());
                    updatePkgInfo.setPostSfcPassStationFlag("Y");
                    updatePkgInfo.setPostSfcDatatime(LocalDateTime.now());
                    updatePkgInfo.setPostSfcMessage(s);
                    updatePkgInfo.updateById();
                } else {
                    WmsPkgSfcInfoEntity updatePkgInfo = new WmsPkgSfcInfoEntity();
                    updatePkgInfo.setId(pkg.getId());
                    updatePkgInfo.setPostSfcPassStationFlag("M");
                    updatePkgInfo.setPostSfcDatatime(LocalDateTime.now());
                    updatePkgInfo.setPostSfcMessage(s);
                    updatePkgInfo.updateById();
                }
            } catch (Exception e) {
                log.error("warehousingPassSnStation {}", e.getMessage());
                WmsPkgSfcInfoEntity updatePkgInfo = new WmsPkgSfcInfoEntity();
                updatePkgInfo.setId(pkg.getId());
                updatePkgInfo.setPostSfcPassStationFlag("M");
                updatePkgInfo.setPostSfcDatatime(LocalDateTime.now());
                updatePkgInfo.setPostSfcMessage("SFC interface error");
                updatePkgInfo.updateById();
            }
        });
    }

    public void syncMsdPkgInfo(String orgCode) {
        List<WmsPkgInfo> wmsPkgInfoList = wmsPkgInfoMapper.selectList(Wrappers.<WmsPkgInfo>lambdaQuery()
                .eq(WmsPkgInfo::getOrgCode, orgCode)
                .eq(WmsPkgInfo::getPostMsdFlag, 0));
        wmsPkgInfoList.forEach(p -> {
            try {
                boolean isOk = checkInfo(p);
                if (!isOk) {
                    return;
                }
                MsdSyncDTO msdSyncDTO = new MsdSyncDTO();
                BeanUtils.copyProperties(p, msdSyncDTO);
                msdSyncDTO.setParentPkgId(StringUtils.isEmpty(p.getParentPkgId()) ? "" : p.getParentPkgId());
                msdSyncDTO.setComponentNo(p.getPartNo());
                msdSyncDTO.setMfgPn(p.getSupplierPartNo());
                msdSyncDTO.setDateCode(p.getOriginalDateCode());
                msdSyncDTO.setLotNo(p.getLotCode());
                HttpResponse response = mesService.syncMsd(msdSyncDTO);
                if (response.getStatus() != HttpStatus.HTTP_OK) {
                    wmsPkgInfoMapper.update(null, Wrappers.<WmsPkgInfo>lambdaUpdate()
                            .eq(WmsPkgInfo::getId, p.getId())
                            .set(WmsPkgInfo::getPostMsdMsg, "syncMsdPkgInfo call mes interface error")
                            .set(WmsPkgInfo::getPostMsdDateTime, LocalDateTime.now()));
                    log.error("syncMsdPkgInfo call mes interface error");
                    return;
                }
                String body = response.body();
                log.info("syncMsdPkgInfo request:{},return:{}", JSONUtil.toJsonStr(msdSyncDTO), body);
                if (StrUtil.isEmpty(body)) {
                    wmsPkgInfoMapper.update(null, Wrappers.<WmsPkgInfo>lambdaUpdate()
                            .eq(WmsPkgInfo::getId, p.getId())
                            .set(WmsPkgInfo::getPostMsdMsg, "mes return empty")
                            .set(WmsPkgInfo::getPostMsdDateTime, LocalDateTime.now()));
                    log.error("syncMsdPkgInfo mes return empty");
                    return;
                }
                JSONObject mesReturnInfo = JSONUtil.parseObj(body);
                String code = mesReturnInfo.getStr("code");
                if (StrUtil.isNotBlank(code) && "200".equals(code)) {
                    wmsPkgInfoMapper.update(null, Wrappers.<WmsPkgInfo>lambdaUpdate()
                            .eq(WmsPkgInfo::getId, p.getId())
                            .set(WmsPkgInfo::getPostMsdFlag, 1)
                            .set(WmsPkgInfo::getPostMsdMsg, "OK")
                            .set(WmsPkgInfo::getPostMsdDateTime, LocalDateTime.now()));
                } else {
                    wmsPkgInfoMapper.update(null, Wrappers.<WmsPkgInfo>lambdaUpdate()
                            .eq(WmsPkgInfo::getId, p.getId())
                            .set(WmsPkgInfo::getPostMsdFlag, 2)
                            .set(WmsPkgInfo::getPostMsdMsg, mesReturnInfo.getStr("msg"))
                            .set(WmsPkgInfo::getPostMsdDateTime, LocalDateTime.now()));
                }
            } catch (Exception e) {
                wmsPkgInfoMapper.update(null, Wrappers.<WmsPkgInfo>lambdaUpdate()
                        .eq(WmsPkgInfo::getId, p.getId())
                        .set(WmsPkgInfo::getPostMsdFlag, 3)
                        .set(WmsPkgInfo::getPostMsdMsg, e.getMessage())
                        .set(WmsPkgInfo::getPostMsdDateTime, LocalDateTime.now()));
            }
        });
    }

    private Boolean checkInfo(WmsPkgInfo p) {
        if (p.getCurrentQty().compareTo(BigDecimal.ZERO) == 0) {
            wmsPkgInfoMapper.update(null, Wrappers.<WmsPkgInfo>lambdaUpdate()
                    .eq(WmsPkgInfo::getId, p.getId())
                    .set(WmsPkgInfo::getPostMsdFlag, 3)
                    .set(WmsPkgInfo::getPostMsdMsg, "currentQty is 0")
                    .set(WmsPkgInfo::getPostMsdDateTime, LocalDateTime.now()));
            return Boolean.FALSE;
        }
        if (StrUtil.isEmpty(p.getMfgName()) || StrUtil.isEmpty(p.getSupplierPartNo())) {
            wmsPkgInfoMapper.update(null, Wrappers.<WmsPkgInfo>lambdaUpdate()
                    .eq(WmsPkgInfo::getId, p.getId())
                    .set(WmsPkgInfo::getPostMsdFlag, 3)
                    .set(WmsPkgInfo::getPostMsdMsg, "mfgName or supplierPartNo is null")
                    .set(WmsPkgInfo::getPostMsdDateTime, LocalDateTime.now()));
            return Boolean.FALSE;
        }
        BasicMaterialMfgEntity basicMaterialMfgEntity = basicMaterialMfgMapper.selectMaterialMfg(p.getOrgCode(),
                p.getPlantCode(), p.getPartNo(), p.getMfgName(), p.getSupplierPartNo());
        if (ObjectUtil.isNull(basicMaterialMfgEntity)) {
            wmsPkgInfoMapper.update(null, Wrappers.<WmsPkgInfo>lambdaUpdate()
                    .eq(WmsPkgInfo::getId, p.getId())
                    .set(WmsPkgInfo::getPostMsdFlag, 3)
                    .set(WmsPkgInfo::getPostMsdMsg, "basicMaterialMfg is not found")
                    .set(WmsPkgInfo::getPostMsdDateTime, LocalDateTime.now()));
            return Boolean.FALSE;
        }
        String msdLevel = basicMaterialMfgEntity.getMsdLevel();
        if (StrUtil.isEmpty(msdLevel) || "0".equals(msdLevel)) {
            wmsPkgInfoMapper.update(null, Wrappers.<WmsPkgInfo>lambdaUpdate()
                    .eq(WmsPkgInfo::getId, p.getId())
                    .set(WmsPkgInfo::getPostMsdFlag, 3)
                    .set(WmsPkgInfo::getPostMsdMsg, "partNo is not msd")
                    .set(WmsPkgInfo::getPostMsdDateTime, LocalDateTime.now()));
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    public void syncMsdPickLog(String orgCode) {
        List<WmsWorkOrderPickLog> wmsWorkOrderPickLogList = wmsWorkOrderPickLogMapper
                .selectList(Wrappers.<WmsWorkOrderPickLog>lambdaQuery()
                        .eq(WmsWorkOrderPickLog::getOrgCode, orgCode)
                        .eq(WmsWorkOrderPickLog::getPostMsdFlag, 0));
        wmsWorkOrderPickLogList.forEach(p -> {
            try {
                boolean isOk = checkPickLogSyncMsd(p);
                if (!isOk) {
                    return;
                }
                MsdSyncDTO msdSyncDTO = new MsdSyncDTO();
                BeanUtils.copyProperties(p, msdSyncDTO);
                msdSyncDTO.setParentPkgId(StringUtils.isEmpty(p.getParentPkgId()) ? "" : p.getParentPkgId());
                msdSyncDTO.setComponentNo(p.getPartNo());
                msdSyncDTO.setMfgPn(p.getSupplierPartNo());
                msdSyncDTO.setDateCode(p.getOriginalDateCode());
                msdSyncDTO.setLotNo(p.getLotCode());
                HttpResponse response = mesService.syncMsd(msdSyncDTO);
                if (response.getStatus() != HttpStatus.HTTP_OK) {
                    wmsWorkOrderPickLogMapper.update(null, Wrappers.<WmsWorkOrderPickLog>lambdaUpdate()
                            .eq(WmsWorkOrderPickLog::getId, p.getId())
                            .set(WmsWorkOrderPickLog::getPostMsdMsg, "syncMsdPickLog call mes interface error")
                            .set(WmsWorkOrderPickLog::getPostMsdDateTime, LocalDateTime.now()));
                    log.error("syncMsdPickLog call mes interface error");
                    return;
                }
                String body = response.body();
                log.info("syncMsdPickLog request:{},return:{}", JSONUtil.toJsonStr(msdSyncDTO), body);
                if (StrUtil.isEmpty(body)) {
                    wmsWorkOrderPickLogMapper.update(null, Wrappers.<WmsWorkOrderPickLog>lambdaUpdate()
                            .eq(WmsWorkOrderPickLog::getId, p.getId())
                            .set(WmsWorkOrderPickLog::getPostMsdMsg, "mes return empty")
                            .set(WmsWorkOrderPickLog::getPostMsdDateTime, LocalDateTime.now()));
                    log.error("syncMsdPickLog mes return empty");
                    return;
                }
                JSONObject mesReturnInfo = JSONUtil.parseObj(body);
                String code = mesReturnInfo.getStr("code");
                if (StrUtil.isNotBlank(code) && "200".equals(code)) {
                    wmsWorkOrderPickLogMapper.update(null, Wrappers.<WmsWorkOrderPickLog>lambdaUpdate()
                            .eq(WmsWorkOrderPickLog::getId, p.getId())
                            .set(WmsWorkOrderPickLog::getPostMsdFlag, 1)
                            .set(WmsWorkOrderPickLog::getPostMsdMsg, "OK")
                            .set(WmsWorkOrderPickLog::getPostMsdDateTime, LocalDateTime.now()));
                } else {
                    wmsWorkOrderPickLogMapper.update(null, Wrappers.<WmsWorkOrderPickLog>lambdaUpdate()
                            .eq(WmsWorkOrderPickLog::getId, p.getId())
                            .set(WmsWorkOrderPickLog::getPostMsdFlag, 2)
                            .set(WmsWorkOrderPickLog::getPostMsdMsg, mesReturnInfo.getStr("msg"))
                            .set(WmsWorkOrderPickLog::getPostMsdDateTime, LocalDateTime.now()));
                    log.error("syncMsdPickLog error:{}", mesReturnInfo.getStr("msg"));
                }
            } catch (Exception e) {
                wmsWorkOrderPickLogMapper.update(null, Wrappers.<WmsWorkOrderPickLog>lambdaUpdate()
                        .eq(WmsWorkOrderPickLog::getId, p.getId())
                        .set(WmsWorkOrderPickLog::getPostMsdFlag, 3)
                        .set(WmsWorkOrderPickLog::getPostMsdMsg, e.getMessage())
                        .set(WmsWorkOrderPickLog::getPostMsdDateTime, LocalDateTime.now()));
            }
        });
    }

    private Boolean checkPickLogSyncMsd(WmsWorkOrderPickLog p) {
        if (p.getCurrentQty().compareTo(BigDecimal.ZERO) == 0) {
            wmsWorkOrderPickLogMapper.update(null, Wrappers.<WmsWorkOrderPickLog>lambdaUpdate()
                    .eq(WmsWorkOrderPickLog::getId, p.getId())
                    .set(WmsWorkOrderPickLog::getPostMsdFlag, 3)
                    .set(WmsWorkOrderPickLog::getPostMsdMsg, "currentQty is 0")
                    .set(WmsWorkOrderPickLog::getPostMsdDateTime, LocalDateTime.now()));
            return Boolean.FALSE;
        }
        if (StrUtil.isEmpty(p.getMfgName()) || StrUtil.isEmpty(p.getSupplierPartNo())) {
            wmsWorkOrderPickLogMapper.update(null, Wrappers.<WmsWorkOrderPickLog>lambdaUpdate()
                    .eq(WmsWorkOrderPickLog::getId, p.getId())
                    .set(WmsWorkOrderPickLog::getPostMsdFlag, 3)
                    .set(WmsWorkOrderPickLog::getPostMsdMsg, "mfgName or supplierPartNo is null")
                    .set(WmsWorkOrderPickLog::getPostMsdDateTime, LocalDateTime.now()));
            return Boolean.FALSE;
        }
        BasicMaterialMfgEntity basicMaterialMfgEntity = basicMaterialMfgMapper.selectMaterialMfg(p.getOrgCode(),
                p.getPlantCode(), p.getPartNo(), p.getMfgName(), p.getSupplierPartNo());
        if (ObjectUtil.isNull(basicMaterialMfgEntity)) {
            wmsWorkOrderPickLogMapper.update(null, Wrappers.<WmsWorkOrderPickLog>lambdaUpdate()
                    .eq(WmsWorkOrderPickLog::getId, p.getId())
                    .set(WmsWorkOrderPickLog::getPostMsdFlag, 3)
                    .set(WmsWorkOrderPickLog::getPostMsdMsg, "basicMaterialMfg is not found")
                    .set(WmsWorkOrderPickLog::getPostMsdDateTime, LocalDateTime.now()));
            return Boolean.FALSE;
        }
        String msdLevel = basicMaterialMfgEntity.getMsdLevel();
        if (StrUtil.isEmpty(msdLevel) || "0".equals(msdLevel)) {
            wmsWorkOrderPickLogMapper.update(null, Wrappers.<WmsWorkOrderPickLog>lambdaUpdate()
                    .eq(WmsWorkOrderPickLog::getId, p.getId())
                    .set(WmsWorkOrderPickLog::getPostMsdFlag, 3)
                    .set(WmsWorkOrderPickLog::getPostMsdMsg, "partNo is not msd")
                    .set(WmsWorkOrderPickLog::getPostMsdDateTime, LocalDateTime.now()));
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    public void syncMsdPrepareLog(String orgCode) {
        /*List<WmsWorkOrderPrepareLog> workOrderPrepareLogList = wmsWorkOrderPrepareLogMapper
                .selectList(Wrappers.<WmsWorkOrderPrepareLog>lambdaQuery()
                        .eq(WmsWorkOrderPrepareLog::getOrgCode, orgCode)
                        .eq(WmsWorkOrderPrepareLog::getPostMsdFlag, 0));
        workOrderPrepareLogList.forEach(p -> {
            try {
                boolean isOk = checkPrepareLogSyncMsd(p);
                if (!isOk) {
                    return;
                }
                MsdSyncDTO msdSyncDTO = new MsdSyncDTO();
                BeanUtils.copyProperties(p, msdSyncDTO);
                msdSyncDTO.setParentPkgId(StringUtils.isEmpty(p.getParentPkgId()) ? "" : p.getParentPkgId());
                msdSyncDTO.setComponentNo(p.getPartNo());
                msdSyncDTO.setMfgPn(p.getSupplierPartNo());
                msdSyncDTO.setDateCode(p.getOriginalDateCode());
                HttpResponse response = mesService.syncMsd(msdSyncDTO);
                if (response.getStatus() != HttpStatus.HTTP_OK) {
                    wmsWorkOrderPrepareLogMapper.update(null, Wrappers.<WmsWorkOrderPrepareLog>lambdaUpdate()
                            .eq(WmsWorkOrderPrepareLog::getId, p.getId())
                            .set(WmsWorkOrderPrepareLog::getPostMsdMsg, "syncMsdPrepareLog call mes interface error")
                            .set(WmsWorkOrderPrepareLog::getPostMsdDateTime, LocalDateTime.now()));
                    log.error("syncMsdPrepareLog call mes interface error");
                    return;
                }
                String body = response.body();
                log.info("syncMsdPrepareLog request:{},return:{}", JSONUtil.toJsonStr(msdSyncDTO), body);
                if (StrUtil.isEmpty(body)) {
                    wmsWorkOrderPrepareLogMapper.update(null, Wrappers.<WmsWorkOrderPrepareLog>lambdaUpdate()
                            .eq(WmsWorkOrderPrepareLog::getId, p.getId())
                            .set(WmsWorkOrderPrepareLog::getPostMsdMsg, "mes return empty")
                            .set(WmsWorkOrderPrepareLog::getPostMsdDateTime, LocalDateTime.now()));
                    log.error("syncMsdPrepareLog mes return empty");
                    return;
                }
                JSONObject mesReturnInfo = JSONUtil.parseObj(body);
                String code = mesReturnInfo.getStr("code");
                if (StrUtil.isNotBlank(code) && "200".equals(code)) {
                    wmsWorkOrderPrepareLogMapper.update(null, Wrappers.<WmsWorkOrderPrepareLog>lambdaUpdate()
                            .eq(WmsWorkOrderPrepareLog::getId, p.getId())
                            .set(WmsWorkOrderPrepareLog::getPostMsdFlag, 1)
                            .set(WmsWorkOrderPrepareLog::getPostMsdMsg, "OK")
                            .set(WmsWorkOrderPrepareLog::getPostMsdDateTime, LocalDateTime.now()));
                } else {
                    wmsWorkOrderPrepareLogMapper.update(null, Wrappers.<WmsWorkOrderPrepareLog>lambdaUpdate()
                            .eq(WmsWorkOrderPrepareLog::getId, p.getId())
                            .set(WmsWorkOrderPrepareLog::getPostMsdFlag, 2)
                            .set(WmsWorkOrderPrepareLog::getPostMsdMsg, mesReturnInfo.getStr("msg"))
                            .set(WmsWorkOrderPrepareLog::getPostMsdDateTime, LocalDateTime.now()));
                    log.error("syncMsdPrepareLog error:{}", mesReturnInfo.getStr("msg"));
                }
            } catch (Exception e) {
                wmsWorkOrderPrepareLogMapper.update(null, Wrappers.<WmsWorkOrderPrepareLog>lambdaUpdate()
                        .eq(WmsWorkOrderPrepareLog::getId, p.getId())
                        .set(WmsWorkOrderPrepareLog::getPostMsdFlag, 3)
                        .set(WmsWorkOrderPrepareLog::getPostMsdMsg, e.getMessage())
                        .set(WmsWorkOrderPrepareLog::getPostMsdDateTime, LocalDateTime.now()));
            }
        });*/
    }

    private Boolean checkPrepareLogSyncMsd(WmsWorkOrderPrepareLog p) {
        if (p.getCurrentQty().compareTo(BigDecimal.ZERO) == 0) {
            wmsWorkOrderPrepareLogMapper.update(null, Wrappers.<WmsWorkOrderPrepareLog>lambdaUpdate()
                    .eq(WmsWorkOrderPrepareLog::getId, p.getId())
                    .set(WmsWorkOrderPrepareLog::getPostMsdFlag, 3)
                    .set(WmsWorkOrderPrepareLog::getPostMsdMsg, "currentQty is 0")
                    .set(WmsWorkOrderPrepareLog::getPostMsdDateTime, LocalDateTime.now()));
            return Boolean.FALSE;
        }
        if (StrUtil.isEmpty(p.getMfgName()) || StrUtil.isEmpty(p.getSupplierPartNo())) {
            wmsWorkOrderPrepareLogMapper.update(null, Wrappers.<WmsWorkOrderPrepareLog>lambdaUpdate()
                    .eq(WmsWorkOrderPrepareLog::getId, p.getId())
                    .set(WmsWorkOrderPrepareLog::getPostMsdFlag, 3)
                    .set(WmsWorkOrderPrepareLog::getPostMsdMsg, "mfgName or supplierPartNo is null")
                    .set(WmsWorkOrderPrepareLog::getPostMsdDateTime, LocalDateTime.now()));
            return Boolean.FALSE;
        }
        BasicMaterialMfgEntity basicMaterialMfgEntity = basicMaterialMfgMapper.selectMaterialMfg(p.getOrgCode(),
                p.getPlantCode(), p.getPartNo(), p.getMfgName(), p.getSupplierPartNo());
        if (ObjectUtil.isNull(basicMaterialMfgEntity)) {
            wmsWorkOrderPrepareLogMapper.update(null, Wrappers.<WmsWorkOrderPrepareLog>lambdaUpdate()
                    .eq(WmsWorkOrderPrepareLog::getId, p.getId())
                    .set(WmsWorkOrderPrepareLog::getPostMsdFlag, 3)
                    .set(WmsWorkOrderPrepareLog::getPostMsdMsg, "basicMaterialMfg is not found")
                    .set(WmsWorkOrderPrepareLog::getPostMsdDateTime, LocalDateTime.now()));
            return Boolean.FALSE;
        }
        String msdLevel = basicMaterialMfgEntity.getMsdLevel();
        if (StrUtil.isEmpty(msdLevel) || "0".equals(msdLevel)) {
            wmsWorkOrderPrepareLogMapper.update(null, Wrappers.<WmsWorkOrderPrepareLog>lambdaUpdate()
                    .eq(WmsWorkOrderPrepareLog::getId, p.getId())
                    .set(WmsWorkOrderPrepareLog::getPostMsdFlag, 3)
                    .set(WmsWorkOrderPrepareLog::getPostMsdMsg, "partNo is not msd")
                    .set(WmsWorkOrderPrepareLog::getPostMsdDateTime, LocalDateTime.now()));
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    public void postingPkgInfoToMes(String orgCode, String pkgId) {
        log.info("postPkgInfoToMes invoke param orgCode:{},pkgId:{}", orgCode, pkgId);
        WmsPkgInfo pkg = wmsPkgInfoMapper.selectOne(Wrappers.<WmsPkgInfo>lambdaQuery()
                .eq(WmsPkgInfo::getOrgCode, orgCode)
                .eq(WmsPkgInfo::getPkgId, pkgId)
                .last("limit 1"));
        if (ObjectUtil.isNotNull(pkg)) {
            PkgInfoDTO p = new PkgInfoDTO();
            p.setPkgId(pkg.getPkgId());
            p.setSourceType(1);
            p.setComponentNo(pkg.getPartNo());
            p.setOriginalQty(pkg.getOriginalQty());
            p.setCurrentQty(pkg.getCurrentQty());
            p.setMfgName(pkg.getMfgName());
            String supplierPartNo = pkg.getSupplierPartNo();
            p.setMfgPn(StrUtil.isBlank(supplierPartNo) ? pkg.getMfgPartNo() : supplierPartNo);
            p.setLotNo(pkg.getLotCode());
            String originalDateCode = pkg.getOriginalDateCode();
            p.setDateCode(originalDateCode);
            p.setPlaceOfOrigin(pkg.getPlaceOfOrigin1());
            p.setOrgCode(orgCode);
            p.setEffectiveDate(pkg.getEffectiveDate());
            LocalDate endDate = pkg.getEndDate();
            p.setEndDate(ObjectUtil.isNotNull(endDate) ?
                    endDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) : StrUtil.EMPTY);
            p.setBinCode(pkg.getBinCode());
            p.setVehicleCode(pkg.getVehicleCode());
            p.setPlantCode(pkg.getPlantCode());
            List<PkgInfoDTO> pkgInfoDTOList = CollUtil.newArrayList();
            pkgInfoDTOList.add(p);
            log.info("postPkgInfoToMes request:{}", JSONUtil.toJsonStr(pkgInfoDTOList));
            HttpResponse httpResponse = mesService.postingWoPreparePkgInfoToMes(pkgInfoDTOList);
            String body = httpResponse.body();
            log.info("postPkgInfoToMes return :{}", body);
        }
    }

    public void postingPreparePkgInfoToMes(String orgCode, String pkgId) {
        WmsWorkOrderPrepareLog pkg = wmsWorkOrderPrepareLogMapper
                .selectOne(Wrappers.<WmsWorkOrderPrepareLog>lambdaQuery()
                        .eq(WmsWorkOrderPrepareLog::getOrgCode, orgCode)
                        .eq(WmsWorkOrderPrepareLog::getPkgId, pkgId)
                        .orderByDesc(WmsWorkOrderPrepareLog::getId)
                        .last("limit 1"));
        if (pkg.getCurrentQty().compareTo(BigDecimal.ZERO) <= 0) {
            log.error("postingPreparePkgInfoToMes Error,Pkg:{} currentQty<=0", pkgId);
            return;
        }
        if (pkg.getPostToMesFlag() != 0) {
            log.error("postingPreparePkgInfoToMes Error,Pkg:{} postToMesFlag==1", pkgId);
            return;
        }
        if (!(Boolean.TRUE.equals(pkg.getWmsToSfcFlag()) && ("N".equals(pkg.getBurnFlag()) ||
                ("Y".equals(pkg.getBurnFlag()) && StrUtil.isNotEmpty(pkg.getBurnValue()))))) {
            log.error("postingPreparePkgInfoToMes Error,Pkg:{} ,BurnFlag:{},BurnValue:{},wmsToSfcFlag:{}", pkgId,
                    pkg.getBurnFlag(), pkg.getBurnValue(), pkg.getWmsToSfcFlag());
            return;
        }
        PkgInfoDTO p = new PkgInfoDTO();
        p.setPkgId(pkg.getPkgId());
        p.setSourceType(1);
        p.setComponentNo(pkg.getPartNo());
        p.setOriginalQty(pkg.getOriginalQty());
        p.setCurrentQty(pkg.getCurrentQty());
        p.setMfgName(pkg.getMfgName());
        String supplierPartNo = pkg.getSupplierPartNo();
        p.setMfgPn(StrUtil.isBlank(supplierPartNo) ? pkg.getMfgPartNo() : supplierPartNo);
        p.setLotNo(pkg.getLotNo());
        String originalDateCode = pkg.getOriginalDateCode();
        p.setDateCode(originalDateCode);
        p.setPlaceOfOrigin(pkg.getPlaceOfOrigin1());
        p.setOrgCode(orgCode);
        p.setEffectiveDate(pkg.getEffectiveDate());
        LocalDate endDate = pkg.getEndDate();
        p.setEndDate(ObjectUtil.isNotNull(endDate) ?
                endDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) : StrUtil.EMPTY);
        p.setSapWoNo(pkg.getWorkOrderNo());
        p.setBinCode(pkg.getBinCode());
        p.setVehicleCode(pkg.getVehicleCode());
        p.setBurnValue(pkg.getBurnValue());
        p.setProductNo(pkg.getProductPartNo());
        p.setPlantCode(pkg.getPlantCode());
        p.setFeederNo(pkg.getFeederNo());
        p.setMachineCode(pkg.getMachineCode());
        //用org_code+pkg去wms_burn_pkg_info找信息,如果找到了就塞入burnDatetime
        WmsPkgBurnInfo wmsPkgBurnInfoDb = wmsPkgBurnInfoMapper.selectOne(Wrappers.<WmsPkgBurnInfo>lambdaQuery()
                .eq(WmsPkgBurnInfo::getOrgCode, orgCode)
                .eq(WmsPkgBurnInfo::getPkgId, pkgId)
                .orderByDesc(WmsPkgBurnInfo::getId)
                .last("limit 1"));
        if (ObjectUtil.isNotNull(wmsPkgBurnInfoDb)) {
            p.setBurnDatetime(ObjectUtil.isNotNull(wmsPkgBurnInfoDb.getBurnDatetime()) ?
                    wmsPkgBurnInfoDb.getBurnDatetime()
                            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) : StrUtil.EMPTY);
        }
        List<PkgInfoDTO> pkgInfoDTOList = CollUtil.newArrayList();
        pkgInfoDTOList.add(p);
        HttpResponse httpResponse = mesService.postingWoPreparePkgInfoToMes(pkgInfoDTOList);
        String body = httpResponse.body();
        if (StrUtil.isEmpty(body)) {
            wmsWorkOrderPrepareLogMapper.update(null, Wrappers.<WmsWorkOrderPrepareLog>lambdaUpdate()
                    .eq(WmsWorkOrderPrepareLog::getId, pkg.getId())
                    .set(WmsWorkOrderPrepareLog::getPostToMesFlag, 3)
                    .set(WmsWorkOrderPrepareLog::getPostToMesDt, LocalDateTime.now())
                    .set(WmsWorkOrderPrepareLog::getPostToMesReturnMessage, "调用mes异常"));
            return;
        }
        log.info("postingPreparePkgInfoToMes content :{} return :{}", JSONUtil.toJsonStr(p), body);
        if (httpResponse.getStatus() == HttpStatus.HTTP_OK) {
            JSONObject mesReturnInfo = JSONUtil.parseObj(body);
            String code = mesReturnInfo.getStr("code");
            String msg = mesReturnInfo.getStr("msg");
            if (StringUtils.isNotBlank(code) && "200".equalsIgnoreCase(code)) {
                wmsWorkOrderPrepareLogMapper.update(null, Wrappers.<WmsWorkOrderPrepareLog>lambdaUpdate()
                        .eq(WmsWorkOrderPrepareLog::getId, pkg.getId())
                        .set(WmsWorkOrderPrepareLog::getPostToMesFlag, 1)
                        .set(WmsWorkOrderPrepareLog::getPostToMesDt, LocalDateTime.now())
                        .set(WmsWorkOrderPrepareLog::getPostToMesReturnMessage, msg));
            } else {
                wmsWorkOrderPrepareLogMapper.update(null, Wrappers.<WmsWorkOrderPrepareLog>lambdaUpdate()
                        .eq(WmsWorkOrderPrepareLog::getId, pkg.getId())
                        .set(WmsWorkOrderPrepareLog::getPostToMesFlag, 3)
                        .set(WmsWorkOrderPrepareLog::getPostToMesDt, LocalDateTime.now())
                        .set(WmsWorkOrderPrepareLog::getPostToMesReturnMessage, msg));
            }
        }
    }

    public void postingReceiveSnToMes(String orgCode) {
        List<ReceiveSnPostToMesDTO> receiveSnPostToMesDTOList = wmsReceiveSnListMapper
                .selectReceiveSnPostToMesInfo(orgCode);
        if (CollUtil.isNotEmpty(receiveSnPostToMesDTOList)) {
            receiveSnPostToMesDTOList = receiveSnPostToMesDTOList.stream().filter(receiveSnPostToMesDTO ->
                    StrUtil.isNotEmpty(receiveSnPostToMesDTO.getPartNo())).collect(Collectors.toList());
            List<ComponentImportDTO> componentImportDTOList = CollUtil.newArrayList();
            for (ReceiveSnPostToMesDTO receiveSnPostToMesDTO : receiveSnPostToMesDTOList) {
                ComponentImportDTO componentImportDTO = new ComponentImportDTO();
                componentImportDTO.setComponentSn(receiveSnPostToMesDTO.getSnNo());
                componentImportDTO.setComponentNo(receiveSnPostToMesDTO.getPartNo());
                componentImportDTO.setMfgName(receiveSnPostToMesDTO.getMfgName());
                componentImportDTO.setMfgPn(receiveSnPostToMesDTO.getMfgPartNo());
                componentImportDTO.setOriginCountry(receiveSnPostToMesDTO.getPlaceOfOrigin1());
                componentImportDTO.setOrgCode(receiveSnPostToMesDTO.getOrgCode());
                componentImportDTOList.add(componentImportDTO);
            }
            if (CollUtil.isNotEmpty(componentImportDTOList)) {
                List<Integer> idList = receiveSnPostToMesDTOList.stream().map(ReceiveSnPostToMesDTO::getId)
                        .collect(Collectors.toList());
                HttpResponse httpResponse = mesService.postingReceiveSnToMes(componentImportDTOList);
                log.info("postingReceiveSnToMes requestJson:{} response: {}",
                        JSONUtil.toJsonStr(componentImportDTOList), httpResponse.body());
                String body = httpResponse.body();
                if (StrUtil.isNotEmpty(body) && httpResponse.getStatus() == 200) {
                    com.alibaba.fastjson.JSONObject dataHubReturnInfo = JSON.parseObject(body);
                    int code = dataHubReturnInfo.getInteger("code");
                    if (code == 200) {
                        wmsReceiveSnListMapper.update(null, Wrappers.<WmsReceiveSnList>lambdaUpdate()
                                .in(WmsReceiveSnList::getId, idList)
                                .set(WmsReceiveSnList::getPostMesFlag, "Y")
                                .set(WmsReceiveSnList::getPostMesDt, LocalDateTime.now()));
                    } else {
                        wmsReceiveSnListMapper.update(null, Wrappers.<WmsReceiveSnList>lambdaUpdate()
                                .in(WmsReceiveSnList::getId, idList)
                                .set(WmsReceiveSnList::getPostMesFlag, "N")
                                .set(WmsReceiveSnList::getPostMesDt, LocalDateTime.now()));
                    }
                } else {
                    wmsReceiveSnListMapper.update(null, Wrappers.<WmsReceiveSnList>lambdaUpdate()
                            .in(WmsReceiveSnList::getId, idList)
                            .set(WmsReceiveSnList::getPostMesFlag, "N")
                            .set(WmsReceiveSnList::getPostMesDt, LocalDateTime.now()));
                }
            }
        }
    }

    public void postPoSnDataToMes(String orgCode) {
        List<WmsShipPkgBindRecord> wmsShipPkgBindRecordList = wmsShipPkgBindRecordMapper
                .selectList(Wrappers.<WmsShipPkgBindRecord>lambdaQuery()
                        .eq(WmsShipPkgBindRecord::getOrgCode, orgCode)
                        .eq(WmsShipPkgBindRecord::getPostPoSnFlag, "0"));
        for (WmsShipPkgBindRecord wmsShipPkgBindRecord : wmsShipPkgBindRecordList) {
            try {
                Integer shipDetailId = wmsShipPkgBindRecord.getShipDetailId();
                WmsDocProductShipDetail wmsDocProductShipDetail = wmsProductShipDetailMapper
                        .selectById(shipDetailId);
                Integer headerId = wmsDocProductShipDetail.getHeaderId();
                WmsDocProductShipHeader wmsDocProductShipHeader = wmsProductShipHeaderMapper.selectById(headerId);
                List<DeliverySnBindDTO> deliverySnBindDTOList = wmsTencentDeliverySnBindRecordMapper
                        .selectDeliverySnBindRecordList(orgCode, shipDetailId);
                List<PoSnBindVO> poSnBindVOList = CollUtil.newArrayList();
                for (DeliverySnBindDTO deliverySnBindDTO : deliverySnBindDTOList) {
                    PoSnBindVO poSnBindVO = new PoSnBindVO();
                    BeanUtils.copyProperties(deliverySnBindDTO, poSnBindVO);
                    poSnBindVO.setPlantCode(wmsDocProductShipHeader.getSapPlantCode());
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    String formattedDate = sdf.format(new Date(wmsShipPkgBindRecord.getCreatedDt()));
                    poSnBindVO.setVendorOutStorageTime(formattedDate);
                    poSnBindVO.setStatus("配送中");
                    poSnBindVOList.add(poSnBindVO);
                }
                if (CollUtil.isNotEmpty(poSnBindVOList)) {
                    HttpResponse httpResponse = mesService.postPoSnDataToMes(poSnBindVOList);
                    log.info("postPoSnDataToMes requestJson:{} response: {}",
                            JSONUtil.toJsonStr(poSnBindVOList), httpResponse.body());
                    String body = httpResponse.body();
                    if (StrUtil.isNotEmpty(body) && httpResponse.getStatus() == 200) {
                        com.alibaba.fastjson.JSONObject dataHubReturnInfo = JSON.parseObject(body);
                        int code = dataHubReturnInfo.getInteger("code");
                        if (code == 200) {
                            wmsShipPkgBindRecordMapper.update(null,
                                    Wrappers.<WmsShipPkgBindRecord>lambdaUpdate()
                                            .eq(WmsShipPkgBindRecord::getId, wmsShipPkgBindRecord.getId())
                                            .set(WmsShipPkgBindRecord::getPostPoSnFlag, "1")
                                            .set(WmsShipPkgBindRecord::getPostPoSnDate, LocalDateTime.now()));
                        } else {
                            wmsShipPkgBindRecordMapper.update(null,
                                    Wrappers.<WmsShipPkgBindRecord>lambdaUpdate()
                                            .eq(WmsShipPkgBindRecord::getId, wmsShipPkgBindRecord.getId())
                                            .set(WmsShipPkgBindRecord::getPostPoSnFlag, "0")
                                            .set(WmsShipPkgBindRecord::getPostPoSnMessage, dataHubReturnInfo.getString("message"))
                                            .set(WmsShipPkgBindRecord::getPostPoSnDate, LocalDateTime.now()));
                        }
                    } else {
                        wmsShipPkgBindRecordMapper.update(null,
                                Wrappers.<WmsShipPkgBindRecord>lambdaUpdate()
                                        .eq(WmsShipPkgBindRecord::getId, wmsShipPkgBindRecord.getId())
                                        .set(WmsShipPkgBindRecord::getPostPoSnFlag, "0")
                                        .set(WmsShipPkgBindRecord::getPostPoSnMessage, "invoke MES interface receivePoSnData error")
                                        .set(WmsShipPkgBindRecord::getPostPoSnDate, LocalDateTime.now()));
                    }
                }
            } catch (Exception e) {
                log.error("postPoSnDataToMes {}", e.getMessage());
                wmsShipPkgBindRecordMapper.update(null,
                        Wrappers.<WmsShipPkgBindRecord>lambdaUpdate()
                                .eq(WmsShipPkgBindRecord::getId, wmsShipPkgBindRecord.getId())
                                .set(WmsShipPkgBindRecord::getPostPoSnFlag, "0")
                                .set(WmsShipPkgBindRecord::getPostPoSnMessage, "invoke MES interface receivePoSnData error")
                                .set(WmsShipPkgBindRecord::getPostPoSnDate, LocalDateTime.now()));
            }
        }
    }
}
