package com.maxnerva.cloudmes.service.jusda.model;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2023/04/21 18:19
 * @Version: 1.0
 */
@Data
public class CreateAsnItemDetailListDto implements Serializable {
    private static final long serialVersionUID = 1L;
    private String poNo;
    private Integer poLine;
    private String partNo;
    private Integer shippingQty;
    private String uomCode;
    private BigDecimal unitPrice;
    private String currency;
    private BigDecimal grossWeight;
    private Integer netWeight;
    private Integer pallet;
    private Integer carton;
    private Integer looseCarton;
    private String invoiceNo;
    private String originPlaceCode;
    private String buyer;
    private String vendorPartNo;
    private String manufacturer;
    private String purchasingType;
    private AsnExtensionalDataDto extensionalData;
}
