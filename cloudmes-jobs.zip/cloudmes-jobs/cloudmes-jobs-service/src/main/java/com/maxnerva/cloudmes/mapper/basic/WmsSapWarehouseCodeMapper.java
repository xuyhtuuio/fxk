package com.maxnerva.cloudmes.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.basic.WmsSapWarehouseCode;

public interface WmsSapWarehouseCodeMapper extends BaseMapper<WmsSapWarehouseCode> {
}
