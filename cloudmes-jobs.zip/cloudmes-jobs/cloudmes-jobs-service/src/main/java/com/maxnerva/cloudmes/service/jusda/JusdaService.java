package com.maxnerva.cloudmes.service.jusda;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpStatus;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.common.response.Result;
import com.maxnerva.cloudmes.config.Constants;
import com.maxnerva.cloudmes.entity.WmsSapPlant;
import com.maxnerva.cloudmes.entity.basic.BasicMaterialMfgEntity;
import com.maxnerva.cloudmes.entity.doc.WmsAsnUpload;
import com.maxnerva.cloudmes.entity.jusda.WmsJusdaBuContrastEntity;
import com.maxnerva.cloudmes.entity.jusda.WmsJusdaReceiptEntity;
import com.maxnerva.cloudmes.mapper.WmsSapPlantMapper;
import com.maxnerva.cloudmes.mapper.basic.BasicMaterialMfgMapper;
import com.maxnerva.cloudmes.mapper.doc.WmsAsnUploadMapper;
import com.maxnerva.cloudmes.mapper.jusda.WmsJusdaBuContrastMapper;
import com.maxnerva.cloudmes.mapper.jusda.WmsJusdaReceiptMapper;
import com.maxnerva.cloudmes.mapper.wo.WmsWorkOrderHeaderMapper;
import com.maxnerva.cloudmes.service.jusda.model.*;
import com.maxnerva.cloudmes.service.sap.gr.GrRfcService;
import com.maxnerva.cloudmes.service.sap.gr.model.GenerateVmiGrDto;
import com.maxnerva.cloudmes.service.sap.material.MaterialRfcService;
import com.maxnerva.cloudmes.service.sap.po.model.PoItemInfoDto;
import com.maxnerva.cloudmes.service.sap.wh.WhRfcService;
import com.maxnerva.cloudmes.service.sap.wh.model.TransferDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/11/09 10:32
 * @Version: 1.0
 */
@Service
@Slf4j
public class JusdaService {

    @Autowired
    JusdaWebService jusdaWebService;


    @Autowired
    WmsJusdaReceiptMapper wmsJusdaReceiptMapper;

    @Autowired
    WmsJusdaBuContrastMapper wmsJusdaBuContrastMapper;

    @Autowired
    GrRfcService grRfcService;

    @Autowired
    WhRfcService whRfcService;

    @Autowired
    WmsWorkOrderHeaderMapper wmsWorkOrderHeaderMapper;

    @Autowired
    MaterialRfcService materialRfcService;

    @Autowired
    WmsAsnUploadMapper wmsAsnUploadMapper;

    @Autowired
    BasicMaterialMfgMapper basicMaterialMfgMapper;

    @Autowired
    WmsSapPlantMapper wmsSapPlantMapper;

    /**
     * shippingID 数量 =  收货数量 回传JUSDA
     */
    public void postingJusdaReceiveCompleted(String orgCode) {
        LocalDateTime time = LocalDateTime.now().plusDays(-10);
        List<WmsJusdaReceiptEntity> docList =
                wmsJusdaReceiptMapper.selectList(Wrappers.<WmsJusdaReceiptEntity>lambdaQuery()
                        .eq(WmsJusdaReceiptEntity::getOrgCode, orgCode)
                        .eq(WmsJusdaReceiptEntity::getPostJusdaRecevieCompletedFlag, false)
                        .isNotNull(WmsJusdaReceiptEntity::getReceiveCompletedDate)
                        .ge(WmsJusdaReceiptEntity::getReceiveCompletedDate, time)
                        .apply("shiped_qty = received_qty"));

        if (CollUtil.isEmpty(docList)) {
            return;
        }

        docList.forEach(d -> {
            ReturnJusdaReceiveCompletedDto dto = new ReturnJusdaReceiveCompletedDto();
            dto.setShipID(d.getShipId());
            dto.setSiteName(d.getSiteName());
            dto.setSubmissionTime(d.getReceiveCompletedDate().toString());
            dto.setSignee(d.getCreator());

            HttpResponse httpResponse = jusdaWebService.doPostingJusdaReceiveCompleted(dto);

            if (httpResponse.getStatus() == HttpStatus.HTTP_OK) {
                String body = httpResponse.body();
                JSONObject returnInfo = JSONUtil.parseObj(body);
                String code = returnInfo.getStr("code");
                if (StringUtils.isNotBlank(code) && "200".equalsIgnoreCase(code)) {
                    WmsJusdaReceiptEntity update = new WmsJusdaReceiptEntity();
                    update.setId(d.getId());
                    update.setPostJusdaRecevieCompletedFlag(true);
                    update.setPostJusdaRecevieCompletedDate(LocalDateTime.now());
                    update.setPostJusdaRecevieCompletedMsg("OK");
                    update.updateById();
                } else {
                    WmsJusdaReceiptEntity update = new WmsJusdaReceiptEntity();
                    update.setId(d.getId());
                    update.setPostJusdaRecevieCompletedFlag(false);
                    update.setPostJusdaRecevieCompletedDate(LocalDateTime.now());
                    update.setPostJusdaRecevieCompletedMsg(code + " / " + returnInfo.getStr("Message"));
                    update.updateById();
                }
            }

        });

    }


    /**
     * 准时达收货资料回复准时达,  只回VMI资料
     * BU回饋收貨信息接口
     */
    public void postingJusdaReceipt(String orgCode) {

        List<WmsJusdaReceiptEntity> docList =
                wmsJusdaReceiptMapper.selectList(Wrappers.<WmsJusdaReceiptEntity>lambdaQuery()
                        .eq(WmsJusdaReceiptEntity::getOrgCode, orgCode)
                        .isNotNull(WmsJusdaReceiptEntity::getSapReturnNumber)
                        .eq(WmsJusdaReceiptEntity::getPostJusdaFlag, false)
                        .eq(WmsJusdaReceiptEntity::getCustomerReceiveType, "VMI")
                        .apply("shiped_qty = received_qty"));

        if (CollUtil.isEmpty(docList)) {
            return;
        }

        docList.forEach(d -> {
            List<ReturnJusdaShippingInfoDto> shippingInfoDtos = new ArrayList<>();

            ReturnJusdaShippingInfoDto dto = new ReturnJusdaShippingInfoDto();

            dto.setShipID(d.getShipId());
            dto.setSiteName(d.getSiteName());
            //记录的序列号，不是必填项，目前很少使用，可以忽略
            dto.setDeliveryNo(d.getSapReturnNumber());
            dto.setCustomerPartNo(d.getCustomerPartNo());
            dto.setOrderQty(d.getShipedQty().toString());
            dto.setUOM(d.getUom());
            dto.setShipDT(LocalDateTime.now().toString());
            dto.setCustomerName(d.getCustomerName());
            dto.setCustomerSupplierNo(d.getCustomerSupplierNo());
            dto.setCustomerPo(d.getVmiPoItem());
            dto.setCustomerPOItem(d.getVmiPoItem());
            dto.setCustomerGRNNo(d.getSapReturnNumber());
            dto.setManufacture(d.getManufacture());
            dto.setDocumentID(d.getDocumentId());
            //dto.setCancelGRN("");
            dto.setUnitPrice(d.getUnitPrice());
            dto.setEndCustomerPo(d.getVmiPoItem());

            HttpResponse httpResponse = jusdaWebService.doPostingJusdaVmiShippingInfo(shippingInfoDtos);

            if (httpResponse.getStatus() == HttpStatus.HTTP_OK) {
                String body = httpResponse.body();
                JSONObject returnInfo = JSONUtil.parseObj(body);
                String code = returnInfo.getStr("code");
                if (StringUtils.isNotBlank(code) && "200".equalsIgnoreCase(code)) {
                    WmsJusdaReceiptEntity update = new WmsJusdaReceiptEntity();
                    update.setId(d.getId());
                    update.setPostJusdaFlag(true);
                    update.setPostJusdaDate(LocalDateTime.now());
                    update.setPostJusdaMessage("");
                    update.updateById();
                } else {
                    WmsJusdaReceiptEntity update = new WmsJusdaReceiptEntity();
                    update.setId(d.getId());
                    update.setPostJusdaFlag(false);
                    update.setPostJusdaDate(LocalDateTime.now());
                    update.setPostJusdaMessage(code + " / " + returnInfo.getStr("Message"));
                    update.updateById();
                }
            }
        });
    }


    /**
     * 准时达收货资料过账SAP
     *
     * @param sapClient
     * @param orgCode
     */
    public void jusdaReceiveInfoPostingSAP(String sapClient, String orgCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }

        List<WmsJusdaReceiptEntity> docList =
                wmsJusdaReceiptMapper.selectList(Wrappers.<WmsJusdaReceiptEntity>lambdaQuery()
                        .eq(WmsJusdaReceiptEntity::getOrgCode, orgCode)
                        //.isNull(WmsJusdaReceiptEntity::getSapReturnNumber)
                        .last(" and shiped_qty = received_qty and (sap_return_number is null or sap_return_number  = '0')"));

        if (CollUtil.isEmpty(docList)) {
            return;
        }

        List<WmsJusdaBuContrastEntity> configs = wmsJusdaBuContrastMapper.selectList(Wrappers.<WmsJusdaBuContrastEntity>lambdaQuery().eq(WmsJusdaBuContrastEntity::getOrgCode, orgCode));

        if (CollUtil.isEmpty(configs)) {
            log.error("wmsJusdaBuContrast is null");
            return;
        }

        docList.forEach(d -> {
            if (Constants.continueJob.equalsIgnoreCase("N")) {
                return;
            }

            if (StringUtils.isBlank(d.getCustomerName())) {
                wmsJusdaReceiptMapper.update(null, Wrappers.<WmsJusdaReceiptEntity>lambdaUpdate().eq(WmsJusdaReceiptEntity::getId, d.getId()).set(WmsJusdaReceiptEntity::getSapReturnMessage,
                        "customer Name is null"));
                return;
            }

            Optional<WmsJusdaBuContrastEntity> customerConfig = configs.stream().filter(a -> a.getCustomerName().equalsIgnoreCase(d.getCustomerName())).findFirst();
            if (!customerConfig.isPresent()) {
                wmsJusdaReceiptMapper.update(null, Wrappers.<WmsJusdaReceiptEntity>lambdaUpdate().eq(WmsJusdaReceiptEntity::getId, d.getId()).set(WmsJusdaReceiptEntity::getSapReturnMessage,
                        "customer Name config is null"));
                return;
            }

            switch (customerConfig.get().getDeliveryType().toUpperCase()) {
                case "VMI":
                    //SAP  无PO GR
                    doVmiPostingSap(sapClient, d, customerConfig, postDate);
                    break;
                case "CMI":
                    //311 转仓
                    doCMIPostingSAP(sapClient, d, postDate);
                    break;
                default:
                    //不支持的类型
                    String errorMsg = "not support type " + customerConfig.get().getDeliveryType();
                    wmsJusdaReceiptMapper.update(null, Wrappers.<WmsJusdaReceiptEntity>lambdaUpdate().eq(WmsJusdaReceiptEntity::getId, d.getId())
                            .set(WmsJusdaReceiptEntity::getSapUploadData, LocalDateTime.now())
                            .set(WmsJusdaReceiptEntity::getSapReturnMessage,
                                    errorMsg));
                    break;
            }

        });


    }

    private void doCMIPostingSAP(String sapClient, WmsJusdaReceiptEntity d,
                                 String postDate) {
        if (StringUtils.isBlank(d.getFromWarehouseCode()) || StringUtils.isBlank(d.getToWarehouseCode())) {
            wmsJusdaReceiptMapper.update(null, Wrappers.<WmsJusdaReceiptEntity>lambdaUpdate()
                    .eq(WmsJusdaReceiptEntity::getId, d.getId())
                    .set(WmsJusdaReceiptEntity::getSapUploadData, LocalDateTime.now())
                    .set(WmsJusdaReceiptEntity::getSapReturnMessage,
                            "from or to wh is null"));
            return;
        }
//            List<WmsWorkOrderHeader> woHeaders =
//                    wmsWorkOrderHeaderMapper.selectList(Wrappers.<WmsWorkOrderHeader>lambdaQuery().eq(WmsWorkOrderHeader::getOrgCode, orgCode).eq(WmsWorkOrderHeader::getWorkOrderNo, wo));
//            if (CollUtil.isEmpty(woHeaders)) {
//                wmsJusdaReceiptMapper.update(null, Wrappers.<WmsJusdaReceiptEntity>lambdaUpdate().eq(WmsJusdaReceiptEntity::getId, d.getId()).set(WmsJusdaReceiptEntity::getSapReturnMessage, "Wo not exist"));
//                return;
//            }

        try {
//                Optional<WmsJusdaBuContrastEntity> cmiConfig =
//                        configs.stream().filter(a -> a.getCustomerName().equalsIgnoreCase(d.getCustomerName())
//                                && orgCode.equalsIgnoreCase(a.getOrgCode())
//                                && a.getPlantCode().equalsIgnoreCase(d.getPlantCode())
//                                && a.getSupplierName().equalsIgnoreCase(d.getSupplierName())
//                                && a.getMrpArea().equalsIgnoreCase(woHeaders.get(0).getMrpArea())
//                                && a.getMrpController().contains(woHeaders.get(0).getMrpController())).findFirst();
//
//            if (!cmiConfig.isPresent()) {
//                wmsJusdaReceiptMapper.update(null, Wrappers.<WmsJusdaReceiptEntity>lambdaUpdate().eq(WmsJusdaReceiptEntity::getId, d.getId()).set(WmsJusdaReceiptEntity::getSapReturnMessage, "cmi config not exist"));
//                return;
//            }

            TransferDto dto = new TransferDto();
            dto.setTransactionDate(postDate);
            dto.setDocDate(postDate);
            dto.setMoveType("311");
            dto.setGmCode("04");
            //List<MaterialStockInfoDto> valueTypeList = whRfcService.doGetStockInfo(sapClient, cmiConfig.get().getPlantCode(), Arrays.asList(cmiConfig.get().getTransferFrom()),
            //        Arrays.asList(d.getCustomerPartNo()), null);

            String valueTypeValue = materialRfcService.doGetMaterialValueType(sapClient, d.getPlantCode(), d.getCustomerPartNo(), d.getFromWarehouseCode());
            if (StringUtils.isEmpty(valueTypeValue)) {
                wmsJusdaReceiptMapper.update(null, Wrappers.<WmsJusdaReceiptEntity>lambdaUpdate().eq(WmsJusdaReceiptEntity::getId, d.getId()).set(WmsJusdaReceiptEntity::getSapReturnMessage,
                        "part value type not exist"));
            }

            dto.setValueType(valueTypeValue);
            dto.setQty(d.getReceivedQty().toString());
            dto.setUnit(d.getUom());
            dto.setFromPlant(d.getPlantCode());
            dto.setFromWarehouseName(d.getFromWarehouseCode());
            dto.setFromPartNo(d.getCustomerPartNo());
            dto.setToPlant(d.getPlantCode());
            dto.setToWarehouseName(d.getToWarehouseCode());
            dto.setToPartNo(d.getCustomerPartNo());
            dto.setFromPartVersion(d.getCpnVersion());
            String s = whRfcService.doTransfer(sapClient, dto);
            log.info("doCMIPostingSAP result {}", s);
            if (StringUtils.isNotBlank(s)) {
                WmsJusdaReceiptEntity update = new WmsJusdaReceiptEntity();
                update.setId(d.getId());
                update.setSapReturnNumber(s);
                update.setSapUploadData(LocalDateTime.now());
                update.setSapReturnMessage("from " + d.getFromWarehouseCode() + " to " + d.getToWarehouseCode());
                update.setCustomerReceiveType("CMI");
                update.updateById();
            }
        } catch (Exception e) {
            log.error(e.getMessage());
            wmsJusdaReceiptMapper.update(null, Wrappers.<WmsJusdaReceiptEntity>lambdaUpdate().eq(WmsJusdaReceiptEntity::getId, d.getId())
                    .set(WmsJusdaReceiptEntity::getSapUploadData, LocalDateTime.now())
                    .set(WmsJusdaReceiptEntity::getSapReturnMessage,
                            e.getMessage()));
        }

    }

    private void doVmiPostingSap(String sapClient, WmsJusdaReceiptEntity d, Optional<WmsJusdaBuContrastEntity> customerConfig,
                                 String postDate) {
        GenerateVmiGrDto inputEntity = new GenerateVmiGrDto();
        inputEntity.setTransactionDate(postDate);
        //inputEntity.setRefDocNo(d.getShipId());
        inputEntity.setPartNo(d.getCustomerPartNo());
        inputEntity.setLocalDealNumber(d.getInnerTransferNo());
        inputEntity.setLocalDealItem(d.getInnerTransferNoItem());
        inputEntity.setPartVersion(d.getCpnVersion());
        inputEntity.setPlant(customerConfig.get().getPlantCode());
        inputEntity.setQty(d.getReceivedQty().toString());
        inputEntity.setUserName("WMSVMI");
        inputEntity.setWarehouseName(d.getToWarehouseCode());
        inputEntity.setVendor(d.getCustomerSupplierNo());
        inputEntity.setUnit(d.getUom());
        inputEntity.setReceiptNumber(d.getShipId());

        try {
            Result result = grRfcService.doGenerateVmiGr(sapClient, inputEntity);
            log.info("doVmiPostingSap result {}", JSONUtil.toJsonStr(result));
            if (result.getCode() == 0) {
                PoItemInfoDto poItemInfoDto = (PoItemInfoDto) result.getData();
                WmsJusdaReceiptEntity update = new WmsJusdaReceiptEntity();
                update.setId(d.getId());
                update.setSapReturnNumber(result.getMessage());
                update.setSapUploadData(LocalDateTime.now());
                update.setSapReturnMessage("OK");
                update.setVmiPoNumber(poItemInfoDto.getPoNumber());
                update.setVmiPoItem(poItemInfoDto.getPoItem());
                update.setVmiWarehouseCode(poItemInfoDto.getWarehouseCode());
                update.setCustomerReceiveType("VMI");
                update.updateById();
            } else {
                String errorMsg = result.getMessage();
                wmsJusdaReceiptMapper.update(null, Wrappers.<WmsJusdaReceiptEntity>lambdaUpdate()
                        .eq(WmsJusdaReceiptEntity::getId, d.getId())
                        .set(WmsJusdaReceiptEntity::getSapUploadData, LocalDateTime.now())
                        .set(WmsJusdaReceiptEntity::getSapReturnMessage, errorMsg));
            }
        } catch (Exception e) {
            log.error(e.getMessage());
            wmsJusdaReceiptMapper.update(null, Wrappers.<WmsJusdaReceiptEntity>lambdaUpdate()
                    .eq(WmsJusdaReceiptEntity::getId, d.getId())
                    .set(WmsJusdaReceiptEntity::getSapUploadData, LocalDateTime.now())
                    .set(WmsJusdaReceiptEntity::getSapReturnMessage, e.getMessage()));
        }
    }

    public void asnPostJusda(String orgCode, String postJusdaFlag) {
        List<WmsAsnUpload> wmsAsnUploadList = wmsAsnUploadMapper.selectList(Wrappers.<WmsAsnUpload>lambdaQuery()
                .eq(WmsAsnUpload::getIsDeleted, Boolean.FALSE)
                .eq(WmsAsnUpload::getOrgCode, orgCode)
                .eq(WmsAsnUpload::getPostJusdaFlag, postJusdaFlag));
        if (CollUtil.isEmpty(wmsAsnUploadList)) {
            return;
        }
        //按invoice-no、customer-name、supplier-name分组抛jusda
        Map<String, List<WmsAsnUpload>> map = wmsAsnUploadList.stream().collect(
                Collectors.groupingBy(v -> v.getInvoiceNo() + "-" + v.getCustomerName() + "-" + v.getSupplierName()));
        WmsSapPlant wmsSapPlant = wmsSapPlantMapper.selectOne(Wrappers.<WmsSapPlant>lambdaQuery()
                .eq(WmsSapPlant::getOrgCode, orgCode)
                .last("limit 1"));
        String sectionType = wmsSapPlant.getSectionType();
        for (Map.Entry<String, List<WmsAsnUpload>> entry : map.entrySet()) {
            List<WmsAsnUpload> postAsnUploadList = entry.getValue();
            postAsnUploadList.sort(Comparator.comparing(WmsAsnUpload::getDocNo));

            String invoiceNo = postAsnUploadList.get(0).getInvoiceNo();
            String customerName = postAsnUploadList.get(0).getCustomerName();
            String supplierName = postAsnUploadList.get(0).getSupplierName();
            String docNo = postAsnUploadList.get(0).getDocNo();
            LocalDate eta = postAsnUploadList.get(0).getEta();
            RequestContentDto requestContent = new RequestContentDto();
            requestContent.setCreateBatchAsnType("OUTER_PO");
            List<CreateAsnListDto> asnList = new ArrayList<>();
            CreateAsnListDto asn = new CreateAsnListDto();
            asn.setAsnStatus("RELEASED");   //asn状态
            asn.setBuyerCompanyCode(customerName);    //采购方公司编码
            asn.setVendorCompanyCode(supplierName);   //供货方公司编码
            Long longEta = eta.atStartOfDay(ZoneOffset.ofHours(8)).toInstant().toEpochMilli();
            asn.setExpectArrivalWarehouseDate(longEta); //预计到仓日期
            asn.setReferenceNo(docNo);     //参考单号
            TransportationInputDto transportationInputDto = new TransportationInputDto();
            transportationInputDto.setCarrierCompanyCode("JUSDA");   //承运方公司编码
            asn.setTransportationInputDTO(transportationInputDto);

            List<CreateAsnItemDetailListDto> asnItems = new ArrayList<>();
            postAsnUploadList.forEach(a -> {
                CreateAsnItemDetailListDto asnItem = new CreateAsnItemDetailListDto();

                asnItem.setPoNo(a.getCustomerPo());
                asnItem.setPoLine(Integer.parseInt(a.getCustomerPoItem()));
                if ("ASSEMBLY_SECTION".equals(sectionType) && "LX".equals(orgCode)) {
                    asnItem.setPartNo(a.getCustomerPartNo() + a.getPartVersion());
                } else {
                    asnItem.setPartNo(a.getCustomerPartNo());
                }
                asnItem.setShippingQty(a.getShippingQty());
                asnItem.setUnitPrice(a.getPrice());
                asnItem.setCurrency(a.getCurrency());
                asnItem.setGrossWeight(a.getGrossWeight());
                asnItem.setPallet(a.getPalletQty());
                asnItem.setCarton(a.getCartonQty());
                asnItem.setInvoiceNo(invoiceNo);
                asnItem.setOriginPlaceCode(a.getCountryOfOriginal());
                asnItem.setVendorPartNo(a.getSupplierPartNo());
                asnItem.setManufacturer(a.getMfr());
                asnItem.setPurchasingType(a.getAsnType());
                AsnExtensionalDataDto extensionalDataDto = new AsnExtensionalDataDto();
                extensionalDataDto.setReference1(StrUtil.EMPTY);
                if (StrUtil.isNotBlank(a.getDc())) {
                    List<String> dcList = StrUtil.split(a.getDc(), ",").stream().sorted(Comparator.comparing(k -> k)).collect(Collectors.toList());
                    String plantCode = a.getPlantCode();
                    String customerPartNo = a.getCustomerPartNo();
                    String supplierPartNo = a.getSupplierPartNo();
                    String mfr = a.getMfr();
                    BasicMaterialMfgEntity basicMaterialMfgEntity = basicMaterialMfgMapper.selectMaterialMfg(orgCode, plantCode, customerPartNo, mfr, supplierPartNo);
                    if (ObjectUtil.isNotNull(basicMaterialMfgEntity)) {
                        if (StrUtil.isNotBlank(basicMaterialMfgEntity.getDatecodeFormat())) {
                            String minDateCode = dcList.get(0);
                            List<String> allDateCodeFormat = StrUtil.split(basicMaterialMfgEntity.getDatecodeFormat(), ",");
                            String dateCodeFormat = allDateCodeFormat.stream().filter(item -> item.length() == minDateCode.length()).findFirst().orElse(null);
                            if (ObjectUtil.isNotNull(dateCodeFormat)) {
                                String dc = dcList.stream().collect(Collectors.joining(","));
                                extensionalDataDto.setReference1(dateCodeFormat + "," + dc);
                            }
                        }
                    }
                }
                asnItem.setExtensionalData(extensionalDataDto);
                asnItems.add(asnItem);
            });
            asn.setCreateAsnItemDetailList(asnItems);
            asnList.add(asn);
            requestContent.setCreateAsnList(asnList);
            String rquestJson = JSON.toJSONString(requestContent);
            if (StrUtil.isNotBlank(rquestJson)) {
                rquestJson = StrUtil.replace(rquestJson, "\u0000", "");
            }
            log.info("ASN：{}, request：{}", docNo, rquestJson);
            String senderId = postAsnUploadList.get(0).getSenderId();
            String msgType = postAsnUploadList.get(0).getMsgType();
            String receiverId = postAsnUploadList.get(0).getReceiverId();
            HttpResponse httpResponse = jusdaWebService.asnPostJusda(senderId, msgType, receiverId, docNo, rquestJson);
            //抛jusda的idList
            List<Integer> idList = postAsnUploadList.stream().map(item -> item.getId()).collect(Collectors.toList());
            if (httpResponse.getStatus() == HttpStatus.HTTP_OK) {
                String body = httpResponse.body();
                log.info("ASN：{}, result body： {}", docNo, body);
                //去掉特殊字符
                body.replace('\u0000', ' ');
                JSONObject returnInfo = JSONUtil.parseObj(body);
                String isSuccess = returnInfo.getStr("isSuccess");
                try {
                    if (StringUtils.isNotBlank(isSuccess) && "true".equalsIgnoreCase(isSuccess)) {
                        wmsAsnUploadMapper.update(null, Wrappers.<WmsAsnUpload>lambdaUpdate()
                                .in(WmsAsnUpload::getId, idList)
                                .set(WmsAsnUpload::getReferenceNo, docNo)
                                .set(WmsAsnUpload::getPostJusdaFlag, "1")
                                .set(WmsAsnUpload::getPostJusdaDate, LocalDateTime.now())
                                .set(WmsAsnUpload::getPostJusdaReturnMsg, returnInfo.getStr("message"))
                                .set(WmsAsnUpload::getPostJusdaJson, rquestJson)
                                .set(WmsAsnUpload::getPostJusdaReturnInfo, body));
                    } else {
                        wmsAsnUploadMapper.update(null, Wrappers.<WmsAsnUpload>lambdaUpdate()
                                .in(WmsAsnUpload::getId, idList)
                                .set(WmsAsnUpload::getReferenceNo, docNo)
                                .set(WmsAsnUpload::getPostJusdaFlag, "2")
                                .set(WmsAsnUpload::getPostJusdaDate, LocalDateTime.now())
                                .set(WmsAsnUpload::getPostJusdaReturnMsg, returnInfo.getStr("message"))
                                .set(WmsAsnUpload::getPostJusdaJson, rquestJson)
                                .set(WmsAsnUpload::getPostJusdaReturnInfo, body));
                    }
                } catch (Exception e) {
                    log.info("ASN：{}, update error： {}", docNo, e.getMessage());
                    wmsAsnUploadMapper.update(null, Wrappers.<WmsAsnUpload>lambdaUpdate()
                            .in(WmsAsnUpload::getId, idList)
                            .set(WmsAsnUpload::getReferenceNo, docNo)
                            .set(WmsAsnUpload::getPostJusdaFlag, "2")
                            .set(WmsAsnUpload::getPostJusdaDate, LocalDateTime.now())
                            .set(WmsAsnUpload::getPostJusdaReturnMsg, "WMS update error")
                            .set(WmsAsnUpload::getPostJusdaJson, rquestJson));
                }
            } else {
                wmsAsnUploadMapper.update(null, Wrappers.<WmsAsnUpload>lambdaUpdate()
                        .in(WmsAsnUpload::getId, idList)
                        .set(WmsAsnUpload::getReferenceNo, docNo)
                        .set(WmsAsnUpload::getPostJusdaFlag, "2")
                        .set(WmsAsnUpload::getPostJusdaDate, LocalDateTime.now())
                        .set(WmsAsnUpload::getPostJusdaReturnMsg, "asnPostJusda interface err")
                        .set(WmsAsnUpload::getPostJusdaJson, rquestJson));
            }
        }
    }
}
