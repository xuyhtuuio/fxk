package com.maxnerva.cloudmes.mapper.doc;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.doc.WmsDocTcHeader;

public interface WmsDocTcHeaderMapper extends BaseMapper<WmsDocTcHeader> {
}
