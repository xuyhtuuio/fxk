package com.maxnerva.cloudmes.service.basic;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.LocalDateTimeUtil;
import cn.hutool.core.util.NumberUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.entity.WmsSapPlant;
import com.maxnerva.cloudmes.entity.basic.BasicMaterialEntity;
import com.maxnerva.cloudmes.entity.basic.BasicMaterialMfgEntity;
import com.maxnerva.cloudmes.entity.wo.*;
import com.maxnerva.cloudmes.mapper.WmsSapPlantMapper;
import com.maxnerva.cloudmes.mapper.basic.BasicMaterialMapper;
import com.maxnerva.cloudmes.mapper.basic.BasicMaterialMfgMapper;
import com.maxnerva.cloudmes.mapper.wo.WmsWarehouseRelationMapper;
import com.maxnerva.cloudmes.mapper.wo.WmsWorkOrderDetailMapper;
import com.maxnerva.cloudmes.mapper.wo.WmsWorkOrderHeaderMapper;
import com.maxnerva.cloudmes.service.sap.material.MaterialRfcService;
import com.maxnerva.cloudmes.service.sap.material.model.AvlDto;
import com.maxnerva.cloudmes.service.sap.material.model.MaterialInfoDto;
import com.maxnerva.cloudmes.service.sap.wh.WhRfcService;
import com.maxnerva.cloudmes.service.sap.wh.model.MaterialStockInfoDto;
import com.maxnerva.cloudmes.service.sap.wo.WoRfcService;
import com.maxnerva.cloudmes.service.sap.wo.model.SapWoDetailDto;
import com.maxnerva.cloudmes.service.sap.wo.model.SapWoHeaderDto;
import com.maxnerva.cloudmes.service.sfc.SfcStoredProcedureFactory;
import com.maxnerva.cloudmes.service.wo.IWmsBomFeederService;
import com.maxnerva.cloudmes.service.wo.IWmsWorkOrderDetailService;
import com.maxnerva.cloudmes.service.wo.IWmsWorkOrderVehicleRecordService;
import com.sap.conn.jco.JCoException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.message.ReusableMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @ClassName IWoService
 * @Description 工单管理service
 * @Author Likun
 * @Date 2022/8/30
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Service
@Slf4j
public class MaterialService {

    @Autowired
    BasicMaterialMapper basicMaterialMapper;

    @Autowired
    BasicMaterialMfgMapper basicMaterialMfgMapper;

    @Autowired
    MaterialRfcService materialRfcService;

    @Autowired
    WmsSapPlantMapper sapPlantMapper;


    /**
     * 同步物料主档资料
     */
    public void syncMaterial(String orgCode, String partNo, String startDate, String endDate) {

        List<WmsSapPlant> plantList = sapPlantMapper.selectList(Wrappers.<WmsSapPlant>lambdaQuery()
                .eq(StringUtils.isNotBlank(orgCode), WmsSapPlant::getOrgCode, orgCode));

        plantList.forEach(p -> {

            List<MaterialInfoDto> materialInfoDtos = new ArrayList<>();

            try {
                materialInfoDtos = materialRfcService.doGetMaterialInfo(p.getErpInterface(), p.getFactoryCode(), partNo, startDate, endDate);

            } catch (JCoException e) {
                log.error("syncMaterial error : {}", e.getMessage());
            }

            if (CollUtil.isNotEmpty(materialInfoDtos)) {

                List<BasicMaterialEntity> insertMaterialList = new LinkedList<>();

                materialInfoDtos.forEach(m -> {
                    BasicMaterialEntity insert = new BasicMaterialEntity();
                    insert.setOrgCode(orgCode);
                    insert.setMaterialNo(m.getPartNo());
                    insert.setMaterialName(m.getPartDesc());
                    insert.setMaterialType(m.getMaterialType());
                    insert.setMaterialValue(m.getLevel());
                    insert.setCustodinCode(m.getBuyer());
                    insert.setFifo(0);
                    insert.setProductType("SMT");
                    insert.setUpc(m.getUnit());
                    insert.setCreator(m.getBuyerName());
                    insert.setCreatedDt(System.currentTimeMillis());
                    basicMaterialMapper.insertMaterialInfo(insert);
//                    insert.insert();
                });
                //orgcode + 料号为主键判断
//                 basicMaterialMapper.insert()

            }


        });
    }


    /**
     * 同步AVL
     */
    public void syncAvl(String orgCode, String partNo) {

        List<WmsSapPlant> plantList = sapPlantMapper.selectList(Wrappers.<WmsSapPlant>lambdaQuery()
                .eq(StringUtils.isNotBlank(orgCode), WmsSapPlant::getOrgCode, orgCode));

        plantList.forEach(p -> {

            List<String> parts = new ArrayList<>();

            if (StringUtils.isBlank(partNo)) {

                List<BasicMaterialEntity> partList = new ArrayList<>();

                partList = basicMaterialMapper.selectList(Wrappers.<BasicMaterialEntity>lambdaQuery()
                        .eq(BasicMaterialEntity::getOrgCode, orgCode));

                if (CollUtil.isEmpty(partList)) {
                    return;
                }

                parts = partList.stream().map(ww -> ww.getMaterialNo()).collect(Collectors.toList());

            } else {

                parts.add(partNo);
            }

            List<AvlDto> avlDtos = new ArrayList<>();

            try {

                avlDtos = materialRfcService.doGetAvlInfoByPartno(p.getErpInterface(), p.getFactoryCode(), parts);

            } catch (JCoException e) {
                log.error("syncMaterial error : {}", e.getMessage());
            }

            if (CollUtil.isNotEmpty(avlDtos)) {

                //去重
                List<AvlDto> avlList =
                        avlDtos.stream().filter(ww -> !ww.getFlag().equalsIgnoreCase("X")).collect(Collectors.collectingAndThen(Collectors.toCollection(() ->
                                        new TreeSet<>(Comparator.comparing(item -> item.getPartNo() + item.getSupplierPartNo() + item.getSupplierName()))),
                                ArrayList::new));

                List<BasicMaterialMfgEntity> insertMaterialList = new LinkedList<>();

                avlList.forEach(m -> {
                    BasicMaterialMfgEntity insert = new BasicMaterialMfgEntity();
                    insert.setOrgCode(orgCode);
                    insert.setMaterialNo(m.getPartNo());
                    insert.setMfgMaterialCode(m.getSupplierPartNo());
                    insert.setStartValidDate(StringUtils.isNotBlank(m.getFromValidity()) && !"00000000".equalsIgnoreCase(m.getFromValidity().replaceAll("-","")) ?
                            LocalDateTimeUtil.parseDate(m.getFromValidity(),
                            "yyyy-MM-dd") : LocalDate.now());
                    insert.setEndValidDate(StringUtils.isNotBlank(m.getToValidity()) && !"00000000".equalsIgnoreCase(m.getToValidity().replaceAll("-","")) ?
                            LocalDateTimeUtil.parseDate(m.getToValidity(),
                            "yyyy-MM-dd") : LocalDate.now());
                    insert.setMfgName(m.getSupplierName());
                    basicMaterialMfgMapper.insertMaterialMfg(insert);
//                    insert.insert();
                });

                //有删除标记的
                List<AvlDto> deleteAvlList =
                        avlDtos.stream().filter(ww -> ww.getFlag().equalsIgnoreCase("X")).collect(Collectors.collectingAndThen(Collectors.toCollection(() ->
                                        new TreeSet<>(Comparator.comparing(item -> item.getPartNo() + item.getSupplierPartNo() + item.getSupplierName()))),
                                ArrayList::new));

                if (CollUtil.isNotEmpty(deleteAvlList)) {
                    deleteAvlList.forEach(aa -> {
                        Optional<AvlDto> first = avlList.stream().filter(cc -> cc.getPartNo().equalsIgnoreCase(aa.getPartNo())
                                && cc.getSupplierPartNo().equalsIgnoreCase(aa.getSupplierPartNo())
                                && cc.getSupplierName().equalsIgnoreCase(aa.getSupplierName())).findFirst();

                        if (first.isPresent()) {
                            BasicMaterialMfgEntity update = new BasicMaterialMfgEntity();
                            update.setIsDeleted(true);
                            int update1 = basicMaterialMfgMapper.update(update, Wrappers.<BasicMaterialMfgEntity>lambdaUpdate()
                                    .eq(BasicMaterialMfgEntity::getOrgCode, orgCode)
                                    .eq(BasicMaterialMfgEntity::getMaterialNo, aa.getPartNo())
                                    .eq(BasicMaterialMfgEntity::getMfgMaterialCode, aa.getSupplierPartNo())
                                    .eq(BasicMaterialMfgEntity::getMfgMaterialName, aa.getSupplierName()));

                        }
                    });
                }


            }


        });
    }


}
