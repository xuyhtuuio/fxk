package com.maxnerva.cloudmes.entity.wo;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @author MFQ
 * @date 2023/10/19 下午 07:16
 */
@Data
@ApiModel(value = "WmsCkdCus对象", description = "Cus记录")
public class WmsCkdCus extends BaseEntity<WmsCkdCus> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主鍵id")
    private Integer id;

    @ApiModelProperty("料号")
    private String hhPn;

    @ApiModelProperty("到货时间")
    private LocalDate date;

    @ApiModelProperty("报关单号")
    private String cusNo;

    @ApiModelProperty("报关项次")
    private String cusItem;

    @ApiModelProperty("报关单价")
    private BigDecimal price;

    @ApiModelProperty("实际报关单价（按照单位换算后的）")
    private BigDecimal actualPrice;

    @ApiModelProperty("数量")
    private BigDecimal qty;

    @ApiModelProperty("原产国")
    private String coo;

    @ApiModelProperty("申报要素	")
    private String spec;

    @ApiModelProperty("预报关单号")
    private String cutNo;

    @ApiModelProperty("预报关项次")
    private String cusUne;

    @ApiModelProperty("po")
    private String po;

    @ApiModelProperty("po项次")
    private String poItem;

    @ApiModelProperty("创建人")
    private String creator;

    @ApiModelProperty("创建时间")
    private LocalDateTime createdDt;

    @ApiModelProperty("组织")
    private String orgCode;

    @ApiModelProperty("商品編號")
    private String goodNo;

    @ApiModelProperty("商品名稱")
    private String goodName;

    @ApiModelProperty("單位編號")
    private String unitNo;

    @ApiModelProperty("單位 007 pc 054 kpc")
    private BigDecimal unitMultiple;

    @ApiModelProperty("申報幣別")
    private String currency;

    @ApiModelProperty("申報部門")
    private String department;

    @ApiModelProperty("來源數量 （數量按照單位換算後的）")
    private BigDecimal actualQty;

    @ApiModelProperty("起運國")
    private String countryOfDeparture;

    @ApiModelProperty("目的地運國（抵運國）")
    private String countryOfArrival;

    @ApiModelProperty("起運港口")
    private String portOfDeparture;

}
