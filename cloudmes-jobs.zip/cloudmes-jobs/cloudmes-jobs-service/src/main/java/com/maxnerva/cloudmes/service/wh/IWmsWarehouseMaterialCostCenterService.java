package com.maxnerva.cloudmes.service.wh;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.entity.wh.WmsWarehouseMaterialCostCenter;

/**
 * <p>
 * 物料成本中心 服务类
 * </p>
 *
 * @author likun
 * @since 2022-11-01
 */
public interface IWmsWarehouseMaterialCostCenterService extends IService<WmsWarehouseMaterialCostCenter> {

}
