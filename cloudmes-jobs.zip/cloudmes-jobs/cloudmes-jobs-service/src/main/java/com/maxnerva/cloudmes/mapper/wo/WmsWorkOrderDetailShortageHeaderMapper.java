package com.maxnerva.cloudmes.mapper.wo;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderDetailShortageHeader;

public interface WmsWorkOrderDetailShortageHeaderMapper extends BaseMapper<WmsWorkOrderDetailShortageHeader> {
}
