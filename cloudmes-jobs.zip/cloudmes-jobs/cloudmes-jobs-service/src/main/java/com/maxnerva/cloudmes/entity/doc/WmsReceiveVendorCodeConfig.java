package com.maxnerva.cloudmes.entity.doc;

import java.time.LocalDateTime;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * (WmsReceiveVendorCodeConfig)实体类
 *
 * @author hgx
 * @since 2023-12-28
 */

@ApiModel("WmsReceiveVenderCodeConfig实体类")
@Data
public class WmsReceiveVendorCodeConfig extends BaseEntity<WmsReceiveVendorCodeConfig> {
 
   
    private Integer id;
   
    private String orgCode;
   
    private String vendorCode;
   
    private String vendorName;
   
    private String vendorAddress;
   
    private String receiveTypeCode;
   
    private String instockStatus;
   
    private String badWarehouseCode;
   
    private String remark;
   
    @ApiModelProperty("创建人")
    private String creator;
   
    @ApiModelProperty("创建人员工id，冗余字段")
    private Integer creatorId;
   
    @ApiModelProperty("创建时间")
    private LocalDateTime createdDt;
   
    @ApiModelProperty("修改人")
    private String lastEditor;
   
    @ApiModelProperty("修改人员工id，冗余字段")
    private Integer lastEditorId;
   
    @ApiModelProperty("修改时间")
    private LocalDateTime lastEditedDt;
}

