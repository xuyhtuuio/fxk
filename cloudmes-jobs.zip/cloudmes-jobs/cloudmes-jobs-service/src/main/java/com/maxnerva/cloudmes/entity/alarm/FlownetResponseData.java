package com.maxnerva.cloudmes.entity.alarm;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel("Flownet返回数据")
@Data
public class FlownetResponseData {
    @ApiModelProperty("申請單號")
    private String businessRequestNo;

    @ApiModelProperty("Flownet 表單唯一 ID")
    private String flownetFormID;

    @ApiModelProperty("新建表單地址，業務系統獲得後，重定向到這裡")
    private String URL;
}
