package com.maxnerva.cloudmes.entity.qms;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName SyncQmsMsdLevelVO
 * @Description TODO
 * @Author Likun
 * @Date 2024/11/28
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("同步qms msd等级")
@Data
public class SyncQmsMsdLevelVO {

    @ApiModelProperty(value = "厂商")
    private String mfg;

    @ApiModelProperty(value = "厂商料号")
    private String mfgMaterialCode;

    @ApiModelProperty(value = "制造商版次")
    private String mfgMaterialVersion;

    @ApiModelProperty(value = "level等级")
    private String msdLevel;

    @ApiModelProperty("组织")
    private String orgCode;
}
