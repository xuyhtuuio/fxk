package com.maxnerva.cloudmes.entity.wo;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 仓库对照关系表
 * </p>
 *
 * @author likun
 * @since 2022-09-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsWarehouseRelation对象", description="仓库对照关系表")
public class WmsWarehouseRelation extends BaseEntity<WmsWarehouseRelation> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "工厂编码")
    private String plantCode;

    @ApiModelProperty(value = "来源仓码")
    private String fromWarehouseCode;

    @ApiModelProperty(value = "来源仓码备注")
    private String fromWarehouseRemark;

    @ApiModelProperty(value = "目标仓码,kitting仓仓码")
    private String toWarehouseCode;

    @ApiModelProperty(value = "目标仓码描述")
    private String toWarehouseRemark;

    @ApiModelProperty(value = "功能类型，(备料,退料,料调）参考字典值")
    private String changeType;

    @ApiModelProperty(value = "BU（业务单元）")
    private String orgCode;

}
