package com.maxnerva.cloudmes.service.trading;

import com.maxnerva.cloudmes.mapper.trading.WmsTradingRecordMapper;
import com.maxnerva.cloudmes.service.sap.trading.TradingRfcService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/11/09 10:32
 * @Version: 1.0
 */
@Service
@Slf4j
public class TradingService {

    @Autowired
    WmsTradingRecordMapper wmsTradingRecordMapper;
    @Autowired
    TradingRfcService tradingRfcService;

    //  内交出，产生内交单号
    public void generateTradingNumber(){

        //wmsTradingRecordMapper.selectList(Wrappers.<WmsTradingRecordEntity>lambdaQuery()
        //        .eq(WmsTradingRecordEntity::))

    }

    // PGI
    public void tradingPgi(){

    }

    // gr
    public void tradingGr(String sapClient) {

        //wmsTradingRecordMapper.selectList(Wrappers.<WmsTradingRecordEntity>lambdaQuery()
        //        .eq(WmsTradingRecordEntity::))
        //tradingRfcService.doGetTradingPoInfo(sapClient,p)
    }


}
