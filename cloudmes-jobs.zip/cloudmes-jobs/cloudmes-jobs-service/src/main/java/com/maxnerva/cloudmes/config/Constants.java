package com.maxnerva.cloudmes.config;

/**
 * @Description: 常量池
 * @Author: Chao Zhang
 * @Date: 2023/02/22 10:42
 * @Version: 1.0
 */
public class Constants {

    /**
     * 终止JOB循环标识， Y：继续循环， N：终止循环
     */
    public static String continueJob = "N";
}
