package com.maxnerva.cloudmes.mapper.doc;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.doc.WmsTradingDocImportRecord;

/**
 * <p>
 * 内交入收货单导入记录 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2023-02-06
 */
public interface WmsTradingDocImportRecordMapper extends BaseMapper<WmsTradingDocImportRecord> {

    int insertTradingDocImportRecord(WmsTradingDocImportRecord wmsTradingDocImportRecord);
}
