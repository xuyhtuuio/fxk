package com.maxnerva.cloudmes.service.jusda.model;

import lombok.Data;

@Data
public class AsnExtensionalDataDto {

    private String reference1;
}
