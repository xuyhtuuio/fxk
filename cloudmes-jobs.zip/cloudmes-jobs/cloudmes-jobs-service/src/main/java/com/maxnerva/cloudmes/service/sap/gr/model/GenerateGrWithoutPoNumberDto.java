package com.maxnerva.cloudmes.service.sap.gr.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @author H7109018
 */
@Data
public class GenerateGrWithoutPoNumberDto implements Serializable {
    private static final long serialVersionUID = 1L;

    private String transactionDate;
    private String refDocNo;
    private String partNo;
    private String partVersion;
    private String plant;
    private String qty;
    private String userName;
    private String warehouseName;

}