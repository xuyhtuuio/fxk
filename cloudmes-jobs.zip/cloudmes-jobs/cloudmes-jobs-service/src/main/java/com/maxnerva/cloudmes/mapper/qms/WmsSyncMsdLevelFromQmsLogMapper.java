package com.maxnerva.cloudmes.mapper.qms;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.qms.WmsSyncMsdLevelFromQmsLog;

/**
 * <p>
 * 从qms同步msd等级表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2024-11-28
 */
public interface WmsSyncMsdLevelFromQmsLogMapper extends BaseMapper<WmsSyncMsdLevelFromQmsLog> {

}
