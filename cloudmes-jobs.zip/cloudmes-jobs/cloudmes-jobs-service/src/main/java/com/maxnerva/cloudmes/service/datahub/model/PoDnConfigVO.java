package com.maxnerva.cloudmes.service.datahub.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("查询createPoDnConfigVO")
public class PoDnConfigVO {

    private String orgCode;

    private String plantCode;

    @ApiModelProperty("出货地")
    private String siteCode;
}
