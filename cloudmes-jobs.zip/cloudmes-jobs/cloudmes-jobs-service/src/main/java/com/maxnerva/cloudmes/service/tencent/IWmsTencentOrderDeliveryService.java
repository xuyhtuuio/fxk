package com.maxnerva.cloudmes.service.tencent;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.entity.tencent.WmsTencentOrderDelivery;

/**
 * <p>
 * MES腾讯订单配送信息表 服务类
 * </p>
 *
 * @author likun
 * @since 2025-05-20
 */
public interface IWmsTencentOrderDeliveryService extends IService<WmsTencentOrderDelivery> {

}
