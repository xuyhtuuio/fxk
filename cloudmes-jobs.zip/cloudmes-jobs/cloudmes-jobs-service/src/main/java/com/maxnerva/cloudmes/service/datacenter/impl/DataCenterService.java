package com.maxnerva.cloudmes.service.datacenter.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpStatus;
import cn.hutool.json.JSONConfig;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.config.DataCenterConfig;
import com.maxnerva.cloudmes.config.JusdaUrlConfig;
import com.maxnerva.cloudmes.entity.WmsSapPlant;
import com.maxnerva.cloudmes.entity.basic.GetProductFlagDTO;
import com.maxnerva.cloudmes.entity.basic.WmsSapWarehouseCode;
import com.maxnerva.cloudmes.entity.datacenter.WmsPostFiiLog;
import com.maxnerva.cloudmes.entity.deliver.WmsDocProductShipDetail;
import com.maxnerva.cloudmes.entity.deliver.WmsDocProductShipHeader;
import com.maxnerva.cloudmes.entity.jusda.WmsJusdaBuContrastEntity;
import com.maxnerva.cloudmes.entity.jusda.WmsJusdaInventory;
import com.maxnerva.cloudmes.entity.jusda.WmsJusdaInventoryConfig;
import com.maxnerva.cloudmes.mapper.WmsSapPlantMapper;
import com.maxnerva.cloudmes.mapper.basic.BasicMaterialMapper;
import com.maxnerva.cloudmes.mapper.basic.WmsSapWarehouseCodeMapper;
import com.maxnerva.cloudmes.mapper.datacenter.WmsPostFiiLogMapper;
import com.maxnerva.cloudmes.mapper.deliver.WmsProductShipDetailMapper;
import com.maxnerva.cloudmes.mapper.deliver.WmsProductShipHeaderMapper;
import com.maxnerva.cloudmes.mapper.doc.WmsDocReceiveMapper;
import com.maxnerva.cloudmes.mapper.jusda.WmsJusdaBuContrastMapper;
import com.maxnerva.cloudmes.mapper.jusda.WmsJusdaInventoryConfigMapper;
import com.maxnerva.cloudmes.mapper.jusda.WmsJusdaInventoryMapper;
import com.maxnerva.cloudmes.mapper.jusda.WmsJusdaReceiptMapper;
import com.maxnerva.cloudmes.mapper.wh.WmsPkgInfoMapper;
import com.maxnerva.cloudmes.service.datacenter.IDataCenterService;
import com.maxnerva.cloudmes.service.datacenter.model.PostShipmentDTO;
import com.maxnerva.cloudmes.service.datacenter.model.SelectGrInfoForFiiDTO;
import com.maxnerva.cloudmes.service.wh.model.SyncInventoryForFiiDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.stream.Collectors;

@Slf4j
@Service
public class DataCenterService implements IDataCenterService {

    @Autowired
    WmsDocReceiveMapper wmsDocReceiveMapper;

    @Autowired
    WmsJusdaReceiptMapper wmsJusdaReceiptMapper;

    @Autowired
    WmsSapWarehouseCodeMapper wmsSapWarehouseCodeMapper;

    @Autowired
    DataCenterConfig dataCenterConfig;

    @Autowired
    WmsPostFiiLogMapper wmsPostFiiLogMapper;

    @Autowired
    WmsPkgInfoMapper wmsPkgInfoMapper;

    @Autowired
    WmsProductShipHeaderMapper wmsProductShipHeaderMapper;

    @Autowired
    WmsProductShipDetailMapper wmsProductShipDetailMapper;

    @Autowired
    BasicMaterialMapper basicMaterialMapper;

    @Autowired
    WmsJusdaInventoryMapper wmsJusdaInventoryMapper;

    @Autowired
    WmsJusdaBuContrastMapper wmsJusdaBuContrastMapper;

    @Resource
    private WmsJusdaInventoryConfigMapper wmsJusdaInventoryConfigMapper;

    @Autowired
    JusdaUrlConfig jusdaUrlConfig;

    @Autowired
    WmsSapPlantMapper wmsSapPlantMapper;


    @Override
    public void syncShipInfoForFii(String orgCode, LocalDateTime localDateTime) {
        String site = dataCenterConfig.getSiteName();
        String businessUnitName = dataCenterConfig.getBusinessUnitName();
        String addUser = dataCenterConfig.getAddUser();
        Integer nowDay = localDateTime.getDayOfWeek().getValue();
        LocalDateTime beginDateTime = LocalDateTime.parse(localDateTime.plusDays(1 - nowDay).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + " 00:00:00", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        LocalDateTime endDateTime = LocalDateTime.parse(localDateTime.plusDays(8 - nowDay).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + " 00:00:00", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        List<PostShipmentDTO> result = ListUtil.toList();
        List<WmsDocProductShipHeader> shipHeaderList = wmsProductShipHeaderMapper.selectList(Wrappers.<WmsDocProductShipHeader>lambdaQuery()
                .eq(WmsDocProductShipHeader::getOrgCode, orgCode)
                .ge(WmsDocProductShipHeader::getPlanShipTime, beginDateTime)
                .lt(WmsDocProductShipHeader::getPlanShipTime, endDateTime)
                .eq(WmsDocProductShipHeader::getIsDeleted, Boolean.FALSE)
        );
        if (CollUtil.isEmpty(shipHeaderList)){
            return;
        }
        shipHeaderList.forEach(shipHeader -> {

            List<WmsDocProductShipDetail> shipDetailList = wmsProductShipDetailMapper.selectList(Wrappers.<WmsDocProductShipDetail>lambdaQuery()
                    .eq(WmsDocProductShipDetail::getOrgCode, orgCode)
                    .eq(WmsDocProductShipDetail::getIsDeleted, Boolean.FALSE)
                    .eq(WmsDocProductShipDetail::getHeaderId, shipHeader.getId())
            );

            shipDetailList.forEach(shipDetail -> {
                String customerName = basicMaterialMapper
                        .selectCustomerNameByMaterialNo(orgCode, shipHeader.getSapPlantCode(), shipDetail.getPartNo());

                PostShipmentDTO wmsShipmentInfo = new PostShipmentDTO();
                wmsShipmentInfo.setSite(site);
                wmsShipmentInfo.setBusinessUnitName(businessUnitName);
                wmsShipmentInfo.setCustomer(customerName);
                wmsShipmentInfo.setDeliverynotes(shipHeader.getDnNo());
                wmsShipmentInfo.setDeliverynotesItem(shipDetail.getDnItem());
                if (StrUtil.isBlank(wmsShipmentInfo.getDeliverynotesItem())){
                    wmsShipmentInfo.setDeliverynotesItem("000010");
                }
                wmsShipmentInfo.setModelName(shipDetail.getPartNo());
                wmsShipmentInfo.setModelRev(shipDetail.getPartVersion());
                wmsShipmentInfo.setPlannedQty(shipDetail.getPlanShipQty());
                wmsShipmentInfo.setPlannedShipmentDatetime(shipHeader.getPlanShipTime());
                wmsShipmentInfo.setShippedQuantity(shipDetail.getShipQty());
                wmsShipmentInfo.setAddUser(addUser);
                wmsShipmentInfo.setLasteditby(shipDetail.getLastEditor());
                ZoneOffset currentZoneOffset = OffsetDateTime.now().getOffset();
                ZoneId targetZoneOffset = ZoneId.ofOffset("UTC", ZoneOffset.of("+00:00"));
                if (ObjectUtil.isNotNull(shipDetail.getLastEditedDt())){
                    wmsShipmentInfo.setLasteditdt(LocalDateTime.ofEpochSecond(shipDetail.getLastEditedDt() / 1000, 0, currentZoneOffset));
                } else {
                    wmsShipmentInfo.setLasteditdt(localDateTime);
                }
                LocalDateTime utcLocalDateTime = wmsShipmentInfo.getLasteditdt().atZone(currentZoneOffset).withZoneSameInstant(targetZoneOffset).toLocalDateTime();
                wmsShipmentInfo.setLasteditdtUtc(utcLocalDateTime);

                wmsShipmentInfo.setUtcZone(String.valueOf(TimeZone.getDefault().getRawOffset() / 3600000));
                wmsShipmentInfo.setAddDate(localDateTime);
                wmsShipmentInfo.setAddDateUtc(localDateTime.atZone(currentZoneOffset).withZoneSameInstant(targetZoneOffset).toLocalDateTime());
                wmsShipmentInfo.setDataStatus("N");
                result.add(wmsShipmentInfo);
            });
        });
        HttpResponse response = postShipmentTo(result);

        JSONConfig jsonConfig = JSONConfig.create();
        jsonConfig.setDateFormat("yyyy-MM-dd HH:mm:ss");

        log.info("inventoryInfo res {}", response.body());
        WmsPostFiiLog wmsPostFiiLog = new WmsPostFiiLog();
        wmsPostFiiLog.setOrgCode(orgCode);
        wmsPostFiiLog.setPostType("SHIPMENT_INFO");
        Map<String, Object> queryContent = new HashMap();
        queryContent.put("site", site);
        queryContent.put("orgCode", orgCode);
        queryContent.put("localDateTime", localDateTime);
        wmsPostFiiLog.setQueryContent(JSONUtil.toJsonStr(queryContent, jsonConfig));
        wmsPostFiiLog.setRequestContent(JSONUtil.toJsonStr(result, jsonConfig));
        // 防止插入特殊字符报错
        String responseContent = StrUtil.isNotBlank(response.body()) ? response.body() : StrUtil.EMPTY;
        responseContent = StrUtil.replace(responseContent, "\u0000", "");
        wmsPostFiiLog.setResponseContent(responseContent);
        wmsPostFiiLog.setCreatedDt(localDateTime);
        wmsPostFiiLog.setCreator("WMS-JOB");
        wmsPostFiiLog.setLastEditedDt(localDateTime);
        wmsPostFiiLog.setLastEditor("WMS-JOB");

        if (response.getStatus() == 200){
            JSONObject jsonObject = JSONUtil.parseObj(response.body());
            if (jsonObject.getInt("code") == 200){
                wmsPostFiiLog.setStatus("Y");
            } else {
                wmsPostFiiLog.setStatus("N");
            }
        } else {
            wmsPostFiiLog.setStatus("N");
        }

        wmsPostFiiLogMapper.insert(wmsPostFiiLog);
    }

    private HttpResponse postShipmentTo(List<PostShipmentDTO> postShipmentInfoDTOList) {
        String url = dataCenterConfig.getShipmentUrl();
        String tokenKey = dataCenterConfig.getTokenKey();
        String token = dataCenterConfig.getToken();
        JSONConfig jsonConfig = JSONConfig.create();
        jsonConfig.setDateFormat("yyyy-MM-dd HH:mm:ss");
        return HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(60 * 1000 * 2)
                .header(tokenKey, token)
                .body(JSONUtil.toJsonStr(postShipmentInfoDTOList, jsonConfig))
                .execute();
    }

    @Override
    public void syncInventoryForFii(String orgCode, LocalDateTime localDateTime) {
        String site = dataCenterConfig.getSiteName();
        String businessUnitName = dataCenterConfig.getBusinessUnitName();
        String addUser = dataCenterConfig.getAddUser();
        List<WmsSapPlant> sapPlantList = wmsSapPlantMapper.selectList(Wrappers.<WmsSapPlant>lambdaQuery()
                .eq(WmsSapPlant::getOrgCode, orgCode)
        );
        List<SyncInventoryForFiiDTO> syncInventoryForFiiDTOList = wmsPkgInfoMapper.selectInventory(orgCode);
        List<WmsSapWarehouseCode> warehouseCodeList = wmsSapWarehouseCodeMapper.selectList(Wrappers.<WmsSapWarehouseCode>lambdaQuery()
                .select(WmsSapWarehouseCode::getWarehouseCode, WmsSapWarehouseCode::getMrpArea)
                .eq(WmsSapWarehouseCode::getOrgCode, orgCode)
                .last(String.format("and warehouse_code in (select warehouse_code from wms_inventory_age_warehouse_config where org_code = '%s')", orgCode))
        );
        // warehouseCode -> mrpArea
        Map<String, String> mrpAreaMap = warehouseCodeList.stream().collect(Collectors.toMap(k -> k.getWarehouseCode(), v -> ObjectUtil.isNull(v.getMrpArea()) ? StrUtil.EMPTY : v.getMrpArea(), (a, b) -> a));
        Map<String, SyncInventoryForFiiDTO> syncInventoryForFiiDTOMap = syncInventoryForFiiDTOList.stream()
                .collect(Collectors.toMap((SyncInventoryForFiiDTO k) -> StrUtil.concat(true, k.getOrgCode(), k.getPlantCode(), k.getPartNo(), k.getSupplierPartNo(), k.getMfgName(), k.getSapWarehouseCode()),
                        v -> v, (l, r) -> {
                            l.setCurrentQty(l.getCurrentQty().add(r.getCurrentQty()));
                            return l;
                        }));
        List<SyncInventoryForFiiDTO> result = syncInventoryForFiiDTOMap.values().stream().collect(Collectors.toList());
        result.forEach(item -> {
            String mrpArea = mrpAreaMap.get(item.getSapWarehouseCode());
            if (StrUtil.isNotBlank(mrpArea)){
                item.setMrpArea(mrpArea);
            } else {
                item.setMrpArea(StrUtil.EMPTY);
            }
            item.setDataSource("BU");
            item.setSite(site);
            if (ObjectUtil.isNull(item.getLastEditDt())){
                item.setLastEditDt(localDateTime);
            }

            ZoneOffset currentZoneOffset = OffsetDateTime.now().getOffset();
            ZoneId targetZoneOffset = ZoneId.ofOffset("UTC", ZoneOffset.of("+00:00"));
            LocalDateTime utcLocalDateTime = item.getLastEditDt().atZone(currentZoneOffset).withZoneSameInstant(targetZoneOffset).toLocalDateTime();
            item.setLastEditDtUtc(utcLocalDateTime);
            item.setUtcZone(String.valueOf(TimeZone.getDefault().getRawOffset() / 3600000));
            item.setAddDate(localDateTime);
            item.setAddDateUtc(localDateTime.atZone(currentZoneOffset).withZoneSameInstant(targetZoneOffset).toLocalDateTime());
            item.setDataStatus("N");
            item.setUnit("EA");
            item.setAddUser(addUser);
            item.setMaterialType(BooleanUtil.isTrue(item.getProductFlag()) ? "GOODS" : "MATERIAL");
            item.setOrgCode(businessUnitName);
        });

        sapPlantList.forEach(wmsSapPlant -> {
            List<SyncInventoryForFiiDTO> subInventoryList = getJusdaInventory(orgCode, wmsSapPlant.getFactoryCode(), localDateTime);
            result.addAll(subInventoryList);
        });

        HttpResponse response = postInventoryInfo(result);
        JSONConfig jsonConfig = JSONConfig.create();
        jsonConfig.setDateFormat("yyyy-MM-dd HH:mm:ss");

        log.info("inventoryInfo res {}", response.body());
        WmsPostFiiLog wmsPostFiiLog = new WmsPostFiiLog();
        wmsPostFiiLog.setOrgCode(orgCode);
        wmsPostFiiLog.setPostType("INVENTORY_INFO");
        Map<String, Object> queryContent = new HashMap();
        queryContent.put("site", site);
        queryContent.put("orgCode", orgCode);
        queryContent.put("localDateTime", localDateTime);
        wmsPostFiiLog.setQueryContent(JSONUtil.toJsonStr(queryContent, jsonConfig));
        wmsPostFiiLog.setRequestContent(JSONUtil.toJsonStr(result, jsonConfig));
        // 防止插入特殊字符报错
        String responseContent = StrUtil.isNotBlank(response.body()) ? response.body() : StrUtil.EMPTY;
        responseContent = StrUtil.replace(responseContent, "\u0000", "");
        wmsPostFiiLog.setResponseContent(responseContent);
        wmsPostFiiLog.setCreatedDt(localDateTime);
        wmsPostFiiLog.setCreator("WMS-JOB");
        wmsPostFiiLog.setLastEditedDt(localDateTime);
        wmsPostFiiLog.setLastEditor("WMS-JOB");

        if (response.getStatus() == 200){
            JSONObject jsonObject = JSONUtil.parseObj(response.body());
            if (jsonObject.getInt("code") == 200){
                wmsPostFiiLog.setStatus("Y");
            } else {
                wmsPostFiiLog.setStatus("N");
            }
        } else {
            wmsPostFiiLog.setStatus("N");
        }
        wmsPostFiiLogMapper.insert(wmsPostFiiLog);
    }

    private List<SyncInventoryForFiiDTO> getJusdaInventory(String orgCode, String plantCode, LocalDateTime localDateTime) {
        String site = dataCenterConfig.getSiteName();
        String businessUnitName = dataCenterConfig.getBusinessUnitName();
        String addUser = dataCenterConfig.getAddUser();
        List<WmsJusdaInventoryConfig> configList = wmsJusdaInventoryConfigMapper.selectList(Wrappers.<WmsJusdaInventoryConfig>lambdaQuery()
                .eq(WmsJusdaInventoryConfig::getOrgCode, orgCode)
                .eq(StringUtils.isNotBlank(plantCode), WmsJusdaInventoryConfig::getSapPlantCode, plantCode));

        List<WmsJusdaBuContrastEntity> wmsJusdaBuContrastList = wmsJusdaBuContrastMapper.selectList(Wrappers.<WmsJusdaBuContrastEntity>lambdaQuery()
                .eq(WmsJusdaBuContrastEntity::getOrgCode, orgCode)
                .eq(WmsJusdaBuContrastEntity::getPlantCode, plantCode)
        );
        Map<String, WmsJusdaBuContrastEntity> cmiWmsJusdaBuContrastEntityMap = wmsJusdaBuContrastList.stream().filter(item -> "CMI".equals(item.getDeliveryType())).collect(Collectors.toMap(k -> k.getCustomerName() + k.getSupplierName(), v -> v, (l, r) -> l));
        Map<String, WmsJusdaBuContrastEntity> vmiWmsJusdaBuContrastEntityMap = wmsJusdaBuContrastList.stream().filter(item -> "VMI".equals(item.getDeliveryType())).collect(Collectors.toMap(k -> k.getCustomerName(), v -> v, (l, r) -> l));

        List<SyncInventoryForFiiDTO> syncInventoryForFiiDTOList = ListUtil.toList();

        for (WmsJusdaInventoryConfig config : configList) {
            log.info("syncJusdaInventory：{}", config.getUserName());
            HttpRequest httpRequest = HttpRequest.post(jusdaUrlConfig.getJusdaInventoryUrl())
                    .header("Content-Type", "multipart/form-data;charset=UTF-8", true)
                    .setConnectionTimeout(300000)
                    .form("SiteName", config.getSiteName())
                    .form("UserName", config.getUserName())
                    .form("PassWord", config.getPassWord());
            HttpResponse response = httpRequest.execute();
            log.info("syncJusdaInventory：::url={},result={},current-time:{}", jusdaUrlConfig.getJusdaInventoryUrl(), response, System.currentTimeMillis());
            if (response.getStatus() == HttpStatus.HTTP_OK) {
                String body = response.body();
                JSONObject returnInfo = JSONUtil.parseObj(body);
                String isSuccess = returnInfo.getStr("IsSuccess");
                if (!"1".equals(isSuccess)) {
                    throw new RuntimeException("准时达库存查询失败");
                }
                String data = returnInfo.getStr("Data");
                List<Map<String, Object>> list = JSON.parseArray(data);
                // plantCode, mrpArea, sapWarehouseCode, partNo, supplierPartNo, mfgName, dataSource
                Map<String, SyncInventoryForFiiDTO> repeatMap = new HashMap();
                list.forEach(wmsJusdaInventory -> {
                    String customerName = ((String)wmsJusdaInventory.getOrDefault("CustomerName", StrUtil.EMPTY)).trim();
                    String customerSupplierNo = ((String)wmsJusdaInventory.getOrDefault("CustomerSupplierNo", StrUtil.EMPTY)).trim();
                    BigDecimal unknowQty = new BigDecimal(wmsJusdaInventory.getOrDefault("UnknownQty", BigDecimal.ZERO).toString());
                    BigDecimal goodQty = new BigDecimal(wmsJusdaInventory.getOrDefault("GOODQTY", BigDecimal.ZERO).toString());
                    BigDecimal defectQty = new BigDecimal(wmsJusdaInventory.getOrDefault("DefectQty", BigDecimal.ZERO).toString());
                    //库存数量
                    BigDecimal qty = unknowQty.add(goodQty).add(defectQty);
                    // 可用数量
                    BigDecimal hubInvQty = new BigDecimal(wmsJusdaInventory.getOrDefault("HubInvQty", BigDecimal.ZERO).toString());
                    WmsJusdaBuContrastEntity wmsJusdaBuContrast = cmiWmsJusdaBuContrastEntityMap.get(customerName + customerSupplierNo);
                    if (ObjectUtil.isNull(wmsJusdaBuContrast)){
                        wmsJusdaBuContrast = vmiWmsJusdaBuContrastEntityMap.get(customerName);
                    }
                    SyncInventoryForFiiDTO syncInventoryForFiiDTO = new SyncInventoryForFiiDTO();
                    syncInventoryForFiiDTO.setSite(site);
                    syncInventoryForFiiDTO.setOrgCode(businessUnitName);
                    syncInventoryForFiiDTO.setPlantCode(plantCode);
                    syncInventoryForFiiDTO.setPartNo(((String)wmsJusdaInventory.getOrDefault("CustomerPartNo", StrUtil.EMPTY)).trim());
                    syncInventoryForFiiDTO.setSupplierPartNo(((String)wmsJusdaInventory.getOrDefault("SupplierPartNo", StrUtil.EMPTY)).trim());
                    syncInventoryForFiiDTO.setMfgName(((String)wmsJusdaInventory.getOrDefault("ManufactureName", StrUtil.EMPTY)).trim());
                    syncInventoryForFiiDTO.setUnit(((String)wmsJusdaInventory.getOrDefault("UOM", StrUtil.EMPTY)).trim());
                    if (ObjectUtil.isNotNull(wmsJusdaBuContrast)){
                        syncInventoryForFiiDTO.setMrpArea(wmsJusdaBuContrast.getMrpArea());
                        syncInventoryForFiiDTO.setSapWarehouseCode(wmsJusdaBuContrast.getTransferTo());
                        if ("VMI".equals(wmsJusdaBuContrast.getDeliveryType())){
                            syncInventoryForFiiDTO.setCurrentQty(hubInvQty);
                            syncInventoryForFiiDTO.setDataSource("VMI");
                        } else if ("CMI".equals(wmsJusdaBuContrast.getDeliveryType())){
                            syncInventoryForFiiDTO.setCurrentQty(qty);
                            syncInventoryForFiiDTO.setDataSource("CMI");
                        }
                    }
                    // plantCode, mrpArea, sapWarehouseCode, partNo, supplierPartNo, mfgName, dataSource
                    String repeatKey = StrUtil.concat(true, syncInventoryForFiiDTO.getPlantCode(), syncInventoryForFiiDTO.getMrpArea(), syncInventoryForFiiDTO.getSapWarehouseCode(),
                            syncInventoryForFiiDTO.getPartNo(), syncInventoryForFiiDTO.getSupplierPartNo(), syncInventoryForFiiDTO.getMfgName(), syncInventoryForFiiDTO.getDataSource());
                    // 同时存在保税，非保税。数量累加到一起
                    if (repeatMap.containsKey(repeatKey)){
                        SyncInventoryForFiiDTO actualSyncInventoryForFiiDTO = repeatMap.get(repeatKey);
                        actualSyncInventoryForFiiDTO.setCurrentQty(actualSyncInventoryForFiiDTO.getCurrentQty().add(syncInventoryForFiiDTO.getCurrentQty()));
                        return;
                    } else {
                        repeatMap.put(repeatKey, syncInventoryForFiiDTO);
                    }

                    syncInventoryForFiiDTO.setLastEditBy("WMS-JOB");
                    syncInventoryForFiiDTO.setLastEditDt(localDateTime);

                    ZoneOffset currentZoneOffset = OffsetDateTime.now().getOffset();
                    ZoneId targetZoneOffset = ZoneId.ofOffset("UTC", ZoneOffset.of("+00:00"));
                    LocalDateTime utcLocalDateTime = syncInventoryForFiiDTO.getLastEditDt().atZone(currentZoneOffset).withZoneSameInstant(targetZoneOffset).toLocalDateTime();
                    syncInventoryForFiiDTO.setLastEditDtUtc(utcLocalDateTime);
                    syncInventoryForFiiDTO.setUtcZone(String.valueOf(TimeZone.getDefault().getRawOffset() / 3600000));
                    syncInventoryForFiiDTO.setAddDate(localDateTime);
                    syncInventoryForFiiDTO.setAddDateUtc(localDateTime.atZone(currentZoneOffset).withZoneSameInstant(targetZoneOffset).toLocalDateTime());
                    syncInventoryForFiiDTO.setDataStatus("N");
                    syncInventoryForFiiDTO.setAddUser(addUser);
                    syncInventoryForFiiDTOList.add(syncInventoryForFiiDTO);
                });
            } else {
                throw new RuntimeException("准时达库存查询失败");
            }
        }
        int num = 1000;
        double total = Math.ceil((double) syncInventoryForFiiDTOList.size() / (double) num);
        for(int i = 0; i < total; i++){
            int start = i * num;
            int end = (i + 1) * num;
            end = end < syncInventoryForFiiDTOList.size() ? end : syncInventoryForFiiDTOList.size();
            List<SyncInventoryForFiiDTO> batchList = syncInventoryForFiiDTOList.subList(start, end);
            List<GetProductFlagDTO> getProductFlagDTOList = basicMaterialMapper.getProductFlag(batchList);
            batchList.forEach(item -> {
                GetProductFlagDTO getProductFlagDTO = getProductFlagDTOList.stream()
                        .filter(it -> item.getOrgCode().equals(it.getOrgCode()) && item.getPlantCode().equals(it.getPlantCode()) && item.getPartNo().equals(it.getMaterialNo()))
                        .findFirst().orElse(null);
                if (ObjectUtil.isNotNull(getProductFlagDTO)){
                    item.setMaterialType(BooleanUtil.isTrue(getProductFlagDTO.getProductFlag()) ? "GOODS" : "MATERIAL");
                }
            });
        }
        return syncInventoryForFiiDTOList;
    }

    private HttpResponse postInventoryInfo(List<SyncInventoryForFiiDTO> syncInventoryForFiiDTOS) {
        String url = dataCenterConfig.getInventoryInfoUrl();
        String tokenKey = dataCenterConfig.getTokenKey();
        String token = dataCenterConfig.getToken();
        JSONConfig jsonConfig = JSONConfig.create();
        jsonConfig.setDateFormat("yyyy-MM-dd HH:mm:ss");

        return HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(60 * 1000 * 2)
                .header(tokenKey, token)
                .body(JSONUtil.toJsonStr(syncInventoryForFiiDTOS, jsonConfig))
                .execute();
    }


    @Override
    public WmsPostFiiLog syncGrInfoForFii(String orgCode, LocalDateTime localDateTime, LocalDateTime beginDateTime, LocalDateTime endDateTime) {
        String site = dataCenterConfig.getSiteName();
        String businessUnitName = dataCenterConfig.getBusinessUnitName();
        String addUser = dataCenterConfig.getAddUser();
        // 左闭右开
        List<SelectGrInfoForFiiDTO> result = wmsDocReceiveMapper.selectGrInfoForFii(orgCode, beginDateTime, endDateTime);
        List<WmsSapWarehouseCode> warehouseCodeList = wmsSapWarehouseCodeMapper.selectList(Wrappers.<WmsSapWarehouseCode>lambdaQuery()
                .select(WmsSapWarehouseCode::getWarehouseCode, WmsSapWarehouseCode::getMrpArea)
                .eq(WmsSapWarehouseCode::getOrgCode, orgCode)
                .last(String.format("and warehouse_code in (select warehouse_code from wms_inventory_age_warehouse_config where org_code = '%s')", orgCode))
        );
        // warehouseCode -> mrpArea
        Map<String, String> mrpAreaMap = warehouseCodeList.stream().collect(Collectors.toMap(k -> k.getWarehouseCode(), v -> ObjectUtil.isNull(v.getMrpArea()) ? StrUtil.EMPTY : v.getMrpArea(), (a, b) -> a));
        result.forEach(item -> {
            String mrpArea = mrpAreaMap.get(item.getSapWarehouseCode());
            if (StrUtil.isNotBlank(mrpArea)){
                item.setMrpArea(mrpArea);
            }
            item.setSite(site);
            if (ObjectUtil.isNull(item.getLastEditDt())){
                item.setLastEditDt(localDateTime);
            }
            ZoneOffset currentZoneOffset = OffsetDateTime.now().getOffset();
            ZoneId targetZoneOffset = ZoneId.ofOffset("UTC", ZoneOffset.of("+00:00"));
            LocalDateTime utcLocalDateTime = item.getLastEditDt().atZone(currentZoneOffset).withZoneSameInstant(targetZoneOffset).toLocalDateTime();
            item.setLastEditDtUtc(utcLocalDateTime);
            item.setUtcZone(String.valueOf(TimeZone.getDefault().getRawOffset() / 3600000));

            item.setAddDate(localDateTime);
            item.setAddDateUtc(localDateTime.atZone(currentZoneOffset).withZoneSameInstant(targetZoneOffset).toLocalDateTime());
            item.setDataStatus("N");
            item.setAddUser(addUser);
            item.setOrgCode(businessUnitName);
        });
        HttpResponse response = postGrInfo(result);
        JSONConfig jsonConfig = JSONConfig.create();
        jsonConfig.setDateFormat("yyyy-MM-dd HH:mm:ss");

        log.info("inventoryInfo res {}", response.body());
        WmsPostFiiLog wmsPostFiiLog = new WmsPostFiiLog();
        wmsPostFiiLog.setOrgCode(orgCode);
        wmsPostFiiLog.setPostType("GR_INFO");
        Map<String, Object> queryContent = new HashMap();
        queryContent.put("site", site);
        queryContent.put("orgCode", orgCode);
        queryContent.put("localDateTime", localDateTime);
        queryContent.put("beginDateTime", beginDateTime);
        queryContent.put("endDateTime", endDateTime);
        wmsPostFiiLog.setQueryContent(JSONUtil.toJsonStr(queryContent, jsonConfig));
        wmsPostFiiLog.setRequestContent(JSONUtil.toJsonStr(result, jsonConfig));
        // 防止插入特殊字符报错
        String responseContent = StrUtil.isNotBlank(response.body()) ? response.body() : StrUtil.EMPTY;
        responseContent = StrUtil.replace(responseContent, "\u0000", "");
        wmsPostFiiLog.setResponseContent(responseContent);
        wmsPostFiiLog.setCreatedDt(localDateTime);
        wmsPostFiiLog.setCreator("WMS-JOB");
        wmsPostFiiLog.setLastEditedDt(localDateTime);
        wmsPostFiiLog.setLastEditor("WMS-JOB");

        if (response.getStatus() == 200){
            JSONObject jsonObject = JSONUtil.parseObj(response.body());
            if (jsonObject.getInt("code") == 200){
                wmsPostFiiLog.setStatus("Y");
            } else {
                wmsPostFiiLog.setStatus("N");
            }
        } else {
            wmsPostFiiLog.setStatus("N");
        }

        wmsPostFiiLogMapper.insert(wmsPostFiiLog);
        return wmsPostFiiLog;
    }

    private HttpResponse postGrInfo(List<SelectGrInfoForFiiDTO> result) {
        String url = dataCenterConfig.getGrInfoUrl();
        String tokenKey = dataCenterConfig.getTokenKey();
        String token = dataCenterConfig.getToken();
        JSONConfig jsonConfig = JSONConfig.create();
        jsonConfig.setDateFormat("yyyy-MM-dd HH:mm:ss");

        return HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(60 * 1000 * 2)
                .header(tokenKey, token)
                .body(JSONUtil.toJsonStr(result, jsonConfig))
                .execute();
    }
}
