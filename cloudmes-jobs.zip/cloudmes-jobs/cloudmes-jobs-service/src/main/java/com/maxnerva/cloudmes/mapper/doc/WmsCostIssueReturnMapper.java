package com.maxnerva.cloudmes.mapper.doc;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.doc.WmsCostIssueReturnHeader;


public interface WmsCostIssueReturnMapper extends BaseMapper<WmsCostIssueReturnHeader> {

}
