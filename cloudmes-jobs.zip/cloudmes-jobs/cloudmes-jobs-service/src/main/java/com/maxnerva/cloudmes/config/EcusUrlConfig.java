package com.maxnerva.cloudmes.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import java.util.List;

@RefreshScope
@Component
@Data
public class EcusUrlConfig {

    @Value("${ecus.cus-url:}")
    private String cusUrl;

    @Value("${ecus.cus-p_cnn.bonded:}")
    private String cusBoundCnn;

    @Value("${ecus.cus-p_cnn.non-bonded:}")
    private String cusNonBoundCnn;
}
