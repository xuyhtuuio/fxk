package com.maxnerva.cloudmes.service.wo.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Author hgx
 * @Description
 * @Date 2023/9/5
 */
@Data
@ApiModel("从MES查询烧录清单vo")
public class GetBurnValueVO {

    @ApiModelProperty("成品料号")
    private String finishedProductPartNo;

    @ApiModelProperty("orgCode")
    private String orgCode;
}
