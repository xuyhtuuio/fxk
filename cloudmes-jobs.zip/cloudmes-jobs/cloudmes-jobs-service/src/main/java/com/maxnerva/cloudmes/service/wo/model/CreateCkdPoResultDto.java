package com.maxnerva.cloudmes.service.wo.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @author H7109018
 */
@Data
public class CreateCkdPoResultDto implements Serializable {

    private static final long serialVersionUID = -1L;

    private int code;

    private String po1Number;

    private String po2Number;

    private String message;


}
