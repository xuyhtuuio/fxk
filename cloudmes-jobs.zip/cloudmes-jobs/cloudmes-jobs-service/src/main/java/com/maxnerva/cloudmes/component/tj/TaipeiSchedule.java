package com.maxnerva.cloudmes.component.tj;

import com.maxnerva.cloudmes.service.basic.PostingConfigService;
import com.maxnerva.cloudmes.service.doc.CostDocPostingService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * @author H7109018
 */
@ConditionalOnProperty(value = "cope.code", havingValue = "F_TJ")
@Component
@EnableScheduling
@Slf4j
public class TaipeiSchedule {

    private static final String ORG_CODE = "Taipei";
    private static final String SAP_CLIENT_CODE = "sap";
    private static final String DATE_FORMAT = "yyyyMMdd";
    private static String postDate = "N";

    @Autowired
    CostDocPostingService costDocPostingService;

    @Autowired
    PostingConfigService postingConfigService;

    /**
     * 修改过账时间
     * 频率：10分钟执行一次
     */
    @Scheduled(initialDelay = 5000, fixedDelay = 300000)
    public void updatePostDate() {
        String s = postingConfigService.getPostDate(ORG_CODE, null);
        postDate = s;
    }


    /**
     * 费领退及报废单过账SAP
     * 频率：5分钟执行一次
     */
    @Scheduled(initialDelay = 36000, fixedDelay = 600000)
    public void costDocPostingService() {
        log.info("costWSDDocPostingService start :" + System.currentTimeMillis());
        costDocPostingService.costDocTransferPosting(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("costWSDDocPostingService end :" + System.currentTimeMillis());
    }


}
