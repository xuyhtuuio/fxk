package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.TableId;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 单据类型表
 * </p>
 *
 * @author likun
 * @since 2022-07-25
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value = "WmsDocType对象", description = "单据类型表")
public class WmsDocType extends BaseEntity<WmsDocType> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    @TableId
    private Integer id;

    @ApiModelProperty(value = "属性编码")
    private String docTypeCode;

    @ApiModelProperty(value = "类型名称")
    private String docTypeName;

    @ApiModelProperty(value = "描述")
    private String description;

    @ApiModelProperty(value = "是否可用（0-否，1-是）默认0")
    private Boolean isEnable;

    @ApiModelProperty(value = "检验标识,是否抛转qms（Y-已检验，N-未检验）")
    private String postingQmsFlag;

    @ApiModelProperty(value = "抛转数据到qms的url地址")
    private String postingQmsUrl;

    @ApiModelProperty(value = "过账sap标识,是否抛转sap（Y-已检验，N-未检验）")
    private String postingSapFlag;

    @ApiModelProperty(value = "过账方法名称")
    private String postingMethodName;

    @ApiModelProperty(value = "物料操作类型")
    private String materialOperateType;

    @ApiModelProperty(value = "交易方向")
    private String tradeDirection;

    @ApiModelProperty(value = "BU(业务单元)")
    private String orgCode;

    @ApiModelProperty(value = "单据大类编码")
    private String docCategoryCode;
}
