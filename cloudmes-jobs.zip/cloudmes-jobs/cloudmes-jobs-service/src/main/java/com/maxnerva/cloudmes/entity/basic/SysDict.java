package com.maxnerva.cloudmes.entity.basic;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import lombok.Data;

/**
 * 数据字典表(SysDict)实体类
 *
 * @author hgx
 * @since 2023-11-21 13:36:04
 */

@ApiModel("数据字典表(SysDict)实体类")
@Data
public class SysDict {
 
/**
     * 自增主键
     */
    private Integer id;
/**
     * 字典类型
     */
    private String dictType;
/**
     * 字典编码
     */
    private String dictCode;
/**
     * 字典名称
     */
    private String dictName;
/**
     * 排序字段
     */
    private Integer sortNo;
/**
     * 字典描述
     */
    private String dictDesc;
/**
     * 字典英文名称
     */
    private String dictEnName;
/**
     * 字典中文繁体名称
     */
    private String dictTwName;
/**
     * 字典中文简体名称
     */
    private String dictZhName;
/**
     * 创建员工code
     */
    private String creator;
/**
     * 创建员工id
     */
    private Integer creatorId;
/**
     * 创建时间
     */
    private Long createdDt;
/**
     * 修改员工code
     */
    private String lastEditor;
/**
     * 修改员工id
     */
    private Integer lastEditorId;
/**
     * 修改时间
     */
    private Long lastEditedDt;

    private Boolean isDeleted;
    }

