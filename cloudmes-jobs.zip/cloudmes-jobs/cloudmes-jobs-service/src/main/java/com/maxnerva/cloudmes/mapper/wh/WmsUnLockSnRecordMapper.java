package com.maxnerva.cloudmes.mapper.wh;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.wh.WmsUnLockSnRecord;

/**
 * <p>
 * mes通知解锁sn记录表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2024-08-07
 */
public interface WmsUnLockSnRecordMapper extends BaseMapper<WmsUnLockSnRecord> {

}
