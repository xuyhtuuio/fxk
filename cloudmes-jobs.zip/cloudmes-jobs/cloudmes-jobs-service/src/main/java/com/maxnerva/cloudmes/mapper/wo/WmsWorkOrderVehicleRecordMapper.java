package com.maxnerva.cloudmes.mapper.wo;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderVehicleRecord;
import org.apache.ibatis.annotations.Insert;

/**
 * <p>
 * 工单绑定载具记录表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2022-09-03
 */
public interface WmsWorkOrderVehicleRecordMapper extends BaseMapper<WmsWorkOrderVehicleRecord> {

    @Insert("insert into wms_work_order_vehicle_record(work_order_no, work_order_to_location, vehicle_code,creator," +
            "created_dt,last_editor) values (#{workOrderNo},#{workOrderToLocation},#{vehicleCode},#{creator},now(),#{lastEditor}}) " +
            "on conflict(work_order_no, work_order_to_location)  do update set vehicle_code = excluded.vehicle_code," +
            "last_editor = excluded.last_editor,last_edited_dt = now()")
    int saveOrderVehicleRecord(WmsWorkOrderVehicleRecord wmsWorkOrderVehicleRecord);
}
