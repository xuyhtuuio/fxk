package com.maxnerva.cloudmes.controller;

import com.maxnerva.cloudmes.service.mes.PostingMesService;
import com.maxnerva.cloudmes.service.mes.model.MesGetWoPreparePkgInfoVO;
import com.maxnerva.cloudmes.service.mes.model.MesSyncPkgInfoVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @ClassName MesController
 * @Description 对接mes接口
 * @Author Likun
 * @Date 2023/2/22
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "对接mes接口")
@Slf4j
@RestController
@RequestMapping("/mes")
public class MesController {

    @Autowired
    PostingMesService postingMesService;

    private static final String ORG_CODE = "EPDVI";

/*    *//**
     * 工单备料PKG信息抛Mes
     * 频率：10分钟执行一次
     *//*
    @ApiOperation("工单备料PKG信息抛Mes")
    @GetMapping("/postingWoPreparePkgInfoToMes")
    public void postingWoPreparePkgInfoToMes() {
        log.info("postingWoPreparePkgInfoToMes start :" + System.currentTimeMillis());
        postingMesService.postingWoPreparePkgInfoToMes(ORG_CODE, "");
        log.info("postingWoPreparePkgInfoToMes end:" + System.currentTimeMillis());
    }*/

    /**
     * 工单备料PKG信息抛Mes
     * 频率：10分钟执行一次
     */
    @ApiOperation("工单备料PKG信息抛Mes")
    @PostMapping("/mesGetWoPreparePkgInfo")
    public void mesGetWoPreparePkgInfo(@RequestBody MesGetWoPreparePkgInfoVO vo) {
        log.info("mesGetWoPreparePkgInfo start :" + System.currentTimeMillis());
        String orgCode = vo.getOrgCode();
        String pkgId = vo.getPkgId();
        postingMesService.postingPreparePkgInfoToMes(orgCode, pkgId);
        log.info("mesGetWoPreparePkgInfo end:" + System.currentTimeMillis());
    }

    @ApiOperation("PKG信息抛Mes")
    @PostMapping("/postingPkgInfoToMes")
    public void postingPkgInfoToMes(@RequestBody MesSyncPkgInfoVO mesSyncPkgInfoVO) {
        log.info("postingPkgInfoToMes start :" + System.currentTimeMillis());
        String orgCode = mesSyncPkgInfoVO.getOrgCode();
        String pkgId = mesSyncPkgInfoVO.getPkgId();
        postingMesService.postingPkgInfoToMes(orgCode, pkgId);
        log.info("postingPkgInfoToMes end:" + System.currentTimeMillis());
    }

    @ApiOperation("抛转po sn信息到mes")
    @GetMapping("/postPoSnDataToMes")
    public void postPoSnDataToMes() {
        log.info("postPoSnDataToMes start :" + System.currentTimeMillis());
        postingMesService.postPoSnDataToMes("LX");
        log.info("postPoSnDataToMes end:" + System.currentTimeMillis());
    }
}
