package com.maxnerva.cloudmes.service.sap.po.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @ClassName TransferOutsourcingDto
 * @Description 委外确认过账dto
 * @Author Likun
 * @Date 2023/12/4
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("委外确认过账dto")
@Data
public class TransferOutsourcingDto {


    @ApiModelProperty("转仓日期")
    private String transactionDate;

    @ApiModelProperty("doc 日期")
    private String docDate;

    @ApiModelProperty("说明")
    private String refDocNo;

    /**
     * 541
     */
    @ApiModelProperty("过账类型")
    private String moveType;

    /**
     * 工厂
     */
    @ApiModelProperty("工厂")
    private String plantCode;

    /**
     * 仓码
     */
    @ApiModelProperty("仓码")
    private String warehouseCode;

    /**
     * 料号
     */
    @ApiModelProperty("料号")
    private String partNo;

    /**
     * 料号版次
     */
    @ApiModelProperty("料号版次")
    private String partNoVersion;

    /**
     * 供应商
     */
    @ApiModelProperty("供应商")
    private String vendorCode;

    /**
     * 数量
     */
    @ApiModelProperty("数量")
    private String qty;

    /**
     * 单位
     */
    @ApiModelProperty("单位")
    private String bom;

    @ApiModelProperty("po号")
    private String poNo;

    @ApiModelProperty("po群组")
    private String poItem;
}
