package com.maxnerva.cloudmes.service.datahub.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2024-01-19
 */
@Data
@ApiModel("WmsWorkOrderPrepareCkdShipHeaderDTO")
public class WmsWorkOrderPrepareCkdShipHeaderDTO {

    private Integer id;

    @ApiModelProperty(value = "流水码")
    private String serialNo;

    @ApiModelProperty(value = "工单")
    private String workOrderNo;

    private String orgCode;

    private String plantCode;

    private String poNo1;

    private String poNo2;

    private String soNo;

    private String dnNo;

    @ApiModelProperty(value = "出货地")
    private String siteCode;

    @ApiModelProperty(value = "创建PO未抛：0，已抛：1")
    private String poPostSapFlag;

    @ApiModelProperty(value = "创建DN、SO未抛：0，已抛：1")
    private String dnPostSapFlag;

    @ApiModelProperty(value = "同步收货单未同步：0，已同步：1")
    private String syncReceiveDocFlag;
}
