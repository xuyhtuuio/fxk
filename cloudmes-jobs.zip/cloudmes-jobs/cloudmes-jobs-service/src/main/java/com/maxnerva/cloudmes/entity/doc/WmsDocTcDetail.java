package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2024-08-16
 */
@TableName("wms_doc_tc_detail")
@ApiModel(value = "WmsDocTcDetail对象", description = "")
@Data
public class WmsDocTcDetail extends BaseEntity<WmsDocTcDetail> {

    private static final long serialVersionUID = 1L;

    private Integer id;

    @ApiModelProperty("工厂组织")
    private String orgCode;

    @ApiModelProperty("工厂")
    private String plantCode;

    @ApiModelProperty("条码")
    private String pkgId;

    @ApiModelProperty("特采单号")
    private String docNo;

    @ApiModelProperty(value = "GR单号")
    private String grNo;

    @ApiModelProperty(value = "入库单号")
    private String wmsNo;

    @ApiModelProperty(value = "厂商名")
    private String mfgName;

    @ApiModelProperty(value = "厂商料号")
    private String supplierPartNo;

    @ApiModelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "数量")
    private BigDecimal qty;

    @ApiModelProperty(value = "DC")
    private String originalDateCode;

    @ApiModelProperty(value = "LOT")
    private String lotCode;

    @ApiModelProperty("到期日")
    @JsonFormat(pattern="yyyy-MM-dd")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate endDate;

    @ApiModelProperty(value = "物料描述")
    private String materialDesc;

    @ApiModelProperty(value = "物料分类")
    private String classCode;
}
