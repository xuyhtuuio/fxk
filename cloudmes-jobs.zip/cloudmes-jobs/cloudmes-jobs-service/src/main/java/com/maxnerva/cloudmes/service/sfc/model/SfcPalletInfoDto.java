package com.maxnerva.cloudmes.service.sfc.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * SFC 栈板信息
 *
 * @author sclq
 * @date 2022/9/6 9:44
 */
@Data
public class SfcPalletInfoDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * ORG_CODE
     */
    @ApiModelProperty(value = "ORG_CODE")
    private String orgCode;

    /**
     * 工单号
     */
    @ApiModelProperty(value = "工单号")
    private String workerOrderNo;


    /**
     * 当前工站
     */
    @ApiModelProperty(value = "当前工站")
    private String currentStation;


    /**
     * 成品料号
     */
    @ApiModelProperty(value = "成品料号")
    private String productPartNo;

    /**
     * 成品料号版次
     */
    @ApiModelProperty(value = "成品料号版次")
    private String productPartNoVersion;

    /**
     * 栈板号
     */
    @ApiModelProperty(value = "栈板号")
    private String palletNo;

    /**
     * 栈板数量
     */
    @ApiModelProperty(value = "栈板数量")
    private BigDecimal palletQty;

    /**
     * 箱
     */
    @ApiModelProperty(value = "箱")
    private String cartonNo;

    /**
     * SN
     */
    @ApiModelProperty(value = "SN")
    private String snNo;

    /**
     * SN数量
     */
    @ApiModelProperty(value = "SN数量")
    private BigDecimal snQty;

    @ApiModelProperty("产品系列")
    private String productSerial;

    @ApiModelProperty("客户料号")
    private String ipn;

    @ApiModelProperty("ASSET ID")
    private String assetId;

    @ApiModelProperty("产品类别")
    private String productCategory;

    @ApiModelProperty("锁定状态 0--正常；1--已锁定")
    private Integer lockStatus = 0;

    @ApiModelProperty("锁定原因")
    private String lockReason;

    @ApiModelProperty("SI号")
    private String siNo;

    @ApiModelProperty("po号")
    private String poNo;

    @ApiModelProperty("客户SN")
    private String customerSn;
}
