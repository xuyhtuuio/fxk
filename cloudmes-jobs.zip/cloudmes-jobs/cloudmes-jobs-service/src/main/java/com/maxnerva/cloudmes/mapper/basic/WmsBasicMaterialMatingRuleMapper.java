package com.maxnerva.cloudmes.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.basic.WmsBasicMaterialMatingRule;

/**
 * <p>
 * 物料配套使用规则 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2024-12-23
 */
public interface WmsBasicMaterialMatingRuleMapper extends BaseMapper<WmsBasicMaterialMatingRule> {

}
