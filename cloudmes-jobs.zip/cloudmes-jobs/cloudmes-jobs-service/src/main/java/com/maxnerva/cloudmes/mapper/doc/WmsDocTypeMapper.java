package com.maxnerva.cloudmes.mapper.doc;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.doc.WmsDocType;

/**
 * <p>
 * 单据类型表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2022-07-25
 */
public interface WmsDocTypeMapper extends BaseMapper<WmsDocType> {

}
