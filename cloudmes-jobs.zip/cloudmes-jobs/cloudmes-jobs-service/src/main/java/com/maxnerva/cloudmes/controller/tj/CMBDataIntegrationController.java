package com.maxnerva.cloudmes.controller.tj;

import cn.hutool.core.date.DateUtil;
import com.maxnerva.cloudmes.common.response.Result;
import com.maxnerva.cloudmes.service.basic.PostingConfigService;
import com.maxnerva.cloudmes.service.doc.*;
import com.maxnerva.cloudmes.service.wo.WorkOrderService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.time.LocalDateTime;

/**
 * @author H7109018
 */
@Api(tags = "CMB数据集成调用接口")
@Slf4j
@RestController
@RequestMapping("/cmbDataIntegration")
public class CMBDataIntegrationController {

    private static final String ORG_CODE = "CMB";
    private static final String SAP_CLIENT_CODE = "sap";
    private static final String DATE_FORMAT = "yyyyMMdd";
    private static String postDate = "N";

    @Autowired
    CostDocPostingService costDocPostingService;

    @Autowired
    PostingConfigService postingConfigService;

    @Autowired
    ReceiveDocPostingService docPostingService;

    @Autowired
    DocJitReceiveRecordService jitDocService;

    @Autowired
    WorkOrderService workOrderService;

    @Autowired
    TradingDocService tradingDocService;

    @Resource
    IWmsDocJitReceiveGrRecordService wmsDocJitReceiveGrRecordService;

    /**
     * 修改过账时间
     * 频率：10分钟执行一次
     */
    @ApiOperation("修改过账时间")
    @GetMapping("/updatePostDate")
    public void updatePostDate() {
        String s = postingConfigService.getPostDate(ORG_CODE, null);
        postDate = s;
        log.info(">>>>>>>>>CMB过账时间:{}",postDate);
    }

    /**
     * 同步SAP workOrder header info,
     * 频率：60分钟执行一次
     */
    @ApiOperation("同步SAP workOrder header info")
    @GetMapping("/syncSapWorkOrderHeader")
    public Result syncSapWorkOrderHeader() {
        log.info(" syncSapWorkOrderHeader start :" + System.currentTimeMillis());
        String startDate = DateUtil.format(LocalDateTime.now().plusDays(-3), DATE_FORMAT);
        String endDate = DateUtil.format(LocalDateTime.now().plusDays(2), DATE_FORMAT);
        workOrderService.syncSapWorkOrderHeader(ORG_CODE, startDate, endDate);
        log.info(" syncSapWorkOrderHeader end :" + System.currentTimeMillis());
        return Result.success();
    }

    /**
     * 同步SAP workOrder detail info,
     * 频率：30分钟执行一次
     */
    @ApiOperation("同步SAP workOrder detail info")
    @GetMapping("/syncSapWorkOrderDetail")
    public void syncSapWorkOrderDetail() {
        log.info("syncSapWorkOrderDetail " + ORG_CODE + "start :" + System.currentTimeMillis());
        workOrderService.syncSapWorkOrderDetail(ORG_CODE, null, SAP_CLIENT_CODE);
        log.info("syncSapWorkOrderDetail " + ORG_CODE + "end :" + System.currentTimeMillis());
    }

    /**
     * 收货确认并上架完成后，收货单抛QMS
     * 频率：5分钟执行一次
     */
    @ApiOperation("收货确认并上架完成后，收货单抛QMS")
    @GetMapping("/docReceivePostQms")
    public void docReceivePostQms() {
        log.info("docReceivePostQms start :" + System.currentTimeMillis());
        docPostingService.docReceivePostQms(ORG_CODE, null);
        log.info("docReceivePostQms end :" + System.currentTimeMillis());
    }

    /**
     *
     * 从SAP产生JIT收货单
     *
     */
    @ApiOperation("从SAP产生JIT收货单")
    @GetMapping("/syncJitDoc")
    public void syncJitDoc() {
        log.info("syncJitDoc start :" + System.currentTimeMillis());
        String date = DateUtil.format(LocalDateTime.now(), DATE_FORMAT);
        jitDocService.syncJitDoc(SAP_CLIENT_CODE,ORG_CODE,date,date,"");
        log.info("syncJitDoc end :" + System.currentTimeMillis());
    }

    /**
     *
     * 根据gr信息产生委外-包材入库
     *
     */
    @ApiOperation("委外入库")
    @GetMapping("/outsourcingReceive")
    public void outsourcingReceive() {
        log.info("outsourcingReceive start :" + System.currentTimeMillis());
        String date = DateUtil.format(LocalDateTime.now(), DATE_FORMAT);
        tradingDocService.outsourcingReceive(SAP_CLIENT_CODE,ORG_CODE,date,date);
        log.info("outsourcingReceive end :" + System.currentTimeMillis());
    }

    /**
     *产生包材入库
     */
    @Deprecated
    @ApiOperation("包材入库")
    @GetMapping("/pnReceive")
    // 2025-04-21 停止节点
    public void pnReceive() {
        log.info("pnReceive start :" + System.currentTimeMillis());
        String startDate = DateUtil.format(LocalDateTime.now(), DATE_FORMAT);
        String endDate = DateUtil.format(LocalDateTime.now().plusDays(1), DATE_FORMAT);
        tradingDocService.pnReceive(SAP_CLIENT_CODE,ORG_CODE,startDate,endDate);
        log.info("pnReceive end :" + System.currentTimeMillis());
    }


    /**
     *
     * 机构产生JIT收货单
     *
     */
    @ApiOperation("机构产生JIT收货单")
    @GetMapping("/createJitDocReceive")
    public void createJitDocReceive() {
        log.info("createJitDocReceive start :" + System.currentTimeMillis());
        wmsDocJitReceiveGrRecordService.createJitDocReceive(SAP_CLIENT_CODE,ORG_CODE);
        log.info("createJitDocReceive end :" + System.currentTimeMillis());
    }
}
