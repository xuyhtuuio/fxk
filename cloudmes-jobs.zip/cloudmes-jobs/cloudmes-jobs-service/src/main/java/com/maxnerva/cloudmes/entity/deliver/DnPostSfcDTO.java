package com.maxnerva.cloudmes.entity.deliver;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName DnPostSfcDTO
 * @Description TODO
 * @Author Likun
 * @Date 2024/11/14
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("货柜dn抛sfc查询dto")
@Data
public class DnPostSfcDTO {

    @ApiModelProperty("id")
    private Integer id;

    @ApiModelProperty("dn")
    private String dn;

    @ApiModelProperty("po")
    private String po;

    @ApiModelProperty("運輸方式")
    private String shippingMethod;

    @ApiModelProperty("貨車類型")
    private String truckType;

    @ApiModelProperty("車牌號")
    private String licensePlateNo;

    @ApiModelProperty("出貨地")
    private String shipFrom;

    @ApiModelProperty("貨櫃號")
    private String containerNo;

    @ApiModelProperty("碼頭編號")
    private String dockNumber;

    @ApiModelProperty("入場時間")
    private String vehicleEntryTime;
}
