package com.maxnerva.cloudmes.entity.wo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName WoHeaderDownloadVO
 * @Description 工单header下载vo
 * @Author Likun
 * @Date 2022/8/30
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel(value = "工单vo")
@Data
public class WoOrderVO {

    @ApiModelProperty("工厂")
    private String plantCode;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("工单号")
    private String workOrderNo;
}
