package com.maxnerva.cloudmes.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/**
 * @ClassName FlowNetUrlConfig
 * @Description flownet地址配置
 * @Author Likun
 * @Date 2023/12/21
 * @Version 1.0
 * @Since JDK 1.8
 **/
@RefreshScope
@Component
@Data
public class FlowNetUrlConfig {

    @Value("${flownet.mail.url:}")
    private String mailUrl;
}
