package com.maxnerva.cloudmes.mapper.wo;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.wo.WmsCreatePoDnConfig;

/**
 * (WmsCreatePoDnConfig)表数据库访问层
 *
 * @author hgx
 * @since 2024-01-30
 */
public interface WmsCreatePoDnConfigMapper extends BaseMapper<WmsCreatePoDnConfig> {

}

