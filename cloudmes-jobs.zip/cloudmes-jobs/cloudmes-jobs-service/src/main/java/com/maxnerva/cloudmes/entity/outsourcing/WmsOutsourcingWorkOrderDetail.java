package com.maxnerva.cloudmes.entity.outsourcing;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>
 * 委外工单信息detail表
 * </p>
 *
 * @author likun
 * @since 2023-11-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsOutsourcingWorkOrderDetail对象", description="委外工单信息detail表")
public class WmsOutsourcingWorkOrderDetail extends BaseEntity<WmsOutsourcingWorkOrderDetail> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "PO号")
    private String poNo;

    @ApiModelProperty(value = "成品料号")
    private String productPartNo;

    @ApiModelProperty(value = "成品料号版次")
    private String productPartVersion;

    @ApiModelProperty(value = "群组")
    private String poItem;

    @ApiModelProperty(value = "料号关系类型,M主料,S替代料;S替代料")
    private String partRelationship;

    @ApiModelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "鸿海料号版次")
    private String partVersion;

    @ApiModelProperty(value = "料号描述")
    private String partNoDesc;

    @ApiModelProperty(value = "主料料号")
    private String mainPartNo;

    @ApiModelProperty(value = "主料料号版次")
    private String mainPartVersion;

    @ApiModelProperty(value = "单位编码")
    private String uomCode;

    @ApiModelProperty(value = "sap发料仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "需求量")
    private BigDecimal requiredQuantity;

    @ApiModelProperty(value = "备料量")
    private BigDecimal stockQty;

    @ApiModelProperty(value = "备料总量")
    private BigDecimal stockTotalQty;

    @ApiModelProperty(value = "过账541数量")
    private BigDecimal postTo541Qty;

    @ApiModelProperty(value = "过账542数量")
    private BigDecimal postTo542Qty;

    @ApiModelProperty(value = "退料量")
    private BigDecimal returnQty;

    @ApiModelProperty(value = "过账541返回信息")
    private String postTo541ReturnMsg;

    @ApiModelProperty(value = "过账541时间")
    private LocalDateTime postTo541LastDt;

    @ApiModelProperty(value = "过账542返回信息")
    private String postTo542ReturnMsg;

    @ApiModelProperty(value = "过账542时间")
    private LocalDateTime postTo542LastDt;

    @ApiModelProperty(value = "计划日期")
    private LocalDate scheduledDate;

    @ApiModelProperty(value = "计划开始时间")
    private LocalDateTime scheduledStart;

    @ApiModelProperty(value = "计划结束时间")
    private LocalDateTime scheduledEnd;

    @ApiModelProperty(value = "po仓码")
    private String poWarehouseCode;

    @ApiModelProperty(value = "用量比例(MENGE) 543用")
    private BigDecimal ratio;

    @ApiModelProperty(value = "基础用量(MNGLG) 543用")
    private BigDecimal basicUsage;

}
