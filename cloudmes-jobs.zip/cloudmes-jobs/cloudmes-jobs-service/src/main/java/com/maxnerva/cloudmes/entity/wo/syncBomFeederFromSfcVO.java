package com.maxnerva.cloudmes.entity.wo;

import lombok.Data;

import java.util.List;

/**
 * @Author hgx
 * @Description 同步上料表VO
 * @Date 2023/5/18
 */
@Data
public class syncBomFeederFromSfcVO {
    private String sfcSite;
    private String workOrderNo;
    private String lineNo;
    private String processType;
    private String partNo;
//    private List<String> workOrderList;
}
