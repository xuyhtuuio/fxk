package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.extension.activerecord.Model;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>
 * 单据表
 * </p>
 *
 * @author likun
 * @since 2022-09-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsDocReceive对象", description="单据表")
public class WmsDocReceive extends Model<WmsDocReceive> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU(业务单元)")
    private String orgCode;

    @ApiModelProperty(value = "单据号(系统根据规则自动生成)")
    private String docNo;

    @ApiModelProperty(value = "单据接收日期")
    private LocalDate docCreateDate;

    @ApiModelProperty(value = "单据状态,参考字典WMS-DOC-STATUS")
    private String docStatus;

    @ApiModelProperty(value = "单据类型主键id")
    private Integer wmsDocTypeId;

    @ApiModelProperty(value = "单据类型编码")
    private String docTypeCode;

    @ApiModelProperty(value = "单据类型名称")
    private String docTypeName;

    @ApiModelProperty(value = "单据大类编码")
    private String docCategoryCode;

    @ApiModelProperty(value = "来源单号")
    private String fromDocNo;

    @ApiModelProperty(value = "来源单项次")
    private String fromDocItem;

    @ApiModelProperty(value = "sap仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "sap工厂")
    private String plantCode;

    @ApiModelProperty(value = "po编码")
    private String poNo;

    @ApiModelProperty(value = "po项次")
    private String poItem;

    @ApiModelProperty(value = "采购单号文件类型")
    private String poDocumentType;

    @ApiModelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "鸿海料号版次")
    private String partNoVersion;

    @ApiModelProperty(value = "制造商编码")
    private String mfgCode;

    @ApiModelProperty(value = "制造商名称")
    private String mfgName;

    @ApiModelProperty(value = "制造商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "制造商料号版次")
    private String mfgVersion;

    @ApiModelProperty(value = "客户料号")
    private String customerPartNo;

    @ApiModelProperty(value = "客户料号版次")
    private String customerVersion;

    @ApiModelProperty(value = "单据数量")
    private BigDecimal docQty;

    @ApiModelProperty(value = "确认数量，未启用，默认等于单据数量")
    private BigDecimal confirmQty;

    @ApiModelProperty(value = "操作数量")
    private BigDecimal operateQty;

    @ApiModelProperty(value = "单位编码")
    private String uomCode;

    @ApiModelProperty(value = "单据创建表单结构体")
    private String wmsContent;

    @ApiModelProperty(value = "原产国1")
    private String placeOfOrigin1;

    @ApiModelProperty(value = "原产国2")
    private String placeOfOrigin2;

    @ApiModelProperty(value = "起运国")
    private String shipOfOrigin;

    @ApiModelProperty(value = "采购员")
    private String purchaser;

    @ApiModelProperty(value = "是否强制检验(f-否，t-是)")
    private Boolean isForceInspect;

    @ApiModelProperty(value = "确认收货标识")
    private Integer confirmReceiptFlag;

    @ApiModelProperty(value = "确认收货人")
    private String confirmDocAccount;

    @ApiModelProperty(value = "确认收货信息,收货员操作备注")
    private String confirmDocMessage;

    @ApiModelProperty(value = "确认收货上传图片地址")
    private String confirmDocFileUrl;

    @ApiModelProperty(value = "确认收货日期")
    private LocalDateTime confirmDocDate;

    @ApiModelProperty(value = "是否调用qms标识（Y-是，N-否）")
    private String postingQmsFlag;

    @ApiModelProperty(value = "是否已经抛转qms状态标识（t-否，f-是）")
    private Boolean toQmsFlag;

    @ApiModelProperty(value = "抛转qms信息")
    private String toQmsMessage;

    @ApiModelProperty(value = "抛转qms时间")
    private LocalDateTime toQmsDate;

    @ApiModelProperty(value = "qms返回标识,0-不合格, 1-合格")
    private Integer qmsReturnFlag;

    @ApiModelProperty(value = "qms回写日期")
    private LocalDateTime qmsReturnDate;

    @ApiModelProperty(value = "qms返回信息")
    private String qmsReturnMessage;

    @ApiModelProperty(value = "是否调用sap标识")
    private String postingSapMethodFlag;

    @ApiModelProperty(value = "调用wms方法名")
    private String postingMethodName;

    @ApiModelProperty(value = "调用sap日期")
    private LocalDateTime postingSapMethodDate;

    @ApiModelProperty(value = "调用sap结果")
    private String postingSapMethodResult;

    @ApiModelProperty(value = "sap返回信息")
    private String sapReturnMessage;

    @ApiModelProperty(value = "sao返回单号")
    private String sapReturnNumber;

    @ApiModelProperty(value = "GR单号")
    private String grNo;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "检验结果(良品,不良品)")
    private String inspectResult;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "质量检验状态")
    private String inspectStatus;

    @ApiModelProperty(value = "是否急件")
    private Boolean isUrgent;

    @ApiModelProperty("采购组织")
    private String purchaseOrg;

    @ApiModelProperty("采购组")
    private String purchaseGroup;

    @ApiModelProperty(value = "转良品仓良品状态返回值sapNumber")
    private String sapConfirmNumber;

    @ApiModelProperty(value = "转良品仓良品状态返回值errorMsg")
    private String sapConfirmMessage;

    @ApiModelProperty(value = "转良品仓良品状态时间")
    private LocalDateTime sapConfirmDatetime;

    @ApiModelProperty(value = "转良品仓良品状态返回值sapNumber")
    private String sapTransferRejectsNumber;

    @ApiModelProperty(value = "转良品仓良品状态返回值errorMsg")
    private String sapTransferRejectsMessage;

    @ApiModelProperty(value = "转良品仓良品状态时间")
    private LocalDateTime sapTransferRejectsDatetime;

    /**
     * 创建时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(hidden = true)
    private LocalDateTime createdDt;

    @ApiModelProperty(hidden = true)
    private String creator;

    /**
     * 最后修改人
     */
    @ApiModelProperty(hidden = true)
    private String lastEditor;

    /**
     * 最后一次编辑时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(hidden = true)
    private LocalDateTime lastEditedDt;

    @ApiModelProperty("供应商")
    private String vendorCode;

    @ApiModelProperty(value = "預計送達時間")
    private LocalDate eta;

    @ApiModelProperty(value = "毛重")
    private BigDecimal grossWeight;

    @ApiModelProperty(value = "箱數")
    private Integer cartonQty;

    @ApiModelProperty(value = "板數")
    private Integer palletQty;

    @ApiModelProperty(value = "dc")
    private String dc;

    @ApiModelProperty(value = "發票號碼")
    private String invoiceNo;

    @ApiModelProperty(value = "ECCN NO")
    private String eccnNo;

    @ApiModelProperty("勾兌报关单号")
    private String blendingCusNo;

    @ApiModelProperty("勾兌报关单项次")
    private String blendingCusItem;

    @ApiModelProperty("勾兑报关单异常信息")
    private String blendingCusMessage;

    @ApiModelProperty("勾兑报关单时间")
    private LocalDateTime blendingCusDatetime;

    @ApiModelProperty(value = "0 未勾兑，1勾兑成功，2ecus未查询到报关单")
    private String blendingCusFlag;
}
