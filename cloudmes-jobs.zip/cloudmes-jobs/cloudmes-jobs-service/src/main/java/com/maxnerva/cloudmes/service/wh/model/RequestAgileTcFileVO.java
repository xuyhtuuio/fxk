package com.maxnerva.cloudmes.service.wh.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class RequestAgileTcFileVO {
    @ApiModelProperty(value = "文件名", required = true)
    private String name;

    @ApiModelProperty(value = "路径", required = true)
    private String path;
}
