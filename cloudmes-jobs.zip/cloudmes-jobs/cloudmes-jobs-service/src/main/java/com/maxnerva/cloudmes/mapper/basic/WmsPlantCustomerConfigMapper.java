package com.maxnerva.cloudmes.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.basic.WmsPlantCustomerConfig;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2023-09-25
 */
public interface WmsPlantCustomerConfigMapper extends BaseMapper<WmsPlantCustomerConfig> {

}
