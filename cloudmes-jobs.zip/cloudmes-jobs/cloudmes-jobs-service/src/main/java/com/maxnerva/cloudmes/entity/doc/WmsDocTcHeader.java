package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2024-08-16
 */
@TableName("wms_doc_tc_header")
@ApiModel(value = "WmsDocTcHeader对象", description = "")
@Data
public class WmsDocTcHeader extends BaseEntity<WmsDocTcHeader> {

    private static final long serialVersionUID = 1L;

    private Integer id;

    @ApiModelProperty("特采单号")
    private String docNo;

    @ApiModelProperty("工厂组织")
    private String orgCode;

    @ApiModelProperty("工厂")
    private String plantCode;

    @ApiModelProperty("工单")
    private String workOrderNo;

    @ApiModelProperty("0 新建，2已发送，1，已回写完成，3抛转失败，4抛转中，5拒签")
    private String identify;

    @ApiModelProperty("抛转数据")
    private String postMessage;

    @ApiModelProperty(value = "操作人")
    private String operator;

    @ApiModelProperty(value = "客户")
    private String customer;

    @ApiModelProperty(value = "成品料号")
    private String finishPartNo;

    @ApiModelProperty(value = "文件名")
    private String fileName;

    @ApiModelProperty(value = "文件地址")
    private String fileUrl;

    @ApiModelProperty(value = "返回报错")
    private String postReturnMessage;

    @ApiModelProperty(value = "物控工号")
    private String originator;

    @ApiModelProperty(value = "实际特采单号")
    private String actualDocNo;

    @ApiModelProperty(value = "特采延期日期")
    private LocalDateTime tcExpirationDate;

    @ApiModelProperty(value = "拒签原因")
    private String reason;

    @ApiModelProperty(value = "抛特采系统时间")
    private LocalDateTime postDt;

    @ApiModelProperty(value = "回写时间")
    private LocalDateTime replyDt;

    @ApiModelProperty(value = "回写信息")
    private String replyMessage;

    @ApiModelProperty(value = "是否3年内 Y/N")
    private String withinThreeYears;
}
