package com.maxnerva.cloudmes.service.jusda.model;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/11/09 10:52
 * @Version: 1.0
 */

import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel("ReturnJusdaReceiveCompletedDto")
public class ReturnJusdaReceiveCompletedDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String ShipID;
    private String SiteName;
    private String SubmissionTime;
    private String Signee;

}