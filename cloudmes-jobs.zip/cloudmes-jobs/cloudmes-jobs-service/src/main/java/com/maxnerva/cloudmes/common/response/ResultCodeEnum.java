package com.maxnerva.cloudmes.common.response;

/**
 * @Description: Result Code Enum
 * @Author: Chao Zhang
 * @Date: 2021/01/25
 * @Version: 1.0
 */
public enum ResultCodeEnum {

    /**
     * 成功
     */
    SUCCESS(0, "Success"),

    /**
     * 操作失败
     */
    FAILURE(-100, "Failure"),

    /**
     * 系统错误
     */
    ERROR(-200, "系统错误"),


    /**
     * 未登录/登录超时
     */
    UNAUTHORIZED(1002, "登录超时"),

    /**
     * 参数错误
     */
    PARAM_ERROR(1003, "参数错误"),

    /**
     * 参数错误-已存在
     */
    INVALID_PARAM_EXIST(1004, "请求参数已存在"),

    /**
     * 参数错误
     */
    INVALID_PARAM_EMPTY(1005, "请求参数为空"),

    /**
     * 参数错误
     */
    PARAM_TYPE_MISMATCH(1006, "参数类型不匹配"),

    /**
     * 参数错误
     */
    PARAM_VALID_ERROR(1007, "参数校验失败"),

    /**
     * 参数错误
     */
    ILLEGAL_REQUEST(1008, "非法请求"),

    /**
     * 验证码错误
     */
    INVALID_VCODE(2004, "验证码错误"),

    /**
     * 用户名或密码错误
     */
    INVALID_USERNAME_PASSWORD(2005, "账号或密码错误"),

    /**
     *
     */
    INVALID_RE_PASSWORD(2006, "两次输入密码不一致"),

    /**
     * 用户名或密码错误
     */
    INVALID_OLD_PASSWORD(2007, "旧密码错误"),

    /**
     * 用户名重复
     */
    USERNAME_ALREADY_IN(2008, "用户名已存在"),

    /**
     * 用户不存在
     */
    INVALID_USERNAME(2009, "用户名不存在"),

    /**
     * 角色不存在
     */
    INVALID_ROLE(2010, "角色不存在"),

    /**
     * 角色不存在
     */
    ROLE_USED(2011, "角色使用中，不可删除"),

    /**
     * 没有权限
     */
    NO_PERMISSION(2012, "当前用户无该接口权限");

    public int code;

    public String message;

    ResultCodeEnum(int code, String msg) {
        this.code = code;
        this.message = msg;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
