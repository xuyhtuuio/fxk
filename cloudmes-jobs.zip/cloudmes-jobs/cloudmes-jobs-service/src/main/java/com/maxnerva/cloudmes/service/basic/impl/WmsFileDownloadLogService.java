package com.maxnerva.cloudmes.service.basic.impl;

import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.io.StreamProgress;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.entity.R;
import com.maxnerva.cloudmes.entity.basic.WmsFileDownloadLog;
import com.maxnerva.cloudmes.mapper.basic.WmsFileDownloadLogMapper;
import com.maxnerva.cloudmes.service.basic.IWmsFileDownloadLogService;
import com.maxnerva.cloudmes.service.basic.UploadFileService;
import com.maxnerva.cloudmes.service.basic.model.FileUploadVO;
import com.maxnerva.cloudmes.service.basic.model.UploadFileRespDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.time.LocalDateTime;
import java.util.List;

@Service
@Slf4j
public class WmsFileDownloadLogService extends ServiceImpl<WmsFileDownloadLogMapper, WmsFileDownloadLog> implements IWmsFileDownloadLogService {
    @Autowired
    UploadFileService uploadFileService;

    @Override
    public WmsFileDownloadLog uploadFile(String orgCode, String type, String fileName, String creator, byte[] bytes) {
        MultipartFile file = new MultipartFile() {
            @Override
            public String getName() {
                return fileName;
            }
            @Override
            public String getOriginalFilename() {
                return fileName;
            }
            @Override
            public String getContentType() {
                return MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE;
            }
            @Override
            public boolean isEmpty() {
                return false;
            }
            @Override
            public long getSize() {
                return bytes.length;
            }
            @Override
            public byte[] getBytes() throws IOException {
                return bytes;
            }
            @Override
            public InputStream getInputStream() throws IOException {
                return new ByteArrayInputStream(bytes);
            }
            @Override
            public void transferTo(File dest) throws IOException, IllegalStateException {
            }
        };
        FileUploadVO fileUploadVO = new FileUploadVO();
        fileUploadVO.setBucketName("cloudsaas");
        fileUploadVO.setFiles(ListUtil.toList(file));
        R<List<UploadFileRespDTO>> res = uploadFileService.uploadBatch(fileUploadVO);
        if (res.getCode() == 200){
            UploadFileRespDTO dto = res.getData().get(0);
            WmsFileDownloadLog wmsFileDownloadLog = new WmsFileDownloadLog();
            wmsFileDownloadLog.setCreatedDt(LocalDateTime.now());
            wmsFileDownloadLog.setCreator(creator);
            wmsFileDownloadLog.setLastEditedDt(LocalDateTime.now());
            wmsFileDownloadLog.setLastEditor(creator);
            wmsFileDownloadLog.setFileId(dto.getId());
            wmsFileDownloadLog.setFileName(fileName);
            wmsFileDownloadLog.setLink(dto.getName());
            wmsFileDownloadLog.setOrgCode(orgCode);
            wmsFileDownloadLog.setType(type);
            baseMapper.insert(wmsFileDownloadLog);
            return wmsFileDownloadLog;
        } else {
            log.error(String.format("statusCode: %s, msg: %s", res.getCode(), res.getMsg()));
        }

        return null;
    }
}
