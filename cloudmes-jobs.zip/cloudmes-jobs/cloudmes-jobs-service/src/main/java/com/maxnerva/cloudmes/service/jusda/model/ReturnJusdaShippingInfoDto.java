package com.maxnerva.cloudmes.service.jusda.model;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/11/09 10:52
 * @Version: 1.0
 */

import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel("JusdaShippingInfoDto")
public class ReturnJusdaShippingInfoDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String ShipID;
    private String SiteName;
    private String DeliveryNo;
    private String CustomerPartNo;
    private String OrderQty;
    private String UOM;
    private String ShipDT;
    private String CustomerName;
    private String CustomerSupplierNo;
    private String CustomerPo;
    private String CustomerPOItem;
    private String CustomerGRNNo;
    private String Manufacture;
    private String DocumentID;
    private String CancelGRN;
    private String UnitPrice;
    private String EndCustomerPo;


}