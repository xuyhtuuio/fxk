package com.maxnerva.cloudmes.mapper.doc;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.doc.WmsDocJitReceiveGrRecord;

/**
 * <p>
 * JIT收货GR记录表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2025-02-11
 */
public interface WmsDocJitReceiveGrRecordMapper extends BaseMapper<WmsDocJitReceiveGrRecord> {

}
