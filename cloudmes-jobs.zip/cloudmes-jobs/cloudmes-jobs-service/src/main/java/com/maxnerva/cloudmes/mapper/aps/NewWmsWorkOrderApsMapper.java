package com.maxnerva.cloudmes.mapper.aps;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.aps.WmsWorkOrderApsEntity;

/**
 * 同步aps工单header信息表 Mapper 接口
 * @author Yang Jun Wen
 * @since 2023-06-09
 */
public interface NewWmsWorkOrderApsMapper extends BaseMapper<WmsWorkOrderApsEntity> {

}
