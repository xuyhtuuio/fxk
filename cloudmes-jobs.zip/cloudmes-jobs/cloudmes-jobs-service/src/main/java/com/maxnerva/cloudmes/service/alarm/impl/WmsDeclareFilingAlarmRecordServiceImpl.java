package com.maxnerva.cloudmes.service.alarm.impl;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.config.FlowNetUrlConfig;
import com.maxnerva.cloudmes.entity.alarm.FlowNetEmailVO;
import com.maxnerva.cloudmes.entity.alarm.FlownetResponse;
import com.maxnerva.cloudmes.entity.alarm.WmsDeclareFilingAlarmRecord;
import com.maxnerva.cloudmes.entity.alarm.WmsSendMailConfig;
import com.maxnerva.cloudmes.mapper.alarm.WmsDeclareFilingAlarmRecordMapper;
import com.maxnerva.cloudmes.mapper.alarm.WmsSendMailConfigMapper;
import com.maxnerva.cloudmes.service.alarm.IWmsDeclareFilingAlarmRecordService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * 备案预警表 服务实现类
 * </p>
 *
 * @author likun
 * @since 2023-12-19
 */
@Slf4j
@Service
public class WmsDeclareFilingAlarmRecordServiceImpl extends ServiceImpl<WmsDeclareFilingAlarmRecordMapper, WmsDeclareFilingAlarmRecord> implements IWmsDeclareFilingAlarmRecordService {

    @Resource
    private FlowNetUrlConfig flowNetUrlConfig;

    @Resource
    private WmsSendMailConfigMapper wmsSendMailConfigMapper;

    @Override
    public void sendMailBatch(String orgCode) {
        String currentStaffCode = "sysadmin";
        //查询组织下未发邮件以及未备过案的预警信息
        List<WmsDeclareFilingAlarmRecord> wmsDeclareFilingAlarmRecords = baseMapper
                .selectList(Wrappers.<WmsDeclareFilingAlarmRecord>lambdaQuery()
                        .eq(WmsDeclareFilingAlarmRecord::getOrgCode, orgCode)
                        .eq(WmsDeclareFilingAlarmRecord::getSendMailFlag, "N")
                        .eq(WmsDeclareFilingAlarmRecord::getFilingStatus, "0")
                        .eq(WmsDeclareFilingAlarmRecord::getIsDeleted, Boolean.FALSE));
        Map<String, List<WmsDeclareFilingAlarmRecord>> collect = wmsDeclareFilingAlarmRecords.stream()
                .collect(Collectors.groupingBy(WmsDeclareFilingAlarmRecord::getPlantCode));
        for (Map.Entry<String, List<WmsDeclareFilingAlarmRecord>> entry : collect.entrySet()) {
            String plantCode = entry.getKey();
            WmsSendMailConfig mailConfig = wmsSendMailConfigMapper.selectOne(Wrappers.<WmsSendMailConfig>lambdaQuery()
                    .eq(WmsSendMailConfig::getOrgCode, orgCode)
                    .eq(WmsSendMailConfig::getPlantCode, plantCode)
                    .eq(WmsSendMailConfig::getSendType, "DECLARE_FILING_ALARM")
                    .last("limit 1"));
            if (ObjectUtil.isNull(mailConfig)) {
                continue;
            }
            List<WmsDeclareFilingAlarmRecord> declareFilingAlarmRecordList = entry.getValue();
            FlowNetEmailVO flowNetEmailVO = new FlowNetEmailVO();
            flowNetEmailVO.setUserID(mailConfig.getUserId());
            flowNetEmailVO.setPassword(mailConfig.getPassWord());
            flowNetEmailVO.setMAILTO(mailConfig.getToAddress());
            flowNetEmailVO.setCC(StrUtil.isNotEmpty(mailConfig.getCcAddress()) ?
                    mailConfig.getCcAddress() : StrUtil.EMPTY);
            String mailTitle = mailConfig.getMailTitle();
            long materialCount = declareFilingAlarmRecordList.stream().distinct().count();
            flowNetEmailVO.setSubject(String.format(mailTitle, plantCode, materialCount));
            String mailContent = mailConfig.getMailContent();
            StringBuilder stringBuilder = new StringBuilder();
            for (WmsDeclareFilingAlarmRecord wmsDeclareFilingAlarmRecord : declareFilingAlarmRecordList) {
                String partNo = wmsDeclareFilingAlarmRecord.getPartNo();
                LocalDate scheduleDate = wmsDeclareFilingAlarmRecord.getScheduleDate();
                String apsScheduleDate = ObjectUtil.isNotNull(scheduleDate) ?
                        DateTimeFormatter.ofPattern("yyyy-MM-dd").format(scheduleDate) :
                        StrUtil.EMPTY;
                stringBuilder.append(String.format(mailContent, plantCode, partNo, apsScheduleDate));
                stringBuilder.append("<br>");
            }
            flowNetEmailVO.setBODY(stringBuilder.toString());
            String flag = invokeFlowNetMailService(flowNetEmailVO);
            List<Integer> updateIdList = declareFilingAlarmRecordList.stream().map(WmsDeclareFilingAlarmRecord::getId)
                    .collect(Collectors.toList());
            String sendMailFlag = StrUtil.equals(flag, "Success") ?
                    "Y" : "N";
            baseMapper.update(null, Wrappers.<WmsDeclareFilingAlarmRecord>lambdaUpdate()
                    .in(WmsDeclareFilingAlarmRecord::getId, updateIdList)
                    .set(WmsDeclareFilingAlarmRecord::getSendMailFlag, sendMailFlag)
                    .set(WmsDeclareFilingAlarmRecord::getSendMailDate, LocalDateTime.now())
                    .set(WmsDeclareFilingAlarmRecord::getSendMailBody, JSONUtil.toJsonStr(flowNetEmailVO))
                    .set(WmsDeclareFilingAlarmRecord::getSendMailMsg, flag)
                    .set(WmsDeclareFilingAlarmRecord::getLastEditor, currentStaffCode)
                    .set(WmsDeclareFilingAlarmRecord::getLastEditedDt, LocalDateTime.now()));
        }
    }

    public String invokeFlowNetMailService(FlowNetEmailVO flowNetEmailVO) {
        FlownetResponse response;
        String result;
        String flowNetMailUrl = flowNetUrlConfig.getMailUrl();
        try {
            result = HttpUtil.createPost(flowNetMailUrl)
                    .header("Content-Type", "application/json;charset=UTF-8")
                    .setConnectionTimeout(30 * 1000)
                    .setReadTimeout(180 * 1000)
                    .body(JSONUtil.toJsonStr(flowNetEmailVO))
                    .execute()
                    .body();
            log.info("sendMailBatchToFlowNet：::requestJson={},url={},result={},current-time:{}",
                    JSONUtil.toJsonStr(flowNetEmailVO), flowNetMailUrl, result, System.currentTimeMillis());
            response = JSON.parseObject(result, FlownetResponse.class);
        } catch (Exception e) {
            log.error("sendMailBatchToFlowNet ERROR:{}", e.getMessage(), e);
            return "Fail";
        }
        return response.getFlag();
    }
}
