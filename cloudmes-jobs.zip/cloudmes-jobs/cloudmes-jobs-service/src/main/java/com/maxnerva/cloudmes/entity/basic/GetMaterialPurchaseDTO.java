package com.maxnerva.cloudmes.entity.basic;

import lombok.Data;

@Data
public class GetMaterialPurchaseDTO {
    String purchaser;
}
