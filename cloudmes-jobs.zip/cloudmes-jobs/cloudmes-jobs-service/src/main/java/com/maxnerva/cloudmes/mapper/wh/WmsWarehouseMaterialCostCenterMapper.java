package com.maxnerva.cloudmes.mapper.wh;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.wh.WmsWarehouseMaterialCostCenter;

/**
 * <p>
 * 物料成本中心 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2022-11-01
 */
public interface WmsWarehouseMaterialCostCenterMapper extends BaseMapper<WmsWarehouseMaterialCostCenter> {

}
