package com.maxnerva.cloudmes.entity;

import lombok.Data;

@Data
public class R<T> {

    int code = 200;

    String msg;

    boolean success;

    T data;

    public static R ok() {
        return R.ok("成功！", null);
    }

    public static <T> R ok(T data) {
        return R.ok("成功！", data);
    }

    public static <T> R ok(String msg, T data) {
        return R.ok(200, msg, data);
    }


    public static <T> R ok(int code, String msg, T data) {
        R r = new R<>();
        r.setCode(code);
        r.setMsg(msg);
        r.setData(data);
        r.setSuccess(Boolean.TRUE);
        return r;
    }

    public static R ok(String msg) {
        return R.ok(msg, null);
    }

    public static R no() {
        return no("服务器异常！");
    }

    public static R no(int code, String msg) {
        return no(code, msg, null);
    }

    public static <T> R no(int code, String msg, T data) {
        R r = new R<>();
        r.setCode(code);
        r.setMsg(msg);
        r.setData(data);
        r.setSuccess(Boolean.FALSE);
        return r;
    }

    public static R no(String msg) {
        return no(500, msg);
    }

    public static R status(boolean flag) {
        return flag ? R.ok("成功！")
                : R.no("服务器异常！");
    }

}
