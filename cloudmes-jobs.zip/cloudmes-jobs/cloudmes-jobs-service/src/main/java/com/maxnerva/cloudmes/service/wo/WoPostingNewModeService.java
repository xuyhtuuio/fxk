package com.maxnerva.cloudmes.service.wo;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.NumberUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.config.Constants;
import com.maxnerva.cloudmes.entity.WmsSapPlant;
import com.maxnerva.cloudmes.entity.scrap.WmsBadProductInStorageEntity;
import com.maxnerva.cloudmes.entity.scrap.WmsWorkOrderDetailScrapInStorageDetailEntity;
import com.maxnerva.cloudmes.entity.wo.WmsSapTransactionLog;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderDetail;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderDetailInStorage;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderHeader;
import com.maxnerva.cloudmes.mapper.WmsSapPlantMapper;
import com.maxnerva.cloudmes.mapper.wo.*;
import com.maxnerva.cloudmes.service.sap.material.MaterialRfcService;
import com.maxnerva.cloudmes.service.sap.wh.WhRfcService;
import com.maxnerva.cloudmes.service.sap.wh.model.TransferDto;
import com.maxnerva.cloudmes.service.sap.wo.WoRfcService;
import com.maxnerva.cloudmes.service.sap.wo.model.BaoGongDto;
import com.maxnerva.cloudmes.service.sap.wo.model.WorkOrderPostingDto;
import com.maxnerva.cloudmes.service.wo.model.PostingSap101ReturnDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.TemporalAdjusters;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @Description: 工单新模式过账服务  261/262 + CDK 311
 * @Author: Chao Zhang
 * @Date: 2022/09/12 09:18
 * @Version: 1.0
 */
@Service
@Slf4j
public class WoPostingNewModeService {

    @Autowired
    WmsWorkOrderDetailMapper workOrderDetailMapper;

    @Autowired
    MaterialRfcService materialRfcService;

    @Autowired
    WhRfcService whRfcService;

    @Autowired
    WoRfcService woRfcService;

    @Autowired
    WmsWorkOrderHeaderMapper workOrderHeaderMapper;

    @Autowired
    WmsWorkOrderDetailInStorageMapper wmsWorkOrderDetailInStorageMapper;

    @Autowired
    WmsSapTransactionLogMapper wmsSapTransactionLogMapper;
    @Autowired
    WmsSapPlantMapper wmsSapPlantMapper;

    @Autowired
    WmsWorkOrderDetailScrapInStorageDetailMapper wmsWorkOrderDetailScrapInStorageDetailMapper;

    @Autowired
    WmsWorkOrderHeaderMapper wmsWorkOrderHeaderMapper;

    @Autowired
    WmsBadProductInStorageMapper wmsBadProductInStorageMapper;

    /**
     * CKD 工单detail备料量过账SAP 311
     * <p>
     * 条件：
     * 1.stock_qty > post_to311_qty
     * 2.work_order_no 工单头以CKD开始
     * <p>
     * 过账方式 311 ， from 大仓 ----> CKD仓码
     * <p>
     * 使用栏位 getStockQty，getPostTo311Qty，setPostTo311Qty，  setPostTo311ReturnMsg，setPostTo311LastDt
     */
    public void postingCkdWoDetail311NewMode(String orgCode, String sapClientCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }
        //需过账311的wo detail list
//        List<WmsWorkOrderDetail> woDetailList = workOrderDetailMapper.selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
//                .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
//                .apply(" stock_qty > post_to311_qty"));
        List<WmsWorkOrderDetail> woDetailList = workOrderDetailMapper.select311deatil(orgCode);
        if (CollUtil.isEmpty(woDetailList)) {
            return;
        }

        List<String> workOrderNoList = woDetailList.parallelStream().map(WmsWorkOrderDetail::getWorkOrderNo).distinct().collect(Collectors.toList());

        List<WmsWorkOrderHeader> ckdWoList =
                workOrderHeaderMapper.selectList(Wrappers.<WmsWorkOrderHeader>lambdaQuery().eq(WmsWorkOrderHeader::getOrgCode, orgCode).in(WmsWorkOrderHeader::getWorkOrderNo, workOrderNoList).in(WmsWorkOrderHeader::getWorkOrderType, Arrays.asList("CKD")));


        woDetailList.forEach(w -> {

            if (Constants.continueJob.equalsIgnoreCase("N")) {
                return;
            }

            //过滤CKD工单
            if (CollUtil.isNotEmpty(ckdWoList)) {
                long count = ckdWoList.stream().filter(a -> a.getWorkOrderNo().equalsIgnoreCase(w.getWorkOrderNo())).count();
                if (count > 0) {
                    // CKD工单
                } else {
                    //过滤非CKD工单
                    return;
                }
            }

            BigDecimal postingQty = NumberUtil.sub(w.getStockQty(), w.getPostTo311Qty());
            try {

                if (postingQty.compareTo(BigDecimal.ZERO) <= 0) {
                    return;
                }
                //from仓码与to仓码一致,不抛sap,直接过账信息填写过账OK
                if (StrUtil.equals(w.getFromWarehouseCode(), w.getToWarehouseCode())) {
                    workOrderDetailMapper.update(null, Wrappers.<WmsWorkOrderDetail>lambdaUpdate()
                            .eq(WmsWorkOrderDetail::getId, w.getId())
                            .set(WmsWorkOrderDetail::getPostTo311Qty, w.getStockQty())
                            .set(WmsWorkOrderDetail::getPostTo311ReturnMsg, "OK")
                            .set(WmsWorkOrderDetail::getPostTo311LastDt, LocalDateTime.now()));
                    return;
                }

                TransferDto dto = setTransfer311Dto(w, postingQty, postDate);

                if (StringUtils.isBlank(w.getValueType())) {
                    String valueTypeValue = materialRfcService.doGetMaterialValueType(sapClientCode, w.getPlantCode(), w.getPartNo(), w.getFromWarehouseCode());
                    dto.setValueType(valueTypeValue);
                } else {
                    dto.setValueType(w.getValueType());
                }
                WmsSapPlant wmsSapPlant = wmsSapPlantMapper.selectOne(Wrappers.<WmsSapPlant>lambdaQuery()
                        .eq(WmsSapPlant::getOrgCode, orgCode)
                        .eq(WmsSapPlant::getFactoryCode, dto.getFromPlant())
                        .last("limit 1"));
                if ("N".equalsIgnoreCase(wmsSapPlant.getEnableVersion())) {
                    dto.setFromPartVersion("");
                    dto.setToPartVersion("");
                }
                String s = whRfcService.doTransfer(sapClientCode, dto);
                // update wo detail post 311 qty
//                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
//                updateDetail.setId(w.getId());
//                updateDetail.setPostTo311Qty(w.getStockQty());
//                updateDetail.setPostTo311ReturnMsg(s);
//                updateDetail.setPostTo311LastDt(LocalDateTime.now());
//                updateDetail.updateById();
                workOrderDetailMapper.update(null, Wrappers.<WmsWorkOrderDetail>lambdaUpdate()
                        .setSql(String.format("post_to311_qty = post_to311_qty + %d", postingQty.toBigInteger()))
                        .set(WmsWorkOrderDetail::getPostTo311ReturnMsg, s)
                        .set(WmsWorkOrderDetail::getPostTo311LastDt, LocalDateTime.now())
                        .eq(WmsWorkOrderDetail::getId, w.getId())
                );

                //write post log
                PostingSap101ReturnDto posrtingResult = new PostingSap101ReturnDto();

                posrtingResult.setDocNumber(s);

                writePostingLog(w, postingQty, posrtingResult, "311_CKD");

            } catch (Exception e) {
                log.error("wo posting 311 error  wo {} ,errorMsg:{}", JSONUtil.toJsonStr(w), e.getMessage());
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPostTo311ReturnMsg("last post311 Qty:" + postingQty + ",sap result:" + e.getMessage());
                updateDetail.setPostTo311LastDt(LocalDateTime.now());
                updateDetail.updateById();
            }
        });
    }

    /**
     * 工单detail备料量过账SAP 261
     * <p>
     * 条件：
     * 1.(stock_qty -move_in_qty) >post_to261_qty
     * 2.工单类型不为 CKD，MERGE
     *
     * <p>
     * 过账方式 261 ， from 大仓 ----> 工单
     * <p>
     * 使用栏位 stock_qty，move_in_qty，post_to261_qty
     */
    public void postingWoDetail261NewMode(String orgCode, String sapClientCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }

        //需过账261的wo detail 群组 list
        List<WmsWorkOrderDetail> woNeedToPosting261List =
                workOrderDetailMapper.selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
                        .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                        //.eq(WmsWorkOrderDetail::getWorkOrderNo, "000400001613")
                        .eq(WmsWorkOrderDetail::getPostingSapStatus, 0)
                        .last(" and work_order_no  not like 'CKD%'  and work_order_no  not like 'MERGE%' and (stock_qty - move_in_qty) > post_to261_qty"));

        if (CollUtil.isEmpty(woNeedToPosting261List)) {
            return;
        }

        List<String> workOrderNoList = woNeedToPosting261List.parallelStream().map(WmsWorkOrderDetail::getWorkOrderNo).distinct().collect(Collectors.toList());

        //List<WmsWorkOrderHeader> ckdWoList =
//        workOrderHeaderMapper.selectList(Wrappers.<WmsWorkOrderHeader>lambdaQuery().eq(WmsWorkOrderHeader::getOrgCode, orgCode).in(WmsWorkOrderHeader::getWorkOrderNo, workOrderNoList).in
//        (WmsWorkOrderHeader::getWorkOrderType, Arrays.asList("CKD", "MERGE")));

        List<WmsWorkOrderHeader> woHeaderList =
                workOrderHeaderMapper.selectList(Wrappers.<WmsWorkOrderHeader>lambdaQuery().eq(WmsWorkOrderHeader::getOrgCode, orgCode).in(WmsWorkOrderHeader::getWorkOrderNo, workOrderNoList));

        woNeedToPosting261List.forEach(w -> {

            if (Constants.continueJob.equalsIgnoreCase("N")) {
                return;
            }

            //过滤D工单
            if (CollUtil.isNotEmpty(woHeaderList)) {
                Optional<WmsWorkOrderHeader> woHeader = woHeaderList.stream().filter(a -> a.getWorkOrderNo().equalsIgnoreCase(w.getWorkOrderNo())).findFirst();

                if (woHeader.isPresent()) {
                    if (0 != woHeader.get().getPostSapFlag()) {
                        return;
                    }
                    if (StringUtils.isNotBlank(woHeader.get().getWorkOrderType()) && "CKD,MERGE".contains(woHeader.get().getWorkOrderType())) {
                        return;
                    }
                    //本月最后一天
                    LocalDate monthEndDay = LocalDate.now().with(TemporalAdjusters.lastDayOfMonth());
                    //本月之后的不过账
                    if (null != woHeader.get().getScheduledDate() && woHeader.get().getScheduledDate().isAfter(monthEndDay)) {
                        return;
                    }
                }
            } else {
                return;
            }

            //当前物料过账量
            BigDecimal post261Qty = BigDecimal.ZERO;
            post261Qty = NumberUtil.sub(w.getStockQty(), w.getMoveInQty(), w.getPostTo261Qty());

            try {
                if (post261Qty.compareTo(BigDecimal.ZERO) <= 0) {
                    return;
                }
               /* //如果组织为CABG_VN,则赋值版次为A
                if ("CABG_VN".equals(orgCode)) {
                    w.setPartVersion("A");
                }*/
                WorkOrderPostingDto input = setWorkOrderPosting261Dto(w, w.getFromWarehouseCode(), post261Qty, postDate);

                if (StringUtils.isBlank(w.getValueType())) {
                    String valueTypeValue = materialRfcService.doGetMaterialValueType(sapClientCode, w.getPlantCode(), w.getPartNo(), w.getFromWarehouseCode());
                    input.setValueType(valueTypeValue);
                } else {
                    input.setValueType(w.getValueType());
                }
                log.info("POST_261_WO_{}_PART_{} start", input.getWorkOrderNo(), input.getPartNo());
                try {
                    log.info("POST_261_WO_{}_PART_{} input {}", input.getWorkOrderNo(), input.getPartNo(), JSONUtil.toJsonStr(input));
                } catch (Exception e){}
                PostingSap101ReturnDto postingSap101ReturnDto = woRfcService.doWorkOrderPosting(sapClientCode, input);

                // update wo detail post 261 qty
          /*      WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPostTo261Qty(NumberUtil.add(w.getPostTo261Qty(), post261Qty));
                updateDetail.setValueType(input.getValueType());
                updateDetail.setPostTo261ReturnMsg(postingSap101ReturnDto.getDocNumber());
                updateDetail.setPostTo261LastDt(LocalDateTime.now());
                updateDetail.updateById();*/
                workOrderDetailMapper.update261WorkOrderDetailInfo(w.getId(), input.getValueType(),
                        postingSap101ReturnDto.getDocNumber(), post261Qty);
                //write post log
                writePostingLog(w, post261Qty, postingSap101ReturnDto, "261_wo");

            } catch (Exception e) {
                log.info("wo posting 261 error：wo {} ,result:{}", JSONUtil.toJsonStr(w), e.getMessage());
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPostTo261ReturnMsg("last post261 Qty:" + post261Qty + ",sap result:" + e.getMessage());
                updateDetail.setPostTo261LastDt(LocalDateTime.now());
                updateDetail.updateById();
            }
        });

    }

    /**
     * 重工工单过账SAP 531
     * 条件 shelf_qty > post_to531_qty
     */
    public void postingWoDetail531NewMode(String orgCode, String sapClientCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }

        List<WmsWorkOrderDetailInStorage> woNeedToPosting531List =
                wmsWorkOrderDetailInStorageMapper.selectList(Wrappers.<WmsWorkOrderDetailInStorage>lambdaQuery()
                        .eq(WmsWorkOrderDetailInStorage::getOrgCode, orgCode)
                        .last(" and shelf_qty > post_to531_qty"));

        if (CollUtil.isEmpty(woNeedToPosting531List)) {
            return;
        }

        woNeedToPosting531List.forEach(w -> {
            if (Constants.continueJob.equalsIgnoreCase("N")) {
                return;
            }

            //当前物料过账量
            BigDecimal inStorageQty = BigDecimal.ZERO;
            inStorageQty = NumberUtil.sub(w.getShelfQty(), w.getPostTo531Qty());

            try {
                if (inStorageQty.compareTo(BigDecimal.ZERO) <= 0) {
                    return;
                }
                /*//如果组织为CABG_VN,则赋值版次为A
                if ("CABG_VN".equals(orgCode)) {
                    w.setPartVersion("A");
                }*/
                WorkOrderPostingDto input = setWorkOrderPosting531Dto(w, inStorageQty, postDate);

                if (StringUtils.isBlank(w.getValueType())) {
                    String valueTypeValue = materialRfcService.doGetMaterialValueType(sapClientCode, w.getPlantCode(), w.getPartNo(), w.getSapWarehouseCode());
                    input.setValueType(valueTypeValue);
                } else {
                    input.setValueType(w.getValueType());
                }


                PostingSap101ReturnDto postingSap531ReturnDto = woRfcService.doWorkOrderPosting(sapClientCode, input);

                WmsWorkOrderDetailInStorage updateDetail = new WmsWorkOrderDetailInStorage();
                updateDetail.setId(w.getId());
                updateDetail.setPostTo531Qty(w.getShelfQty());
                updateDetail.setValueType(input.getValueType());
                updateDetail.setPostTo531ReturnNumber(postingSap531ReturnDto.getDocNumber());
                updateDetail.setPostTo531ReturnMsg(postingSap531ReturnDto.getDocNumber());
                updateDetail.setPostTo531ReturnDt(LocalDateTime.now());
                updateDetail.updateById();
                //write post log
                w.setValueType(input.getValueType());
                writePosting531Log(w, inStorageQty, postingSap531ReturnDto, "531_wo");

            } catch (Exception e) {
                WmsWorkOrderDetailInStorage updateDetail = new WmsWorkOrderDetailInStorage();
                updateDetail.setId(w.getId());
                updateDetail.setPostTo531ReturnMsg("last psot531 Qty:" + inStorageQty + ",sap result:" + e.getMessage());
                updateDetail.setPostTo531ReturnDt(LocalDateTime.now());
                updateDetail.updateById();
            }
        });

    }

    /**
     * 工单detail 退料量过账sap 262
     * <p>
     * 条件：
     * 1.return_qty > post_to262_qty
     * 2.工单类型不为 CKD，MERGE
     *
     * <p>
     * 过账方式 262 ， 工单 ----> 大仓
     * <p>
     * 使用栏位 stock_qty，move_in_qty，post_to261_qty
     */
    public void postingWoDetail262NewMode(String orgCode, String sapClientCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }

        //需过账262的wo detail 群组 list
        List<WmsWorkOrderDetail> woNeedToPosting262List =
                workOrderDetailMapper.selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
                        .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                        //.eq(WmsWorkOrderDetail::getWorkOrderNo, "000400001613")
                        .eq(WmsWorkOrderDetail::getPostingSapStatus, 0)
                        .last(" and (return_qty - bad_in_storage_qty) > post_to262_qty - bad_post_sap_qty"));

        if (CollUtil.isEmpty(woNeedToPosting262List)) {
            return;
        }

        List<String> workOrderNoList = woNeedToPosting262List.parallelStream().map(WmsWorkOrderDetail::getWorkOrderNo).distinct().collect(Collectors.toList());

        List<WmsWorkOrderHeader> woHeaderList =
                workOrderHeaderMapper.selectList(Wrappers.<WmsWorkOrderHeader>lambdaQuery().eq(WmsWorkOrderHeader::getOrgCode, orgCode).in(WmsWorkOrderHeader::getWorkOrderNo, workOrderNoList));

        woNeedToPosting262List.forEach(w -> {
            if (Constants.continueJob.equalsIgnoreCase("N")) {
                return;
            }

            //过滤CKD工单
            if (CollUtil.isNotEmpty(woHeaderList)) {
                Optional<WmsWorkOrderHeader> woHeader = woHeaderList.stream().filter(a -> a.getWorkOrderNo().equalsIgnoreCase(w.getWorkOrderNo())).findFirst();

                if (woHeader.isPresent()) {
                    if (0 != woHeader.get().getPostSapFlag()) {
                        return;
                    }
                    if (StringUtils.isNotBlank(woHeader.get().getWorkOrderType()) && "CKD,MERGE".contains(woHeader.get().getWorkOrderType())) {
                        return;
                    }
                    //本月最后一天
                    LocalDate monthEndDay = LocalDate.now().with(TemporalAdjusters.lastDayOfMonth());
                    //本月之后的不过账
                    if (null != woHeader.get().getScheduledDate() && woHeader.get().getScheduledDate().isAfter(monthEndDay)) {
                        return;
                    }
                }
            } else {
                return;
            }
            BigDecimal qty = workOrderDetailMapper.getQty(w.getWorkOrderNo(), w.getWorkOrderItem(), w.getPartNo());
            BigDecimal returnTotalQty = NumberUtil.add(qty, w.getBadInStorageQty());
            if (returnTotalQty.compareTo(w.getReturnQty()) != 0) {
                workOrderDetailMapper.update(null, Wrappers.<WmsWorkOrderDetail>lambdaUpdate()
                        .eq(WmsWorkOrderDetail::getId, w.getId())
                        .set(WmsWorkOrderDetail::getReversionLevel, "repeat oldReturnQty：" + w.getReturnQty())
                        .set(WmsWorkOrderDetail::getReturnQty, returnTotalQty));
                return;
            }

            //262过账量
            BigDecimal sub1 = NumberUtil.sub(w.getReturnQty(), w.getBadInStorageQty());
            BigDecimal sub2 = NumberUtil.sub(w.getPostTo262Qty(), w.getBadPostSapQty());
            BigDecimal post262Qty = NumberUtil.sub(sub1, sub2);

            try {
                if (post262Qty.compareTo(BigDecimal.ZERO) <= 0) {
                    return;
                }
                /*//如果组织为CABG_VN,则赋值版次为A
                if ("CABG_VN".equals(orgCode)) {
                    w.setPartVersion("A");
                }*/
                //退回大仓
                WorkOrderPostingDto input = setWorkOrderPosting262Dto(w, w.getFromWarehouseCode(), post262Qty, postDate);

                if (StringUtils.isBlank(w.getValueType())) {
                    String valueTypeValue = materialRfcService.doGetMaterialValueType(sapClientCode, w.getPlantCode(), w.getPartNo(), w.getFromWarehouseCode());
                    input.setValueType(valueTypeValue);
                } else {
                    input.setValueType(w.getValueType());
                }


                PostingSap101ReturnDto post262Dto = woRfcService.doWorkOrderPosting(sapClientCode, input);

                // update wo detail post 262 qty
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPostTo262Qty(NumberUtil.add(w.getPostTo262Qty(), post262Qty));
                updateDetail.setValueType(input.getValueType());
                updateDetail.setPost262Msg(post262Dto.getDocNumber() + " - " + LocalDateTime.now());
                updateDetail.updateById();

                //write post log
                w.setValueType(input.getValueType());
                writePostingLog(w, post262Qty, post262Dto, "262_return");

            } catch (Exception e) {
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPost262Msg("last post262 Qty:" + post262Qty + " dt:" + LocalDateTime.now() + ",sap result:" + e.getMessage());
                updateDetail.updateById();
            }
        });
    }

    /**
     * 工单detail移出量过账SAP 262
     * <p>
     * 条件：
     * 1.return_qty > post_to262_qty
     * 2.工单类型不为 CKD，MERGE
     *
     * <p>
     * 过账方式 262 ， 工单 ----> kitting     *
     * <p>
     * 使用栏位 stock_qty，move_in_qty，post_to261_qty
     */
    public void postingWoRemove262NewMode(String orgCode, String sapClientCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }

        List<WmsWorkOrderDetail> postingWoRemove262List =
                workOrderDetailMapper.selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
                        .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                        .eq(WmsWorkOrderDetail::getPostingSapStatus, 0)
                        .last(" and remove_qty > posting_sap_remove_qty"));

        if (CollUtil.isEmpty(postingWoRemove262List)) {
            return;
        }

        List<String> workOrderNoList = postingWoRemove262List.parallelStream().map(WmsWorkOrderDetail::getWorkOrderNo).distinct().collect(Collectors.toList());

        List<WmsWorkOrderHeader> woHeaderList =
                workOrderHeaderMapper.selectList(Wrappers.<WmsWorkOrderHeader>lambdaQuery().eq(WmsWorkOrderHeader::getOrgCode, orgCode).in(WmsWorkOrderHeader::getWorkOrderNo, workOrderNoList));
        postingWoRemove262List.forEach(w -> {

            if (Constants.continueJob.equalsIgnoreCase("N")) {
                return;
            }

            //过滤D工单
            if (CollUtil.isNotEmpty(woHeaderList)) {

                Optional<WmsWorkOrderHeader> woHeader = woHeaderList.stream().filter(a -> a.getWorkOrderNo().equalsIgnoreCase(w.getWorkOrderNo())).findFirst();

                if (woHeader.isPresent()) {
                    if (0 != woHeader.get().getPostSapFlag()) {
                        return;
                    }
                    if (StringUtils.isNotBlank(woHeader.get().getWorkOrderType()) && "CKD,MERGE".contains(woHeader.get().getWorkOrderType())) {
                        return;
                    }
                    //本月最后一天
                    LocalDate monthEndDay = LocalDate.now().with(TemporalAdjusters.lastDayOfMonth());
                    //本月之后的不过账
                    if (null != woHeader.get().getScheduledDate() && woHeader.get().getScheduledDate().isAfter(monthEndDay)) {
                        return;
                    }
                }
            } else {
                return;
            }

            //262过账量
            BigDecimal post262Qty = NumberUtil.sub(w.getRemoveQty(), w.getPostingSapRemoveQty());

            try {
                if (post262Qty.compareTo(BigDecimal.ZERO) <= 0) {
                    return;
                }
                /*//如果组织为CABG_VN,则赋值版次为A
                if ("CABG_VN".equals(orgCode)) {
                    w.setPartVersion("A");
                }*/
                //退回kitting 仓
                WorkOrderPostingDto input = setWorkOrderPosting262Dto(w, w.getToWarehouseCode(), post262Qty, postDate);

                if (StringUtils.isBlank(w.getValueType())) {
                    String valueTypeValue = materialRfcService.doGetMaterialValueType(sapClientCode, w.getPlantCode(), w.getPartNo(), w.getFromWarehouseCode());
                    input.setValueType(valueTypeValue);
                } else {
                    input.setValueType(w.getValueType());
                }


                PostingSap101ReturnDto post262Dto = woRfcService.doWorkOrderPosting(sapClientCode, input);

                // update wo detail post 262 qty
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPostingSapRemoveQty(w.getRemoveQty());
                updateDetail.setValueType(input.getValueType());
                updateDetail.setPostingSapRemoveNumber(post262Dto.getDocNumber());
                updateDetail.setPostingSapRemoveDt(LocalDateTime.now());
                updateDetail.setPostingSapRemoveMsg("OK");
                updateDetail.updateById();

                //write post log
                writePostingLog(w, post262Qty, post262Dto, "262_remove");

            } catch (Exception e) {
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPostingSapRemoveMsg("last post262 Qty:" + post262Qty + ",sap result:" + e.getMessage());
                updateDetail.setPostingSapRemoveDt(LocalDateTime.now());
                updateDetail.updateById();
            }
        });
    }

    /**
     * 工单detail移入量SAP 261
     * <p>
     * 条件：
     * 1.(stock_qty -move_in_qty) >post_to261_qty
     * 2.工单类型不为 CKD，MERGE
     *
     * <p>
     * 过账方式 261 ， from 大仓 ----> 工单
     * <p>
     * 使用栏位 stock_qty，move_in_qty，post_to261_qty
     */
    public void postingWoMoveIn261NewMode(String orgCode, String sapClientCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }

        //需过账261的wo detail 群组 list
        List<WmsWorkOrderDetail> postingWoMoveIn261List =
                workOrderDetailMapper.selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
                        .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                        .eq(WmsWorkOrderDetail::getPostingSapStatus, 0)
                        .last(" and move_in_qty > posting_sap_move_in_qty"));

        if (CollUtil.isEmpty(postingWoMoveIn261List)) {
            return;
        }

        List<String> workOrderNoList = postingWoMoveIn261List.parallelStream().map(WmsWorkOrderDetail::getWorkOrderNo).distinct().collect(Collectors.toList());

        //List<WmsWorkOrderHeader> ckdWoList =
//        workOrderHeaderMapper.selectList(Wrappers.<WmsWorkOrderHeader>lambdaQuery().eq(WmsWorkOrderHeader::getOrgCode, orgCode).in(WmsWorkOrderHeader::getWorkOrderNo, workOrderNoList).in
//        (WmsWorkOrderHeader::getWorkOrderType, Arrays.asList("CKD", "MERGE")));

        List<WmsWorkOrderHeader> woHeaderList =
                workOrderHeaderMapper.selectList(Wrappers.<WmsWorkOrderHeader>lambdaQuery().eq(WmsWorkOrderHeader::getOrgCode, orgCode).in(WmsWorkOrderHeader::getWorkOrderNo, workOrderNoList));


        postingWoMoveIn261List.forEach(w -> {
            if (Constants.continueJob.equalsIgnoreCase("N")) {
                return;
            }

            //过滤D工单
            if (CollUtil.isNotEmpty(woHeaderList)) {
                Optional<WmsWorkOrderHeader> woHeader = woHeaderList.stream().filter(a -> a.getWorkOrderNo().equalsIgnoreCase(w.getWorkOrderNo())).findFirst();

                if (woHeader.isPresent()) {
                    if (0 != woHeader.get().getPostSapFlag()) {
                        return;
                    }
                    if (StringUtils.isNotBlank(woHeader.get().getWorkOrderType()) && "CKD,MERGE".contains(woHeader.get().getWorkOrderType())) {
                        return;
                    }
                    //本月最后一天
                    LocalDate monthEndDay = LocalDate.now().with(TemporalAdjusters.lastDayOfMonth());
                    //本月之后的不过账
                    if (null != woHeader.get().getScheduledDate() && woHeader.get().getScheduledDate().isAfter(monthEndDay)) {
                        return;
                    }
                }
            } else {
                return;
            }

            //当前物料过账量
            BigDecimal post261Qty = BigDecimal.ZERO;
            post261Qty = NumberUtil.sub(w.getMoveInQty(), w.getPostingSapMoveInQty());

            try {
                if (post261Qty.compareTo(BigDecimal.ZERO) <= 0) {
                    return;
                }
                /*//如果组织为CABG_VN,则赋值版次为A
                if ("CABG_VN".equals(orgCode)) {
                    w.setPartVersion("A");
                }*/
                WorkOrderPostingDto input = setWorkOrderPosting261Dto(w, w.getToWarehouseCode(), post261Qty, postDate);

                if (StringUtils.isBlank(w.getValueType())) {
                    String valueTypeValue = materialRfcService.doGetMaterialValueType(sapClientCode, w.getPlantCode(), w.getPartNo(), w.getFromWarehouseCode());
                    input.setValueType(valueTypeValue);
                } else {
                    input.setValueType(w.getValueType());
                }


                PostingSap101ReturnDto postingSap101ReturnDto = woRfcService.doWorkOrderPosting(sapClientCode, input);

                // update wo detail post 261 qty
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
//                updateDetail.setPostingSapMoveInQty(NumberUtil.add(w.getPostTo261Qty(), post261Qty));
                updateDetail.setPostingSapMoveInQty(w.getMoveInQty());
                updateDetail.setValueType(input.getValueType());
                updateDetail.setPostingSapMoveInNumber(postingSap101ReturnDto.getDocNumber());
                updateDetail.setPostingSapMoveInDt(LocalDateTime.now());
                updateDetail.setPostingSapMoveInMsg("OK");
                updateDetail.updateById();
                //write post log
                writePostingLog(w, post261Qty, postingSap101ReturnDto, "261_movein");

            } catch (Exception e) {
                log.info("wo posting 261 error：wo {} ,result:{}", JSONUtil.toJsonStr(w), e.getMessage());
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPostingSapMoveInMsg("last post261 Qty:" + post261Qty + ",sap result:" + e.getMessage());
                updateDetail.setPostingSapMoveInDt(LocalDateTime.now());
                updateDetail.updateById();
            }
        });

    }


    /**
     * 报废品入库 101
     */
    public void postingScrap101(String orgCode, String sapClientCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }

        //报废品需要过账的list,已入库并且没有过账的数据
        List<WmsWorkOrderDetailScrapInStorageDetailEntity> needPosting101List =
                wmsWorkOrderDetailScrapInStorageDetailMapper.selectList(Wrappers.<WmsWorkOrderDetailScrapInStorageDetailEntity>lambdaQuery()
                        .eq(WmsWorkOrderDetailScrapInStorageDetailEntity::getOrgCode, orgCode)
//                        .in(WmsWorkOrderDetailScrapInStorageDetailEntity::getId, Arrays.asList(58))
                        .eq(WmsWorkOrderDetailScrapInStorageDetailEntity::getInStorageStatus, 'Y')
                        .apply("  (post_sap_no is null or post_sap_no = '0')"));

        if (CollUtil.isEmpty(needPosting101List)) {
            return;
        }

        needPosting101List.forEach(w -> {
            if (Constants.continueJob.equalsIgnoreCase("N")) {
                return;
            }

            if (StringUtils.isEmpty(w.getWorkOrderNo()) || StringUtils.isEmpty(w.getToWhCode())) {
                wmsWorkOrderDetailScrapInStorageDetailMapper.update(null, Wrappers.<WmsWorkOrderDetailScrapInStorageDetailEntity>lambdaUpdate()
                        .eq(WmsWorkOrderDetailScrapInStorageDetailEntity::getId, w.getId())
                        .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapMessage, "wo or whCode not exist")
                        .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapDate, LocalDateTime.now()));
            }

            //工单过账量
            BigDecimal posting101Qty = BigDecimal.valueOf(1);
            try {
                if (posting101Qty.compareTo(BigDecimal.ZERO) <= 0) {
                    return;
                }
                //准备过账DTO
                WorkOrderPostingDto dto = new WorkOrderPostingDto();
                WmsWorkOrderHeader wmsWorkOrderHeader = wmsWorkOrderHeaderMapper.selectOne(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                        .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                        .eq(WmsWorkOrderHeader::getWorkOrderNo, w.getWorkOrderNo()));
                if (!"BOARD".equalsIgnoreCase(wmsWorkOrderHeader.getProcessType())) {
                    dto.setWorkOrderNo(w.getWorkOrderNo());
                }
                dto.setPostDate(postDate);
                dto.setDocDate(postDate);
                dto.setUserName("WMS");
                dto.setHeaderText(w.getWorkOrderNo());
                dto.setMoveType("101");
                dto.setGmCode("01");
                dto.setPlant(w.getPlantCode());
                dto.setPartNo(w.getFinishedProductNo());
                // 版次没有
                //if (StringUtils.isNotBlank(w.getPartVersion())) {
                //    dto.setPartVersion(w.getPartVersion());
                //}
                dto.setQty(posting101Qty);
                dto.setUnit("EA");
                dto.setFromWarehouseName(w.getToWhCode());

                String valueTypeValue = materialRfcService.doGetMaterialValueType(sapClientCode, w.getPlantCode(), w.getFinishedProductNo(), w.getToWhCode());
                if (StrUtil.isNotEmpty(valueTypeValue)) {
                    dto.setValueType(valueTypeValue);
                } else {
                    wmsWorkOrderDetailScrapInStorageDetailMapper.update(null, Wrappers.<WmsWorkOrderDetailScrapInStorageDetailEntity>lambdaUpdate()
                            .eq(WmsWorkOrderDetailScrapInStorageDetailEntity::getId, w.getId())
                            .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapMessage, "sap value type not exist")
                            .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapDate, LocalDateTime.now()));
                    return;
                }

                //SAP 过账
                PostingSap101ReturnDto postingSap101ReturnDto = woRfcService.doWorkOrderPosting(sapClientCode, dto);
                log.info("scrap post 101 result {}", JSONUtil.toJsonStr(postingSap101ReturnDto));

                wmsWorkOrderDetailScrapInStorageDetailMapper.update(null, Wrappers.<WmsWorkOrderDetailScrapInStorageDetailEntity>lambdaUpdate()
                        .eq(WmsWorkOrderDetailScrapInStorageDetailEntity::getId, w.getId())
                        .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapNo, postingSap101ReturnDto.getDocNumber())
                        .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapMessage, postingSap101ReturnDto.getSapWo())
                        .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapQty, posting101Qty)
                        .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapDate, LocalDateTime.now()));

                //修改工单入库数量
                String result = String.format("last post Qty: %s ,sap result:[%s] [%s],dt:[%s]", posting101Qty.toString(), postingSap101ReturnDto.getDocNumber(), postingSap101ReturnDto.getSapWo(),
                        LocalDateTime.now().toString());
                LambdaUpdateWrapper<WmsWorkOrderHeader> wrapper = Wrappers.<WmsWorkOrderHeader>lambdaUpdate()
                        .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                        .eq(WmsWorkOrderHeader::getWorkOrderNo, w.getWorkOrderNo())
                        .set(WmsWorkOrderHeader::getPostTo101Msg, result);
                wrapper.setSql("inbound_qty = inbound_qty + 1 ");
                wrapper.setSql("post_to101_qty = post_to101_qty + 1 ");
                workOrderHeaderMapper.update(null, wrapper);

                //write posting log
                writePostingScrap101Log(w, posting101Qty, postingSap101ReturnDto, result);

            } catch (Exception e) {
                //update SAP error result
                wmsWorkOrderDetailScrapInStorageDetailMapper.update(null, Wrappers.<WmsWorkOrderDetailScrapInStorageDetailEntity>lambdaUpdate()
                        .eq(WmsWorkOrderDetailScrapInStorageDetailEntity::getId, w.getId())
                        .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapMessage, e.getMessage())
                        .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapDate, LocalDateTime.now()));
            }
        });
    }

    /**
     * 报废品入库 311
     */
    public void postingScrap311(String orgCode, String sapClientCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }

        //报废品需要过账的list,已入库并且没有过账的数据
        List<WmsWorkOrderDetailScrapInStorageDetailEntity> needPosting101List =
                wmsWorkOrderDetailScrapInStorageDetailMapper.selectList(Wrappers.<WmsWorkOrderDetailScrapInStorageDetailEntity>lambdaQuery()
                        .eq(WmsWorkOrderDetailScrapInStorageDetailEntity::getOrgCode, orgCode)
//                        .in(WmsWorkOrderDetailScrapInStorageDetailEntity::getId, Arrays.asList(28))
                        .eq(WmsWorkOrderDetailScrapInStorageDetailEntity::getInStorageStatus, 'Y')
                        .apply("  (post_sap_no is null or post_sap_no = '0')"));

        if (CollUtil.isEmpty(needPosting101List)) {
            return;
        }

        needPosting101List.forEach(w -> {
            if (Constants.continueJob.equalsIgnoreCase("N")) {
                return;
            }

            if (StringUtils.isEmpty(w.getFromWhCode()) || StringUtils.isEmpty(w.getToWhCode())) {
                wmsWorkOrderDetailScrapInStorageDetailMapper.update(null, Wrappers.<WmsWorkOrderDetailScrapInStorageDetailEntity>lambdaUpdate()
                        .eq(WmsWorkOrderDetailScrapInStorageDetailEntity::getId, w.getId())
                        .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapMessage, "from or to wh not exist")
                        .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapDate, LocalDateTime.now()));
                return;
            } else {
                if (w.getFromWhCode().equalsIgnoreCase(w.getToWhCode())) {
                    wmsWorkOrderDetailScrapInStorageDetailMapper.update(null, Wrappers.<WmsWorkOrderDetailScrapInStorageDetailEntity>lambdaUpdate()
                            .eq(WmsWorkOrderDetailScrapInStorageDetailEntity::getId, w.getId())
                            .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapMessage, "from or to wh is equal")
                            .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapDate, LocalDateTime.now()));
                    return;
                }

            }

            //转仓数量
            BigDecimal transferQty = BigDecimal.valueOf(1);
            try {
                if (transferQty.compareTo(BigDecimal.ZERO) <= 0) {
                    return;
                }
                //准备过账DTO
                TransferDto dto = new TransferDto();
                dto.setTransactionDate(postDate);
                dto.setDocDate(postDate);
                dto.setMoveType("311");
                dto.setGmCode("04");
                dto.setQty(transferQty.toString());
                dto.setUnit("EA");
                //301 夸工厂转仓   04
                //311 同工厂转仓   04
                //309 料调        04
                dto.setFromPlant(w.getPlantCode());
                dto.setFromWarehouseName(w.getFromWhCode());
                dto.setFromPartNo(w.getFinishedProductNo());
               /* //如果组织为CABG_VN,则赋值版次为A
                if ("CABG_VN".equals(w.getOrgCode())) {
                    dto.setFromPartVersion("A");
                    dto.setToPartVersion("A");
                } else {
                    dto.setToPartVersion("");
                }*/
                dto.setToPartVersion("");
                dto.setToPlant(w.getPlantCode());
                dto.setToWarehouseName(w.getToWhCode());
                dto.setToPartNo(w.getFinishedProductNo());

                String valueTypeValue = materialRfcService.doGetMaterialValueType(sapClientCode, w.getPlantCode(), w.getFinishedProductNo(), w.getFromWhCode());
                if (StrUtil.isNotEmpty(valueTypeValue)) {
                    dto.setValueType(valueTypeValue);
                } else {
                    wmsWorkOrderDetailScrapInStorageDetailMapper.update(null, Wrappers.<WmsWorkOrderDetailScrapInStorageDetailEntity>lambdaUpdate()
                            .eq(WmsWorkOrderDetailScrapInStorageDetailEntity::getId, w.getId())
                            .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapMessage, "sap value type not exist")
                            .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapDate, LocalDateTime.now()));
                    return;
                }

                //SAP 过账
                String s = whRfcService.doTransfer(sapClientCode, dto);

                if (StringUtils.isNotEmpty(s)) {
                    //过账成功
                    wmsWorkOrderDetailScrapInStorageDetailMapper.update(null, Wrappers.<WmsWorkOrderDetailScrapInStorageDetailEntity>lambdaUpdate()
                            .eq(WmsWorkOrderDetailScrapInStorageDetailEntity::getId, w.getId())
                            .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapNo, s)
                            .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapMessage, "311 OK")
                            .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapQty, transferQty)
                            .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapDate, LocalDateTime.now()));

                } else {
                    wmsWorkOrderDetailScrapInStorageDetailMapper.update(null, Wrappers.<WmsWorkOrderDetailScrapInStorageDetailEntity>lambdaUpdate()
                            .eq(WmsWorkOrderDetailScrapInStorageDetailEntity::getId, w.getId())
//                            .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapNo, "0")
                            .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapMessage, "SAP docNumber not generate")
                            .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapDate, LocalDateTime.now()));

                }

            } catch (Exception e) {
                //update SAP error result
                wmsWorkOrderDetailScrapInStorageDetailMapper.update(null, Wrappers.<WmsWorkOrderDetailScrapInStorageDetailEntity>lambdaUpdate()
                        .eq(WmsWorkOrderDetailScrapInStorageDetailEntity::getId, w.getId())
//                        .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapNo, "0")
                        .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapMessage, e.getMessage())
                        .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostSapDate, LocalDateTime.now()));
            }
        });
    }

    private void writePostingScrap101Log(WmsWorkOrderDetailScrapInStorageDetailEntity w, BigDecimal posting101Qty, PostingSap101ReturnDto s, String result) {
        //write post log
        WmsSapTransactionLog log = new WmsSapTransactionLog();
        log.setOrgCode(w.getOrgCode());
        log.setPlantCode(w.getPlantCode());
        log.setPartNo(w.getFinishedProductNo());
        //log.setFromWarehouseCode(w.getStorageLocation());
        log.setToWarehouseCode(w.getToWhCode());
        log.setWorkOrderNo(w.getWorkOrderNo());
        log.setPostSapReturnMsg(s.getDocNumber());
        // log.setWmsWorkOrderDetailId(w.getId());
        log.setTransactionQty(posting101Qty);
        log.setUomCode("EA");
        log.setSapUomCode("EA");
        log.setPostType("scrap_101");
        log.setSapResult(s.getSapWo());
        log.setPostSapReturnDt(LocalDateTime.now());
        log.insert();
    }

    /**
     * 工单成品入库 101
     * 工单 process_type == BOARD 为滚工单入库，由SAP决定入库工单并返回
     */
    public void postingWoHeader101(String orgCode, String sapClientCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }

        //需过账101 的wo header list
        List<WmsWorkOrderHeader> needPosting101List = workOrderHeaderMapper.selectList(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                //0527取消
                //.eq(WmsWorkOrderHeader::getWorkOrderStatus, "REL")
                .notIn(WmsWorkOrderHeader::getWorkOrderType, Arrays.asList("CKD", "MERGE"))
                .eq(WmsWorkOrderHeader::getPostSapFlag, 0)
                .apply(" inbound_qty > post_to101_qty"));

        if (CollUtil.isEmpty(needPosting101List)) {
            return;
        }

        needPosting101List.forEach(w -> {
            if (Constants.continueJob.equalsIgnoreCase("N")) {
                return;
            }

            //工单过账量
            BigDecimal posting101Qty = NumberUtil.sub(w.getInboundQty(), w.getPostTo101Qty());

            try {
                if (posting101Qty.compareTo(BigDecimal.ZERO) <= 0) {
                    return;
                }

                //准备过账DTO
                WorkOrderPostingDto dto = setWorkOrderPosting101Dto(w, posting101Qty, postDate);

                if (StringUtils.isBlank(w.getValueType())) {
//                    String valueTypeValue = materialRfcService.doGetMaterialValueType(sapClientCode, w.getPlantCode(), w.getPartNo(), w.getStorageLocation());
                    String valueTypeValue = materialRfcService.getValueType(sapClientCode, orgCode, w.getPlantCode(),
                            w.getPartNo(), w.getPartVersion(), w.getStorageLocation());
                    if (StrUtil.isNotEmpty(valueTypeValue)) {
                        dto.setValueType(valueTypeValue);
                    } else {
                        /*WmsWorkOrderHeader updateHeader = new WmsWorkOrderHeader();
                        updateHeader.setId(w.getId());
                        updateHeader.setPostTo101Msg("value type not exist " + LocalDateTime.now());
                        updateHeader.updateById();*/
                        wmsWorkOrderHeaderMapper.update(null, Wrappers.<WmsWorkOrderHeader>lambdaUpdate()
                                .eq(WmsWorkOrderHeader::getId, w.getId())
                                .set(WmsWorkOrderHeader::getPostTo101Msg, "value type not exist " + LocalDateTime.now()));
                        return;
                    }
                } else {
                    dto.setValueType(w.getValueType());
                }
                log.info("post 101 request sap {}", JSONUtil.toJsonStr(dto));
                //SAP 过账
                PostingSap101ReturnDto postingSap101ReturnDto = woRfcService.doWorkOrderPosting(sapClientCode, dto);
                log.info("post 101 result {}", JSONUtil.toJsonStr(postingSap101ReturnDto));

                //修改工单入库数量
                String result = String.format("last post Qty: %s ,sap result:[%s] [%s],dt:[%s]", posting101Qty.toString(), postingSap101ReturnDto.getDocNumber(), postingSap101ReturnDto.getSapWo(),
                        LocalDateTime.now().toString());
             /*   WmsWorkOrderHeader updateHeader = new WmsWorkOrderHeader();
                updateHeader.setId(w.getId());
                updateHeader.setPostTo101Qty(w.getInboundQty());
                updateHeader.setValueType(dto.getValueType());
                updateHeader.setPostTo101Msg(result);
                updateHeader.updateById();*/
                wmsWorkOrderHeaderMapper.update(null, Wrappers.<WmsWorkOrderHeader>lambdaUpdate()
                        .eq(WmsWorkOrderHeader::getId, w.getId())
                        .set(WmsWorkOrderHeader::getPostTo101Qty, w.getInboundQty())
                        .set(WmsWorkOrderHeader::getValueType, dto.getValueType())
                        .set(WmsWorkOrderHeader::getPostTo101Msg, result));
                //write posting log
                writePosting101Log(w, posting101Qty, postingSap101ReturnDto, result);

            } catch (Exception e) {
                //update SAP error result
                /*WmsWorkOrderHeader updateHeader = new WmsWorkOrderHeader();
                updateHeader.setId(w.getId());
                updateHeader.setPostTo101Msg("last post Qty:" + posting101Qty + " dt:" + LocalDateTime.now() + ",sap result:" + e.getMessage());
                updateHeader.updateById();*/
                wmsWorkOrderHeaderMapper.update(null, Wrappers.<WmsWorkOrderHeader>lambdaUpdate()
                        .eq(WmsWorkOrderHeader::getId, w.getId())
                        .set(WmsWorkOrderHeader::getPostTo101Msg, "last post Qty:" + posting101Qty + " dt:" + LocalDateTime.now() + ",sap result:" + e.getMessage()));
            }
        });
    }

    private void writePosting101Log(WmsWorkOrderHeader w, BigDecimal posting101Qty, PostingSap101ReturnDto s, String result) {
        //write post log
        WmsSapTransactionLog log = new WmsSapTransactionLog();
        log.setOrgCode(w.getOrgCode());
        log.setPlantCode(w.getPlantCode());
        log.setPartNo(w.getPartNo());
        log.setFromWarehouseCode(w.getStorageLocation());
        log.setToWarehouseCode(w.getStorageLocation());
        log.setWorkOrderNo(w.getWorkOrderNo());
        log.setPostSapReturnMsg(s.getDocNumber());
        // log.setWmsWorkOrderDetailId(w.getId());
        log.setTransactionQty(posting101Qty);
        log.setUomCode("EA");
        log.setSapUomCode("EA");
        log.setPostType("101");
        log.setSapResult(s.getSapWo());
        log.setPostSapReturnDt(LocalDateTime.now());
        log.insert();

    }

    private WorkOrderPostingDto setWorkOrderPosting101Dto(WmsWorkOrderHeader w, BigDecimal posting101Qty, String postDate) {
        WorkOrderPostingDto dto = new WorkOrderPostingDto();
        dto.setPostDate(postDate);
        dto.setDocDate(postDate);

        dto.setUserName("WMS");
        dto.setHeaderText(w.getWorkOrderNo());
        dto.setMoveType("101");
        dto.setGmCode("01");
        dto.setPlant(w.getPlantCode());
        if (!"BOARD".equalsIgnoreCase(w.getProcessType())) {
            dto.setWorkOrderNo(w.getWorkOrderNo());
        }
        dto.setPartNo(w.getPartNo());
        if (StringUtils.isNotBlank(w.getPartVersion())) {
            dto.setPartVersion(w.getPartVersion());
        }
        dto.setQty(posting101Qty);
        dto.setUnit("EA");
        dto.setFromWarehouseName(w.getStorageLocation());
        return dto;
    }

    private WorkOrderPostingDto setWorkOrderPosting101Dto(WmsWorkOrderHeader w, String postDate) {
        //过账 101 总量
        BigDecimal posting101Qty = NumberUtil.sub(w.getInboundQty(), w.getPostTo101Qty());

        WorkOrderPostingDto dto = setWorkOrderPosting101Dto(w, posting101Qty, postDate);
        return dto;
    }

    private WorkOrderPostingDto setWorkOrderPosting261Dto(WmsWorkOrderDetail s, String whCode, BigDecimal post261Qty, String postDate) {
        WorkOrderPostingDto input = new WorkOrderPostingDto();
        input.setPostDate(postDate);
        input.setDocDate(postDate);
        input.setUserName("WMS");
        input.setHeaderText("");
        input.setPlant(s.getPlantCode());
        input.setPartNo(s.getPartNo());
        input.setLongPartNo(s.getPartNo());
        input.setPartVersion(s.getPartVersion());
        input.setFromWarehouseName(whCode);
        input.setMoveType("261");
        input.setGmCode("03");
        input.setUnit(StringUtils.isNotEmpty(s.getSapUomCode()) ? s.getSapUomCode() : "EA");
        input.setQty(post261Qty);
        input.setValueType(s.getValueType());

        input.setWorkOrderNo(s.getWorkOrderNo());
//        input.setWorkOrderItem(s.getItemNumber());
        input.setReservationNo(s.getReservationNumber());
        input.setReservationItem(s.getReservationItem());
        return input;
    }

    private WorkOrderPostingDto setWorkOrderPosting531Dto(WmsWorkOrderDetailInStorage s, BigDecimal inStroeageQty, String postDate) {
        WorkOrderPostingDto input = new WorkOrderPostingDto();
        input.setPostDate(postDate);
        input.setDocDate(postDate);
        input.setUserName("WMS");
        input.setHeaderText("");
        input.setPlant(s.getPlantCode());
        input.setPartNo(s.getPartNo());
        input.setLongPartNo(s.getPartNo());
        input.setPartVersion(s.getPartVersion());
        input.setFromWarehouseName(s.getSapWarehouseCode());
        input.setMoveType("531");
        input.setGmCode("03");
        input.setUnit("EA");
        input.setQty(inStroeageQty);
        input.setValueType(s.getValueType());
        input.setWorkOrderNo(s.getWorkOrderNo());
        input.setReservationNo(s.getReservationNumber());
        input.setReservationItem(s.getReservationItem());
        return input;
    }

    private WorkOrderPostingDto setWorkOrderPosting262Dto(WmsWorkOrderDetail s, String whCode, BigDecimal post262Qty, String postDate) {
        WorkOrderPostingDto input = new WorkOrderPostingDto();
        input.setPostDate(postDate);
        input.setDocDate(postDate);
        input.setUserName("WMS");
        input.setHeaderText("");
        input.setPlant(s.getPlantCode());
        input.setPartNo(s.getPartNo());
        input.setLongPartNo(s.getPartNo());
        input.setPartVersion(s.getPartVersion());
        input.setFromWarehouseName(whCode);
        input.setMoveType("262");
        input.setGmCode("03");
        input.setUnit(StringUtils.isNotEmpty(s.getSapUomCode()) ? s.getSapUomCode() : "EA");
        input.setQty(post262Qty);
        input.setValueType(s.getValueType());

        input.setWorkOrderNo(s.getWorkOrderNo());
//        input.setWorkOrderItem(s.getItemNumber());
        input.setReservationNo(s.getReservationNumber());
        input.setReservationItem(s.getReservationItem());
        return input;
    }

    private void writePostingLog(WmsWorkOrderDetail w, BigDecimal postingQty, PostingSap101ReturnDto s, String postingType) {
        WmsSapTransactionLog log = new WmsSapTransactionLog();
        log.setOrgCode(w.getOrgCode());
        log.setPlantCode(w.getPlantCode());
        log.setPartNo(w.getPartNo());
        log.setFromWarehouseCode(w.getFromWarehouseCode());
        log.setToWarehouseCode(w.getToWarehouseCode());
        log.setWorkOrderNo(w.getWorkOrderNo());
        log.setWmsWorkOrderDetailId(w.getId());
        log.setTransactionQty(postingQty);
        log.setUomCode(w.getUomCode());
        log.setSapUomCode(w.getSapUomCode());
        log.setPostType(postingType);
        log.setPostSapReturnMsg(s.getDocNumber());
        log.setFromDocNo(w.getWorkOrderNo());
        log.setPostSapReturnFlag(1);
        log.setTransactionSapQty(postingQty);
        log.setTransactionDate(LocalDateTime.now());
        log.setCreator(postingType);
        log.setCreatedDt(LocalDateTime.now());
        log.setValueType(w.getValueType());
        log.setSapResult(s.getSapWo());
        log.insert();
    }

    private void writePosting531Log(WmsWorkOrderDetailInStorage w, BigDecimal postingQty, PostingSap101ReturnDto s, String postingType) {
        WmsSapTransactionLog log = new WmsSapTransactionLog();
        log.setOrgCode(w.getOrgCode());
        log.setPlantCode(w.getPlantCode());
        log.setPartNo(w.getPartNo());
        log.setFromWarehouseCode(w.getSapWarehouseCode());
        log.setToWarehouseCode(w.getSapWarehouseCode());
        log.setWorkOrderNo(w.getWorkOrderNo());
        log.setWmsWorkOrderDetailId(w.getId());
        log.setTransactionQty(postingQty);
        log.setUomCode(w.getUomCode());
        log.setSapUomCode(w.getUomCode());
        log.setPostType(postingType);
        log.setPostSapReturnMsg(s.getDocNumber());
        log.setFromDocNo(w.getWorkOrderNo());
        log.setPostSapReturnFlag(1);
        log.setTransactionSapQty(postingQty);
        log.setTransactionDate(LocalDateTime.now());
        log.setCreator(postingType);
        log.setCreatedDt(LocalDateTime.now());
        log.setValueType(w.getValueType());
        log.setSapResult(s.getSapWo());
        log.insert();
    }

    private TransferDto setTransfer311Dto(WmsWorkOrderDetail w, BigDecimal postingQty, String postDate) {
        TransferDto dto = new TransferDto();
        dto.setTransactionDate(postDate);
        dto.setDocDate(postDate);
        dto.setMoveType("311");
        dto.setGmCode("04");
        dto.setQty(postingQty.toString());
        dto.setUnit(w.getSapUomCode());
        //301 夸工厂转仓   04
        //311 同工厂转仓   04
        //309 料调        04
        dto.setFromPlant(w.getPlantCode());
        dto.setFromWarehouseName(w.getFromWarehouseCode());
        dto.setFromPartNo(w.getPartNo());
        if (StringUtils.isNotBlank(w.getPartVersion())) {
            dto.setFromPartVersion(w.getPartVersion());
            dto.setToPartVersion(w.getPartVersion());
        }
        dto.setToPlant(w.getPlantCode());
        dto.setToWarehouseName(w.getToWarehouseCode());
        dto.setToPartNo(w.getPartNo());
        return dto;
    }


    public void postingWoDetail311To261InAssyTemp(String orgCode, String sapClientCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }

        //需过账261的wo detail 群组 list
        List<WmsWorkOrderDetail> woNeedToPosting261List =
                workOrderDetailMapper.selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery().eq(WmsWorkOrderDetail::getOrgCode, orgCode).eq(WmsWorkOrderDetail::getPostingSapStatus, 1).last(" and " +
                        "mrp_controller  in  ('J00','J01','J02') and post_to311_qty  > post_to261_qty"));

        if (CollUtil.isEmpty(woNeedToPosting261List)) {
            return;
        }

        List<String> workOrderNoList = woNeedToPosting261List.parallelStream().map(WmsWorkOrderDetail::getWorkOrderNo).distinct().collect(Collectors.toList());

        List<WmsWorkOrderHeader> ckdWoList =
                workOrderHeaderMapper.selectList(Wrappers.<WmsWorkOrderHeader>lambdaQuery().eq(WmsWorkOrderHeader::getOrgCode, orgCode).in(WmsWorkOrderHeader::getWorkOrderNo, workOrderNoList).in(WmsWorkOrderHeader::getWorkOrderType, Arrays.asList("CKD", "MERGE")));

        woNeedToPosting261List.forEach(w -> {

            //过滤CKD工单
            if (CollUtil.isNotEmpty(ckdWoList)) {
                long count = ckdWoList.stream().filter(a -> a.getWorkOrderNo().equalsIgnoreCase(w.getWorkOrderNo())).count();
                if (count > 0) {
                    return;
                }

            }

            //当前物料过账量
            BigDecimal post261Qty = BigDecimal.ZERO;
            post261Qty = NumberUtil.sub(w.getPostTo311Qty(), w.getPostTo261Qty());

            try {
                if (post261Qty.compareTo(BigDecimal.ZERO) < 0) {
                    return;
                }

                WorkOrderPostingDto input = setWorkOrderPosting261Dto(w, w.getToWarehouseCode(), post261Qty, postDate);

                if (StringUtils.isBlank(w.getValueType())) {
                    String valueTypeValue = materialRfcService.doGetMaterialValueType(sapClientCode, w.getPlantCode(), w.getPartNo(), w.getFromWarehouseCode());
                    input.setValueType(valueTypeValue);
                } else {
                    input.setValueType(w.getValueType());
                }


                PostingSap101ReturnDto postingSap101ReturnDto = woRfcService.doWorkOrderPosting(sapClientCode, input);

                // update wo detail post 261 qty
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPostTo261Qty(NumberUtil.add(w.getPostTo261Qty(), post261Qty));
                updateDetail.setValueType(input.getValueType());
                updateDetail.setPostTo261ReturnMsg(postingSap101ReturnDto.getDocNumber());
                updateDetail.setPostTo261LastDt(LocalDateTime.now());
                updateDetail.updateById();

                //write post log
                writePostingLog(w, post261Qty, postingSap101ReturnDto, "261_wo");

            } catch (Exception e) {
                log.info("wo posting 261 error：wo {} ,result:{}", JSONUtil.toJsonStr(w), e.getMessage());
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPostTo261ReturnMsg("last post261 Qty:" + post261Qty + ",sap result:" + e.getMessage());
                updateDetail.setPostTo261LastDt(LocalDateTime.now());
                updateDetail.updateById();
            }
        });

    }

    public void postingWoDetail311To261InBoradTemp(String orgCode, String sapClientCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }
        //需过账261的wo detail 群组 list
        List<WmsWorkOrderDetail> woNeedToPosting261List =
                workOrderDetailMapper.selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
                        .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                        //.eq(WmsWorkOrderDetail::getId, 127697)
                        .eq(WmsWorkOrderDetail::getPostingSapStatus, 1)
                        .last(" and mrp_controller = 'J03' and (post_to311_qty  - post_to261_qty - return_qty ) > 0 "));

        if (CollUtil.isEmpty(woNeedToPosting261List)) {
            return;
        }

        List<String> workOrderNoList = woNeedToPosting261List.parallelStream().map(WmsWorkOrderDetail::getWorkOrderNo).distinct().collect(Collectors.toList());

        List<WmsWorkOrderHeader> ckdWoList =
                workOrderHeaderMapper.selectList(Wrappers.<WmsWorkOrderHeader>lambdaQuery().eq(WmsWorkOrderHeader::getOrgCode, orgCode).in(WmsWorkOrderHeader::getWorkOrderNo, workOrderNoList).in(WmsWorkOrderHeader::getWorkOrderType, Arrays.asList("CKD", "MERGE")));

        woNeedToPosting261List.forEach(w -> {

            //过滤CKD工单
            if (CollUtil.isNotEmpty(ckdWoList)) {
                long count = ckdWoList.stream().filter(a -> a.getWorkOrderNo().equalsIgnoreCase(w.getWorkOrderNo())).count();
                if (count > 0) {
                    return;
                }

            }

            //当前物料过账量
            BigDecimal post261Qty = BigDecimal.ZERO;
            post261Qty = NumberUtil.sub(w.getPostTo311Qty(), w.getPostTo261Qty(), w.getReturnQty());

            try {
                if (post261Qty.compareTo(BigDecimal.ZERO) < 0) {
                    return;
                }

                WorkOrderPostingDto input = setWorkOrderPosting261Dto(w, w.getToWarehouseCode(), post261Qty, postDate);

                if (StringUtils.isBlank(w.getValueType())) {
                    String valueTypeValue = materialRfcService.doGetMaterialValueType(sapClientCode, w.getPlantCode(), w.getPartNo(), w.getToWarehouseCode());
                    input.setValueType(valueTypeValue);
                } else {
                    input.setValueType(w.getValueType());
                }


                PostingSap101ReturnDto postingSap101ReturnDto = woRfcService.doWorkOrderPosting(sapClientCode, input);

                // update wo detail post 261 qty
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPostTo261Qty(NumberUtil.add(w.getPostTo261Qty(), post261Qty));
                updateDetail.setValueType(input.getValueType());
                updateDetail.setPostTo261ReturnMsg(postingSap101ReturnDto.getDocNumber() + "kitting to wo");
                updateDetail.setPostTo261LastDt(LocalDateTime.now());
                updateDetail.updateById();

                //write post log
                writePostingLog(w, post261Qty, postingSap101ReturnDto, "261_k_wo");

            } catch (Exception e) {
                log.info("wo posting 261 error：wo {} ,result:{}", JSONUtil.toJsonStr(w), e.getMessage());
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPostTo261ReturnMsg("last post261 k to wo Qty:" + post261Qty + ",sap result:" + e.getMessage());
                updateDetail.setPostTo261LastDt(LocalDateTime.now());
                updateDetail.updateById();
            }
        });

    }

    public void postingWoDetailStockTo261AssyTemp(String orgCode, String sapClientCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }

        //需过账261的wo detail 群组 list
        List<WmsWorkOrderDetail> woNeedToPosting261List =
                workOrderDetailMapper.selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
                        .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                        //.eq(WmsWorkOrderDetail::getId, 78400)
                        .eq(WmsWorkOrderDetail::getPostingSapStatus, 1)
                        .last(" and mrp_controller  in  ('J03') and  stock_qty  > post_to311_qty  and work_order_no  not like 'MERGE%' and  material_group is null"));

        if (CollUtil.isEmpty(woNeedToPosting261List)) {
            return;
        }

        List<String> workOrderNoList = woNeedToPosting261List.parallelStream().map(WmsWorkOrderDetail::getWorkOrderNo).distinct().collect(Collectors.toList());

        List<WmsWorkOrderHeader> ckdWoList =
                workOrderHeaderMapper.selectList(Wrappers.<WmsWorkOrderHeader>lambdaQuery().eq(WmsWorkOrderHeader::getOrgCode, orgCode).in(WmsWorkOrderHeader::getWorkOrderNo, workOrderNoList).in(WmsWorkOrderHeader::getWorkOrderType, Arrays.asList("CKD", "MERGE")));

        woNeedToPosting261List.forEach(w -> {

            //过滤CKD工单
            if (CollUtil.isNotEmpty(ckdWoList)) {
                long count = ckdWoList.stream().filter(a -> a.getWorkOrderNo().equalsIgnoreCase(w.getWorkOrderNo())).count();
                if (count > 0) {
                    return;
                }
            }

            //当前物料过账量
            BigDecimal post261Qty = BigDecimal.ZERO;
            post261Qty = NumberUtil.sub(w.getStockQty(), w.getPostTo311Qty());

            try {
                if (post261Qty.compareTo(BigDecimal.ZERO) <= 0) {
                    return;
                }

                WorkOrderPostingDto input = setWorkOrderPosting261Dto(w, w.getFromWarehouseCode(), post261Qty, postDate);

                if (StringUtils.isBlank(w.getValueType())) {
                    String valueTypeValue = materialRfcService.doGetMaterialValueType(sapClientCode, w.getPlantCode(), w.getPartNo(), w.getFromWarehouseCode());
                    input.setValueType(valueTypeValue);
                } else {
                    input.setValueType(w.getValueType());
                }

                PostingSap101ReturnDto postingSap101ReturnDto = woRfcService.doWorkOrderPosting(sapClientCode, input);

                // update wo detail post 261 qty
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPostTo261Qty(NumberUtil.add(w.getPostTo261Qty(), post261Qty));
                updateDetail.setValueType(input.getValueType());
                updateDetail.setPostTo261ReturnMsg(postingSap101ReturnDto.getDocNumber());
                updateDetail.setPostTo261LastDt(LocalDateTime.now());
                updateDetail.setMaterialGroup(postingSap101ReturnDto.getDocNumber() + "_" + post261Qty);
                updateDetail.updateById();
                //write post log
                writePostingLog(w, post261Qty, postingSap101ReturnDto, "261_wo0309");

            } catch (Exception e) {
                log.info("wo posting 261 error：wo {} ,result:{}", JSONUtil.toJsonStr(w), e.getMessage());
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPostTo261ReturnMsg("last post261 Qty:" + post261Qty + ",sap result:" + e.getMessage());
                updateDetail.setPostTo261LastDt(LocalDateTime.now());
                updateDetail.updateById();
            }
        });

    }


    public void postingJ03WoReturnWh262NewModeTemp(String orgCode, String sapClientCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }

        List<WmsSapTransactionLog> post262List = wmsSapTransactionLogMapper.selectList(Wrappers.<WmsSapTransactionLog>lambdaQuery()
                .eq(WmsSapTransactionLog::getOrgCode, orgCode)
                .last(" and post_type  = '261_wo' and work_order_no  in (select work_order_no from wms_work_order_header where mrp_controller  = 'J03')"));

        if (CollUtil.isEmpty(post262List)) {
            return;
        }

        List<String> workOrderNoList = post262List.parallelStream().map(WmsSapTransactionLog::getWorkOrderNo).distinct().collect(Collectors.toList());

        List<WmsWorkOrderHeader> ckdWoList =
                workOrderHeaderMapper.selectList(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                        .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                        .in(WmsWorkOrderHeader::getWorkOrderNo, workOrderNoList)
                        .in(WmsWorkOrderHeader::getWorkOrderType, Arrays.asList("CKD", "MERGE")));

        post262List.forEach(w -> {
            //过滤CKD工单
            if (CollUtil.isNotEmpty(ckdWoList)) {
                long count = ckdWoList.stream().filter(a -> a.getWorkOrderNo().equalsIgnoreCase(w.getWorkOrderNo())).count();
                if (count > 0) {
                    return;
                }
            }

            WmsWorkOrderDetail detail = workOrderDetailMapper.selectById(w.getWmsWorkOrderDetailId());

            //262过账量
            BigDecimal post262Qty = w.getTransactionQty();

            try {
                if (post262Qty.compareTo(BigDecimal.ZERO) < 0) {
                    return;
                }

                if (NumberUtil.sub(detail.getPostTo261Qty(), post262Qty).compareTo(BigDecimal.ZERO) < 0) {
                    return;
                }


                //退回kitting 仓
                WorkOrderPostingDto input = setWorkOrderPosting262Dto(detail, w.getFromWarehouseCode(), post262Qty, postDate);

                if (StringUtils.isBlank(w.getValueType())) {
                    String valueTypeValue = materialRfcService.doGetMaterialValueType(sapClientCode, w.getPlantCode(), w.getPartNo(), w.getFromWarehouseCode());
                    input.setValueType(valueTypeValue);
                } else {
                    input.setValueType(w.getValueType());
                }


                PostingSap101ReturnDto post262Dto = woRfcService.doWorkOrderPosting(sapClientCode, input);

                // update wo detail post 262 qty
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getWmsWorkOrderDetailId());
                updateDetail.setValueType(input.getValueType());
                updateDetail.setPostTo261Qty(NumberUtil.sub(detail.getPostTo261Qty(), post262Qty));
                updateDetail.updateById();

                wmsSapTransactionLogMapper.update(null, Wrappers.<WmsSapTransactionLog>lambdaUpdate()
                        .eq(WmsSapTransactionLog::getId, w.getId())
                        .set(WmsSapTransactionLog::getPostType, "261_wo_del"));

                //write post log
                writePostingLog(detail, post262Qty, post262Dto, "262_temp0307");

            } catch (Exception e) {
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getWmsWorkOrderDetailId());
                updateDetail.setPost262Msg("last 262_temp0307 Qty:" + post262Qty + ",sap result:" + e.getMessage());
                updateDetail.updateById();
            }
        });
    }

    //kitting  to 大仓
    public void postingWoDetail311NewModeTemp(String orgCode, String sapClientCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }
        //需过账311的wo detail list
        List<WmsWorkOrderDetail> woDetailList = workOrderDetailMapper.selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
                .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                //.eq(WmsWorkOrderDetail::getId, 77802)
                .last(" and   return_qty  > post_return_to311_qty AND posting_sap_status ='1' and work_order_no  not like 'MERGE%'"));

        if (CollUtil.isEmpty(woDetailList)) {
            return;
        }

        woDetailList.forEach(w -> {

            BigDecimal postingQty = NumberUtil.sub(w.getReturnQty(), w.getPostReturnTo311Qty());
            try {

                if (postingQty.compareTo(BigDecimal.ZERO) <= 0) {
                    return;
                }

                TransferDto dto = setTransfer311Dto(w, postingQty, postDate);

                if (StringUtils.isBlank(w.getValueType())) {
                    String valueTypeValue = materialRfcService.doGetMaterialValueType(sapClientCode, w.getPlantCode(), w.getPartNo(), w.getFromWarehouseCode());
                    dto.setValueType(valueTypeValue);
                } else {
                    dto.setValueType(w.getValueType());
                }

                String s = whRfcService.doTransfer(sapClientCode, dto);
                // update wo detail post 311 qty
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPostReturnTo311Qty(w.getReturnQty());
                updateDetail.setPostReturn311Msg(s + " _ " + postingQty + " _ " + LocalDateTime.now());
                updateDetail.updateById();

                //write post log
                PostingSap101ReturnDto posrtingResult = new PostingSap101ReturnDto();

                posrtingResult.setDocNumber(s);

                writePostingLog(w, postingQty, posrtingResult, "311_return0311");

            } catch (Exception e) {
                log.error("wo posting 311 error  wo {} ,errorMsg:{}", JSONUtil.toJsonStr(w), e.getMessage());
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPostReturn311Msg("last post311 Qty:" + postingQty + " _ " + LocalDateTime.now() + ",sap result:" + e.getMessage());
                updateDetail.updateById();
            }
        });
    }


    //不良品QMS领用过账到QMS仓码 311
    public void scrapPostingQmsWarehouseCodeBy311(String orgCode, String sapClientCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }

        List<WmsBadProductInStorageEntity> postingList = wmsBadProductInStorageMapper.selectList(Wrappers.<WmsBadProductInStorageEntity>lambdaQuery()
                .eq(WmsBadProductInStorageEntity::getOrgCode, orgCode)
                .last(" and issue_flag='2' and (issue_post_no is null or issue_post_no='')")
        );

        if (CollUtil.isEmpty(postingList)) {
            return;
        }

        postingList.forEach(w -> {

            if (Constants.continueJob.equalsIgnoreCase("N")) {
                return;
            }

            // 过账数量
            BigDecimal postingQty = w.getQty();
            try {

                if (postingQty.compareTo(BigDecimal.ZERO) <= 0) {
                    return;
                }

                if (StringUtils.isEmpty(w.getBadWarehouseCode()) || StringUtils.isEmpty(w.getIssueWarehouseCode())) {
                    wmsBadProductInStorageMapper.update(null, Wrappers.<WmsBadProductInStorageEntity>lambdaUpdate()
                            .eq(WmsBadProductInStorageEntity::getId, w.getId())
                            .set(WmsBadProductInStorageEntity::getIssuePostNo, "")
                            .set(WmsBadProductInStorageEntity::getIssuePostMsg, "wh not exist")
                            .set(WmsBadProductInStorageEntity::getIssuePostDateTime, LocalDateTime.now())
                    );
                    return;
                }

                TransferDto dto = new TransferDto();
                dto.setTransactionDate(postDate);
                dto.setDocDate(postDate);
                dto.setMoveType("311");
                dto.setGmCode("04");
                dto.setQty(postingQty.toString());
                dto.setUnit("EA");
                //301 夸工厂转仓   04
                //311 同工厂转仓   04
                //309 料调        04
                dto.setFromPlant(w.getPlantCode());
                dto.setFromWarehouseName(w.getBadWarehouseCode());
                dto.setFromPartNo(w.getPartNo());
                dto.setToPlant(w.getPlantCode());
                dto.setToWarehouseName(w.getIssueWarehouseCode());
                dto.setToPartNo(w.getPartNo());
                String valueTypeValue = materialRfcService.doGetMaterialValueType(sapClientCode, w.getPlantCode(), w.getPartNo(), w.getBadWarehouseCode());
                if (StringUtils.isEmpty(valueTypeValue)) {
                    wmsBadProductInStorageMapper.update(null, Wrappers.<WmsBadProductInStorageEntity>lambdaUpdate()
                            .eq(WmsBadProductInStorageEntity::getId, w.getId())
                            .set(WmsBadProductInStorageEntity::getIssuePostNo, "")
                            .set(WmsBadProductInStorageEntity::getIssuePostMsg, "valueType not exist")
                            .set(WmsBadProductInStorageEntity::getIssuePostDateTime, LocalDateTime.now())
                    );
                    return;

                }
                dto.setValueType(valueTypeValue);
                String s = whRfcService.doTransfer(sapClientCode, dto);
                wmsBadProductInStorageMapper.update(null, Wrappers.<WmsBadProductInStorageEntity>lambdaUpdate()
                        .eq(WmsBadProductInStorageEntity::getId, w.getId())
                        .set(WmsBadProductInStorageEntity::getIssuePostNo, s)
                        .set(WmsBadProductInStorageEntity::getIssuePostMsg, "OK")
                        .set(WmsBadProductInStorageEntity::getIssuePostDateTime, LocalDateTime.now())
                );
            } catch (Exception e) {
                log.error("scrapPostingQmsWarehouseCodeBy311 error  post:{} ,errorMsg:{}", JSONUtil.toJsonStr(w), e.getMessage());
                wmsBadProductInStorageMapper.update(null, Wrappers.<WmsBadProductInStorageEntity>lambdaUpdate()
                        .eq(WmsBadProductInStorageEntity::getId, w.getId())
                        .set(WmsBadProductInStorageEntity::getIssuePostNo, "")
                        .set(WmsBadProductInStorageEntity::getIssuePostMsg, e.getMessage())
                        .set(WmsBadProductInStorageEntity::getIssuePostDateTime, LocalDateTime.now())
                );
            }
        });
    }


    //不良品QMS退回过账至指定仓码 311
    public void scrapPostingQmsReturnBy311(String orgCode, String sapClientCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }

        List<WmsBadProductInStorageEntity> postingList = wmsBadProductInStorageMapper.selectList(Wrappers.<WmsBadProductInStorageEntity>lambdaQuery()
                .eq(WmsBadProductInStorageEntity::getOrgCode, orgCode)
                .last(" and return_flag='2' and (return_post_no is null or return_post_no='')")
        );

        if (CollUtil.isEmpty(postingList)) {
            return;
        }

        postingList.forEach(w -> {

            if (Constants.continueJob.equalsIgnoreCase("N")) {
                return;
            }

            // 过账数量
            BigDecimal postingQty = w.getQty();
            try {

                if (postingQty.compareTo(BigDecimal.ZERO) <= 0) {
                    return;
                }

                if (StringUtils.isEmpty(w.getBadWarehouseCode()) || StringUtils.isEmpty(w.getIssueWarehouseCode())) {
                    wmsBadProductInStorageMapper.update(null, Wrappers.<WmsBadProductInStorageEntity>lambdaUpdate()
                            .eq(WmsBadProductInStorageEntity::getId, w.getId())
                            .set(WmsBadProductInStorageEntity::getIssuePostNo, "")
                            .set(WmsBadProductInStorageEntity::getIssuePostMsg, "wh not exist")
                            .set(WmsBadProductInStorageEntity::getIssuePostDateTime, LocalDateTime.now())
                    );
                    return;
                }

                TransferDto dto = new TransferDto();
                dto.setTransactionDate(postDate);
                dto.setDocDate(postDate);
                dto.setMoveType("311");
                dto.setGmCode("04");
                dto.setQty(postingQty.toString());
                dto.setUnit("EA");
                //301 夸工厂转仓   04
                //311 同工厂转仓   04
                //309 料调        04
                dto.setFromPlant(w.getPlantCode());
                dto.setFromWarehouseName(w.getIssueWarehouseCode());
                dto.setFromPartNo(w.getPartNo());
                dto.setToPlant(w.getPlantCode());
                dto.setToWarehouseName(w.getReturnWarehouseCode());
                dto.setToPartNo(w.getPartNo());
                String valueTypeValue = materialRfcService.doGetMaterialValueType(sapClientCode, w.getPlantCode(), w.getPartNo(), w.getIssueWarehouseCode());
                if (StringUtils.isEmpty(valueTypeValue)) {
                    wmsBadProductInStorageMapper.update(null, Wrappers.<WmsBadProductInStorageEntity>lambdaUpdate()
                            .eq(WmsBadProductInStorageEntity::getId, w.getId())
                            .set(WmsBadProductInStorageEntity::getReturnPostNo, "")
                            .set(WmsBadProductInStorageEntity::getReturnPostMsg, "valueType not exist")
                            .set(WmsBadProductInStorageEntity::getReturnPostDateTime, LocalDateTime.now())
                    );
                    return;

                }
                dto.setValueType(valueTypeValue);
                String s = whRfcService.doTransfer(sapClientCode, dto);
                wmsBadProductInStorageMapper.update(null, Wrappers.<WmsBadProductInStorageEntity>lambdaUpdate()
                        .eq(WmsBadProductInStorageEntity::getId, w.getId())
                        .set(WmsBadProductInStorageEntity::getReturnPostNo, s)
                        .set(WmsBadProductInStorageEntity::getReturnPostMsg, "OK")
                        .set(WmsBadProductInStorageEntity::getReturnPostDateTime, LocalDateTime.now())
                );
            } catch (Exception e) {
                log.error("scrapPostingQmsReturnBy311 error  post:{} ,errorMsg:{}", JSONUtil.toJsonStr(w), e.getMessage());
                wmsBadProductInStorageMapper.update(null, Wrappers.<WmsBadProductInStorageEntity>lambdaUpdate()
                        .eq(WmsBadProductInStorageEntity::getId, w.getId())
                        .set(WmsBadProductInStorageEntity::getReturnPostNo, "")
                        .set(WmsBadProductInStorageEntity::getReturnPostMsg, e.getMessage())
                        .set(WmsBadProductInStorageEntity::getReturnPostDateTime, LocalDateTime.now())
                );
            }
        });
    }

    /**
     * 机构段工单成品入库 101
     */
    public void postingCmbWoHeader101(String orgCode, String sapClientCode, String postDate) {
        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }
        //需过账101 的wo header list
        List<WmsWorkOrderHeader> needPosting101List = workOrderHeaderMapper.selectList(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                .notIn(WmsWorkOrderHeader::getWorkOrderType, Arrays.asList("CKD", "MERGE"))
                .eq(WmsWorkOrderHeader::getPostSapFlag, 0)
                .apply(" inbound_qty > post_to101_qty"));
        if (CollUtil.isEmpty(needPosting101List)) {
            return;
        }
        needPosting101List.forEach(w -> {
            if (Constants.continueJob.equalsIgnoreCase("N")) {
                return;
            }
            //工单过账量
            BigDecimal posting101Qty = NumberUtil.sub(w.getInboundQty(), w.getPostTo101Qty());
            try {
                if (posting101Qty.compareTo(BigDecimal.ZERO) <= 0) {
                    return;
                }
                String valueType;
                if (StringUtils.isBlank(w.getValueType())) {
                    String valueTypeValue = materialRfcService.getValueType(sapClientCode, orgCode, w.getPlantCode(),
                            w.getPartNo(), w.getPartVersion(), w.getStorageLocation());
                    if (StrUtil.isNotEmpty(valueTypeValue)) {
                        valueType = valueTypeValue;
                    } else {
                        wmsWorkOrderHeaderMapper.update(null, Wrappers.<WmsWorkOrderHeader>lambdaUpdate()
                                .eq(WmsWorkOrderHeader::getId, w.getId())
                                .set(WmsWorkOrderHeader::getPostTo101Msg, "value type not exist " + LocalDateTime.now()));
                        return;
                    }
                } else {
                    valueType = w.getValueType();
                }
                //SAP 过账
                BaoGongDto baoGongDto = new BaoGongDto();
                baoGongDto.setPostDate(postDate);
                baoGongDto.setWorkOrderNo(w.getWorkOrderNo());
                baoGongDto.setQty(posting101Qty.intValue());
                baoGongDto.setUnit("EA");
                log.info("postBaoGong 101 request sap {}", JSONUtil.toJsonStr(baoGongDto));
                String sapResult = woRfcService.doWorkOrderBaoGong(sapClientCode, baoGongDto);
                log.info("postBaoGong 101 result {}", sapResult);
                if (!"OK".equals(sapResult)) {
                    throw new Exception(sapResult);
                }
                //修改工单入库数量
                String result = String.format("last post Qty: %s ,sap result:[%s],dt:[%s]", posting101Qty,
                        sapResult, LocalDateTime.now());
                wmsWorkOrderHeaderMapper.update(null, Wrappers.<WmsWorkOrderHeader>lambdaUpdate()
                        .eq(WmsWorkOrderHeader::getId, w.getId())
                        .set(WmsWorkOrderHeader::getPostTo101Qty, w.getInboundQty())
                        .set(WmsWorkOrderHeader::getValueType, valueType)
                        .set(WmsWorkOrderHeader::getPostTo101Msg, result));
                //write posting log
                PostingSap101ReturnDto postingSap101ReturnDto = new PostingSap101ReturnDto();
                postingSap101ReturnDto.setSapWo(sapResult);
                postingSap101ReturnDto.setDocNumber(sapResult);
                writePosting101Log(w, posting101Qty, postingSap101ReturnDto, result);
            } catch (Exception e) {
                wmsWorkOrderHeaderMapper.update(null, Wrappers.<WmsWorkOrderHeader>lambdaUpdate()
                        .eq(WmsWorkOrderHeader::getId, w.getId())
                        .set(WmsWorkOrderHeader::getPostTo101Msg, "last post Qty:" + posting101Qty + " dt:" + LocalDateTime.now() + ",sap result:" + e.getMessage()));
            }
        });
    }

    public void postingWoDetail961Mode(String orgCode, String sapClientCode, String postDate){
        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }
        //需过账261的wo detail 群组 list
        List<WmsWorkOrderDetail> woNeedToPosting961List =
                workOrderDetailMapper.selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
                        .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                        //.eq(WmsWorkOrderDetail::getWorkOrderNo, "000400001613")
                        .eq(WmsWorkOrderDetail::getPostingSapStatus, 0)
                        .last(" and work_order_no not like 'CKD%'  and work_order_no  not like 'MERGE%' " +
                                "and stock_to961_qty > post_to961_qty"));
        if (CollUtil.isEmpty(woNeedToPosting961List)) {
            return;
        }
        List<String> workOrderNoList = woNeedToPosting961List.parallelStream()
                .map(WmsWorkOrderDetail::getWorkOrderNo).distinct().collect(Collectors.toList());
        List<WmsWorkOrderHeader> woHeaderList =
                workOrderHeaderMapper.selectList(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                        .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                        .in(WmsWorkOrderHeader::getWorkOrderNo, workOrderNoList));
        woNeedToPosting961List.forEach(w -> {
            if ("N".equalsIgnoreCase(Constants.continueJob)) {
                return;
            }
            //过滤D工单
            if (CollUtil.isNotEmpty(woHeaderList)) {
                Optional<WmsWorkOrderHeader> woHeader = woHeaderList.stream()
                        .filter(a -> a.getWorkOrderNo().equalsIgnoreCase(w.getWorkOrderNo())).findFirst();
                if (woHeader.isPresent()) {
                    if (0 != woHeader.get().getPostSapFlag()) {
                        return;
                    }
                    if (StringUtils.isNotBlank(woHeader.get().getWorkOrderType()) &&
                            "CKD,MERGE".contains(woHeader.get().getWorkOrderType())) {
                        return;
                    }
                    //本月最后一天
                    LocalDate monthEndDay = LocalDate.now().with(TemporalAdjusters.lastDayOfMonth());
                    //本月之后的不过账
                    if (null != woHeader.get().getScheduledDate() && woHeader.get()
                            .getScheduledDate().isAfter(monthEndDay)) {
                        return;
                    }
                }
            } else {
                return;
            }
            //当前物料过账量
            BigDecimal post961Qty;
            post961Qty = NumberUtil.sub(w.getStockTo961Qty(), w.getPostTo961Qty());
            try {
                if (post961Qty.compareTo(BigDecimal.ZERO) <= 0) {
                    return;
                }
                WorkOrderPostingDto input = setWorkOrderPosting961Dto(w, w.getFromWarehouseCode(),
                        post961Qty, postDate);
                if (StringUtils.isBlank(w.getValueType())) {
                    String valueTypeValue = materialRfcService.doGetMaterialValueType(sapClientCode,
                            w.getPlantCode(), w.getPartNo(), w.getFromWarehouseCode());
                    input.setValueType(valueTypeValue);
                } else {
                    input.setValueType(w.getValueType());
                }
                log.info("POST_961_WO_{}_PART_{} input {}", input.getWorkOrderNo(),
                            input.getPartNo(), JSONUtil.toJsonStr(input));
                PostingSap101ReturnDto postingSap101ReturnDto = woRfcService.doWorkOrderPosting(sapClientCode,
                        input);
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPostTo961Qty(NumberUtil.add(w.getPostTo961Qty(), post961Qty));
                updateDetail.setValueType(input.getValueType());
                updateDetail.setPostTo961ReturnMsg(postingSap101ReturnDto.getDocNumber());
                updateDetail.setPostTo961LastDt(LocalDateTime.now());
                updateDetail.updateById();
                //write post log
                writePostingLog(w, post961Qty, postingSap101ReturnDto, "961_wo");
            } catch (Exception e) {
                log.info("wo posting 261 error：wo {} ,result:{}", JSONUtil.toJsonStr(w), e.getMessage());
                WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
                updateDetail.setId(w.getId());
                updateDetail.setPostTo961ReturnMsg("last post961 Qty:" + post961Qty + ",sap result:"
                        + e.getMessage());
                updateDetail.setPostTo961LastDt(LocalDateTime.now());
                updateDetail.updateById();
            }
        });
    }

    private WorkOrderPostingDto setWorkOrderPosting961Dto(WmsWorkOrderDetail s, String whCode,
                                                          BigDecimal post961Qty, String postDate) {
        WorkOrderPostingDto input = new WorkOrderPostingDto();
        input.setPostDate(postDate);
        input.setDocDate(postDate);
        input.setUserName("WMS");
        input.setHeaderText("");
        input.setPlant(s.getPlantCode());
        input.setPartNo(s.getPartNo());
        input.setLongPartNo(s.getPartNo());
        input.setPartVersion(s.getPartVersion());
        input.setFromWarehouseName(whCode);
        input.setMoveType("961");
        input.setGmCode("03");
        input.setUnit(StringUtils.isNotEmpty(s.getSapUomCode()) ? s.getSapUomCode() : "EA");
        input.setQty(post961Qty);
        input.setValueType(s.getValueType());
        input.setWorkOrderNo(s.getWorkOrderNo());
  /*      input.setReservationNo(s.getReservationNumber());
        input.setReservationItem(s.getReservationItem());*/
        return input;
    }
}
