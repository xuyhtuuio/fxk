package com.maxnerva.cloudmes.service.sap.material.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @author H7109018
 */
@Data
public class AvlDto implements Serializable {
    private String plant;
    private String partNo;
    private String supplierPartNo;
    private String supplierName;
    private String supplierCode;
    private String fromValidity;
    private String toValidity;
    private String flag;
}
