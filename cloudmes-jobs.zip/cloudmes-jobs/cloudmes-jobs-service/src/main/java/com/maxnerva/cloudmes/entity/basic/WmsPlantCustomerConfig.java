package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.extension.activerecord.Model;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

/**
 * <p>
 * 
 * </p>
 *
 * @author likun
 * @since 2023-09-25
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsPlantCustomerConfig对象", description="")
public class WmsPlantCustomerConfig extends Model<WmsPlantCustomerConfig> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "组织")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "SAP MRP area")
    private String mrpArea;

    @ApiModelProperty(value = "客户名称")
    private String customerName;

    @ApiModelProperty(value = "MES来源 MES、SFC")
    private String mesDataSource;

    @ApiModelProperty(value = "备注")
    private String remark;

    /**
     * 创建时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(hidden = true)
    private LocalDateTime createdDt;

    @ApiModelProperty(hidden = true)
    private String creator;

    /**
     * 最后修改人
     */
    @ApiModelProperty(hidden = true)
    private String lastEditor;

    /**
     * 最后一次编辑时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(hidden = true)
    private LocalDateTime lastEditedDt;

    /**
     * 创建人id
     */
    @ApiModelProperty(value = "创建人id")
    private Integer creatorId;

    /**
     * 最后一次编辑人id
     */
    @ApiModelProperty(value = "最后一次编辑人id")
    private Integer lastEditorId;

}
