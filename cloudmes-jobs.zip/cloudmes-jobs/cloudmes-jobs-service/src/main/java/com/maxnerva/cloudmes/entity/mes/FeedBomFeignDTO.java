package com.maxnerva.cloudmes.entity.mes;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel("查询上料BOM清单")
public class FeedBomFeignDTO implements Serializable {

    @ApiModelProperty("成品料号")
    private String partNo;

    @ApiModelProperty("线别编码")
    private String lineNo;

    @ApiModelProperty("职称分类")
    private String processType;

    @ApiModelProperty("工厂Code")
    private String plantCode;

    @ApiModelProperty("所属BU")
    private String orgCode;
}
