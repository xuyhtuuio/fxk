package com.maxnerva.cloudmes.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.basic.BasicMaterialEntity;
import com.maxnerva.cloudmes.entity.basic.GetMaterialPurchaseDTO;
import com.maxnerva.cloudmes.entity.basic.GetProductFlagDTO;
import com.maxnerva.cloudmes.entity.basic.MaterialCategoryCodeDTO;
import com.maxnerva.cloudmes.service.wh.model.SyncInventoryForFiiDTO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 物料主档定义 Mapper 接口
 * </p>
 *
 * @author Chao Zhang
 * @since 2022-11-19
 */
public interface BasicMaterialMapper extends BaseMapper<BasicMaterialEntity> {

    int insertMaterialInfo(BasicMaterialEntity insert);

    List<BasicMaterialEntity> selectMaterialList(@Param("orgCode") String orgCode,
                                                 @Param("partNoList") List<String> partNoList);

    BasicMaterialEntity selectMaterialInfo(@Param("orgCode") String orgCode,
                                           @Param("plantCode") String plantCode,
                                           @Param("partNo") String partNo,
                                           @Param("materialGroupList") List<String> materialGroupList);

    String selectCustomerNameByMaterialNo(@Param("orgCode") String orgCode,
                                          @Param("plantCode") String plantCode,
                                          @Param("partNo") String partNo);

    String selectCustomerNameByMaterialNoCusNo(@Param("orgCode") String orgCode,
                                               @Param("plantCode") String plantCode,
                                               @Param("partNo") String partNo,
                                               @Param("customerMaterialCode") String customerMaterialCode);

    List<MaterialCategoryCodeDTO> selectMaterialCategoryCode(String orgCode, String plantCode, List<String> materialNoList);

    List<GetMaterialPurchaseDTO> getMaterialPurchase(String orgCode, String plantCode, String partNo);

    List<GetProductFlagDTO> getProductFlag(List<SyncInventoryForFiiDTO> list);
}
