package com.maxnerva.cloudmes.service.basic;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.entity.basic.BasicVendor;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author ChaoZhang
 * @since 2021-06-09
 */
public interface IBasicVendorService extends IService<BasicVendor> {

}
