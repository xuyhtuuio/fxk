package com.maxnerva.cloudmes.mapper.qms;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.qms.WmsSyncMfgMaterialFromQmsLog;

/**
 * <p>
 * 从qms同步有效期log表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2024-11-27
 */
public interface WmsSyncMfgMaterialFromQmsLogMapper extends BaseMapper<WmsSyncMfgMaterialFromQmsLog> {

}
