package com.maxnerva.cloudmes.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.basic.SysDict;

import java.util.List;

public interface SysDictMapper extends BaseMapper<SysDict> {


    List<SysDict> selectDictList(String dictType);
}
