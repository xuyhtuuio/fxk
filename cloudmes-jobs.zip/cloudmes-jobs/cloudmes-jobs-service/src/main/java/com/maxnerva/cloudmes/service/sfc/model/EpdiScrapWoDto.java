package com.maxnerva.cloudmes.service.sfc.model;

import io.swagger.annotations.ApiModel;
import lombok.Data;

/**
 * @Author hgx
 * @Description EPDI报废单获取工单DTO
 * @Date 2023/9/21
 */
@ApiModel("EPDI报废单获取工单DTO")
@Data
public class EpdiScrapWoDto {
    private String workOrder;
    private String woSchedule;
}
