package com.maxnerva.cloudmes.service.sfc.model;

import io.swagger.annotations.ApiModel;
import lombok.Data;

@ApiModel("根据不良代码查询不良原因")
@Data
public class MesErrorDescVo {
    private String orgCode;
    private String errorCode;
}
