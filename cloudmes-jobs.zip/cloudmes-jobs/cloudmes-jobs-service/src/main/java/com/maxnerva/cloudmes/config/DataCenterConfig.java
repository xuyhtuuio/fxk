package com.maxnerva.cloudmes.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

@RefreshScope
@Component
@Data
public class DataCenterConfig {
    @Value("${dataCenter.add_user:}")
    private String addUser;

    @Value("${dataCenter.business_unit_name}")
    private String businessUnitName;

    @Value("${dataCenter.site_name}")
    private String siteName;

    @Value("${dataCenter.shipment.url:}")
    private String shipmentUrl;

    @Value("${dataCenter.inventory_info.url:}")
    private String inventoryInfoUrl;

    @Value("${dataCenter.gr_info.url:}")
    private String grInfoUrl;

    @Value("${dataCenter.token-key:}")
    private String tokenKey;

    @Value("${dataCenter.token:}")
    private String token;
}
