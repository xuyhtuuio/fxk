package com.maxnerva.cloudmes.service.wh.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.entity.wh.WmsWarehouseMaterialCostCenter;
import com.maxnerva.cloudmes.mapper.wh.WmsWarehouseMaterialCostCenterMapper;
import com.maxnerva.cloudmes.service.wh.IWmsWarehouseMaterialCostCenterService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 物料成本中心 服务实现类
 * </p>
 *
 * @author likun
 * @since 2022-11-01
 */
@Service
public class WmsWarehouseMaterialCostCenterServiceImpl extends ServiceImpl<WmsWarehouseMaterialCostCenterMapper, WmsWarehouseMaterialCostCenter> implements IWmsWarehouseMaterialCostCenterService {

}
