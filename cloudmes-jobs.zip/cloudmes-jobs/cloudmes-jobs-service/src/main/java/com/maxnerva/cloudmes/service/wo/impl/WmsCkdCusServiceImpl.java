package com.maxnerva.cloudmes.service.wo.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.date.LocalDateTimeUtil;
import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.core.util.XmlUtil;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;

import com.maxnerva.cloudmes.config.EcusUrlConfig;
import com.maxnerva.cloudmes.entity.wo.WmsCkdCus;
import com.maxnerva.cloudmes.mapper.wo.WmsCkdCusMapper;
import com.maxnerva.cloudmes.service.wo.IWmsCkdCusService;
import com.maxnerva.cloudmes.service.wo.model.CusInfoDTO;
import lombok.extern.slf4j.Slf4j;

import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * @author MFQ
 * @date 2023/10/20 上午 08:24
 */
@RefreshScope
@Slf4j
@Service
public class WmsCkdCusServiceImpl implements IWmsCkdCusService {

    @Resource
    private EcusUrlConfig ecusUrlConfig;

    @Resource
    private WmsCkdCusMapper wmsCkdCusMapper;

    // ECUS接口连续调用会挂掉。每次请求需要间隔30s再请求。
    private Boolean isRequest = Boolean.FALSE;

    private long REQ_INTERVAL = 30;

    @Override
    // 该函数是从wmsService拷贝过来的，如果需要修改，需要先改wmsService里的，保持一致
    public List<WmsCkdCus> getAndInsertCkdCus(String orgCode, Boolean isBonded, String po, String poItem, Boolean isForce) {
        // 先查数据库
        List<WmsCkdCus> wmsCkdCusList = wmsCkdCusMapper.selectList(Wrappers.<WmsCkdCus>lambdaQuery()
                .eq(WmsCkdCus::getOrgCode, orgCode)
                .eq(WmsCkdCus::getPo, po)
                .eq(WmsCkdCus::getPoItem, poItem)
        );
        // 获取单位编码->倍数关系
        // Map<String, String> unitNoMap = dictLangUtils.getByType("WMS_CUS_UNIT_NO");
        // 数据库没有再查Ecus
        if (CollUtil.isEmpty(wmsCkdCusList) || BooleanUtil.isTrue(isForce)){
            if (BooleanUtil.isTrue(isRequest)){
                try {
                    Thread.sleep(REQ_INTERVAL * 1000);
                } catch (Exception e){
                    e.printStackTrace();
                }
            } else {
                isRequest = Boolean.TRUE;
            }
            List<CusInfoDTO> cusInfoDTOList = requestCusInfo(isBonded, po, poItem);
            if (CollUtil.isNotEmpty(cusInfoDTOList)){
                cusInfoDTOList.forEach(item -> {
                    WmsCkdCus wmsCkdCus = new WmsCkdCus();
                    wmsCkdCus.setCreatedDt(LocalDateTime.now());
                    wmsCkdCus.setCreator("WMS-JOB");
                    wmsCkdCus.setLastEditedDt(LocalDateTime.now());
                    wmsCkdCus.setLastEditor("WMS-JOB");
                    wmsCkdCus.setOrgCode(orgCode);
                    wmsCkdCus.setDate(null);
                    wmsCkdCus.setOrgCode(orgCode);
                    wmsCkdCus.setPoItem(poItem);
                    wmsCkdCus.setPo(po);
                    wmsCkdCus.setCutNo(item.getBSI01());
                    wmsCkdCus.setCusUne(item.getBSI02());
                    // 有的按PO POITEM能查到，但是没有报关单。不插入数据库
                    if (StrUtil.isBlank(item.getBSI011())){
                        return;
                    }
                    String cusNo = item.getBSI011();
                    wmsCkdCus.setCusNo(cusNo);
                    wmsCkdCus.setCusItem(item.getBSI25());
                    wmsCkdCus.setGoodNo(item.getBSI031());
                    wmsCkdCus.setGoodName(item.getBSI032());
                    wmsCkdCus.setSpec(item.getBSI033());
                    wmsCkdCus.setQty(item.getBSI04());
                    wmsCkdCus.setUnitNo(item.getBSI05());
                    BigDecimal unitMultiple = BigDecimal.ONE;
//                    if (unitNoMap.containsKey(wmsCkdCus.getUnitNo())){
//                        unitMultiple = NumberUtil.toBigDecimal(unitNoMap.get(wmsCkdCus.getUnitNo()));
//                    }
                    wmsCkdCus.setUnitMultiple(unitMultiple);
                    wmsCkdCus.setCoo(item.getBSI06());
                    BigDecimal price = item.getBSI07();
                    wmsCkdCus.setPrice(price);
                    wmsCkdCus.setActualPrice(item.getBSI26());
//                    if (ObjectUtil.isNotNull(price)){
//                        wmsCkdCus.setActualPrice(price.divide(unitMultiple, 6, RoundingMode.DOWN));
//                    }
                    // 获取当前时区
                    ZoneId currentZoneId = ZoneId.systemDefault();
                    // 获取当前时区的偏移量
                    ZonedDateTime currentZonedDateTime = ZonedDateTime.now(currentZoneId);
                    ZoneOffset zoneOffset = currentZonedDateTime.getOffset();
                    // +08
                    String offsetString = zoneOffset.getId().substring(0, 3);
                    wmsCkdCus.setDate(LocalDateTimeUtil.parse(item.getBSH28(), DateTimeFormatter.ofPattern(String.format("yyyy-MM-dd'T'HH:mm:ss'%s:00'", offsetString))).toLocalDate());
                    wmsCkdCus.setCurrency(item.getBSI08());
                    wmsCkdCus.setDepartment(item.getBSI09());
                    wmsCkdCus.setHhPn(item.getBSI14());
                    wmsCkdCus.setActualQty(item.getBSI28());
                    wmsCkdCus.setCountryOfDeparture(item.getBSH09());
                    wmsCkdCus.setCountryOfArrival(item.getBSI35());
                    wmsCkdCus.setPortOfDeparture(item.getBSH13());
                    wmsCkdCusList.add(wmsCkdCus);
                });
                if (CollUtil.isNotEmpty(wmsCkdCusList)){
                    wmsCkdCusMapper.insertCkdCusList(wmsCkdCusList);
                }
            }
        }
        wmsCkdCusList.sort(Comparator.comparing(WmsCkdCus::getCusNo).thenComparing(WmsCkdCus::getCusItem));
        return wmsCkdCusList;
    }

    private List<CusInfoDTO> requestCusInfo(Boolean isBonded, String po, String poItem){
        Map<String, String > form = new HashMap<>();
        form.put("p_cnn", isBonded ? ecusUrlConfig.getCusBoundCnn() : ecusUrlConfig.getCusNonBoundCnn());
        form.put("p_bsi12", po);
        form.put("p_bsi13", poItem);
        try {
            log.info("requestCus: {}", JSONUtil.toJsonStr(form));
        } catch (Exception e){
            log.error("requestCus err", e);
        }
        HttpResponse response = HttpRequest.get(ecusUrlConfig.getCusUrl())
                .header("Content-Type", "text/xml; charset=utf-8")
                .setConnectionTimeout(5000)
                .formStr(form)
                .execute();
        try {
            log.info("responseCus {}", response.body());
        } catch (Exception e){
            log.error("responseCus err", e);
        }
        List<CusInfoDTO> cusInfoDTOList = ListUtil.toList();
        if (response.getStatus() == 200){
            NodeList list = XmlUtil.parseXml(response.body()).getElementsByTagName("Table");
            for (int i = 0; i < list.getLength(); i ++){
                Node node = list.item(i);
                CusInfoDTO cusInfoDTO = XmlUtil.xmlToBean(node, CusInfoDTO.class);
                cusInfoDTOList.add(cusInfoDTO);
            }
            return cusInfoDTOList;
        }
        return ListUtil.toList();
    }
}
