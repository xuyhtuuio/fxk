package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.extension.activerecord.Model;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@ApiModel("ASN上传JUSDA")
@Data
public class WmsAsnUpload extends Model<WmsAsnUpload> {

    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "sap工厂")
    private String plantCode;

    @ApiModelProperty(value = "单号")
    private String docNo;

    @ApiModelProperty(value = "ASN類型")
    private String asnType;

    @ApiModelProperty(value = "供應商名稱")
    private String supplierName;

    @ApiModelProperty(value = "收貨PO號")
    private String customerPo;

    @ApiModelProperty(value = "收貨PO項次")
    private String customerPoItem;

    @ApiModelProperty(value = "客戶料號")
    private String customerPartNo;

    @ApiModelProperty(value = "出貨數量")
    private Integer shippingQty;

    @ApiModelProperty(value = "預計送達時間")
    private LocalDate eta;

    @ApiModelProperty(value = "發票號碼")
    private String invoiceNo;

    @ApiModelProperty(value = "原產國")
    private String countryOfOriginal;

    @ApiModelProperty(value = "毛重")
    private BigDecimal grossWeight;

    @ApiModelProperty(value = "箱數")
    private Integer cartonQty;

    @ApiModelProperty(value = "板數")
    private Integer palletQty;

    @ApiModelProperty(value = "客戶名稱")
    private String customerName;

    @ApiModelProperty(value = "供應商料號")
    private String supplierPartNo;

    @ApiModelProperty(value = "製造商")
    private String mfr;

    @ApiModelProperty(value = "單價")
    private BigDecimal price;

    @ApiModelProperty(value = "幣別")
    private String currency;

    @ApiModelProperty(value = "ASN類型描述")
    private String asnTypeDescription;

    @ApiModelProperty(value = "進出模式")
    private String inOutMode;

    @ApiModelProperty(value = "保稅性質")
    private String natureOfBond;

    @ApiModelProperty(value = "恒溫否")
    private String thermostatic;

    @ApiModelProperty(value = "適用于物料情況")
    private String partCondition;

    private Boolean isDeleted;

    @ApiModelProperty(value = "抛jsda标识（0：未抛，1：已抛）")
    private String postJusdaFlag;

    @ApiModelProperty(value = "jusda返回msg")
    private String postJusdaReturnMsg;

    @ApiModelProperty(value = "post-jusda时间")
    private LocalDateTime postJusdaDate;

    @ApiModelProperty(value = "post-jusda时间")
    private String postJusdaJson;

    @ApiModelProperty(value = "jusda返回信息")
    private String postJusdaReturnInfo;

    @ApiModelProperty(value = "抛jusda参数")
    private String senderId;

    @ApiModelProperty(value = "抛jusda参数")
    private String msgType;

    @ApiModelProperty(value = "抛jusda参数")
    private String receiverId;

    @ApiModelProperty(value = "抛jusda参考单号")
    private String referenceNo;

    @ApiModelProperty(value = "dc")
    private String dc;

    @ApiModelProperty(value = "版次")
    private String partVersion;
}
