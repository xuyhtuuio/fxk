package com.maxnerva.cloudmes.entity.basic;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

/**
 * @ClassName RecommendDTO
 * @Description 扫描载具推荐dto
 * @Author Likun
 * @Date 2022/8/9
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Builder
@ApiModel("扫描载具推荐dto")
@Data
public class RecommendDTO {

    @ApiModelProperty(value = "储位编码")
    private String binCode;

    @ApiModelProperty(value = "库位编码")
    private String locationCode;
}
