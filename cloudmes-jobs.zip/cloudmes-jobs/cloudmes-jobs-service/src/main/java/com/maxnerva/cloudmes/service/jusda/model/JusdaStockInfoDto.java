package com.maxnerva.cloudmes.service.jusda.model;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/12/08 13:04
 * @Version: 1.0
 */
@Data
public class JusdaStockInfoDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String Ownership;
    private String SupplierName;
    private String SupplierPartNo;
    private String CustomerName;
    private String CustomerSupplierNo;
    private String CustomerPartNo;
    private String CustomerRevision;
    private String MFR;
    private BigDecimal Qty;
    private String Category;
    private String StockStatus;
    private String WarehouseNo;
    private String LastEditBy;
    private String LastEditDT;
    private String SupplierNo;
    private String CustomerNo;
    private String VMIExemption;
}
