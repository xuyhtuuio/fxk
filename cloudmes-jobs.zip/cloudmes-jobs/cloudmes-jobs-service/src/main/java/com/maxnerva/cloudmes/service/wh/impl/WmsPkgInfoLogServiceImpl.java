package com.maxnerva.cloudmes.service.wh.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.entity.wh.WmsPkgInfoLog;
import com.maxnerva.cloudmes.mapper.wh.WmsPkgInfoLogMapper;
import com.maxnerva.cloudmes.service.wh.IWmsPkgInfoLogService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author likun
 * @since 2022-08-05
 */
@Slf4j
@Service
public class WmsPkgInfoLogServiceImpl extends ServiceImpl<WmsPkgInfoLogMapper, WmsPkgInfoLog> implements
        IWmsPkgInfoLogService {
}








