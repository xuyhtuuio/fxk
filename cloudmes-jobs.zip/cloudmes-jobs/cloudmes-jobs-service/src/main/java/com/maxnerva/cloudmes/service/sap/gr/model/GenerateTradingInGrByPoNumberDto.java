package com.maxnerva.cloudmes.service.sap.gr.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @author H7109018
 */
@Data
public class GenerateTradingInGrByPoNumberDto implements Serializable {
	private static final long serialVersionUID = 1L;

	private String transactionDate;
	private String docDate;
	private String refDocNo;
	private String partNo;
	private String plant;
	private String warehouseName;
	private String qty;
	private String unit;
	private String poNumber;
	private String poItem;
	//X是待驗，  空是良品
	private String stckType;
	private String vendor;
	private String itemText;
	private String batch;
}