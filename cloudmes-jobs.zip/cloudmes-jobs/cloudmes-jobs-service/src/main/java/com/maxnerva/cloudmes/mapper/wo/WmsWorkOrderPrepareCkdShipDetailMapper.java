package com.maxnerva.cloudmes.mapper.wo;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderPrepareCkdShipDetail;


public interface WmsWorkOrderPrepareCkdShipDetailMapper extends BaseMapper<WmsWorkOrderPrepareCkdShipDetail> {

}
