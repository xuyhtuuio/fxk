package com.maxnerva.cloudmes.entity.wo;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

/**
 * <p>
 * 上料表信息，从sfc同步;從SFC同步
 * </p>
 *
 * @author likun
 * @since 2022-08-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value = "WmsBomFeeder对象", description = "上料表信息")
public class WmsBomFeeder extends BaseEntity<WmsBomFeeder> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "SMT、PTH、ASSY")
    private String productProcess;

    @ApiModelProperty(value = "成品料号")
    private String productPartNo;

    @ApiModelProperty(value = "成品料号版次")
    private String productPartVersion;

    @ApiModelProperty(value = "线别")
    private String lineNo;

    @ApiModelProperty(value = "AB面")
    private String lineCategory;

    @ApiModelProperty(value = "机台编号")
    private String machineCode;

    @ApiModelProperty(value = "机台方向（13、 24）")
    private String machineDirection;

    @ApiModelProperty(value = "feeder号,轨道号")
    private String feederNo;

    @ApiModelProperty(value = "主料號")
    private String keyPartNo;

    @ApiModelProperty(value = "版次")
    private String keyPartVersion;

    @ApiModelProperty(value = "替代号")
    private String sparePartNo;

    @ApiModelProperty(value = "版次")
    private String sparePartNoVersion;

    @ApiModelProperty(value = "M:主料，S替代料")
    private String partNoType;

    @ApiModelProperty(value = "检料量")
    private BigDecimal pickedQty;

    @ApiModelProperty(value = "连板数")
    private BigDecimal cardsPerPanel;

    @ApiModelProperty(value = "是否需要烧录")
    private Boolean isBurn;

    @ApiModelProperty(value = "烧录值")
    private String burnValue;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "工单绑定位置")
    private String workOrderToLocation;

    @ApiModelProperty(value = "需求数量")
    private BigDecimal requestQty;

    @ApiModelProperty(value = "工单群组")
    private String workOrderItem;

    @ApiModelProperty(value = "生产制程分类")
    private String productProcessCategory;

    @ApiModelProperty(value = "是否合盘物料")
    private String mergeFlag;

    @ApiModelProperty(value = "制程分类")
    private String materialProductProcess;

    public String distinctByKey() {
        return this.lineCategory + "_" + this.machineDirection;
    }
}
