package com.maxnerva.cloudmes;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author likun
 */
@SpringBootApplication
//@ComponentScan(value = {"com.maxnerva.cloudmes"},
//        excludeFilters = {@ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE,
//                classes = {Knife4jConfiguration.class})})
@MapperScan(basePackages = {"com.maxnerva.cloudmes.mapper"})
public class JobApplication {

    public static void main(String[] args) {
        SpringApplication.run(JobApplication.class, args);
    }


}
