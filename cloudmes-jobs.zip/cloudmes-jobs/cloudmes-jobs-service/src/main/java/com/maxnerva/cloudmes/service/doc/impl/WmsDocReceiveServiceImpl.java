package com.maxnerva.cloudmes.service.doc.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.entity.doc.WmsDocReceive;
import com.maxnerva.cloudmes.mapper.doc.WmsDocReceiveMapper;
import com.maxnerva.cloudmes.service.doc.IWmsDocReceiveService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * @ClassName WmsDocReceiveServiceImpl
 * @Description TODO
 * @Author Likun
 * @Date 2023/5/8
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Slf4j
@Service
public class WmsDocReceiveServiceImpl extends ServiceImpl<WmsDocReceiveMapper, WmsDocReceive>
        implements IWmsDocReceiveService {
}
