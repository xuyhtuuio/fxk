package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.TableId;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 载具表
 * </p>
 *
 * @author likun
 * @since 2022-07-22
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsVehicle对象", description="载具表")
public class WmsVehicle extends BaseEntity<WmsVehicle> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    @TableId
    private Integer id;

    @ApiModelProperty(value = "BU(业务单元)")
    private String orgCode;

    @ApiModelProperty(value = "载具编码")
    private String vehicleCode;

    @ApiModelProperty(value = "载具名称")
    private String vehicleName;

    @ApiModelProperty(value = "关联库位表(wms_location)主键id")
    private Integer wmsLocationId;

    @ApiModelProperty(value = "库位编码")
    private String locationCode;

    @ApiModelProperty(value = "载具类型(料车，料架)")
    private String vehicleType;

    @ApiModelProperty(value = "使用状态(false-可用 true-占用) 默认false")
    private Boolean usageStatus;

    @ApiModelProperty(value = "使用场景")
    private String useScene;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "料号个数")
    private Integer materialCount;

    @ApiModelProperty(value = "pkgId个数")
    private Integer pkgIdCount;
}
