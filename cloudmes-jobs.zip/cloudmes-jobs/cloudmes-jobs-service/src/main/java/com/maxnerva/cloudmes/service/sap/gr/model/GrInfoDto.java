package com.maxnerva.cloudmes.service.sap.gr.model;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author H7109018
 */
@Data
public class GrInfoDto implements Serializable {
    private static final long serialVersionUID = 1L;

    private String grNumber;
    private String grItem;
    private String plantCode;
    private String tradingCode;
    private String partNo;
    private String partVerion;
    private String partDesc;
    private String valueType;
    private String poNumber;
    private String poItem;
    private String bom;
    private String warehouseCode;
    private BigDecimal qty;
    private String movementType;
    private String returnGrNumber;
}