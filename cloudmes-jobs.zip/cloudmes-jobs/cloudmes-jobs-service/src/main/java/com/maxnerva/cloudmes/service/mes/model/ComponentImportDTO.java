package com.maxnerva.cloudmes.service.mes.model;

import com.alibaba.excel.annotation.ExcelProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <p>
 * 零件条码管理
 * </p>
 *
 * @author hej
 * @since 2022-11-09
 */
@Data
@ApiModel(value = "ComponetImportDTO", description = "ComponetImportDTO")
public class ComponentImportDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    @ExcelProperty(index = 0)
    @ApiModelProperty("零件SN")
    private String componentSn;

    @ExcelProperty(index = 1)
    @ApiModelProperty("零件料号")
    private String componentNo;

    @ExcelProperty(index = 2)
    @ApiModelProperty("零件料号版次")
    private String componentVersion;

    @ExcelProperty(index = 3)
    @ApiModelProperty("供应商名称")
    private String mfgName;

    @ExcelProperty(index = 4)
    @ApiModelProperty("供应商料号")
    private String mfgPn;

    @ExcelProperty(index = 5)
    @ApiModelProperty("D/C")
    private String dateCode;

    @ExcelProperty(index = 6)
    @ApiModelProperty("L/C")
    private String lotNo;

    @ExcelProperty(index = 7)
    @ApiModelProperty("原产国(关联sys_dict: MES_ORIGIN_COUNTRY)")
    private String originCountry;

    @ExcelProperty(index = 8)
    @ApiModelProperty("PKGID")
    private String pkgId;

    @ApiModelProperty("所属厂部")
    private String plantCode;

    @ApiModelProperty("所属BY")
    private String orgCode;
}
