package com.maxnerva.cloudmes.service.tencent;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.entity.tencent.WmsTencentDeliverySnBindRecord;

/**
 * <p>
 * 腾讯订单sn绑定记录表 服务类
 * </p>
 *
 * @author likun
 * @since 2025-05-21
 */
public interface IWmsTencentDeliverySnBindRecordService extends IService<WmsTencentDeliverySnBindRecord> {

}
