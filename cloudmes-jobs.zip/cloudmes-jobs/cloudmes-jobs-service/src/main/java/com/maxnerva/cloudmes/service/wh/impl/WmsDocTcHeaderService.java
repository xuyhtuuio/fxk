package com.maxnerva.cloudmes.service.wh.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.entity.doc.WmsDocTcHeader;
import com.maxnerva.cloudmes.mapper.doc.WmsDocTcHeaderMapper;
import com.maxnerva.cloudmes.service.wh.IWmsDocTcHeaderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class WmsDocTcHeaderService extends ServiceImpl<WmsDocTcHeaderMapper, WmsDocTcHeader> implements IWmsDocTcHeaderService {
}
