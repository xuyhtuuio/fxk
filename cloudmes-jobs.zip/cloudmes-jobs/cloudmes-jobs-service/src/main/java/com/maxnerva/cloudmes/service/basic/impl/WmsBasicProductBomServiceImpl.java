package com.maxnerva.cloudmes.service.basic.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.entity.basic.WmsBasicProductBom;
import com.maxnerva.cloudmes.mapper.basic.WmsBasicProductBomMapper;
import com.maxnerva.cloudmes.service.basic.IWmsBasicProductBomService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 同步basic产品bom表 服务实现类
 * </p>
 *
 * @author likun
 * @since 2024-12-23
 */
@Service
public class WmsBasicProductBomServiceImpl extends ServiceImpl<WmsBasicProductBomMapper, WmsBasicProductBom>
        implements IWmsBasicProductBomService {

}
