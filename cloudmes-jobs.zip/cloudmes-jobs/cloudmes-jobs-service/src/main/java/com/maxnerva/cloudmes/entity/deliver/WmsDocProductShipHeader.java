package com.maxnerva.cloudmes.entity.deliver;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class WmsDocProductShipHeader{
    private Integer id;

    @ApiModelProperty("出库单号")
    private String docNo;

    @ApiModelProperty("单据类型")
    private String docType;

    @ApiModelProperty("单据状态")
    private String status;

    @ApiModelProperty("工厂组织")
    private String orgCode;

    @ApiModelProperty("SAP工厂")
    private String sapPlantCode;

    @ApiModelProperty("计划出货时间")
    private LocalDateTime planShipTime;

    @ApiModelProperty("客户编码")
    private String cusCode;

    @ApiModelProperty("客户名称")
    private String cusName;

    @ApiModelProperty("DN单号")
    private String dnNo;

    @ApiModelProperty("来源类型")
    private String sourceType;

    @ApiModelProperty("ship_code")
    private String shipCode;

    @ApiModelProperty("ship_place")
    private String shipPlace;

    @ApiModelProperty("ship_address1")
    private String shipAddress1;

    @ApiModelProperty("ship_address2")
    private String shipAddress2;

    @ApiModelProperty("ship_to_party_code")
    private String shipToPartyCode;

    @ApiModelProperty("ship_city")
    private String shipCity;

    @ApiModelProperty("address_code")
    private String addressCode;

    @ApiModelProperty(value = "运输方式")
    private String transportMode;

    @ApiModelProperty(value = "删除标识")
    private Boolean isDeleted;

    @ApiModelProperty(value = "是否调用QMS")
    private Boolean postingQmsFlag;

    @ApiModelProperty(value = "是否已抛Q")
    private Boolean toQmsFlag;

    @ApiModelProperty(value = "抛Q信息")
    private String toQmsMessage;

    @ApiModelProperty(value = "抛Q时间")
    private LocalDateTime toQmsDate;

    @ApiModelProperty(value = "抛Q结果（SUCCESS:成功，FAIL:失败）")
    private String toQmsResult;

    @ApiModelProperty(value = "qms返回标识（NG：失败，OK：成功）")
    private String qmsReturnFlag;

    @ApiModelProperty(value = "qms回写日期")
    private LocalDateTime qmsReturnDate;

    @ApiModelProperty(value = "qms返回信息")
    private String qmsReturnMessage;

    @ApiModelProperty(value = "出货地")
    private String siteCode;

    private String creator;
    private Integer creatorId;
    private Long createdDt;
    private String lastEditor;
    private Integer lastEditorId;
    private Long lastEditedDt;

    @ApiModelProperty(value = "DN扣账标识（0：未扣，1：已扣）")
    private String pgiFlag;

    @ApiModelProperty(value = "DN扣账时间")
    private LocalDateTime pgiDate;

    @ApiModelProperty(value = "DN扣账信息")
    private String pgiMsg;

    @ApiModelProperty(value = "抛sfc标识")
    private Boolean toSfcFlag;

    @ApiModelProperty(value = "抛sfc信息")
    private String toSfcMsg;

    @ApiModelProperty(value = "抛sfc时间")
    private LocalDateTime toSfcDt;
}
