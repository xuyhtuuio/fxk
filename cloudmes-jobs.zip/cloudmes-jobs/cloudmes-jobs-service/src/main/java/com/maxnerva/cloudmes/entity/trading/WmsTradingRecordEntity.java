package com.maxnerva.cloudmes.entity.trading;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * <p>
 * 内交单据表
 * </p>
 *
 * @author Chao Zhang
 * @since 2022-11-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("wms_trading_record")
public class WmsTradingRecordEntity extends Model<WmsTradingRecordEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 内交单号;
     */
    @TableField("trading_number")
    private String tradingNumber;

    /**
     * 内交出BU
     */
    @TableField("from_org_code")
    private String fromOrgCode;

    /**
     * 内交出工厂
     */
    @TableField("from_plant_code")
    private String fromPlantCode;

    /**
     * 鸿海料号
     */
    @TableField("part_no")
    private String partNo;

    /**
     * 鸿海料号版次
     */
    @TableField("part_version")
    private String partVersion;

    /**
     * 内交出数量
     */
    @TableField("trading_qty")
    private BigDecimal tradingQty;

    /**
     * 内交入数量
     */
    @TableField("confirm_qty")
    private BigDecimal confirmQty;

    /**
     * 单位
     */
    @TableField("uom_code")
    private String uomCode;

    /**
     * 转出仓码
     */
    @TableField("from_warehouse_code")
    private String fromWarehouseCode;

    /**
     * 内交类型
     */
    @TableField("trading_type")
    private String tradingType;

    /**
     * 配銷通路
     */
    @TableField("sales_chain")
    private String salesChain;

    /**
     * 产品部
     */
    @TableField("product_department")
    private String productDepartment;

    /**
     * 内交入bu
     */
    @TableField("to_org_code")
    private String toOrgCode;

    /**
     * 内交出代码
     */
    @TableField("trading_from_code")
    private String tradingFromCode;

    /**
     * 内交入代码
     */
    @TableField("trading_to_code")
    private String tradingToCode;

    /**
     * 内交入工厂
     */
    @TableField("to_plant_code")
    private String toPlantCode;

    /**
     * 内交入料号;
     */
    @TableField("to_part_no")
    private String toPartNo;

    /**
     * 内交入版次;
     */
    @TableField("to_part_version")
    private String toPartVersion;

    /**
     * 内交入仓码;
     */
    @TableField("to_warehouse_code")
    private String toWarehouseCode;

    /**
     * 内交标识，内交出过账sap用;
     */
    @TableField("trading_flag")
    private Integer tradingFlag;

    /**
     * 内交信息，内交出过账sap用;
     */
    @TableField("trading_msg")
    private String tradingMsg;

    /**
     * 内交日期，内交出过账sap用;
     */
    @TableField("trading_date")
    private LocalDateTime tradingDate;

    /**
     * 内交人，内交出过账sap用;
     */
    @TableField("trading_by")
    private String tradingBy;

    /**
     * pgi标识，内交出过账sap用;（0：未过账）
     */
    @TableField("pgi_flag")
    private Integer pgiFlag;

    /**
     * pgi信息，内交出过账sap用;
     */
    @TableField("pgi_msg")
    private String pgiMsg;

    /**
     * pgi日期，内交出过账sap用;
     */
    @TableField("pgi_date")
    private LocalDateTime pgiDate;

    /**
     * pgi人，内交出过账sap用;
     */
    @TableField("pgi_by")
    private String pgiBy;

    /**
     * gr标识，内交入过账sap用;
     */
    @TableField("gr_flag")
    private Integer grFlag;

    /**
     * gr工厂，内交入过账sap用;
     */
    @TableField("gr_plant_code")
    private String grPlantCode;

    /**
     * gr信息，内交入过账sap用;
     */
    @TableField("gr_msg")
    private String grMsg;

    /**
     * gr日期，内交入过账sap用;
     */
    @TableField("gr_date")
    private LocalDateTime grDate;

    /**
     * gr人，内交入过账sap用;
     */
    @TableField("gr_by")
    private String grBy;

    /**
     * 内交出确认人
     */
    @TableField("trading_from_confirm_by")
    private String tradingFromConfirmBy;

    /**
     * 内交出确认时间
     */
    @TableField("trading_from_confirm_date")
    private LocalDateTime tradingFromConfirmDate;

    /**
     * 内交出确认标识
     */
    @TableField("trading_from_confirm_flag")
    private String tradingFromConfirmFlag;

    /**
     * 内交入确认人
     */
    @TableField("trading_to_confirm_by")
    private String tradingToConfirmBy;

    /**
     * 内交入确认时间
     */
    @TableField("trading_to_confirm_date")
    private LocalDateTime tradingToConfirmDate;

    /**
     * 内交入确认数量
     */
    @TableField("trading_to_confirm_qty")
    private BigDecimal tradingToConfirmQty;

    /**
     * 内交入确认标识
     */
    @TableField("trading_to_confirm_flag")
    private String tradingToConfirmFlag;

    /**
     * 创建人
     */
    @TableField("creator")
    private String creator;

    /**
     * 创建时间
     */
    @TableField("created_dt")
    private LocalDateTime createdDt;

    /**
     * 修改人
     */
    @TableField("last_editor")
    private String lastEditor;

    /**
     * 修改时间
     */
    @TableField("last_edited_dt")
    private LocalDateTime lastEditedDt;

    /**
     * 是否虚拟过账（是否动实物）
     */
    @TableField("is_trading")
    private String isTrading;

    /**
     * 创建人id
     */
    @TableField("creator_id")
    private Integer creatorId;

    /**
     * 最后编辑人id
     */
    @TableField("last_editor_id")
    private Integer lastEditorId;

    /**
     * 出库数量
     */
    @TableField("delivery_qty")
    private BigDecimal deliveryQty;

    /**
     * 制造商料号
     */
    @TableField("to_mfg_part_no")
    private String toMfgPartNo;

    /**
     * 制造商名称
     */
    @TableField("to_mfg_name")
    private String toMfgName;

    /**
     * 是否保税
     */
    @TableField("is_bonded")
    private Boolean isBonded;
    /**
     * 内交入过账时间
     */
    @TableField("post_sap_date")
    private LocalDateTime postSapDate;
    /**
     * 内交入返回msg
     */
    @TableField("sap_return_msg")
    private String sapReturnMsg;
    /**
     * 内交入过账单号
     */
    @TableField("sap_return_number")
    private String sapReturnNumber;


    @Override
    public Serializable pkVal() {
        return this.id;
    }

}
