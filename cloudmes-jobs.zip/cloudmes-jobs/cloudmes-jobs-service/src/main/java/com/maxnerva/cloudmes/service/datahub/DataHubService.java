package com.maxnerva.cloudmes.service.datahub;

import cn.hutool.http.HttpResponse;
import com.maxnerva.cloudmes.entity.spm.TransferDocToSpmVO;
import com.maxnerva.cloudmes.service.datahub.model.*;
import com.maxnerva.cloudmes.service.wo.model.JsonStringVO;

import java.util.List;

/**
 * @ClassName DataHubService
 * @Description 服务节点service
 * @Author Likun
 * @Date 2023/3/9
 * @Version 1.0
 * @Since JDK 1.8
 **/
public interface DataHubService {

    HttpResponse vnCreatePo(JsonStringVO vnCreatePoVO);

    HttpResponse saveWmsDocReceive(JsonStringVO jsonStringVO);

    HttpResponse syncTransferToSpm(List<TransferDocToSpmVO> transferDocToSpmVOList);
}
