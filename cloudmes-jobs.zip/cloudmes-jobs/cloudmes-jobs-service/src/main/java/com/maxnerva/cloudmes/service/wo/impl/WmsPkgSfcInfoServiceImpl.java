package com.maxnerva.cloudmes.service.wo.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.entity.pkg.WmsPkgSfcInfoEntity;
import com.maxnerva.cloudmes.mapper.pkg.WmsPkgSfcInfoMapper;
import com.maxnerva.cloudmes.service.wo.IWmsPkgSfcInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * @ClassName WmsPkgSfcInfoServiceImpl
 * @Description 成品入库信息
 * @Author Likun
 * @Date 2023/6/10
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Slf4j
@Service
public class WmsPkgSfcInfoServiceImpl extends ServiceImpl<WmsPkgSfcInfoMapper, WmsPkgSfcInfoEntity>
        implements IWmsPkgSfcInfoService {
}
