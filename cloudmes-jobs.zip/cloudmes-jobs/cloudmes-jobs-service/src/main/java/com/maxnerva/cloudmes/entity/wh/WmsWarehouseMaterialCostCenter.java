package com.maxnerva.cloudmes.entity.wh;

import com.baomidou.mybatisplus.extension.activerecord.Model;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * <p>
 * 物料成本中心
 * </p>
 *
 * @author likun
 * @since 2022-11-01
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsWarehouseMaterialCostCenter对象", description="物料成本中心")
public class WmsWarehouseMaterialCostCenter extends Model<WmsWarehouseMaterialCostCenter> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "工厂编码")
    private String plantCode;

    @ApiModelProperty(value = "仓码")
    private String warehouseCode;

    @ApiModelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "版次")
    private String partVersion;

    @ApiModelProperty(value = "value type")
    private String valueType;

    @ApiModelProperty(value = "料号类型")
    private String materialType;

    @ApiModelProperty(value = "料号群组")
    private String materialGroup;

    @ApiModelProperty(value = "良品数量")
    private String goodProductQty;

    @ApiModelProperty(value = "待验数量")
    private String inspectedQty;

    @ApiModelProperty(value = "创建人")
    private String creator;

    @ApiModelProperty(value = "创建人员工id，冗余字段")
    private Integer creatorId;

    @ApiModelProperty(value = "创建时间")
    private Long createdDt;

    @ApiModelProperty(value = "修改人")
    private String lastEditor;

    @ApiModelProperty(value = "修改人员工id，冗余字段")
    private Integer lastEditorId;

    @ApiModelProperty(value = "修改时间")
    private Long lastEditedDt;


    @Override
    public Serializable pkVal() {
        return this.id;
    }

}
