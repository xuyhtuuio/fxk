package com.maxnerva.cloudmes.entity.deliver;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class WmsDocProductShipDetail{
    private Integer id;

    @ApiModelProperty("单头id")
    private Integer headerId;

    @ApiModelProperty("行号")
    private Integer lineNo;

    @ApiModelProperty("行状态")
    private String status;

    @ApiModelProperty("鸿海料号")
    private String partNo;

    @ApiModelProperty("料号名称")
    private String partName;

    @ApiModelProperty("客户料号")
    private String cusNo;

    @ApiModelProperty("计划出货数量")
    private BigDecimal planShipQty;

    @ApiModelProperty("DN单号")
    private String dnNo;

    @ApiModelProperty("DN项次")
    private String dnItem;

    @ApiModelProperty("出货数量")
    private BigDecimal shipQty;

    @ApiModelProperty("转出仓")
    private String transferPlantCode;

    @ApiModelProperty("单据日期")
    private LocalDateTime docDate;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty("PO類型")
    private String demandType;

    @ApiModelProperty("正式PO")
    private String amazonId;

    @ApiModelProperty("客戶ID")
    private String requestId;

    @ApiModelProperty("臨時PO")
    private String buildTriggerId;

    @ApiModelProperty("機種名")
    private String itemDescription;

    @ApiModelProperty("出貨地")
    private String siteCode;

    @ApiModelProperty("出貨日期")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate estimatedShipDate;

    @ApiModelProperty("PO")
    private String po;

    @ApiModelProperty("poItem")
    private String poItem;

    @ApiModelProperty(value = "删除标识")
    private Boolean isDeleted;

    @ApiModelProperty(value = "是否已抛Q")
    private Boolean toQmsFlag;

    @ApiModelProperty(value = "抛Q信息")
    private String toQmsMessage;

    @ApiModelProperty(value = "抛Q时间")
    private LocalDateTime toQmsDate;

    @ApiModelProperty(value = "抛Q结果（SUCCESS:成功，FAIL:失败）")
    private String toQmsResult;

    @ApiModelProperty(value = "qms返回标识（NG：失败，OK：成功）")
    private String qmsReturnFlag;

    @ApiModelProperty(value = "qms回写日期")
    private LocalDateTime qmsReturnDate;

    @ApiModelProperty(value = "qms返回信息")
    private String qmsReturnMessage;

    private String postSfcFlag;

    private String postSfcMessage;

    private LocalDateTime postSfcDate;

    private String creator;
    private Integer creatorId;
    private Long createdDt;
    private String lastEditor;
    private Integer lastEditorId;
    private Long lastEditedDt;

    private String orgCode;

    private String partVersion;
}
