package com.maxnerva.cloudmes.service.sap.util.impl;

import cn.hutool.core.map.CaseInsensitiveMap;
import com.maxnerva.cloudmes.service.sap.util.SapPoolService;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.ext.DestinationDataProvider;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import java.util.Map;
import java.util.Properties;

/**
 * @author H7109018
 */
@Component("sap")
@ConfigurationProperties(prefix = "sap")
@Data
public class SapEntity implements SapPoolService {

    private CaseInsensitiveMap<String, Map<String, String>> pool;

    @Override
    public JCoDestination getSapPool(String clientId) {
        Assert.notNull(pool, "SAP pool configuration error");
        Map<String, String> properties = pool.get(clientId);
        Assert.notNull(properties, "ClientID [ " + clientId + " ] not found config information");
        Properties connectProperties = new Properties();
        connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, properties.get("host"));
        connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, properties.get("client"));
        connectProperties.setProperty(DestinationDataProvider.JCO_USER, properties.get("user"));
        connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, properties.get("password"));
        connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR, properties.get("sysnr"));
        connectProperties.setProperty(DestinationDataProvider.JCO_LANG, properties.get("lang"));
        connectProperties.setProperty(DestinationDataProvider.JCO_PEAK_LIMIT, properties.get("limit"));
        connectProperties.setProperty(DestinationDataProvider.JCO_POOL_CAPACITY, properties.get("poolCapacity"));
        connectProperties.setProperty(DestinationDataProvider.JCO_MAX_GET_TIME, properties.get("maxGetTime"));
        connectProperties.setProperty(DestinationDataProvider.JCO_EXPIRATION_TIME, properties.get("expirationTime"));
        //目标检查释放的连接是否到期后的周期（以毫秒为单位）。 10s
        connectProperties.setProperty(DestinationDataProvider.JCO_EXPIRATION_PERIOD, properties.get("expirationPeriod"));
        return generateSapPool(properties.get("poolName"), connectProperties);
    }
}
