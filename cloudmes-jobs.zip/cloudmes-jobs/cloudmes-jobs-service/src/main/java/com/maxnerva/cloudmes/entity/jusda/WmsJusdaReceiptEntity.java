package com.maxnerva.cloudmes.entity.jusda;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * <p>
 * 
 * </p>
 *
 * @author Chao Zhang
 * @since 2022-11-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("wms_jusda_receipt")
public class WmsJusdaReceiptEntity extends Model<WmsJusdaReceiptEntity> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * VMIHUB 中的工厂别
     */
    @TableField("site_name")
    private String siteName;

    /**
     * VMIHUB 中的工厂别
     */
    @TableField("plant_code")
    private String plantCode;

    /**
     * Foxconn BU代碼
     */
    @TableField("customer_name")
    private String customerName;

    /**
     * 出货单号
     */
    @TableField("ship_id")
    private String shipId;

    /**
     * 來源國
     */
    @TableField("origin_of_country")
    private String originOfCountry;

    /**
     * 供應商代碼
     */
    @TableField("customer_supplier_no")
    private String customerSupplierNo;

    /**
     * 供應商料號
     */
    @TableField("supplier_part_no")
    private String supplierPartNo;

    /**
     * BU料號
     */
    @TableField("customer_part_no")
    private String customerPartNo;

    /**
     * 供應商料號版次
     */
    @TableField("spn_version")
    private String spnVersion;

    /**
     * BU料號版次
     */
    @TableField("cpn_version")
    private String cpnVersion;

    /**
     * 制造商簡稱
     */
    @TableField("manufacture")
    private String manufacture;

    /**
     * 出貨時間
     */
    @TableField("ship_dt")
    private LocalDateTime shipDt;

    /**
     * 出貨數量
     */
    @TableField("shiped_qty")
    private BigDecimal shipedQty;

    /**
     * 單位
     */
    @TableField("uom")
    private String uom;

    /**
     * EDI862 ID
     */
    @TableField("pull_list_no")
    private String pullListNo;

    /**
     * EDI862文件ID號碼項次
     */
    @TableField("pull_list_item")
    private String pullListItem;

    /**
     * 報關PO號碼
     */
    @TableField("custom_po")
    private String customPo;

    /**
     * 報關PO項次
     */
    @TableField("custom_po_item")
    private String customPoItem;

    /**
     * 報關單號
     */
    @TableField("custom_doc_no")
    private String customDocNo;

    /**
     * 報關單項次
     */
    @TableField("custom_doc_item_no")
    private String customDocItemNo;

    /**
     * VMI GRN NO
     */
    @TableField("grn_no")
    private String grnNo;

    /**
     * 工單號
     */
    @TableField("work_order_no")
    private String workOrderNo;

    /**
     * Supplier PO單號
     */
    @TableField("customer_po")
    private String customerPo;

    /**
     * Supplier Po單項次
     */
    @TableField("customer_po_item")
    private String customerPoItem;

    /**
     * 物料進口類型
     */
    @TableField("inbound_type")
    private String inboundType;

    /**
     * 預計到貨時間
     */
    @TableField("eta")
    private LocalDateTime eta;

    /**
     * 最小出货单位包规
     */
    @TableField("box_qty")
    private String boxQty;

    /**
     * EDI856文件唯一的ID
     */
    @TableField("document_id")
    private String documentId;

    /**
     * 出貨類型(H2S,H2C)
     */
    @TableField("so_type")
    private String soType;

    /**
     * 內交單號
     */
    @TableField("inner_transfer_no")
    private String innerTransferNo;

    /**
     * 內交單號項次
     */
    @TableField("inner_transfer_no_item")
    private String innerTransferNoItem;

    /**
     * 物料單價
     */
    @TableField("unit_price")
    private String unitPrice;

    /**
     * 参考栏位1
     */
    @TableField("reference1")
    private String reference1;

    /**
     * 参考栏位2
     */
    @TableField("reference2")
    private String reference2;

    /**
     * 参考栏位3
     */
    @TableField("reference3")
    private String reference3;

    /**
     * 参考栏位4
     */
    @TableField("reference4")
    private String reference4;

    /**
     * 创建人
     */
    @TableField("creator")
    private String creator;

    /**
     * 创建人id
     */
    @TableField("creator_id")
    private Integer creatorId;

    /**
     * 创建时间
     */
    @TableField("created_dt")
    private Long createdDt;

    /**
     * 最后编辑人
     */
    @TableField("last_editor")
    private String lastEditor;

    /**
     * 最后编辑人id
     */
    @TableField("last_editor_id")
    private Integer lastEditorId;

    /**
     * 最后编辑时间
     */
    @TableField("last_edited_dt")
    private Long lastEditedDt;

    /**
     * 0=正常、1=删除
     */
    @TableField("is_deleted")
    private Boolean isDeleted;

    /**
     * 参考栏位5
     */
    @TableField("reference5")
    private String reference5;

    /**
     * 收货类型（VMI、CMI）
     */
    @TableField("received_type")
    private String receivedType;

    /**
     * 上传日期
     */
    @TableField("sap_upload_data")
    private LocalDateTime sapUploadData;

    /**
     * 上传SAP结果（0：失败；1：成功）
     */
    @TableField("sap_return_result")
    private String sapReturnResult;

    /**
     * SAP返回信息
     */
    @TableField("sap_return_message")
    private String sapReturnMessage;

    /**
     * SAP返回单号
     */
    @TableField("sap_return_number")
    private String sapReturnNumber;

    /**
     * 供应商名称
     */
    @TableField("supplier_name")
    private String supplierName;

    /**
     * 收货数量
     */
    @TableField("received_qty")
    private BigDecimal receivedQty;

    /**
     * 工厂组织
     */
    @TableField("org_code")
    private String orgCode;

    /**
     * 抛jusda标识
     */
    @TableField("post_jusda_flag")
    private Boolean postJusdaFlag;

    /**
     * 抛jusda日期
     */
    @TableField("post_jusda_date")
    private LocalDateTime postJusdaDate;

    /**
     * 抛jusda信息
     */
    @TableField("post_jusda_message")
    private String postJusdaMessage;

    /**
     * vmi采购单号
     */
    @TableField("vmi_po_number")
    private String vmiPoNumber;

    /**
     * vmi采购项次
     */
    @TableField("vmi_po_item")
    private String vmiPoItem;

    @TableField("vmi_warehouse_code")
    private String vmiWarehouseCode;

    @TableField("post_jusda_recevie_completed_flag")
    private Boolean postJusdaRecevieCompletedFlag;

    @TableField("post_jusda_recevie_completed_date")
    private LocalDateTime postJusdaRecevieCompletedDate;

    @TableField("post_jusda_recevie_completed_msg")
    private String postJusdaRecevieCompletedMsg;

    @TableField("customer_receive_type")
    private String customerReceiveType;

    @TableField("receive_completed_date")
    private LocalDateTime receiveCompletedDate;

    @ApiModelProperty("from_warehouse_code")
    private String fromWarehouseCode;

    @ApiModelProperty("to_warehouse_code")
    private String toWarehouseCode;

    @ApiModelProperty("勾兌报关单号")
    private String blendingCusNo;

    @ApiModelProperty("勾兌报关单项次")
    private String blendingCusItem;

    @ApiModelProperty("勾兑报关单异常信息")
    private String blendingCusMessage;

    @ApiModelProperty("勾兑报关单时间")
    private LocalDateTime blendingCusDatetime;

    @ApiModelProperty(value = "0 未勾兑，1勾兑成功，2ecus未查询到报关单")
    private String blendingCusFlag;

    @Override
    public Serializable pkVal() {
        return this.id;
    }

}
