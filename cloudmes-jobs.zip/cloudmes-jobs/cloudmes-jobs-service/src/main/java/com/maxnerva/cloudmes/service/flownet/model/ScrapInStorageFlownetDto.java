package com.maxnerva.cloudmes.service.flownet.model;

import lombok.Data;

import java.util.List;

/**
 * @Author hgx
 * @Description 报废入库抛flownet DTO
 * @Date 2023/8/15
 */
@Data
public class ScrapInStorageFlownetDto {
    private String flownetformid;

    private List<ScrapInStorageFlownetDetailDto> materialList;
}
