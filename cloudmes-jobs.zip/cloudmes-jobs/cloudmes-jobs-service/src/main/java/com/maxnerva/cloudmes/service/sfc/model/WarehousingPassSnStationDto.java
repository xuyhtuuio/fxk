package com.maxnerva.cloudmes.service.sfc.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/09/20 08:49
 * @Version: 1.0
 */
@Data
public class WarehousingPassSnStationDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String userName;
    private String line;
    private String section;
    private String wStation;
    private String badCode;
    private String sn;
    private String myGroup;
    /**
     * OK or error msg
     */
    private String res;


}
