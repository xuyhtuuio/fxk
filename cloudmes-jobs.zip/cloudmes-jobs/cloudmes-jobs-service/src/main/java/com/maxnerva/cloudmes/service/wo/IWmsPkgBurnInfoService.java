package com.maxnerva.cloudmes.service.wo;


import com.maxnerva.cloudmes.service.wo.model.BurnInfoNewDTO;

import java.util.List;

/**
 * @Author hgx
 * @Description 烧录信息
 * @Date 2023/9/5
 */
public interface IWmsPkgBurnInfoService {
    List<BurnInfoNewDTO> getBurnedInfo(String orgCode, String finishedProductPartNo);

}
