package com.maxnerva.cloudmes.service.aps.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2023/06/09 08:33
 * @Version: 1.0
 */
@Data
public class ApsRequestDto implements Serializable {

    private static final long serialVersionUID = 1L;

    //  {"Plant":"F6T1","BeginDate":"2023-06-08","EndDate":"2023-06-15"}
    private String Plant;
    private String BeginDate;
    private String EndDate;

}
