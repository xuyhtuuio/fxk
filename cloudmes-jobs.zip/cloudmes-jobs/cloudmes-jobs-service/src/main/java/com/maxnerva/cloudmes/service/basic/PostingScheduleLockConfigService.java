package com.maxnerva.cloudmes.service.basic;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.ListUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.entity.WmsSapPlant;
import com.maxnerva.cloudmes.entity.basic.WmsPostingScheduleLockConfig;
import com.maxnerva.cloudmes.mapper.WmsSapPlantMapper;
import com.maxnerva.cloudmes.mapper.basic.WmsPostingScheduleLockConfigMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@Slf4j
public class PostingScheduleLockConfigService {

    @Autowired
    private WmsPostingScheduleLockConfigMapper wmsPostingScheduleLockConfigMapper;

    @Autowired
    private WmsSapPlantMapper wmsSapPlantMapper;

    public List<String> allowRun(String orgCode, String transactionType){
        List<WmsSapPlant> wmsSapPlantList = wmsSapPlantMapper.selectList(Wrappers.<WmsSapPlant>lambdaQuery()
                .eq(WmsSapPlant::getOrgCode, orgCode)
        );
        Set<String> allowRunPlantCodeSet = new HashSet();
        List<WmsPostingScheduleLockConfig> wmsPostingScheduleLockConfigList = wmsPostingScheduleLockConfigMapper.selectList(Wrappers.<WmsPostingScheduleLockConfig>lambdaQuery()
                .eq(WmsPostingScheduleLockConfig::getOrgCode, orgCode)
                .eq(WmsPostingScheduleLockConfig::getTransactionType, transactionType)
                .eq(WmsPostingScheduleLockConfig::getIsEnable, Boolean.TRUE)
        );

        wmsSapPlantList.forEach(wmsSapPlant -> {
            List<WmsPostingScheduleLockConfig> list = wmsPostingScheduleLockConfigList.stream()
                    .filter(item -> item.getOrgCode().equals(orgCode) && item.getPlantCode().equals(wmsSapPlant.getFactoryCode()))
                    .collect(Collectors.toList());
            if (CollUtil.isEmpty(list)){
                allowRunPlantCodeSet.add(wmsSapPlant.getFactoryCode());
                return;
            }
            Integer nowDay = LocalDateTime.now().getDayOfWeek().getValue();
            List<WmsPostingScheduleLockConfig> lockList = ListUtil.toList();

            list.forEach(item -> {
                if (nowDay.compareTo(item.getStartDay()) > 0 && nowDay.compareTo(item.getEndDay()) < 0){
                    lockList.add(item);
                    return;
                }
                if (nowDay.compareTo(item.getStartDay()) >= 0 && nowDay.compareTo(item.getEndDay()) < 0){
                    if (LocalDateTime.now().toLocalTime().compareTo(item.getStartTime()) >= 0){
                        lockList.add(item);
                    }
                    return;
                }
                if (nowDay.compareTo(item.getStartDay()) > 0 && nowDay.compareTo(item.getEndDay()) <= 0){
                    if (LocalDateTime.now().toLocalTime().compareTo(item.getEndTime()) <= 0){
                        lockList.add(item);
                    }
                    return;
                }
                if (nowDay.compareTo(item.getStartDay()) == 0 && nowDay.compareTo(item.getEndDay()) == 0){
                    if (LocalDateTime.now().toLocalTime().compareTo(item.getEndTime()) <= 0 && LocalDateTime.now().toLocalTime().compareTo(item.getStartTime()) >= 0){
                        lockList.add(item);
                    }
                    return;
                }
            });

            if (CollUtil.isNotEmpty(lockList)){
                return;
            } else {
                allowRunPlantCodeSet.add(wmsSapPlant.getFactoryCode());
                return;
            }
        });

        return allowRunPlantCodeSet.stream().collect(Collectors.toList());
    }
}
