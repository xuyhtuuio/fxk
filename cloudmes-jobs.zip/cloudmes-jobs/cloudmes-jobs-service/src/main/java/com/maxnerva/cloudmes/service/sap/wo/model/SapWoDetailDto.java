package com.maxnerva.cloudmes.service.sap.wo.model;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Description: wo detail
 * @Author: Chao Zhang
 * @Date: 2021/05/17
 * @Version: 1.0
 */
@Data
public class SapWoDetailDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String reservationNumber;

    private String reservationItem;

    private String mrpArea;

    private String mrpController;

    /**
     * 工厂
     */
    private String plant;

    /**
     * 工单号
     */
    private String workOrderNo;

    private String sapItemNumber;

    /**
     * 工单项次
     */
    private String workOrderItem;

    /**
     * 料号
     */
    private String partNo;

    /**
     * 物料描述
     */
    private String partDesc;

    /**
     * 版次
     */
    private String partVersion;

    /**
     * 移动类型 261
     */
    private String movementType;

    /**
     * ???
     */
    private String systemStatus;

    /**
     * 出库仓码
     */
    private String fromWarehouse;

    private String toWarehouse;

    /**
     * 需求数量
     */
    private BigDecimal requestQty;

    /**
     * 单位
     */
    private String unit;


    /**
     * 删除标识
     */
    private  String deleteFlag;


    /**
     * 物料群组
     */
    private String materialGroup;


//	parts
//	customer_material
//	required_quantity
//	base_unit_measure
//	revision_level
//	higher_level_material_no
//	rep_no
//	rep_part_no
//	sales_document_type
//	name_change
//	last_change_date
//	material_description
//	material_group
//	material_group_description
//	indicator_alternative_item
//	storage_location
//	withdrawn_quantity
//	phantom_item_indicator
//	old_material_no
//	deleted_item
//	debit/credit_indicator
//	batch_no
//	reservation/dependent_require_no
//	operatiom/activity_no
//	alternative_item_group
//	finish_goods_no
//	create_dt

}
