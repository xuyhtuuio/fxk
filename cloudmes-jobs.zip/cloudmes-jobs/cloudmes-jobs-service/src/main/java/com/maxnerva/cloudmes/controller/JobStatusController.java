package com.maxnerva.cloudmes.controller;

import com.maxnerva.cloudmes.config.Constants;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/07/13 14:31
 * @Version: 1.0
 */
@Api(tags = "Job接口")
@Slf4j
@RestController
@RequestMapping("/job")
public class JobStatusController {

    @ApiOperation("Job开关")
    @GetMapping("/off")
    public void turnOffJob() {
        Constants.continueJob = "N";
    }

    @ApiOperation("Job开关")
    @GetMapping("/on")
    public void turnOnJob() {
        Constants.continueJob = "Y";
    }

    @ApiOperation("Job开关")
    @GetMapping("/status")
    public String getJobStatus() {
        return Constants.continueJob;
    }
}
