package com.maxnerva.cloudmes.service.sfc.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/09/20 08:49
 * @Version: 1.0
 */
@Data
public class PkgLinkListDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String pkgId;
    private String linkTime;
}
