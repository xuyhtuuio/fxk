package com.maxnerva.cloudmes.service.wh.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ResponseAgileTcDTO {
    @ApiModelProperty(value = "結果為是否成功（success/failed）")
    private String result;

    @ApiModelProperty(value = "TC单号")
    private String number;

    @ApiModelProperty(value = "原因")
    private String msg;
}
