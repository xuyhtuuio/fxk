package com.maxnerva.cloudmes.controller.tj;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.maxnerva.cloudmes.common.response.Result;
import com.maxnerva.cloudmes.entity.R;
import com.maxnerva.cloudmes.entity.datacenter.WmsPostFiiLog;
import com.maxnerva.cloudmes.entity.qms.SyncQmsMsdLevelVO;
import com.maxnerva.cloudmes.entity.qms.SyncQmsValidVO;
import com.maxnerva.cloudmes.service.alarm.IWmsDeclareFilingAlarmRecordService;
import com.maxnerva.cloudmes.service.aps.ApsService;
import com.maxnerva.cloudmes.service.aps.model.ApsRequestVO;
import com.maxnerva.cloudmes.service.basic.MaterialService;
import com.maxnerva.cloudmes.service.basic.PostingConfigService;
import com.maxnerva.cloudmes.service.datacenter.IDataCenterService;
import com.maxnerva.cloudmes.service.doc.*;
import com.maxnerva.cloudmes.service.flownet.FlownetService;
import com.maxnerva.cloudmes.service.jusda.JusdaService;
import com.maxnerva.cloudmes.service.sfc.PostingSfcService;
import com.maxnerva.cloudmes.service.sfc.SfcStoredProcedureFactory;
import com.maxnerva.cloudmes.service.wh.IWmsPkgInfoService;
import com.maxnerva.cloudmes.service.wo.WoPostingService;
import com.maxnerva.cloudmes.service.wo.WorkOrderService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

@Api(tags = "EPDVI数据集成调用接口")
@Slf4j
@RestController
@RequestMapping("/dataIntegration")
public class Epd6DataIntegrationController {

    private static final String ORG_CODE = "EPDVI";
    private static final String SAP_CLIENT_CODE = "sap";
    private static final String DATE_FORMAT = "yyyyMMdd";
    private static String postDate = "N";

    @Autowired
    WorkOrderService workOrderService;

    @Autowired
    WoPostingService woPostingService;

    @Autowired
    ReceiveDocPostingService docPostingService;

    @Autowired
    TransferDocPostingService transferDocPostingService;

    @Autowired
    AdjustDocPostingService adjustDocPostingService;

    @Autowired
    CostDocPostingService costDocPostingService;
    @Autowired
    MaterialService materialService;
    @Autowired
    PostingConfigService postingConfigService;
    @Autowired
    PostingSfcService postingSfcService;
    @Autowired
    JusdaService jusdaService;
    @Autowired
    SfcStoredProcedureFactory sfcStoredProcedureFactory;
    @Autowired
    TradingDocService tradingDocService;
    @Autowired
    DocJitReceiveRecordService jitDocService;
    @Autowired
    private ApsService apsService;
    @Autowired
    private FlownetService flownetService;
    @Autowired
    private IWmsDeclareFilingAlarmRecordService wmsDeclareFilingAlarmRecordService;
    @Autowired
    private IWmsPkgInfoService wmsPkgInfoService;
    @Autowired
    private IDataCenterService dataCenterService;
    /**
     * 修改过账时间
     * 频率：10分钟执行一次
     */
    @ApiOperation("修改过账时间")
    @GetMapping("/updatePostDate")
    public void updatePostDate() {
        String s = postingConfigService.getPostDate(ORG_CODE, null);
        postDate = s;
        log.info(">>>>>>>>>EDPVI过账时间:{}",postDate);
    }

    /**
     * 同步SAP workOrder header info,
     * 频率：60分钟执行一次
     */
    @ApiOperation("同步SAP workOrder header info")
    @GetMapping("/syncSapWorkOrderHeader")
    public Result syncSapWorkOrderHeader() {
        log.info(" syncSapWorkOrderHeader start :" + System.currentTimeMillis());
        String startDate = DateUtil.format(LocalDateTime.now().plusDays(-3), DATE_FORMAT);
        String endDate = DateUtil.format(LocalDateTime.now().plusDays(2), DATE_FORMAT);
        workOrderService.syncSapWorkOrderHeader(ORG_CODE, startDate, endDate);
        log.info(" syncSapWorkOrderHeader end :" + System.currentTimeMillis());

//        log.info("syncSapWorkOrderDetail start :" + System.currentTimeMillis());
//        workOrderService.syncSapWorkOrderDetail(ORG_CODE, null, SAP_CLIENT_CODE);
//        log.info("syncSapWorkOrderDetail end :" + System.currentTimeMillis());
        return Result.success();
    }

    /**
     * 同步SAP workOrder detail info,
     * 频率：30分钟执行一次
     */
    @ApiOperation("同步SAP workOrder detail info")
    @GetMapping("/syncSapWorkOrderDetail")
    public void syncSapWorkOrderDetail() {
        log.info("syncSapWorkOrderDetail " + ORG_CODE + "start :" + System.currentTimeMillis());
        workOrderService.syncSapWorkOrderDetail(ORG_CODE, null, SAP_CLIENT_CODE);
        log.info("syncSapWorkOrderDetail " + ORG_CODE + "end :" + System.currentTimeMillis());
    }

    /**
     * 同步SFC 上料表和备料方向
     * 频率：30分钟执行一次
     */
    @ApiOperation("同步SFC 上料表和备料方向")
    @GetMapping("/syncBomFeederFromSfc")
    public void syncBomFeederFromSfc() {
        log.info("syncBomFeederFromSfc start :" + System.currentTimeMillis());
        workOrderService.syncBomFeederFromSfc(ORG_CODE, null);
        log.info("syncBomFeederFromSfc end :" + System.currentTimeMillis());
    }

    /**
     * 工单detail过账311
     * 频率：30分钟执行一次
     */
    @ApiOperation("工单detail过账311")
    @GetMapping("/postingWoDetail311")
    public void postingWoDetail311() {
        log.info("postingWoDetail311 start :" + System.currentTimeMillis());
        woPostingService.postingWoDetail311(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoDetail311 end :" + System.currentTimeMillis());
    }

    /**
     * 工单detail过账 261
     * SMT端工单 mrp_controller  in  ('J03')
     * 频率：30分钟执行一次
     */
    @ApiOperation("工单detail过账 261 SMT端工单")
    @GetMapping("/postingWoDetail261")
    public void postingWoDetail261() {
        log.info("postingWoDetail261 start :" + System.currentTimeMillis());
        woPostingService.postingWoDetail261(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoDetail261 end :" + System.currentTimeMillis());
    }


    /**
     * 收货确认并上架完成后，收货单抛QMS
     * 频率：5分钟执行一次
     */
    @ApiOperation("收货确认并上架完成后，收货单抛QMS")
    @GetMapping("/docReceivePostQms")
    public void docReceivePostQms() {
        log.info("docReceivePostQms start :" + System.currentTimeMillis());
        docPostingService.docReceivePostQms(ORG_CODE, null);
        log.info("docReceivePostQms end :" + System.currentTimeMillis());
    }

    /**
     * 收货单据确认收货后转良品仓待验状态
     * 频率：5分钟执行一次
     */
    @ApiOperation("收货单据确认收货后转良品仓待验状态")
    @GetMapping("/postingToBeInspected")
    public void postingToBeInspected() {
        log.info("postingToBeInspected start :" + System.currentTimeMillis());
        docPostingService.docPostingToBeInspected(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("postingToBeInspected end :" + System.currentTimeMillis());
    }

    /**
     * 收货单据，QMS有返回结果后转良品仓良品状态
     * 频率：5分钟执行一次
     */
    @ApiOperation("收货单据，QMS有返回结果后转良品仓良品状态")
    @GetMapping("/postingGoodProductStatus")
    public void postingGoodProductStatus() {
        log.info("postingGoodProductStatus start :" + System.currentTimeMillis());
        docPostingService.docPostingGoodProductStatus(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("postingGoodProductStatus end :" + System.currentTimeMillis());
    }

    /**
     * 收货单据，依据Q的结果判断是否需要转不良品仓
     * 频率：5分钟执行一次
     */
    @ApiOperation("收货单据，依据Q的结果判断是否需要转不良品仓")
    @GetMapping("/docPosting311ToRejectsWarehouse")
    public void docPosting311ToRejectsWarehouse() {
        log.info("docPosting311ToRejectsWarehouse start :" + System.currentTimeMillis());
        docPostingService.docPosting311ToRejectsWarehouse(SAP_CLIENT_CODE, ORG_CODE, "", postDate);
        log.info("docPosting311ToRejectsWarehouse end :" + System.currentTimeMillis());
    }

    /**
     * 收货单据确认且不需要抛Q需要过账的直接入良品仓良品状态
     * 频率：5分钟执行一次
     */
    @ApiOperation("收货单据确认且不需要抛Q需要过账的直接入良品仓良品状态")
    @GetMapping("/docPostingToGoodProduct")
    public void docPostingToGoodProduct() {
        log.info("docPostingToGoodProduct start :" + System.currentTimeMillis());
        docPostingService.docPostingToGoodProduct(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("docPostingToGoodProduct end :" + System.currentTimeMillis());
    }


    /**
     * 转仓单过账
     * 频率：5分钟执行一次
     */
    @ApiOperation("转仓单过账")
    @GetMapping("/docTransferPosting")
    public void docTransferPosting() {
        log.info("docTransferPosting start :" + System.currentTimeMillis());
        transferDocPostingService.docTransferPosting(SAP_CLIENT_CODE, ORG_CODE, Arrays.asList("5"), postDate);
        log.info("docTransferPosting end :" + System.currentTimeMillis());
    }

    /**
     * 料调单过账
     * 频率：5分钟执行一次
     */
    @ApiOperation("料调单过账")
    @GetMapping("/docAdjustPosting")
    public void docAdjustPosting() {
        log.info("docAdjustPosting start :" + System.currentTimeMillis());
        adjustDocPostingService.docAdjustPosting(SAP_CLIENT_CODE, ORG_CODE, Arrays.asList("5"), postDate);
        log.info("docAdjustPosting end :" + System.currentTimeMillis());
    }

    /**
     * 费领退及报废单过账SAP
     * 频率：5分钟执行一次
     */
    @ApiOperation("费领退及报废单过账SAP")
    @GetMapping("/costDocPostingService")
    public void costDocPostingService() {
        log.info("costDocPostingService start :" + System.currentTimeMillis());
        costDocPostingService.costDocTransferPosting(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("costDocPostingService end :" + System.currentTimeMillis());
    }

    /**
     * 成品入库过账
     * 频率：30分钟执行一次
     */
    @ApiOperation("成品入库过账")
    @GetMapping("/postingWoHeader101")
    public void postingWoHeader101() {
        log.info("postingWoHeader101 start :" + System.currentTimeMillis());
        woPostingService.postingWoHeader101(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("postingWoHeader101 end :" + System.currentTimeMillis());
    }

    /**
     * 以上已在169配置（22-12-28）
     * 工单备料PKG信息抛SFC
     * 频率：10分钟执行一次
     */
    @ApiOperation("工单备料PKG信息抛SFC")
    @GetMapping("/postingWoPreparePkgInfoToSFC")
    public void postingWoPreparePkgInfoToSFC() {
        log.info("postingWoPreparePkgInfoToSFC start :" + System.currentTimeMillis());
        postingSfcService.postingWoPreparePkgInfoToSFC(ORG_CODE);
        log.info("postingWoPreparePkgInfoToSFC end:" + System.currentTimeMillis());
    }

    /**
     * 同步SN扩展信息
     * 频率：10分钟执行一次
     */
    @Deprecated
    @ApiOperation("同步SN扩展信息")
    @GetMapping("/syncSfcExtendInfoBySn")
    public void syncSfcExtendInfoBySn() {
        log.info("syncSfcExtendInfoBySn start :" + System.currentTimeMillis());
        postingSfcService.syncSfcExtendInfoBySn(ORG_CODE);
        log.info("syncSfcExtendInfoBySn end:" + System.currentTimeMillis());
    }

    /**
     * 入库sn 回写SFC过账工站
     * 频率：10分钟执行一次
     */
    @ApiOperation("入库sn 回写SFC过账工站")
    @GetMapping("/syncWarehousingPassSnStation")
    public void syncWarehousingPassSnStation() {
        log.info("syncWarehousingPassSnStation start :" + System.currentTimeMillis());
        postingSfcService.warehousingPassSnStation(ORG_CODE);
        log.info("syncWarehousingPassSnStation end:" + System.currentTimeMillis());
    }

    /**
     * jusda VMI 收货过账SAP
     * 频率：10分钟执行一次
     */
    @ApiOperation("jusda VMI 收货过账SAP")
    @GetMapping("/jusdaReceiveInfoPostingSAP")
    public void jusdaReceiveInfoPostingSAP() {
        log.info("jusdaReceiveInfoPostingSAP start :" + System.currentTimeMillis());
        jusdaService.jusdaReceiveInfoPostingSAP(SAP_CLIENT_CODE, ORG_CODE,postDate);
        log.info("jusdaReceiveInfoPostingSAP end:" + System.currentTimeMillis());
    }

    /**
     * JUSDA收货完成后回传
     * 频率：10分钟执行一次
     */
    @ApiOperation("JUSDA收货完成后回传")
    @GetMapping("/postingJusdaReceiveCompleted")
    public void postingJusdaReceiveCompleted() {
        log.info("postingJusdaReceiveCompleted start :" + System.currentTimeMillis());
        jusdaService.postingJusdaReceiveCompleted(ORG_CODE);
        log.info("postingJusdaReceiveCompleted end:" + System.currentTimeMillis());
    }

    /**
     * JUSDA VMI收货完成，过账SAP完成后 回传JUSDA
     * 频率：10分钟执行一次
     */
    @ApiOperation("JUSDA VMI收货完成，过账SAP完成后 回传JUSDA")
    @GetMapping("/postingJusdaReceipt")
    public void postingJusdaReceipt() {
        log.info("postingJusdaReceipt start :" + System.currentTimeMillis());
        jusdaService.postingJusdaReceipt(ORG_CODE);
        log.info("postingJusdaReceipt end:" + System.currentTimeMillis());
    }

    /**
     * 上架PKG信息抛SFC
     * 频率：10分钟执行一次
     * 20221207 老孔通知不用传SFc
     */
    @Deprecated
    @ApiOperation("上架PKG信息抛SFC")
    @GetMapping("/postingUpShelfPkgInfoToSFC")
    public void postingUpShelfPkgInfoToSFC() {
        log.info("postingUpShelfPkgInfoToSFC start :" + System.currentTimeMillis());
        postingSfcService.postingUpShelfPkgInfoToSFC(ORG_CODE);
        log.info("postingUpShelfPkgInfoToSFC end:" + System.currentTimeMillis());
    }

    /**
     * 回写DN、SN的绑定关系
     *
     */
    @ApiOperation("回写DN、SN的绑定关系 ")
    @GetMapping("/sendSnDnRelationshipToSfc")
    public void sendSnDnRelationshipToSfc() {
        log.info("sendSnDnRelationshipToSfc start :" + System.currentTimeMillis());
        postingSfcService.sendSnDnRelationshipToSfc(ORG_CODE);
        log.info("sendSnDnRelationshipToSfc end:" + System.currentTimeMillis());
    }

    /**
     * insertAmazonLogToSfc
     *
     */
    @ApiOperation("insertAmazonLogToSfc ")
    @GetMapping("/insertAmazonLogToSfc")
    public void insertAmazonLog() {
        log.info("insertAmazonLogToSfc start :" + System.currentTimeMillis());
        postingSfcService.insertAmazonLog(ORG_CODE);
        log.info("insertAmazonLogToSfc end:" + System.currentTimeMillis());
    }



    /**
     * 同步sfc条码使用记录
     *
     */
    @ApiOperation("同步sfc条码使用记录")
    @GetMapping("/syncSfcWoUsePkgInfo")
    public void syncSfcWoUsePkgInfo() {
        log.info("syncSfcWoUsePkgInfo start :" + System.currentTimeMillis());
        String syncDateTime = workOrderService.getSyncStartTime(ORG_CODE);
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime ldt = LocalDateTime.parse(syncDateTime,dtf);
        DateTimeFormatter fa = DateTimeFormatter.ofPattern("yyyyMMdd HHmmss");
        String startTime = ldt.format(fa);
        workOrderService.syncSfcWoUsePkgInfo(ORG_CODE,startTime);
        log.info("syncSfcWoUsePkgInfo end:" + System.currentTimeMillis());
    }

    /**
     * 回写工单消耗量
     *
     */
    @ApiOperation("回写工单消耗量")
    @GetMapping("/syncWoDetailUseQty")
    public void syncWoDetailUseQty() {
        log.info("syncWoDetailUseQty start :" + System.currentTimeMillis());
        workOrderService.syncWoDetailUseQty(ORG_CODE);
        log.info("syncWoDetailUseQty end:" + System.currentTimeMillis());
    }

    /**
     * 工单detail过账 261
     * 组装端工单 mrp_controller  in  ('J00','J01','J02')
     * 频率：30分钟执行一次
     */
    @ApiOperation("工单detail过账 261 组装端工单")
    @GetMapping("/postingWoDetail261InAssy")
    public void postingWoDetail261InAssy() {
        log.info("postingWoDetail261InAssy start :" + System.currentTimeMillis());
        woPostingService.postingWoDetail261InAssy(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoDetail261InAssy end :" + System.currentTimeMillis());
    }

    /**
     *
     * 根据gr信息产生内交入收货单
     *
     */
    @ApiOperation("根据gr信息产生内交入收货单")
    @GetMapping("/syncTradingDoc")
    public void syncTradingDoc() {
        log.info("syncTradingDoc start :" + System.currentTimeMillis());
//        String startDate = DateUtil.format(LocalDateTime.now().plusDays(-2), DATE_FORMAT);
        String date = DateUtil.format(LocalDateTime.now(), DATE_FORMAT);
        tradingDocService.syncTradingDoc(SAP_CLIENT_CODE,ORG_CODE,date,date);
        log.info("syncTradingDoc end :" + System.currentTimeMillis());
    }

    /**
     * 工单detail退料量過賬SAP 311
     * 频率：30分钟执行一次
     */
    @ApiOperation("工单detail退料量過賬SAP 311")
    @GetMapping("/postingWoReturn311")
    public void postingWoReturn311() {
        log.info("postingWoReturn311 start :" + System.currentTimeMillis());
        woPostingService.postingWoReturn311(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoReturn311 end :" + System.currentTimeMillis());
    }

    /**
     * 工单detail备料量过账SAP 261 PTH
     */
    @ApiOperation("工单detail备料量过账SAP 261 PTH")
    @GetMapping("/postingWoDetail261InPth")
    public void postingWoDetail261InPth() {
        log.info("postingWoDetail261InPth start :" + System.currentTimeMillis());
        woPostingService.postingWoDetail261InPth(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoDetail261InPth end :" + System.currentTimeMillis());
    }

    /**
     * ASN上传抛JUSDA
     * 频率：10分钟执行一次
     */
    @ApiOperation("ASN上传抛JUSDA")
    @GetMapping("/asnPostJusda")
    public void asnPostJusda() {
        log.info("asnPostJusda start :" + System.currentTimeMillis());
        jusdaService.asnPostJusda(ORG_CODE, "0");
        log.info("asnPostJusda end:" + System.currentTimeMillis());
    }

    /**
     *
     * 从SAP产生JIT收货单
     *
     */
    @ApiOperation("从SAP产生JIT收货单")
    @GetMapping("/syncJitDoc")
    public void syncJitDoc() {
        log.info("syncJitDoc start :" + System.currentTimeMillis());
        String date = DateUtil.format(LocalDateTime.now(), DATE_FORMAT);
        jitDocService.syncJitDoc(SAP_CLIENT_CODE,ORG_CODE,date,date,"");
        log.info("syncJitDoc end :" + System.currentTimeMillis());
    }

    @ApiOperation(value = "同步APS信息")
    @PostMapping("/aps")
    public R<Void> syncWorkOrderApsInfo(@RequestBody ApsRequestVO apsRequestVO){
        log.info("syncWorkOrderApsInfo start :" + System.currentTimeMillis());
        String DATE_FORMAT = "yyyy-MM-dd";
        //获取当前时间
        String startDate = DateUtil.format(LocalDateTime.now().plusDays(-0), DATE_FORMAT);
        //获取当前时间七天后的
        String endDate = DateUtil.format(LocalDateTime.now().plusDays(7), DATE_FORMAT);
        apsRequestVO.setBeginDate(startDate);
        apsRequestVO.setOrgCode(ORG_CODE);
        apsRequestVO.setEndDate(endDate);
        apsService.doGetApsInfolist(apsRequestVO);
        log.info("syncWorkOrderApsInfo end :" + System.currentTimeMillis());
        return R.ok();
    }

    /**
     * 报废入库单过账后抛flownet
     */
    @ApiOperation("报废入库单过账后抛flownet")
    @GetMapping("/postingScrapFlownet")
    public void postingScrapFlownet() {
        log.info("postingScrapFlownet start :" + System.currentTimeMillis());
        flownetService.postingScrapFlownet(ORG_CODE);
        log.info("postingScrapFlownet end :" + System.currentTimeMillis());
    }

    /**
     * 备案预警发邮件
     */
    @ApiOperation("备案预警发邮件")
    @GetMapping("/sendMailBatch")
    public void sendMailBatch(){
        log.info("sendMailBatch start :" + System.currentTimeMillis());
        wmsDeclareFilingAlarmRecordService.sendMailBatch(ORG_CODE);
        log.info("sendMailBatch end :" + System.currentTimeMillis());
    }

    /**
     * 工单Detail同步单价
     */
    @ApiOperation("工单Detail同步单价")
    @GetMapping("/syncWorkDetailMaterialStandardPrice")
    public R syncWorkDetailMaterialStandardPrice(){
        log.info("{} {}", "开始同步单价", LocalDateTime.now());
        workOrderService.syncWorkDetailMaterialStandardPrice(ORG_CODE, SAP_CLIENT_CODE);
        log.info("{} {}", "结束同步单价", LocalDateTime.now());
        return R.ok();
    }

    @ApiOperation("自动生成TC单")
    @GetMapping("/generateTcDoc")
    public R generateTcDoc(){
        log.info("{} {}", "开始生成特采单", LocalDateTime.now());
        wmsPkgInfoService.generateTcDoc(ORG_CODE);
        log.info("{} {}", "结束生成特采单", LocalDateTime.now());
        return R.ok();
    }

    @ApiOperation("自动抛转TC单")
    @GetMapping("/postTcDoc")
    public R postTcDoc(){
        log.info("{} {}", "开始抛转特采单", LocalDateTime.now());
        wmsPkgInfoService.postTcDoc(ORG_CODE);
        log.info("{} {}", "结束抛转特采单", LocalDateTime.now());
        return R.ok();
    }

    @ApiOperation("同步qms有效期")
    @PostMapping("/materialMfgSyncFromQms")
    public R<Void> materialMfgSyncFromQms(@RequestBody List<SyncQmsValidVO> syncQmsValidVOList){
        wmsPkgInfoService.materialMfgSyncFromQms(syncQmsValidVOList);
        return R.ok();
    }

    @ApiOperation("同步qms level等级")
    @PostMapping("/materialMfgLevel")
    public R<Void> materialMfgLevel(@RequestBody List<SyncQmsMsdLevelVO> syncQmsMsdLevelVOList){
        wmsPkgInfoService.materialMfgLevel(syncQmsMsdLevelVOList);
        return R.ok();
    }


    @ApiOperation("抛转FII出货数据")
    @GetMapping("/syncShipInfoForFii")
    public R syncShipInfo(String now){
        log.info("开始抛转FII出货数据 {}", LocalDateTime.now());
        dataCenterService.syncShipInfoForFii(ORG_CODE, StrUtil.isBlank(now) ? LocalDateTime.now() : LocalDateTime.parse(now, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        log.info("结束抛转FII出货数据 {}", LocalDateTime.now());
        return R.ok();
    }

    @ApiOperation("抛转FII库存数据")
    @GetMapping("/syncInventoryForFii")
    public R syncInventoryForFii(){
        log.info("开始抛转FII库存数据 {}", LocalDateTime.now());
        dataCenterService.syncInventoryForFii(ORG_CODE, LocalDateTime.now());
        log.info("结束抛转FII库存数据 {}", LocalDateTime.now());
        return R.ok();
    }

    @ApiOperation("抛转FII-GR数据")
    @GetMapping("/syncGrInfoForFii")
    public R syncGrInfoForFii(String beginDateTime, String endDateTime){
        log.info("开始抛转FII-GR数据 {} {}-{}", LocalDateTime.now(), beginDateTime, endDateTime);
        WmsPostFiiLog wmsPostFiiLog = dataCenterService.syncGrInfoForFii(ORG_CODE, LocalDateTime.now(),
                LocalDateTime.parse(beginDateTime, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")),
                LocalDateTime.parse(endDateTime, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        log.info("结束抛转FII-GR数据 {}", LocalDateTime.now());
        if ("N".equals(wmsPostFiiLog.getStatus())) {
            return R.no();
        }
        return R.ok();
    }

    @ApiOperation("根据gr信息产生jusda内交入收货单")
    @GetMapping("/syncJusdaTradingDoc")
    public void syncJusdaTradingDoc() {
        log.info("syncJusdaTradingDoc start :" + System.currentTimeMillis());
        String date = DateUtil.format(LocalDateTime.now(), DATE_FORMAT);
        tradingDocService.syncJusdaTradingDoc(SAP_CLIENT_CODE,ORG_CODE,date,date);
        log.info("syncJusdaTradingDoc end :" + System.currentTimeMillis());
    }
}
