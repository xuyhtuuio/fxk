package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>
 * WMS过账时间段设置
 * </p>
 *
 * @author Chao Zhang
 * @since 2022-11-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("wms_posting_schedule_setting")
public class WmsPostingScheduleSettingEntity extends Model<WmsPostingScheduleSettingEntity> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @TableField("ord_code")
    private String ordCode;

    @TableField("begin_datetime")
    private LocalDateTime beginDatetime;

    @TableField("end_datetime")
    private LocalDateTime endDatetime;

    @TableField("posting_flag")
    private String postingFlag;

    @TableField("posting_date")
    private LocalDate postingDate;

    @TableField("posting_setting_desc")
    private String postingSettingDesc;

    @TableField("creator")
    private String creator;

    @TableField("creator_id")
    private Integer creatorId;

    @TableField("created_dt")
    private LocalDateTime createdDt;

    @TableField("last_editor")
    private String lastEditor;

    @TableField("last_editor_id")
    private Integer lastEditorId;

    @TableField("last_edited_dt")
    private LocalDateTime lastEditedDt;

    @TableField("trading_start_time")
    private LocalDateTime tradingStartTime;

    @TableField("trading_end_time")
    private LocalDateTime tradingEndTime;

    @TableField("ckd_ship_pgi_start_time")
    private LocalDateTime ckdShipPgiStartTime;

    @TableField("ckd_ship_pgi_end_time")
    private LocalDateTime ckdShipPgiEndTime;


    @Override
    public Serializable pkVal() {
        return this.id;
    }

}
