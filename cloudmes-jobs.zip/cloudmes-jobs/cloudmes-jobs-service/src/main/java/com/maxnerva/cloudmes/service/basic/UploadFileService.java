package com.maxnerva.cloudmes.service.basic;

import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.io.resource.InputStreamResource;
import cn.hutool.core.io.resource.MultiResource;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.TypeReference;
import com.maxnerva.cloudmes.entity.R;
import com.maxnerva.cloudmes.service.basic.model.FileUploadVO;
import com.maxnerva.cloudmes.service.basic.model.UploadFileRespDTO;
import com.maxnerva.cloudmes.service.user.UserService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.stream.Collectors;

@Service
@Slf4j
public class UploadFileService {

    @Value("${cloudmes.service.url}")
    private String basicServiceUrl;

    @Autowired
    UserService userService;

    public R<List<UploadFileRespDTO>> uploadBatch(FileUploadVO vo){
        Map<String,String> headers = userService.getUserToken();
        String userToken = headers.get("token");
        String uuid = headers.get("uuid");
        if (StringUtils.isBlank(userToken)) {
            log.error("getCodeRule get user token error");
        }
        String url = basicServiceUrl + "/cloudbase-system/client/batch/upload";
        HttpRequest httpRequest = HttpRequest.post(url)
                .header("Content-Type", "multipart/form-data")
                .header("Authorization", userToken)
                .header("uuid",uuid)
                .setConnectionTimeout(30 * 1000)
                .form("bucketName", vo.getBucketName());

        MultiResource multiResource = new MultiResource(vo.getFiles().stream().map(file -> {
            try {
                return new InputStreamResource(file.getInputStream(), file.getOriginalFilename());
            } catch (Exception e){
                throw new RuntimeException(e.getMessage());
            }
        }).collect(Collectors.toList()));
        httpRequest.form("files", multiResource);
        HttpResponse response = httpRequest.execute();
        R<List<UploadFileRespDTO>> r = (R<List<UploadFileRespDTO>>)JSON.parseObject(response.body(), new TypeReference<R<List<UploadFileRespDTO>>>(){});

        return r;
    }
}
