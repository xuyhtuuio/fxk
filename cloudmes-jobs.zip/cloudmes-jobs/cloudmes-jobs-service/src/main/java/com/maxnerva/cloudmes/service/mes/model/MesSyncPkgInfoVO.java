package com.maxnerva.cloudmes.service.mes.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName MesSyncPkgInfoVO
 * @Description PKG信息抛MesVO
 * @Author Likun
 * @Date 2023/10/17
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("PKG信息抛MesVO")
@Data
public class MesSyncPkgInfoVO {

    @ApiModelProperty("工厂组织")
    private String orgCode;

    @ApiModelProperty("pkg")
    private String pkgId;
}
