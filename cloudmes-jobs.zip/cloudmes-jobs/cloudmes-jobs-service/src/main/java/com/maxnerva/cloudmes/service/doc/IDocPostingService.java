package com.maxnerva.cloudmes.service.doc;

import com.maxnerva.cloudmes.common.response.Result;
import com.maxnerva.cloudmes.entity.doc.WmsDocReceive;
import com.maxnerva.cloudmes.entity.trading.WmsTradingRecordEntity;
import com.sap.conn.jco.JCoException;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/09/12 08:11
 * @Version: 1.0
 */
public interface IDocPostingService {

    /**
     * 执行过账
     */
    Result doPost(String sapClientCode, WmsDocReceive wmsDocReceive, String stckType,String postDate);


    Result doTradingInPosting(String sapClientCode, WmsDocReceive wmsDocReceive, WmsTradingRecordEntity tradingRecordEntity, String stckType, String postDate);

    Result doOutsourcingPosting(String sapClientCode, WmsDocReceive wmsDocReceive, String postDate) throws JCoException;
}
