package com.maxnerva.cloudmes.service.flownet;

import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.json.JSONUtil;
import com.maxnerva.cloudmes.service.flownet.model.ScrapInStorageFlownetDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;

/**
 * @Author hgx
 * @Description FlownetWebService
 * @Date 2023/8/15
 */
@RefreshScope
@Service
@Slf4j
public class FlownetWebService {

    @Value("${flownet.service.url:}")
    private String flownetServiceUrl;
    @Value("${connection.timeout:30000}")
    private int timeout;

    public HttpResponse postingScrapFlownet(ScrapInStorageFlownetDto dto) {
        String url = flownetServiceUrl + "/FASFP";
        HttpResponse response = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(timeout)
                .body(JSONUtil.toJsonStr(dto))
                .execute();
        return response;

    }
}
