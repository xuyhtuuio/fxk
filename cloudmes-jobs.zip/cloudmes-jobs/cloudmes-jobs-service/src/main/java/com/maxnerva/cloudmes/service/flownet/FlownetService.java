package com.maxnerva.cloudmes.service.flownet;

import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpStatus;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.entity.scrap.WmsWorkOrderDetailScrapInStorageDetailEntity;
import com.maxnerva.cloudmes.entity.wh.WmsPkgInfo;
import com.maxnerva.cloudmes.mapper.wh.WmsPkgInfoMapper;
import com.maxnerva.cloudmes.mapper.wo.WmsWorkOrderDetailScrapInStorageDetailMapper;
import com.maxnerva.cloudmes.service.flownet.model.ScrapInStorageFlownetDetailDto;
import com.maxnerva.cloudmes.service.flownet.model.ScrapInStorageFlownetDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @Author hgx
 * @Description FlownetService
 * @Date 2023/8/15
 */
@Service
@Slf4j
public class FlownetService {

    @Autowired
    FlownetWebService flownetWebService;

    @Autowired
    WmsWorkOrderDetailScrapInStorageDetailMapper wmsWorkOrderDetailScrapInStorageDetailMapper;

    @Autowired
    WmsPkgInfoMapper wmsPkgInfoMapper;

    public void postingScrapFlownet(String orgCode) {
        //查询需要抛flownet数据(需同一个单的明细都过账完成)
        List<WmsWorkOrderDetailScrapInStorageDetailEntity> dataList
                = wmsWorkOrderDetailScrapInStorageDetailMapper.selectPostFlownetList(orgCode);
        //根据单头id 分组数据
        Map<Integer, List<WmsWorkOrderDetailScrapInStorageDetailEntity>> collect
                = dataList.stream().collect(Collectors.groupingBy(WmsWorkOrderDetailScrapInStorageDetailEntity::getScrapInStorageId));
        for (Map.Entry<Integer, List<WmsWorkOrderDetailScrapInStorageDetailEntity>> entry : collect.entrySet()) {
            int scrapInStorageId = entry.getKey();
            List<WmsWorkOrderDetailScrapInStorageDetailEntity> detailList = entry.getValue();
            ScrapInStorageFlownetDto flownetDto = new ScrapInStorageFlownetDto();
            flownetDto.setFlownetformid(detailList.get(0).getFlownetFormId());
            //拼明细参数
            List<ScrapInStorageFlownetDetailDto> materialList = new ArrayList<>();
            for (WmsWorkOrderDetailScrapInStorageDetailEntity entity : detailList) {
                ScrapInStorageFlownetDetailDto detailDto = new ScrapInStorageFlownetDetailDto();
                //pkg信息
                WmsPkgInfo wmsPkgInfo = wmsPkgInfoMapper.selectOne(Wrappers.<WmsPkgInfo>lambdaQuery()
                        .eq(WmsPkgInfo::getPkgId, entity.getPkgId())
                        .eq(WmsPkgInfo::getOrgCode, orgCode));
                detailDto.setPPID(entity.getPpId());
                String warehouse = wmsPkgInfo.getLocationCode()
                        + "-" + wmsPkgInfo.getVehicleCode() + "-" + wmsPkgInfo.getBinCode();
                detailDto.setWarehouse(warehouse);
                detailDto.setBillingNO(entity.getPostSapNo());
                materialList.add(detailDto);
                wmsWorkOrderDetailScrapInStorageDetailMapper.update(null
                        , Wrappers.<WmsWorkOrderDetailScrapInStorageDetailEntity>lambdaUpdate()
                                .eq(WmsWorkOrderDetailScrapInStorageDetailEntity::getId, entity.getId())
                                .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostFlownetWarehouse, warehouse));
            }
            flownetDto.setMaterialList(materialList);
            HttpResponse httpResponse = flownetWebService.postingScrapFlownet(flownetDto);
            log.info("postingScrapFlownet request:{}, httpResponse:{}", JSONUtil.toJsonStr(flownetDto), httpResponse);
            if (httpResponse.getStatus() == HttpStatus.HTTP_OK) {
                String body = httpResponse.body();
                log.info("postingScrapFlownet request:{}, result:{}", JSONUtil.toJsonStr(flownetDto), body);
                JSONObject returnInfo = JSONUtil.parseObj(body);
                String flag = returnInfo.getStr("flag");
                String msg = returnInfo.getStr("msg");
                if (StringUtils.isNotBlank(flag) && "SUCCESS".equalsIgnoreCase(flag)) {
                    wmsWorkOrderDetailScrapInStorageDetailMapper.update(null
                            , Wrappers.<WmsWorkOrderDetailScrapInStorageDetailEntity>lambdaUpdate()
                                    .eq(WmsWorkOrderDetailScrapInStorageDetailEntity::getScrapInStorageId, scrapInStorageId)
                                    .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostFlownetDate, LocalDateTime.now())
                                    .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostFlownetFlag, "Y")
                                    .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostFlownetMsg, msg));
                } else {
                    wmsWorkOrderDetailScrapInStorageDetailMapper.update(null
                            , Wrappers.<WmsWorkOrderDetailScrapInStorageDetailEntity>lambdaUpdate()
                                    .eq(WmsWorkOrderDetailScrapInStorageDetailEntity::getScrapInStorageId, scrapInStorageId)
                                    .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostFlownetDate, LocalDateTime.now())
                                    .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostFlownetFlag, "N")
                                    .set(WmsWorkOrderDetailScrapInStorageDetailEntity::getPostFlownetMsg, msg));
                }
            }
        }
    }
}
