package com.maxnerva.cloudmes.entity.wo;

import java.time.LocalDateTime;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * (WmsWorkOrderPrepareCkdShipHeader)实体类
 *
 * @author hgx
 * @since 2024-01-30
 */

@ApiModel("WmsWorkOrderPrepareCkdShipHeader实体类")
@Data
public class WmsWorkOrderPrepareCkdShipHeader extends BaseEntity<WmsWorkOrderPrepareCkdShipHeader> {
 
   
    @ApiModelProperty("id")
    private Integer id;
   
    @ApiModelProperty("流水码")
    private String serialNo;
   
    @ApiModelProperty("工单")
    private String workOrderNo;
   
    @ApiModelProperty("Bu")
    private String orgCode;
   
    @ApiModelProperty("工厂")
    private String plantCode;
   
    @ApiModelProperty("poNo1")
    private String poNo1;
   
    @ApiModelProperty("poNo2")
    private String poNo2;
   
    @ApiModelProperty("soNo")
    private String soNo;
   
    @ApiModelProperty("dnNo")
    private String dnNo;
   
    @ApiModelProperty("出货地")
    private String siteCode;

    @ApiModelProperty("创建POpostSapFlag")
    private String poPostSapFlag;

    @ApiModelProperty("创建PO抛SAP返回msg")
    private String poPostSapMsg;

    @ApiModelProperty("创建PO抛SAP时间")
    private LocalDateTime poPostSapDate;

    @ApiModelProperty("产生DN/SOpostSapFlag")
    private String dnPostSapFlag;

    @ApiModelProperty("产生DN/SO抛SAP返回msg")
    private String dnPostSapMsg;

    @ApiModelProperty("产生DN/SO抛SAP时间")
    private LocalDateTime dnPostSapDate;

    @ApiModelProperty("出货标识")
    private String shipFlag;

    @ApiModelProperty("是否扣账（0：否，1：是）")
    private String pgiFlag;

    @ApiModelProperty("扣账时间")
    private LocalDateTime pgiDate;

    @ApiModelProperty("pgi单号")
    private String pgiNo;

    @ApiModelProperty("pgi信息")
    private String pgiMsg;

    @ApiModelProperty("同步收货单：未抛：0，已抛：1")
    private String syncReceiveDocFlag;

    @ApiModelProperty("同步收货单结果描述")
    private String syncReceiveDocMsg;

    @ApiModelProperty("同步收货单时间")
    private LocalDateTime syncReceiveDocDate;
}

