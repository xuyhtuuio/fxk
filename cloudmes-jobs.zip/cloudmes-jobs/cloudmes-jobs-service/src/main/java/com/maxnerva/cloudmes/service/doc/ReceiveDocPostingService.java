package com.maxnerva.cloudmes.service.doc;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpStatus;
import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.github.pagehelper.util.StringUtil;
import com.maxnerva.cloudmes.common.response.Result;
import com.maxnerva.cloudmes.config.Constants;
import com.maxnerva.cloudmes.config.SupplierCheckConfig;
import com.maxnerva.cloudmes.entity.WmsSapPlant;
import com.maxnerva.cloudmes.entity.basic.SysDict;
import com.maxnerva.cloudmes.entity.basic.WmsSapWarehouseCode;
import com.maxnerva.cloudmes.entity.doc.ReceiveDocScCheckDTO;
import com.maxnerva.cloudmes.entity.doc.ScCheckPartNoDTO;
import com.maxnerva.cloudmes.entity.doc.WmsDocJitReceiveGrRecord;
import com.maxnerva.cloudmes.entity.doc.WmsDocReceive;
import com.maxnerva.cloudmes.entity.jusda.WmsJusdaReceiptEntity;
import com.maxnerva.cloudmes.entity.outsourcing.WmsOutsourcingWorkOrderDetail;
import com.maxnerva.cloudmes.entity.outsourcing.WmsOutsourcingWorkOrderHeader;
import com.maxnerva.cloudmes.entity.trading.WmsTradingConfig;
import com.maxnerva.cloudmes.entity.trading.WmsTradingRecordEntity;
import com.maxnerva.cloudmes.entity.wh.WmsPkgInfo;
import com.maxnerva.cloudmes.entity.wo.WmsCkdCus;
import com.maxnerva.cloudmes.entity.wo.WmsWarehouseRelation;
import com.maxnerva.cloudmes.enums.ValueType;
import com.maxnerva.cloudmes.mapper.WmsSapPlantMapper;
import com.maxnerva.cloudmes.mapper.basic.SysDictMapper;
import com.maxnerva.cloudmes.mapper.basic.WmsSapWarehouseCodeMapper;
import com.maxnerva.cloudmes.mapper.doc.WmsDocJitReceiveGrRecordMapper;
import com.maxnerva.cloudmes.mapper.doc.WmsDocReceiveMapper;
import com.maxnerva.cloudmes.mapper.jusda.WmsJusdaReceiptMapper;
import com.maxnerva.cloudmes.mapper.outsourcing.WmsOutsourcingSapTransactionLogMapper;
import com.maxnerva.cloudmes.mapper.outsourcing.WmsOutsourcingWorkOrderDetailMapper;
import com.maxnerva.cloudmes.mapper.outsourcing.WmsOutsourcingWorkOrderHeaderMapper;
import com.maxnerva.cloudmes.mapper.trading.WmsTradingConfigMapper;
import com.maxnerva.cloudmes.mapper.trading.WmsTradingRecordMapper;
import com.maxnerva.cloudmes.mapper.wh.WmsPkgInfoMapper;
import com.maxnerva.cloudmes.mapper.wo.WmsWarehouseRelationMapper;
import com.maxnerva.cloudmes.service.qms.QmsService;
import com.maxnerva.cloudmes.service.qms.model.ReceiveIqcDataVo;
import com.maxnerva.cloudmes.service.sap.doc.DocRfcService;
import com.maxnerva.cloudmes.service.sap.doc.model.BlendIngCusDTO;
import com.maxnerva.cloudmes.service.sap.material.MaterialRfcService;
import com.maxnerva.cloudmes.service.sap.material.model.MaterialInfoDto;
import com.maxnerva.cloudmes.service.sap.trading.TradingRfcService;
import com.maxnerva.cloudmes.service.sap.trading.model.GenerateTradingNumberDto;
import com.maxnerva.cloudmes.service.sap.wh.WhRfcService;
import com.maxnerva.cloudmes.service.sap.wh.model.TransferDto;
import com.maxnerva.cloudmes.service.wo.IWmsCkdCusService;
import com.sap.conn.jco.JCoException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @ClassName 单据过账服务
 * @Description 工单管理service
 * @Author Likun
 * @Date 2022/8/30
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Service
@Slf4j
public class ReceiveDocPostingService {

    @Autowired
    SupplierCheckConfig supplierCheckConfig;

    @Autowired
    DocPostingFactory postFactory;

    @Autowired
    WmsDocReceiveMapper wmsDocReceiveMapper;

    @Autowired
    WhRfcService whRfcService;

    @Autowired
    WmsWarehouseRelationMapper warehouseRelationMapper;

    @Autowired
    QmsService qmsService;

    @Autowired
    WmsPkgInfoMapper wmsPkgInfoMapper;

    @Autowired
    MaterialRfcService materialRfcService;

    @Autowired
    IWmsDocReceiveService wmsDocReceiveService;

    @Autowired
    WmsTradingRecordMapper wmsTradingRecordMapper;

    @Autowired
    WmsTradingConfigMapper wmsTradingConfigMapper;

    @Autowired
    WmsSapPlantMapper wmsSapPlantMapper;

    @Autowired
    TradingRfcService tradingRfcService;

    @Autowired
    WmsOutsourcingSapTransactionLogMapper wmsOutsourcingSapTransactionLogMapper;

    @Autowired
    WmsOutsourcingWorkOrderHeaderMapper wmsOutsourcingWorkOrderHeaderMapper;

    @Autowired
    WmsOutsourcingWorkOrderDetailMapper wmsOutsourcingWorkOrderDetailMapper;

    @Autowired
    SysDictMapper sysDictMapper;

    @Autowired
    DocRfcService docRfcService;

    @Autowired
    IWmsCkdCusService wmsCkdCusService;

    @Autowired
    WmsSapWarehouseCodeMapper wmsSapWarehouseCodeMapper;

    @Autowired
    WmsJusdaReceiptMapper wmsJusdaReceiptMapper;

    @Autowired
    WmsDocJitReceiveGrRecordMapper wmsDocJitReceiveGrRecordMapper;
//    @Autowired
//    DictL dictLangUtils;

    /**
     * 收货单据确认收货且需要抛Q的转良品仓待验状态
     */
    public void docPostingToBeInspected(String sapClientCode, String orgCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }

        List<WmsDocReceive> docList =
                wmsDocReceiveMapper.selectList(Wrappers.<WmsDocReceive>lambdaQuery()
                        .eq(WmsDocReceive::getOrgCode, orgCode)
                        .eq(WmsDocReceive::getPostingQmsFlag, "Y")
//                        .eq(WmsDocReceive::getToQmsFlag, true)
                        .eq(WmsDocReceive::getPostingSapMethodFlag, "Y")
                        .eq(WmsDocReceive::getConfirmReceiptFlag, 1)
                        .ne(WmsDocReceive::getDocTypeCode, "INNERRING_RECEIVE_DOC")
                        .ne(WmsDocReceive::getDocTypeCode, "OUTSOURCING_DOC")
                        .isNull(WmsDocReceive::getSapReturnNumber));

        docList.forEach(d -> {
            if ("N".equalsIgnoreCase(Constants.continueJob)) {
                return;
            }
            if (StringUtils.isEmpty(d.getFromDocNo())) {
                d.setFromDocNo(d.getDocNo());
            }
            //直接入良品仓待待验状态
            Result b = postFactory.doPosting(sapClientCode, d, "X", postDate);
            log.info("docPostingToBeInspected, {}，result：{}", JSONUtil.toJsonStr(d), JSONUtil.toJsonStr(b));

            WmsDocReceive wmsDocReceive = new WmsDocReceive();
            wmsDocReceive.setId(d.getId());
            if (b.getCode() == 0) {
                wmsDocReceive.setSapReturnNumber(b.getMessage());
                wmsDocReceive.setSapReturnMessage("OK");
                wmsDocReceive.setPostingSapMethodDate(LocalDateTime.now());
                wmsDocReceive.updateById();
            } else {
               /* wmsDocReceive.setSapReturnNumber(null);
                wmsDocReceive.setSapReturnMessage(b.getMessage());
                wmsDocReceive.setPostingSapMethodDate(LocalDateTime.now());
                wmsDocReceive.updateById();*/
                LambdaUpdateWrapper<WmsDocReceive> updateWrapper = new LambdaUpdateWrapper<>();
                updateWrapper.set(WmsDocReceive::getSapReturnNumber, null);
                updateWrapper.set(WmsDocReceive::getSapReturnMessage, b.getMessage());
                updateWrapper.set(WmsDocReceive::getPostingSapMethodDate, LocalDateTime.now());
                updateWrapper.eq(WmsDocReceive::getId, d.getId());
                wmsDocReceiveService.update(updateWrapper);
            }


        });
    }

    /**
     * 收货单据确认收货且不需要抛Q的直接入良品仓良品状态，排除内交单
     */
    public void docPostingToGoodProduct(String sapClientCode, String orgCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }

        List<WmsDocReceive> docList =
                wmsDocReceiveMapper.selectList(Wrappers.<WmsDocReceive>lambdaQuery()
                        .eq(WmsDocReceive::getOrgCode, orgCode)
                        .eq(WmsDocReceive::getConfirmReceiptFlag, 1)
                        .eq(WmsDocReceive::getPostingQmsFlag, "N")
                        .eq(WmsDocReceive::getPostingSapMethodFlag, "Y")
                        .ne(WmsDocReceive::getDocTypeCode, "INNERRING_RECEIVE_DOC")
                        .isNull(WmsDocReceive::getSapReturnNumber));

        docList.forEach(d -> {
            if ("N".equalsIgnoreCase(Constants.continueJob)) {
                return;
            }
            //直接入良品仓良品状态
            Result b = postFactory.doPosting(sapClientCode, d, "", postDate);

            log.info("docPostingToGoodProduct, {}，result：{}", JSONUtil.toJsonStr(d), JSONUtil.toJsonStr(b));

            WmsDocReceive wmsDocReceive = new WmsDocReceive();
            wmsDocReceive.setId(d.getId());
            if (b.getCode() == 0) {
                wmsDocReceive.setSapConfirmNumber("OK");
                wmsDocReceive.setSapReturnNumber(b.getMessage());
                wmsDocReceive.setSapReturnMessage("OK");
                wmsDocReceive.setSapConfirmMessage("OK");
                wmsDocReceive.setPostingSapMethodDate(LocalDateTime.now());
                wmsDocReceive.updateById();
            } else {
                /*wmsDocReceive.setSapConfirmNumber(null);
                wmsDocReceive.setSapConfirmMessage(b.getMessage());
                wmsDocReceive.setSapConfirmDatetime(LocalDateTime.now());
                wmsDocReceive.updateById();*/
                LambdaUpdateWrapper<WmsDocReceive> updateWrapper = new LambdaUpdateWrapper<>();
                updateWrapper.set(WmsDocReceive::getSapConfirmNumber, null);
                updateWrapper.set(WmsDocReceive::getSapReturnNumber, null);
                //updateWrapper.set(WmsDocReceive::getSapConfirmMessage, b.getMessage());
                updateWrapper.set(WmsDocReceive::getSapReturnMessage, b.getMessage());
                updateWrapper.set(WmsDocReceive::getSapConfirmDatetime, LocalDateTime.now());
                updateWrapper.set(WmsDocReceive::getPostingSapMethodDate, LocalDateTime.now());
                updateWrapper.eq(WmsDocReceive::getId, d.getId());
                wmsDocReceiveService.update(updateWrapper);
            }
        });
    }

    /**
     * 收货单据，QMS有返回结果后转良品仓良品状态
     * 不需要抛QMS的直接入良品仓良品状态
     */
    public void docPostingGoodProductStatus(String sapClientCode, String orgCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }

        List<WmsDocReceive> docList =
                wmsDocReceiveMapper.selectList(Wrappers.<WmsDocReceive>lambdaQuery()
                        .eq(WmsDocReceive::getOrgCode, orgCode)
                        .eq(WmsDocReceive::getConfirmReceiptFlag, 1)
                        .apply("((posting_qms_flag ='Y' and qms_return_message !='H'  and posting_sap_method_flag ='Y' and qms_return_flag =1 and sap_return_number is not null  and " +
                                "sap_confirm_number is null)) ")
                );

        docList.forEach(d -> {
            if ("N".equalsIgnoreCase(Constants.continueJob)) {
                return;
            }
           /* //如果工厂组织为"CABG_VN",将收货单版次赋值成A
            if ("CABG_VN".equals(orgCode)) {
                d.setPartNoVersion("A");
            }*/
            TransferDto dto = new TransferDto();
            dto.setTransactionDate(postDate);
            dto.setDocDate(postDate);
            dto.setMoveType("321");
            dto.setGmCode("04");
            dto.setQty(d.getConfirmQty().toString());
            dto.setUnit(d.getUomCode());
            dto.setFromPlant(d.getPlantCode());
            dto.setFromWarehouseName(d.getSapWarehouseCode());
            dto.setFromPartNo(d.getPartNo());
            if (StringUtils.isNotBlank(d.getPartNoVersion())) {
                dto.setFromPartVersion(d.getPartNoVersion());
                dto.setToPartVersion(d.getPartNoVersion());
            }
            dto.setToPlant(d.getPlantCode());
            dto.setToWarehouseName(d.getSapWarehouseCode());
            dto.setToPartNo(d.getPartNo());

            try {
//                String s1 = materialRfcService.doGetMaterialValueType(sapClientCode, d.getPlantCode(), d.getPartNo(), d.getSapWarehouseCode());
                String s1 = materialRfcService.getValueType(sapClientCode, orgCode, d.getPlantCode(),
                        d.getPartNo(), d.getPartNoVersion(), d.getSapWarehouseCode());
                if (StringUtils.isNotBlank(s1)) {
                    dto.setValueType(s1);
                } else {
                   /* WmsDocReceive wmsDocReceive = new WmsDocReceive();
                    wmsDocReceive.setId(d.getId());
                    wmsDocReceive.setSapConfirmNumber(null);
                    wmsDocReceive.setSapConfirmMessage("value type not exist");
                    wmsDocReceive.setSapConfirmDatetime(LocalDateTime.now());
                    wmsDocReceive.updateById();*/
                    LambdaUpdateWrapper<WmsDocReceive> updateWrapper = new LambdaUpdateWrapper<>();
                    updateWrapper.set(WmsDocReceive::getSapConfirmNumber, null);
                    updateWrapper.set(WmsDocReceive::getSapConfirmMessage, "value type not exist");
                    updateWrapper.set(WmsDocReceive::getSapConfirmDatetime, LocalDateTime.now());
                    updateWrapper.eq(WmsDocReceive::getId, d.getId());
                    wmsDocReceiveService.update(updateWrapper);
                    return;
                }

                String s = whRfcService.doTransfer(sapClientCode, dto);

                log.info("docPostingGoodProductStatus, {}，result：{}", JSONUtil.toJsonStr(d), s);
                WmsDocReceive wmsDocReceive = new WmsDocReceive();
                wmsDocReceive.setId(d.getId());
                if (StringUtils.isNotBlank(s)) {
                    wmsDocReceive.setSapConfirmNumber(s);
                    wmsDocReceive.setSapConfirmMessage("OK");
                    wmsDocReceive.setSapConfirmDatetime(LocalDateTime.now());
                    wmsDocReceive.updateById();

                    //解锁PKG
                    if ("AW".contains(d.getQmsReturnMessage())) {
                        WmsPkgInfo pkgInfo = new WmsPkgInfo();
                        pkgInfo.setLockStatus("0");
                        pkgInfo.setLockMessage(null);
                        int update = wmsPkgInfoMapper.update(pkgInfo, Wrappers.<WmsPkgInfo>lambdaUpdate()
                                .eq(WmsPkgInfo::getOrgCode, d.getOrgCode())
                                .eq(WmsPkgInfo::getWmsNo, d.getDocNo()));
                    }
                } else {
                    wmsDocReceive.setSapConfirmMessage("sap not response error");
                    wmsDocReceive.setSapConfirmDatetime(LocalDateTime.now());
                    wmsDocReceive.updateById();
                }
            } catch (Exception e) {
                /*WmsDocReceive wmsDocReceive = new WmsDocReceive();
                wmsDocReceive.setId(d.getId());
                wmsDocReceive.setSapConfirmNumber(null);
                wmsDocReceive.setSapConfirmMessage(e.getMessage());
                wmsDocReceive.setSapConfirmDatetime(LocalDateTime.now());
                wmsDocReceive.updateById();*/
                LambdaUpdateWrapper<WmsDocReceive> updateWrapper = new LambdaUpdateWrapper<>();
                updateWrapper.set(WmsDocReceive::getSapConfirmNumber, null);
                updateWrapper.set(WmsDocReceive::getSapConfirmMessage, e.getMessage());
                updateWrapper.set(WmsDocReceive::getSapConfirmDatetime, LocalDateTime.now());
                updateWrapper.eq(WmsDocReceive::getId, d.getId());
                wmsDocReceiveService.update(updateWrapper);
            }
        });
    }


    /**
     * 收货单据，依据Q的结果判断是否需要转不良品仓
     */
    public void docPosting311ToRejectsWarehouse(String sapClientCode, String orgCode, String docTypeCode, String postDate) {


        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }
        //需过账DOC list
        List<WmsDocReceive> docList =
                wmsDocReceiveMapper.selectList(Wrappers.<WmsDocReceive>lambdaQuery()
                        .eq(WmsDocReceive::getOrgCode, orgCode)
                        .eq(WmsDocReceive::getPostingSapMethodFlag, "Y")
                        .eq(WmsDocReceive::getConfirmReceiptFlag, 1)
                        .eq(WmsDocReceive::getQmsReturnFlag, 1)
                        // R：拒收  S：重工 A：合格 W：特采   H:带判
                        .in(WmsDocReceive::getQmsReturnMessage, Arrays.asList("R", "S"))
                        .isNotNull(WmsDocReceive::getSapReturnNumber)
                        .isNotNull(WmsDocReceive::getSapConfirmNumber)
                        .last(" and  (sap_transfer_rejects_number is null or sap_transfer_rejects_number = '')"));

        List<WmsWarehouseRelation> wmsWarehouseRelations =
                warehouseRelationMapper.selectList(Wrappers.<WmsWarehouseRelation>lambdaQuery().eq(WmsWarehouseRelation::getOrgCode, orgCode).eq(WmsWarehouseRelation::getChangeType,
                        "QMS_TRANSFER_REJECTS"));

        docList.forEach(d -> {
            if ("N".equalsIgnoreCase(Constants.continueJob)) {
                return;
            }
            TransferDto dto = new TransferDto();

            Optional<WmsWarehouseRelation> first =
                    wmsWarehouseRelations.stream().filter(a -> a.getFromWarehouseCode().equalsIgnoreCase(d.getSapWarehouseCode()) && a.getPlantCode().equalsIgnoreCase(d.getPlantCode())).findFirst();

            if (first.isPresent()) {
                dto.setToWarehouseName(first.get().getToWarehouseCode());
            } else {
               /* WmsDocReceive wmsDocReceive = new WmsDocReceive();
                wmsDocReceive.setId(d.getId());
                wmsDocReceive.setSapTransferRejectsNumber(null);
                wmsDocReceive.setSapTransferRejectsMessage("no config transfer to warehouse code");
                wmsDocReceive.setSapTransferRejectsDatetime(LocalDateTime.now());
                wmsDocReceive.updateById();*/
                LambdaUpdateWrapper<WmsDocReceive> updateWrapper = new LambdaUpdateWrapper<>();
                updateWrapper.set(WmsDocReceive::getSapTransferRejectsNumber, null);
                updateWrapper.set(WmsDocReceive::getSapTransferRejectsMessage, "no config transfer to warehouse code");
                updateWrapper.set(WmsDocReceive::getSapTransferRejectsDatetime, LocalDateTime.now());
                updateWrapper.eq(WmsDocReceive::getId, d.getId());
                wmsDocReceiveService.update(updateWrapper);
                return;
            }


            dto.setTransactionDate(postDate);
            dto.setDocDate(postDate);
            dto.setMoveType("311");
            dto.setGmCode("04");
            dto.setQty(d.getConfirmQty().toString());
            dto.setUnit("EA");
            dto.setFromPlant(d.getPlantCode());
            dto.setFromWarehouseName(d.getSapWarehouseCode());
            dto.setFromPartNo(d.getPartNo());
            if (StringUtils.isNotBlank(d.getPartNoVersion())) {
                dto.setFromPartVersion(d.getPartNoVersion());
                dto.setToPartVersion(d.getPartNoVersion());
            }
            dto.setToPlant(d.getPlantCode());
            dto.setToPartNo(d.getPartNo());
            String s = null;
            try {

                String s1 = materialRfcService.doGetMaterialValueType(sapClientCode, d.getPlantCode(), d.getPartNo(), d.getSapWarehouseCode());
                if (StringUtils.isNotBlank(s1)) {
                    dto.setValueType(s1);
                } else {
                    WmsDocReceive wmsDocReceive = new WmsDocReceive();
                    wmsDocReceive.setId(d.getId());
                    wmsDocReceive.setSapTransferRejectsMessage("value type not exist");
                    wmsDocReceive.setSapTransferRejectsDatetime(LocalDateTime.now());
                    wmsDocReceive.updateById();
                    return;
                }

                s = whRfcService.doTransfer(sapClientCode, dto);

                WmsDocReceive wmsDocReceive = new WmsDocReceive();
                wmsDocReceive.setId(d.getId());
                wmsDocReceive.setSapTransferRejectsNumber(s);
                wmsDocReceive.setSapTransferRejectsMessage(first.get().getToWarehouseCode() + "--" + s1);
                wmsDocReceive.setSapTransferRejectsDatetime(LocalDateTime.now());
                wmsDocReceive.updateById();

                //解锁PKG,修改SAP仓码
                WmsPkgInfo pkgInfo = new WmsPkgInfo();
                pkgInfo.setLockStatus("0");
                pkgInfo.setLockMessage(null);
                pkgInfo.setSapWarehouseCode(first.get().getToWarehouseCode());
                int update = wmsPkgInfoMapper.update(pkgInfo, Wrappers.<WmsPkgInfo>lambdaUpdate()
                        .eq(WmsPkgInfo::getOrgCode, d.getOrgCode())
                        .eq(WmsPkgInfo::getWmsNo, d.getDocNo()));


            } catch (JCoException e) {
                log.error(e.getMessage());
               /* WmsDocReceive wmsDocReceive = new WmsDocReceive();
                wmsDocReceive.setId(d.getId());
                wmsDocReceive.setSapTransferRejectsNumber(null);
                wmsDocReceive.setSapTransferRejectsMessage("sap posting 311 error");
                wmsDocReceive.setSapTransferRejectsDatetime(LocalDateTime.now());
                wmsDocReceive.updateById();*/
                LambdaUpdateWrapper<WmsDocReceive> updateWrapper = new LambdaUpdateWrapper<>();
                updateWrapper.set(WmsDocReceive::getSapTransferRejectsNumber, null);
                updateWrapper.set(WmsDocReceive::getSapTransferRejectsMessage, "sap posting 311 error");
                updateWrapper.set(WmsDocReceive::getSapTransferRejectsDatetime, LocalDateTime.now());
                updateWrapper.eq(WmsDocReceive::getId, d.getId());
                wmsDocReceiveService.update(updateWrapper);
            }

        });
    }


    /**
     * 收货确认并上架完成收收货单抛QMS
     *
     * @param orgCode
     * @param docTypeCode
     */
    public void docReceivePostQms(String orgCode, String docTypeCode) {
        // 需要check协作云平台的BU
        List<SysDict> dictList = sysDictMapper.selectDictList("WMS_RECEIVE_DOC_CHECK_SC_CONFIG");
        // bu->向协作云传参的BU-code
        Map<String, String> scCheckBuMap = dictList.stream().collect(Collectors.toMap(k -> k.getDictCode(), v -> v.getDictName()));
        //需过账DOC list
        List<WmsDocReceive> docList =
                wmsDocReceiveMapper.selectList(Wrappers.<WmsDocReceive>lambdaQuery()
                        .eq(WmsDocReceive::getOrgCode, orgCode)
                        .eq(WmsDocReceive::getConfirmReceiptFlag, 1)
                        .eq(WmsDocReceive::getPostingQmsFlag, "Y")
                        .eq(WmsDocReceive::getDocStatus, "SHELF_COMPLETED")
                        .eq(WmsDocReceive::getToQmsFlag, false));

        if (CollUtil.isEmpty(docList)) {
            return;
        }

        for (WmsDocReceive wmsDocReceiveDb : docList) {
            try {
                if (scCheckBuMap.containsKey(wmsDocReceiveDb.getOrgCode())) {
                    Boolean isCheck = receiveDocScCheck(wmsDocReceiveDb, scCheckBuMap.get(wmsDocReceiveDb.getOrgCode()));
                    if (BooleanUtil.isFalse(isCheck)) {
                        continue;
                    }
                }
                //如果收货单单据类型是委外收货单，并且单据号是RCMB2开头，则不抛qms，
                // 并且将收货单抛q状态改成完成，并且抛qms信息记录为:委外重复单据
                /*if (StrUtil.equals("OUTSOURCING_DOC", wmsDocReceiveDb.getDocTypeCode()) &&
                        wmsDocReceiveDb.getDocNo().startsWith("RCMB2")) {
                    wmsDocReceiveMapper.update(null, Wrappers.<WmsDocReceive>lambdaUpdate()
                            .eq(WmsDocReceive::getId, wmsDocReceiveDb.getId())
                            .set(WmsDocReceive::getToQmsFlag, true)
                            .set(WmsDocReceive::getToQmsDate, LocalDateTime.now())
                            .set(WmsDocReceive::getToQmsMessage, "委外重复单据"));
                    continue;
                }*/
                List<ReceiveIqcDataVo> receiveIqcDataVoList = new ArrayList<>();
                //收货完成后，调用QMS的IQC建单接口，抛数据给QMS
                ReceiveIqcDataVo receiveIqcDataVo = new ReceiveIqcDataVo();
                receiveIqcDataVo.setGrnNo(wmsDocReceiveDb.getDocNo());
                receiveIqcDataVo.setPoNo(wmsDocReceiveDb.getPoNo());
                if ("CMB".equals(wmsDocReceiveDb.getOrgCode())) {
                    if ("JIT".equalsIgnoreCase(wmsDocReceiveDb.getSapWarehouseCode()) && "PN_RECEIVE_DOC".equals(wmsDocReceiveDb.getDocTypeCode())) {
                        receiveIqcDataVo.setPoNo(wmsDocReceiveDb.getSapReturnNumber());
                    } else if ("JIT_PN_RECEIVE_DOC".equals(wmsDocReceiveDb.getDocTypeCode())) {
                        receiveIqcDataVo.setPoNo(wmsDocReceiveDb.getFromDocNo());
                        WmsDocJitReceiveGrRecord wmsDocJitReceiveGrRecord = wmsDocJitReceiveGrRecordMapper.selectOne(Wrappers.<WmsDocJitReceiveGrRecord>lambdaQuery()
                                .eq(WmsDocJitReceiveGrRecord::getOrgCode, wmsDocReceiveDb.getOrgCode())
                                .eq(WmsDocJitReceiveGrRecord::getAsnNo, wmsDocReceiveDb.getFromDocNo())
                                .last("limit 1")
                        );
                        if (ObjectUtil.isNotNull(wmsDocJitReceiveGrRecord)) {
                            receiveIqcDataVo.setInvoiceNumber(wmsDocJitReceiveGrRecord.getPartDesc());
                        }
                    }
                }
                receiveIqcDataVo.setPoDocumentType(wmsDocReceiveDb.getPoDocumentType());
                receiveIqcDataVo.setMaterialNo(wmsDocReceiveDb.getPartNo());
                receiveIqcDataVo.setMaterialVersion(wmsDocReceiveDb.getPartNoVersion());
                receiveIqcDataVo.setMfg(wmsDocReceiveDb.getMfgCode());
                receiveIqcDataVo.setMfgName(wmsDocReceiveDb.getMfgName());
                receiveIqcDataVo.setMfgMaterialNo(wmsDocReceiveDb.getMfgPartNo());
                receiveIqcDataVo.setMfgMaterialVersion(wmsDocReceiveDb.getMfgVersion());
                receiveIqcDataVo.setClientele(wmsDocReceiveDb.getCustomerPartNo());
                receiveIqcDataVo.setQty(wmsDocReceiveDb.getDocQty());
                receiveIqcDataVo.setUnit(wmsDocReceiveDb.getUomCode());
                receiveIqcDataVo.setPlant(wmsDocReceiveDb.getPlantCode());
                receiveIqcDataVo.setLocation(wmsDocReceiveDb.getSapWarehouseCode());
                receiveIqcDataVo.setCollectPerson("WMS");
                //待确认
                receiveIqcDataVo.setCollectDate(new Date());
                receiveIqcDataVo.setReceiveAccountDate(new Date());
                receiveIqcDataVo.setIsCartonBroken(wmsDocReceiveDb.getInspectResult()
                        .equalsIgnoreCase("Y") ? Boolean.FALSE : Boolean.TRUE);
                receiveIqcDataVo.setOrgCode(wmsDocReceiveDb.getOrgCode());
                receiveIqcDataVo.setGrnResource("WMS");
                receiveIqcDataVo.setIsDispatch(wmsDocReceiveDb.getIsUrgent());
                receiveIqcDataVo.setPurchaseOrg(wmsDocReceiveDb.getPurchaseOrg());
                receiveIqcDataVo.setPoItem(wmsDocReceiveDb.getPoItem());
                receiveIqcDataVo.setVendorCode(wmsDocReceiveDb.getVendorCode());
                //查询收货单已上架的条码信息
                List<WmsPkgInfo> wmsPkgInfoList = wmsPkgInfoMapper.selectList(Wrappers.<WmsPkgInfo>lambdaQuery()
                        .eq(WmsPkgInfo::getOrgCode, orgCode)
                        .eq(WmsPkgInfo::getPlantCode, wmsDocReceiveDb.getPlantCode())
                        .eq(WmsPkgInfo::getWmsNo, wmsDocReceiveDb.getDocNo()));
                if (CollUtil.isNotEmpty(wmsPkgInfoList)) {
                    StringBuilder stringBuilder = new StringBuilder();
                    int i = 0;
                    for (WmsPkgInfo wmsPkgInfo : wmsPkgInfoList) {
                        //避免QMS异常
                        if (i++ > 5) {
                            break;
                        }
                        String areaCode = wmsPkgInfo.getAreaCode();
                        String locationCode = wmsPkgInfo.getLocationCode();
                        String vehicleCode = wmsPkgInfo.getVehicleCode();
                        String binCode = wmsPkgInfo.getBinCode();
                        stringBuilder.append("[").append(areaCode).append("]")
                                .append("[").append(locationCode).append("]")
                                .append("[").append(vehicleCode).append("]")
                                .append("[").append(binCode).append("]")
                                .append(",");
                    }
                    receiveIqcDataVo.setBin(stringBuilder.deleteCharAt(stringBuilder.lastIndexOf(",")).toString());
                }
                receiveIqcDataVoList.add(receiveIqcDataVo);
                log.info("抛转qms结构体打印》》》》》》" + JSONUtil.toJsonStr(receiveIqcDataVoList));

                HttpResponse httpResponse = qmsService.postQmsReceiveDoc(receiveIqcDataVoList);
                String body = httpResponse.body();
                log.info("抛转qms响应打印》》》》》》{} {}", wmsDocReceiveDb.getDocNo(), body);
                if (httpResponse.getStatus() == HttpStatus.HTTP_OK) {
                    JSONObject qmsReturnInfo = JSONUtil.parseObj(body);
                    String code = qmsReturnInfo.getStr("code");
                    if (StringUtils.isNotBlank(code) && "200".equalsIgnoreCase(code)) {
                        WmsDocReceive doc = new WmsDocReceive();
                        doc.setId(wmsDocReceiveDb.getId());
                        doc.setToQmsFlag(true);
                        doc.setToQmsMessage("OK");
                        doc.setToQmsDate(LocalDateTime.now());
                        doc.updateById();
                    } else {
                        WmsDocReceive doc = new WmsDocReceive();
                        doc.setId(wmsDocReceiveDb.getId());
                        doc.setToQmsFlag(false);
                        doc.setToQmsMessage(qmsReturnInfo.getStr("msg"));
                        doc.setToQmsDate(LocalDateTime.now());
                        doc.updateById();

                    }
                } else {
                    WmsDocReceive doc = new WmsDocReceive();
                    doc.setId(wmsDocReceiveDb.getId());
                    doc.setToQmsFlag(false);
                    doc.setToQmsMessage(body);
                    doc.setToQmsDate(LocalDateTime.now());
                    doc.updateById();
                }
            } catch (Exception e) {
                log.error("docReceivePostQms Exception : {}", e.getMessage());
                WmsDocReceive doc = new WmsDocReceive();
                doc.setId(wmsDocReceiveDb.getId());
                doc.setToQmsFlag(false);
                doc.setToQmsMessage("docReceivePostQms Exception");
                doc.setToQmsDate(LocalDateTime.now());
                doc.updateById();
            }
        }
    }

    private Boolean receiveDocScCheck(WmsDocReceive docDTO, String scOrgCode) {
        ReceiveDocScCheckDTO dto = new ReceiveDocScCheckDTO();
        dto.setFromSystem("WMS");
        dto.setBu(scOrgCode);
        dto.setPoNumber(docDTO.getPoNo());
        List<String> lotCodes;
        if ("JIT".equalsIgnoreCase(docDTO.getSapWarehouseCode()) && "PN_RECEIVE_DOC".equals(docDTO.getDocTypeCode())) {
            dto.setPoNumber(docDTO.getSapReturnNumber());
            lotCodes = ListUtil.toList();
        } else if ("JIT_PN_RECEIVE_DOC".equals(docDTO.getDocTypeCode())) {
            dto.setPoNumber(docDTO.getFromDocNo());
            lotCodes = ListUtil.toList();
        } else {
            List<WmsPkgInfo> wmsPkgInfoList = wmsPkgInfoMapper.selectList(Wrappers.<WmsPkgInfo>lambdaQuery()
                    .eq(WmsPkgInfo::getOrgCode, docDTO.getOrgCode())
                    .eq(WmsPkgInfo::getWmsNo, docDTO.getDocNo())
            );
            lotCodes = wmsPkgInfoList.stream().map(WmsPkgInfo::getLotCode)
                    .filter(StrUtil::isNotBlank)
                    .distinct().collect(Collectors.toList());
        }
        dto.setVendorCode(docDTO.getVendorCode());
        dto.setVendorName(StrUtil.EMPTY);
        List<ScCheckPartNoDTO> partNumberList = ListUtil.toList();
        ScCheckPartNoDTO scCheckPartNoDTO = new ScCheckPartNoDTO();
        scCheckPartNoDTO.setHhpn(docDTO.getPartNo());
        scCheckPartNoDTO.setVersion(docDTO.getPartNoVersion());
        scCheckPartNoDTO.setLotCodes(lotCodes);
        if (StrUtil.isBlank(docDTO.getMfgPartNo())) {
            scCheckPartNoDTO.setVendorPartNumber(docDTO.getPartNo());
        } else {
            scCheckPartNoDTO.setVendorPartNumber(docDTO.getMfgPartNo());
        }
        partNumberList.add(scCheckPartNoDTO);
        dto.setPartNumberList(partNumberList);
        dto.setCreateUserId("ig-admin-0001");
        log.info("receiveDocCheckSc reqDTO {}", JSONUtil.toJsonStr(dto));
        HttpResponse httpResponse = receiveDocScCheckRequest(dto);
        log.info("receiveDocCheckSc resBody {}", httpResponse.body());
        JSONObject jsonObject = null;
        String holdReason = "";
        String rtnCode = "";
        try {
            jsonObject = JSONUtil.parseObj(httpResponse.body());
        } catch (Exception e) {
        }
        JSONObject header = null;
        JSONObject body = null;
        if (ObjectUtil.isNotNull(jsonObject)) {
            header = jsonObject.getJSONObject("header");
            body = jsonObject.getJSONObject("body");
            if (ObjectUtil.isNotNull(body)) {
                JSONArray partList = body.getJSONArray("resultList");
                if (ObjectUtil.isNotNull(partList)) {
                    JSONObject data = partList.getJSONObject(0);
                    if (ObjectUtil.isNotNull(data)) {
                        if (StrUtil.equals(data.getStr("status"), "CHECK")) {
                            return Boolean.TRUE;
                        } else {
                            holdReason = data.getStr("rejectReason");
                        }
                    }
                }

            }
        }
        if (ObjectUtil.isNotNull(header)) {
            rtnCode = header.getStr("rtnCode");
        }
        log.info(String.format("协作云：hold reason: %s | rtnCode：%s", holdReason, rtnCode));
        wmsDocReceiveMapper.update(null, Wrappers.<WmsDocReceive>lambdaUpdate()
                .set(WmsDocReceive::getToQmsFlag, false)
                .set(WmsDocReceive::getToQmsDate, LocalDateTime.now())
                .set(WmsDocReceive::getToQmsMessage, String.format("协作云：hold reason: %s | rtnCode：%s", holdReason, rtnCode))
                .eq(WmsDocReceive::getId, docDTO.getId())
        );

        return Boolean.FALSE;
    }

    public HttpResponse receiveDocScCheckRequest(ReceiveDocScCheckDTO reqDto) {
        String url = supplierCheckConfig.getReceiveDocCheckUrl();
        HttpResponse response = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(reqDto))
                .execute();
        return response;
    }

    public void tradingPosting(String orgCode, String postDate) {
        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }
        List<WmsSapPlant> wmsSapPlantList = wmsSapPlantMapper.selectList(Wrappers.<WmsSapPlant>lambdaQuery()
                .eq(WmsSapPlant::getOrgCode, orgCode));
        // 使用旧过账方式的BU
        List<SysDict> dictList = sysDictMapper.selectDictList("WMS_TRADING_OUT_OLD_TRANSACTION");
        List<String> oldRFCBuList = dictList.stream().map(SysDict::getDictCode).distinct().collect(Collectors.toList());

        for (WmsSapPlant wmsSapPlant : wmsSapPlantList) {
            List<WmsTradingRecordEntity> tradingRecordEntityList = wmsTradingRecordMapper.selectList(Wrappers.<WmsTradingRecordEntity>lambdaQuery()
                    .eq(WmsTradingRecordEntity::getFromOrgCode, orgCode)
                    .eq(WmsTradingRecordEntity::getFromPlantCode, wmsSapPlant.getFactoryCode())
                    .eq(WmsTradingRecordEntity::getTradingFlag, 0)
                    .eq(WmsTradingRecordEntity::getTradingToConfirmFlag, "1"));
            tradingRecordEntityList.forEach(recordEntity -> {
                if ("N".equalsIgnoreCase(Constants.continueJob)) {
                    return;
                }
                try {
                    WmsTradingConfig wmsTradingConfig;
                    List<WmsTradingConfig> wmsTradingConfigList = wmsTradingConfigMapper.selectList(Wrappers.<WmsTradingConfig>lambdaQuery()
                            .eq(WmsTradingConfig::getFromOrgCode, orgCode)
                            .eq(WmsTradingConfig::getFromPlantCode, wmsSapPlant.getFactoryCode())
                            .eq(WmsTradingConfig::getTradingToOrgCode, recordEntity.getToOrgCode()));
                    if (wmsTradingConfigList.size() > 1) {
                        wmsTradingConfig = wmsTradingConfigList.stream().filter(config ->
                                recordEntity.getToPlantCode().equals(config.getToPlantCode())).findFirst().orElse(null);
                    } else {
                        wmsTradingConfig = wmsTradingConfigList.get(0);
                    }
                    String sapClient = wmsSapPlant.getErpInterface();
                    String valueType;
                    valueType = getValueType(sapClient, recordEntity);
                    if (StringUtils.isEmpty(valueType)) {
                        wmsTradingRecordMapper.update(null, Wrappers.<WmsTradingRecordEntity>lambdaUpdate()
                                .eq(WmsTradingRecordEntity::getId, recordEntity.getId())
                                .set(WmsTradingRecordEntity::getTradingMsg, "valueType is empty")
                                .set(WmsTradingRecordEntity::getTradingDate, LocalDateTime.now())
                                .set(WmsTradingRecordEntity::getTradingBy, "sysadmin"));
                        return;
                    }
                    GenerateTradingNumberDto sapDto = new GenerateTradingNumberDto();
                    sapDto.setSapClient(sapClient);
                    sapDto.setValueType(valueType);
                    sapDto.setFromPlant(recordEntity.getFromPlantCode());
                    sapDto.setDeliveryType(wmsTradingConfig.getDeliveryType());
                    sapDto.setSalesOrg(wmsTradingConfig.getSalesOrg());
                    sapDto.setDistriChan(recordEntity.getSalesChain());
                    sapDto.setTradingToCode(recordEntity.getTradingToCode());
                    SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
                    sapDto.setGiDate(sdf.format(new Date()));
                    sapDto.setQuantity(recordEntity.getTradingQty().stripTrailingZeros().toPlainString());
                    sapDto.setLocation(recordEntity.getFromWarehouseCode());
                    sapDto.setBatch(recordEntity.getPartVersion());
                    sapDto.setTradingFromCode(recordEntity.getTradingFromCode());
                    sapDto.setDivision(recordEntity.getProductDepartment());
                    sapDto.setMaterial(recordEntity.getPartNo());
                    sapDto.setUnit(recordEntity.getUomCode());
                    sapDto.setClientId(wmsTradingConfig.getFromSapClientId());
                    sapDto.setOrgCode(orgCode);
                    String result;
                    //只有EPDVI走新的过账方法
                    if (oldRFCBuList.contains(orgCode)) {
                        result = tradingRfcService.doGenerateTradingNumber(sapClient, sapDto);
                    } else {
                        result = tradingRfcService.doGenerateTradingNumber2(sapClient, sapDto);
                    }
                    if (StringUtils.isEmpty(result)) {
                        wmsTradingRecordMapper.update(null, Wrappers.<WmsTradingRecordEntity>lambdaUpdate()
                                .eq(WmsTradingRecordEntity::getId, recordEntity.getId())
                                .set(WmsTradingRecordEntity::getTradingMsg, "SAP return empty")
                                .set(WmsTradingRecordEntity::getTradingDate, LocalDateTime.now())
                                .set(WmsTradingRecordEntity::getTradingBy, "sysadmin"));
                    }
                    wmsTradingRecordMapper.update(null, Wrappers.<WmsTradingRecordEntity>lambdaUpdate()
                            .eq(WmsTradingRecordEntity::getId, recordEntity.getId())
                            .set(WmsTradingRecordEntity::getTradingFlag, 1)
                            .set(WmsTradingRecordEntity::getTradingMsg, result)
                            .set(WmsTradingRecordEntity::getTradingDate, LocalDateTime.now())
                            .set(WmsTradingRecordEntity::getTradingBy, "sysadmin"));
                } catch (Exception e) {
                    wmsTradingRecordMapper.update(null, Wrappers.<WmsTradingRecordEntity>lambdaUpdate()
                            .eq(WmsTradingRecordEntity::getId, recordEntity.getId())
                            .set(WmsTradingRecordEntity::getTradingMsg, e.getMessage())
                            .set(WmsTradingRecordEntity::getTradingDate, LocalDateTime.now()));
                }
            });
        }
    }

    private String getValueType(String sapClient, WmsTradingRecordEntity wmsTradingRecordEntity) throws JCoException {
        String orgCode = wmsTradingRecordEntity.getFromOrgCode();
        String plantCode = wmsTradingRecordEntity.getFromPlantCode();
        String partVersion = wmsTradingRecordEntity.getPartVersion();
        String partNo = wmsTradingRecordEntity.getPartNo();
        String warehouseCode = wmsTradingRecordEntity.getFromWarehouseCode();
        //判断料号是否纯数字且未满18位
        if (org.apache.commons.lang3.StringUtils.isNumeric(partNo) && partNo.length() < 18) {
            partNo = materialRfcService.doGetMaterialNo(sapClient, partNo);
        }
        List<MaterialInfoDto> materialInfoDtos = materialRfcService.doGetMaterialInfo(sapClient, plantCode, partNo, "", "");
        if (CollUtil.isEmpty(materialInfoDtos)) {
            return null;
        }
        String valueType;
        List<SysDict> sysDictList = sysDictMapper.selectDictList(plantCode);
        if (CollUtil.isNotEmpty(sysDictList)) {
            //版次不允许为空
            valueType = ValueType.getDictNameByDictCode(materialInfoDtos.get(0).getProductType());
            if (StringUtil.isEmpty(partVersion) || StringUtil.isEmpty(valueType)) {
                return null;
            }
            if (org.apache.commons.lang3.StringUtils.left(partVersion, 1).equalsIgnoreCase("N")) {
                valueType = "N" + valueType;
            }
        } else {
            if ("WI".equalsIgnoreCase(orgCode)) {
                valueType = "COST";
            } else {
                valueType = materialRfcService.doGetMaterialValueType(sapClient, plantCode, partNo, warehouseCode);
            }
        }
        if (StringUtil.isEmpty(valueType)) {
            return null;
        }
        return valueType;
    }

    public void tradingPGI(String orgCode, String postDate) {
        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }
        List<WmsSapPlant> wmsSapPlantList = wmsSapPlantMapper.selectList(Wrappers.<WmsSapPlant>lambdaQuery()
                .eq(WmsSapPlant::getOrgCode, orgCode));
        for (WmsSapPlant wmsSapPlant : wmsSapPlantList) {
            List<WmsTradingRecordEntity> tradingRecordEntityList = wmsTradingRecordMapper.selectList(Wrappers.<WmsTradingRecordEntity>lambdaQuery()
                    .eq(WmsTradingRecordEntity::getFromOrgCode, orgCode)
                    .eq(WmsTradingRecordEntity::getFromPlantCode, wmsSapPlant.getFactoryCode())
                    .eq(WmsTradingRecordEntity::getTradingFlag, 1)
                    .eq(WmsTradingRecordEntity::getPgiFlag, 0));
            tradingRecordEntityList.forEach(recordEntity -> {
                if ("N".equalsIgnoreCase(Constants.continueJob)) {
                    return;
                }
                try {
                    String sapClient = wmsSapPlant.getErpInterface();
                    String result = tradingRfcService.doPgi(sapClient, recordEntity.getTradingMsg());
                    wmsTradingRecordMapper.update(null, Wrappers.<WmsTradingRecordEntity>lambdaUpdate()
                            .eq(WmsTradingRecordEntity::getId, recordEntity.getId())
                            .set(WmsTradingRecordEntity::getPgiFlag, 1)
                            .set(WmsTradingRecordEntity::getPgiMsg, result)
                            .set(WmsTradingRecordEntity::getPgiDate, LocalDateTime.now())
                            .set(WmsTradingRecordEntity::getPgiBy, "sysadmin"));
                } catch (Exception e) {
                    wmsTradingRecordMapper.update(null, Wrappers.<WmsTradingRecordEntity>lambdaUpdate()
                            .eq(WmsTradingRecordEntity::getId, recordEntity.getId())
                            .set(WmsTradingRecordEntity::getPgiMsg, e.getMessage())
                            .set(WmsTradingRecordEntity::getPgiDate, LocalDateTime.now())
                            .set(WmsTradingRecordEntity::getPgiBy, "sysadmin"));
                }
            });
        }
    }

    public void doTradingInPosting(String orgCode, String postDate) {
        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }
        List<WmsSapPlant> wmsSapPlantList = wmsSapPlantMapper.selectList(Wrappers.<WmsSapPlant>lambdaQuery()
                .eq(WmsSapPlant::getOrgCode, orgCode));
        for (WmsSapPlant wmsSapPlant : wmsSapPlantList) {
            List<WmsDocReceive> docList =
                    wmsDocReceiveMapper.selectList(Wrappers.<WmsDocReceive>lambdaQuery()
                            .eq(WmsDocReceive::getOrgCode, orgCode)
//                            .eq(WmsDocReceive::getPostingQmsFlag, "Y")
                            .eq(WmsDocReceive::getPostingSapMethodFlag, "Y")
                            .eq(WmsDocReceive::getConfirmReceiptFlag, 1)
                            .eq(WmsDocReceive::getPlantCode, wmsSapPlant.getFactoryCode())
                            .eq(WmsDocReceive::getDocTypeCode, "INNERRING_RECEIVE_DOC")
                            .isNull(WmsDocReceive::getSapReturnNumber));

            docList.forEach(d -> {
                if ("N".equalsIgnoreCase(Constants.continueJob)) {
                    return;
                }
                String sapClientCode = wmsSapPlant.getErpInterface();
                //直接入良品仓待待验状态
                Result b;
                WmsTradingRecordEntity wmsTradingRecordEntity = wmsTradingRecordMapper.selectOne(Wrappers.<WmsTradingRecordEntity>lambdaQuery()
                        .eq(WmsTradingRecordEntity::getToOrgCode, orgCode)
                        .eq(WmsTradingRecordEntity::getTradingNumber, d.getFromDocNo())
                        .last("limit 1"));
                if (ObjectUtil.isNull(wmsTradingRecordEntity)) {
                    LambdaUpdateWrapper<WmsDocReceive> updateWrapper = new LambdaUpdateWrapper<>();
                    updateWrapper.set(WmsDocReceive::getSapReturnNumber, null);
                    updateWrapper.set(WmsDocReceive::getSapReturnMessage, "tradingRecord is not exist");
                    updateWrapper.set(WmsDocReceive::getPostingSapMethodDate, LocalDateTime.now());
                    updateWrapper.eq(WmsDocReceive::getId, d.getId());
                    wmsDocReceiveService.update(updateWrapper);
                    return;
                }
                if (1 != wmsTradingRecordEntity.getTradingFlag()
                        || 1 != wmsTradingRecordEntity.getPgiFlag()) {
                    LambdaUpdateWrapper<WmsDocReceive> updateWrapper = new LambdaUpdateWrapper<>();
                    updateWrapper.set(WmsDocReceive::getSapReturnNumber, null);
                    updateWrapper.set(WmsDocReceive::getSapReturnMessage, "tradingFlag or pgiFlag is 0");
                    updateWrapper.set(WmsDocReceive::getPostingSapMethodDate, LocalDateTime.now());
                    updateWrapper.eq(WmsDocReceive::getId, d.getId());
                    wmsDocReceiveService.update(updateWrapper);
                    wmsTradingRecordMapper.update(null, Wrappers.<WmsTradingRecordEntity>lambdaUpdate()
                            .eq(WmsTradingRecordEntity::getId, wmsTradingRecordEntity.getId())
                            .set(WmsTradingRecordEntity::getPostSapDate, LocalDateTime.now())
                            .set(WmsTradingRecordEntity::getSapReturnMsg, "tradingFlag or pgiFlag is 0")
                            .set(WmsTradingRecordEntity::getSapReturnNumber, null));
                    return;
                }
                //直接入良品仓待待验状态
                String stckType = "Y".equals(d.getPostingQmsFlag()) ? "X" : StrUtil.EMPTY;
                b = postFactory.doTradingInPosting(sapClientCode, d, wmsTradingRecordEntity, stckType, postDate);
                log.info("doTradingInPosting, {}，result：{}", JSONUtil.toJsonStr(d), JSONUtil.toJsonStr(b));
                WmsDocReceive wmsDocReceive = new WmsDocReceive();
                wmsDocReceive.setId(d.getId());
                if (b.getCode() == 0) {
                    wmsDocReceive.setSapReturnNumber(b.getMessage());
                    wmsDocReceive.setSapReturnMessage("OK");
                    wmsDocReceive.setPostingSapMethodDate(LocalDateTime.now());
                    wmsDocReceive.updateById();
                    wmsTradingRecordMapper.update(null, Wrappers.<WmsTradingRecordEntity>lambdaUpdate()
                            .eq(WmsTradingRecordEntity::getId, wmsTradingRecordEntity.getId())
                            .set(WmsTradingRecordEntity::getPostSapDate, LocalDateTime.now())
                            .set(WmsTradingRecordEntity::getSapReturnMsg, "OK")
                            .set(WmsTradingRecordEntity::getSapReturnNumber, b.getMessage()));
                } else {
                    LambdaUpdateWrapper<WmsDocReceive> updateWrapper = new LambdaUpdateWrapper<>();
                    updateWrapper.set(WmsDocReceive::getSapReturnNumber, null);
                    updateWrapper.set(WmsDocReceive::getSapReturnMessage, b.getMessage());
                    updateWrapper.set(WmsDocReceive::getPostingSapMethodDate, LocalDateTime.now());
                    updateWrapper.eq(WmsDocReceive::getId, d.getId());
                    wmsDocReceiveService.update(updateWrapper);
                    wmsTradingRecordMapper.update(null, Wrappers.<WmsTradingRecordEntity>lambdaUpdate()
                            .eq(WmsTradingRecordEntity::getId, wmsTradingRecordEntity.getId())
                            .set(WmsTradingRecordEntity::getPostSapDate, LocalDateTime.now())
                            .set(WmsTradingRecordEntity::getSapReturnMsg, b.getMessage())
                            .set(WmsTradingRecordEntity::getSapReturnNumber, null));
                }
            });
        }
    }

    public void outsourcingPosting(String orgCode, String postDate) throws JCoException {
        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }
        List<WmsSapPlant> wmsSapPlantList = wmsSapPlantMapper.selectList(Wrappers.<WmsSapPlant>lambdaQuery()
                .eq(WmsSapPlant::getOrgCode, orgCode));
        for (WmsSapPlant wmsSapPlant : wmsSapPlantList) {
            List<WmsDocReceive> docList =
                    wmsDocReceiveMapper.selectList(Wrappers.<WmsDocReceive>lambdaQuery()
                            .eq(WmsDocReceive::getOrgCode, orgCode)
                            .eq(WmsDocReceive::getPostingQmsFlag, "Y")
                            .eq(WmsDocReceive::getPostingSapMethodFlag, "Y")
                            .eq(WmsDocReceive::getConfirmReceiptFlag, 1)
                            .eq(WmsDocReceive::getPlantCode, wmsSapPlant.getFactoryCode())
                            .eq(WmsDocReceive::getDocTypeCode, "OUTSOURCING_DOC")
                            .last("and (sap_return_number is null or sap_return_number = '0')"));
            for (WmsDocReceive d : docList) {
                if ("N".equalsIgnoreCase(Constants.continueJob)) {
                    return;
                }
                String sapClientCode = wmsSapPlant.getErpInterface();
                long count = wmsOutsourcingWorkOrderHeaderMapper.selectCount(Wrappers.<WmsOutsourcingWorkOrderHeader>lambdaQuery()
                        .eq(WmsOutsourcingWorkOrderHeader::getOrgCode, orgCode)
                        .eq(WmsOutsourcingWorkOrderHeader::getPlantCode, wmsSapPlant.getFactoryCode())
                        .eq(WmsOutsourcingWorkOrderHeader::getPoNo, d.getPoNo()));
                long count1 = wmsOutsourcingWorkOrderDetailMapper
                        .selectCount(Wrappers.<WmsOutsourcingWorkOrderDetail>lambdaQuery()
                                .eq(WmsOutsourcingWorkOrderDetail::getOrgCode, orgCode)
                                .eq(WmsOutsourcingWorkOrderDetail::getPlantCode, wmsSapPlant.getFactoryCode())
                                .eq(WmsOutsourcingWorkOrderDetail::getPoNo, d.getPoNo()));
                if (count == 0 || count1 == 0) {
                    LambdaUpdateWrapper<WmsDocReceive> updateWrapper = new LambdaUpdateWrapper<>();
                    updateWrapper.set(WmsDocReceive::getSapReturnNumber, null);
                    updateWrapper.set(WmsDocReceive::getSapReturnMessage, "outsourcing_header or outsourcing_detail is empty");
                    updateWrapper.set(WmsDocReceive::getPostingSapMethodDate, LocalDateTime.now());
                    updateWrapper.eq(WmsDocReceive::getId, d.getId());
                    wmsDocReceiveService.update(updateWrapper);
                    continue;
                }
                //直接入良品仓待待验状态
                Result b = postFactory.doOutsourcingPosting(sapClientCode, d, postDate);

                log.info("doOutsourcingPosting request: {}，result：{}", JSONUtil.toJsonStr(d), JSONUtil.toJsonStr(b));
                WmsDocReceive wmsDocReceive = new WmsDocReceive();
                wmsDocReceive.setId(d.getId());
                if (b.getCode() == 0) {
                    wmsDocReceive.setSapReturnNumber(b.getMessage());
                    wmsDocReceive.setSapReturnMessage("OK");
                    wmsDocReceive.setPostingSapMethodDate(LocalDateTime.now());
                    wmsDocReceive.updateById();
                } else {
                    LambdaUpdateWrapper<WmsDocReceive> updateWrapper = new LambdaUpdateWrapper<>();
                    updateWrapper.set(WmsDocReceive::getSapReturnNumber, null);
                    updateWrapper.set(WmsDocReceive::getSapReturnMessage, b.getMessage());
                    updateWrapper.set(WmsDocReceive::getPostingSapMethodDate, LocalDateTime.now());
                    updateWrapper.eq(WmsDocReceive::getId, d.getId());
                    wmsDocReceiveService.update(updateWrapper);
                }
            }
        }
    }

    // 收货单勾兑报关单
    public void docReceiveBlendingCusNo(String sapClient, String orgCode, String postDate, String docNo) {
        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }
        List<SysDict> dictList = sysDictMapper.selectDictList("WMS_NEED_BLENDING_CUS_DOC_TYPE");
        List<String> docTypeList = dictList.stream().map(item -> item.getDictCode()).distinct().collect(Collectors.toList());
        if (CollUtil.isEmpty(docTypeList)) {
            return;
        }
        List<WmsDocReceive> docList =
                wmsDocReceiveMapper.selectList(Wrappers.<WmsDocReceive>lambdaQuery()
                        .eq(WmsDocReceive::getOrgCode, orgCode)
                        .isNotNull(WmsDocReceive::getSapReturnNumber)
                        .ne(WmsDocReceive::getSapReturnNumber, StrUtil.EMPTY)
                        .in(WmsDocReceive::getDocTypeCode, docTypeList)
                        .eq(WmsDocReceive::getBlendingCusFlag, "0")
                        .eq(StrUtil.isNotBlank(docNo), WmsDocReceive::getDocNo, docNo)
                        .isNotNull(WmsDocReceive::getPoNo)
                        .isNotNull(WmsDocReceive::getPoItem)
                        .isNotNull(WmsDocReceive::getFromDocNo)
                        .isNotNull(WmsDocReceive::getFromDocItem)
                        .ne(WmsDocReceive::getPoNo, StrUtil.EMPTY)
                        .ne(WmsDocReceive::getPoItem, StrUtil.EMPTY)
                        .ne(WmsDocReceive::getFromDocNo, StrUtil.EMPTY)
                        .ne(WmsDocReceive::getFromDocItem, StrUtil.EMPTY)
                        .last("AND posting_sap_method_date is not null AND now() > posting_sap_method_date + interval '3d' order by blending_cus_datetime desc")
                );

        if (CollUtil.isEmpty(docList)) {
            return;
        }


        for (WmsDocReceive doc : docList) {
            try {
                if (Constants.continueJob.equalsIgnoreCase("N")) {
                    return;
                }
                String grNumber = doc.getSapReturnNumber();
                String yearStr = doc.getPostingSapMethodDate().format(DateTimeFormatter.ofPattern("yyyy"));
                String po = doc.getPoNo();
                String poItem = doc.getPoItem();
                String fromDocNo = doc.getFromDocNo();
                String fromDocItem = doc.getFromDocItem();

                WmsSapWarehouseCode wmsSapWarehouseCode = wmsSapWarehouseCodeMapper.selectOne(Wrappers.<WmsSapWarehouseCode>lambdaQuery()
                        .eq(WmsSapWarehouseCode::getOrgCode, orgCode)
                        .eq(WmsSapWarehouseCode::getWarehouseCode, doc.getSapWarehouseCode())
                );
                Boolean isBonded = "bonded".equalsIgnoreCase(wmsSapWarehouseCode.getBondedType());

                List<WmsCkdCus> wmsCkdCusList = wmsCkdCusService.getAndInsertCkdCus(orgCode, isBonded, po, poItem, Boolean.FALSE);
                // 如果数据库，和ecus都没有
                if (CollUtil.isEmpty(wmsCkdCusList)) {
                    wmsDocReceiveMapper.update(null, Wrappers.<WmsDocReceive>lambdaUpdate()
                            .set(WmsDocReceive::getBlendingCusFlag, "2")
                            .set(WmsDocReceive::getBlendingCusMessage, String.format("WMS: po：%s, poItem：%s, 来源单号：%s，来源项次：%s 找不到对应的报关单", po, poItem, fromDocNo, fromDocItem))
                            .set(WmsDocReceive::getBlendingCusDatetime, LocalDateTime.now())
                            .eq(WmsDocReceive::getId, doc.getId())
                    );
                    continue;
                }
                WmsCkdCus wmsCkdCus = wmsCkdCusList.stream()
                        .filter(item -> StrUtil.equals(fromDocNo, item.getCutNo())
                                && StrUtil.equals(StrUtil.padPre(fromDocItem, 5, "0"), StrUtil.padPre(item.getCusUne(), 5, "0")))
                        .findFirst().orElse(null);
                // 如果找不到，有可能是走数据库了，就再请求一次ecus
                if (ObjectUtil.isNull(wmsCkdCus)) {
                    wmsCkdCusList = wmsCkdCusService.getAndInsertCkdCus(orgCode, isBonded, po, poItem, Boolean.TRUE);
                }
                wmsCkdCus = wmsCkdCusList.stream()
                        .filter(item -> StrUtil.equals(fromDocNo, item.getCutNo())
                                && StrUtil.equals(StrUtil.padPre(fromDocItem, 5, "0"), StrUtil.padPre(item.getCusUne(), 5, "0")))
                        .findFirst().orElse(null);
                if (ObjectUtil.isNull(wmsCkdCus)) {
                    wmsDocReceiveMapper.update(null, Wrappers.<WmsDocReceive>lambdaUpdate()
                            .set(WmsDocReceive::getBlendingCusFlag, "2")
                            .set(WmsDocReceive::getBlendingCusMessage, String.format("WMS: po：%s, poItem：%s, 来源单号：%s，来源项次：%s 找不到对应的报关单", po, poItem, fromDocNo, fromDocItem))
                            .set(WmsDocReceive::getBlendingCusDatetime, LocalDateTime.now())
                            .eq(WmsDocReceive::getId, doc.getId())
                    );
                    continue;
                }

                String cusNo = wmsCkdCus.getCusNo();
                String cusItem = wmsCkdCus.getCusItem();
                BlendIngCusDTO dto = docRfcService.doBlendIngDocReceiveCus(sapClient, grNumber, yearStr, cusNo, cusItem);
                if ("S".equalsIgnoreCase(dto.getCode())) {
                    wmsDocReceiveMapper.update(null, Wrappers.<WmsDocReceive>lambdaUpdate()
                            .set(WmsDocReceive::getBlendingCusNo, cusNo)
                            .set(WmsDocReceive::getBlendingCusItem, cusItem)
                            .set(WmsDocReceive::getBlendingCusFlag, "1")
                            .set(WmsDocReceive::getBlendingCusMessage, dto.getMsg())
                            .set(WmsDocReceive::getBlendingCusDatetime, LocalDateTime.now())
                            .eq(WmsDocReceive::getId, doc.getId())
                    );
                } else {
                    wmsDocReceiveMapper.update(null, Wrappers.<WmsDocReceive>lambdaUpdate()
                            .set(WmsDocReceive::getBlendingCusMessage, dto.getMsg())
                            .set(WmsDocReceive::getBlendingCusDatetime, LocalDateTime.now())
                            .eq(WmsDocReceive::getId, doc.getId())
                    );
                }
            } catch (Exception e) {
                log.error("docReceiveBlendingCusNo", e);
                wmsDocReceiveMapper.update(null, Wrappers.<WmsDocReceive>lambdaUpdate()
                        .set(WmsDocReceive::getBlendingCusMessage, e.getMessage())
                        .set(WmsDocReceive::getBlendingCusDatetime, LocalDateTime.now())
                        .eq(WmsDocReceive::getId, doc.getId())
                );
            }

        }

    }

    public void jusdaVmiBlendingCusNo(String sapClient, String orgCode, String postDate, String docNo) {
        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }

        List<WmsJusdaReceiptEntity> docList = wmsJusdaReceiptMapper.selectList(Wrappers.<WmsJusdaReceiptEntity>lambdaQuery()
                .eq(WmsJusdaReceiptEntity::getOrgCode, orgCode)
                .eq(StrUtil.isNotBlank(docNo), WmsJusdaReceiptEntity::getShipId, docNo)
                .eq(WmsJusdaReceiptEntity::getReceivedType, "VMI")
                .eq(WmsJusdaReceiptEntity::getBlendingCusFlag, "0")
                .isNotNull(WmsJusdaReceiptEntity::getSapReturnNumber)
                .ne(WmsJusdaReceiptEntity::getSapReturnNumber, StrUtil.EMPTY)
                .last("AND sap_upload_data is not null AND now() > sap_upload_data + interval '3d' order by blending_cus_datetime desc")
        );


        if (CollUtil.isEmpty(docList)) {
            return;
        }

        for (WmsJusdaReceiptEntity doc : docList) {
            if (Constants.continueJob.equalsIgnoreCase("N")) {
                return;
            }
            try {
                String customDocNo = doc.getCustomDocNo();
                String customDocItemNo = doc.getCustomDocItemNo();
                String sapReturnNumber = doc.getSapReturnNumber();
                String yearStr = doc.getSapUploadData().format(DateTimeFormatter.ofPattern("yyyy"));
                if (StrUtil.isNotBlank(customDocNo) && StrUtil.isNotBlank(customDocItemNo)) {
                    if (customDocNo.length() == 18) {
                        BlendIngCusDTO dto = docRfcService.doBlendIngJusdaVmiCus(sapClient, sapReturnNumber, yearStr, customDocNo, customDocItemNo);
                        if ("S".equalsIgnoreCase(dto.getCode())) {
                            wmsJusdaReceiptMapper.update(null, Wrappers.<WmsJusdaReceiptEntity>lambdaUpdate()
                                    .set(WmsJusdaReceiptEntity::getBlendingCusNo, customDocNo)
                                    .set(WmsJusdaReceiptEntity::getBlendingCusItem, customDocItemNo)
                                    .set(WmsJusdaReceiptEntity::getBlendingCusFlag, "1")
                                    .set(WmsJusdaReceiptEntity::getBlendingCusMessage, dto.getMsg())
                                    .set(WmsJusdaReceiptEntity::getBlendingCusDatetime, LocalDateTime.now())
                                    .eq(WmsJusdaReceiptEntity::getId, doc.getId())
                            );
                        } else {
                            wmsJusdaReceiptMapper.update(null, Wrappers.<WmsJusdaReceiptEntity>lambdaUpdate()
                                    .set(WmsJusdaReceiptEntity::getBlendingCusMessage, dto.getMsg())
                                    .set(WmsJusdaReceiptEntity::getBlendingCusDatetime, LocalDateTime.now())
                                    .eq(WmsJusdaReceiptEntity::getId, doc.getId())
                            );
                        }
                        continue;
                    }
                }

                WmsSapWarehouseCode wmsSapWarehouseCode = wmsSapWarehouseCodeMapper.selectOne(Wrappers.<WmsSapWarehouseCode>lambdaQuery()
                        .eq(WmsSapWarehouseCode::getOrgCode, orgCode)
                        .eq(WmsSapWarehouseCode::getWarehouseCode, doc.getToWarehouseCode())
                );
                Boolean isBonded = "bonded".equalsIgnoreCase(wmsSapWarehouseCode.getBondedType());

                List<WmsCkdCus> wmsCkdCusList = wmsCkdCusService.getAndInsertCkdCus(orgCode, isBonded, customDocNo, customDocItemNo, Boolean.FALSE);
                if (CollUtil.isEmpty(wmsCkdCusList)) {
                    wmsJusdaReceiptMapper.update(null, Wrappers.<WmsJusdaReceiptEntity>lambdaUpdate()
                            .set(WmsJusdaReceiptEntity::getBlendingCusFlag, "2")
                            .set(WmsJusdaReceiptEntity::getBlendingCusMessage, String.format("WMS: po：%s, poItem：%s,找不到对应的报关单", customDocNo, customDocItemNo))
                            .set(WmsJusdaReceiptEntity::getBlendingCusDatetime, LocalDateTime.now())
                            .eq(WmsJusdaReceiptEntity::getId, doc.getId())
                    );
                    continue;
                }
                WmsCkdCus wmsCkdCus = wmsCkdCusList.get(0);
                // 如果找不到，就再请求一次
                if (ObjectUtil.isNull(wmsCkdCus)) {
                    wmsCkdCusList = wmsCkdCusService.getAndInsertCkdCus(orgCode, isBonded, customDocNo, customDocItemNo, Boolean.TRUE);
                }
                wmsCkdCus = wmsCkdCusList.get(0);
                if (ObjectUtil.isNull(wmsCkdCus)) {
                    wmsJusdaReceiptMapper.update(null, Wrappers.<WmsJusdaReceiptEntity>lambdaUpdate()
                            .set(WmsJusdaReceiptEntity::getBlendingCusFlag, "2")
                            .set(WmsJusdaReceiptEntity::getBlendingCusMessage, String.format("WMS: po：%s, poItem：%s,找不到对应的报关单", customDocNo, customDocItemNo))
                            .set(WmsJusdaReceiptEntity::getBlendingCusDatetime, LocalDateTime.now())
                            .eq(WmsJusdaReceiptEntity::getId, doc.getId())
                    );
                    continue;
                }
                String cusNo = wmsCkdCus.getCusNo();
                String cusItem = wmsCkdCus.getCusItem();
                BlendIngCusDTO dto = docRfcService.doBlendIngJusdaVmiCus(sapClient, sapReturnNumber, yearStr, cusNo, cusItem);
                if ("S".equalsIgnoreCase(dto.getCode())) {
                    wmsJusdaReceiptMapper.update(null, Wrappers.<WmsJusdaReceiptEntity>lambdaUpdate()
                            .set(WmsJusdaReceiptEntity::getBlendingCusNo, cusNo)
                            .set(WmsJusdaReceiptEntity::getBlendingCusItem, cusItem)
                            .set(WmsJusdaReceiptEntity::getBlendingCusFlag, "1")
                            .set(WmsJusdaReceiptEntity::getBlendingCusMessage, dto.getMsg())
                            .set(WmsJusdaReceiptEntity::getBlendingCusDatetime, LocalDateTime.now())
                            .eq(WmsJusdaReceiptEntity::getId, doc.getId())
                    );
                } else {
                    wmsJusdaReceiptMapper.update(null, Wrappers.<WmsJusdaReceiptEntity>lambdaUpdate()
                            .set(WmsJusdaReceiptEntity::getBlendingCusMessage, dto.getMsg())
                            .set(WmsJusdaReceiptEntity::getBlendingCusDatetime, LocalDateTime.now())
                            .eq(WmsJusdaReceiptEntity::getId, doc.getId())
                    );
                }

            } catch (Exception e) {
                log.error(StrUtil.concat(true, "jusdaVmiBlendingCusNo: ", e.getMessage()));
                e.printStackTrace();
                wmsJusdaReceiptMapper.update(null, Wrappers.<WmsJusdaReceiptEntity>lambdaUpdate()
                        .set(WmsJusdaReceiptEntity::getBlendingCusMessage, e.getMessage())
                        .set(WmsJusdaReceiptEntity::getBlendingCusDatetime, LocalDateTime.now())
                        .eq(WmsJusdaReceiptEntity::getId, doc.getId())
                );
            }
        }
    }

    /**
     * 转仓收货单，依据Q的结果判断是否需要转不良品仓
     */
    public void docTransferReceiveToRejectsWarehouse(String sapClientCode, String orgCode, String postDate) {


        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }
        //需过账DOC list
        List<WmsDocReceive> docList =
                wmsDocReceiveMapper.selectList(Wrappers.<WmsDocReceive>lambdaQuery()
                        .eq(WmsDocReceive::getOrgCode, orgCode)
                        .eq(WmsDocReceive::getQmsReturnFlag, 1)
                        .eq(WmsDocReceive::getDocTypeCode, "TRANSFER_RECEIVE_DOC")
                        // R：拒收  S：重工 A：合格 W：特采   H:带判
                        .in(WmsDocReceive::getQmsReturnMessage, Arrays.asList("R", "S"))
                        .last(" and  (sap_transfer_rejects_number is null or sap_transfer_rejects_number = '')"));

        List<WmsWarehouseRelation> wmsWarehouseRelations =
                warehouseRelationMapper.selectList(Wrappers.<WmsWarehouseRelation>lambdaQuery().eq(WmsWarehouseRelation::getOrgCode, orgCode).eq(WmsWarehouseRelation::getChangeType,
                        "QMS_TRANSFER_REJECTS"));

        docList.forEach(d -> {
            if ("N".equalsIgnoreCase(Constants.continueJob)) {
                return;
            }
            TransferDto dto = new TransferDto();

            Optional<WmsWarehouseRelation> first =
                    wmsWarehouseRelations.stream().filter(a -> a.getFromWarehouseCode().equalsIgnoreCase(d.getSapWarehouseCode()) && a.getPlantCode().equalsIgnoreCase(d.getPlantCode())).findFirst();

            if (first.isPresent()) {
                dto.setToWarehouseName(first.get().getToWarehouseCode());
            } else {
               /* WmsDocReceive wmsDocReceive = new WmsDocReceive();
                wmsDocReceive.setId(d.getId());
                wmsDocReceive.setSapTransferRejectsNumber(null);
                wmsDocReceive.setSapTransferRejectsMessage("no config transfer to warehouse code");
                wmsDocReceive.setSapTransferRejectsDatetime(LocalDateTime.now());
                wmsDocReceive.updateById();*/
                LambdaUpdateWrapper<WmsDocReceive> updateWrapper = new LambdaUpdateWrapper<>();
                updateWrapper.set(WmsDocReceive::getSapTransferRejectsNumber, null);
                updateWrapper.set(WmsDocReceive::getSapTransferRejectsMessage, "no config transfer to warehouse code");
                updateWrapper.set(WmsDocReceive::getSapTransferRejectsDatetime, LocalDateTime.now());
                updateWrapper.eq(WmsDocReceive::getId, d.getId());
                wmsDocReceiveService.update(updateWrapper);
                return;
            }


            dto.setTransactionDate(postDate);
            dto.setDocDate(postDate);
            dto.setMoveType("311");
            dto.setGmCode("04");
            dto.setQty(d.getConfirmQty().toString());
            dto.setUnit("EA");
            dto.setFromPlant(d.getPlantCode());
            dto.setFromWarehouseName(d.getSapWarehouseCode());
            dto.setFromPartNo(d.getPartNo());
            if (StringUtils.isNotBlank(d.getPartNoVersion())) {
                dto.setFromPartVersion(d.getPartNoVersion());
                dto.setToPartVersion(d.getPartNoVersion());
            }
            dto.setToPlant(d.getPlantCode());
            dto.setToPartNo(d.getPartNo());
            String s = null;
            try {

                String s1 = materialRfcService.doGetMaterialValueType(sapClientCode, d.getPlantCode(), d.getPartNo(), d.getSapWarehouseCode());
                if (StringUtils.isNotBlank(s1)) {
                    dto.setValueType(s1);
                } else {
                    WmsDocReceive wmsDocReceive = new WmsDocReceive();
                    wmsDocReceive.setId(d.getId());
                    wmsDocReceive.setSapTransferRejectsMessage("value type not exist");
                    wmsDocReceive.setSapTransferRejectsDatetime(LocalDateTime.now());
                    wmsDocReceive.updateById();
                    return;
                }

                s = whRfcService.doTransfer(sapClientCode, dto);

                WmsDocReceive wmsDocReceive = new WmsDocReceive();
                wmsDocReceive.setId(d.getId());
                wmsDocReceive.setSapTransferRejectsNumber(s);
                wmsDocReceive.setSapTransferRejectsMessage(first.get().getToWarehouseCode() + "--" + s1);
                wmsDocReceive.setSapTransferRejectsDatetime(LocalDateTime.now());
                wmsDocReceive.updateById();

                //解锁PKG,修改SAP仓码
                WmsPkgInfo pkgInfo = new WmsPkgInfo();
                pkgInfo.setLockStatus("0");
                pkgInfo.setLockMessage(null);
                pkgInfo.setSapWarehouseCode(first.get().getToWarehouseCode());
                int update = wmsPkgInfoMapper.update(pkgInfo, Wrappers.<WmsPkgInfo>lambdaUpdate()
                        .eq(WmsPkgInfo::getOrgCode, d.getOrgCode())
                        .eq(WmsPkgInfo::getWmsNo, d.getDocNo()));


            } catch (JCoException e) {
                log.error(e.getMessage());
               /* WmsDocReceive wmsDocReceive = new WmsDocReceive();
                wmsDocReceive.setId(d.getId());
                wmsDocReceive.setSapTransferRejectsNumber(null);
                wmsDocReceive.setSapTransferRejectsMessage("sap posting 311 error");
                wmsDocReceive.setSapTransferRejectsDatetime(LocalDateTime.now());
                wmsDocReceive.updateById();*/
                LambdaUpdateWrapper<WmsDocReceive> updateWrapper = new LambdaUpdateWrapper<>();
                updateWrapper.set(WmsDocReceive::getSapTransferRejectsNumber, null);
                updateWrapper.set(WmsDocReceive::getSapTransferRejectsMessage, "sap posting 311 error");
                updateWrapper.set(WmsDocReceive::getSapTransferRejectsDatetime, LocalDateTime.now());
                updateWrapper.eq(WmsDocReceive::getId, d.getId());
                wmsDocReceiveService.update(updateWrapper);
            }

        });
    }
}