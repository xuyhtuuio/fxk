package com.maxnerva.cloudmes.service.sap.doc.model;

import lombok.Data;

@Data
public class BlendIngCusDTO {
    private String code;

    private String msg;
}
