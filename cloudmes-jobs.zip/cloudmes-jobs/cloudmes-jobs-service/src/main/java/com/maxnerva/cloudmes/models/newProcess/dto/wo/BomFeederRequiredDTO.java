package com.maxnerva.cloudmes.models.newProcess.dto.wo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @Author hgx
 * @Description wmsbomfeeder需求料DTO
 * @Date 2023/5/8 15:27
 */
@Data
@ApiModel
public class BomFeederRequiredDTO {
    @ApiModelProperty("料号")
    private String sparePartNo;

    @ApiModelProperty("productProcess")
    private String materialProductProcess;

    @ApiModelProperty("数量")
    private BigDecimal qty;
}
