package com.maxnerva.cloudmes.service.wh;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.entity.doc.WmsDocTcDetail;

public interface IWmsDocTcDetailService extends IService<WmsDocTcDetail> {
}
