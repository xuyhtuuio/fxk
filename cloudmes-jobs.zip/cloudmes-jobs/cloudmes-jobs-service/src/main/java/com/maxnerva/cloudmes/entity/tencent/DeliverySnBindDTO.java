package com.maxnerva.cloudmes.entity.tencent;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName DeliverySnBindDTO
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/22
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Data
@ApiModel("PO SN绑定信息dto")
public class DeliverySnBindDTO {

    @ApiModelProperty(value = "4.3/4.20接收的PO单号")
    private String poNumber;

    @ApiModelProperty(value = "4.3/4.20接收的detail_id")
    private String detailId;

    @ApiModelProperty(value = "条码SN")
    private String snCode;

    @ApiModelProperty(value = "4.3/4.20接收的estDeliveryDate")
    private String actArriveDate;

    @ApiModelProperty(value = "4.3/4.20接收的conf1")
    private String attr1;

    @ApiModelProperty(value = "4.3/4.20接收的conf2")
    private String attr2;

    @ApiModelProperty(value = "4.3/4.20接收的conf3")
    private String attr3;

    @ApiModelProperty(value = "4.3/4.20接收的conf4")
    private String attr4;

    @ApiModelProperty(value = "4.3/4.20接收的conf5")
    private String attr5;

    @ApiModelProperty(value = "组织代码")
    private String orgCode;
}
