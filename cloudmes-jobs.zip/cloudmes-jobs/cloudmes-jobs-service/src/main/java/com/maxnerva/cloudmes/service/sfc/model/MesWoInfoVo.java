package com.maxnerva.cloudmes.service.sfc.model;

import io.swagger.annotations.ApiModel;
import lombok.Data;

@Data
@ApiModel("根据SN取SFC信息")
public class MesWoInfoVo {
    private String sn;
}
