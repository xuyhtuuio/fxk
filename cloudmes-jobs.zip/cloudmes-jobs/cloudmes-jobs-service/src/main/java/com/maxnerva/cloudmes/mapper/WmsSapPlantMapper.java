package com.maxnerva.cloudmes.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.WmsSapPlant;

/**
 * <p>
 * 工厂属性维护表 Mapper 接口
 * </p>
 *
 * @author caijun
 * @since 2022-08-29
 */
public interface WmsSapPlantMapper extends BaseMapper<WmsSapPlant> {

}
