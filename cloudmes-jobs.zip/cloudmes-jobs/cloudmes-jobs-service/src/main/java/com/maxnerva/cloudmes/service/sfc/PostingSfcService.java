package com.maxnerva.cloudmes.service.sfc;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONConfig;
import cn.hutool.json.JSONUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.config.GlobalCommonConfig;
import com.maxnerva.cloudmes.entity.deliver.*;
import com.maxnerva.cloudmes.entity.pkg.WmsPkgSfcInfoEntity;
import com.maxnerva.cloudmes.entity.wh.WmsPkgInfo;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderHeader;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderPrepareLog;
import com.maxnerva.cloudmes.mapper.basic.BasicMaterialMapper;
import com.maxnerva.cloudmes.mapper.basic.WmsPlantCustomerConfigMapper;
import com.maxnerva.cloudmes.mapper.deliver.*;
import com.maxnerva.cloudmes.mapper.pkg.WmsPkgSfcInfoMapper;
import com.maxnerva.cloudmes.mapper.wh.WmsPkgInfoMapper;
import com.maxnerva.cloudmes.mapper.wo.WmsWorkOrderHeaderMapper;
import com.maxnerva.cloudmes.mapper.wo.WmsWorkOrderPrepareLogMapper;
import com.maxnerva.cloudmes.service.DataSourceService;
import com.maxnerva.cloudmes.service.SfcSiteService;
import com.maxnerva.cloudmes.service.sfc.model.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/09/20 15:20
 * @Version: 1.0
 */
@Service
@Slf4j
public class PostingSfcService {

    @Autowired
    WmsPkgInfoMapper wmsPkgInfoMapper;

    @Autowired
    SfcStoredProcedureFactory sfcStoredProcedureFactory;

    @Autowired
    WmsWorkOrderPrepareLogMapper wmsWorkOrderPrepareLogMapper;

    @Autowired
    WmsPkgSfcInfoMapper wmsPkgSfcInfoMapper;

    @Autowired
    WmsShipPkgBindRecordMapper wmsShipPkgBindRecordMapper;

    @Autowired
    WmsProductShipDetailMapper wmsProductShipDetailMapper;

    @Autowired
    WmsProductShipHeaderMapper wmsProductShipHeaderMapper;

    @Autowired
    WmsShipPkgRecordMapper wmsShipPkgRecordMapper;
    @Autowired
    WmsShippingToSfcLogMapper wmsShippingToSfcLogMapper;

    @Autowired
    DataSourceService dataSourceService;

    @Autowired
    WmsWorkOrderHeaderMapper wmsWorkOrderHeaderMapper;

    @Autowired
    WmsPlantCustomerConfigMapper wmsPlantCustomerConfigMapper;

    @Resource
    private BasicMaterialMapper basicMaterialMapper;

    @Resource
    private GlobalCommonConfig globalCommonConfig;

    /**
     * 上架PKG信息抛SFC DEL
     *
     * @param orgCode
     */
    public void postingUpShelfPkgInfoToSFC(String orgCode) {

        //已经上架，没有被锁的，没有抛SFC的pkg list
        List<WmsPkgInfo> pkgInfos =
                wmsPkgInfoMapper.selectList(Wrappers.<WmsPkgInfo>lambdaQuery().eq(WmsPkgInfo::getOrgCode, orgCode).eq(WmsPkgInfo::getLockStatus, "0").eq(WmsPkgInfo::getWmsToSfcFlag, 0)

                );

        if (CollUtil.isEmpty(pkgInfos)) {
            return;
        }

        pkgInfos.forEach(pkg -> {
            PostPkgInfoToSfcDto p = new PostPkgInfoToSfcDto();
            p.setPkgId(pkg.getPkgId());
            p.setPartNo(pkg.getPartNo());
            p.setQty(pkg.getOriginalQty().toString());
            p.setRemainQty(pkg.getCurrentQty().toString());
            p.setMfgName(pkg.getMfgName());
            p.setMfgPartNo(pkg.getMfgPartNo());
            p.setLotCode(pkg.getLotCode());
            p.setDateCode(pkg.getOriginalDateCode());
            p.setEmpNo("WMS");
            p.setPlaceOfOrigin(pkg.getPlaceOfOrigin1());
            //获取sfcSite  根据组织+工厂
//            String sfcSite = getSfcSite(orgCode, pkg.getPlantCode());
//            String org = orgCode + "_"+ pkg.getPlantCode();
            String sfcSite = SfcSiteService.getSfcSite(orgCode, pkg.getPlantCode());
            String s = sfcStoredProcedureFactory.postingSfcPkgInfo(sfcSite, p, pkg.getPlantCode(),
                    "MES");
            if (StringUtils.isNotBlank(s)) {
                WmsPkgInfo updatePkgInfo = new WmsPkgInfo();
                updatePkgInfo.setId(pkg.getId());
                updatePkgInfo.setWmsToSfcFlag(1);
                updatePkgInfo.setSfcDate(LocalDateTime.now());
                updatePkgInfo.setSfcMessage("OK");
                updatePkgInfo.updateById();
            } else {
                WmsPkgInfo updatePkgInfo = new WmsPkgInfo();
                updatePkgInfo.setId(pkg.getId());
                updatePkgInfo.setSfcDate(LocalDateTime.now());
                updatePkgInfo.setSfcMessage("error");
                updatePkgInfo.updateById();
            }
        });

    }


    /**
     * 工单备料PKG信息抛SFC
     *
     * @param orgCode
     */
    public void postingWoPreparePkgInfoToSFC(String orgCode) {

        //已经上架，没有被锁的，没有抛SFC的pkg list
        List<WmsWorkOrderPrepareLog> pkgInfos =
                wmsWorkOrderPrepareLogMapper.selectList(Wrappers.<WmsWorkOrderPrepareLog>lambdaQuery()
                        .eq(WmsWorkOrderPrepareLog::getOrgCode, orgCode)
//                        .eq(WmsWorkOrderPrepareLog::getLockStatus, "0")
                        .last(" and wms_to_sfc_flag = true and post_sfc_flag = 0 order by id"));

        log.info("postingWoPreparePkgInfoToSFC getData:{}", pkgInfos.size());

        if (CollUtil.isEmpty(pkgInfos)) {
            return;
        }
        Map<String, List<WmsWorkOrderPrepareLog>> collect = pkgInfos.stream()
                .collect(Collectors.groupingBy(WmsWorkOrderPrepareLog::getPkgId));
        log.info("postingWoPreparePkgInfoToSFC getData Collect:{}", collect.size());
        for (Map.Entry<String, List<WmsWorkOrderPrepareLog>> entry : collect.entrySet()) {
            List<WmsWorkOrderPrepareLog> workOrderPrepareLogList = entry.getValue();
            //如果同一个pkg有多条需要抛转的记录,则先取id最小的抛转
            WmsWorkOrderPrepareLog pkg = workOrderPrepareLogList.get(0);
            if (workOrderPrepareLogList.size() > 1) {
                pkg = workOrderPrepareLogList.stream().min(Comparator.comparing(WmsWorkOrderPrepareLog::getId))
                        .orElse(null);
            }
            try {
                if (pkg.getCurrentQty().compareTo(BigDecimal.ZERO) <= 0) {
                    /*WmsWorkOrderPrepareLog updatePkgInfo = new WmsWorkOrderPrepareLog();
                    updatePkgInfo.setId(pkg.getId());
                    updatePkgInfo.setPostSfcFlag(3);
                    updatePkgInfo.updateById();*/
                    wmsWorkOrderPrepareLogMapper.update(null, Wrappers.<WmsWorkOrderPrepareLog>lambdaUpdate()
                            .eq(WmsWorkOrderPrepareLog::getId, pkg.getId())
                            .set(WmsWorkOrderPrepareLog::getPostSfcFlag, 3));
                    continue;
                }
                PostPkgInfoToSfcDto p = new PostPkgInfoToSfcDto();
                p.setPkgId(pkg.getPkgId());
                p.setPartNo(pkg.getPartNo());
                p.setQty(pkg.getOriginalQty().toString());
                p.setRemainQty(pkg.getCurrentQty().toString());
                p.setMfgName(pkg.getMfgName());
                String supplierPartNo = pkg.getSupplierPartNo();
                p.setMfgPartNo(StrUtil.isBlank(supplierPartNo) ? pkg.getMfgPartNo() : supplierPartNo);
//            p.setMfgPartNo(pkg.getMfgPartNo());
                p.setLotCode(pkg.getLotNo());
                p.setDateCode(pkg.getOriginalDateCode());
                p.setCheckSum(pkg.getBurnValue());
                p.setEmpNo("WMS");
                p.setPlaceOfOrigin(pkg.getPlaceOfOrigin1());
                p.setEffectiveDate(pkg.getEffectiveDate());
                LocalDate endDate = pkg.getEndDate();
                p.setEndDate(ObjectUtil.isNotNull(endDate) ?
                        endDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) : StrUtil.EMPTY);
                p.setWorkOrderNo(pkg.getWorkOrderNo());
                p.setVehicleCode(pkg.getVehicleCode());
                p.setBinCode(pkg.getBinCode());
                p.setProductNo(pkg.getProductPartNo());
                p.setFeederNo(pkg.getFeederNo());
                p.setMachineCode(pkg.getMachineCode());
                //获取sfcSite  根据组织+工厂
//                String sfcSite = SfcSiteService.getSfcSite(orgCode, pkg.getPlantCode());
//                String sfcSite = getSfcSite(orgCode, pkg.getPlantCode());
//            String org = orgCode + "_" + pkg.getPlantCode();
                WmsWorkOrderHeader wmsWorkOrderHeaderDb = wmsWorkOrderHeaderMapper.selectOne(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                        .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                        .eq(WmsWorkOrderHeader::getWorkOrderNo, pkg.getWorkOrderNo())
                        .last("limit 1"));
//                String dataSource = dataSourceService.getDataSource(orgCode, wmsWorkOrderHeaderDb.getMrpArea());
                String dataSource = wmsWorkOrderHeaderDb.getMesDataSource();
                log.info("postingWoPreparePkgInfoToSFC dataSource:{} content :{}", dataSource, JSONUtil.toJsonStr(p));
                String s = sfcStoredProcedureFactory.postingSfcPkgInfo(orgCode, p, pkg.getPlantCode(),
                        dataSource);
                log.info("postingWoPreparePkgInfoToSFC dataSource:{} content :{} return :{}",
                        dataSource, JSONUtil.toJsonStr(p), s);
                if (StringUtils.isNotBlank(s) && "OK".equalsIgnoreCase(s)) {
                    /*WmsWorkOrderPrepareLog updatePkgInfo = new WmsWorkOrderPrepareLog();
                    updatePkgInfo.setId(pkg.getId());
//                updatePkgInfo.setWmsToSfcFlag(true);
                    updatePkgInfo.setPostSfcFlag(1);
                    updatePkgInfo.setPostSfcDt(LocalDateTime.now());
//                updatePkgInfo.setPostSfcReturnMessage("OK");
                    updatePkgInfo.setPostSfcReturnMessage(s + " " + dataSource);
                    updatePkgInfo.updateById();*/
                    wmsWorkOrderPrepareLogMapper.update(null, Wrappers.<WmsWorkOrderPrepareLog>lambdaUpdate()
                            .eq(WmsWorkOrderPrepareLog::getId, pkg.getId())
                            .set(WmsWorkOrderPrepareLog::getPostSfcFlag, 1)
                            .set(WmsWorkOrderPrepareLog::getPostSfcDt, LocalDateTime.now())
                            .set(WmsWorkOrderPrepareLog::getPostSfcReturnMessage, s + " " + dataSource));
                } else {
                  /*  WmsWorkOrderPrepareLog updatePkgInfo = new WmsWorkOrderPrepareLog();
                    updatePkgInfo.setId(pkg.getId());
                    updatePkgInfo.setPostSfcFlag(3);
                    updatePkgInfo.setPostSfcDt(LocalDateTime.now());
                    updatePkgInfo.setPostSfcReturnMessage(s + " " + dataSource);
                    updatePkgInfo.updateById();*/
                    wmsWorkOrderPrepareLogMapper.update(null, Wrappers.<WmsWorkOrderPrepareLog>lambdaUpdate()
                            .eq(WmsWorkOrderPrepareLog::getId, pkg.getId())
                            .set(WmsWorkOrderPrepareLog::getPostSfcFlag, 3)
                            .set(WmsWorkOrderPrepareLog::getPostSfcDt, LocalDateTime.now())
                            .set(WmsWorkOrderPrepareLog::getPostSfcReturnMessage, s + " " + dataSource));
                }
            } catch (Exception e) {
                log.error("postingWoPreparePkgInfoToSFC ERROR:{}", e.getMessage());
           /*     WmsWorkOrderPrepareLog updatePkgInfo = new WmsWorkOrderPrepareLog();
                updatePkgInfo.setId(pkg.getId());
                updatePkgInfo.setPostSfcFlag(3);
                updatePkgInfo.setPostSfcDt(LocalDateTime.now());
                updatePkgInfo.setPostSfcReturnMessage("SFC interface error");
                updatePkgInfo.updateById();*/
                wmsWorkOrderPrepareLogMapper.update(null, Wrappers.<WmsWorkOrderPrepareLog>lambdaUpdate()
                        .eq(WmsWorkOrderPrepareLog::getId, pkg.getId())
                        .set(WmsWorkOrderPrepareLog::getPostSfcFlag, 3)
                        .set(WmsWorkOrderPrepareLog::getPostSfcDt, LocalDateTime.now())
                        .set(WmsWorkOrderPrepareLog::getPostSfcReturnMessage, "SFC interface error"));
            }
        }
        /*pkgInfos.forEach(pkg -> {
            try {
                if (pkg.getCurrentQty().compareTo(BigDecimal.ZERO) <= 0) {
                    WmsWorkOrderPrepareLog updatePkgInfo = new WmsWorkOrderPrepareLog();
                    updatePkgInfo.setId(pkg.getId());
                    updatePkgInfo.setPostSfcFlag(3);
                    updatePkgInfo.updateById();
                    return;
                }
                PostPkgInfoToSfcDto p = new PostPkgInfoToSfcDto();
                p.setPkgId(pkg.getPkgId());
                p.setPartNo(pkg.getPartNo());
                p.setQty(pkg.getOriginalQty().toString());
                p.setRemainQty(pkg.getCurrentQty().toString());
                p.setMfgName(pkg.getMfgName());
                String supplierPartNo = pkg.getSupplierPartNo();
                p.setMfgPartNo(StrUtil.isBlank(supplierPartNo) ? pkg.getMfgPartNo() : supplierPartNo);
//            p.setMfgPartNo(pkg.getMfgPartNo());
                p.setLotCode(pkg.getLotNo());
                p.setDateCode(pkg.getOriginalDateCode());
                p.setCheckSum(pkg.getBurnValue());
                p.setEmpNo("WMS");
                p.setPlaceOfOrigin(pkg.getPlaceOfOrigin1());
                p.setEffectiveDate(pkg.getEffectiveDate());
                LocalDate endDate = pkg.getEndDate();
                p.setEndDate(ObjectUtil.isNotNull(endDate) ?
                        endDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) : StrUtil.EMPTY);
                p.setWorkOrderNo(pkg.getWorkOrderNo());
                p.setVehicleCode(pkg.getVehicleCode());
                p.setBinCode(pkg.getBinCode());
                p.setProductNo(pkg.getProductPartNo());
                //获取sfcSite  根据组织+工厂
//                String sfcSite = SfcSiteService.getSfcSite(orgCode, pkg.getPlantCode());
//                String sfcSite = getSfcSite(orgCode, pkg.getPlantCode());
//            String org = orgCode + "_" + pkg.getPlantCode();
                WmsWorkOrderHeader wmsWorkOrderHeaderDb = wmsWorkOrderHeaderMapper.selectOne(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                        .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                        .eq(WmsWorkOrderHeader::getWorkOrderNo, pkg.getWorkOrderNo())
                        .last("limit 1"));
//                String dataSource = dataSourceService.getDataSource(orgCode, wmsWorkOrderHeaderDb.getMrpArea());
                String dataSource = wmsWorkOrderHeaderDb.getMesDataSource();
                String s = sfcStoredProcedureFactory.postingSfcPkgInfo(orgCode, p, pkg.getPlantCode(),
                        dataSource);
                log.info("to SFC content :{} return :{}", JSONUtil.toJsonStr(p), s);
                if (StringUtils.isNotBlank(s) && "OK".equalsIgnoreCase(s)) {
                    WmsWorkOrderPrepareLog updatePkgInfo = new WmsWorkOrderPrepareLog();
                    updatePkgInfo.setId(pkg.getId());
//                updatePkgInfo.setWmsToSfcFlag(true);
                    updatePkgInfo.setPostSfcFlag(1);
                    updatePkgInfo.setPostSfcDt(LocalDateTime.now());
//                updatePkgInfo.setPostSfcReturnMessage("OK");
                    updatePkgInfo.setPostSfcReturnMessage(s + " " + dataSource);
                    updatePkgInfo.updateById();
                } else {
                    WmsWorkOrderPrepareLog updatePkgInfo = new WmsWorkOrderPrepareLog();
                    updatePkgInfo.setId(pkg.getId());
                    updatePkgInfo.setPostSfcFlag(3);
                    updatePkgInfo.setPostSfcDt(LocalDateTime.now());
                    updatePkgInfo.setPostSfcReturnMessage(s + " " + dataSource);
                    updatePkgInfo.updateById();
                }
            } catch (Exception e) {
                log.error("postingWoPreparePkgInfoToSFC {}", e.getMessage());
                WmsWorkOrderPrepareLog updatePkgInfo = new WmsWorkOrderPrepareLog();
                updatePkgInfo.setId(pkg.getId());
                updatePkgInfo.setPostSfcFlag(3);
                updatePkgInfo.setPostSfcDt(LocalDateTime.now());
                updatePkgInfo.setPostSfcReturnMessage("SFC interface error");
                updatePkgInfo.updateById();
            }
        });*/

    }


    /**
     * 入库sn 回写SFC过账工站
     */
    public void warehousingPassSnStation(String orgCode) {

        List<WmsPkgSfcInfoEntity> pkgInfos =
                wmsPkgSfcInfoMapper.selectList(Wrappers.<WmsPkgSfcInfoEntity>lambdaQuery().eq(WmsPkgSfcInfoEntity::getOrgCode, orgCode)
                        .eq(WmsPkgSfcInfoEntity::getPostSfcPassStationFlag, "N"));

        if (CollUtil.isEmpty(pkgInfos)) {
            return;
        }

        pkgInfos.forEach(pkg -> {
            try {
                WarehousingPassSnStationDto p = new WarehousingPassSnStationDto();
                p.setSn(pkg.getSnNo());
                p.setUserName("WMS");
                p.setLine("");
                p.setSection("INSTORE");
                p.setWStation("INSTORE");
                p.setBadCode("N/A");
                p.setMyGroup("INSTORE");
                //获取sfcSite  根据组织+工厂
//                String sfcSite = SfcSiteService.getSfcSite(orgCode, pkg.getPlantCode());
//                String sfcSite = getSfcSite(orgCode, pkg.getPlantCode());
                String workerOrderNo = pkg.getWorkerOrderNo();
                WmsWorkOrderHeader wmsWorkOrderHeaderDb = wmsWorkOrderHeaderMapper.selectOne(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                        .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                        .eq(WmsWorkOrderHeader::getWorkOrderNo, workerOrderNo)
                        .last("limit 1"));
//                String dataSource = dataSourceService.getDataSource(orgCode, wmsWorkOrderHeaderDb.getMrpArea());
                String dataSource = wmsWorkOrderHeaderDb.getMesDataSource();
                String s = sfcStoredProcedureFactory.warehousingPassSnStation(orgCode, p, pkg.getPlantCode(),
                        dataSource);
                log.info("warehousingPassSnStation to SFC content :{} return :{}", JSONUtil.toJsonStr(p), s);

                if (StringUtils.isNotBlank(s) && "OK".equalsIgnoreCase(s)) {
                    WmsPkgSfcInfoEntity updatePkgInfo = new WmsPkgSfcInfoEntity();
                    updatePkgInfo.setId(pkg.getId());
                    updatePkgInfo.setPostSfcPassStationFlag("Y");
                    updatePkgInfo.setPostSfcDatatime(LocalDateTime.now());
                    updatePkgInfo.setPostSfcMessage(s + " " + dataSource);
                    updatePkgInfo.updateById();
                } else {
                    WmsPkgSfcInfoEntity updatePkgInfo = new WmsPkgSfcInfoEntity();
                    updatePkgInfo.setId(pkg.getId());
                    updatePkgInfo.setPostSfcPassStationFlag("M");
                    updatePkgInfo.setPostSfcDatatime(LocalDateTime.now());
                    updatePkgInfo.setPostSfcMessage(s + " " + dataSource);
                    updatePkgInfo.updateById();
                }
            } catch (Exception e) {
                log.error("warehousingPassSnStation {}", e.getMessage());
                WmsPkgSfcInfoEntity updatePkgInfo = new WmsPkgSfcInfoEntity();
                updatePkgInfo.setId(pkg.getId());
                updatePkgInfo.setPostSfcPassStationFlag("M");
                updatePkgInfo.setPostSfcDatatime(LocalDateTime.now());
                updatePkgInfo.setPostSfcMessage("SFC interface error");
                updatePkgInfo.updateById();
            }
        });

    }


    public void syncSfcExtendInfoBySn(String orgCode) {

/*        List<WmsPkgSfcInfoEntity> pkgList =
                wmsPkgSfcInfoMapper.selectList(Wrappers.<WmsPkgSfcInfoEntity>lambdaQuery()
                        .eq(WmsPkgSfcInfoEntity::getOrgCode, orgCode)
                        .last(" and (sync_sfc_extend_info_result is null or sync_sfc_extend_info_result = '0') "));*/
        List<WmsPkgSfcInfoEntity> pkgList = wmsPkgSfcInfoMapper.selectSfcInfoList(orgCode, "EPDVI_F6T1");

        if (CollUtil.isEmpty(pkgList)) {
            return;
        }

        pkgList.forEach(pkg -> {
            //获取sfcSite  根据组织+工厂
            try {
//                String sfcSite = SfcSiteService.getSfcSite(orgCode, pkg.getPlantCode());
//                String sfcSite = getSfcSite(pkg.getOrgCode(), pkg.getPlantCode());
                Map info = sfcStoredProcedureFactory.getSfcExtendInfoBySn("EPDVI_F6T1", pkg.getSnNo());
                if ("OK".equalsIgnoreCase(info.get("o_res").toString())) {
                    List<SnSfcExtendInfoDto> a = (List<SnSfcExtendInfoDto>) info.get("o_dataset");
                    if (CollUtil.isNotEmpty(a)) {
                        WmsPkgSfcInfoEntity update = new WmsPkgSfcInfoEntity();
                        update.setId(pkg.getId());
                        update.setSyncSfcExtendInfoResult("OK");
                        update.setSfcModelName(a.get(0).getModelName());
                        update.setSfcIpn(a.get(0).getIPN());
                        update.setSfcModelSerial(a.get(0).getModelSerial());
                        update.setSfcRev(a.get(0).getRev());
                        update.setSfcAssetid(a.get(0).getAssetidAddress());
                        update.updateById();
//                    if (pkg.getPalletNo().equalsIgnoreCase(pkg.getSnNo())) {
                        //修改pkginfo
                        wmsPkgInfoMapper.update(null, Wrappers.<WmsPkgInfo>lambdaUpdate()
                                .eq(WmsPkgInfo::getOrgCode, orgCode)
                                .eq(WmsPkgInfo::getPkgId, pkg.getSnNo())
                                .set(WmsPkgInfo::getAssetId, a.get(0).getAssetidAddress())
                                .set(WmsPkgInfo::getIPn, a.get(0).getIPN())
                                .set(WmsPkgInfo::getModelNameSfc, a.get(0).getModelName())
                                .set(WmsPkgInfo::getModelSerial, a.get(0).getModelSerial())
                        );
//                    }
                    } else {
                        wmsPkgSfcInfoMapper.update(null, Wrappers.<WmsPkgSfcInfoEntity>lambdaUpdate()
                                .eq(WmsPkgSfcInfoEntity::getId, pkg.getId())
                                .set(WmsPkgSfcInfoEntity::getSyncSfcExtendInfoResult, "sfc data is null"));
                    }

                } else {
                    wmsPkgSfcInfoMapper.update(null, Wrappers.<WmsPkgSfcInfoEntity>lambdaUpdate()
                            .eq(WmsPkgSfcInfoEntity::getId, pkg.getId())
                            .set(WmsPkgSfcInfoEntity::getSyncSfcExtendInfoResult, info.get("o_res")));
                }
            } catch (Exception e) {
                log.error("getSfcExtendInfoBySn {}", e.getMessage());
                wmsPkgSfcInfoMapper.update(null, Wrappers.<WmsPkgSfcInfoEntity>lambdaUpdate()
                        .eq(WmsPkgSfcInfoEntity::getId, pkg.getId())
                        .set(WmsPkgSfcInfoEntity::getSyncSfcExtendInfoResult, "SFC interface error"));
            }
        });


    }


    public void sendSnDnRelationshipToSfc(String orgCode) {
        List<WmsShipPkgBindRecord> wmsShipPkgBindRecordList = wmsShipPkgBindRecordMapper
                .selectList(Wrappers.<WmsShipPkgBindRecord>lambdaQuery()
                        .eq(WmsShipPkgBindRecord::getOrgCode, orgCode)
                        .eq(WmsShipPkgBindRecord::getPostSfcFlag, "0"));
        for (WmsShipPkgBindRecord wmsShipPkgBindRecord : wmsShipPkgBindRecordList) {
            try {
                Integer shipDetailId = wmsShipPkgBindRecord.getShipDetailId();
                WmsDocProductShipDetail wmsDocProductShipDetail = wmsProductShipDetailMapper
                        .selectById(shipDetailId);
                Integer headerId = wmsDocProductShipDetail.getHeaderId();
                WmsDocProductShipHeader wmsDocProductShipHeader = wmsProductShipHeaderMapper.selectById(headerId);
                String dnNo = wmsDocProductShipHeader.getDnNo();
                SnDnRelationshipDto snDnRelationshipDto = new SnDnRelationshipDto();
                snDnRelationshipDto.setDn(dnNo);
                String pkgId = wmsShipPkgBindRecord.getPkgId();
                WmsPkgSfcInfoEntity wmsPkgSfcInfoEntity = wmsPkgSfcInfoMapper.selectOne(Wrappers.<WmsPkgSfcInfoEntity>lambdaQuery()
                        .eq(WmsPkgSfcInfoEntity::getPalletNo, pkgId)
                        .eq(WmsPkgSfcInfoEntity::getOrgCode, orgCode)
//                        .orderByDesc(WmsPkgSfcInfoEntity::getId)
                        .last("order by id+0 desc limit 1"));
                if (ObjectUtil.isNotNull(wmsPkgSfcInfoEntity)) {
                    snDnRelationshipDto.setSn(wmsPkgSfcInfoEntity.getSnNo());
                } else {
                    wmsPkgSfcInfoEntity = wmsPkgSfcInfoMapper.selectOne(Wrappers.<WmsPkgSfcInfoEntity>lambdaQuery()
                            .eq(WmsPkgSfcInfoEntity::getCartonNo, pkgId)
                            .eq(WmsPkgSfcInfoEntity::getOrgCode, orgCode)
//                            .orderByDesc(WmsPkgSfcInfoEntity::getId)
                            .last("order by id+0 desc limit 1"));
                    snDnRelationshipDto.setSn(wmsPkgSfcInfoEntity.getSnNo());
                }
                snDnRelationshipDto.setSfcWorkstation("INSTORE");
                snDnRelationshipDto.setPo(wmsDocProductShipDetail.getAmazonId());
                snDnRelationshipDto.setTemporaryPoOfHub(wmsDocProductShipDetail.getBuildTriggerId());
                snDnRelationshipDto.setProductNo(wmsDocProductShipDetail.getPartNo());
                snDnRelationshipDto.setDestination(wmsDocProductShipHeader.getSiteCode());
                snDnRelationshipDto.setCusNo(wmsDocProductShipDetail.getCusNo());
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String shippingDt = sdf.format(wmsShipPkgBindRecord.getCreatedDt());
                snDnRelationshipDto.setShippingDt(shippingDt);
                WmsWorkOrderHeader wmsWorkOrderHeader = wmsWorkOrderHeaderMapper.selectOne(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                        .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                        .eq(WmsWorkOrderHeader::getWorkOrderNo, wmsPkgSfcInfoEntity.getWorkerOrderNo())
                        .last("limit 1"));
                if (ObjectUtil.isNull(wmsWorkOrderHeader)) {
                    log.error("sendSnDnRelationshipToSfc wmsWorkOrderHeader:{} is null", wmsPkgSfcInfoEntity.getWorkerOrderNo());
                    WmsShipPkgBindRecord pkgBindRecord = new WmsShipPkgBindRecord();
                    pkgBindRecord.setId(wmsShipPkgBindRecord.getId());
                    wmsShipPkgBindRecord.setPostSfcDate(LocalDateTime.now());
                    wmsShipPkgBindRecord.setPostSfcMessage("wmsWorkOrderHeader："
                            + wmsPkgSfcInfoEntity.getWorkerOrderNo() + "is null");
                    wmsShipPkgBindRecordMapper.updateById(wmsShipPkgBindRecord);
                    continue;
                }
                snDnRelationshipDto.setTransportType(wmsDocProductShipHeader.getTransportMode());
                snDnRelationshipDto.setWmsNo(wmsDocProductShipHeader.getDocNo());
                //获取sfcSite  根据组织+工厂
                String result = sfcStoredProcedureFactory.sendSnDnRelationshipToSfc(orgCode, wmsWorkOrderHeader.getMrpArea(),
                        wmsWorkOrderHeader.getMesDataSource(), wmsDocProductShipHeader.getSapPlantCode(), snDnRelationshipDto);
                log.info("to sendSnDnRelationshipToSfc content :{} return :{}", JSONUtil.toJsonStr(snDnRelationshipDto), result);
                if (StrUtil.isNotBlank(result) && "OK".equals(result)) {
                    WmsShipPkgBindRecord pkgBindRecord = new WmsShipPkgBindRecord();
                    pkgBindRecord.setId(wmsShipPkgBindRecord.getId());
                    wmsShipPkgBindRecord.setPostSfcFlag("1");
                    wmsShipPkgBindRecord.setPostSfcDate(LocalDateTime.now());
                    wmsShipPkgBindRecord.setPostSfcMessage(result);
                    wmsShipPkgBindRecordMapper.updateById(wmsShipPkgBindRecord);
                } else {
                    WmsShipPkgBindRecord pkgBindRecord = new WmsShipPkgBindRecord();
                    pkgBindRecord.setId(wmsShipPkgBindRecord.getId());
                    wmsShipPkgBindRecord.setPostSfcDate(LocalDateTime.now());
                    wmsShipPkgBindRecord.setPostSfcMessage(result);
                    wmsShipPkgBindRecordMapper.updateById(wmsShipPkgBindRecord);
                }
            } catch (Exception e) {
                log.error("sendSnDnRelationshipToSfc {}", e.getMessage());
                WmsShipPkgBindRecord pkgBindRecord = new WmsShipPkgBindRecord();
                pkgBindRecord.setId(wmsShipPkgBindRecord.getId());
                wmsShipPkgBindRecord.setPostSfcDate(LocalDateTime.now());
                wmsShipPkgBindRecord.setPostSfcMessage("SFC interface error");
                wmsShipPkgBindRecordMapper.updateById(wmsShipPkgBindRecord);
            }
        }
    }

    public void insertAmazonLog(String orgCode) {
        List<WmsDocProductShipDetail> wmsDocProductShipDetails = wmsProductShipDetailMapper
                .selectList(Wrappers.<WmsDocProductShipDetail>lambdaQuery()
                        .eq(WmsDocProductShipDetail::getOrgCode, orgCode)
                        .eq(WmsDocProductShipDetail::getIsDeleted, Boolean.FALSE)
                        .eq(WmsDocProductShipDetail::getPostSfcFlag, "0"));
        for (WmsDocProductShipDetail wmsDocProductShipDetail : wmsDocProductShipDetails) {
            try {
                Integer headerId = wmsDocProductShipDetail.getHeaderId();
                WmsDocProductShipHeader wmsDocProductShipHeader = wmsProductShipHeaderMapper.selectById(headerId);
                String docType = wmsDocProductShipHeader.getDocType();
                if (!"PRE_SHIPPING_PRODUCT_DELIVERY".equals(docType)) {
                    continue;
                }
                if ("E1T1".equals(wmsDocProductShipHeader.getSapPlantCode())) {
                    WmsDocProductShipDetail productShipDetail = new WmsDocProductShipDetail();
                    productShipDetail.setId(wmsDocProductShipDetail.getId());
                    wmsDocProductShipDetail.setPostSfcFlag("1");
                    wmsDocProductShipDetail.setPostSfcDate(LocalDateTime.now());
                    wmsDocProductShipDetail.setPostSfcMessage("E1T1");
                    wmsProductShipDetailMapper.updateById(wmsDocProductShipDetail);
                    continue;
                }
                InsertAmazonLogDto insertAmazonLogDto = new InsertAmazonLogDto();
                insertAmazonLogDto.setDemandType(wmsDocProductShipDetail.getDemandType());
                insertAmazonLogDto.setAmazonId(wmsDocProductShipDetail.getAmazonId());
                insertAmazonLogDto.setRequestId(wmsDocProductShipDetail.getRequestId());
                insertAmazonLogDto.setBuildTriggerId(wmsDocProductShipDetail.getBuildTriggerId());
                insertAmazonLogDto.setAssetId(StrUtil.EMPTY);
                insertAmazonLogDto.setQty(wmsDocProductShipDetail.getPlanShipQty().intValue());
                insertAmazonLogDto.setIPn(wmsDocProductShipDetail.getCusNo());
                insertAmazonLogDto.setAssetCategory("Rack");
                insertAmazonLogDto.setTestItem("NO");
                insertAmazonLogDto.setItemDescription(wmsDocProductShipDetail.getItemDescription());
                insertAmazonLogDto.setSiteCode(wmsDocProductShipDetail.getSiteCode());
                insertAmazonLogDto.setInStockHub(StrUtil.EMPTY);
                insertAmazonLogDto.setManufacturingStartDate(StrUtil.EMPTY);
                insertAmazonLogDto.setEstimatedReadyDate(StrUtil.EMPTY);
                insertAmazonLogDto.setComments(StrUtil.EMPTY);
                String org = orgCode + "_" + wmsDocProductShipHeader.getSapPlantCode();
                String result = sfcStoredProcedureFactory.insertAmazonLog(org, insertAmazonLogDto);
                log.info("to insertAmazonLogToSfc content :{} return :{}", JSONUtil.toJsonStr(insertAmazonLogDto), result);
                if (StrUtil.isNotBlank(result) && "OK".equals(result)) {
                    WmsDocProductShipDetail productShipDetail = new WmsDocProductShipDetail();
                    productShipDetail.setId(wmsDocProductShipDetail.getId());
                    wmsDocProductShipDetail.setPostSfcFlag("1");
                    wmsDocProductShipDetail.setPostSfcDate(LocalDateTime.now());
                    wmsDocProductShipDetail.setPostSfcMessage(result);
                    wmsProductShipDetailMapper.updateById(wmsDocProductShipDetail);
                } else {
                    WmsDocProductShipDetail productShipDetail = new WmsDocProductShipDetail();
                    productShipDetail.setId(wmsDocProductShipDetail.getId());
                    wmsDocProductShipDetail.setPostSfcDate(LocalDateTime.now());
                    wmsDocProductShipDetail.setPostSfcMessage(result);
                    wmsProductShipDetailMapper.updateById(wmsDocProductShipDetail);
                }
            } catch (Exception e) {
                log.error("insertAmazonLog {}", e.getMessage());
                WmsDocProductShipDetail productShipDetail = new WmsDocProductShipDetail();
                productShipDetail.setId(wmsDocProductShipDetail.getId());
                wmsDocProductShipDetail.setPostSfcDate(LocalDateTime.now());
                wmsDocProductShipDetail.setPostSfcMessage("SFC interface error");
                wmsProductShipDetailMapper.updateById(wmsDocProductShipDetail);
            }
        }
    }

    public void productShipCompletedToSfc(String orgCode, String docNo, String cartonNo) {
        WmsDocProductShipHeader shipHeader = wmsProductShipHeaderMapper.selectOne(Wrappers.<WmsDocProductShipHeader>lambdaQuery()
                .eq(WmsDocProductShipHeader::getOrgCode, orgCode)
                .eq(WmsDocProductShipHeader::getDocNo, docNo));
        //先匹配箱号，没有数据再匹配栈板号
        List<WmsPkgSfcInfoEntity> sfcInfoEntityList = new ArrayList<>();
        QueryWrapper<WmsPkgSfcInfoEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("DISTINCT carton_no, worker_order_no").lambda()
                .eq(WmsPkgSfcInfoEntity::getOrgCode, orgCode)
                .eq(WmsPkgSfcInfoEntity::getCartonNo, cartonNo);
        sfcInfoEntityList = wmsPkgSfcInfoMapper.selectList(queryWrapper);
        if (CollUtil.isEmpty(sfcInfoEntityList)) {
            QueryWrapper<WmsPkgSfcInfoEntity> queryWrapper2 = new QueryWrapper<>();
            queryWrapper2.select("DISTINCT carton_no, worker_order_no").lambda()
                    .eq(WmsPkgSfcInfoEntity::getOrgCode, orgCode)
                    .eq(WmsPkgSfcInfoEntity::getPalletNo, cartonNo);
            sfcInfoEntityList = wmsPkgSfcInfoMapper.selectList(queryWrapper2);
        }
        if (CollUtil.isEmpty(sfcInfoEntityList)) {
            throw new RuntimeException("The carton number is not exist in pkgSfcInfo");
        }
        Set<String> dataSourceList = CollUtil.newHashSet();
        for (WmsPkgSfcInfoEntity wmsPkgSfcInfoEntity : sfcInfoEntityList) {
            WmsWorkOrderHeader wmsWorkOrderHeader = wmsWorkOrderHeaderMapper.selectOne(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                    .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                    .eq(WmsWorkOrderHeader::getWorkOrderNo, wmsPkgSfcInfoEntity.getWorkerOrderNo())
                    .last("limit 1"));
            if (ObjectUtil.isNull(wmsWorkOrderHeader)) {
                throw new RuntimeException("wmsWorkOrderHeader not exist:" + wmsPkgSfcInfoEntity.getWorkerOrderNo());
            }
            //获取sfcSite  根据组织+工厂
            String dataSource = wmsWorkOrderHeader.getMesDataSource();
            dataSourceList.add(dataSource);
        }
        //此箱号对应的工单有不同数据源
        if (dataSourceList.size() > 1) {
            throw new RuntimeException("this carton no:" + cartonNo + " has different data sources");
        }
        WmsPkgSfcInfoEntity sfcInfoEntity = sfcInfoEntityList.get(0);
//        for (WmsPkgSfcInfoEntity sfcInfoEntity : sfcInfoEntityList) {
            String toSfcFlag = "";
            String result = "";
            String dataSource = "";
            try {
                PostProductShippingToSfcDto toSfcDto = new PostProductShippingToSfcDto();
                toSfcDto.setEmp("WMS");
//                String vehicle = StringUtils.isNotEmpty(shipHeader.getTransportMode()) ? shipHeader.getTransportMode() : "";
                toSfcDto.setVehicle(shipHeader.getTransportMode());
                toSfcDto.setDn(shipHeader.getDnNo());
                toSfcDto.setDestination(shipHeader.getSiteCode());
                toSfcDto.setMygroup("SHIPPING");
                toSfcDto.setCarton(sfcInfoEntity.getCartonNo());
                toSfcDto.setOrgCode(orgCode);
                if ("CMB".equals(orgCode)) {
                    //根据箱号+org_code去wms_ship_pkg_bind_record找到最大id的一条
                    WmsShipPkgBindRecord wmsShipPkgBindRecord = wmsShipPkgBindRecordMapper
                            .selectOne(Wrappers.<WmsShipPkgBindRecord>lambdaQuery()
                                    .eq(WmsShipPkgBindRecord::getOrgCode, orgCode)
                                    .eq(WmsShipPkgBindRecord::getPkgId, sfcInfoEntity.getCartonNo())
                                    .orderByDesc(WmsShipPkgBindRecord::getId)
                                    .last("limit 1"));
                    //找ship_detail_id(成品出货明细),找到成品出货明细的cus_no和part_no
                    Integer shipDetailId = wmsShipPkgBindRecord.getShipDetailId();
                    WmsDocProductShipDetail wmsDocProductShipDetail = wmsProductShipDetailMapper
                            .selectById(shipDetailId);
                    /*//根据cus_no和part_no找到基础档的客户名称
                    String customerName = basicMaterialMapper.selectCustomerNameByMaterialNoCusNo(orgCode,
                            shipHeader.getSapPlantCode(), wmsDocProductShipDetail.getPartNo(),
                            wmsDocProductShipDetail.getCusNo());
                    if (StrUtil.isEmpty(customerName)) {
                        log.error("")
                    }*/
                    toSfcDto.setPo(wmsDocProductShipDetail.getPo());
                }
                toSfcDto.setDnFlag("3".equals(shipHeader.getStatus())?"Y":"N");
                WmsWorkOrderHeader wmsWorkOrderHeader = wmsWorkOrderHeaderMapper.selectOne(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                        .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                        .eq(WmsWorkOrderHeader::getWorkOrderNo, sfcInfoEntity.getWorkerOrderNo())
                        .last("limit 1"));
                if (ObjectUtil.isNull(wmsWorkOrderHeader)) {
                    throw new RuntimeException("wmsWorkOrderHeader not exist:" + sfcInfoEntity.getWorkerOrderNo());
                }
                //获取sfcSite  根据组织+工厂
                dataSource = wmsWorkOrderHeader.getMesDataSource();
                result = sfcStoredProcedureFactory.sendProductShippingToSfc(dataSource, toSfcDto);
                log.info("to sendProductShippingToSfc content :{} return :{}", JSONUtil.toJsonStr(toSfcDto), result);
                //回写结果
                toSfcFlag = result.equalsIgnoreCase("ok") || result.equals("SHIPPING(0)") ? "ok" : "fail";
                wmsPkgSfcInfoMapper.update(null, Wrappers.<WmsPkgSfcInfoEntity>lambdaUpdate()
                        .set(WmsPkgSfcInfoEntity::getShippingToSfcFlag, toSfcFlag)
                        .set(WmsPkgSfcInfoEntity::getShippingToSfcMsg, result)
                        .eq(WmsPkgSfcInfoEntity::getOrgCode, orgCode)
                        .eq(WmsPkgSfcInfoEntity::getCartonNo, sfcInfoEntity.getCartonNo()));
                //回写抛SFC日志表
                WmsShippingToSfcLog toSfcLog = new WmsShippingToSfcLog();
                toSfcLog.setPkgId(cartonNo);
                toSfcLog.setCartonNo(toSfcDto.getCarton());
                toSfcLog.setToSfcDate(LocalDateTime.now());
                toSfcLog.setToSfcResult(result);
                toSfcLog.setOrgCode(orgCode);
                toSfcLog.setToSfcData(JSONUtil.toJsonStr(toSfcDto));
                toSfcLog.setType(dataSource);
                wmsShippingToSfcLogMapper.insert(toSfcLog);
            } catch (Exception e) {
                log.error("sendProductShippingToSfc:{}",e.getMessage());
                wmsPkgSfcInfoMapper.update(null, Wrappers.<WmsPkgSfcInfoEntity>lambdaUpdate()
                        .set(WmsPkgSfcInfoEntity::getShippingToSfcFlag, "fail")
                        .set(WmsPkgSfcInfoEntity::getShippingToSfcMsg, "SFC interface error")
                        .eq(WmsPkgSfcInfoEntity::getOrgCode, orgCode)
                        .eq(WmsPkgSfcInfoEntity::getCartonNo, sfcInfoEntity.getCartonNo())
                );
            }
            if (!"ok".equals(toSfcFlag)) {
                throw new RuntimeException("POST " + dataSource + " ERROR：" + result);
            }
//        }
    }

    public List<SfcPkgRelationDto> getPkgRelation(String orgCode, String pkgId) {
        Map info = sfcStoredProcedureFactory.getPkgRelation(orgCode, pkgId);
        List<SfcPkgRelationDto> sfcPkgRelationDtoList = CollUtil.newArrayList();
        if ("OK".equalsIgnoreCase(info.get("o_res").toString())) {
            sfcPkgRelationDtoList = (List<SfcPkgRelationDto>) info.get("o_dataset");
        }
        return sfcPkgRelationDtoList;
    }

    /**
     * 获取sfc调用节点
     *
     * @param orgCode   组织
     * @param plantCode 工厂编码
     * @return sfc节点
     */
    public String getSfcSite(String orgCode, String plantCode) {
        return StrUtil.isNotEmpty(plantCode) ? orgCode + "_" + plantCode : orgCode;
    }

    /**
     * 退料上架将工单备料PKG信息抛SFC
     *
     * @param orgCode
     */
    public String postingReturnWoPreparePkgInfoToSfC(String orgCode, String id, String remainQty) {
        WmsWorkOrderPrepareLog pkg = wmsWorkOrderPrepareLogMapper.selectOne(Wrappers.<WmsWorkOrderPrepareLog>lambdaQuery()
                .eq(WmsWorkOrderPrepareLog::getOrgCode, orgCode)
                .eq(WmsWorkOrderPrepareLog::getId, Integer.valueOf(id)));
        PostPkgInfoToSfcDto p = new PostPkgInfoToSfcDto();
        p.setPkgId(pkg.getPkgId());
        p.setPartNo(pkg.getPartNo());
        p.setQty(pkg.getOriginalQty().toString());
        p.setRemainQty(StrUtil.isEmpty(remainQty) ? BigDecimal.ZERO.toString() : remainQty);
//        p.setRemainQty(BigDecimal.ZERO.toString());
        p.setMfgName(pkg.getMfgName());
        String supplierPartNo = pkg.getSupplierPartNo();
        p.setMfgPartNo(StrUtil.isBlank(supplierPartNo) ? pkg.getMfgPartNo() : supplierPartNo);
        p.setLotCode(pkg.getLotNo());
        p.setDateCode(pkg.getOriginalDateCode());
        p.setEmpNo("WMS");
        p.setPlaceOfOrigin(pkg.getPlaceOfOrigin1());
        p.setEffectiveDate(pkg.getEffectiveDate());
        LocalDate endDate = pkg.getEndDate();
        p.setEndDate(ObjectUtil.isNotNull(endDate) ?
                endDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) : StrUtil.EMPTY);
        p.setWorkOrderNo(pkg.getWorkOrderNo());
        p.setVehicleCode(pkg.getVehicleCode());
        p.setBinCode(pkg.getBinCode());
        p.setProductNo(pkg.getProductPartNo());
        p.setFeederNo(pkg.getFeederNo());
        p.setMachineCode(pkg.getMachineCode());
        //获取sfcSite  根据组织+工厂
//        String sfcSite = SfcSiteService.getSfcSite(orgCode, pkg.getPlantCode());
//        String sfcSite = getSfcSite(orgCode, pkg.getPlantCode());
        WmsWorkOrderHeader wmsWorkOrderHeaderDb = wmsWorkOrderHeaderMapper
                .selectOne(Wrappers.<WmsWorkOrderHeader>lambdaQuery()
                        .eq(WmsWorkOrderHeader::getOrgCode, orgCode)
                        .eq(WmsWorkOrderHeader::getWorkOrderNo, pkg.getWorkOrderNo())
                        .last("limit 1"));
//        String dataSource = dataSourceService.getDataSource(orgCode, wmsWorkOrderHeaderDb.getMrpArea());
        String dataSource = wmsWorkOrderHeaderDb.getMesDataSource();
        String s = sfcStoredProcedureFactory.postingSfcPkgInfo(orgCode, p, pkg.getPlantCode(), dataSource);
        log.info("return to SFC content :{} return :{}", JSONUtil.toJsonStr(p), s);
        return s;
    }

    public void containerDnPostSfc(String orgCode){
        List<DnPostSfcDTO> dnPostSfcDTOList = wmsProductShipHeaderMapper.selectPostSfcDnList(orgCode);
        if (CollUtil.isNotEmpty(dnPostSfcDTOList)) {
            Map<String, List<DnPostSfcDTO>> collect = dnPostSfcDTOList.stream()
                    .collect(Collectors.groupingBy(DnPostSfcDTO::getDn));
            for (Map.Entry<String, List<DnPostSfcDTO>> entry : collect.entrySet()) {
                List<DnPostSfcDTO> postSfcDTOList = entry.getValue();
                DnPostSfcDTO dnPostSfcDTO = postSfcDTOList.get(0);
                Integer id = dnPostSfcDTO.getId();
                DnPostSfcVO dnPostSfcVO = new DnPostSfcVO();
                BeanUtils.copyProperties(dnPostSfcDTO,dnPostSfcVO);
                String result;
                DnPostSfcResponse response;
                try {
                    result = HttpUtil.createPost(globalCommonConfig.getDnPostSfcUrl())
                            .header("Content-Type", "application/json;charset=UTF-8")
                            .setConnectionTimeout(30 * 1000)
                            .body(JSONUtil.toJsonStr(dnPostSfcVO, JSONConfig.create().setIgnoreNullValue(false)))
                            .execute()
                            .body();
                    log.info("dnPostSfc requestJson：{},return：{}",
                            JSONUtil.toJsonStr(dnPostSfcVO), result);
                    response = JSON.parseObject(result, DnPostSfcResponse.class);
                } catch (Exception e) {
                    log.error("dnPostSfc requestJson：{}, ERROR:{}", JSONUtil.toJsonStr(dnPostSfcVO),
                            e.getMessage());
                    wmsProductShipHeaderMapper.update(null, Wrappers.<WmsDocProductShipHeader>lambdaUpdate()
                            .eq(WmsDocProductShipHeader::getId, id)
                            .set(WmsDocProductShipHeader::getToSfcFlag, Boolean.FALSE)
                            .set(WmsDocProductShipHeader::getToSfcMsg, e.getMessage())
                            .set(WmsDocProductShipHeader::getToSfcDt, LocalDateTime.now()));
                    continue;
                }
                if ("SUCCESS".equalsIgnoreCase(response.getFlag())) {
                    wmsProductShipHeaderMapper.update(null, Wrappers.<WmsDocProductShipHeader>lambdaUpdate()
                            .eq(WmsDocProductShipHeader::getId, id)
                            .set(WmsDocProductShipHeader::getToSfcFlag, Boolean.TRUE)
                            .set(WmsDocProductShipHeader::getToSfcMsg, response.getMsg())
                            .set(WmsDocProductShipHeader::getToSfcDt, LocalDateTime.now()));
                }else {
                    wmsProductShipHeaderMapper.update(null, Wrappers.<WmsDocProductShipHeader>lambdaUpdate()
                            .eq(WmsDocProductShipHeader::getId, id)
                            .set(WmsDocProductShipHeader::getToSfcFlag, Boolean.FALSE)
                            .set(WmsDocProductShipHeader::getToSfcMsg, response.getMsg())
                            .set(WmsDocProductShipHeader::getToSfcDt, LocalDateTime.now()));
                }
            }
        }
    }
}
