package com.maxnerva.cloudmes.service.basic.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Data
public class FileUploadVO {
    @ApiModelProperty(
            value = "文件列表",
            required = true
    )
    private List<MultipartFile> files;
    @ApiModelProperty("桶名，不传就默认删除cloudbase桶里")
    private String bucketName;
    @ApiModelProperty("文件类别，来源于字典表FILE_CATEGORY")
    private String fileCategory;

    public FileUploadVO() {
    }
}
