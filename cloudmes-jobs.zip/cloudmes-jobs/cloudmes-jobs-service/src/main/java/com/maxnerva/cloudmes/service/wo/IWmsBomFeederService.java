package com.maxnerva.cloudmes.service.wo;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.entity.wo.WmsBomFeeder;

/**
 * <p>
 * 上料表信息 服务类
 * </p>
 *
 * @author likun
 * @since 2022-08-30
 */
public interface IWmsBomFeederService extends IService<WmsBomFeeder> {

}
