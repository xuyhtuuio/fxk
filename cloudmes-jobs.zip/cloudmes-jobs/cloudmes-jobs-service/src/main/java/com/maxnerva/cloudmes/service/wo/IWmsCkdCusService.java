package com.maxnerva.cloudmes.service.wo;


import com.maxnerva.cloudmes.entity.wo.WmsCkdCus;


import javax.servlet.http.HttpServletResponse;
import java.util.List;

public interface IWmsCkdCusService {

    List<WmsCkdCus> getAndInsertCkdCus(String orgCode, Boolean isBonded, String po, String poItem, Boolean isForce);
}
