package com.maxnerva.cloudmes.service.wh.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
public class RequestAgileTcVO {
    @ApiModelProperty(value = "固定栏位：D/C 過期", required = true)
    private String description;

    @ApiModelProperty(value = "orgCode", required = true)
    private String productLine;

    @ApiModelProperty(value = "计算缺料人工号", required = true)
    private String originator;

    @ApiModelProperty(value = "固定栏位：EPDVI|SUPPLY_CHAIN 配置个字典", required = true)
    private String applicationDepartment;

    @ApiModelProperty(value = "该PKG所对应GR号，多个按分号隔开", required = true)
    private String GRNNo;

    @ApiModelProperty(value = "basic_material.material_category=basic_material_class.id的class_code,多个按分号隔开", required = true)
    private String partName;

    @ApiModelProperty(value = "汇总的pkg数量", required = true)
    private String qty;

    @ApiModelProperty(value = "汇总的pkg的supplierPartNo", required = true)
    private String venderNumber;

    @ApiModelProperty(value = "汇总的pkg的mfgName，多个按分号隔开", required = true)
    private String vender;

    @ApiModelProperty(value = "汇总的pkg的料号，多个按分号隔开", required = true)
    private String HHPN;

    @ApiModelProperty(value = "料号的客户，按照工单的MrpArea找客户", required = true)
    private String usedClient;

    @ApiModelProperty(value = "固定栏位：OTHERS", required = true)
    private String materialType;

    @ApiModelProperty(value = "固定栏位：NO")
    private String OEMCase;

    @ApiModelProperty(value = "成品料號：工单的成品料号")
    private String fitProduction;

    @ApiModelProperty(value = "固定內容：NO", required = true)
    private String applicantDeductionForecast;

    @ApiModelProperty(value = "固定內容：無", required = true)
    private String lastAbnormDes;

    @ApiModelProperty(value = "固定栏位：D/C 過期", required = true)
    private String badType;

    @ApiModelProperty(value = "固定栏位：物料延期（明细见附件）", required = true)
    private String waiveContent;

    @ApiModelProperty(value = "固定內容：上線使用", required = true)
    private String waiveReason;

    @ApiModelProperty(value = "表單創立日期", required = true)
    private String TCStartDate;

    @ApiModelProperty(value = "表單創立日期+30天：待品管确认", required = true)
    private String TCExpirationDate;

    @ApiModelProperty(value = "固定內容：反馈供应商和客户")
    private String correctAction;

    @ApiModelProperty(value = "表單創立日期+30天", required = true)
    private String finishDate;

    @ApiModelProperty(value = "文件")
    private List<RequestAgileTcFileVO> files;

    @ApiModelProperty(value = "是否3年内 Y/N")
    private String withinThreeYears;
}
