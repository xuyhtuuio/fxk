package com.maxnerva.cloudmes.mapper.wo;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.wo.WmsPkgBurnInfo;

/**
 *  表数据库访问层
 *
 * @author hgx
 * @since 2023-07-28
 */
public interface WmsPkgBurnInfoMapper extends BaseMapper<WmsPkgBurnInfo>{


}

