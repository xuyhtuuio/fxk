package com.maxnerva.cloudmes.entity.qms;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 从qms同步msd等级表
 * </p>
 *
 * @author likun
 * @since 2024-11-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsSyncMsdLevelFromQmsLog对象", description="从qms同步msd等级表")
public class WmsSyncMsdLevelFromQmsLog extends BaseEntity<WmsSyncMsdLevelFromQmsLog> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "组织")
    private String orgCode;

    @ApiModelProperty(value = "厂商")
    private String mfg;

    @ApiModelProperty(value = "厂商料号")
    private String mfgMaterialCode;

    @ApiModelProperty(value = "制造商版次")
    private String mfgMaterialVersion;

    @ApiModelProperty(value = "level等级")
    private String msdLevel;
}
