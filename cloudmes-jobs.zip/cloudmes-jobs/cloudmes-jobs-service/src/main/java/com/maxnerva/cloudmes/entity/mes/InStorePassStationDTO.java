package com.maxnerva.cloudmes.entity.mes;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel("WMS成品入库过站参数")
public class InStorePassStationDTO implements Serializable {

    @ApiModelProperty("员工名称")
    private String userName;

    @ApiModelProperty("线体")
    private String line;

    @ApiModelProperty("")
    private String section;

    @ApiModelProperty("")
    private String wStation;

    @ApiModelProperty("不良代码")
    private String badCode;

    @ApiModelProperty("产品SN")
    private String sn;

    @ApiModelProperty("产品SN")
    private String myGroup;

    @ApiModelProperty("所属BUG")
    private String orgCode;

}
