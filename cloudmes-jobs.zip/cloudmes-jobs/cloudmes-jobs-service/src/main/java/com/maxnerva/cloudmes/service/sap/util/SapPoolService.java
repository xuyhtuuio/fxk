package com.maxnerva.cloudmes.service.sap.util;

import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Properties;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/01/04 17:31
 * @Version: 1.0
 */
public interface SapPoolService {

    /**
     * 获取SAP pool interface
     *
     * @return
     */
    JCoDestination getSapPool(String clientId);

    /**
     * 生成 SAP file
     *
     * @param client
     * @param connectProperties
     * @return
     */
    default JCoDestination generateSapPool(String client, Properties connectProperties) {
        File cfg = new File(client + ".jcoDestination");
        if (!cfg.exists()) {
            try {
                FileOutputStream fos = new FileOutputStream(cfg, false);
                connectProperties.store(fos, "for tests only !");
                fos.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        JCoDestination destination = null;
        try {
            destination = JCoDestinationManager.getDestination(client);
        } catch (JCoException e) {
            e.printStackTrace();
        }
        return destination;
    }
}
