package com.maxnerva.cloudmes.entity.doc;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
public class ScCheckPartNoDTO {
    @ApiModelProperty(value = "厂商料号")
    private String vendorPartNumber;

    @ApiModelProperty(value = "料号")
    private String hhpn;

    @ApiModelProperty(value = "版次")
    private String version;

    @ApiModelProperty(value = "LOT")
    private List<String> lotCodes;
}
