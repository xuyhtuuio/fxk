package com.maxnerva.cloudmes.entity.basic;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 同步basic产品bom表
 * </p>
 *
 * @author likun
 * @since 2024-12-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsBasicProductBom对象", description="同步basic产品bom表")
public class WmsBasicProductBom extends BaseEntity<WmsBasicProductBom> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "项次")
    private String item;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "零件料号")
    private String materialNo;

    @ApiModelProperty(value = "单位")
    private String uom;

    @ApiModelProperty(value = "主/替料")
    private String alternative;

    @ApiModelProperty(value = "物料群组")
    private String altgroup;

    @ApiModelProperty(value = "优先级")
    private String priority;

    @ApiModelProperty(value = "位置")
    private String location;

    @ApiModelProperty(value = "备注")
    private String bomnotes;

    @ApiModelProperty(value = "主料料号")
    private String priMaterial;

    @ApiModelProperty(value = "产品料号")
    private String productNo;

    @ApiModelProperty(value = "基本用量")
    private Integer basicQty;

    @ApiModelProperty(value = "ECN变更单号")
    private String ecnumber;

    @ApiModelProperty(value = "产品分类")
    private String productType;

    @ApiModelProperty(value = "工厂组织")
    private String orgCode;

    @ApiModelProperty(value = "是否删除")
    private Boolean isDeleted;

    @ApiModelProperty(value = "sap工廠code")
    private String plantCode;

    @ApiModelProperty(value = "混用标记")
    private String mixFlag;


}
