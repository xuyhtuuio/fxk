package com.maxnerva.cloudmes.entity.trading;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 内交配置表
 * @TableName wms_trading_config
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class WmsTradingConfig extends BaseEntity<WmsTradingConfig> {

    /**
     * 主键id
     */
    @ApiModelProperty(value = "主键id")
    private Integer id;

    /**
     * 来源BU;
     */
    @ApiModelProperty(value = "来源BU")
    private String fromOrgCode;

    /**
     * 内交工厂
     */
    @ApiModelProperty(value = "内交工厂")
    private String fromPlantCode;

    /**
     * sap来源集团号
     */
    @ApiModelProperty(value = "sap来源集团号")
    private String fromSapClientId;

    /**
     * 內交代码
     */
    @ApiModelProperty(value = "內交代码")
    private String tradingFromCode;

    /**
     * 对应內交出代码
     */
    @ApiModelProperty(value = "对应內交出代码")
    private String tradingToCode;

    /**
     * 对应內交BU
     */
    @ApiModelProperty(value = "对应內交BU")
    private String tradingToOrgCode;

    /**
     * sap目标集团号
     */
    @ApiModelProperty(value = "sap目标集团号")
    private String toSapClientId;

    /**
     * 类型
     */
    @ApiModelProperty(value = "类型")
    private String deliveryType;

    /**
     * 配销通路
     */
    @ApiModelProperty(value = "配销通路")
    private String salesChain;

    /**
     * 产品部
     */
    @ApiModelProperty(value = "产品部")
    private String productDepartment;

    /**
     * 内交入工厂
     */
    @ApiModelProperty(value = "内交入工厂")
    private String toPlantCode;

    @ApiModelProperty(value = "法人")
    private String salesOrg;
}