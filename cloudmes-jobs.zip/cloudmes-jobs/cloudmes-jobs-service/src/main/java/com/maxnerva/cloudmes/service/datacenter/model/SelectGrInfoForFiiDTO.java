package com.maxnerva.cloudmes.service.datacenter.model;

import cn.hutool.core.annotation.Alias;
import cn.hutool.core.annotation.PropIgnore;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class SelectGrInfoForFiiDTO {
    @ApiModelProperty(value = "Site")
    private String site;

    @ApiModelProperty(value = "BU")
    @Alias(value = "business_unit_name")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    @Alias(value = "plant_code")
    private String plantCode;

    @ApiModelProperty(value = "客户")
    @Alias(value = "mrp_area")
    private String mrpArea;

    @ApiModelProperty(value = "仓码")
    @Alias(value = "sap_warehouse_code")
    private String sapWarehouseCode;


    @ApiModelProperty(value = "GR")
    private String gr;

    @ApiModelProperty(value = "PO")
    private String po;

    @ApiModelProperty(value = "PO项次")
    @Alias(value = "po_item")
    private String poItem;

    @ApiModelProperty(value = "料号")
    private String hhpn;

    @ApiModelProperty(value = "厂商料号")
    @Alias(value = "mfg_pn")
    private String mfgPn;

    @ApiModelProperty(value = "厂商名")
    @Alias(value = "mfg_name")
    private String mfgName;

    @ApiModelProperty(value = "原产国")
    private String origin;

    @ApiModelProperty(value = "GR时间")
    @Alias(value = "gr_time")
    private LocalDateTime grTime;

    @ApiModelProperty(value = "GR数量(查询数量)")
    @PropIgnore
    private BigDecimal qty;

    @ApiModelProperty(value = "GR数量")
    @Alias(value = "gr_qty")
    private String grQty;

    @ApiModelProperty("最近一次维护人")
    @Alias(value = "last_edit_by")
    private String lastEditBy;

    @ApiModelProperty("最近一次维护时间")
    @Alias(value = "last_edit_dt")
    private LocalDateTime lastEditDt;

    @ApiModelProperty("最近一次维护时间 0时区")
    @Alias(value = "last_edit_dt_utc")
    private LocalDateTime lastEditDtUtc;

    @ApiModelProperty("时区 utc+8 填8 utc-1 填-1")
    @Alias(value = "utc_zone")
    private String utcZone;

    @ApiModelProperty(value = "写入资料系统")
    @Alias(value = "add_user")
    private String addUser;

    @ApiModelProperty(value = "写入资料时间")
    @Alias(value = "add_date")
    private LocalDateTime addDate;

    @ApiModelProperty(value = "写入资料时间UTC+0")
    @Alias(value = "add_date_utc")
    private LocalDateTime addDateUtc;

    @ApiModelProperty(value = "新增/刪除(N/D)")
    @Alias(value = "data_status")
    private String dataStatus;

    @ApiModelProperty(value = "GR备注")
    @Alias(value = "gr_remark")
    private String grRemark;

    @ApiModelProperty(value = "PO备注")
    @Alias(value = "po_remark")
    private String poRemark;

    public String getGrQty(){
        return StrUtil.emptyIfNull(qty.stripTrailingZeros().toPlainString());
    }

    public String getMrpArea() {
        return StrUtil.emptyIfNull(mrpArea);
    }

    public String getSapWarehouseCode() {
        return StrUtil.emptyIfNull(sapWarehouseCode);
    }

    public String getGr() {
        return StrUtil.emptyIfNull(gr);
    }

    public String getPo() {
        return StrUtil.emptyIfNull(po);
    }

    public String getPoItem() {
        return StrUtil.emptyIfNull(poItem);
    }

    public String getHhpn() {
        return StrUtil.emptyIfNull(hhpn);
    }

    public String getMfgPn() {
        return StrUtil.emptyIfNull(mfgPn);
    }

    public String getMfgName() {
        return StrUtil.emptyIfNull(mfgName);
    }

    public String getOrigin() {
        return StrUtil.emptyIfNull(origin);
    }

    public String getLastEditBy() {
        return StrUtil.emptyIfNull(lastEditBy);
    }

    public String getGrRemark() {
        return StrUtil.emptyIfNull(grRemark);
    }

    public String getPoRemark() {
        return StrUtil.emptyIfNull(poRemark);
    }
}
