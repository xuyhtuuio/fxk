package com.maxnerva.cloudmes.entity.wo;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import lombok.Data;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 捡料记录表(WmsWorkOrderPickLog)实体类
 *
 * @author hgx
 * @since 2023-09-15
 */
@Data
@ApiModel("WmsWorkOrderPickLog实体类")
public class WmsWorkOrderPickLog {

    /**
     * 主键id
     */
    @ApiModelProperty("主键id")
    private Integer id;
    /**
     * pkg
     */
    @ApiModelProperty("pkg")
    private String pkgId;
    /**
     * 父pkg
     */
    @ApiModelProperty("父pkg")
    private String parentPkgId;
    /**
     * BU（业务单元）
     */
    @ApiModelProperty("BU（业务单元）")
    private String orgCode;
    /**
     * 工厂
     */
    @ApiModelProperty("工厂")
    private String plantCode;
    /**
     * 来源仓码
     */
    @ApiModelProperty("来源仓码")
    private String fromWarehouseCode;
    /**
     * 目标仓码
     */
    @ApiModelProperty("目标仓码")
    private String toWarehouseCode;
    /**
     * 鸿海料号
     */
    @ApiModelProperty("鸿海料号")
    private String partNo;
    /**
     * 原始数量
     */
    @ApiModelProperty("原始数量")
    private BigDecimal originalQty;
    /**
     * 当前数量
     */
    @ApiModelProperty("当前数量")
    private BigDecimal currentQty;
    /**
     * 异动数量
     */
    @ApiModelProperty("异动数量")
    private BigDecimal transactionQty;
    /**
     * 供应商料号
     */
    @ApiModelProperty("供应商料号")
    private String supplierPartNo;
    /**
     * 制造商料号
     */
    @ApiModelProperty("制造商料号")
    private String mfgPartNo;
    /**
     * 制造商名称
     */
    @ApiModelProperty("制造商名称")
    private String mfgName;
    /**
     * 解析datecode
     */
    @ApiModelProperty("解析datecode")
    private LocalDate dateCode;
    /**
     * 原始datecode
     */
    @ApiModelProperty("原始datecode")
    private String originalDateCode;
    /**
     * 批次号
     */
    @ApiModelProperty("批次号")
    private String lotCode;
    /**
     * 锁定状态
     */
    @ApiModelProperty("锁定状态")
    private String lockStatus;
    /**
     * 锁定时间
     */
    @ApiModelProperty("锁定时间")
    private LocalDateTime lockDate;
    /**
     * lock原因
     */
    @ApiModelProperty("lock原因")
    private String lockMessage;
    /**
     * 原产国1
     */
    @ApiModelProperty("原产国1")
    private String placeOfOrigin1;
    /**
     * 工单号
     */
    @ApiModelProperty("工单号")
    private String workOrderNo;
    /**
     * 工单群组
     */
    @ApiModelProperty("工单群组")
    private String workOrderItem;
    /**
     * 制程分类
     */
    @ApiModelProperty("制程分类")
    private String materialProductProcess;
    /**
     * 制程类型
     */
    @ApiModelProperty("制程类型")
    private String materialProductType;
    /**
     * 是否为烧录物料 默认false
     */
    @ApiModelProperty("是否为烧录物料 默认false")
    private Boolean isBurn;
    /**
     * 计划烧录值
     */
    @ApiModelProperty("计划烧录值")
    private String planBurnValue;
    /**
     * 烧录值
     */
    @ApiModelProperty("烧录值")
    private String burnValue;
    /**
     * 是否合盘物料 N:不是，Y:是
     */
    @ApiModelProperty("是否合盘物料 N:不是，Y:是")
    private String mergeFlag;
    /**
     * N:不是剪角物料，Y:剪角物料
     */
    @ApiModelProperty("N:不是剪角物料，Y:剪角物料")
    private String cutOffFlag;
    /**
     * 物料类型（A/B/C)
     */
    @ApiModelProperty("物料类型（A/B/C)")
    private String materialType;
    /**
     * 是否前加工 默认否
     */
    @ApiModelProperty("是否前加工 默认否")
    private Boolean isPreWork;
    /**
     * 前加工类型
     */
    @ApiModelProperty("前加工类型")
    private String preProcessType;
    /**
     * 前加工是否完成标识 默认否
     */
    @ApiModelProperty("前加工是否完成标识 默认否")
    private Boolean isPreWoFinished;
    /**
     * 备料标识 默认0-未备料 1-已备料
     */
    @ApiModelProperty("备料标识 默认0-未备料 1-已备料")
    private String prepareWoFlag;
    /**
     * 捡料下架标识 默认0-未下架 1-已下架
     */
    @ApiModelProperty("捡料下架标识 默认0-未下架 1-已下架")
    private String pickUnShelfFlag;
    /**
     * 异动类型编码，参考字典
     */
    @ApiModelProperty("异动类型编码，参考字典")
    private String transactionType;
    /**
     * 异动类型字典值
     */
    @ApiModelProperty("异动类型字典值")
    private String transactionMessage;
    /**
     * 异动类型单号
     */
    @ApiModelProperty("异动类型单号")
    private String transactionNumber;
    /**
     * 有效日期
     */
    @ApiModelProperty("有效日期")
    private Integer effectiveDate;
    /**
     * 有效期截止时间
     */
    @ApiModelProperty("有效期截止时间")
    private LocalDate endDate;
    /**
     * 载具编码
     */
    @ApiModelProperty("载具编码")
    private String vehicleCode;
    /**
     * 载具编码
     */
    @ApiModelProperty("载具编码")
    private String binCode;
    /**
     * 捡料人
     */
    @ApiModelProperty("捡料人")
    private String materialPicker;
    /**
     * 捡料时间
     */
    @ApiModelProperty("捡料时间")
    private LocalDateTime pickingTime;
    /**
     * 分料人
     */
    @ApiModelProperty("分料人")
    private String materialDistributor;
    /**
     * 分料时间
     */
    @ApiModelProperty("分料时间")
    private LocalDateTime materialDistributionTime;
    /**
     * 转料人
     */
    @ApiModelProperty("转料人")
    private String transferPerson;
    /**
     * 转料时间
     */
    @ApiModelProperty("转料时间")
    private LocalDateTime transferTime;
    /**
     * 工单绑定位置
     */
    @ApiModelProperty("工单绑定位置")
    private String workOrderToLocation;
    /**
     * 上料表工单群组
     */
    @ApiModelProperty("上料表工单群组")
    private String feederWorkOrderItem;
    /**
     * 轨道号
     */
    @ApiModelProperty("轨道号")
    private String feederNo;
    /**
     * 机台编号
     */
    @ApiModelProperty("机台编号")
    private String machineCode;
    /**
     * 成品料号
     */
    @ApiModelProperty("成品料号")
    private String productPartNo;
    /**
     * 线别
     */
    @ApiModelProperty("线别")
    private String lineNo;
    /**
     * 创建人
     */
    @ApiModelProperty("创建人")
    private String creator;
    /**
     * 创建人员工id，冗余字段
     */
    @ApiModelProperty("创建人员工id，冗余字段")
    private Integer creatorId;
    /**
     * 创建时间
     */
    @ApiModelProperty("创建时间")
    private LocalDateTime createdDt;
    /**
     * 修改人
     */
    @ApiModelProperty("修改人")
    private String lastEditor;
    /**
     * 修改人员工id，冗余字段
     */
    @ApiModelProperty("修改人员工id，冗余字段")
    private Integer lastEditorId;
    /**
     * 修改时间
     */
    @ApiModelProperty("修改时间")
    private LocalDateTime lastEditedDt;
    /**
     * 分料分盘标识  0-不需要分盘  1-需要分盘  2-已分盘完成
     */
    @ApiModelProperty("分料分盘标识  0-不需要分盘  1-需要分盘  2-已分盘完成")
    private String partitionFlag;
    /**
     * 能否烧录标识 否-N 能-Y
     */
    @ApiModelProperty("能否烧录标识 否-N 能-Y")
    private String burnFlag;
    /**
     * 烧录数量
     */
    @ApiModelProperty("烧录数量")
    private BigDecimal burnQty;
    /**
     * 烧录分盘标识  0-不需要分盘  1-需要分盘  2-已分盘完成
     */
    @ApiModelProperty("烧录分盘标识  0-不需要分盘  1-需要分盘  2-已分盘完成")
    private String burnPartitionFlag;
    /**
     * 分料量,工单分料用
     */
    @ApiModelProperty("分料量,工单分料用")
    private BigDecimal distributeQty;
    /**
     * 捡料类型，默认WAREHOUSE
     */
    @ApiModelProperty("捡料类型，默认WAREHOUSE")
    private String pickType;
    /**
     * 客供料类型,默认N--非客供料 Y-客供料
     */
    @ApiModelProperty("客供料类型,默认N--非客供料 Y-客供料")
    private String buySellType;
    /**
     * 同步msd标识
     */
    @ApiModelProperty("同步msd标识")
    private Integer postMsdFlag;
    /**
     * 同步msd信息描述
     */
    @ApiModelProperty("同步msd信息描述")
    private String postMsdMsg;
    /**
     * 同步msd时间
     */
    @ApiModelProperty("同步msd时间")
    private LocalDateTime postMsdDateTime;
}

