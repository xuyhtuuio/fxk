package com.maxnerva.cloudmes.service.wo.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Author hgx
 * @Description 工单烧录DTO
 * @Date 2023/6/6
 */
@ApiModel("工单烧录DTO")
@Data
public class BurnInfoNewDTO {

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("成品料号")
    private String finishedProductPartNo;

    @ApiModelProperty("洪海料号")
    private String partNo;

    @ApiModelProperty("制造商料号")
    private String mfgPartNo;

    @ApiModelProperty("烧录后的物料鸿海料号")
    private String burnedPartNo;

    @ApiModelProperty("烧录值")
    private String burnValue;
}
