package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.TableId;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;


/**
 * <p>
 * SAP仓码属性维护表
 * </p>
 *
 * @author caijun
 * @since 2022-08-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value = "WmsSapWarehouseCode对象", description = "SAP仓码属性维护表")
public class WmsSapWarehouseCode extends BaseEntity<WmsSapWarehouseCode> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    @TableId
    private Integer id;

    @ApiModelProperty(value = "SAP工厂")
    private String plantCode;

    @ApiModelProperty(value = "SAP仓码")
    private String warehouseCode;

    @ApiModelProperty(value = "仓码名称")
    private String warehouseName;

    @ApiModelProperty(value = "库位")
    private String location;

    @ApiModelProperty(value = "是否允许合备(false-否 true-是)，默认false")
    private Boolean isCombine;

    @ApiModelProperty(value = "是否启用(false-否 true-是)，默认false")
    private Boolean isEnable;

    @ApiModelProperty(value = "引用wms_sap_plant表org_code")
    private Integer sapPlantId;

    @ApiModelProperty(value = "工厂组织")
    private String orgCode;

    @ApiModelProperty(value = "成本属性")
    private String costType;

    @ApiModelProperty(value = "保税属性")
    private String bondedType;

    @ApiModelProperty(value = "责任部门")
    private String ownerDept;

    @ApiModelProperty(value = "客户")
    private String mrpArea;

}
