package com.maxnerva.cloudmes.mapper.basic;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.basic.WmsPostingScheduleSettingEntity;

/**
 * <p>
 * WMS过账时间段设置 Mapper 接口
 * </p>
 *
 * @author Chao Zhang
 * @since 2022-11-29
 */
public interface WmsPostingScheduleSettingMapper extends BaseMapper<WmsPostingScheduleSettingEntity> {

}
