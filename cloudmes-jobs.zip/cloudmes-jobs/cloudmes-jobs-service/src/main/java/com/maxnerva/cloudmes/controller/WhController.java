package com.maxnerva.cloudmes.controller;

import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.common.response.ResultCodeEnum;
import com.maxnerva.cloudmes.entity.R;
import com.maxnerva.cloudmes.entity.WmsSapPlant;
import com.maxnerva.cloudmes.mapper.WmsSapPlantMapper;
import com.maxnerva.cloudmes.service.sap.material.MaterialRfcService;
import com.maxnerva.cloudmes.service.sap.material.model.MaterialInfoDto;
import com.maxnerva.cloudmes.service.sfc.SfcStoredProcedureFactory;
import com.sap.conn.jco.JCoException;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/07/13 14:31
 * @Version: 1.0
 */
@Api(tags = "SFC接口")
@Slf4j
@RestController
@RequestMapping("/wh")
public class WhController {

    @Autowired
    SfcStoredProcedureFactory sfcStoredProcedureFactory;

    @Autowired
    MaterialRfcService materialRfcService;

    @Autowired
    WmsSapPlantMapper wmsSapPlantMapper;


    @GetMapping("/doGetMaterialInfo")
    public R<String> doGetMaterialInfo(@RequestParam("sapClient") String sapClient,
                                       @RequestParam("plantCode") String plantCode) throws JCoException {
        List<MaterialInfoDto> materialInfoDtos = materialRfcService.doGetMaterialInfo(sapClient, plantCode, null, null, null);
        return R.ok(ResultCodeEnum.SUCCESS.getCode(), ResultCodeEnum.SUCCESS.getMessage(),
                JSONUtil.toJsonStr(materialInfoDtos));
    }
}
