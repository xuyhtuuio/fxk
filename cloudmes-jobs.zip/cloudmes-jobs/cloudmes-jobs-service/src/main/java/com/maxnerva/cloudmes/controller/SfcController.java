package com.maxnerva.cloudmes.controller;

import cn.hutool.core.util.StrUtil;
import com.maxnerva.cloudmes.entity.R;
import com.maxnerva.cloudmes.entity.mes.PassSnStationVO;
import com.maxnerva.cloudmes.service.sap.trading.TradingRfcService;
import com.maxnerva.cloudmes.service.sap.trading.model.GenerateTradingNumberDto;
import com.maxnerva.cloudmes.service.sfc.PostingSfcService;
import com.maxnerva.cloudmes.service.sfc.SfcStoredProcedureFactory;
import com.maxnerva.cloudmes.service.sfc.model.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/07/13 14:31
 * @Version: 1.0
 */
@Api(tags = "SFC接口")
@Slf4j
@RestController
@RequestMapping("/sfc")
public class SfcController {

    @Autowired
    SfcStoredProcedureFactory sfcStoredProcedureFactory;

    @Autowired
    PostingSfcService postingSfcService;

    @Autowired
    TradingRfcService tradingRfcService;


    @ApiOperation("取PKG状态值")
    @GetMapping("/getPkgStatusInfo")
    public PkgStatusInfoDto getPkgStatusInfo(@RequestParam(value = "orgCode") String orgCode,
                                             @RequestParam(value = "pkgId") String pkgId,
                                             @RequestParam(value = "remainQty") String remainQty,
                                             @RequestParam(value = "plantCode", required = false) String plantCode,
                                             @RequestParam(value = "dataSource") String dataSource) {

        PkgStatusInfoDto pkgStatusInfoDto = new PkgStatusInfoDto();
        pkgStatusInfoDto.setPkgId(pkgId);
        pkgStatusInfoDto.setRemainQty(remainQty);
        PkgStatusInfoDto pkgStatusInfo = sfcStoredProcedureFactory.getPkgStatusInfo(orgCode, pkgStatusInfoDto,
                plantCode, dataSource);
        return pkgStatusInfo;
    }


    @ApiOperation("回写DN、SN的绑定关系")
    @GetMapping("/sendSnDnRelationshipToSfc")
    public String sendSnDnRelationshipToSfc(@RequestParam(value = "orgCode") String orgCode,
                                            @RequestParam(value = "dataSource") String dataSource,
                                            @RequestParam(value = "snDnRelationshipDto") SnDnRelationshipDto snDnRelationshipDto,
                                            @RequestParam(value = "plantCode", required = false) String plantCode) {

        String s = sfcStoredProcedureFactory.sendSnDnRelationshipToSfc(orgCode, "", dataSource, plantCode, snDnRelationshipDto);
        return s;
    }


    @ApiOperation("取成品入库栈板信息")
    @GetMapping("/getSfcPalletInfo")
    public R<List<SfcPalletInfoDto>> getSfcPalletInfo(@RequestParam(value = "orgCode") String orgCode,
                                                      @RequestParam(value = "barcode") String barcode,
                                                      @RequestParam(value = "dataSource") String dataSource) {
        try {
            List<SfcPalletInfoDto> palletInfo = sfcStoredProcedureFactory.getSfcPalletInfo(orgCode, barcode, StrUtil.EMPTY, dataSource);
            return R.ok(palletInfo);
        } catch (Exception e) {
            log.error("sfc getSfcPalletInfo error:{}", e.getMessage(), e);
            return R.no(e.getMessage());
        }
    }

    @ApiOperation("查询新旧条码关系")
    @GetMapping("/getPkgRelation")
    public List<SfcPkgRelationDto> getPkgRelation(@RequestParam(value = "orgCode") String orgCode,
                                                  @RequestParam(value = "pkgId") String pkgId) {

        List<SfcPkgRelationDto> sfcPkgRelationDtoList = postingSfcService.getPkgRelation(orgCode, pkgId);
        return sfcPkgRelationDtoList;
    }

    @ApiOperation("WMS退料时调用此接口, 需要清除零数盘的丝印,LCR状态 及物料下线(SMT,PTH)")
    @GetMapping("/clearPkgStatusToSfc")
    public String clearPkgStatusToSfc(@RequestParam(value = "orgCode") String orgCode,
                                      @RequestParam(value = "pkgId") String pkgId,
                                      @RequestParam(value = "currentQty") String currentQty,
                                      @RequestParam(value = "plantCode", required = false) String plantCode,
                                      @RequestParam(value = "dataSource") String dataSource) {

        String s = sfcStoredProcedureFactory.clearPkgStatusToSfc(orgCode, pkgId, currentQty, plantCode, dataSource);
        return s;
    }

    @ApiOperation("退料上架将工单备料PKG信息抛SFC")
    @GetMapping("/postingReturnWoPreparePkgInfoToSFC")
    public String postingReturnWoPreparePkgInfoToSfC(@RequestParam(value = "orgCode") String orgCode,
                                                     @RequestParam(value = "id") String id,
                                                     @RequestParam(value = "remainQty", required = false)
                                                     String remainQty) {

        String s = postingSfcService.postingReturnWoPreparePkgInfoToSfC(orgCode, id, remainQty);
        return s;
    }

    /**
     * 查询工单信息
     */
    @ApiOperation("根据SN取SFC信息")
    @GetMapping("/getSfcWoInfo")
    public R<SfcWoDto> getSfcWoInfo(@RequestParam("dataSorce") String dataSorce,
                                    @RequestParam("orgCode") String orgCode,
                                    @RequestParam("sn") String sn) {
        try {
            return R.ok(sfcStoredProcedureFactory.getSfcWoInfo(dataSorce, orgCode, sn));
        } catch (Exception e) {
            return R.no(e.getMessage());
        }
    }

    /**
     * 根据不良代码获取不良原因
     */
    @ApiOperation("根据根据不良代码获取不良原因")
    @GetMapping(value = "/getSfcErrorDesc", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public R<String> getSfcErrorDesc(@RequestParam("orgCode") String orgCode,
                                     @RequestParam("dataSource") String dataSource,
                                     @RequestParam("errorCode") String errorCode,
                                     @RequestParam(value = "plantCode", required = false) String plantCode) {
        try {
            return R.ok(200, "OK", sfcStoredProcedureFactory.getSfcErrorDesc(orgCode, plantCode, dataSource, errorCode));
        }catch (Exception e) {
            return R.no(e.getMessage());
        }

    }

    /**
     * 抛PKG info资料给SFC
     */
    @ApiOperation("抛PKG info资料给SFC")
    @PostMapping("/postingSfcPkgInfo")
    public String postingSfcPkgInfo(@RequestBody PostingSfcPkgInfoDto postingSfcPkgInfoDto) {
        String orgCode = postingSfcPkgInfoDto.getOrgCode();
        PostPkgInfoToSfcDto postPkgInfoToSfcDto = postingSfcPkgInfoDto.getPostPkgInfoToSfcDto();
        return sfcStoredProcedureFactory.postingSfcPkgInfo(orgCode, postPkgInfoToSfcDto,
                postPkgInfoToSfcDto.getPlantCode(), postPkgInfoToSfcDto.getDataSource());
    }

    @ApiOperation("根据cartonNo取SFC信息")
    @GetMapping("/getSfcCartonInfoByCartonNo")
    public List<SfcCartonInfoDTO> getSfcPalletInfoByCartonNo(@RequestParam("orgCode") String orgCode,
                                                             @RequestParam("cartonNo") String cartonNo,
                                                             @RequestParam(value = "plantCode", required = false) String plantCode,
                                                             @RequestParam(value = "dataSource") String dataSource) {
        return sfcStoredProcedureFactory.getSfcPalletInfoByCartonNo(orgCode, cartonNo, plantCode, dataSource);
    }

    @ApiOperation("报废入库根据PKGID获取单号")
    @GetMapping("/getWoNoByPkgId")
    public String getWoNoByPkgId(@RequestParam("orgCode") String orgCode,
                                 @RequestParam("plantCode") String plantCode,
                                 @RequestParam("pkgId") String pkgId,
                                 @RequestParam("dataSource") String dataSource) {
        return sfcStoredProcedureFactory.getWoNoByPkgId(orgCode, plantCode, pkgId, dataSource);
    }

    @Deprecated
    @ApiOperation("查询SN扩展信息")
    @GetMapping("/selectSfcExtendInfoBySn")
    public Map selectSfcExtendInfoBySn(@RequestParam("orgCode") String orgCode,
                                       @RequestParam("plantCode") String plantCode,
                                       @RequestParam("sn") String sn) {
        String sfcSite = orgCode + "_" + plantCode;
        return sfcStoredProcedureFactory.getSfcExtendInfoBySn(sfcSite, sn);
    }

    @ApiOperation("产生内交单号")
    @PostMapping("/doGenerateTradingNumber")
    public R<String> doGenerateTradingNumber(@RequestBody GenerateTradingNumberDto generateTradingNumberDto) {
        String sapClient = generateTradingNumberDto.getSapClient();
        String orgCode = generateTradingNumberDto.getOrgCode();
        try {
            //只有EPDVI走新的过账方法
            if ("EPDVI".equals(orgCode)) {
                return R.ok("成功", tradingRfcService.doGenerateTradingNumber2(sapClient, generateTradingNumberDto));
            } else {
                return R.ok("成功", tradingRfcService.doGenerateTradingNumber(sapClient, generateTradingNumberDto));
            }
        } catch (Exception e) {
            return R.no(e.getMessage());
        }
    }

    @ApiOperation("内交PGI")
    @GetMapping("/doPgi")
    public R<String> doPgi(@RequestParam(value = "sapClient") String sapClient,
                           @RequestParam(value = "tradingNumber") String tradingNumber) {
        try {
            return R.ok(200, "成功", tradingRfcService.doPgi(sapClient, tradingNumber));
        } catch (Exception e) {
            return R.no(e.getMessage());
        }
    }

    /**
     * 成品出货完成抛SFC
     */
    @ApiOperation("成品出货完成抛SFC")
    @GetMapping("/productShipCompletedToSfc")
    public R<Void> productShipCompletedToSfc(@RequestParam("orgCode") String orgCode,
                                             @RequestParam("docNo") String docNo,
                                             @RequestParam("cartonNo") String cartonNo) {
        try {
            postingSfcService.productShipCompletedToSfc(orgCode, docNo, cartonNo);
            return R.ok();
        } catch (Exception e) {
            return R.no(e.getMessage());
        }
    }

    /**
     * 查询E1T1烧录值
     */
    @ApiOperation("查询E1T1烧录值")
    @GetMapping("/getSFCBurnValue")
    @Deprecated
    public R<List<SfcBurnValueDto>> getSFCBurnValue(@RequestParam("sfcSite") String sfcSite,
                                                    @RequestParam("productPartNo") String productPartNo) {
        try {
            return R.ok(sfcStoredProcedureFactory.getSFCBurnValue(sfcSite, productPartNo));
        } catch (Exception e) {
            return R.no(e.getMessage());
        }
    }

    @ApiOperation("查询SFC是否存在PKGID")
    @GetMapping("/getSFCPkgId")
    public R<List<String>> getSFCPkgId(@RequestParam("orgCode") String orgCode,
                                       @RequestParam("plantCode") String plantCode,
                                       @RequestParam(value = "dataSorce", required = false) String dataSorce,
                                       @RequestParam("pkgId") String pkgId) {
        try {
            return R.ok(sfcStoredProcedureFactory.getSFCPkgId(orgCode, dataSorce, pkgId, plantCode));
        } catch (Exception e) {
            return R.no(e.getMessage());
        }
    }

    @ApiOperation("入库sn实时过站")
    @PostMapping("/passSnStation")
    public String passSnStation(@RequestBody PassSnStationVO passSnStationVO) {
        String orgCode = passSnStationVO.getOrgCode();
        String plantCode = passSnStationVO.getPlantCode();
        String dataSource = passSnStationVO.getDataSource();
        WarehousingPassSnStationDto warehousingPassSnStationDto = new WarehousingPassSnStationDto();
        warehousingPassSnStationDto.setUserName("WMS");
        warehousingPassSnStationDto.setLine("");
        warehousingPassSnStationDto.setSection("INSTORE");
        warehousingPassSnStationDto.setWStation("INSTORE");
        warehousingPassSnStationDto.setBadCode("N/A");
        warehousingPassSnStationDto.setMyGroup("INSTORE");
        warehousingPassSnStationDto.setRes("");
        warehousingPassSnStationDto.setSn(passSnStationVO.getSn());
        return sfcStoredProcedureFactory.warehousingPassSnStation(orgCode, warehousingPassSnStationDto,
                plantCode, dataSource);
    }

    @GetMapping("/dnPostSfc")
    @ApiOperation("dn抛SFC")
    public R<Void> containerDnPostSfc(@RequestParam String orgCode){
        postingSfcService.containerDnPostSfc(orgCode);
        return R.ok();
    }
}
