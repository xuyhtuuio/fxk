package com.maxnerva.cloudmes.service.mes.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @ClassName InStorageWoInfo
 * @Description 入库工单信息dto
 * @Author Likun
 * @Date 2022/11/16
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("入库工单信息dto")
@Data
public class InStorageWoDTO {

    @ApiModelProperty("入库工单号")
    private String workOrderNo;

    @ApiModelProperty("入库数量")
    private BigDecimal inBoundQty;
}
