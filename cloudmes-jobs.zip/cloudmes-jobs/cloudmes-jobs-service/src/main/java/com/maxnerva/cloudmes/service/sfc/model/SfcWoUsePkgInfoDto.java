package com.maxnerva.cloudmes.service.sfc.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/09/20 08:49
 * @Version: 1.0
 */
@Data
public class SfcWoUsePkgInfoDto implements Serializable {

    //成品料号     pkgid鸿海料号  使用线别  供应商    DC               LC,   制造商料号  PKGID,   上线时间
    //product_no,key_part_no,line_name,vendor,date_code,lot_no,mfg_pn,pkg_id,work_time

    private static final long serialVersionUID = 1L;
    //成品料号
    private String productNo;
    //成品料号
    private String keyPartNo;
    //使用线别
    private String lineName;
    //供应商
    private String vendor;
    //DC
    private String dateCode;
    //LC
    private String lotNo;
    //制造商料号
    private String mfgPn;
    //PKGID
    private String PKGID;
    //上线时间
    private String workTime;

}
