package com.maxnerva.cloudmes.entity.jusda;

import com.maxnerva.cloudmes.entity.BaseCommonEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


@Data
@ApiModel("JIT库存配置")
public class WmsJusdaInventoryConfig extends BaseCommonEntity {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String sapPlantCode;

    @ApiModelProperty(value = "siteName")
    private String siteName;

    @ApiModelProperty(value = "userName")
    private String userName;

    @ApiModelProperty(value = "passWord")
    private String passWord;

    @ApiModelProperty(value = "customerNo")
    private String customerNo;

    @ApiModelProperty(value = "良品库存状态标识")
    private String goodProductStatus;

    @ApiModelProperty(value = "shipTo")
    private String shipTo;

    @ApiModelProperty(value = "enterpriseGroup")
    private String enterpriseGroup;

    @ApiModelProperty(value = "mrpArea")
    private String mrpArea;
}
