package com.maxnerva.cloudmes.service.jusda;

import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.json.JSONUtil;
import com.maxnerva.cloudmes.common.response.Result;
import com.maxnerva.cloudmes.service.jusda.model.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/11/09 10:32
 * @Version: 1.0
 */
@RefreshScope
@Service
@Slf4j
public class JusdaWebService {

    @Value("${jusda.service.url:}")
    private String jusdaServiceUrl;

    @Value("${jusda.asn-upload.url:}")
    private String asnUploadJusdaUrl;

    @Value("${connection.timeout:30000}")
    private int timeout;

    /**
     * shippingID shipQty = receiveQty 回复JUADA
     *
     * @param dto
     * @return
     */
    public HttpResponse doPostingJusdaReceiveCompleted(ReturnJusdaReceiveCompletedDto dto) {

        String url = jusdaServiceUrl + "/B2BCustomer/EDISignInByShipIDforBU";

        HttpResponse response = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(timeout)
                .body(JSONUtil.toJsonStr(dto))
                .execute();

        return response;

    }


    /**
     * 回复 JUSDA shippingID 已签收完成
     * shipping过完账后 回写 861
     *
     * @param shippingInfoDtos
     * @return
     */
    public HttpResponse doPostingJusdaVmiShippingInfo(List<ReturnJusdaShippingInfoDto> shippingInfoDtos) {

        String url = jusdaServiceUrl + "/B2BCustomer/ShipResponseForBU";

        HttpResponse response = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(timeout)
                .body(JSONUtil.toJsonStr(shippingInfoDtos))
                .execute();

        return response;

    }

    /**
     * 取jusda库存
     *
     * @return
     */
    public HttpResponse doGetJusdaStockInfo(Edi846RequestDto dto) {

        String url = jusdaServiceUrl + "/WMS/EDI846FORBU";
//        String url = "http://10.134.167.135:90/WebApi/api/WMS/EDI846FORBU";
        log.info("dto ：{}", JSONUtil.toJsonStr(dto));


        HttpRequest httpRequest = HttpRequest.post(url)
                .header("Content-Type", "multipart/form-data;charset=UTF-8", true)
                .setConnectionTimeout(timeout)
                .form("SiteName", dto.getSiteName())
                .form("UserName", dto.getUserName())
                .form("PassWord", dto.getPassWord())
                .form("CustomerNo", dto.getCustomerNo());


        HttpResponse response = httpRequest.execute();

        return response;

    }

    /**
     * post pull list
     *
     * @return
     */
    public HttpResponse doPostJusdaPullList(Edi862RequestDto dto) {

        String url = jusdaServiceUrl + "/WMS/EDI862";

        HttpResponse response = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(timeout)
                .body(JSONUtil.toJsonStr(dto))
                .execute();

        return response;

    }


    public HttpResponse getScanPalletDataListTest(String palletNo) {
        //正式地址
        String url = "http://10.134.167.135:90/WebApi/api/B2BCustomer/EDI856PackagingForBU?SiteName=TJ&PalletID="+palletNo;
        //测试
//        String url = "http://10.157.152.197:91/api/B2BCustomer/EDI856PackagingForBU?SiteName=TJUAT&PalletID="+palletNo;
        System.out.println("url----------:"+url);
        HttpResponse response = HttpRequest.get(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .setConnectionTimeout(timeout)
//                .body(JSONUtil.toJsonStr(dto))
                .execute();

        return response;

    }

    public HttpResponse asnPostJusda(String senderId, String msgType, String receiverId, String docId, String rquestJson) {
        HttpResponse response = HttpRequest.post(asnUploadJusdaUrl)
                .header("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8", true)
                .setConnectionTimeout(timeout)
                .form("senderID", senderId)
                .form("receiverID", receiverId)
                .form("msgType", msgType)
                .form("docID", docId)
                .form("requestContent", rquestJson)
                .execute();
        log.info("url:{}, response:{}", asnUploadJusdaUrl, response.body());
        return response;
    }
}
