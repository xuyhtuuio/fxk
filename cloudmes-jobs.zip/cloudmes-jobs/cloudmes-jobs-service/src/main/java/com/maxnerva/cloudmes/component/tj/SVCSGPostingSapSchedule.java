package com.maxnerva.cloudmes.component.tj;

import com.maxnerva.cloudmes.service.basic.PostingConfigService;
import com.maxnerva.cloudmes.service.doc.CostDocPostingService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * @ClassName SVCSGPostingSapSchedule
 * @Description TODO
 * @Author Likun
 * @Date 2024/6/24
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ConditionalOnProperty(value = "schedule.scope", havingValue = "F_TJ")
@Component
@EnableScheduling
@Slf4j
public class SVCSGPostingSapSchedule {

    private static final String ORG_CODE = "SVC_SG";
    private static final String SAP_CLIENT_CODE = "sapvn";
    private static String postDate = "N";

    @Autowired
    CostDocPostingService costDocPostingService;

    @Autowired
    PostingConfigService postingConfigService;


    @Scheduled(initialDelay = 5000, fixedDelay = 300000)
    public void updatePostDate() {
        log.info("SVCSGUpdatePostDate start :" + System.currentTimeMillis());
        String s = postingConfigService.getPostDate(ORG_CODE, null);
        log.info("SVCSGUpdatePostDate end :" + System.currentTimeMillis());
        postDate = s;
    }

    /**
     * 费领退单过账
     * 频率：10分钟执行一次
     */
    @Scheduled(initialDelay = 30000, fixedDelay = 600000)
    public void costAllDocTransferPosting() {
        log.info("costSVCSGDocTransferPosting start :" + System.currentTimeMillis());
        costDocPostingService.costDocTransferPosting(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("costSVCSGDocTransferPosting end :" + System.currentTimeMillis());
    }
}
