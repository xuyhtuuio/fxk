package com.maxnerva.cloudmes.entity.deliver;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName DnPostSfcResponse
 * @Description TODO
 * @Author Likun
 * @Date 2024/11/14
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("dn抛sfc返回实体")
@Data
public class DnPostSfcResponse {

    @ApiModelProperty("成功：SUCCESS")
    private String flag;

    @ApiModelProperty("返回信息")
    private String msg;
}
