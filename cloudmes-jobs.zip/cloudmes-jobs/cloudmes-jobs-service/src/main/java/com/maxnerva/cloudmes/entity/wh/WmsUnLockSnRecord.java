package com.maxnerva.cloudmes.entity.wh;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * mes通知解锁sn记录表
 * </p>
 *
 * @author likun
 * @since 2024-08-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsUnLockSnRecord对象", description="mes通知解锁sn记录表")
public class WmsUnLockSnRecord extends BaseEntity<WmsUnLockSnRecord> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "pkg")
    private String pkgId;

    @ApiModelProperty(value = "完成标识 0--未完成 1---完成")
    private String completedFlag;
}
