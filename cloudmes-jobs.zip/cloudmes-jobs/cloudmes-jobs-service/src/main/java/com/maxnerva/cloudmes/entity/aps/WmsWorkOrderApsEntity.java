package com.maxnerva.cloudmes.entity.aps;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.maxnerva.cloudmes.entity.BaseEntity;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 同步aps工单header信息表
 * @author Yang Jun Wen
 * @since 2023-06-09
 */
@Data
@TableName("wms_work_order_aps")
public class WmsWorkOrderApsEntity extends BaseEntity<WmsWorkOrderApsEntity> {

    /**
     * 主键id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 工厂组织
     */
    @TableField("org_code")
    private String orgCode;

    /**
     * aps单号
     */
    @TableField("aps_number")
    private String apsNumber;

    /**
     * aps时间
     */
    @TableField("aps_date")
    private LocalDate ApsDate;

    /**
     * 工厂
     */
    @TableField("plant_code")
    private String PlantCode;

    /**
     * 线别
     */
    @TableField("line_no")
    private String LineNo;

    /**
     * 料号
     */
    @TableField("part_no")
    private String partNo;

    @TableField("module")
    private String Module;

    /**
     * 描述
     */
    @TableField("description")
    private String Description;

    /**
     * 连板数
     */
    @TableField("cards_per_panel")
    private BigDecimal CardsPerPanel;

    @TableField("panel_type")
    private String PanelType;

    /**
     * 工单号
     */
    @TableField("work_order_no")
    private String workOrderNo;

    /**
     * 工单数量
     */
    @TableField("work_order_qty")
    private BigDecimal workOrderQty;

    /**
     * aps数量
     */
    @TableField("aps_qty")
    private BigDecimal ApsQty;

    /**
     * 紧急程度
     */
    @TableField("priority")
    private String Priority;

    /**
     * 开始时间
     */
    @TableField("begin_time")
    private LocalDateTime BeginTime;

    /**
     * 结束时间
     */
    @TableField("end_time")
    private LocalDateTime EndTime;

}
