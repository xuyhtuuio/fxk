package com.maxnerva.cloudmes.service.sfc.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import com.maxnerva.cloudmes.entity.wo.WmsBomFeeder;
import com.maxnerva.cloudmes.mapper.sfc.Epd6OracleProcedureMapper;
import com.maxnerva.cloudmes.service.sfc.SfcStoredProcedureService;
import com.maxnerva.cloudmes.service.sfc.model.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/09/02 08:34
 * @Version: 1.0
 */
@Service
@Component("EPDVI_F6T1")
public class Epd6SfcStoredProcedureServiceImpl implements SfcStoredProcedureService {

    @Resource
    Epd6OracleProcedureMapper oracleProcedureMapper;

    @Override
    public List<WmsBomFeeder> getWmsBomFeeder(String partNo, String lineNo, String processType,
                                              String orgCode, String plantCode) {

        Map input = new HashMap();
        input.put("i_pn", partNo);
        input.put("i_line", lineNo);
        oracleProcedureMapper.getWmsBomFeeder(input);
        List<WmsBomFeeder> wmsBomFeeders = (List<WmsBomFeeder>) input.get("o_dataset");
        long count = wmsBomFeeders.stream().filter(ObjectUtil::isNull).count();
        if (count > 0) {
            return CollUtil.newArrayList();
        }
        if (StringUtils.isNotBlank(processType)) {
            return wmsBomFeeders.stream().filter(o -> o.getProductProcess().equalsIgnoreCase(processType)).collect(Collectors.toList());
        }

        return wmsBomFeeders;
    }

    @Override
    public String postingSfcPkgInfo(PostPkgInfoToSfcDto dto,
                                    String orgCode, String plantCode) {
        Map input = new HashMap();
        input.put("i_pkgid", dto.getPkgId());
        input.put("i_hhpn", dto.getPartNo());
        input.put("i_qty", dto.getQty());
        input.put("i_mfgpn", dto.getMfgPartNo());
        input.put("i_dc", dto.getDateCode());
        input.put("i_lc", dto.getLotCode());
        input.put("i_vendor_name", dto.getMfgName());
        input.put("i_remain_qty", dto.getRemainQty());
        input.put("i_emp_no", dto.getEmpNo());
        input.put("i_tiptop_ord", dto.getWorkOrderNo());
        input.put("i_parent_pkgid", dto.getParentPkgId());
        input.put("i_origin", dto.getPlaceOfOrigin());
        input.put("i_check_sum", dto.getCheckSum());

        oracleProcedureMapper.postingSfcPkgInfo(input);
        String result = (String) input.get("o_res");

        return result;

    }

    @Override
    public PkgStatusInfoDto getPkgStatusInfo(PkgStatusInfoDto pkgStatusInfoDto, String orgCode,
                                             String plantCode) {

        Map input = new HashMap();
        input.put("i_pkgid", pkgStatusInfoDto.getPkgId());
        input.put("i_remain_qty", pkgStatusInfoDto.getRemainQty());

//        oracleProcedureMapper.getPkgStatusInfo(input);
        oracleProcedureMapper.getOnlinePkgStatusInfo(input);

        pkgStatusInfoDto.setTopMarking((String) input.get("o_topmarking"));
        pkgStatusInfoDto.setMsdValue((String) input.get("o_msd"));
        pkgStatusInfoDto.setLcrValue((String) input.get("o_lcr"));
        pkgStatusInfoDto.setMsdOpen((String) input.get("o_msd_open"));
        pkgStatusInfoDto.setIsOnline((String) input.get("o_is_online"));
        return pkgStatusInfoDto;
    }

    @Override
    public List<SfcPalletInfoDto> getSfcPalletInfo(String barcode, String orgCode, String plantCode) {
        Map input = new HashMap();
        input.put("i_pallet", barcode);
        oracleProcedureMapper.getSfcPalletInfo(input);
        String result = (String) input.get("o_res");
        Assert.isTrue("OK".equalsIgnoreCase(result), "SFC error " + result);
        List<SfcPalletInfoDto> palletInfo = (List<SfcPalletInfoDto>) input.get("o_dataset");

        if (CollUtil.isEmpty(palletInfo)) {
            return null;
        }

        //BigDecimal t =palletInfo.stream()
        //        .map(SfcPalletInfoDto::getSnQty).reduce(BigDecimal.ZERO,BigDecimal::add);
        //
        //palletInfo.forEach(a -> {
        //    a.setPalletQty(t);
        //});


        return palletInfo;
    }

    @Override
    public List<PkgLinkListDto> getPkgLinkList(String pkgId) {
        Map input = new HashMap();
        input.put("i_pkgid", pkgId);

        oracleProcedureMapper.getPkgLinkList(input);
        List<PkgLinkListDto> result = (List<PkgLinkListDto>) input.get("o_dataset");

        return result;

    }

    @Override
    public String clearPkgStatusToSfc(String pkgId, String currentQty, String orgCode, String plantCode) {
        Map input = new HashMap();
        input.put("i_pkgid", pkgId);
        input.put("i_remain_qty", currentQty);
        oracleProcedureMapper.clearPkgStatusToSfc(input);
        String result = (String) input.get("o_res");
        return result;
    }

    @Override
    public String sendSnDnRelationshipToSfc(String orgCode, String plantCode, String mrpArea, SnDnRelationshipDto dto) {
        Map input = new HashMap();
        input.put("i_sn", dto.getSn());
        input.put("i_po", dto.getPo());
        input.put("i_group_name", dto.getSfcWorkstation());
        input.put("i_bt", dto.getTemporaryPoOfHub());
        input.put("i_dn", dto.getDn());
        oracleProcedureMapper.sendSnDnRelationshipToSfc(input);
        String result = (String) input.get("o_res");
        return result;
    }

    @Override
    public String doWarehousingPassSnStation(WarehousingPassSnStationDto dto,
                                             String orgCode, String plantCode) {

        Map input = new HashMap();
        input.put("EMP", dto.getUserName());
        input.put("LINE", dto.getLine());
        input.put("SECTION", "INSTORE");
        input.put("W_STATION", "INSTORE");
        input.put("EC", dto.getBadCode());
        input.put("DATA", dto.getSn());
        input.put("MYGROUP", "INSTORE");
        oracleProcedureMapper.warehousingPassSnStation(input);
        String result = (String) input.get("RES");
        return result;
    }

    @Override
    public Map getSfcExtendInfoBySn(String sn) {
        Map input = new HashMap<>();
        input.put("i_sn", sn);
        oracleProcedureMapper.getSnSfcExtendInfo(input);
        return input;
    }

    @Override
    public String insertAmazonLog(InsertAmazonLogDto amazonLogDto) {
        Map input = new HashMap();
        input.put("i_DEMAND_TYPE", amazonLogDto.getDemandType());
        input.put("i_AMAZON_ID", amazonLogDto.getAmazonId());
        input.put("i_REQUEST_ID", amazonLogDto.getRequestId());
        input.put("i_BUILD_TRIGGER_ID", amazonLogDto.getBuildTriggerId());
        input.put("i_ASSET_ID", amazonLogDto.getAssetId());
        input.put("i_QUANTITY", amazonLogDto.getQty());
        input.put("i_IPN", amazonLogDto.getIPn());
        input.put("i_ASSET_CATEGORY", amazonLogDto.getAssetCategory());
        input.put("i_TEST_ITEM", amazonLogDto.getTestItem());
        input.put("i_ITEM_DESCRIPTION", amazonLogDto.getItemDescription());
        input.put("i_SITE_CODE", amazonLogDto.getSiteCode());
        input.put("i_IN_STOCK_HUB", amazonLogDto.getInStockHub());
        input.put("i_MANUFACTURING_START_DATE", amazonLogDto.getManufacturingStartDate());
        input.put("i_ESTIMATED_READY_DATE", amazonLogDto.getEstimatedReadyDate());
        input.put("i_COMMENTS", amazonLogDto.getComments());
        oracleProcedureMapper.insertAmazonLog(input);
        String result = (String) input.get("o_res");
        return result;
    }

    @Override
    public String sendProductShippingToSfc(PostProductShippingToSfcDto toSfcDto) {
        Map input = new HashMap();
        input.put("i_EMP", toSfcDto.getEmp());
        input.put("i_VEHICLE", toSfcDto.getVehicle());
        input.put("i_DESTINATION", toSfcDto.getDestination());
        input.put("i_CARTON", toSfcDto.getCarton());
        input.put("i_MYGROUP", toSfcDto.getMygroup());
        input.put("i_DN", toSfcDto.getDn());
        oracleProcedureMapper.testInputShipping(input);
        String result = (String) input.get("o_RES");
        return result;
    }

    @Override
    public List<SfcWoUsePkgInfoDto> getSfcWoUsePkgInfo(String startDateTime) {
        Map input = new HashMap();
        input.put("i_date", startDateTime);

        oracleProcedureMapper.getSfcWoUsePkgInfo(input);
        List<SfcWoUsePkgInfoDto> result = (List<SfcWoUsePkgInfoDto>) input.get("o_dataset");

        return result;
    }

    @Override
    public Map getPkgRelation(String pkgId) {
        Map input = new HashMap();
        input.put("i_pkgid", pkgId);
        oracleProcedureMapper.getPdPkgId(input);
        return input;
    }

    @Override
    public SfcWoDto getSfcWoInfo(String sn) {
        SfcWoDto sfcWoDto = oracleProcedureMapper.getSfcWoInfo(sn);
        return sfcWoDto;
    }

    @Override
    public List<SfcCartonInfoDTO> getSfcPalletInfoByCartonNo(String cartonNo, String orgCode, String plantCode) {
        return CollUtil.newArrayList();
    }

    @Override
    public String getSfcErrorDesc(String orgCode, String plantCode, String errorCode) {
        return oracleProcedureMapper.getSfcErrorDesc(errorCode);
    }

    @Override
    public String getWoNoByPkgId(String orgCode, String plantCode, String pkgId) {
        return oracleProcedureMapper.getWoNoByPkgId(pkgId);
    }

    @Override
    public List<SfcBurnValueDto> getSFCBurnValue(String productPartNo) {
        return null;
    }

    @Override
    public List<String> getSFCPkgId(String orgCode, String plantCode, String pkgId) {
        return null;
    }

}
