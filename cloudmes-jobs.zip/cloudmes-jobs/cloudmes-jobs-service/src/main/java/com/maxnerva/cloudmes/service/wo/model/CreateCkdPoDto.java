package com.maxnerva.cloudmes.service.wo.model;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author H7109018
 */
@Data
public class CreateCkdPoDto implements Serializable {

    private static final long serialVersionUID = -1L;

    //PO HEADER
    //为空，保留栏位
    private String poNumber;
    // 越南法人
    //VN07
    private String compCode;

    private String orgCode;
    //PO 类型
    // YZNE
    private String docType;
    //创建日期
    private String createDate;
    //VSG0000018
    private String vendorCode;
    //采购组织
    // E6VD
    private String purchaseOrg;
    //F60
    private String purchaseGroup;

    //PO ITEM
    List<CreateCkdPoItemDto> poItem;

    // po Partner
    // 2A
    private String partnerDesc;
    // EN
    private String langu;

    // VHK0010168
    // TJ vender code
    private String buspartNo;

    // po Text Header
    // F50 购方部门代码
    // F51 销方部门代码
    private String buyTextId;
    private String buyTextLine;
    private String sellTextId;
    private String sellTextLine;
    private String shippingPoint;


}
