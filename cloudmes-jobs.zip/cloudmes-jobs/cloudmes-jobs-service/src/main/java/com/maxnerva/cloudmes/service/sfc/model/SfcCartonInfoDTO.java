package com.maxnerva.cloudmes.service.sfc.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @ClassName SfcCartonInfoDTO
 * @Description TODO
 * @Author Likun
 * @Date 2023/6/10
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Data
public class SfcCartonInfoDTO {

    /**
     * ORG_CODE
     */
    @ApiModelProperty(value = "工厂组织")
    private String orgCode;

    /**
     * 栈板号
     */
    @ApiModelProperty(value = "栈板号")
    private String palletNo;

    /**
     * 箱
     */
    @ApiModelProperty(value = "箱")
    private String cartonNo;


    /**
     * SN
     */
    @ApiModelProperty(value = "SN")
    private String snNo;

    /**
     * SN数量
     */
    @ApiModelProperty(value = "SN数量")
    private BigDecimal qty;


    @ApiModelProperty("单位")
    private String uomCode;

    /**
     * 工单号
     */
    @ApiModelProperty(value = "工单号")
    private String workerOrderNo;

    /**
     * 成品料号
     */
    @ApiModelProperty(value = "成品料号")
    private String partNo;

    @ApiModelProperty("post_sfc_pass_station_flag")
    private String postSfcPassStationFlag;

    @ApiModelProperty("post_sfc_message")
    private String postSfcMessage;

    @ApiModelProperty("sync_sfc_extend_info_result")
    private String syncSfcExtendInfoResult;

    @ApiModelProperty("versionCode")
    private String versionCode;

    @ApiModelProperty("modelSerial")
    private String modelSerial;

    @ApiModelProperty("plantCode")
    private String plantCode;

}
