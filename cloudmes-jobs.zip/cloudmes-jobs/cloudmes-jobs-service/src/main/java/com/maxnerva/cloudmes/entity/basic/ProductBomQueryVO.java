package com.maxnerva.cloudmes.entity.basic;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName ProductBomQueryVO
 * @Description TODO
 * @Author Likun
 * @Date 2024/12/20
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("产品bom查询vo")
@Data
public class ProductBomQueryVO {

    @ApiModelProperty("成品料号")
    private String productNo;

    @ApiModelProperty("组织")
    private String orgCode;
}
