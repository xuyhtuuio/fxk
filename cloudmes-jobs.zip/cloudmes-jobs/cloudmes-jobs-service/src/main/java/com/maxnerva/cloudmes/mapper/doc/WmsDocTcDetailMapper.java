package com.maxnerva.cloudmes.mapper.doc;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.doc.WmsDocTcDetail;

public interface WmsDocTcDetailMapper extends BaseMapper<WmsDocTcDetail> {
}
