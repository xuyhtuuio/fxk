package com.maxnerva.cloudmes.entity.basic;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class MaterialCategoryCodeDTO {
    @ApiModelProperty(value = "料号")
    private String materialNo;

    @ApiModelProperty(value = "物料分类Code")
    private String classCode;
}
