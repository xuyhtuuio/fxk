package com.maxnerva.cloudmes.mapper.alarm;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.alarm.WmsSendMailConfig;

/**
 * <p>
 * 邮件配置表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2023-12-19
 */
public interface WmsSendMailConfigMapper extends BaseMapper<WmsSendMailConfig> {

}
