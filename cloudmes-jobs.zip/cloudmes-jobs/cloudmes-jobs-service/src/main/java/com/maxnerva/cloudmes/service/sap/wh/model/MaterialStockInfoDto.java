package com.maxnerva.cloudmes.service.sap.wh.model;

import cn.hutool.core.util.NumberUtil;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author H7109018
 */
@Data
public class MaterialStockInfoDto implements Serializable {

    private static final long serialVersionUID = 1L;
    private String plantCode;
    private String warehouseCode;
    private String warehouseDesc;
    private String unit;
    private String partNo;
    private String partVersion;
    private String materialType;
    private String materialGroup;
    private String valueType;
    /**
     * 物料描述
     */
    private String partDesc;
    /**
     * 良品数量
     */
    private BigDecimal goodProductsQty;

    /**
     * 待验数量
     */
    private BigDecimal inspectedQty;
    private String special;
    private String vendor;


    public BigDecimal stockTotalQty() {
        return NumberUtil.add(this.goodProductsQty, this.getInspectedQty());
    }


}
