package com.maxnerva.cloudmes.mapper.doc;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.doc.WmsAsnUpload;


/**
 * @author H7109018
 */
public interface WmsAsnUploadMapper extends BaseMapper<WmsAsnUpload> {

}
