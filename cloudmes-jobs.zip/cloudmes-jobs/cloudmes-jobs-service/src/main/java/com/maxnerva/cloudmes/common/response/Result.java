package com.maxnerva.cloudmes.common.response;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.ToString;

/**
 * @Description: result
 * @Author: Chao Zhang
 * @Date: 2021/01/25
 * @Version: 1.0
 */

@ApiModel(description = "通用响应类")
@Getter
@ToString
public class Result<T> {

    @ApiModelProperty(value = "响应代码", required = true)
    private int code;

    @ApiModelProperty(value = "提示信息", required = true)
    private String message;

    @ApiModelProperty(value = "响应数据")
    private T data;

    //@ApiModelProperty(value = "响应时间")
    //@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    //private LocalDateTime rt = LocalDateTime.now();

    /**
     * @param code
     * @param data
     * @param message
     */
    private Result(int code, T data, String message) {
        this.code = code;
        this.message = message;
        this.data = data;
    }

    /**
     * @param resultCodeEnum
     */
    private Result(ResultCodeEnum resultCodeEnum) {
        this(resultCodeEnum.code, null, resultCodeEnum.message);
    }

    /**
     * @param resultCodeEnum
     * @param msg
     */
    private Result(ResultCodeEnum resultCodeEnum, String msg) {
        this(resultCodeEnum, null, msg);
    }

    /**
     * @param resultCodeEnum
     * @param data
     */
    private Result(ResultCodeEnum resultCodeEnum, T data) {
        this(resultCodeEnum, data, resultCodeEnum.message);
    }

    /**
     * @param resultCodeEnum
     * @param data
     * @param msg
     */
    private Result(ResultCodeEnum resultCodeEnum, T data, String msg) {
        this(resultCodeEnum.code, data, msg);
    }

    /**
     * @param data 数据
     * @param <T>  T 响应数据
     * @
     */
    public static <T> Result<T> data(T data) {
        return data(data, ResultCodeEnum.SUCCESS.message);
    }

    /**
     * @param data 数据
     * @param msg  消息
     * @param <T>  T 响应数据
     * @
     */
    public static <T> Result<T> data(T data, String msg) {
        return data(ResultCodeEnum.SUCCESS.code, data, msg);
    }

    /**
     * @param code 状态码
     * @param data 数据
     * @param msg  消息
     * @param <T>  T 响应数据
     * @
     */
    public static <T> Result<T> data(int code, T data, String msg) {
        return new Result<>(code, data, msg);
    }

    /**
     * 返回Result
     *
     * @param
     * @param <T> T 响应数据
     * @返回Result
     */
    public static <T> Result<T> success() {
        return new Result<>(ResultCodeEnum.SUCCESS);
    }

    /**
     * 返回Result
     *
     * @param msg 消息
     * @param <T> T 响应数据
     * @返回Result
     */
    public static <T> Result<T> success(String msg) {
        return new Result<>(ResultCodeEnum.SUCCESS, msg);
    }

    /**
     * 返回Result
     *
     * @param
     * @param <T> T 响应数据
     * @返回Result
     */
    public static <T> Result<T> success(ResultCodeEnum resultCodeEnum) {
        return new Result<>(resultCodeEnum);
    }

    /**
     * 返回Result
     *
     * @param
     * @param msg 提示信息
     * @param <T> T 响应数据
     * @返回Result
     */
    public static <T> Result<T> success(ResultCodeEnum resultCodeEnum, String msg) {
        return new Result<>(resultCodeEnum, msg);
    }

    /**
     * 返回Result
     *
     * @param <T> T 响应数据
     * @返回Result
     */
    public static <T> Result<T> failure() {
        return new Result<>(ResultCodeEnum.FAILURE, ResultCodeEnum.FAILURE.message);
    }

    /**
     * 返回Result
     *
     * @param msg 消息
     * @param <T> T 响应数据
     * @返回Result
     */
    public static <T> Result<T> failure(String msg) {
        return new Result<>(ResultCodeEnum.FAILURE, msg);
    }


    /**
     * 返回Result
     *
     * @param code 状态码
     * @param msg  消息
     * @param <T>  T 响应数据
     * @返回Result
     */
    public static <T> Result<T> failure(int code, String msg) {
        return new Result<>(code, null, msg);
    }

    /**
     * 返回Result
     *
     * @param
     * @param <T> T 响应数据
     * @返回Result
     */
    public static <T> Result<T> failure(ResultCodeEnum resultCodeEnum) {
        return new Result<>(resultCodeEnum);
    }

    /**
     * 返回Result
     *
     * @param
     * @param msg 提示信息
     * @param <T> T 响应数据
     * @返回Result
     */
    public static <T> Result<T> failure(ResultCodeEnum resultCodeEnum, String msg) {
        return new Result<>(resultCodeEnum, msg);
    }

    /**
     * @param <T>
     * @param flag
     * @return
     */
    public static <T> Result<T> result(boolean flag) {
        return flag ? Result.success("操作成功") : Result.failure("操作失败");
    }

}