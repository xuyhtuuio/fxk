package com.maxnerva.cloudmes.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/**
 * @ClassName GlobalConfig
 * @Description TODO
 * @Author Likun
 * @Date 2024/11/14
 * @Version 1.0
 * @Since JDK 1.8
 **/
@RefreshScope
@Component
@Data
public class GlobalCommonConfig {

    @Value("${dnPostSfcUrl:}")
    private String dnPostSfcUrl;

    /**
     * 发料时间在当前日期上延长的天数  默认0
     */
    @Value("${delay.day:0}")
    private String delayDay;
}
