package com.maxnerva.cloudmes.mapper.wo;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderPrepareCkdShipHeader;


public interface WmsWorkOrderPrepareCkdShipHeaderMapper extends BaseMapper<WmsWorkOrderPrepareCkdShipHeader> {

}
