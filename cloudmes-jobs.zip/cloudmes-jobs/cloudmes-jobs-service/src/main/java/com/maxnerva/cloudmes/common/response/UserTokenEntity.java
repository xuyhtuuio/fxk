package com.maxnerva.cloudmes.common.response;

import lombok.Builder;
import lombok.Data;

/**
 * @author H7109018
 */
@Data
@Builder
public class UserTokenEntity {
	private String userName;
	private String bu;
	private String userPermission;

}
