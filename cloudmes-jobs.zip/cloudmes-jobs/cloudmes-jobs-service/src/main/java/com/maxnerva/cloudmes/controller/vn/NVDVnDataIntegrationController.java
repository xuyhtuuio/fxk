package com.maxnerva.cloudmes.controller.vn;

import cn.hutool.core.date.DateUtil;
import com.maxnerva.cloudmes.common.response.Result;
import com.maxnerva.cloudmes.entity.R;
import com.maxnerva.cloudmes.entity.qms.SyncQmsMsdLevelVO;
import com.maxnerva.cloudmes.entity.qms.SyncQmsValidVO;
import com.maxnerva.cloudmes.service.alarm.IWmsDeclareFilingAlarmRecordService;
import com.maxnerva.cloudmes.service.aps.ApsService;
import com.maxnerva.cloudmes.service.aps.model.ApsRequestVO;
import com.maxnerva.cloudmes.service.basic.PostingConfigService;
import com.maxnerva.cloudmes.service.doc.CostDocPostingService;
import com.maxnerva.cloudmes.service.doc.DocJitReceiveRecordService;
import com.maxnerva.cloudmes.service.doc.ReceiveDocPostingService;
import com.maxnerva.cloudmes.service.doc.TradingDocService;
import com.maxnerva.cloudmes.service.flownet.FlownetService;
import com.maxnerva.cloudmes.service.wh.IWmsPkgInfoService;
import com.maxnerva.cloudmes.service.wo.WorkOrderService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @ClassName NVDVnDataIntegrationController
 * @Description TODO
 * @Author Likun
 * @Date 2024/11/12
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "NVD_VN数据集成调用接口")
@Slf4j
@RestController
@RequestMapping("/nvdVnDataIntegration")
public class NVDVnDataIntegrationController {

    private static final String ORG_CODE = "NVD_VN";
    private static final String SAP_CLIENT_CODE = "sapvn";
    private static final String DATE_FORMAT = "yyyyMMdd";
    private static String postDate = "N";

    @Autowired
    CostDocPostingService costDocPostingService;

    @Autowired
    PostingConfigService postingConfigService;

    @Autowired
    ReceiveDocPostingService docPostingService;

    @Autowired
    DocJitReceiveRecordService jitDocService;

    @Autowired
    WorkOrderService workOrderService;

    @Autowired
    TradingDocService tradingDocService;

    @Autowired
    private ApsService apsService;

    @Autowired
    private FlownetService flownetService;

    @Autowired
    private IWmsDeclareFilingAlarmRecordService wmsDeclareFilingAlarmRecordService;

    @Autowired
    private IWmsPkgInfoService wmsPkgInfoService;

    /**
     * 修改过账时间
     * 频率：10分钟执行一次
     */
    @ApiOperation("修改过账时间")
    @GetMapping("/updatePostDate")
    public void updatePostDate() {
        String s = postingConfigService.getPostDate(ORG_CODE, null);
        postDate = s;
        log.info(">>>>>>>>>NVD_VN过账时间:{}", postDate);
    }

    /**
     * 同步SFC 上料表和备料方向
     * 频率：30分钟执行一次
     */
    @ApiOperation("同步SFC 上料表和备料方向")
    @GetMapping("/syncBomFeederFromSfc")
    public void syncBomFeederFromSfc() {
        log.info("syncBomFeederFromSfc start :" + System.currentTimeMillis());
        workOrderService.syncBomFeederFromSfc(ORG_CODE, null);
        log.info("syncBomFeederFromSfc end :" + System.currentTimeMillis());
    }

    /**
     * 同步SAP workOrder header info,
     * 频率：60分钟执行一次
     */
    @ApiOperation("同步SAP workOrder header info")
    @GetMapping("/syncSapWorkOrderHeader")
    public Result syncSapWorkOrderHeader() {
        log.info(" syncSapWorkOrderHeader start :" + System.currentTimeMillis());
        String startDate = DateUtil.format(LocalDateTime.now().plusDays(-3), DATE_FORMAT);
        String endDate = DateUtil.format(LocalDateTime.now().plusDays(2), DATE_FORMAT);
        workOrderService.syncSapWorkOrderHeader(ORG_CODE, startDate, endDate);
        log.info(" syncSapWorkOrderHeader end :" + System.currentTimeMillis());
        return Result.success();
    }

    /**
     * 同步SAP workOrder detail info,
     * 频率：30分钟执行一次
     */
    @ApiOperation("同步SAP workOrder detail info")
    @GetMapping("/syncSapWorkOrderDetail")
    public void syncSapWorkOrderDetail() {
        log.info("syncSapWorkOrderDetail " + ORG_CODE + "start :" + System.currentTimeMillis());
        workOrderService.syncSapWorkOrderDetail(ORG_CODE, null, SAP_CLIENT_CODE);
        log.info("syncSapWorkOrderDetail " + ORG_CODE + "end :" + System.currentTimeMillis());
    }

    /**
     * 收货确认并上架完成后，收货单抛QMS
     * 频率：5分钟执行一次
     */
    @ApiOperation("收货确认并上架完成后，收货单抛QMS")
    @GetMapping("/docReceivePostQms")
    public void docReceivePostQms() {
        log.info("docReceivePostQms start :" + System.currentTimeMillis());
        docPostingService.docReceivePostQms(ORG_CODE, null);
        log.info("docReceivePostQms end :" + System.currentTimeMillis());
    }

    @ApiOperation("收货单据，依据Q的结果判断是否需要转不良品仓")
    @GetMapping("/docPosting311ToRejectsWarehouse")
    public void docPosting311ToRejectsWarehouse() {
        log.info("docPosting311ToRejectsWarehouse start :" + System.currentTimeMillis());
        docPostingService.docPosting311ToRejectsWarehouse(SAP_CLIENT_CODE, ORG_CODE, "", postDate);
        log.info("docPosting311ToRejectsWarehouse end :" + System.currentTimeMillis());
    }

    /**
     *
     * 从SAP产生JIT收货单
     *
     */
    @ApiOperation("从SAP产生JIT收货单")
    @GetMapping("/syncJitDoc")
    public void syncJitDoc() {
        log.info("syncJitDoc start :" + System.currentTimeMillis());
        String date = DateUtil.format(LocalDateTime.now(), DATE_FORMAT);
        jitDocService.syncJitDoc(SAP_CLIENT_CODE,ORG_CODE,date,date,"");
        log.info("syncJitDoc end :" + System.currentTimeMillis());
    }

    /**
     *产生包材入库
     */
    @ApiOperation("包材入库")
    @GetMapping("/pnReceive")
    public void pnReceive() {
        log.info("pnReceive start :" + System.currentTimeMillis());
        String startDate = DateUtil.format(LocalDateTime.now(), DATE_FORMAT);
        String endDate = DateUtil.format(LocalDateTime.now().plusDays(1), DATE_FORMAT);
        tradingDocService.pnReceive(SAP_CLIENT_CODE,ORG_CODE,startDate,endDate);
        log.info("pnReceive end :" + System.currentTimeMillis());
    }

    @ApiOperation(value = "同步APS信息")
    @PostMapping("/aps")
    public R<Void> syncWorkOrderApsInfo(@RequestBody ApsRequestVO apsRequestVO){
        log.info("syncWorkOrderApsInfo start :" + System.currentTimeMillis());
        String DATE_FORMAT = "yyyy-MM-dd";
        //获取当前时间
        String startDate = DateUtil.format(LocalDateTime.now().plusDays(-0), DATE_FORMAT);
        //获取当前时间七天后的
        String endDate = DateUtil.format(LocalDateTime.now().plusDays(7), DATE_FORMAT);
        apsRequestVO.setBeginDate(startDate);
        apsRequestVO.setOrgCode(ORG_CODE);
        apsRequestVO.setEndDate(endDate);
        apsService.doGetApsInfolist(apsRequestVO);
        log.info("syncWorkOrderApsInfo end :" + System.currentTimeMillis());
        return R.ok();
    }

    /**
     * 报废入库单过账后抛flownet
     */
    @ApiOperation("报废入库单过账后抛flownet")
    @GetMapping("/postingScrapFlownet")
    public void postingScrapFlownet() {
        log.info("Epd6VnpostingScrapFlownet start :" + System.currentTimeMillis());
        flownetService.postingScrapFlownet(ORG_CODE);
        log.info("Epd6VnpostingScrapFlownet end :" + System.currentTimeMillis());
    }

    /**
     *
     * 根据gr信息产生内交入收货单
     *
     */
    @ApiOperation("根据gr信息产生内交入收货单")
    @GetMapping("/syncTradingDoc")
    public void syncTradingDoc() {
        log.info("syncTradingDoc start :" + System.currentTimeMillis());
//        String startDate = DateUtil.format(LocalDateTime.now().plusDays(-2), DATE_FORMAT);
        String date = DateUtil.format(LocalDateTime.now(), DATE_FORMAT);
        tradingDocService.syncTradingDoc(SAP_CLIENT_CODE,ORG_CODE,date,date);
        log.info("syncTradingDoc end :" + System.currentTimeMillis());
    }

    @ApiOperation("备案预警发邮件")
    @GetMapping("/sendMailBatch")
    public void sendMailBatch(){
        log.info("Epd6VnsendMailBatch start :" + System.currentTimeMillis());
        wmsDeclareFilingAlarmRecordService.sendMailBatch(ORG_CODE);
        log.info("Epd6VnsendMailBatch end :" + System.currentTimeMillis());
    }


    @ApiOperation("同步qms有效期")
    @PostMapping("/materialMfgSyncFromQms")
    public R<Void> materialMfgSyncFromQms(@RequestBody List<SyncQmsValidVO> syncQmsValidVOList){
        wmsPkgInfoService.materialMfgSyncFromQms(syncQmsValidVOList);
        return R.ok();
    }

    @ApiOperation("同步qms level等级")
    @PostMapping("/materialMfgLevel")
    public R<Void> materialMfgLevel(@RequestBody List<SyncQmsMsdLevelVO> syncQmsMsdLevelVOList){
        wmsPkgInfoService.materialMfgLevel(syncQmsMsdLevelVOList);
        return R.ok();
    }
}
