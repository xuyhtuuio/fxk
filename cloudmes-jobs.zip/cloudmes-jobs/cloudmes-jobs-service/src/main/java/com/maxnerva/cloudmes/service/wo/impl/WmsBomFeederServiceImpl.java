package com.maxnerva.cloudmes.service.wo.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.entity.wo.WmsBomFeeder;
import com.maxnerva.cloudmes.mapper.wo.WmsBomFeederMapper;
import com.maxnerva.cloudmes.service.wo.IWmsBomFeederService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 上料表信息 服务实现类
 * </p>
 *
 * @author likun
 * @since 2022-08-30
 */
@Service
public class WmsBomFeederServiceImpl extends ServiceImpl<WmsBomFeederMapper, WmsBomFeeder>
        implements IWmsBomFeederService {

}
