package com.maxnerva.cloudmes.service.sap.gr.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @author H7109018
 */
@Data
public class GenerateVmiGrDto implements Serializable {
	private static final long serialVersionUID = 1L;

	private String transactionDate;
	private String refDocNo;
	private String partNo;
	private String partVersion;
	private String plant;
	private String qty;
	private String userName;
	private String warehouseName;
	private String unit;

	/**
	 * 供应商代码， VMI必传,非保税不用传
	 */
	private String vendor;


	/**
	 * 收货单号， VMI必传,非保税不用传
	 */
	private String receiptNumber;
	/**
	 * VMI内交单号
	 */
	private String localDealNumber;
	/**
	 * 内交项次
	 */
	private String localDealItem;
}