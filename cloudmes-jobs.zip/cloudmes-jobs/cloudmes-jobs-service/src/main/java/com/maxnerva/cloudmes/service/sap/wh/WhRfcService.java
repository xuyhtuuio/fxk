package com.maxnerva.cloudmes.service.sap.wh;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.maxnerva.cloudmes.service.sap.util.SapPoolFactory;
import com.maxnerva.cloudmes.service.sap.wh.model.MaterialStockInfoDto;
import com.maxnerva.cloudmes.service.sap.wh.model.TransferDto;
import com.sap.conn.jco.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author H7109018
 */
@Slf4j
@Service
public class WhRfcService {

    @Autowired
    SapPoolFactory sapPoolFactory;

    /**
     * GOODSMVT_CODE  GM_CODE
     * 301 夸工厂转仓   04
     * 311 同工厂转仓   04
     * 309 料调        04
     * 费领 201        03
     * 费退 202        03
     * 报废 551/z51    03
     *
     * @return
     */
    public String doTransfer(String sapClient, TransferDto dto) throws JCoException,RuntimeException{

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        // SAP wo header interface
        JCoFunction function = pool.getRepository().getFunction("Z_MMFM030");

        JCoParameterList inputParams = function.getImportParameterList();
        JCoStructure header = inputParams.getStructure("GOODSMVT_HEADER");
        //转仓日期
        header.setValue("PSTNG_DATE", dto.getTransactionDate());
        //转仓日期
        header.setValue("DOC_DATE", dto.getDocDate());
        //单号
        header.setValue("HEADER_TXT", dto.getHeaderText());
        inputParams.setValue("GOODSMVT_HEADER", header);

        JCoStructure code = inputParams.getStructure("GOODSMVT_CODE");
        code.setValue("GM_CODE", dto.getGmCode());
        inputParams.setValue("GOODSMVT_CODE", code);

        JCoTable itemTable = function.getTableParameterList().getTable("GOODSMVT_ITEM");
        itemTable.appendRow();
        itemTable.setRow(0);

        //转出料号
        itemTable.setValue("MATERIAL_LONG", dto.getFromPartNo());

        if (StrUtil.isNotBlank(dto.getFromPartVersion())) {
            //料号版次不为空，不需要传入move_type
            itemTable.setValue("BATCH", dto.getFromPartVersion());
        } else {
            //评估类型
            itemTable.setValue("VAL_TYPE", dto.getValueType());
            itemTable.setValue("MOVE_VAL_TYPE",dto.getMoveValueType());
        }
        //过账类型
        itemTable.setValue("MOVE_TYPE", dto.getMoveType());

        itemTable.setValue("MOVE_MAT_LONG", dto.getToPartNo());

        if (StrUtil.isNotBlank(dto.getToPartVersion())) {
            itemTable.setValue("MOVE_BATCH", dto.getToPartVersion());
        }

        //转出厂
        if (StringUtils.isNotBlank(dto.getFromPlant())) {
            itemTable.setValue("PLANT", dto.getFromPlant());
        }

        //转入厂
        if (StringUtils.isNotBlank(dto.getToPlant())) {
            itemTable.setValue("MOVE_PLANT", dto.getToPlant());
        }

        //转出仓码
        if (StringUtils.isNotBlank(dto.getFromWarehouseName())) {
            itemTable.setValue("STGE_LOC", dto.getFromWarehouseName());
        }

        // 转入仓码
        if (StringUtils.isNotBlank(dto.getToWarehouseName())) {
            itemTable.setValue("MOVE_STLOC", dto.getToWarehouseName());
        }

        //数量
        itemTable.setValue("ENTRY_QNT", dto.getQty());

        //单位
        itemTable.setValue("ENTRY_UOM", dto.getUnit());

        function.execute(pool);

        JCoParameterList exportlist = function.getExportParameterList();
        //获取转仓后产生的单号
        String transferNo = String.valueOf(exportlist.getValue("MATERIALDOCUMENT"));

        if (StrUtil.isBlank(transferNo)) {
            //转仓失败，未获取单号，需要在表return中获取失败原因
            String errorMessage = "Sap error：";

            JCoTable returnTable = function.getTableParameterList().getTable("RETURN");

            if (returnTable != null && returnTable.getNumRows() > 0) {
                errorMessage = errorMessage + returnTable.getString("MESSAGE");
            } else {
                errorMessage = errorMessage + "SAP do not give failure reason";
            }
            throw new RuntimeException(errorMessage);
        }

        return transferNo;

    }

    /**
     * 批量转仓
     * GOODSMVT_CODE  GM_CODE
     * 301 夸工厂转仓   04
     * 311 同工厂转仓   04
     * 309 料调        04
     * 费领 201        03
     * 费退 202        03
     * 报废 551/z51    03
     *
     * @return
     */
    public String doBatchTransfer(String sapClient, List<TransferDto> dtos) throws JCoException {

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        // SAP wo header interface
        JCoFunction function = pool.getRepository().getFunction("Z_MMFM030");

        JCoParameterList inputParams = function.getImportParameterList();
        JCoStructure header = inputParams.getStructure("GOODSMVT_HEADER");
        //转仓日期
        header.setValue("PSTNG_DATE", dtos.get(0).getTransactionDate());
        //转仓日期
        header.setValue("DOC_DATE", dtos.get(0).getDocDate());
        //单号
        header.setValue("HEADER_TXT", dtos.get(0).getHeaderText());
        //专案名称
        header.setValue("REF_DOC_NO", dtos.get(0).getRefDocNo());
        inputParams.setValue("GOODSMVT_HEADER", header);

        JCoStructure code = inputParams.getStructure("GOODSMVT_CODE");
        code.setValue("GM_CODE", dtos.get(0).getGmCode());
        inputParams.setValue("GOODSMVT_CODE", code);

        JCoTable itemTable = function.getTableParameterList().getTable("GOODSMVT_ITEM");
        for (int i = 0; i < dtos.size(); i++) {
            itemTable.appendRow();
            itemTable.setRow(i);

            //过账类型
            itemTable.setValue("MOVE_TYPE", dtos.get(i).getMoveType());

            if (StringUtils.isNotBlank(dtos.get(i).getCostCenter())) {
                itemTable.setValue("COSTCENTER", dtos.get(i).getCostCenter());
            }
            if (StringUtils.isNotBlank(dtos.get(i).getReasonCode())) {
                itemTable.setValue("MOVE_REAS", dtos.get(i).getReasonCode());
            }


            //转出料号
            itemTable.setValue("MATERIAL_LONG", dtos.get(i).getFromPartNo());

            if (StrUtil.isNotBlank(dtos.get(i).getFromPartVersion())) {
                //料号版次不为空，不需要传入move_type
                itemTable.setValue("BATCH", dtos.get(i).getFromPartVersion());
            } else {
                //评估类型
                itemTable.setValue("VAL_TYPE", dtos.get(i).getValueType());
            }

            itemTable.setValue("MOVE_MAT_LONG", dtos.get(i).getToPartNo());

            if (StrUtil.isNotBlank(dtos.get(i).getToPartVersion())) {
                itemTable.setValue("MOVE_BATCH", dtos.get(i).getToPartVersion());
            }

            //转出厂
            if (StringUtils.isNotBlank(dtos.get(i).getFromPlant())) {
                itemTable.setValue("PLANT", dtos.get(i).getFromPlant());
            }
            //转入厂
            if (StringUtils.isNotBlank(dtos.get(i).getToPlant())) {
                itemTable.setValue("MOVE_PLANT", dtos.get(i).getToPlant());
            }


            //转出仓码
            if (StringUtils.isNotBlank(dtos.get(i).getFromWarehouseName())) {
                itemTable.setValue("STGE_LOC", dtos.get(i).getFromWarehouseName());
            }
            // 转入仓码
            if (StringUtils.isNotBlank(dtos.get(i).getToWarehouseName())) {
                itemTable.setValue("MOVE_STLOC", dtos.get(i).getToWarehouseName());
            }
            // 会计科目
            if (StringUtils.isNotBlank(dtos.get(i).getAccountingSubjects())) {
                itemTable.setValue("GL_ACCOUNT", dtos.get(i).getAccountingSubjects());
            }

            //数量
            itemTable.setValue("ENTRY_QNT", dtos.get(i).getQty());
            //单位
            itemTable.setValue("ENTRY_UOM", dtos.get(i).getUnit());
            //说明
            itemTable.setValue("ITEM_TEXT", dtos.get(i).getItemText());
        }


        function.execute(pool);

        JCoParameterList exportlist = function.getExportParameterList();
        //获取转仓后产生的单号
        String transferNo = String.valueOf(exportlist.getValue("MATERIALDOCUMENT"));

        if (StrUtil.isBlank(transferNo)) {
            //转仓失败，未获取单号，需要在表return中获取失败原因
            String errorMessage = "Sap error：";

            JCoTable returnTable = function.getTableParameterList().getTable("RETURN");

            if (returnTable != null && returnTable.getNumRows() > 0) {
                for (int i = 0; i < returnTable.getNumRows(); i++) {
                    returnTable.setRow(i);
                    errorMessage = errorMessage + returnTable.getString("MESSAGE") + ",[item]:" + returnTable.getString("ROW") +";";
                }
            } else {
                errorMessage = errorMessage + "SAP do not give failure reason";
            }
            throw new RuntimeException(errorMessage);
        }

        return transferNo;

    }

    /**
     * 取SAP 仓库库存信息
     *
     * @return
     */
    public List<MaterialStockInfoDto> doGetStockInfo(String sapClient, String plant, List<String> wareHouseList, List<String> partNoList, List<String> partVersionList) throws JCoException {

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        // SAP wo header interface
        JCoFunction function = pool.getRepository().getFunction("ZFM_GET_STOCK_LIST");

        JCoParameterList inputParams = function.getImportParameterList();
        inputParams.setValue("PLANT", plant);

        if (CollUtil.isNotEmpty(wareHouseList)) {
            JCoTable warehouseTable = inputParams.getTable("LOCATIONS");
            for (int i = 0; i < wareHouseList.size(); i++) {
                warehouseTable.appendRow();
                warehouseTable.setRow(i);
                warehouseTable.setValue("LINE", wareHouseList.get(i));
            }
        }

        if (CollUtil.isNotEmpty(partNoList)) {
            JCoTable materials = inputParams.getTable("MATERIALS");
            for (int i = 0; i < partNoList.size(); i++) {
                materials.appendRow();
                materials.setRow(i);
                materials.setValue("LINE", partNoList.get(i));
            }
        }

        if (CollUtil.isNotEmpty(partVersionList)) {
            JCoTable batches = inputParams.getTable("BATCHES");
            for (int i = 0; i < partVersionList.size(); i++) {
                batches.appendRow();
                batches.setRow(i);
                batches.setValue("LINE", partVersionList.get(i));
            }
        }

        function.execute(pool);

        JCoTable messgeTable = function.getTableParameterList().getTable("STOCK_LIST");

        List<MaterialStockInfoDto> stocks = new ArrayList<>();

        if (messgeTable != null && messgeTable.getNumRows() == 0) {
            return stocks;
        }

        MaterialStockInfoDto sapStockEntity;

        for (int i = 0, rows = messgeTable.getNumRows(); i < rows; i++) {
            messgeTable.setRow(i);
            sapStockEntity = new MaterialStockInfoDto();
            sapStockEntity.setPlantCode(plant);
            sapStockEntity.setWarehouseCode(messgeTable.getString("LOCATION"));
            sapStockEntity.setWarehouseDesc(messgeTable.getString("LOCATION_DESC"));
            sapStockEntity.setPartNo(messgeTable.getString("MATERIAL"));
            sapStockEntity.setValueType(messgeTable.getString("BATCH"));
            sapStockEntity.setPartDesc(messgeTable.getString("MATERIAL_DESC"));
            sapStockEntity.setMaterialType(messgeTable.getString("MATERIAL_TYPE"));
            sapStockEntity.setMaterialGroup(messgeTable.getString("MATERIAL_GROUP"));
            sapStockEntity.setUnit(messgeTable.getString("UNIT"));
            sapStockEntity.setGoodProductsQty(messgeTable.getBigDecimal("UNRESTRICTED"));
            sapStockEntity.setInspectedQty(messgeTable.getBigDecimal("QUALITY"));
            sapStockEntity.setSpecial(messgeTable.getString("SPECIAL"));
            sapStockEntity.setVendor(messgeTable.getString("VENDOR"));
            stocks.add(sapStockEntity);
        }

        return stocks;

    }


}
