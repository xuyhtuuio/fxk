package com.maxnerva.cloudmes.mapper.jusda;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.jusda.WmsJusdaSyncStockConfigEntity;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Chao Zhang
 * @since 2022-12-08
 */
public interface WmsJusdaSyncStockConfigMapper extends BaseMapper<WmsJusdaSyncStockConfigEntity> {

}
