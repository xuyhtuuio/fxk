package com.maxnerva.cloudmes.service.wo;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderDetail;

/**
 * <p>
 * 工单detail信息表 服务类
 * </p>
 *
 * @author likun
 * @since 2022-08-30
 */
public interface IWmsWorkOrderDetailService extends IService<WmsWorkOrderDetail> {

}
