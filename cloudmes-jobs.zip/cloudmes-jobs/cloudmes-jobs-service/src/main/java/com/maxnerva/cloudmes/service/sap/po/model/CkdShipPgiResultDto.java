package com.maxnerva.cloudmes.service.sap.po.model;

import lombok.Data;

import java.io.Serializable;

/**
 * 创建SO、DN 结果
 *
 * @author H7109018
 */
@Data
public class CkdShipPgiResultDto implements Serializable {

    private static final long serialVersionUID = -1L;

    /**
     * DN
     */
    private String dnNo;

    /**
     * 描述
     */
    private String msg;

    /**
     * result
     */
    private String pgiNo;

}
