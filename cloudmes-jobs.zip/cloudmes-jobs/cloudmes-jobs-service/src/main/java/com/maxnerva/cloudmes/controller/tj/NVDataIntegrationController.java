package com.maxnerva.cloudmes.controller.tj;

import com.maxnerva.cloudmes.service.basic.PostingConfigService;
import com.maxnerva.cloudmes.service.doc.CostDocPostingService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author H7109018
 */
@Api(tags = "NV数据集成调用接口")
@Slf4j
@RestController
@RequestMapping("/NVDataIntegration")
public class NVDataIntegrationController {

    private static final String ORG_CODE = "NV";
    private static final String SAP_CLIENT_CODE = "sap";
    private static final String DATE_FORMAT = "yyyyMMdd";
    private static String postDate = "N";

    @Autowired
    CostDocPostingService costDocPostingService;

    @Autowired
    PostingConfigService postingConfigService;

    /**
     * 修改过账时间
     * 频率：10分钟执行一次
     */
    @ApiOperation("修改过账时间")
    @GetMapping("/updatePostDate")
    public void updatePostDate() {
        String s = postingConfigService.getPostDate(ORG_CODE, null);
        postDate = s;
        log.info(">>>>>>>>>NV过账时间:{}",postDate);
    }


    /**
     * 费领退及报废单过账SAP
     * 频率：5分钟执行一次
     */
    @ApiOperation("费领退及报废单过账SAP")
    @GetMapping("/costDocPostingService")
    public void costDocPostingService() {
        log.info("costDocPostingService start :" + System.currentTimeMillis());
        costDocPostingService.costDocTransferPosting(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("costDocPostingService end :" + System.currentTimeMillis());
    }


}
