package com.maxnerva.cloudmes.mapper.outsourcing;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.outsourcing.WmsOutsourcingSapTransactionLog;

/**
 * <p>
 * 委外过账清单 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2023-12-05
 */
public interface WmsOutsourcingSapTransactionLogMapper extends BaseMapper<WmsOutsourcingSapTransactionLog> {

}
