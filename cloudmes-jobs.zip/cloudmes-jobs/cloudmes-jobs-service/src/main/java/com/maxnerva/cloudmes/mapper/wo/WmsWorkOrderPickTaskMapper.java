package com.maxnerva.cloudmes.mapper.wo;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderPickTask;

/**
 * <p>
 * 捡料任务表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2023-07-11
 */
public interface WmsWorkOrderPickTaskMapper extends BaseMapper<WmsWorkOrderPickTask> {

}
