package com.maxnerva.cloudmes.entity.jusda;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 *
 * </p>
 *
 * @author Chao Zhang
 * @since 2022-12-08
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("wms_jusda_sync_stock_config")
public class WmsJusdaSyncStockConfigEntity extends Model<WmsJusdaSyncStockConfigEntity> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @TableField("org_code")
    private String orgCode;

    @TableField("jusda_org_code")
    private String jusdaOrgCode;

    @TableField("site_name")
    private String siteName;

    @TableField("username")
    private String username;

    @TableField("password")
    private String password;

    @TableField("creator")
    private String creator;

    @TableField("creator_id")
    private Integer creatorId;

    @TableField("created_dt")
    private LocalDateTime createdDt;

    @TableField("last_editor")
    private String lastEditor;

    @TableField("last_editor_id")
    private Integer lastEditorId;

    @TableField("last_edited_dt")
    private LocalDateTime lastEditedDt;


    @Override
    public Serializable pkVal() {
        return this.id;
    }

}
