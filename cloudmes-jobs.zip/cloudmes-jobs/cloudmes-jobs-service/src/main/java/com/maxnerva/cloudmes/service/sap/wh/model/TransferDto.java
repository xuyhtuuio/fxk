package com.maxnerva.cloudmes.service.sap.wh.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @author H7109018
 */
@Data
public class TransferDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 转仓日期
     */
    private String transactionDate;

    /**
     * doc 日期
     */
    private String docDate;

    /**
     * From 料号
     */
    private String fromPartNo;

    /**
     * From 料号版次
     */

    private String fromPartVersion;
    /**
     * to 料号
     */

    private String toPartNo;
    /**
     * to 料号版次
     */
    private String toPartVersion;

    /**
     * From 工厂
     */
    private String fromPlant;

    /**
     * to 工厂
     */
    private String toPlant;

    /**
     * 转出仓码
     */
    private String fromWarehouseName;

    /**
     * 转入仓码
     */
    private String toWarehouseName;

    private String costCenter;

    private String reasonCode;

    /**
     * 过账类型
     */
    private String valueType;

    /**
     * 过账类型
     */
    private String moveValueType;

    /**
     * 转仓数量
     */
    private String qty;

    /**
     * 单位
     */
    private String unit;

    /**
     * 311  同工厂转仓
     * 301  夸工厂转仓
     */
    private String moveType;

    /**
     * 311 默 04
     */
    private String gmCode;

    /**
     * 单号
     */
    private String headerText;

    /**
     * 说明
     */
    private String refDocNo;

    /**
     * 专案名称
     */
    private String itemText;

    private String accountingSubjects;
}
