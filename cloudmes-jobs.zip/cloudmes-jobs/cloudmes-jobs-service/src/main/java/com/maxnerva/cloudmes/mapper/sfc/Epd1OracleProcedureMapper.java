package com.maxnerva.cloudmes.mapper.sfc;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.maxnerva.cloudmes.service.sfc.model.EpdiScrapWoDto;
import com.maxnerva.cloudmes.service.sfc.model.SfcCartonInfoDTO;
import com.maxnerva.cloudmes.service.sfc.model.SfcWoDto;

import java.util.List;
import java.util.Map;

/**
 * @author Chao Zhang
 */
@DS("epd1_db")
public interface Epd1OracleProcedureMapper {
    /**
     * 取 SFC 上料表
     *
     * @param map
     */
    void getWmsBomFeeder(Map map);

    /**
     * 抛pkg info 给SFC
     *
     * @param map
     */
    void postingSfcPkgInfo(Map map);

    /**
     * 取PKG 状态值
     * o_res       OUT      VARCHAR2,              -->执行结果： OK/错误信息
     * o_topmarking  OUT      VARCHAR2,   -->丝印结果： NA(不需要比对丝印)，Y(已比对丝印)，N (未比对丝印)
     * o_msd       OUT      VARCHAR2,           -->MSD结果： NA(非MSD物料)，剩余小时数
     * o_lcr       OUT      VARCHAR2                -->LCR结果 ：  NA(不需要测值)，Y(已测值)，N (未测值)
     *
     * @param map
     */
    void getPkgStatusInfo(Map map);

    /**
     * from SFC 取成品入库栈板信息
     *
     * @param map
     */
    void getSfcPalletInfo(Map map);

    /**
     * 退料時返回該PKGID中接料的清單
     *
     * @param map
     */
    void getPkgLinkList(Map map);

    /**
     * WMS退料时调用此接口, 需要清除零数盘的丝印,LCR状态 及物料下线(SMT,PTH)
     *
     * @param map
     */
    void clearPkgStatusToSfc(Map map);

    /**
     * 回写DN、SN的绑定关系
     *
     * @param map
     */
    void sendSnDnRelationshipToSfc(Map map);

    /**
     * 成品入库后触发SFC SN station变动
     *
     * @param map
     */
    void warehousingPassSnStation(Map map);

    /**
     * 取SFC扩展信息
     *
     * @param map
     */
    void getSnSfcExtendInfo(Map map);


    void testInputShipping(Map map);

    void insertAmazonLog(Map map);

    void getSfcWoUsePkgInfo(Map map);

    void getPdPkgId(Map map);

    void getOnlinePkgStatusInfo(Map map);

    SfcWoDto getSfcWoInfo(String sn);

    String getSfcErrorDesc(String errorCode);

    List<SfcCartonInfoDTO> getSfcPalletInfoByCartonNo(String cartonNo);

    List<EpdiScrapWoDto> getWoNoByPkgId(String pkgId);

    void getSFCBurnValue(Map map);

    List<String> getSFCPkgId(String pkgId);
}
