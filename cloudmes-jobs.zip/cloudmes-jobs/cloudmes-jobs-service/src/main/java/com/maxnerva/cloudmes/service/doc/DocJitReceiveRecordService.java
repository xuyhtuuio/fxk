package com.maxnerva.cloudmes.service.doc;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpStatus;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.entity.WmsSapPlant;
import com.maxnerva.cloudmes.entity.doc.WmsDocJitReceiveRecord;
import com.maxnerva.cloudmes.entity.doc.WmsDocReceive;
import com.maxnerva.cloudmes.entity.doc.WmsDocType;
import com.maxnerva.cloudmes.mapper.WmsSapPlantMapper;
import com.maxnerva.cloudmes.mapper.doc.WmsDocJitReceiveRecordMapper;
import com.maxnerva.cloudmes.mapper.doc.WmsDocReceiveMapper;
import com.maxnerva.cloudmes.mapper.doc.WmsDocTypeMapper;
import com.maxnerva.cloudmes.service.basic.CodeRuleService;
import com.maxnerva.cloudmes.service.sap.doc.DocRfcService;
import com.maxnerva.cloudmes.service.sap.doc.model.JitReceiptDto;
import com.maxnerva.cloudmes.service.sap.po.PoRfcService;
import com.maxnerva.cloudmes.service.sap.po.model.MfrInfoDto;
import com.maxnerva.cloudmes.service.sap.po.model.PoItemInfoDto;
import com.sap.conn.jco.JCoException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @ClassName JitDocService
 * @Description JITservice
 * @Date 2023/3/17
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Service
@Slf4j
public class DocJitReceiveRecordService {

    @Autowired
    private WmsDocJitReceiveRecordMapper wmsDocJitReceiveRecordMapper;

    @Autowired
    private CodeRuleService codeRuleService;

    @Autowired
    private WmsSapPlantMapper wmsSapPlantMapper;

    @Autowired
    private DocRfcService docRfcService;
    @Autowired
    private PoRfcService poRfcService;
    @Autowired
    private WmsDocReceiveMapper wmsDocReceiveMapper;
    @Autowired
    private WmsDocTypeMapper wmsDocTypeMapper;

    @Transactional
    public void syncJitDoc(String sapClientCode, String orgCode, String fromDate, String EndDate, String receiptNumber) {
        List<WmsSapPlant> wmsSapPlantList = wmsSapPlantMapper.selectList(Wrappers.<WmsSapPlant>lambdaQuery()
                .eq(WmsSapPlant::getOrgCode, orgCode));
        for (WmsSapPlant wmsSapPlant : wmsSapPlantList) {
            String plantCode = wmsSapPlant.getFactoryCode();
            List<JitReceiptDto> dtoList = docRfcService.doGetJITReceipt(sapClientCode,plantCode,fromDate,EndDate,receiptNumber);
            //保存导入记录
            for (JitReceiptDto jitDto : dtoList) {
                WmsDocJitReceiveRecord wmsDocJitReceiveRecord = new WmsDocJitReceiveRecord();
                BeanUtils.copyProperties(jitDto,wmsDocJitReceiveRecord);
                wmsDocJitReceiveRecord.setOrgCode(orgCode);
                wmsDocJitReceiveRecord.setPlantCode(jitDto.getPlant());
                wmsDocJitReceiveRecord.setDocCreateFlag("N");
                wmsDocJitReceiveRecord.setCreatedDt(LocalDateTime.now());
                wmsDocJitReceiveRecord.setCreator("sysadmin");
                wmsDocJitReceiveRecord.setLastEditor("sysadmin");
                wmsDocJitReceiveRecord.setLastEditedDt(LocalDateTime.now());
                wmsDocJitReceiveRecordMapper.insertJitReceiveRecord(wmsDocJitReceiveRecord);
                WmsDocJitReceiveRecord wmsDocJitReceiveRecordDB = wmsDocJitReceiveRecordMapper.selectOne(Wrappers.<WmsDocJitReceiveRecord>lambdaQuery()
                        .eq(WmsDocJitReceiveRecord::getOrgCode, wmsDocJitReceiveRecord.getOrgCode())
                        .eq(WmsDocJitReceiveRecord::getPlantCode, wmsDocJitReceiveRecord.getPlantCode())
                        .eq(WmsDocJitReceiveRecord::getReceiptNumber, wmsDocJitReceiveRecord.getReceiptNumber())
                        .last("limit 1"));
                if ("Y".equals(wmsDocJitReceiveRecordDB.getDocCreateFlag())) {
                    continue;
                }
                //查询po信息
                String poNumber = wmsDocJitReceiveRecordDB.getPoNumber();
                String poItem = getPoItem(wmsDocJitReceiveRecord.getPoItem());
                List<PoItemInfoDto> poItemInfoDtoList = CollUtil.newArrayList();
                try {
                    poItemInfoDtoList = poRfcService.doGetPoInfo(sapClientCode, poNumber, "x", "x");
                } catch (JCoException e) {
                    log.error("doGetPoInfo error : {}", e.getMessage());
                }
                PoItemInfoDto itemInfoDto = poItemInfoDtoList.stream()
                        .filter(poItemInfoDto -> poItem.equals(poItemInfoDto.getPoItem()))
                        .findFirst().orElse(null);
                String docCreateMsg = StrUtil.EMPTY;
                if (ObjectUtil.isNotNull(itemInfoDto)) {
                    wmsDocJitReceiveRecordDB.setPartVersion(itemInfoDto.getPartVersion());
                    wmsDocJitReceiveRecordDB.setPoDocumentType(itemInfoDto.getDocType());
                    wmsDocJitReceiveRecordDB.setPurchaseGroup(itemInfoDto.getPurchaseGroup());
                    wmsDocJitReceiveRecordDB.setPurchaseOrg(itemInfoDto.getPurchaseOrg());
                    wmsDocJitReceiveRecordDB.setMfgCode(itemInfoDto.getMfrCode());
                    wmsDocJitReceiveRecordDB.setMfgPartNo(itemInfoDto.getMfrPartNo());
                    wmsDocJitReceiveRecordDB.setSapWarehouseCode(itemInfoDto.getWarehouseCode());
                    wmsDocJitReceiveRecordDB.setAnalysisPoItem(poItem);
                    MfrInfoDto mfrInfoDto = null;
                    try {
                        mfrInfoDto = poRfcService.doGetMfrNameByCode(sapClientCode, itemInfoDto.getMfrCode());
                    } catch (JCoException e) {
                        log.error("doGetMfrNameByCode error : {}", e.getMessage());
                    }
                    if (ObjectUtil.isNull(mfrInfoDto) || StrUtil.isEmpty(mfrInfoDto.getMfrName())) {
                        docCreateMsg = docCreateMsg + "未找到mfrCode:" + itemInfoDto.getMfrCode() + "的制造商名称信息";
                    } else {
                        wmsDocJitReceiveRecordDB.setMfgName(mfrInfoDto.getMfrName());
                    }
                } else {
                    docCreateMsg = docCreateMsg + "poNumber:" + poNumber + "poItem:" + poItem + "不存在";
                }
                if (StrUtil.isNotEmpty(docCreateMsg)) {
                    wmsDocJitReceiveRecordDB.setDocCreateMsg(docCreateMsg);
                }
                wmsDocJitReceiveRecordMapper.updateById(wmsDocJitReceiveRecordDB);
            }
        }
        //查询导入记录中未建单成功并且没有错误信息的记录,准备新增JIT收货单
        List<WmsDocJitReceiveRecord> tradingDocImportRecordList = wmsDocJitReceiveRecordMapper.selectList(Wrappers.<WmsDocJitReceiveRecord>lambdaQuery()
                .eq(WmsDocJitReceiveRecord::getDocCreateFlag, "N")
                .isNull(WmsDocJitReceiveRecord::getDocCreateMsg));
        WmsDocType wmsDocTypeDb = wmsDocTypeMapper.selectOne(Wrappers.<WmsDocType>lambdaQuery()
                .eq(WmsDocType::getDocTypeCode, "JIT_RECEIVE_DOC"));
        for (WmsDocJitReceiveRecord wmsDocJitReceiveRecord : tradingDocImportRecordList) {
            Long count = wmsDocReceiveMapper.selectCount(Wrappers.<WmsDocReceive>lambdaQuery()
                    .eq(WmsDocReceive::getFromDocNo, wmsDocJitReceiveRecord.getReceiptNumber()));
            if (count > 0) {
                wmsDocJitReceiveRecord.setDocCreateMsg("receiptNumber已在WMS收货单中存在");
                wmsDocJitReceiveRecord.setDocCreateFlag("N");
                wmsDocJitReceiveRecordMapper.updateById(wmsDocJitReceiveRecord);
                continue;
            }
            //新增JIT收货单
            WmsDocReceive wmsDocReceive = new WmsDocReceive();
            BeanUtils.copyProperties(wmsDocJitReceiveRecord, wmsDocReceive);
            wmsDocReceive.setId(null);
            wmsDocReceive.setDocTypeCode("JIT_RECEIVE_DOC");
            wmsDocReceive.setFromDocNo(wmsDocJitReceiveRecord.getReceiptNumber());
            wmsDocReceive.setPoNo(wmsDocJitReceiveRecord.getPoNumber());
            wmsDocReceive.setPoItem(wmsDocJitReceiveRecord.getAnalysisPoItem());
            wmsDocReceive.setConfirmReceiptFlag(0);
            wmsDocReceive.setDocQty(wmsDocJitReceiveRecord.getQty());
            wmsDocReceive.setConfirmQty(wmsDocJitReceiveRecord.getQty());
            wmsDocReceive.setWmsDocTypeId(wmsDocTypeDb.getId());
            wmsDocReceive.setDocCategoryCode(wmsDocTypeDb.getDocCategoryCode());
            wmsDocReceive.setDocCreateDate(LocalDate.now());
            wmsDocReceive.setPostingMethodName(wmsDocTypeDb.getPostingMethodName());
            wmsDocReceive.setPostingSapMethodFlag(wmsDocTypeDb.getPostingSapFlag());
            wmsDocReceive.setDocTypeName(wmsDocTypeDb.getDocTypeName());
            wmsDocReceive.setPostingQmsFlag(wmsDocTypeDb.getPostingQmsFlag());
            wmsDocReceive.setDocStatus("NOT_RECEIVED");
            wmsDocReceive.setPlaceOfOrigin1("CN");
            wmsDocReceive.setWmsContent(JSONUtil.toJsonStr(wmsDocReceive));
            String docNo = StrUtil.EMPTY;
            HttpResponse httpResponse = codeRuleService.getCodeRule(orgCode);
            String body = httpResponse.body();
            if (httpResponse.getStatus() == HttpStatus.HTTP_OK) {
                JSONObject jsonObject = JSONUtil.parseObj(body);
                String code = jsonObject.getStr("code");
                if (StringUtils.isNotBlank(code) && "200".equalsIgnoreCase(code)) {
                    List<String> data = (List<String>) jsonObject.getObj("data");
                    docNo = data.get(0);
                }
            }
            if (StrUtil.isEmpty(docNo)) {
                wmsDocJitReceiveRecord.setDocCreateMsg("生成JIT收货单号异常");
                wmsDocJitReceiveRecord.setDocCreateFlag("N");
                wmsDocJitReceiveRecordMapper.updateById(wmsDocJitReceiveRecord);
                continue;
            } else {
                wmsDocJitReceiveRecord.setDocCreateFlag("Y");
                wmsDocJitReceiveRecordMapper.updateById(wmsDocJitReceiveRecord);
            }
            wmsDocReceive.setDocNo(docNo);
            wmsDocReceiveMapper.insert(wmsDocReceive);
        }
    }

    private String getPoItem(String poItem){
        //不以000开头的，补到三个0
        if (poItem.startsWith("000")){
            return poItem;
        }else if (poItem.startsWith("00")){
            return "0" + poItem;
        }else if (poItem.startsWith("0")){
            return  "00" + poItem;
        }else {
            return "000" + poItem;
        }
    }
}
