package com.maxnerva.cloudmes.service.sap.wo.model;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 工单备料DTO
 *
 * @author H7109018
 */
@Data
public class WorkOrderPostingDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 过账日期
     */
    private String postDate;

    /**
     * 过账日期
     */
    private String docDate;

    /**
     * 提交用户
     */
    private String userName;

    /**
     * Document Header Text
     */
    private String headerText;

    /**
     * 工厂
     */
    private String plant;

    /**
     * 料号
     */
    private String partNo;

    /**
     * 版次
     */
    private String partVersion;

    /**
     * 转出仓码
     */
    private String fromWarehouseName;

    /**
     * 移动类型 261/262 101/102
     */
    private String moveType;

    /**
     * GM_CODE Assign code to transaction for BAPI goods movement
     * 01:101/102 , 03:261/262
     */
    private String gmCode;


    /**
     * 移动数量
     */
    private BigDecimal qty;

    /**
     * 单位
     */
    private String unit;

    /**
     * 工单号
     */
    private String workOrderNo;

    /**
     * 项次
     */
    private String workOrderItem;

    /**
     * Number of reservation/dependent requirements
     */
    private String reservationNo;

    /**
     * Item Number of Reservation / Dependent Requirements
     */
    private String reservationItem;

    /**
     * MATERIAL_LONG
     */
    private String longPartNo;

    private String valueType;

}
