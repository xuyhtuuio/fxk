package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.TableName;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalTime;

/**
 * <p>
 * 过账锁定周期配置
 * </p>
 *
 * @author baomidou
 * @since 2024-09-12
 */
@TableName("wms_posting_schedule_lock_config")
@ApiModel(value = "WmsPostingScheduleLockConfig对象", description = "过账锁定周期配置")
@Data
public class WmsPostingScheduleLockConfig extends BaseEntity<WmsPostingScheduleLockConfig> {

    private static final long serialVersionUID = 1L;

    private Integer id;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("工厂")
    private String plantCode;

    @ApiModelProperty("开始日")
    private Integer startDay;

    @ApiModelProperty("开始时间")
    private LocalTime startTime;

    @ApiModelProperty("结束日")
    private Integer endDay;

    @ApiModelProperty("结束时间")
    private LocalTime endTime;

    @ApiModelProperty("过账类型")
    private String transactionType;

    @ApiModelProperty(value = "是否启用")
    private Boolean isEnable;

    @ApiModelProperty(value = "描述")
    private String description;
}
