package com.maxnerva.cloudmes.service.doc.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpStatus;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.entity.doc.WmsDocJitReceiveGrRecord;
import com.maxnerva.cloudmes.entity.doc.WmsDocJitReceiveRecord;
import com.maxnerva.cloudmes.entity.doc.WmsDocReceive;
import com.maxnerva.cloudmes.entity.doc.WmsDocType;
import com.maxnerva.cloudmes.mapper.doc.WmsDocJitReceiveGrRecordMapper;
import com.maxnerva.cloudmes.mapper.doc.WmsDocReceiveMapper;
import com.maxnerva.cloudmes.mapper.doc.WmsDocTypeMapper;
import com.maxnerva.cloudmes.service.basic.CodeRuleService;
import com.maxnerva.cloudmes.service.doc.IWmsDocJitReceiveGrRecordService;
import com.maxnerva.cloudmes.service.sap.po.PoRfcService;
import com.maxnerva.cloudmes.service.sap.po.model.MfrInfoDto;
import com.maxnerva.cloudmes.service.sap.po.model.PoItemInfoDto;
import com.sap.conn.jco.JCoException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * JIT收货GR记录表 服务实现类
 * </p>
 *
 * @author likun
 * @since 2025-02-11
 */
@Slf4j
@Service
public class WmsDocJitReceiveGrRecordServiceImpl extends ServiceImpl<WmsDocJitReceiveGrRecordMapper,
        WmsDocJitReceiveGrRecord> implements IWmsDocJitReceiveGrRecordService {

    @Resource
    private WmsDocReceiveMapper wmsDocReceiveMapper;

    @Resource
    private PoRfcService poRfcService;

    @Resource
    private WmsDocTypeMapper wmsDocTypeMapper;

    @Resource
    private CodeRuleService codeRuleService;

    @Override
    public void createJitDocReceive(String sapClientCode, String orgCode) {
        List<WmsDocJitReceiveGrRecord> wmsDocJitReceiveGrRecordList = baseMapper
                .selectList(Wrappers.<WmsDocJitReceiveGrRecord>lambdaQuery()
                        .eq(WmsDocJitReceiveGrRecord::getOrgCode, orgCode)
                        .eq(WmsDocJitReceiveGrRecord::getDocCreateFlag, "N"));
        if (CollUtil.isNotEmpty(wmsDocJitReceiveGrRecordList)) {
            for (WmsDocJitReceiveGrRecord wmsDocJitReceiveGrRecord : wmsDocJitReceiveGrRecordList) {
                String poNo = wmsDocJitReceiveGrRecord.getPoNo();
                String poItem = wmsDocJitReceiveGrRecord.getPoItem();
                List<PoItemInfoDto> poItemInfoDtoList = CollUtil.newArrayList();
                try {
                    poItemInfoDtoList = poRfcService.doGetPoInfo(sapClientCode, poNo, "x", "x");
                } catch (JCoException e) {
                    log.error("doGetPoInfo error : {}", e.getMessage());
                }
                PoItemInfoDto itemInfoDto = poItemInfoDtoList.stream()
                        .filter(poItemInfoDto -> poItem.equals(poItemInfoDto.getPoItem()))
                        .findFirst().orElse(null);
                String docCreateMsg = StrUtil.EMPTY;
                if (ObjectUtil.isNotNull(itemInfoDto)) {
                    wmsDocJitReceiveGrRecord.setPartDesc(itemInfoDto.getPartDesc());
                    wmsDocJitReceiveGrRecord.setVendorCode(itemInfoDto.getVendorCode());
                    wmsDocJitReceiveGrRecord.setUomCode(itemInfoDto.getUnit());
                    String partNo = itemInfoDto.getPartNo();
                    //解析料号的信息
                    int length = partNo.lastIndexOf("-");
                    String partNoVersion = partNo.substring(length + 1);
                    wmsDocJitReceiveGrRecord.setPartNo(partNo);
                    wmsDocJitReceiveGrRecord.setPartVersion(partNoVersion);
                    wmsDocJitReceiveGrRecord.setPoDocumentType(itemInfoDto.getDocType());
                    wmsDocJitReceiveGrRecord.setPurchaseGroup(itemInfoDto.getPurchaseGroup());
                    wmsDocJitReceiveGrRecord.setPurchaseOrg(itemInfoDto.getPurchaseOrg());
                    wmsDocJitReceiveGrRecord.setMfgName(itemInfoDto.getVendorCode());
                    wmsDocJitReceiveGrRecord.setMfgCode(itemInfoDto.getVendorCode());
                    wmsDocJitReceiveGrRecord.setMfgPartNo(partNo);
                    wmsDocJitReceiveGrRecord.setWarehouseCode(itemInfoDto.getWarehouseCode());
                } else {
                    docCreateMsg = docCreateMsg + "poNumber:" + poNo + "poItem:" + poItem + "不存在";
                }
                if (StrUtil.isNotEmpty(docCreateMsg)) {
                    wmsDocJitReceiveGrRecord.setDocCreateMsg(docCreateMsg);
                }
                baseMapper.updateById(wmsDocJitReceiveGrRecord);
            }
        }
        List<WmsDocJitReceiveGrRecord> docJitReceiveGrRecordList = baseMapper
                .selectList(Wrappers.<WmsDocJitReceiveGrRecord>lambdaQuery()
                        .eq(WmsDocJitReceiveGrRecord::getOrgCode, orgCode)
                        .eq(WmsDocJitReceiveGrRecord::getDocCreateFlag, "N")
                        .isNull(WmsDocJitReceiveGrRecord::getDocCreateMsg));
        WmsDocType wmsDocTypeDb = wmsDocTypeMapper.selectOne(Wrappers.<WmsDocType>lambdaQuery()
                .eq(WmsDocType::getDocTypeCode, "JIT_PN_RECEIVE_DOC"));
        for (WmsDocJitReceiveGrRecord docJitReceiveGrRecord : docJitReceiveGrRecordList) {
            Long count = wmsDocReceiveMapper.selectCount(Wrappers.<WmsDocReceive>lambdaQuery()
                    .eq(WmsDocReceive::getFromDocNo, docJitReceiveGrRecord.getAsnNo()));
            if (count > 0) {
                docJitReceiveGrRecord.setDocCreateMsg("ASN NO已在WMS收货单中存在");
                docJitReceiveGrRecord.setDocCreateFlag("N");
                baseMapper.updateById(docJitReceiveGrRecord);
                continue;
            }
            //新增JIT收货单
            WmsDocReceive wmsDocReceive = new WmsDocReceive();
            BeanUtils.copyProperties(docJitReceiveGrRecord, wmsDocReceive);
            wmsDocReceive.setId(null);
            wmsDocReceive.setDocTypeCode("JIT_PN_RECEIVE_DOC");
            wmsDocReceive.setFromDocNo(docJitReceiveGrRecord.getAsnNo());
            wmsDocReceive.setSapWarehouseCode(docJitReceiveGrRecord.getWarehouseCode());
            wmsDocReceive.setPartNoVersion(docJitReceiveGrRecord.getPartVersion());
            wmsDocReceive.setFromDocItem("1");
            wmsDocReceive.setPoNo(docJitReceiveGrRecord.getPoNo());
            wmsDocReceive.setPoItem(docJitReceiveGrRecord.getPoItem());
            wmsDocReceive.setConfirmReceiptFlag(1);
            wmsDocReceive.setDocQty(docJitReceiveGrRecord.getQty());
            wmsDocReceive.setConfirmQty(docJitReceiveGrRecord.getQty());
            wmsDocReceive.setOperateQty(docJitReceiveGrRecord.getQty());
            wmsDocReceive.setWmsDocTypeId(wmsDocTypeDb.getId());
            wmsDocReceive.setDocCategoryCode(wmsDocTypeDb.getDocCategoryCode());
            wmsDocReceive.setDocCreateDate(LocalDate.now());
            wmsDocReceive.setPostingMethodName(wmsDocTypeDb.getPostingMethodName());
            wmsDocReceive.setPostingSapMethodFlag(wmsDocTypeDb.getPostingSapFlag());
            wmsDocReceive.setDocTypeName(wmsDocTypeDb.getDocTypeName());
            wmsDocReceive.setPostingQmsFlag(wmsDocTypeDb.getPostingQmsFlag());
            wmsDocReceive.setDocStatus("SHELF_COMPLETED");
            wmsDocReceive.setPlaceOfOrigin1("CN");
            wmsDocReceive.setConfirmDocDate(LocalDateTime.now());
            wmsDocReceive.setSapReturnNumber(docJitReceiveGrRecord.getGrNumber());
            wmsDocReceive.setSapReturnMessage("OK");
            wmsDocReceive.setInspectResult("Y");
            wmsDocReceive.setEta(LocalDate.now());
            wmsDocReceive.setWmsContent(JSONUtil.toJsonStr(wmsDocReceive));
            String docNo = StrUtil.EMPTY;
            HttpResponse httpResponse = codeRuleService.getCodeRule(orgCode);
            String body = httpResponse.body();
            if (httpResponse.getStatus() == HttpStatus.HTTP_OK) {
                JSONObject jsonObject = JSONUtil.parseObj(body);
                String code = jsonObject.getStr("code");
                if (StringUtils.isNotBlank(code) && "200".equalsIgnoreCase(code)) {
                    List<String> data = (List<String>) jsonObject.getObj("data");
                    docNo = data.get(0);
                }
            }
            if (StrUtil.isEmpty(docNo)) {
                docJitReceiveGrRecord.setDocCreateMsg("生成JIT收货单号异常");
                docJitReceiveGrRecord.setDocCreateFlag("N");
                baseMapper.updateById(docJitReceiveGrRecord);
                continue;
            } else {
                docJitReceiveGrRecord.setDocCreateFlag("Y");
                baseMapper.updateById(docJitReceiveGrRecord);
            }
            wmsDocReceive.setDocNo(docNo);
            wmsDocReceiveMapper.insert(wmsDocReceive);
        }
    }
}
