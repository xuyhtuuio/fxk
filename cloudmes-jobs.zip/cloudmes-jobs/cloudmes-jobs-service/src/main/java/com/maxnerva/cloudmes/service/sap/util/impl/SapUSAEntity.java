/*
package com.maxnerva.cloudmes.service.sap.util.impl;

import com.maxnerva.cloudmes.service.sap.util.SapPoolService;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.ext.DestinationDataProvider;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.Properties;

*/
/**
 * @author H7109018
 *//*

@Component("sapusa")
@ConfigurationProperties(prefix = "sapusa.pool")
@Data
public class SapUSAEntity implements SapPoolService {
    private String host;
    private String client;
    private String sysnr;
    private String user;
    private String password;
    private String lang;
    private String limit;
    private String poolCapacity;
    private String poolName;
    private String maxGetTime;
    private String expirationTime;
    private String expirationPeriod;

    @Override
    public JCoDestination getSapPool() {
        Properties connectProperties = new Properties();
        connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, host);
        connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, client);
        connectProperties.setProperty(DestinationDataProvider.JCO_USER, user);
        connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, password);
        connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR, sysnr);
        connectProperties.setProperty(DestinationDataProvider.JCO_LANG, lang);
        //最大连接数 30
        connectProperties.setProperty(DestinationDataProvider.JCO_PEAK_LIMIT, limit);
        //目的地保持打开状态的最大空闲连接数。值为0表示没有连接池（默认值= 1） 1
        connectProperties.setProperty(DestinationDataProvider.JCO_POOL_CAPACITY, poolCapacity);
        //達到最大連接後的等待時間 10S
        connectProperties.setProperty(DestinationDataProvider.JCO_MAX_GET_TIME, maxGetTime);
        //可以关闭目标内部建立的免费连接之后的时间（以毫秒为单位）。 5m
        connectProperties.setProperty(DestinationDataProvider.JCO_EXPIRATION_TIME, expirationTime);
        //目标检查释放的连接是否到期后的周期（以毫秒为单位）。 10s
        connectProperties.setProperty(DestinationDataProvider.JCO_EXPIRATION_PERIOD, expirationPeriod);

        return generateSapPool(poolName, connectProperties);
    }
}
*/
