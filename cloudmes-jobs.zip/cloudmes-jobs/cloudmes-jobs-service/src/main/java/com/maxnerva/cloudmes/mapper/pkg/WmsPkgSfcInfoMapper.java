package com.maxnerva.cloudmes.mapper.pkg;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.pkg.WmsPkgSfcInfoEntity;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author Chao Zhang
 * @since 2022-12-09
 */
public interface WmsPkgSfcInfoMapper extends BaseMapper<WmsPkgSfcInfoEntity> {

    List<WmsPkgSfcInfoEntity> selectSfcInfoList(@Param("orgCode") String orgCode,
                                                @Param("mesDataSource") String mesDataSource);
}
