package com.maxnerva.cloudmes.service.sfc.model;

import lombok.Data;

/**
 * @ClassName InsertAmazonLogDto
 * @Description TODO
 * @Author Likun
 * @Date 2023/1/9
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Data
public class InsertAmazonLogDto {

    private String demandType;

    private String amazonId;

    private String requestId;

    private String buildTriggerId;

    private String assetId;

    private Integer qty;

    private String iPn;

    private String assetCategory;

    private String testItem;

    private String itemDescription;

    private String siteCode;

    private String inStockHub;

    private String manufacturingStartDate;

    private String estimatedReadyDate;

    private String comments;
}
