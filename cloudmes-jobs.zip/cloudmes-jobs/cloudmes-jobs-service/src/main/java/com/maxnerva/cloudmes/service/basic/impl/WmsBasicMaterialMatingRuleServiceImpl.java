package com.maxnerva.cloudmes.service.basic.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.entity.basic.WmsBasicMaterialMatingRule;
import com.maxnerva.cloudmes.mapper.basic.WmsBasicMaterialMatingRuleMapper;
import com.maxnerva.cloudmes.service.basic.IWmsBasicMaterialMatingRuleService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 物料配套使用规则 服务实现类
 * </p>
 *
 * @author likun
 * @since 2024-12-23
 */
@Service
public class WmsBasicMaterialMatingRuleServiceImpl extends ServiceImpl<WmsBasicMaterialMatingRuleMapper,
        WmsBasicMaterialMatingRule> implements IWmsBasicMaterialMatingRuleService {

}
