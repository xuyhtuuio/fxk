package com.maxnerva.cloudmes.service.qms;

import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.json.JSONUtil;
import com.maxnerva.cloudmes.service.qms.model.ReceiveIqcDataVo;
import com.maxnerva.cloudmes.service.user.UserService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/11/09 10:32
 * @Version: 1.0
 */
@Service
@Slf4j
public class QmsService {

    @Value("${cloudmes.service.url}")
    private String qmsServiceUrl;

    @Autowired
    UserService userService;

    public HttpResponse postQmsReceiveDoc(List<ReceiveIqcDataVo> docList) {

        Map<String,String> headers = userService.getUserToken();
        String userToken = headers.get("token");
        String uuid = headers.get("uuid");
        if (StringUtils.isBlank(userToken)) {
            log.error("postQmsReceiveDoc get user token error");
        }

        String url = qmsServiceUrl + "/cloudmes-qms/iqcMain/receiveIqcData";
        HttpResponse response = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .header("Authorization", userToken)
                .header("uuid",uuid)
                .setConnectionTimeout(30 * 1000)
                .body(JSONUtil.toJsonStr(docList))
                .execute();

        return response;

    }
}
