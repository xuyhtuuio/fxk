package com.maxnerva.cloudmes.service.basic;

import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import com.maxnerva.cloudmes.service.user.UserService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * @ClassName CodeRuleService
 * @Description TODO
 * @Author Likun
 * @Date 2023/2/6
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Service
@Slf4j
public class CodeRuleService {


    @Value("${cloudmes.service.url}")
    private String basicServiceUrl;

    @Autowired
    UserService userService;

    public HttpResponse getCodeRule(String orgCode){
        Map<String,String> headers = userService.getUserToken();
        String userToken = headers.get("token");
        String uuid = headers.get("uuid");
        if (StringUtils.isBlank(userToken)) {
            log.error("getCodeRule get user token error");
        }
        String url = basicServiceUrl + "/cloudmes-basic/codeRule/getSerialNumberByOrgCode";
        HttpResponse response = HttpRequest.get(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .header("Authorization", userToken)
                .header("uuid",uuid)
                .setConnectionTimeout(30 * 1000)
                .form("argType","WMS_DOC_RECEIVE_NO")
                .form("num","1")
                .form("orgCode",orgCode)
                .execute();
        return response;
    }

    public HttpResponse getSerialNumber(String argType, Integer num){
        Map<String,String> headers = userService.getUserToken();
        String userToken = headers.get("token");
        String uuid = headers.get("uuid");
        if (StringUtils.isBlank(userToken)) {
            log.error("getCodeRule get user token error");
        }
        String url = basicServiceUrl + "/cloudmes-basic/codeRule/getSerialNumber";
        HttpResponse response = HttpRequest.get(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .header("Authorization", userToken)
                .header("uuid",uuid)
                .setConnectionTimeout(30 * 1000)
                .form("argType",argType)
                .form("num",num)
                .execute();
        return response;
    }
}
