package com.maxnerva.cloudmes.mapper.wo;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderPickLog;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;

/**
 * 捡料记录表 表数据库访问层
 *
 * @author hgx
 * @since 2023-09-15
 */
public interface WmsWorkOrderPickLogMapper extends BaseMapper<WmsWorkOrderPickLog>{

    void updatePkgEndDate(@Param("orgCode") String orgCode,
                          @Param("mfg") String mfg,
                          @Param("mfgMaterialNo") String mfgMaterialNo,
                          @Param("validPeriod") BigDecimal validPeriod);

}

