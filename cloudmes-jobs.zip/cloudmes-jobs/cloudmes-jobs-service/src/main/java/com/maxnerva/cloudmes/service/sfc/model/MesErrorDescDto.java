package com.maxnerva.cloudmes.service.sfc.model;

import io.swagger.annotations.ApiModel;
import lombok.Data;

@ApiModel("MES返回不良原因")
@Data
public class MesErrorDescDto {
    private String isLeaf;
    private String errorCodeType;
    private String errorCode;
    private String errorName;
    private String location;
    private String desc;
    private Integer customerId;
    private Integer customerCode;
    private Integer deleteReason;
    private Integer errorType;
}
