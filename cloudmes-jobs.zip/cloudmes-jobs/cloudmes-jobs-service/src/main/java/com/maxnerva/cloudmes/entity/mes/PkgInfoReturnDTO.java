package com.maxnerva.cloudmes.entity.mes;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * <p>
 * PKG信息表
 * </p>
 *
 * @author hej
 * @since 2023-01-30
 */
@Data
@ApiModel(value = "PkgInfoReturnDTO", description = "PkgInfoReturnDTO")
public class PkgInfoReturnDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    @NotBlank(message = "pkgId不能为空")
    @ApiModelProperty("pkgId")
    private String pkgId;

    @NotNull(message = "退库数量不能为空")
    @ApiModelProperty("退库数量")
    private BigDecimal returnQty;

    @NotBlank(message = "组织代码不能为空")
    @ApiModelProperty("组织代码")
    private String orgCode;

}
