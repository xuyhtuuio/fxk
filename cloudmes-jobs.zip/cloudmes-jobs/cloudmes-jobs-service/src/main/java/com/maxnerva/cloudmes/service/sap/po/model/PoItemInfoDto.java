package com.maxnerva.cloudmes.service.sap.po.model;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author H7109018
 */
@Data
public class PoItemInfoDto implements Serializable {

    private static final long serialVersionUID = -1L;

    //PO 类型
    private String docType;
    //采购组织
    private String purchaseOrg;
    private String purchaseGroup;
    private String poNumber;
    private String poItem;
    private String partNo;
    private String partVersion;
    private String partDesc;
    private String plantCode;
    private String warehouseCode;
    private BigDecimal quantity;
    private String unit;
    private String poDate;
    private String closeStatus;
    private BigDecimal receivedQty;
    private String mfrPartNo;
    private String mfrName;
    private String mfrCode;
    private String vendorCode;
    private String vendorName;
}
