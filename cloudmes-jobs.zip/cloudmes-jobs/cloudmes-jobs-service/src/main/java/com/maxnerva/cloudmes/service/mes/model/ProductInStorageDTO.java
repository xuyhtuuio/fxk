package com.maxnerva.cloudmes.service.mes.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

/**
 * @ClassName ProductInStorageDTO
 * @Description 成品入库dto
 * @Author Likun
 * @Date 2022/11/16
 * @Version 1.0
 * @Since JDK 1.8
 **/
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel("成品入库dto")
@Data
public class ProductInStorageDTO {

    @ApiModelProperty("库位编码")
    private String locationCode;

    @ApiModelProperty("储位编码")
    private String binCode;

    @ApiModelProperty("栈板号")
    private String palletNo;

    @ApiModelProperty("栈板数量")
    private BigDecimal qty;

    @ApiModelProperty("入库工单信息")
    private List<InStorageWoDTO> inStorageWoDTOList;

    @ApiModelProperty("成品料号")
    private String partNo;

    @ApiModelProperty("载具编码")
    private String vehicleCode;
}
