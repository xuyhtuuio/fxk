package com.maxnerva.cloudmes.service.jusda.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/12/07 13:40
 * @Version: 1.0
 */
@Data
public class Edi846RequestDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String SiteName;
    private String UserName;
    private String PassWord;
    private String CustomerNo;


}
