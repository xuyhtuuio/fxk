package com.maxnerva.cloudmes.mapper.wo;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.wo.WmsSapTransactionLog;

/**
 * <p>
 * 过账sap记录表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2022-08-30
 */
public interface WmsSapTransactionLogMapper extends BaseMapper<WmsSapTransactionLog> {

}
