package com.maxnerva.cloudmes.service.prepare.wo;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.entity.wo.WmsBomFeeder;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderDetail;
import com.maxnerva.cloudmes.mapper.wo.WmsBomFeederMapper;
import com.maxnerva.cloudmes.mapper.wo.WmsWorkOrderDetailMapper;
import com.maxnerva.cloudmes.models.newProcess.dto.wo.BomFeederRequiredDTO;
import com.maxnerva.cloudmes.service.sfc.SfcStoredProcedureFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @ClassName IWoService
 * @Description 工单管理service
 * @Author Likun
 * @Date 2022/8/30
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Service
@Slf4j
public class WoService {


    @Autowired
    WmsWorkOrderDetailMapper workOrderDetailMapper;

    @Autowired
    WmsBomFeederMapper wmsBomFeederMapper;

    @Autowired
    SfcStoredProcedureFactory bomFeederFactory;

    /**
     * 修改群组主料需求量：取工单中part_no_type  = 'M'的需求量最大的值
     * 修改是否合盘物料：工单群组物料中存在在上料表中且 part_no_type  = 'M'则修改整个群组为合盘物料
     * 修改是否烧录、烧录值、制程分类：取上料表中spare_part_no=wo detail料号的值
     */
    @Transactional(rollbackFor = Exception.class)
    public void writeWoDetailInfo(String orgCode, String workOrderNo) {
        List<WmsWorkOrderDetail> wmsWorkOrderDetailList = workOrderDetailMapper.selectList(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
                .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                .eq(WmsWorkOrderDetail::getWorkOrderNo, workOrderNo));
        if (CollUtil.isEmpty(wmsWorkOrderDetailList)) {
            return;
        }
        //初始化工单detail数据
        workOrderDetailMapper.update(null, Wrappers.<WmsWorkOrderDetail>lambdaUpdate()
                .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                .eq(WmsWorkOrderDetail::getWorkOrderNo, workOrderNo)
                .set(WmsWorkOrderDetail::getRequiredPkgQty, BigDecimal.ZERO)   //需求量
                .set(WmsWorkOrderDetail::getMergeFlag, "N") //是否合盘物料
//                .set(WmsWorkOrderDetail::getIsBurn, Boolean.FALSE)  //是否烧录物料
//                .set(WmsWorkOrderDetail::getBurnValue, null)    //烧录值
//                .set(WmsWorkOrderDetail::getCutOffFlag, "N")
        );    //是否剪角物料

        //根据工单群组分组
        Map<String, List<WmsWorkOrderDetail>> collect = wmsWorkOrderDetailList.stream()
                .collect(Collectors.groupingBy(WmsWorkOrderDetail::getWorkOrderItem));
        for (Map.Entry<String, List<WmsWorkOrderDetail>> entry : collect.entrySet()) {
            List<WmsWorkOrderDetail> wmsWorkOrderDetails = entry.getValue();
            //群组料号list
            List<String> partNoList = wmsWorkOrderDetails.stream().map(workOrderDetail -> workOrderDetail.getPartNo()).collect(Collectors.toList());
            //修改主料号需求量（PTH、ASSY、A类物料为1盘）
            updateMainRequired(wmsWorkOrderDetails, partNoList);
            //修改群组为合盘物料
            updateMergeFlag(wmsWorkOrderDetails, partNoList);
            for (WmsWorkOrderDetail wmsWorkOrderDetail : wmsWorkOrderDetails) {
                //修改是否烧录、烧录值
                updateIsBurn(wmsWorkOrderDetail);
                //修改制程分类
                updateProductProcess(wmsWorkOrderDetail);
            }
        }
    }

    private void updateProductProcess(WmsWorkOrderDetail workOrderDetail) {
        String orgCode = workOrderDetail.getOrgCode();
        String workOrderNo = workOrderDetail.getWorkOrderNo();
        String partNo = workOrderDetail.getPartNo();
        WmsWorkOrderDetail wmsWorkOrderDetail = workOrderDetailMapper.selectById(workOrderDetail.getId());
        WmsBomFeeder processWmsBomFeeder = wmsBomFeederMapper.selectOne(Wrappers.<WmsBomFeeder>lambdaQuery()
                .eq(WmsBomFeeder::getOrgCode, orgCode)
                .eq(WmsBomFeeder::getWorkOrderNo, workOrderNo)
                .eq(WmsBomFeeder::getSparePartNo, partNo)
                .last("limit 1"));
        if (ObjectUtil.isNotNull(processWmsBomFeeder)) {
            String bomProcess = "PTH".equals(processWmsBomFeeder.getMaterialProductProcess())
                    ? "ASSY" : processWmsBomFeeder.getMaterialProductProcess();
            String processType = bomProcess;
            if (bomProcess.equals("SMT")) {
                if (wmsWorkOrderDetail.getIsBurn()) {
                    processType = "SMT-BURN";
                } else if ("Y".equalsIgnoreCase(wmsWorkOrderDetail.getMergeFlag())) {
                    processType = "SMT-MARGE";
                } else if ("Y".equalsIgnoreCase(wmsWorkOrderDetail.getCutOffFlag())) {
                    processType = "SMT-CUT";
                }
            }
            workOrderDetailMapper.update(null, Wrappers.<WmsWorkOrderDetail>lambdaUpdate()
                    .eq(WmsWorkOrderDetail::getId, workOrderDetail.getId())
                    .set(WmsWorkOrderDetail::getMaterialProductProcess, bomProcess)
                    .set(WmsWorkOrderDetail::getMaterialProductType, processType));
        }
    }

    private void updateIsBurn(WmsWorkOrderDetail workOrderDetail) {
        String orgCode = workOrderDetail.getOrgCode();
        String workOrderNo = workOrderDetail.getWorkOrderNo();
        String partNo = workOrderDetail.getPartNo();
        WmsBomFeeder wmsBomFeeder = wmsBomFeederMapper.selectOne(Wrappers.<WmsBomFeeder>lambdaQuery()
                .eq(WmsBomFeeder::getOrgCode, orgCode)
                .eq(WmsBomFeeder::getWorkOrderNo, workOrderNo)
                .eq(WmsBomFeeder::getIsBurn, Boolean.TRUE)
                .eq(WmsBomFeeder::getSparePartNo, partNo)
                .last("limit 1"));
        if (ObjectUtil.isNotNull(wmsBomFeeder)) {
            workOrderDetailMapper.update(null, Wrappers.<WmsWorkOrderDetail>lambdaUpdate()
                    .eq(WmsWorkOrderDetail::getId, workOrderDetail.getId())
                    .set(WmsWorkOrderDetail::getIsBurn, wmsBomFeeder.getIsBurn())
                    .set(WmsWorkOrderDetail::getBurnValue, wmsBomFeeder.getBurnValue()));
        }
    }

    private void updateMergeFlag(List<WmsWorkOrderDetail> wmsWorkOrderDetailList, List<String> partNoList) {
        String orgCode = wmsWorkOrderDetailList.get(0).getOrgCode();
        String workOrderNo = wmsWorkOrderDetailList.get(0).getWorkOrderNo();
        String workOrderItem = wmsWorkOrderDetailList.get(0).getWorkOrderItem();
        //筛选工单满足合盘条件的上料信息
        List<WmsBomFeeder> mergeBomFeederList = wmsBomFeederMapper.selectList(Wrappers.<WmsBomFeeder>lambdaQuery()
                .eq(WmsBomFeeder::getOrgCode, orgCode)
                .eq(WmsBomFeeder::getWorkOrderNo, workOrderNo)
                .eq(WmsBomFeeder::getMergeFlag, "Y")
                .eq(WmsBomFeeder::getPartNoType, "M")
                .in(WmsBomFeeder::getSparePartNo, partNoList));
        //修改群组为合盘物料
        if (mergeBomFeederList.size() > 0) {
            workOrderDetailMapper.update(null, Wrappers.<WmsWorkOrderDetail>lambdaUpdate()
                    .eq(WmsWorkOrderDetail::getOrgCode, orgCode)
                    .eq(WmsWorkOrderDetail::getWorkOrderNo, workOrderNo)
                    .eq(WmsWorkOrderDetail::getWorkOrderItem, workOrderItem)
                    .set(WmsWorkOrderDetail::getMergeFlag, "Y"));
        }
    }

    private void updateMainRequired(List<WmsWorkOrderDetail> wmsWorkOrderDetailList, List<String> partNoList) {
        String orgCode = wmsWorkOrderDetailList.get(0).getOrgCode();
        String workOrderNo = wmsWorkOrderDetailList.get(0).getWorkOrderNo();
        //选出主料
        WmsWorkOrderDetail wmsWorkOrderDetail = wmsWorkOrderDetailList.stream()
                .filter(workOrderDetail -> "M".equals(workOrderDetail.getPartRelationship()))
                .findFirst().orElse(null);
        if (ObjectUtil.isNull(wmsWorkOrderDetail)) {
            return;
        }
        //最大需求盘数
        BigDecimal qty = BigDecimal.ZERO;
        //PTH、ASSY、A类物料为1盘
        if ("A".equalsIgnoreCase(wmsWorkOrderDetail.getMaterialType())
                || "PTH".equalsIgnoreCase(wmsWorkOrderDetail.getMaterialProductProcess())
                || "ASSY".equalsIgnoreCase(wmsWorkOrderDetail.getMaterialProductProcess())) {
            qty = BigDecimal.ONE;
        } else {
            //取群组里需求量最大的写到wo detail 主料号中
            List<BomFeederRequiredDTO> requiredDTOList = wmsBomFeederMapper.getRequiredLsit(orgCode, workOrderNo, partNoList);
            if (CollUtil.isEmpty(requiredDTOList)) {
                return;
            }
            BomFeederRequiredDTO requiredDTO = requiredDTOList.stream().max(Comparator.comparing(BomFeederRequiredDTO::getQty)).get();
            qty = requiredDTO.getQty();
        }
        //修改主料的需求量
        workOrderDetailMapper.update(null, Wrappers.<WmsWorkOrderDetail>lambdaUpdate()
                .eq(WmsWorkOrderDetail::getId, wmsWorkOrderDetail.getId())
                .set(WmsWorkOrderDetail::getRequiredPkgQty, qty));
    }
}
