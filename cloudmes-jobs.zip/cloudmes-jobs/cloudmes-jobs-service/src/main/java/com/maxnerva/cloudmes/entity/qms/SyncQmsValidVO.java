package com.maxnerva.cloudmes.entity.qms;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName SyncQmsValidVO
 * @Description TODO
 * @Author Likun
 * @Date 2024/11/27
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("同步qms有效期vo")
@Data
public class SyncQmsValidVO {

    @ApiModelProperty(value = "厂商")
    private String mfg;

    @ApiModelProperty(value = "厂商料号")
    private String mfgMaterialNo;

    @ApiModelProperty(value = "期限")
    private String deadline;

    @ApiModelProperty("组织")
    private String orgCode;

}
