package com.maxnerva.cloudmes.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.basic.WmsBin;

/**
 * <p>
 * 储位表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2022-07-22
 */
public interface WmsBinMapper extends BaseMapper<WmsBin> {

}
