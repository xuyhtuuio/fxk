package com.maxnerva.cloudmes.service.sap.po.model;

import lombok.Data;

import java.io.Serializable;

/**
 * 创建SO、DN item入参DTO
 *
 * @author H7109018
 */
@Data
public class CreateDnItemInputDto implements Serializable {

    private static final long serialVersionUID = -1L;

    /**
     * itemNumber
     */
    private String itemNumber;

    /**
     * partNo
     */
    private String partNo;

    /**
     * 版次
     */
    private String partVersion;

    /**
     * valueType
     */
    private String valueType;

    /**
     * plant
     */
    private String plantCode;

    /**
     * 仓码
     * TJ仓码
     */
    private String warehouseCode;

    /**
     * 数量
     */
    private String qty;

}
