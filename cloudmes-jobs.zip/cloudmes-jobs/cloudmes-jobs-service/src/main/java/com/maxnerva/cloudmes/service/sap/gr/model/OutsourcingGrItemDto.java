package com.maxnerva.cloudmes.service.sap.gr.model;

import lombok.Data;

import java.io.Serializable;

/**
 * 委外收货 DTO item
 *
 * @author H7109018
 */
@Data
public class OutsourcingGrItemDto implements Serializable {

    private static final long serialVersionUID = -1L;

    /**
     * 料号
     */
    private String partNo;

    /**
     * 版次
     */
    private String partVersion;

    /**
     * 工厂
     */
    private String plantCode;

    /**
     * 仓码
     */
    private String warehouseCode;

    /**
     * SAP 异动类型
     */
    private String movType;

    /**
     * vendor
     */
    private String vendorCode;

    /**
     * valueType
     */
    private String valueType;

    /**
     * 数量
     */
    private String qty;

    /**
     * 单位
     */
    private String bom;

    /**
     * po number
     */
    private String poNo;

    /**
     * po item
     */
    private String poItem;

    /**
     * ？？
     * 成品  B
     * 原物料 空
     */
    private String mvtInd;

    /**
     * lineID
     */
    private String lineId;


    /**
     * PARENT_ID
     */
    private String parentId;

    /**
     * matDocItem
     */
    private String matDocItem;

    /**
     * serial No
     */
    private String serialNo;

    /**
     * outSourcingDetailId
     */
    private Integer detailId;



}
