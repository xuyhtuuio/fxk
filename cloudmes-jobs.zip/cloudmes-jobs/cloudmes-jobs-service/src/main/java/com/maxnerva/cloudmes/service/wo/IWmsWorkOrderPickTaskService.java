package com.maxnerva.cloudmes.service.wo;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderPickTask;

/**
 * <p>
 * 捡料任务表 服务类
 * </p>
 *
 * @author likun
 * @since 2023-07-11
 */
public interface IWmsWorkOrderPickTaskService extends IService<WmsWorkOrderPickTask> {

}
