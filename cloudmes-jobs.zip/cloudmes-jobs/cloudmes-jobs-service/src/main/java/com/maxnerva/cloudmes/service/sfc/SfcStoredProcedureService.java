package com.maxnerva.cloudmes.service.sfc;

import com.maxnerva.cloudmes.entity.wo.WmsBomFeeder;
import com.maxnerva.cloudmes.service.sfc.model.*;

import java.util.List;
import java.util.Map;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/09/02 09:05
 * @Version: 1.0
 */
public interface SfcStoredProcedureService {

    /**
     * 取 SFC 上料表
     *
     * @param partNo
     * @param lineNo
     * @param processType
     * @return
     */
    List<WmsBomFeeder> getWmsBomFeeder(String partNo, String lineNo, String processType,
                                       String orgCode, String plantCode);

    /**
     * 抛PKG info资料给SFC
     *
     * @param postPkgInfoToSfcDto
     * @return
     */
    String postingSfcPkgInfo(PostPkgInfoToSfcDto postPkgInfoToSfcDto,
                             String orgCode, String plantCode);

    /**
     * 取PKG 状态值
     *
     * @param pkgStatusInfoDto
     * @return
     */
    PkgStatusInfoDto getPkgStatusInfo(PkgStatusInfoDto pkgStatusInfoDto, String orgCode,
                                      String plantCode);

    /**
     * from SFC 取成品入库栈板信息
     *
     * @param barcode
     * @return
     */
    List<SfcPalletInfoDto> getSfcPalletInfo(String barcode, String orgCode, String plantCode);


    /**
     * 退料時返回該PKGID中接料的清單
     *
     * @param pkgId
     * @return
     */
    List<PkgLinkListDto> getPkgLinkList(String pkgId);


    /**
     * WMS退料时调用此接口, 需要清除零数盘的丝印,LCR状态 及物料下线(SMT,PTH)
     *
     * @param pkgId
     * @param currentQty
     * @return
     */
    String clearPkgStatusToSfc(String pkgId, String currentQty, String orgCode, String plantCode);

    /**
     * 回写DN、SN的绑定关系  (只EPD6需要)
     *
     * @param snDnRelationshipDto
     * @return
     */
    String sendSnDnRelationshipToSfc(String orgCode, String plantCode, String mrpArea, SnDnRelationshipDto snDnRelationshipDto);

    /**
     * 入库sn 回写SFC过账工站
     *
     * @param warehousingPassSnStationDto
     * @return
     */
    String doWarehousingPassSnStation(WarehousingPassSnStationDto warehousingPassSnStationDto,
                                      String orgCode, String plantCode);


    /**
     * 取SFC SN扩展信息
     *
     * @param sn
     * @return
     */
    Map getSfcExtendInfoBySn(String sn);


    String insertAmazonLog(InsertAmazonLogDto amazonLogDto);

    String sendProductShippingToSfc(PostProductShippingToSfcDto toSfcDto);

    /**
     * 取SFC pkg上线使用信息
     *
     * @param startDateTime
     * @return
     */
    List<SfcWoUsePkgInfoDto> getSfcWoUsePkgInfo(String startDateTime);

    Map getPkgRelation(String pkgId);

    SfcWoDto getSfcWoInfo(String sn);

    List<SfcCartonInfoDTO> getSfcPalletInfoByCartonNo(String cartonNo, String orgCode, String plantCode);

    String getSfcErrorDesc(String orgCode, String plantCode, String errorCode);

    String getWoNoByPkgId(String orgCode, String plantCode, String pkgId);

    List<SfcBurnValueDto> getSFCBurnValue(String productPartNo);

    List<String> getSFCPkgId(String orgCode, String plantCode, String pkgId);
}
