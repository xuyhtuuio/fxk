package com.maxnerva.cloudmes.service.sfc.model;

import lombok.Data;

import java.io.Serializable;


@Data
public class SfcBurnValueDto implements Serializable {


    private static final long serialVersionUID = 1L;
    /**
     * SAP品料号
     */
    private String sapPn;
    /**
     * 鸿海料号
     */
    private String hhPn;
    /**
     * 制造商料号
     */
    private String mfgPn;

    /**
     * 烧录值
     */
    private String checkSum;

    /**
     * SFC成品料号
     */
    private String modelPn;

    /**
     * SFC成品版次
     */
    private String modelRev;

}
