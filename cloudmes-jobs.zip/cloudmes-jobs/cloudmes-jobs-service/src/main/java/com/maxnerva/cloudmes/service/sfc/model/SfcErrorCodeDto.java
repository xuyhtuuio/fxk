package com.maxnerva.cloudmes.service.sfc.model;

import lombok.Data;

/**
 * @Author hgx
 * @Description SFC返回不良原因DTO
 * @Date 2023/6/30
 */
@Data
public class SfcErrorCodeDto {
    private String badReason;
}
