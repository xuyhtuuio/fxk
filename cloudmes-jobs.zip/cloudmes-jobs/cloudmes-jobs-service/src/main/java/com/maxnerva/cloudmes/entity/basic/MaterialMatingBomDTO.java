package com.maxnerva.cloudmes.entity.basic;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author hj
 * @since 2024-12-02
 */
@Getter
@Setter
@ApiModel(value = "MaterialMatingBomDTO", description = "MaterialMatingBomDTO")
public class MaterialMatingBomDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("产品料号")
    private String productNo;

    @ApiModelProperty("零件料号")
    private String componentNo;

    @ApiModelProperty("项次")
    private String item;

    @ApiModelProperty("生产分类")
    private String productType;

    @ApiModelProperty("制造商名称")
    private String mfgName;

    @ApiModelProperty("配套组")
    private String matingGroup;

    @ApiModelProperty("制造商料号")
    private String mfgPn;

    @ApiModelProperty("配套标记")
    private String mark;

    private String orgCode;

}
