package com.maxnerva.cloudmes.mapper.datacenter;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.datacenter.WmsPostFiiLog;

public interface WmsPostFiiLogMapper extends BaseMapper<WmsPostFiiLog> {
}
