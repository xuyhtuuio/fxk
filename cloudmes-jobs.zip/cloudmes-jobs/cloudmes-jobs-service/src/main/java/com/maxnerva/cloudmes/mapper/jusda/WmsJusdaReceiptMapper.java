package com.maxnerva.cloudmes.mapper.jusda;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.jusda.WmsJusdaReceiptEntity;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Chao Zhang
 * @since 2022-11-22
 */
public interface WmsJusdaReceiptMapper extends BaseMapper<WmsJusdaReceiptEntity> {

}
