package com.maxnerva.cloudmes.service.jusda.model;

import lombok.Data;

import java.util.List;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2023/04/21 18:16
 * @Version: 1.0
 */
@Data
public class CreateAsnListDto {
    private String asnStatus;
    private String buyerCompanyCode;
    private String vendorCompanyCode;
    private String incoterms;
    private Integer shippingDate;
    private Long expectArrivalWarehouseDate;
    private String referenceNo;
    private String remark;
    private TransportationInputDto transportationInputDTO;
    private List<AttachmentsDto> attachments;
    private List<CreateAsnItemDetailListDto> createAsnItemDetailList;
}
