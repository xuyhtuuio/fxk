package com.maxnerva.cloudmes.mapper.tencent;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.tencent.DeliverySnBindDTO;
import com.maxnerva.cloudmes.entity.tencent.WmsTencentDeliverySnBindRecord;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 腾讯订单sn绑定记录表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2025-05-21
 */
public interface WmsTencentDeliverySnBindRecordMapper extends BaseMapper<WmsTencentDeliverySnBindRecord> {

    List<DeliverySnBindDTO> selectDeliverySnBindRecordList(@Param("orgCode") String orgCode,
                                                           @Param("shipDetailId") Integer shipDetailId);

}
