package com.maxnerva.cloudmes.service.aps.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2023/06/09 08:38
 * @Version: 1.0
 */
@Data
public class ApsContentDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String ItemID;
    private String APSDate;
    private String Plant;
    private String Line;
    private String HHPN;
    private String Module;
    private String Description;
    private String CardsPerPanel;
    private String PanelType;
    private String WO;
    private String WOQty;
    private String APSQty;
    private String Priority;
    private String BeginTime;
    private String EndTime;

}
