package com.maxnerva.cloudmes.service.doc;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.config.Constants;
import com.maxnerva.cloudmes.entity.doc.WmsDocAdjust;
import com.maxnerva.cloudmes.mapper.doc.WmsDocAdjustMapper;
import com.maxnerva.cloudmes.service.sap.material.MaterialRfcService;
import com.maxnerva.cloudmes.service.sap.wh.WhRfcService;
import com.maxnerva.cloudmes.service.sap.wh.model.TransferDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * @ClassName 料调据过账服务
 * @Description 工单管理service
 * @Author Likun
 * @Date 2022/8/30
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Service
@Slf4j
public class AdjustDocPostingService {

    @Autowired
    WmsDocAdjustMapper docAdjustMapper;

    @Autowired
    WhRfcService whRfcService;

    @Autowired
    MaterialRfcService materialRfcService;


    /**
     * 料调单过账SAP 309
     */
    public void docAdjustPosting(String sapClientCode, String orgCode, List<String> indentifyList,String postDate) {

        if("N".equalsIgnoreCase(postDate)){
            return;
        }

        //需过账DOC adjust list
        List<WmsDocAdjust> docList = docAdjustMapper.selectList(Wrappers.<WmsDocAdjust>lambdaQuery()
                .eq(WmsDocAdjust::getOrgCode, orgCode)
                .eq(WmsDocAdjust::getIsUpload, "0")
                .in(WmsDocAdjust::getIdentify, indentifyList)
        );

        if (CollUtil.isEmpty(docList)) {
            return;
        }

        docList.forEach(w -> {
            try {
                if ("N".equalsIgnoreCase(Constants.continueJob)) {
                    return;
                }
                // 仓码 + 料号 取value type from sap
                log.info("TransferPosting content: %S", JSONUtil.toJsonStr(w));
               /* //如果组织为CABG_VN,则赋值版次为A
                if ("CABG_VN".equals(orgCode)) {
                    w.setOldMaterialVersion("A");
                    w.setTargetMaterialVersion("A");
                }*/
                // 仓码 + 料号 取value type from sap
//                String target = materialRfcService.doGetMaterialValueType(sapClientCode, w.getOldPlantCode(), w.getTargetMaterialCode(), w.getTargetWarehoseCode());
                String target = materialRfcService.getValueType(sapClientCode, orgCode, w.getOldPlantCode(),
                        w.getTargetMaterialCode(), w.getTargetMaterialVersion(), w.getTargetWarehoseCode());
//                String old = materialRfcService.doGetMaterialValueType(sapClientCode, w.getOldPlantCode(), w.getOldMaterialCode(), w.getOldWarehoseCode());
                String old = materialRfcService.getValueType(sapClientCode, orgCode, w.getOldPlantCode(),
                        w.getOldMaterialCode(), w.getOldMaterialVersion(), w.getOldWarehoseCode());
                if (StringUtils.isBlank(old)) {
                    String error = String.format("TransferDoc[%s] warehouseCode [%s] partNo [%s] not found value type from SAP", w.getId(), w.getOldWarehoseCode(),
                            w.getOldMaterialCode());
                    log.error(error);
                    throw new RuntimeException("not found value type from SAP");
                }
                if (StringUtils.isBlank(target)) {
                    String error = String.format("TransferDoc[%s] warehouseCode [%s] partNo [%s] not found value type from SAP", w.getId(), w.getTargetWarehoseCode(),
                            w.getTargetMaterialCode());
                    log.error(error);
                    throw new RuntimeException("not found value type from SAP");
                }
                TransferDto dto = setTransfer309Dto(w,postDate);
                dto.setValueType(old);
                dto.setMoveValueType(target);
                //posting 309
                String s = whRfcService.doTransfer(sapClientCode, dto);
                log.info("AdjustPosting success content: %S , sap result: %s", JSONUtil.toJsonStr(w), s);

                // update doc sap result
                WmsDocAdjust updateDetail = new WmsDocAdjust();
                updateDetail.setId(w.getId());
                updateDetail.setIsUpload("1");
                updateDetail.setSapReturnMessage("OK");
                updateDetail.setSapReturnNumber(s);
                updateDetail.setSapReturnResult(target);
                updateDetail.setSapUploadData(new Date());
                updateDetail.updateById();

            } catch (Exception e) {
                // update doc sap result
                WmsDocAdjust updateDetail = new WmsDocAdjust();
                updateDetail.setId(w.getId());
                updateDetail.setSapReturnMessage(e.getMessage());
                updateDetail.setSapUploadData(new Date());
                updateDetail.updateById();
                log.error("AdjustPosting error doc {} ,errorMsg:{}", JSONUtil.toJsonStr(w), e.getMessage());

            }
        });


    }

    private TransferDto setTransfer309Dto(WmsDocAdjust w,String postDate) {
        TransferDto dto = new TransferDto();
        dto.setTransactionDate(postDate);
        dto.setDocDate(postDate);
        //301 夸工厂转仓   04
        //311 同工厂转仓   04
        //309 料调        04
        dto.setMoveType("309");
        dto.setGmCode("04");
        //默认 NOCOST
        //dto.setValueType("COSTRM");
        dto.setQty(w.getConfirmPostingQty().toString());
        dto.setUnit(StringUtils.isNotBlank(w.getUom()) ? w.getUom() : "EA");
        dto.setFromPlant(w.getOldPlantCode());
        dto.setFromWarehouseName(w.getOldWarehoseCode());
        dto.setFromPartNo(w.getOldMaterialCode());
        if (StringUtils.isNotBlank(w.getOldMaterialVersion())) {
            dto.setFromPartVersion(w.getOldMaterialVersion());
//            dto.setToPartVersion(w.getOldMaterialVersion());
            dto.setToPartVersion(w.getTargetMaterialVersion());
        }
        dto.setToPlant(w.getTargetPlantCode());
        dto.setToWarehouseName(w.getTargetWarehoseCode());
        dto.setToPartNo(w.getTargetMaterialCode());
        return dto;
    }

}
