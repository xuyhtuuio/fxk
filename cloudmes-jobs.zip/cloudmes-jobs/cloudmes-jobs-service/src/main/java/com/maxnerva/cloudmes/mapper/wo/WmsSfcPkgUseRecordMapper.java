package com.maxnerva.cloudmes.mapper.wo;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.wo.WmsSfcPkgUseRecordEntity;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author Chao Zhang
 * @since 2023-01-11
 */
public interface WmsSfcPkgUseRecordMapper extends BaseMapper<WmsSfcPkgUseRecordEntity> {

    int insertSfcPkgUseInfo(WmsSfcPkgUseRecordEntity wmsSfcPkgUseRecordEntity);

    String getSyncStartTime(String orgCode);
}
