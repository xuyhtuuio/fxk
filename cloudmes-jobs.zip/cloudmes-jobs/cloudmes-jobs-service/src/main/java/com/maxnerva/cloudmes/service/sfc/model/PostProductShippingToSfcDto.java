package com.maxnerva.cloudmes.service.sfc.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description:
 * @Author: hgx
 * @Date: 2022/09/20 09:09
 * @Version: 1.0
 */
@Data
public class PostProductShippingToSfcDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 员工号
     */
    private String emp;
    /**
     * 出货方式
     */
    private String vehicle;
    /**
     * DN
     */
    private String dn;
    /**
     * 目的地
     */
    private String destination;
    /**
     * 箱号
     */
    private String carton;
    /**
     *  固定值=SHIPPING
     */
    private String mygroup;
    private String orgCode;


    private String cusName;

    private String dnFlag;

    private String po;
}
