package com.maxnerva.cloudmes.component.vn;

import com.maxnerva.cloudmes.service.basic.PostingConfigService;
import com.maxnerva.cloudmes.service.doc.AdjustDocPostingService;
import com.maxnerva.cloudmes.service.doc.CostDocPostingService;
import com.maxnerva.cloudmes.service.doc.ReceiveDocPostingService;
import com.maxnerva.cloudmes.service.doc.TransferDocPostingService;
import com.maxnerva.cloudmes.service.jusda.JusdaService;
import com.maxnerva.cloudmes.service.mes.PostingMesService;
import com.maxnerva.cloudmes.service.sfc.PostingSfcService;
import com.maxnerva.cloudmes.service.wo.WmsBadPostingService;
import com.maxnerva.cloudmes.service.wo.WoPostingNewModeService;
import com.maxnerva.cloudmes.service.wo.WorkOrderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Arrays;

/**
 * @author H7109018
 */
@ConditionalOnProperty(value = "schedule.scope", havingValue = "F_VN")
@Component
@EnableScheduling
@Slf4j
public class NVDVNPostingSapSchedule {

    private static final String ORG_CODE = "NVD_VN";
    private static final String SAP_CLIENT_CODE = "sapvn";
    private static String postDate = "N";

    @Autowired
    WoPostingNewModeService woPostingNewModeService;

    @Autowired
    PostingConfigService postingConfigService;

    @Autowired
    JusdaService jusdaService;

    @Autowired
    CostDocPostingService costDocPostingService;

    @Autowired
    WmsBadPostingService wmsBadPostingService;

    @Autowired
    PostingSfcService postingSfcService;

    @Autowired
    AdjustDocPostingService adjustDocPostingService;

    @Autowired
    TransferDocPostingService transferDocPostingService;

    @Autowired
    ReceiveDocPostingService docPostingService;

    @Autowired
    WorkOrderService workOrderService;

    @Autowired
    PostingMesService postingMesService;

    @Scheduled(initialDelay = 5000, fixedDelay = 300000)
    public void updatePostDate() {
        log.info("NVDVNupdatePostDate start :" + System.currentTimeMillis());
        String s = postingConfigService.getPostDate(ORG_CODE, null);
        log.info("NVDVNupdatePostDate end :" + System.currentTimeMillis());
        postDate = s;
    }

    /**
     * CKD工单过账311
     * 频率：10分钟执行一次
     */
    @Scheduled(initialDelay = 20000, fixedDelay = 600000)
    public void postingCkdWoDetail311NewModeTest() {
        log.info("postingCkdWoDetail311NewModeTest start :" + System.currentTimeMillis());
        woPostingNewModeService.postingCkdWoDetail311NewMode(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingCkdWoDetail311NewModeTest end :" + System.currentTimeMillis());
    }

    /**
     * 工单备料量过账261
     * 频率：10分钟执行一次
     */
    @Scheduled(initialDelay = 15000, fixedDelay = 600000)
    public void postingWoDetail261NewModeTest() {
        //工单备料量过账261
        log.info("postingWoDetail261NewModeTest start :" + System.currentTimeMillis());
        woPostingNewModeService.postingWoDetail261NewMode(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoDetail261NewModeTest end :" + System.currentTimeMillis());

        //工单退料量过账262
        log.info("postingWoDetail262NewModeTest start :" + System.currentTimeMillis());
        woPostingNewModeService.postingWoDetail262NewMode(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoDetail262NewModeTest end :" + System.currentTimeMillis());

        //工单移出量过账 262
        log.info("postingWoRemove262NewModeTest start :" + System.currentTimeMillis());
        woPostingNewModeService.postingWoRemove262NewMode(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoRemove262NewModeTest end :" + System.currentTimeMillis());

        //工单移入量过账 261
        log.info("postingWoMoveIn261NewModeTest start :" + System.currentTimeMillis());
        woPostingNewModeService.postingWoMoveIn261NewMode(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoMoveIn261NewModeTest end :" + System.currentTimeMillis());

        //重工工单过账SAP 531
        log.info("postingWoDetail531NewMode start :" + System.currentTimeMillis());
        woPostingNewModeService.postingWoDetail531NewMode(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoDetail531NewMode end :" + System.currentTimeMillis());

        //不良品退料过账
        log.info("postingReturnBadGoods start :" + System.currentTimeMillis());
        wmsBadPostingService.postingReturnBadGoods(ORG_CODE, postDate);
        log.info("postingReturnBadGoods end :" + System.currentTimeMillis());

        //报废入库过账311
        log.info("postingScrap311 start :" + System.currentTimeMillis());
        woPostingNewModeService.postingScrap311(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingScrap311 end :" + System.currentTimeMillis());

        //不良品QMS领用过账到QMS仓码 311
        log.info("scrapPostingQmsWarehouseCodeBy311 start :" + System.currentTimeMillis());
        woPostingNewModeService.scrapPostingQmsWarehouseCodeBy311(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("scrapPostingQmsWarehouseCodeBy311 end :" + System.currentTimeMillis());

        //不良品QMS退回过账至指定仓码 311
        log.info("scrapPostingQmsReturnBy311 start :" + System.currentTimeMillis());
        woPostingNewModeService.scrapPostingQmsReturnBy311(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("scrapPostingQmsReturnBy311 end :" + System.currentTimeMillis());
    }


    /**
     * 工单成品入库 101
     * 频率：10分钟执行一次
     */
    @Scheduled(initialDelay = 10000, fixedDelay = 600000)
    public void postingWoHeader101Test() {
        log.info("postingWoHeader101Test start :" + System.currentTimeMillis());
        woPostingNewModeService.postingWoHeader101(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoHeader101Test end :" + System.currentTimeMillis());

    }

    /**
     * 费领退单过账
     * 频率：10分钟执行一次
     */
    @Scheduled(initialDelay = 30000, fixedDelay = 600000)
    public void costAllDocTransferPosting() {
        log.info("costNVDVNDocTransferPosting start :" + System.currentTimeMillis());
        costDocPostingService.costDocTransferPosting(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("costNVDVNDocTransferPosting end :" + System.currentTimeMillis());
    }


    /**
     * 成品出货抛出货明细到sfc
     */
    @Scheduled(initialDelay = 50000, fixedDelay = 300000)
    public void insertAmazonLog() {
        log.info("insertAmazonLogToSfc start :" + System.currentTimeMillis());
        postingSfcService.insertAmazonLog(ORG_CODE);
        log.info("insertAmazonLogToSfc end:" + System.currentTimeMillis());
    }

    /**
     * 回写DN、SN的绑定关系
     */
    @Scheduled(initialDelay = 60000, fixedDelay = 600000)
    public void sendSnDnRelationshipToSfc() {
        log.info("sendSnDnRelationshipToSfc start :" + System.currentTimeMillis());
        postingSfcService.sendSnDnRelationshipToSfc(ORG_CODE);
        log.info("sendSnDnRelationshipToSfc end:" + System.currentTimeMillis());
    }


    /**
     * 同步SN扩展信息 DEL
     */
    @Scheduled(initialDelay = 80000, fixedDelay = 900000)
    public void syncSfcExtendInfoBySn() {
        log.info("syncSfcExtendInfoBySn start :" + System.currentTimeMillis());
        postingSfcService.syncSfcExtendInfoBySn(ORG_CODE);
        log.info("syncSfcExtendInfoBySn end:" + System.currentTimeMillis());
    }

    /**
     * 工单备料PKG信息抛SFC
     */
    @Scheduled(initialDelay = 90000, fixedDelay = 300000)
    public void postingWoPreparePkgInfoToSFC() {
        log.info("postingWoPreparePkgInfoToSFC start :" + System.currentTimeMillis());
        postingSfcService.postingWoPreparePkgInfoToSFC(ORG_CODE);
        log.info("postingWoPreparePkgInfoToSFC end:" + System.currentTimeMillis());
    }


    /**
     * 料调单过账
     */
    @Scheduled(initialDelay = 120000, fixedDelay = 600000)
    public void docAdjustPosting() {
        log.info("docAdjustPosting start :" + System.currentTimeMillis());
        adjustDocPostingService.docAdjustPosting(SAP_CLIENT_CODE, ORG_CODE, Arrays.asList("5"), postDate);
        log.info("docAdjustPosting end :" + System.currentTimeMillis());
    }

    /**
     * 转仓单过账
     */
    @Scheduled(initialDelay = 130000, fixedDelay = 900000)
    public void docTransferPosting() {
        log.info("docTransferPosting start :" + System.currentTimeMillis());
        transferDocPostingService.docTransferPosting(SAP_CLIENT_CODE, ORG_CODE, Arrays.asList("5"), postDate);
        log.info("docTransferPosting end :" + System.currentTimeMillis());
    }

    /**
     * 收货单据确认且不需要抛Q需要过账的直接入良品仓良品状态
     */
    @Scheduled(initialDelay = 140000, fixedDelay = 900000)
    public void docPostingToGoodProduct() {
        log.info("docPostingToGoodProduct start :" + System.currentTimeMillis());
        docPostingService.docPostingToGoodProduct(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("docPostingToGoodProduct end :" + System.currentTimeMillis());
    }

    /**
     * 收货单据确认收货后转良品仓待验状态
     */
    @Scheduled(initialDelay = 150000, fixedDelay = 900000)
    public void postingToBeInspected() {
        log.info("postingToBeInspected start :" + System.currentTimeMillis());
        docPostingService.docPostingToBeInspected(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("postingToBeInspected end :" + System.currentTimeMillis());
    }

    /**
     * 收货单据，QMS有返回结果后转良品仓良品状态
     */
    @Scheduled(initialDelay = 160000, fixedDelay = 900000)
    public void postingGoodProductStatus() {
        log.info("postingGoodProductStatus start :" + System.currentTimeMillis());
        docPostingService.docPostingGoodProductStatus(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("postingGoodProductStatus end :" + System.currentTimeMillis());
    }

    /**
     * 工单合备分备料
     * 频率：10分钟执行一次
     */
    @Scheduled(initialDelay = 170000, fixedDelay = 600000)
    public void divideMergeOrderPrepare() {
        log.info("divideMergeOrderPrepare start :" + System.currentTimeMillis());
        workOrderService.divideMergeOrderPrepare(ORG_CODE);
        log.info("divideMergeOrderPrepare end :" + System.currentTimeMillis());
    }

    /**
     * 工单合备分退料
     * 频率：10分钟执行一次
     */
    @Scheduled(initialDelay = 180000, fixedDelay = 600000)
    public void divideMergeOrderReturn() {
        log.info("divideMergeOrderReturn start :" + System.currentTimeMillis());
        workOrderService.divideMergeOrderReturn(ORG_CODE);
        log.info("divideMergeOrderReturn end :" + System.currentTimeMillis());
    }

    /**
     * 内交单过账
     */
    @Scheduled(initialDelay = 190000, fixedDelay = 600000)
    public void tradingPosting() {
        log.info("getTradingNVDVNStatus start :" + System.currentTimeMillis());
        String s = postingConfigService.getTradingStatus(ORG_CODE, null);
        log.info("getTradingNVDVNStatus end :" + System.currentTimeMillis());
        if ("N".equalsIgnoreCase(s)) {
            return;
        }
        //内交出过账
        log.info("tradingPosting start :" + System.currentTimeMillis());
        docPostingService.tradingPosting(ORG_CODE, postDate);
        log.info("tradingPosting end :" + System.currentTimeMillis());

        //PGI
        log.info("tradingPosting start :" + System.currentTimeMillis());
        docPostingService.tradingPGI(ORG_CODE, postDate);
        log.info("tradingPosting end :" + System.currentTimeMillis());

        //内交入过账
        log.info("doTradingInPosting start :" + System.currentTimeMillis());
        docPostingService.doTradingInPosting(ORG_CODE, postDate);
        log.info("doTradingInPosting end :" + System.currentTimeMillis());
    }

    /**
     * 同步MSD
     */
    @Scheduled(initialDelay = 200000, fixedDelay = 300000)
    public void syncMsd() {
        //pkg_info同步MSD
        log.info("syncMsdPkgInfo start :" + System.currentTimeMillis());
        postingMesService.syncMsdPkgInfo(ORG_CODE);
        log.info("syncMsdPkgInfo end :" + System.currentTimeMillis());

        //pick_log同步MSD
        log.info("syncMsdPickLog start :" + System.currentTimeMillis());
        postingMesService.syncMsdPickLog(ORG_CODE);
        log.info("syncMsdPickLog end :" + System.currentTimeMillis());

        //prepare_log同步MSD
        log.info("syncMsdPrepareLog start :" + System.currentTimeMillis());
        postingMesService.syncMsdPrepareLog(ORG_CODE);
        log.info("syncMsdPrepareLog end :" + System.currentTimeMillis());
    }

    /**
     * 更新三锡三剂类型工单明细扣账信息
     */
//    @Scheduled(initialDelay = 210000, fixedDelay = 900000)
    public void updateAmWoDetailStockInfo() {
        log.info("updateAmWoDetailStockInfo start :" + System.currentTimeMillis());
        workOrderService.updateAmWoDetailStockInfo(ORG_CODE);
        log.info("updateAmWoDetailStockInfo end :" + System.currentTimeMillis());
    }
}
