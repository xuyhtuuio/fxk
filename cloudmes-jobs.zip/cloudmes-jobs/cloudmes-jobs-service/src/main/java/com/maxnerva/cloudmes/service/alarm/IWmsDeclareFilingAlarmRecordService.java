package com.maxnerva.cloudmes.service.alarm;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.entity.alarm.WmsDeclareFilingAlarmRecord;

/**
 * <p>
 * 备案预警表 服务类
 * </p>
 *
 * @author likun
 * @since 2023-12-19
 */
public interface IWmsDeclareFilingAlarmRecordService extends IService<WmsDeclareFilingAlarmRecord> {

    void sendMailBatch(String orgCode);
}
