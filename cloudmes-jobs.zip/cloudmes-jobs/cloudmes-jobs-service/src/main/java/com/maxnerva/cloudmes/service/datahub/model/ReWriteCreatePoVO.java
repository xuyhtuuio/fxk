package com.maxnerva.cloudmes.service.datahub.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("回写创建POVO")
public class ReWriteCreatePoVO {

    private Integer id;

    @ApiModelProperty("PoNo1")
    private String poNo1;

    @ApiModelProperty("PoNo2")
    private String poNo2;

    @ApiModelProperty("PoNo2")
    private String poPostSapFlag;

    @ApiModelProperty("创建PO信息")
    private String poPostSapMsg;
}
