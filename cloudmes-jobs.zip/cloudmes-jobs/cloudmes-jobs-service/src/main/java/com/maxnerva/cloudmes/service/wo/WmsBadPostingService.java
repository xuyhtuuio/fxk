package com.maxnerva.cloudmes.service.wo;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.NumberUtil;
import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.config.Constants;
import com.maxnerva.cloudmes.entity.WmsSapPlant;
import com.maxnerva.cloudmes.entity.scrap.WmsBadProductInStorageEntity;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderDetail;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderDetailInStorage;
import com.maxnerva.cloudmes.mapper.WmsSapPlantMapper;
import com.maxnerva.cloudmes.mapper.wo.WmsBadProductInStorageMapper;
import com.maxnerva.cloudmes.mapper.wo.WmsWorkOrderDetailInStorageMapper;
import com.maxnerva.cloudmes.mapper.wo.WmsWorkOrderDetailMapper;
import com.maxnerva.cloudmes.service.sap.material.MaterialRfcService;
import com.maxnerva.cloudmes.service.sap.wh.WhRfcService;
import com.maxnerva.cloudmes.service.sap.wh.model.TransferDto;
import com.maxnerva.cloudmes.service.sap.wo.WoRfcService;
import com.maxnerva.cloudmes.service.sap.wo.model.WorkOrderPostingDto;
import com.maxnerva.cloudmes.service.wo.model.PostingSap101ReturnDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * @Description: 不良品过账服务
 * @Author: Chao Zhang
 * @Date: 2023/07/08 14:40
 * @Version: 1.0
 */
@Service
@Slf4j
public class WmsBadPostingService {

    @Autowired
    WmsBadProductInStorageMapper wmsBadProductInStorageMapper;

    @Autowired
    MaterialRfcService materialRfcService;

    @Autowired
    WoRfcService woRfcService;

    @Autowired
    WhRfcService whRfcService;

    @Autowired
    WmsWorkOrderDetailMapper wmsWorkOrderDetailMapper;

    @Autowired
    WmsWorkOrderDetailInStorageMapper wmsWorkOrderDetailInStorageMapper;

    @Autowired
    WmsSapPlantMapper wmsSapPlantMapper;

    /**
     * 不良品退料过账
     */
    public void postingReturnBadGoods(String orgCode, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }

        //需过账list
        List<WmsBadProductInStorageEntity> postingList = wmsBadProductInStorageMapper.selectList(Wrappers.<WmsBadProductInStorageEntity>lambdaQuery()
                .eq(WmsBadProductInStorageEntity::getOrgCode, orgCode)
                .ne(WmsBadProductInStorageEntity::getOperationType, "REPAIR_SCRAP")
                .last(" and (post_sap_no is null or post_sap_no  = '0')  and ((operation_type  = 'BAD_REPLACEMENT' and status  = '2') or (operation_type  != 'BAD_REPLACEMENT' and status  = '1'))"));

        if (CollUtil.isEmpty(postingList)) {
            return;
        }

        List<WmsSapPlant> plantList = wmsSapPlantMapper.selectList(Wrappers.<WmsSapPlant>lambdaQuery().eq(WmsSapPlant::getOrgCode, orgCode));

        postingList.forEach(w -> {

            if (Constants.continueJob.equalsIgnoreCase("N")) {
                return;
            }

            Optional<WmsSapPlant> curPlant = plantList.stream().filter(a -> a.getFactoryCode().equalsIgnoreCase(w.getPlantCode())).findFirst();

            if (!curPlant.isPresent()) {
                doError(w, "plant is error");
                return;
            }

            String sapClient = curPlant.get().getErpInterface();

            try {
                switch (w.getOperationType()) {
                    case "BAD_RETURN":
                    case "PROCESS_SCRAP":
                        //不良退料 262
                        //制程报废   262
                        doPost262(w, postDate, sapClient);
                        break;
                    case "BAD_REPLACEMENT":
                        // 不良品置換 311
                        doPost311(w, postDate, sapClient);
                        break;
                    case "POOR_DISASSEMBLY":
                        // 拆解不良  531
                        doPost531(w, postDate, sapClient);
                        break;
                    default:
                        //error 不支持的类型
                        doError(w, "Unsupported type");
                }

            } catch (Exception e) {
                doError(w, e.getMessage());
            }
        });
    }

    private void doPost262(WmsBadProductInStorageEntity s, String postDate, String sapClient) {

        // 找工单detail
        WmsWorkOrderDetail woDetailInfo = wmsWorkOrderDetailMapper.selectOne(Wrappers.<WmsWorkOrderDetail>lambdaQuery()
                .eq(WmsWorkOrderDetail::getOrgCode, s.getOrgCode())
                .eq(WmsWorkOrderDetail::getWorkOrderNo, s.getWorkOrderNo())
                .eq(WmsWorkOrderDetail::getFromWarehouseCode, s.getGoodWarehouseCode())
                .eq(WmsWorkOrderDetail::getPartNo, s.getPartNo())
                .gt(WmsWorkOrderDetail::getBadInStorageQty, 0d)
                .last(" limit 1")
        );

        if (ObjectUtil.isNull(woDetailInfo)) {
            wmsBadProductInStorageMapper.update(null, Wrappers.<WmsBadProductInStorageEntity>lambdaUpdate()
                    .eq(WmsBadProductInStorageEntity::getId, s.getId())
                    .set(WmsBadProductInStorageEntity::getPostSapDate, LocalDateTime.now())
                    .set(WmsBadProductInStorageEntity::getPostSapMsg, "wo detail not exist"));
            return;
        }

        try {
            WorkOrderPostingDto input = new WorkOrderPostingDto();
            input.setPostDate(postDate);
            input.setDocDate(postDate);
            input.setUserName("WMS");
            input.setHeaderText("");
            input.setPlant(s.getPlantCode());
            input.setPartNo(s.getPartNo());
            input.setLongPartNo(s.getPartNo());
            /*//如果组织为CABG_VN,则赋值版次为A
            if ("CABG_VN".equals(s.getOrgCode())) {
                input.setPartVersion("A");
            } else {
                input.setPartVersion("");
            }*/
            WmsSapPlant sapPlant = wmsSapPlantMapper.selectOne(Wrappers.<WmsSapPlant>lambdaQuery()
                    .eq(WmsSapPlant::getOrgCode, s.getOrgCode())
                    .last("limit 1"));
            String enableVersion = sapPlant.getEnableVersion();
            input.setPartVersion("Y".equals(enableVersion) ? s.getPartVersion() : "");
            input.setFromWarehouseName(s.getBadWarehouseCode());
            input.setMoveType("262");
            input.setGmCode("03");
            input.setUnit("EA");
            input.setQty(s.getInStorageQty());

            String valueType = materialRfcService.doGetMaterialValueType(sapClient, s.getPlantCode(), s.getPartNo(), s.getBadWarehouseCode());

            if (StringUtils.isEmpty(valueType)) {
                wmsBadProductInStorageMapper.update(null, Wrappers.<WmsBadProductInStorageEntity>lambdaUpdate()
                        .eq(WmsBadProductInStorageEntity::getId, s.getId())
                        .set(WmsBadProductInStorageEntity::getPostSapDate, LocalDateTime.now())
                        .set(WmsBadProductInStorageEntity::getPostSapMsg, "value type not exist"));
                return;
            }

            input.setValueType(valueType);
            input.setWorkOrderNo(s.getWorkOrderNo());
            input.setReservationNo(woDetailInfo.getReservationNumber());
            input.setReservationItem(woDetailInfo.getReservationItem());

            PostingSap101ReturnDto post262Dto = woRfcService.doWorkOrderPosting(sapClient, input);

            wmsBadProductInStorageMapper.update(null, Wrappers.<WmsBadProductInStorageEntity>lambdaUpdate()
                    .eq(WmsBadProductInStorageEntity::getId, s.getId())
                    .set(WmsBadProductInStorageEntity::getPostSapDate, LocalDateTime.now())
                    .set(WmsBadProductInStorageEntity::getPostSapQty, s.getInStorageQty())
                    .set(WmsBadProductInStorageEntity::getPostSapNo, post262Dto.getDocNumber())
                    .set(WmsBadProductInStorageEntity::getPostSapMsg, "OK"));

            WmsWorkOrderDetail updateDetail = new WmsWorkOrderDetail();
            updateDetail.setId(woDetailInfo.getId());
            updateDetail.setPostTo262Qty(NumberUtil.add(woDetailInfo.getPostTo262Qty(), s.getInStorageQty()));
            updateDetail.setBadPostSapQty(NumberUtil.add(woDetailInfo.getBadPostSapQty(), s.getInStorageQty()));
            updateDetail.setPost262Msg(post262Dto.getDocNumber() + " - " + LocalDateTime.now());
            updateDetail.updateById();

        } catch (Exception e) {
            wmsBadProductInStorageMapper.update(null, Wrappers.<WmsBadProductInStorageEntity>lambdaUpdate()
                    .eq(WmsBadProductInStorageEntity::getId, s.getId())
                    .set(WmsBadProductInStorageEntity::getPostSapDate, LocalDateTime.now())
                    .set(WmsBadProductInStorageEntity::getPostSapNo, "0")
                    .set(WmsBadProductInStorageEntity::getPostSapMsg, e.getMessage()));
        }
    }


    private void doPost531(WmsBadProductInStorageEntity s, String postDate, String sapClient) {

        //531 不良品入库数量
        WmsWorkOrderDetailInStorage woDetailInfo = wmsWorkOrderDetailInStorageMapper.selectOne(Wrappers.<WmsWorkOrderDetailInStorage>lambdaQuery()
                .eq(WmsWorkOrderDetailInStorage::getOrgCode, s.getOrgCode())
                .eq(WmsWorkOrderDetailInStorage::getWorkOrderNo, s.getWorkOrderNo())
                .eq(WmsWorkOrderDetailInStorage::getSapWarehouseCode, s.getGoodWarehouseCode())
                .eq(WmsWorkOrderDetailInStorage::getPartNo, s.getPartNo())
                .gt(WmsWorkOrderDetailInStorage::getBadInStorageQty, 0d)
                .last(" limit 1")
        );

        if (ObjectUtil.isNull(woDetailInfo)) {
            wmsBadProductInStorageMapper.update(null, Wrappers.<WmsBadProductInStorageEntity>lambdaUpdate()
                    .eq(WmsBadProductInStorageEntity::getId, s.getId())
                    .set(WmsBadProductInStorageEntity::getPostSapDate, LocalDateTime.now())
                    .set(WmsBadProductInStorageEntity::getPostSapMsg, "wo detail not exist"));
            return;
        }

        //当前物料过账量
        BigDecimal inStorageQty = s.getInStorageQty();

        if (inStorageQty.compareTo(BigDecimal.ZERO) <= 0) {
            return;
        }

        try {
            WorkOrderPostingDto input = new WorkOrderPostingDto();
            input.setPostDate(postDate);
            input.setDocDate(postDate);
            input.setUserName("WMS");
            input.setHeaderText("");
            input.setPlant(s.getPlantCode());
            input.setPartNo(s.getPartNo());
            input.setLongPartNo(s.getPartNo());
            /*//如果组织为CABG_VN,则赋值版次为A
            if ("CABG_VN".equals(s.getOrgCode())) {
                input.setPartVersion("A");
            } else {
                input.setPartVersion("");
            }*/
            WmsSapPlant sapPlant = wmsSapPlantMapper.selectOne(Wrappers.<WmsSapPlant>lambdaQuery()
                    .eq(WmsSapPlant::getOrgCode, s.getOrgCode())
                    .last("limit 1"));
            String enableVersion = sapPlant.getEnableVersion();
            input.setPartVersion("Y".equals(enableVersion) ? s.getPartVersion() : "");
//            input.setPartVersion("");
            input.setFromWarehouseName(s.getBadWarehouseCode());
            input.setMoveType("531");
            input.setGmCode("03");
            input.setUnit("EA");
            input.setQty(inStorageQty);

            input.setWorkOrderNo(s.getWorkOrderNo());
            input.setReservationNo(woDetailInfo.getReservationNumber());
            input.setReservationItem(woDetailInfo.getReservationItem());


            String valueTypeValue = materialRfcService.doGetMaterialValueType(sapClient, s.getPlantCode(), s.getPartNo(), s.getBadWarehouseCode());
            input.setValueType(valueTypeValue);


            PostingSap101ReturnDto postingSap531ReturnDto = woRfcService.doWorkOrderPosting(sapClient, input);

            wmsBadProductInStorageMapper.update(null, Wrappers.<WmsBadProductInStorageEntity>lambdaUpdate()
                    .eq(WmsBadProductInStorageEntity::getId, s.getId())
                    .set(WmsBadProductInStorageEntity::getPostSapDate, LocalDateTime.now())
                    .set(WmsBadProductInStorageEntity::getPostSapQty, s.getInStorageQty())
                    .set(WmsBadProductInStorageEntity::getPostSapNo, postingSap531ReturnDto.getDocNumber())
                    .set(WmsBadProductInStorageEntity::getPostSapMsg, "OK"));

            WmsWorkOrderDetailInStorage updateDetail = new WmsWorkOrderDetailInStorage();
            updateDetail.setId(woDetailInfo.getId());
            updateDetail.setBadPostSapQty(NumberUtil.add(woDetailInfo.getBadPostSapQty(), s.getInStorageQty()));
            updateDetail.setPostTo531Qty(NumberUtil.add(woDetailInfo.getPostTo531Qty(), s.getInStorageQty()));
            updateDetail.setShelfQty(NumberUtil.add(woDetailInfo.getShelfQty(), s.getInStorageQty()));
            //updateDetail.setPostTo531Qty(NumberUtil.add(woDetailInfo.getPostTo531Qty(), s.getInStorageQty()));
            //updateDetail.setPostTo531ReturnMsg(postingSap531ReturnDto.getDocNumber() + " - " + LocalDateTime.now());
            updateDetail.updateById();

        } catch (Exception e) {
            wmsBadProductInStorageMapper.update(null, Wrappers.<WmsBadProductInStorageEntity>lambdaUpdate()
                    .eq(WmsBadProductInStorageEntity::getId, s.getId())
                    .set(WmsBadProductInStorageEntity::getPostSapDate, LocalDateTime.now())
                    .set(WmsBadProductInStorageEntity::getPostSapNo, "0")
                    .set(WmsBadProductInStorageEntity::getPostSapMsg, e.getMessage()));
        }
    }


    private void doPost311(WmsBadProductInStorageEntity s, String postDate, String sapClient) {

        //过账数量
        BigDecimal postingQty = s.getInStorageQty();

        try {

            if (postingQty.compareTo(BigDecimal.ZERO) <= 0) {
                return;
            }

            TransferDto dto = new TransferDto();
            dto.setTransactionDate(postDate);
            dto.setDocDate(postDate);
            dto.setMoveType("311");
            dto.setGmCode("04");
            dto.setQty(postingQty.toString());
            dto.setUnit("EA");
            //301 夸工厂转仓   04
            //311 同工厂转仓   04
            //309 料调        04
            dto.setFromPlant(s.getPlantCode());
            dto.setFromWarehouseName(s.getGoodWarehouseCode());
            dto.setFromPartNo(s.getPartNo());
            /*//如果组织为CABG_VN,则赋值版次为A
            if ("CABG_VN".equals(s.getOrgCode())) {
                dto.setFromPartVersion("A");
                dto.setToPartVersion("A");
            } else {
                dto.setFromPartVersion("");
                dto.setToPartVersion("");
            }*/
            WmsSapPlant sapPlant = wmsSapPlantMapper.selectOne(Wrappers.<WmsSapPlant>lambdaQuery()
                    .eq(WmsSapPlant::getOrgCode, s.getOrgCode())
                    .last("limit 1"));
            String enableVersion = sapPlant.getEnableVersion();
            if ("Y".equals(enableVersion)) {
                dto.setFromPartVersion(s.getPartVersion());
                dto.setToPartVersion(s.getPartVersion());
            } else {
                dto.setFromPartVersion("");
                dto.setToPartVersion("");
            }
            dto.setToPlant(s.getPlantCode());
            dto.setToWarehouseName(s.getBadWarehouseCode());
            dto.setToPartNo(s.getPartNo());

            String valueType = materialRfcService.doGetMaterialValueType(sapClient, s.getPlantCode(), s.getPartNo(), s.getBadWarehouseCode());

            if (StringUtils.isEmpty(valueType)) {
                wmsBadProductInStorageMapper.update(null, Wrappers.<WmsBadProductInStorageEntity>lambdaUpdate()
                        .eq(WmsBadProductInStorageEntity::getId, s.getId())
                        .set(WmsBadProductInStorageEntity::getPostSapDate, LocalDateTime.now())
                        .set(WmsBadProductInStorageEntity::getPostSapMsg, "value type not exist"));
                return;

            }
            dto.setValueType(valueType);

            String docNumber = whRfcService.doTransfer(sapClient, dto);

            if (StringUtils.isNotEmpty(docNumber)) {
                wmsBadProductInStorageMapper.update(null, Wrappers.<WmsBadProductInStorageEntity>lambdaUpdate()
                        .eq(WmsBadProductInStorageEntity::getId, s.getId())
                        .set(WmsBadProductInStorageEntity::getPostSapDate, LocalDateTime.now())
                        .set(WmsBadProductInStorageEntity::getPostSapQty, s.getInStorageQty())
                        .set(WmsBadProductInStorageEntity::getPostSapNo, docNumber)
                        .set(WmsBadProductInStorageEntity::getPostSapMsg, "OK"));
            }

        } catch (Exception e) {
            wmsBadProductInStorageMapper.update(null, Wrappers.<WmsBadProductInStorageEntity>lambdaUpdate()
                    .eq(WmsBadProductInStorageEntity::getId, s.getId())
                    .set(WmsBadProductInStorageEntity::getPostSapDate, LocalDateTime.now())
                    .set(WmsBadProductInStorageEntity::getPostSapNo, "0")
                    .set(WmsBadProductInStorageEntity::getPostSapMsg, e.getMessage()));
        }
    }

    private void doError(WmsBadProductInStorageEntity s, String errorMsg) {
        wmsBadProductInStorageMapper.update(null, Wrappers.<WmsBadProductInStorageEntity>lambdaUpdate()
                .eq(WmsBadProductInStorageEntity::getId, s.getId())
                .set(WmsBadProductInStorageEntity::getPostSapDate, LocalDateTime.now())
                .set(WmsBadProductInStorageEntity::getPostSapMsg, errorMsg));

    }
}
