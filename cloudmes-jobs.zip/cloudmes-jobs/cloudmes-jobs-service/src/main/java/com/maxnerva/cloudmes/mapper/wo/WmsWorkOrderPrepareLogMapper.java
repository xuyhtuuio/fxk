package com.maxnerva.cloudmes.mapper.wo;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderPrepareLog;

/**
 * <p>
 * 工单备料记录表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2022-08-30
 */
public interface WmsWorkOrderPrepareLogMapper extends BaseMapper<WmsWorkOrderPrepareLog> {

}
