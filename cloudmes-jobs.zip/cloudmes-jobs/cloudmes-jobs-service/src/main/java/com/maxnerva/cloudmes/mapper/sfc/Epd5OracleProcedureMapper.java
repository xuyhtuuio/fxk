package com.maxnerva.cloudmes.mapper.sfc;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.maxnerva.cloudmes.service.sfc.model.SfcCartonInfoDTO;

import java.util.List;
import java.util.Map;

/**
 * @ClassName CmbOracleProcedureMapper
 * @Description TODO
 * @Author Likun
 * @Date 2024/1/15
 * @Version 1.0
 * @Since JDK 1.8
 **/
@DS("epd5_db")
public interface Epd5OracleProcedureMapper {

    /**
     * from SFC 取成品入库栈板信息
     *
     * @param map
     */
    void getSfcPalletInfo(Map map);
    /**
     * 回写DN、SN的绑定关系
     *
     * @param map
     */
    void sendSnDnRelationshipToSfc(Map map);

    void testInputShipping(Map map);


    List<SfcCartonInfoDTO> getSfcPalletInfoByCartonNo(String cartonNo);

}
