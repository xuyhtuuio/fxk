package com.maxnerva.cloudmes.entity.wo;

import com.baomidou.mybatisplus.extension.activerecord.Model;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>
 * 工单备料记录表;sfc table
 * </p>
 *
 * @author likun
 * @since 2022-08-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsWorkOrderPrepareLog对象", description="工单备料记录表")
public class WmsWorkOrderPrepareLog extends Model<WmsWorkOrderPrepareLog> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "pkg")
    private String pkgId;

    @ApiModelProperty(value = "父pkg")
    private String parentPkgId;

    @ApiModelProperty(value = "BU（业务单元）")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "储位id")
    private Integer wmsBinId;

    @ApiModelProperty(value = "储位编码")
    private String binCode;

    @ApiModelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "原始数量")
    private BigDecimal originalQty;

    @ApiModelProperty(value = "当前数量")
    private BigDecimal currentQty;

    @ApiModelProperty(value = "操作数量")
    private BigDecimal transactionQty;

    @ApiModelProperty(value = "供应商料号")
    private String supplierPartNo;

    @ApiModelProperty(value = "制造商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "解析datecode")
    private LocalDate dateCode;

    @ApiModelProperty(value = "原始datecode")
    private String originalDateCode;

    @ApiModelProperty(value = "批次号")
    private String lotNo;

    @ApiModelProperty(value = "上架时间;")
    private LocalDateTime shelfDate;

    @ApiModelProperty(value = "wms单号")
    private String wmsNo;

    @ApiModelProperty(value = "锁定标识")
    private Integer lockFlag;

    @ApiModelProperty(value = "锁定状态")
    private String lockStatus;

    @ApiModelProperty(value = "锁定时间")
    private LocalDateTime lockDt;

    @ApiModelProperty(value = "lock原因")
    private String lockMessage;

    @ApiModelProperty(value = "工单")
    private String workOrderNo;

    @ApiModelProperty(value = "异动类型编码，参考字典")
    private String transactionType;

    @ApiModelProperty(value = "异动类型字典值")
    private String transactionMessage;

    @ApiModelProperty(value = "检验日期")
    private LocalDate checkDate;

    @ApiModelProperty(value = "有效日期")
    private Integer effectiveDate;

    @ApiModelProperty(value = "有效期截止时间")
    private LocalDate endDate;

    @ApiModelProperty(value = "载具id")
    private Integer wmsVehicleId;

    @ApiModelProperty(value = "载具编码")
    private String vehicleCode;

    @ApiModelProperty(value = "是否抛转sfc标识")
    private Boolean wmsToSfcFlag;

    @ApiModelProperty(value = "wms抛转sfc标识")
    private Integer postSfcFlag;

    @ApiModelProperty(value = "wms抛转sfc时间")
    private LocalDateTime postSfcDt;

    @ApiModelProperty(value = "抛转sfc返回信息")
    private String postSfcReturnMessage;

    @ApiModelProperty(value = "工单绑定位置")
    private String workOrderToLocation;

    @ApiModelProperty(value = "来源仓码")
    private String fromWarehouseCode;

    @ApiModelProperty(value = "工单群组")
    private String workOrderItem;

    @ApiModelProperty(value = "消耗数量")
    private BigDecimal consumeQty;

    @ApiModelProperty(value = "上料表工单群组")
    private String feederWorkOrderItem;

    @ApiModelProperty(value = "制造商名称")
    private String mfgName;

    @ApiModelProperty(value = "原产国1")
    private String placeOfOrigin1;

    @ApiModelProperty(value = "退料量")
    private BigDecimal returnQty;

    @ApiModelProperty(value = "烧录值")
    private String burnValue;

    @ApiModelProperty(value = "烧录标识(N-不烧录 Y-烧录)")
    private String burnFlag;

    @ApiModelProperty(value = "机台编号")
    private String machineCode;

    @ApiModelProperty(value = "feeder号,轨道号")
    private String feederNo;

    @ApiModelProperty(value = "wms抛转mes标识")
    private Integer postToMesFlag;

    @ApiModelProperty(value = "wms抛转mes时间")
    private LocalDateTime postToMesDt;

    @ApiModelProperty(value = "抛转mes返回信息")
    private String postToMesReturnMessage;

    @ApiModelProperty(value = "成品料号")
    private String productPartNo;

    @ApiModelProperty(value = "线别")
    private String lineNo;

    /**
     * 创建时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(hidden = true)
    private LocalDateTime createdDt;

    @ApiModelProperty(hidden = true)
    private String creator;

    /**
     * 最后修改人
     */
    @ApiModelProperty(hidden = true)
    private String lastEditor;

    /**
     * 最后一次编辑时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(hidden = true)
    private LocalDateTime lastEditedDt;

    /**
     * 同步msd标识
     */
    @ApiModelProperty("同步msd标识")
    private Integer postMsdFlag;
    /**
     * 同步msd信息描述
     */
    @ApiModelProperty("同步msd信息描述")
    private String postMsdMsg;
    /**
     * 同步msd时间
     */
    @ApiModelProperty("同步msd时间")
    private LocalDateTime postMsdDateTime;
}
