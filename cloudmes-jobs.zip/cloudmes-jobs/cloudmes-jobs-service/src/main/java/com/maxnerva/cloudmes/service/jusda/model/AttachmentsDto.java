package com.maxnerva.cloudmes.service.jusda.model;

import lombok.Data;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2023/04/21 18:19
 * @Version: 1.0
 */
@Data
public class AttachmentsDto {
    private Integer fileId;
    private String fileName;
    private String attachmentType;
}
