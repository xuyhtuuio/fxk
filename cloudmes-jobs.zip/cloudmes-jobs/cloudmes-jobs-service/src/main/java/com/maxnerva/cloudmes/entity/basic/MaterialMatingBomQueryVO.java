package com.maxnerva.cloudmes.entity.basic;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName MaterialMatingBomQueryVO
 * @Description TODO
 * @Author Likun
 * @Date 2024/12/20
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("配套信息查询vo")
@Data
public class MaterialMatingBomQueryVO {

    @ApiModelProperty("成品料号")
    private String productNo;

    @ApiModelProperty("组织")
    private String orgCode;
}
