package com.maxnerva.cloudmes.service.wo.model;

import lombok.Data;

@Data
public class JsonStringVO {
    private String parameter;
}
