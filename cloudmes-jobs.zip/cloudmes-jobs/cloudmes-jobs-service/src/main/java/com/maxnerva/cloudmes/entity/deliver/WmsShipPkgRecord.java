package com.maxnerva.cloudmes.entity.deliver;

import com.maxnerva.cloudmes.entity.BaseEntity;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class WmsShipPkgRecord{
    private Integer id;

    private Integer shipDetailId;

    private String pkgId;

    private String partNo;
    private BigDecimal qty;
    private String sapWarehouseCode;
    private String binCode;
    private String assetId;
    private String workOrder;
    private String vehicleCode;
    private String locationCode;
    private String orgCode;
    private String ipn;
    private String modelSerial;
    private String modelNameSfc;

    private String creator;
    private Integer creatorId;
    private Long createdDt;
    private String lastEditor;
    private Integer lastEditorId;
    private Long lastEditedDt;
    private String toSfcShippingMsg;
    private LocalDateTime postSfcDate;
}
