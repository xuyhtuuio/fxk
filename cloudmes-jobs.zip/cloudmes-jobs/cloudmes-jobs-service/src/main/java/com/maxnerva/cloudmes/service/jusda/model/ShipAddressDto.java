package com.maxnerva.cloudmes.service.jusda.model;

import lombok.Data;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2023/04/21 18:18
 * @Version: 1.0
 */
@Data
public class ShipAddressDto {
    private Integer addressCode;
    private String country;
    private String province;
    private String city;
    private String district;
    private String street;
    private String detail;
}
