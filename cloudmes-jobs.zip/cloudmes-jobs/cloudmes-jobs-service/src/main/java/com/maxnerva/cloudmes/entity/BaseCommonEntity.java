package com.maxnerva.cloudmes.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/11/03 10:10
 * @Version: 1.0
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BaseCommonEntity implements Serializable {
    private Integer id;
    private String creator;
    private Integer creatorId;
    private Long createdDt;
    private String lastEditor;
    private Integer lastEditorId;
    private Long lastEditedDt;

    public void initCreate(String create) {
        this.creator = create;
        this.lastEditor = create;
        this.createdDt = System.currentTimeMillis();
        this.lastEditedDt = this.createdDt;
    }

    public void initCreate(String create, Integer creatorId) {
        this.creator = create;
        this.creatorId = creatorId;
        this.lastEditor = create;
        this.lastEditorId = creatorId;
        this.createdDt = System.currentTimeMillis();
        this.lastEditedDt = this.createdDt;
    }

    public void initUpdate(String lastEditor, Integer lastEditorId) {
        this.lastEditor = lastEditor;
        this.lastEditorId = lastEditorId;
        this.lastEditedDt = System.currentTimeMillis();
    }

    public void initUpdate(String lastEditor) {
        this.lastEditor = lastEditor;
        this.lastEditedDt = System.currentTimeMillis();
    }
}

