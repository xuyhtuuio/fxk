package com.maxnerva.cloudmes.mapper.doc;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.doc.WmsDoc;

/**
 * <p>
 * 单据表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2022-07-28
 */
public interface WmsDocMapper extends BaseMapper<WmsDoc> {



}
