package com.maxnerva.cloudmes.service.wo.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName SapWoDetailVO
 * @Description 工单detail下载vo
 * @Author Likun
 * @Date 2022/8/30
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("工单detail下载vo")
@Data
public class SapWoDetailVO {

    @ApiModelProperty("orgCode")
    private String orgCode;


    @ApiModelProperty("sap客户端")
    private String sapClient;

    @ApiModelProperty("工厂")
    private String plant;

    @ApiModelProperty("工单号")
    private String woNumber;
}
