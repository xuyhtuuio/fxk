package com.maxnerva.cloudmes.service.wo;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpStatus;
import cn.hutool.json.JSONUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.github.pagehelper.util.StringUtil;
import com.maxnerva.cloudmes.entity.R;
import com.maxnerva.cloudmes.entity.WmsSapPlant;
import com.maxnerva.cloudmes.entity.basic.SysDict;
import com.maxnerva.cloudmes.entity.deliver.WmsDocProductShipHeader;
import com.maxnerva.cloudmes.entity.doc.WmsDocReceive;
import com.maxnerva.cloudmes.entity.doc.WmsDocType;
import com.maxnerva.cloudmes.entity.wo.WmsCreatePoDnConfig;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderPrepareCkdShipDetail;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderPrepareCkdShipHeader;
import com.maxnerva.cloudmes.mapper.WmsSapPlantMapper;
import com.maxnerva.cloudmes.mapper.basic.SysDictMapper;
import com.maxnerva.cloudmes.mapper.deliver.WmsProductShipHeaderMapper;
import com.maxnerva.cloudmes.mapper.doc.WmsDocReceiveMapper;
import com.maxnerva.cloudmes.mapper.doc.WmsDocTypeMapper;
import com.maxnerva.cloudmes.mapper.wo.WmsCreatePoDnConfigMapper;
import com.maxnerva.cloudmes.mapper.wo.WmsWorkOrderPrepareCkdShipDetailMapper;
import com.maxnerva.cloudmes.mapper.wo.WmsWorkOrderPrepareCkdShipHeaderMapper;
import com.maxnerva.cloudmes.service.basic.CodeRuleService;
import com.maxnerva.cloudmes.service.datahub.DataHubService;
import com.maxnerva.cloudmes.service.sap.material.MaterialRfcService;
import com.maxnerva.cloudmes.service.sap.po.PoRfcService;
import com.maxnerva.cloudmes.service.sap.po.model.CkdShipPgiResultDto;
import com.maxnerva.cloudmes.service.sap.po.model.CreateDnInputDto;
import com.maxnerva.cloudmes.service.sap.po.model.CreateDnItemInputDto;
import com.maxnerva.cloudmes.service.sap.po.model.CreateDnResultDto;
import com.maxnerva.cloudmes.service.wo.model.*;
import com.sap.conn.jco.JCoException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class WmsWorkOrderPrepareCkdShipService {

    @Autowired
    private PoRfcService poRfcService;
    @Autowired
    private WmsSapPlantMapper wmsSapPlantMapper;
    @Autowired
    private WmsWorkOrderPrepareCkdShipHeaderMapper wmsWorkOrderPrepareCkdShipHeaderMapper;
    @Autowired
    private WmsWorkOrderPrepareCkdShipDetailMapper wmsWorkOrderPrepareCkdShipDetailMapper;
    @Autowired
    private WmsCreatePoDnConfigMapper wmsCreatePoDnConfigMapper;
    @Autowired
    private MaterialRfcService materialRfcService;
    @Autowired
    private DataHubService dataHubService;
    @Autowired
    private WmsDocTypeMapper wmsDocTypeMapper;
    @Autowired
    private CodeRuleService codeRuleService;
    @Autowired
    private WmsDocReceiveMapper wmsDocReceiveMapper;
    @Autowired
    WmsProductShipHeaderMapper wmsProductShipHeaderMapper;
    @Autowired
    SysDictMapper sysDictMapper;

    public void doCreateCkdPo(String orgCode, String toOrgCode) {
        List<WmsWorkOrderPrepareCkdShipHeader> shipHeaderList = wmsWorkOrderPrepareCkdShipHeaderMapper
                .selectList(Wrappers.<WmsWorkOrderPrepareCkdShipHeader>lambdaQuery()
                        .eq(WmsWorkOrderPrepareCkdShipHeader::getOrgCode, orgCode)
                        .eq(WmsWorkOrderPrepareCkdShipHeader::getPoPostSapFlag, "0"));
        if (CollUtil.isEmpty(shipHeaderList)) {
            return;
        }
        List<String> serialNoList = shipHeaderList.stream().map(WmsWorkOrderPrepareCkdShipHeader::getSerialNo)
                .collect(Collectors.toList());
        List<WmsWorkOrderPrepareCkdShipDetail> shipDetailList = wmsWorkOrderPrepareCkdShipDetailMapper
                .selectList(Wrappers.<WmsWorkOrderPrepareCkdShipDetail>lambdaQuery()
                        .eq(WmsWorkOrderPrepareCkdShipDetail::getOrgCode, orgCode)
                        .in(WmsWorkOrderPrepareCkdShipDetail::getSerialNo, serialNoList));
        if (CollUtil.isEmpty(shipDetailList)) {
            return;
        }
        //按照工厂分组，因为查PoDnConfig区分工厂
        Map<String, List<WmsWorkOrderPrepareCkdShipHeader>> collect = shipHeaderList.stream()
                .collect(Collectors.groupingBy(WmsWorkOrderPrepareCkdShipHeader::getPlantCode));
        for (Map.Entry<String, List<WmsWorkOrderPrepareCkdShipHeader>> entry : collect.entrySet()) {
            String plantCode = entry.getKey();
            List<WmsWorkOrderPrepareCkdShipHeader> headerList = entry.getValue();
            for (WmsWorkOrderPrepareCkdShipHeader header : headerList) {
                WmsCreatePoDnConfig poDnConfig = getPoDnConfig(orgCode, plantCode, header.getSiteCode());
                if (ObjectUtil.isNull(poDnConfig)) {
                    wmsWorkOrderPrepareCkdShipHeaderMapper.update(null, Wrappers.<WmsWorkOrderPrepareCkdShipHeader>lambdaUpdate()
                            .eq(WmsWorkOrderPrepareCkdShipHeader::getId, header.getId())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getPoPostSapMsg, "WmsCreatePoDnConfig is not exist")
                            .set(WmsWorkOrderPrepareCkdShipHeader::getPoPostSapDate, LocalDateTime.now())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditor, "sysadmin")
                            .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditedDt, LocalDateTime.now()));
                }
                CreateCkdPoDto dto = new CreateCkdPoDto();
                dto.setOrgCode(toOrgCode);
                dto.setCompCode(poDnConfig.getCompCode());
                dto.setDocType(poDnConfig.getDocType());
                Date now = new Date();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
                dto.setCreateDate(sdf.format(now));
                dto.setVendorCode(poDnConfig.getVendorCode());
                dto.setPurchaseOrg(poDnConfig.getPurchaseOrg());
                dto.setPurchaseGroup(poDnConfig.getPurchaseGroup());
                dto.setPartnerDesc(poDnConfig.getPartnerDesc());
                dto.setLangu(poDnConfig.getLangu());
                dto.setBuspartNo(poDnConfig.getBuspartNo());
                List<WmsWorkOrderPrepareCkdShipDetail> detailList = shipDetailList.stream().filter(d ->
                        header.getSerialNo().equals(d.getSerialNo())).collect(Collectors.toList());
                if (CollUtil.isEmpty(detailList)) {
                    continue;
                }
                List<CreateCkdPoItemDto> poItemDtos = new ArrayList<>();
                for (WmsWorkOrderPrepareCkdShipDetail detail : detailList) {
                    CreateCkdPoItemDto poItemDto = new CreateCkdPoItemDto();
                    poItemDto.setPoItem(detail.getItem());
                    poItemDto.setMaterial(detail.getPartNo());
                    poItemDto.setMaterialExternal(detail.getSupplierPartNo());
                    poItemDto.setEmaterialExternal(detail.getMfgName());
                    poItemDto.setPlantCode(poDnConfig.getShippingPoint());
                    poItemDto.setStgeLoc(poDnConfig.getStgeLoc());
                    poItemDto.setQty(detail.getQty().toString());
                    poItemDto.setBom("EA");
                    poItemDtos.add(poItemDto);
                }
                dto.setPoItem(poItemDtos);
                String parameter = JSONUtil.toJsonStr(dto);
                JsonStringVO vnCreatePoVO = new JsonStringVO();
                vnCreatePoVO.setParameter(parameter);
                HttpResponse httpResponse = dataHubService.vnCreatePo(vnCreatePoVO);
                if (httpResponse.getStatus() != HttpStatus.HTTP_OK) {
                    wmsWorkOrderPrepareCkdShipHeaderMapper.update(null, Wrappers.<WmsWorkOrderPrepareCkdShipHeader>lambdaUpdate()
                            .eq(WmsWorkOrderPrepareCkdShipHeader::getId, header.getId())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getPoPostSapMsg, "call vnCreatePo interface fail")
                            .set(WmsWorkOrderPrepareCkdShipHeader::getPoPostSapDate, LocalDateTime.now())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditor, "sysadmin")
                            .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditedDt, LocalDateTime.now()));
                }
                String body = httpResponse.body();
                log.info("doCreateCkdPo request:{}, return:{}", JSONUtil.toJsonStr(dto), body);
                if (StrUtil.isEmpty(body)) {
                    wmsWorkOrderPrepareCkdShipHeaderMapper.update(null, Wrappers.<WmsWorkOrderPrepareCkdShipHeader>lambdaUpdate()
                            .eq(WmsWorkOrderPrepareCkdShipHeader::getId, header.getId())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getPoPostSapMsg, "call vnCreatePo interface fail")
                            .set(WmsWorkOrderPrepareCkdShipHeader::getPoPostSapDate, LocalDateTime.now())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditor, "sysadmin")
                            .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditedDt, LocalDateTime.now()));
                    continue;
                }
                JSONObject dataHubReturnInfo = JSON.parseObject(body);
                int code = dataHubReturnInfo.getInteger("code");
                String msg = dataHubReturnInfo.getString("msg");
                String data = dataHubReturnInfo.getString("data");
                if (200 != code) {
                    wmsWorkOrderPrepareCkdShipHeaderMapper.update(null, Wrappers.<WmsWorkOrderPrepareCkdShipHeader>lambdaUpdate()
                            .eq(WmsWorkOrderPrepareCkdShipHeader::getId, header.getId())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getPoPostSapMsg, msg)
                            .set(WmsWorkOrderPrepareCkdShipHeader::getPoPostSapDate, LocalDateTime.now())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditor, "sysadmin")
                            .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditedDt, LocalDateTime.now()));
                    continue;
                }
                CreateCkdPoResultDto createCkdPoResultDto = JSON.parseObject(data, CreateCkdPoResultDto.class);
                wmsWorkOrderPrepareCkdShipHeaderMapper.update(null, Wrappers.<WmsWorkOrderPrepareCkdShipHeader>lambdaUpdate()
                        .eq(WmsWorkOrderPrepareCkdShipHeader::getId, header.getId())
                        .set(WmsWorkOrderPrepareCkdShipHeader::getPoNo1, createCkdPoResultDto.getPo1Number())
                        .set(WmsWorkOrderPrepareCkdShipHeader::getPoNo2, createCkdPoResultDto.getPo2Number())
                        .set(WmsWorkOrderPrepareCkdShipHeader::getPoPostSapMsg, "OK")
                        .set(WmsWorkOrderPrepareCkdShipHeader::getPoPostSapFlag, "1")
                        .set(WmsWorkOrderPrepareCkdShipHeader::getPoPostSapDate, LocalDateTime.now())
                        .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditor, "sysadmin")
                        .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditedDt, LocalDateTime.now()));
            }
        }
    }

    public void doCreateDn(String orgCode) {
        List<WmsSapPlant> wmsSapPlantList = wmsSapPlantMapper.selectList(Wrappers.<WmsSapPlant>lambdaQuery()
                .eq(WmsSapPlant::getOrgCode, orgCode));
        for (WmsSapPlant wmsSapPlant : wmsSapPlantList) {
            String plantCode = wmsSapPlant.getFactoryCode();
            String sapClient = wmsSapPlant.getErpInterface();
            List<WmsWorkOrderPrepareCkdShipHeader> headerList = wmsWorkOrderPrepareCkdShipHeaderMapper
                    .selectList(Wrappers.<WmsWorkOrderPrepareCkdShipHeader>lambdaQuery()
                            .eq(WmsWorkOrderPrepareCkdShipHeader::getOrgCode, orgCode)
                            .eq(WmsWorkOrderPrepareCkdShipHeader::getPlantCode, plantCode)
                            .eq(WmsWorkOrderPrepareCkdShipHeader::getPoPostSapFlag, "1")
                            .eq(WmsWorkOrderPrepareCkdShipHeader::getDnPostSapFlag, "0"));
            if (CollUtil.isEmpty(headerList)) {
                continue;
            }
            for (WmsWorkOrderPrepareCkdShipHeader header : headerList) {
                WmsCreatePoDnConfig wmsCreatePoDnConfig = wmsCreatePoDnConfigMapper.selectOne(Wrappers.<WmsCreatePoDnConfig>lambdaQuery()
                        .eq(WmsCreatePoDnConfig::getOrgCode, orgCode)
                        .eq(WmsCreatePoDnConfig::getPlantCode, plantCode)
                        .eq(WmsCreatePoDnConfig::getSiteCode, header.getSiteCode())
                        .last("limit 1"));
                if (ObjectUtil.isNull(wmsCreatePoDnConfig)) {
                    wmsWorkOrderPrepareCkdShipHeaderMapper.update(null, Wrappers.<WmsWorkOrderPrepareCkdShipHeader>lambdaUpdate()
                            .eq(WmsWorkOrderPrepareCkdShipHeader::getId, header.getId())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getDnPostSapMsg, "siteCode in wmsCreatePoDnConfig is not exist")
                            .set(WmsWorkOrderPrepareCkdShipHeader::getDnPostSapDate, LocalDateTime.now())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditor, "sysadmin")
                            .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditedDt, LocalDateTime.now()));
                    continue;
                }
                CreateDnInputDto dto = new CreateDnInputDto();
                dto.setCreateDocType(wmsCreatePoDnConfig.getCreateDocType());
//                dto.setBuyerDeptCode(wmsCreatePoDnConfig.getBuyerDeptCode());
//                dto.setSellerDeptCode(wmsCreatePoDnConfig.getSellerDeptCode());
//                dto.setShippingPoint(wmsCreatePoDnConfig.getShippingPoint());
                dto.setSalesDocType(wmsCreatePoDnConfig.getSalesDocType());
                dto.setSalesOrganization(wmsCreatePoDnConfig.getSalesOrganization());
                dto.setDistributionChannel(wmsCreatePoDnConfig.getDistributionChannel());
                dto.setDivision(wmsCreatePoDnConfig.getDivision());
//                dto.setCustomerPO(header.getPoNo2());
                dto.setPartnerBuyerFunction(wmsCreatePoDnConfig.getPartnerBuyerFunction());
                dto.setPartnerBuyerFunctionNumber(wmsCreatePoDnConfig.getPartnerBuyerFunctionNumber());
                dto.setPartnerSellerFunction(wmsCreatePoDnConfig.getPartnerSellerFunction());
                dto.setPartnerSellerFunctionNumber(wmsCreatePoDnConfig.getPartnerSellerFunctionNumber());
                List<WmsWorkOrderPrepareCkdShipDetail> detailList = wmsWorkOrderPrepareCkdShipDetailMapper
                        .selectList(Wrappers.<WmsWorkOrderPrepareCkdShipDetail>lambdaQuery()
                                .eq(WmsWorkOrderPrepareCkdShipDetail::getSerialNo, header.getSerialNo()));
                if (CollUtil.isEmpty(detailList)) {
                    continue;
                }
                boolean skipHeader = Boolean.FALSE;
                List<CreateDnItemInputDto> poItemDtos = new ArrayList<>();
                for (WmsWorkOrderPrepareCkdShipDetail detail : detailList) {
                    CreateDnItemInputDto itemInputDto = new CreateDnItemInputDto();
                    itemInputDto.setItemNumber(detail.getItem());
                    itemInputDto.setPartNo(detail.getPartNo());
                    itemInputDto.setPartVersion("");
                    itemInputDto.setPlantCode(wmsCreatePoDnConfig.getPlantCode());
                    itemInputDto.setWarehouseCode(wmsCreatePoDnConfig.getStgeLoc());
                    itemInputDto.setQty(detail.getQty().toString());
                    String valueType;
                    try {
                        valueType = materialRfcService.getValueType(sapClient, orgCode, plantCode,
                                detail.getPartNo(), "", detail.getSapWarehouseCode());
                    } catch (JCoException e) {
                        wmsWorkOrderPrepareCkdShipHeaderMapper.update(null, Wrappers.<WmsWorkOrderPrepareCkdShipHeader>lambdaUpdate()
                                .eq(WmsWorkOrderPrepareCkdShipHeader::getId, header.getId())
                                .set(WmsWorkOrderPrepareCkdShipHeader::getDnPostSapMsg, "partNo:" + detail.getPartNo() + "getValueType error")
                                .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditor, "sysadmin")
                                .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditedDt, LocalDateTime.now()));
                        log.info("doCreateDn partNo:{} getValueType error:{}", detail.getPartNo(), e.getMessage());
                        skipHeader = Boolean.TRUE;
                        break;
                    }
                    itemInputDto.setValueType(valueType);
                    poItemDtos.add(itemInputDto);
                }
                if (skipHeader) {
                    continue;
                }
                dto.setItems(poItemDtos);
                log.info("doCreateDn dto:{}", JSONUtil.toJsonStr(dto));
                CreateDnResultDto resultDto;
                try {
                    resultDto = poRfcService.doCreateDn(sapClient, dto);
                    log.info("doCreateDn return:{}", JSONUtil.toJsonStr(resultDto));
                } catch (JCoException e) {
                    log.info("doCreateDn error:{}", e.getMessage());
                    wmsWorkOrderPrepareCkdShipHeaderMapper.update(null, Wrappers.<WmsWorkOrderPrepareCkdShipHeader>lambdaUpdate()
                            .eq(WmsWorkOrderPrepareCkdShipHeader::getId, header.getId())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getDnPostSapMsg, e.getMessage())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getDnPostSapDate, LocalDateTime.now())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditor, "sysadmin")
                            .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditedDt, LocalDateTime.now()));
                    continue;
                }
                if ("OK".equalsIgnoreCase(resultDto.getResult())) {
                    wmsWorkOrderPrepareCkdShipHeaderMapper.update(null, Wrappers.<WmsWorkOrderPrepareCkdShipHeader>lambdaUpdate()
                            .eq(WmsWorkOrderPrepareCkdShipHeader::getId, header.getId())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getDnNo, resultDto.getDnNumber())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getSoNo, resultDto.getSoNumber())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getDnPostSapFlag, "1")
                            .set(WmsWorkOrderPrepareCkdShipHeader::getDnPostSapDate, LocalDateTime.now())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditor, "sysadmin")
                            .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditedDt, LocalDateTime.now()));
                } else {
                    wmsWorkOrderPrepareCkdShipHeaderMapper.update(null, Wrappers.<WmsWorkOrderPrepareCkdShipHeader>lambdaUpdate()
                            .eq(WmsWorkOrderPrepareCkdShipHeader::getId, header.getId())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getDnPostSapMsg, resultDto.getResult())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getDnPostSapDate, LocalDateTime.now())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditor, "sysadmin")
                            .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditedDt, LocalDateTime.now()));
                }
            }
        }
    }

    public void doCreateCkdReceive(String orgCode, String toOrgCode) {
        List<WmsWorkOrderPrepareCkdShipHeader> shipHeaderList = wmsWorkOrderPrepareCkdShipHeaderMapper
                .selectList(Wrappers.<WmsWorkOrderPrepareCkdShipHeader>lambdaQuery()
                        .eq(WmsWorkOrderPrepareCkdShipHeader::getOrgCode, orgCode)
                        .eq(WmsWorkOrderPrepareCkdShipHeader::getPoPostSapFlag, "1")
                        .eq(WmsWorkOrderPrepareCkdShipHeader::getDnPostSapFlag, "1")
                        .eq(WmsWorkOrderPrepareCkdShipHeader::getShipFlag, "1")
                        .eq(WmsWorkOrderPrepareCkdShipHeader::getSyncReceiveDocFlag, "0")
                        .eq(WmsWorkOrderPrepareCkdShipHeader::getSiteCode, "VN"));
        if (CollUtil.isEmpty(shipHeaderList)) {
            return;
        }
        List<String> serialNoList = shipHeaderList.stream().map(WmsWorkOrderPrepareCkdShipHeader::getSerialNo)
                .collect(Collectors.toList());
        List<WmsWorkOrderPrepareCkdShipDetail> shipDetailList = wmsWorkOrderPrepareCkdShipDetailMapper
                .selectList(Wrappers.<WmsWorkOrderPrepareCkdShipDetail>lambdaQuery()
                        .eq(WmsWorkOrderPrepareCkdShipDetail::getOrgCode, orgCode)
                        .in(WmsWorkOrderPrepareCkdShipDetail::getSerialNo, serialNoList));
        if (CollUtil.isEmpty(shipDetailList)) {
            return;
        }
        //根据serialNo分组，收货单生成完后修改headerFlag
        Map<String, List<WmsWorkOrderPrepareCkdShipDetail>> collect = shipDetailList.stream().collect(Collectors
                .groupingBy(WmsWorkOrderPrepareCkdShipDetail::getSerialNo));
        for (Map.Entry<String, List<WmsWorkOrderPrepareCkdShipDetail>> entry : collect.entrySet()) {
            String serialNo = entry.getKey();
            WmsWorkOrderPrepareCkdShipHeader header = shipHeaderList.stream().filter(
                    h -> serialNo.equals(h.getSerialNo())).findFirst().orElse(null);
            WmsCreatePoDnConfig poDnConfig = getPoDnConfig(orgCode, header.getPlantCode(), header.getSiteCode());
            if (ObjectUtil.isNull(poDnConfig)) {
                wmsWorkOrderPrepareCkdShipHeaderMapper.update(null, Wrappers.<WmsWorkOrderPrepareCkdShipHeader>lambdaUpdate()
                        .eq(WmsWorkOrderPrepareCkdShipHeader::getId, header.getId())
                        .set(WmsWorkOrderPrepareCkdShipHeader::getSyncReceiveDocMsg, "siteCode in wmsCreatePoDnConfig is not exist")
                        .set(WmsWorkOrderPrepareCkdShipHeader::getSyncReceiveDocDate, LocalDateTime.now())
                        .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditor, "sysadmin")
                        .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditedDt, LocalDateTime.now()));
                continue;
            }
            List<WmsWorkOrderPrepareCkdShipDetail> detailList = entry.getValue();
            SaveCkdDocReceiveVO saveCkdDocReceiveVO = new SaveCkdDocReceiveVO();
            saveCkdDocReceiveVO.setOrgCode(toOrgCode);
            saveCkdDocReceiveVO.setPoNo(header.getPoNo1());
            saveCkdDocReceiveVO.setWmsCreatePoDnConfig(poDnConfig);
            saveCkdDocReceiveVO.setShipDetail(detailList);
            String parameter = JSONUtil.toJsonStr(saveCkdDocReceiveVO);
            JsonStringVO jsonStringVO = new JsonStringVO();
            jsonStringVO.setParameter(parameter);
            HttpResponse httpResponse = dataHubService.saveWmsDocReceive(jsonStringVO);
            if (httpResponse.getStatus() != HttpStatus.HTTP_OK) {
                wmsWorkOrderPrepareCkdShipHeaderMapper.update(null, Wrappers.<WmsWorkOrderPrepareCkdShipHeader>lambdaUpdate()
                        .eq(WmsWorkOrderPrepareCkdShipHeader::getId, header.getId())
                        .set(WmsWorkOrderPrepareCkdShipHeader::getSyncReceiveDocMsg, "call saveCkdDocReceive interface fail")
                        .set(WmsWorkOrderPrepareCkdShipHeader::getSyncReceiveDocDate, LocalDateTime.now())
                        .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditor, "sysadmin")
                        .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditedDt, LocalDateTime.now()));
            }
            String body = httpResponse.body();
            log.info("saveCkdDocReceive request:{}, return:{}", JSONUtil.toJsonStr(saveCkdDocReceiveVO), body);
            if (StrUtil.isEmpty(body)) {
                wmsWorkOrderPrepareCkdShipHeaderMapper.update(null, Wrappers.<WmsWorkOrderPrepareCkdShipHeader>lambdaUpdate()
                        .eq(WmsWorkOrderPrepareCkdShipHeader::getId, header.getId())
                        .set(WmsWorkOrderPrepareCkdShipHeader::getSyncReceiveDocMsg, "call saveCkdDocReceive interface fail")
                        .set(WmsWorkOrderPrepareCkdShipHeader::getSyncReceiveDocDate, LocalDateTime.now())
                        .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditor, "sysadmin")
                        .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditedDt, LocalDateTime.now()));
                continue;
            }
            JSONObject dataHubReturnInfo = JSON.parseObject(body);
            int code = dataHubReturnInfo.getInteger("code");
            String msg = dataHubReturnInfo.getString("msg");
            if (200 != code) {
                wmsWorkOrderPrepareCkdShipHeaderMapper.update(null, Wrappers.<WmsWorkOrderPrepareCkdShipHeader>lambdaUpdate()
                        .eq(WmsWorkOrderPrepareCkdShipHeader::getId, header.getId())
                        .set(WmsWorkOrderPrepareCkdShipHeader::getSyncReceiveDocMsg, msg)
                        .set(WmsWorkOrderPrepareCkdShipHeader::getSyncReceiveDocDate, LocalDateTime.now())
                        .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditor, "sysadmin")
                        .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditedDt, LocalDateTime.now()));
                continue;
            }
            wmsWorkOrderPrepareCkdShipHeaderMapper.update(null, Wrappers.<WmsWorkOrderPrepareCkdShipHeader>lambdaUpdate()
                    .eq(WmsWorkOrderPrepareCkdShipHeader::getId, header.getId())
                    .set(WmsWorkOrderPrepareCkdShipHeader::getSyncReceiveDocMsg, "OK")
                    .set(WmsWorkOrderPrepareCkdShipHeader::getSyncReceiveDocDate, LocalDateTime.now())
                    .set(WmsWorkOrderPrepareCkdShipHeader::getSyncReceiveDocFlag, "1")
                    .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditor, "sysadmin")
                    .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditedDt, LocalDateTime.now()));
        }
    }

    /*
     * 生成收货单
     */
    @Transactional(rollbackFor = Exception.class)
    public R<Void> saveCkdDocReceive(JsonStringVO jsonStringVO) {
        String parameter = jsonStringVO.getParameter();
        SaveCkdDocReceiveVO receiveVO = JSON.parseObject(parameter, SaveCkdDocReceiveVO.class);
        String orgCode = receiveVO.getOrgCode();
        String poNo = receiveVO.getPoNo();
        WmsCreatePoDnConfig poDnConfig = receiveVO.getWmsCreatePoDnConfig();
        List<WmsWorkOrderPrepareCkdShipDetail> detailList = receiveVO.getShipDetail();
        String docType = "CKD_RECEIVE_DOC";
        WmsDocType wmsDocTypeDb = wmsDocTypeMapper.selectOne(Wrappers.<WmsDocType>lambdaQuery()
                .eq(WmsDocType::getDocTypeCode, docType));
        for (WmsWorkOrderPrepareCkdShipDetail detail : detailList) {
                WmsDocReceive wmsDocReceive = new WmsDocReceive();
                wmsDocReceive.setOrgCode(orgCode);
                wmsDocReceive.setDocCreateDate(LocalDate.now());
                wmsDocReceive.setWmsDocTypeId(wmsDocTypeDb.getId());
                wmsDocReceive.setDocTypeName(wmsDocTypeDb.getDocTypeName());
                wmsDocReceive.setDocTypeCode(docType);
                wmsDocReceive.setDocCategoryCode(wmsDocTypeDb.getDocCategoryCode());
                wmsDocReceive.setPostingMethodName(wmsDocTypeDb.getPostingMethodName());
                wmsDocReceive.setPostingSapMethodFlag(wmsDocTypeDb.getPostingSapFlag());
                wmsDocReceive.setPostingQmsFlag(wmsDocTypeDb.getPostingQmsFlag());
                wmsDocReceive.setSapWarehouseCode(poDnConfig.getStgeLoc());
                wmsDocReceive.setPlantCode(poDnConfig.getShippingPoint());
                wmsDocReceive.setPoNo(poNo);
                wmsDocReceive.setPoItem(detail.getItem());
                wmsDocReceive.setPartNo(detail.getPartNo());
                wmsDocReceive.setPartNoVersion("");
                wmsDocReceive.setDocQty(detail.getQty());
                wmsDocReceive.setConfirmQty(detail.getQty());
                wmsDocReceive.setOperateQty(BigDecimal.ZERO);
                wmsDocReceive.setUomCode("EA");
                wmsDocReceive.setPlaceOfOrigin1(detail.getPlaceOfOrigin1());
                wmsDocReceive.setIsForceInspect(Boolean.FALSE);
                wmsDocReceive.setVendorCode(poDnConfig.getVendorCode());
                wmsDocReceive.setMfgPartNo(detail.getSupplierPartNo());
                wmsDocReceive.setMfgName(detail.getMfgName());
                wmsDocReceive.setFromDocNo(detail.getSerialNo());
                wmsDocReceive.setFromDocItem(detail.getItem());
                wmsDocReceive.setPurchaseOrg(poDnConfig.getPurchaseOrg());
                wmsDocReceive.setPurchaseGroup(poDnConfig.getPurchaseGroup());
                wmsDocReceive.setPoDocumentType(poDnConfig.getDocType());
                wmsDocReceive.setDocStatus("NOT_RECEIVED");
            try {
                HttpResponse httpResponse = codeRuleService.getCodeRule(orgCode);
                String body = httpResponse.body();
                String docNo = "";
                if (httpResponse.getStatus() == HttpStatus.HTTP_OK) {
                    cn.hutool.json.JSONObject jsonObject = JSONUtil.parseObj(body);
                    String code = jsonObject.getStr("code");
                    if (StringUtils.isNotBlank(code) && "200".equalsIgnoreCase(code)) {
                        List<String> data = (List<String>) jsonObject.getObj("data");
                        docNo = data.get(0);
                    }
                }
                if (StringUtils.isEmpty(docNo)) {
                    return R.no("call basic generate docNo error");
                }
                wmsDocReceive.setDocNo(docNo);
                wmsDocReceive.setCreatedDt(LocalDateTime.now());
                wmsDocReceive.setLastEditedDt(LocalDateTime.now());
                wmsDocReceive.setWmsContent(JSONUtil.toJsonStr(wmsDocReceive));
                wmsDocReceiveMapper.insert(wmsDocReceive);
            } catch (Exception e) {
                log.error("partNo:{} saveCkdDocReceive error:{}", detail.getPartNo(), e.getMessage());
                throw new RuntimeException(e.getMessage());
            }
        }
        return R.ok();
    }

    private WmsCreatePoDnConfig getPoDnConfig(String orgCode, String plantCode, String siteCode) {
        return wmsCreatePoDnConfigMapper.selectOne(Wrappers.<WmsCreatePoDnConfig>lambdaQuery()
                .eq(WmsCreatePoDnConfig::getOrgCode, orgCode)
                .eq(WmsCreatePoDnConfig::getPlantCode, plantCode)
                .eq(WmsCreatePoDnConfig::getSiteCode, siteCode)
                .last("limit 1"));
    }

    public void ckdShipPgi(String sapClient, String orgCode,  List<String> allowRunPlantCodeList) {
        List<WmsWorkOrderPrepareCkdShipHeader> shipHeaderList = wmsWorkOrderPrepareCkdShipHeaderMapper
                .selectList(Wrappers.<WmsWorkOrderPrepareCkdShipHeader>lambdaQuery()
                        .eq(WmsWorkOrderPrepareCkdShipHeader::getOrgCode, orgCode)
                        .eq(WmsWorkOrderPrepareCkdShipHeader::getDnPostSapFlag, "1")
                        .eq(WmsWorkOrderPrepareCkdShipHeader::getShipFlag, "1")
                        .eq(WmsWorkOrderPrepareCkdShipHeader::getPgiFlag, "0")
                        .in(WmsWorkOrderPrepareCkdShipHeader::getPlantCode, allowRunPlantCodeList)
                );
        String date = DateTimeFormatter.ofPattern("yyyyMMdd").format(LocalDate.now());
        for (WmsWorkOrderPrepareCkdShipHeader shipHeader : shipHeaderList) {
            try {
                CkdShipPgiResultDto resultDto = poRfcService.ckdShipPgi(sapClient, shipHeader.getDnNo(), date);
                log.info("ckdShipPgi request dnNo:{}, return:{}", shipHeader.getDnNo(), JSONUtil.toJsonStr(resultDto));
                if (StringUtil.isNotEmpty(resultDto.getPgiNo())) {
                    wmsWorkOrderPrepareCkdShipHeaderMapper.update(null, Wrappers.<WmsWorkOrderPrepareCkdShipHeader>lambdaUpdate()
                            .eq(WmsWorkOrderPrepareCkdShipHeader::getId, shipHeader.getId())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getPgiNo, resultDto.getPgiNo())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getPgiFlag, "1")
                            .set(WmsWorkOrderPrepareCkdShipHeader::getPgiDate, LocalDateTime.now())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getPgiMsg, resultDto.getMsg())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditor, "sysadmin")
                            .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditedDt, LocalDateTime.now()));
                } else {
                    wmsWorkOrderPrepareCkdShipHeaderMapper.update(null, Wrappers.<WmsWorkOrderPrepareCkdShipHeader>lambdaUpdate()
                            .eq(WmsWorkOrderPrepareCkdShipHeader::getId, shipHeader.getId())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getPgiDate, LocalDateTime.now())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getPgiMsg, resultDto.getMsg())
                            .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditor, "sysadmin")
                            .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditedDt, LocalDateTime.now()));
                }
            } catch (JCoException e) {
                log.info("ckdShipPgi error:{}", e.getMessage());
                wmsWorkOrderPrepareCkdShipHeaderMapper.update(null, Wrappers.<WmsWorkOrderPrepareCkdShipHeader>lambdaUpdate()
                        .eq(WmsWorkOrderPrepareCkdShipHeader::getId, shipHeader.getId())
                        .set(WmsWorkOrderPrepareCkdShipHeader::getPgiDate, LocalDateTime.now())
                        .set(WmsWorkOrderPrepareCkdShipHeader::getPgiMsg, e.getMessage())
                        .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditor, "sysadmin")
                        .set(WmsWorkOrderPrepareCkdShipHeader::getLastEditedDt, LocalDateTime.now()));
            }
        }
    }

    public R<CreateCkdPoResultDto> vnCreatePo(JsonStringVO vnCreatePoVO) {
        String parameter = vnCreatePoVO.getParameter();
        CreateCkdPoDto dto = JSON.parseObject(parameter, CreateCkdPoDto.class);
        String orgCode = dto.getOrgCode();
        List<WmsSapPlant> plantList = wmsSapPlantMapper.selectList(Wrappers.<WmsSapPlant>lambdaQuery()
                .eq(WmsSapPlant::getOrgCode, orgCode));
        String erpInterface = plantList.stream().findFirst().get().getErpInterface();
        List<CreateCkdPoItemDto> poItems = dto.getPoItem();
        for (CreateCkdPoItemDto poItem : poItems) {
            String valueType;
            try {
                valueType = materialRfcService.getValueType(erpInterface, orgCode, poItem.getPlantCode(),
                        poItem.getMaterial(), "", poItem.getStgeLoc());
            } catch (JCoException e) {
                log.info("doCreateCkdPo partNo:{}, getValueType error:{}", poItem.getMaterial(), e.getMessage());
                return R.no("doCreateCkdPo partNo:" + poItem.getMaterial() + " getValueType error:" + e.getMessage());
            }
            poItem.setValType(valueType);
        }
        log.info("doCreateCkdPo dto:{}", JSONUtil.toJsonStr(dto));
        CreateCkdPoResultDto resultDto;
        try {
            resultDto = poRfcService.doCreateCkdPo(erpInterface, dto);
            log.info("doCreateCkdPo return:{}", JSONUtil.toJsonStr(resultDto));
        } catch (JCoException e) {
            log.info("doCreateCkdPo error:{}", e.getMessage());
            return R.no(e.getMessage());
        }
        if (resultDto.getCode() != 0) {
            return R.no(resultDto.getMessage());
        }
        return R.ok(resultDto);
    }


    public void productShipPgi(String sapClient, String orgCode, List<String> allowRunPlantCodeList) {
        List<SysDict> notPgiDictList = sysDictMapper.selectDictList("WMS_DISABLE_PGI_PLANT_CONFIG");
        List<String> notPgiPlantCodeList = notPgiDictList.stream().map(item -> item.getDictCode()).collect(Collectors.toList());
        List<WmsDocProductShipHeader> shipHeaderList =wmsProductShipHeaderMapper
                .selectList(Wrappers.<WmsDocProductShipHeader>lambdaQuery()
                        .eq(WmsDocProductShipHeader::getOrgCode, orgCode)
                        .eq(WmsDocProductShipHeader::getStatus, "3")
                        .eq(WmsDocProductShipHeader::getPgiFlag, "0")
                        .ne(WmsDocProductShipHeader::getDocType, "TRADING_PRODUCT_DELIVERY")
                        .in(WmsDocProductShipHeader::getSapPlantCode, allowRunPlantCodeList)
                        // LX扣账排除CXT4
                        .notIn(CollUtil.isNotEmpty(notPgiPlantCodeList), WmsDocProductShipHeader::getSapPlantCode, notPgiPlantCodeList)
                        .eq(WmsDocProductShipHeader::getIsDeleted, Boolean.FALSE));
        String date = DateTimeFormatter.ofPattern("yyyyMMdd").format(LocalDate.now());
        for (WmsDocProductShipHeader shipHeader : shipHeaderList) {
            try {
                CkdShipPgiResultDto resultDto = poRfcService.ckdShipPgi(sapClient, shipHeader.getDnNo(), date);
                log.info("productShipPgi request dnNo:{}, return:{}", shipHeader.getDnNo(), JSONUtil.toJsonStr(resultDto));
                if (StringUtil.isNotEmpty(resultDto.getPgiNo())) {
                    wmsProductShipHeaderMapper.update(null, Wrappers.<WmsDocProductShipHeader>lambdaUpdate()
                            .eq(WmsDocProductShipHeader::getId, shipHeader.getId())
                            .set(WmsDocProductShipHeader::getPgiMsg, resultDto.getPgiNo())
                            .set(WmsDocProductShipHeader::getPgiFlag, "1")
                            .set(WmsDocProductShipHeader::getPgiDate, LocalDateTime.now())
                            .set(WmsDocProductShipHeader::getLastEditor, "sysadmin")
                            .set(WmsDocProductShipHeader::getLastEditedDt, System.currentTimeMillis()));
                } else {
                    wmsProductShipHeaderMapper.update(null, Wrappers.<WmsDocProductShipHeader>lambdaUpdate()
                            .eq(WmsDocProductShipHeader::getId, shipHeader.getId())
                            .set(WmsDocProductShipHeader::getPgiDate, LocalDateTime.now())
                            .set(WmsDocProductShipHeader::getPgiMsg, resultDto.getMsg())
                            .set(WmsDocProductShipHeader::getLastEditor, "sysadmin")
                            .set(WmsDocProductShipHeader::getLastEditedDt, System.currentTimeMillis()));
                }
            } catch (JCoException e) {
                log.info("productShipPgi error:{}", e.getMessage());
                wmsProductShipHeaderMapper.update(null, Wrappers.<WmsDocProductShipHeader>lambdaUpdate()
                        .eq(WmsDocProductShipHeader::getId, shipHeader.getId())
                        .set(WmsDocProductShipHeader::getPgiDate, LocalDateTime.now())
                        .set(WmsDocProductShipHeader::getPgiMsg, e.getMessage())
                        .set(WmsDocProductShipHeader::getLastEditor, "sysadmin")
                        .set(WmsDocProductShipHeader::getLastEditedDt, System.currentTimeMillis()));
            }
        }
    }
}
