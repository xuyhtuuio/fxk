package com.maxnerva.cloudmes.service.wh;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.entity.qms.SyncQmsMsdLevelVO;
import com.maxnerva.cloudmes.entity.qms.SyncQmsValidVO;
import com.maxnerva.cloudmes.entity.wh.WmsPkgInfo;

import java.util.List;

/**
 * @Author hgx
 * @Description
 * @Date 2023/6/1
 */
public interface IWmsPkgInfoService extends IService<WmsPkgInfo> {
    int expireLockMaterial();

    /**
     * 当工单锁料时间离当前时间超过了二十四小时，将现在工单锁料的pkg自动解锁
     */
    void unLockMaterialAuto();

    /**
     * 根据工单缺料记录，生成特采单
     */
    void generateTcDoc(String orgCode);

    /**
     * 特采单抛转
     */
    void postTcDoc(String orgCode);

    void materialMfgSyncFromQms(List<SyncQmsValidVO> syncQmsValidVOList);

    void materialMfgLevel(List<SyncQmsMsdLevelVO> syncQmsMsdLevelVOList);
}
