package com.maxnerva.cloudmes.service.sap.gr;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.maxnerva.cloudmes.common.response.Result;
import com.maxnerva.cloudmes.service.sap.gr.model.*;
import com.maxnerva.cloudmes.service.sap.po.model.PoItemInfoDto;
import com.maxnerva.cloudmes.service.sap.util.SapPoolFactory;
import com.sap.conn.jco.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author H7109018
 */
@Slf4j
@Service
public class GrRfcService {

    @Autowired
    SapPoolFactory sapPoolFactory;


    /**
     * 依据PO生成GR
     *
     * @param inputEntity
     * @return
     */
    public Result doGenerateGrByPoNumber(String sapClient, GenerateGrByPoNumberDto inputEntity) throws JCoException {

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        // SAP wo header interface
        JCoFunction function = pool.getRepository().getFunction("Z_MMFM031");

        JCoParameterList inputParams = function.getImportParameterList();

        JCoStructure headerSAP = inputParams.getStructure("ITAB_HEADER");

        // GR日期
        headerSAP.setValue("PSTNG_DATE", inputEntity.getTransactionDate());
        headerSAP.setValue("DOC_DATE", inputEntity.getDocDate());
        headerSAP.setValue("REF_DOC_NO", inputEntity.getRefDocNo());
        if (StrUtil.isNotEmpty(inputEntity.getInvoiceNo())) {
            headerSAP.setValue("HEADER_TXT",inputEntity.getInvoiceNo());
        }
        JCoTable detail = function.getTableParameterList().getTable("ITAB_ITEM");
        detail.appendRow();
        detail.setRow(0);
        // 料号
        detail.setValue("MATERIAL", inputEntity.getPartNo());
        detail.setValue("PLANT", inputEntity.getPlant());
        //空是待驗, 良品
        if (StringUtils.isNotBlank(inputEntity.getStckType())) {
            detail.setValue("STCK_TYPE", inputEntity.getStckType());
        }

        if (!StringUtils.isBlank(inputEntity.getWarehouseName())) {
            detail.setValue("STGE_LOC", inputEntity.getWarehouseName());
        }

        detail.setValue("ENTRY_QNT", inputEntity.getQty());
        detail.setValue("ENTRY_UOM", inputEntity.getUnit());
        detail.setValue("PO_NUMBER", inputEntity.getPoNumber());
        detail.setValue("PO_ITEM", inputEntity.getPoItem());
        if (StringUtils.isNotBlank(inputEntity.getBatch())) {
            detail.setValue("BATCH", inputEntity.getBatch());
        }
        function.execute(pool);

        JCoParameterList exportlist = function.getExportParameterList();

        // GR单号
        String grNo = String.valueOf(exportlist.getValue("MATERIALDOCUMENT"));

        if (StringUtils.isNotBlank(grNo)) {

            return Result.success(grNo);

        } else {
            // message
            JCoTable messgeTable = function.getTableParameterList().getTable("RETURN");
            if (messgeTable != null && messgeTable.getNumRows() > 0) {
                messgeTable.setRow(0);
                log.error("SAP GR 产生失败,原因:" + messgeTable.getString("MESSAGE"));
                return Result.failure(messgeTable.getString("MESSAGE"));
            } else {
                log.error("SAP沒有回傳異常信息");
                return Result.failure("SAP沒有回傳異常信息");
            }
        }

    }

    /**
     * 没有PO生成GR
     *
     * @param sapClient
     * @param inputEntity
     * @return
     * @throws JCoException
     */
    public Result doGenerateGrWithOutPoNumber(String sapClient, GenerateGrWithoutPoNumberDto inputEntity) throws JCoException {

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        JCoFunction function = pool.getRepository().getFunction("Z_MMFM032");

        JCoParameterList inputParams = function.getImportParameterList();

        JCoStructure headerSAP = inputParams.getStructure("ITAB_HEADER");

        // GR日期
        headerSAP.setValue("PSTNG_DATE", inputEntity.getTransactionDate());
        headerSAP.setValue("REF_DOC_NO", inputEntity.getRefDocNo());
        headerSAP.setValue("HEADER_TXT", inputEntity.getUserName());
        inputParams.setValue("ITAB_HEADER", headerSAP);

        JCoTable detail = function.getTableParameterList().getTable("ITAB_ITEM");

        detail.appendRow();
        detail.setRow(0);
        detail.setValue("PLANT", inputEntity.getPlant());
        // 料號
        detail.setValue("MATERIAL", inputEntity.getPartNo());
        if (StringUtils.isNotBlank(inputEntity.getPartVersion())) {
            // 版次
            detail.setValue("BATCH", inputEntity.getPartVersion());
        }
        if (StringUtils.isNotBlank(inputEntity.getWarehouseName())) {
            //仓码
            detail.setValue("STGE_LOC", inputEntity.getWarehouseName());
        }
        // 數量
        detail.setValue("ENTRY_QNT", inputEntity.getQty());

        function.execute(pool);

        JCoParameterList exportlist = function.getExportParameterList();

        // GR单号
        String grNo = String.valueOf(exportlist.getValue("MATERIALDOCUMENT"));

        if (StringUtils.isBlank(grNo)) {
            // error message
            JCoTable messgeTable = function.getTableParameterList().getTable("RETURN");
            if (messgeTable != null && messgeTable.getNumRows() > 0) {
                messgeTable.setRow(0);
                log.error("SAP GR 产生失败,原因:" + messgeTable.getString("MESSAGE"));
                return Result.success(messgeTable.getString("MESSAGE"));
            } else {
                log.error("SAP沒有回傳異常信息");
                return Result.failure("SAP沒有回傳異常信息");
            }
        } else {
            PoItemInfoDto po = new PoItemInfoDto();
            // PO info
            JCoTable poTable = function.getTableParameterList().getTable("ITAB_ITEM");
            if (poTable != null && poTable.getNumRows() > 0) {
                po.setPlantCode(poTable.getString("PLANT"));
                po.setPoNumber(poTable.getString("PO_NUMBER"));
                po.setPoItem(poTable.getString("PO_ITEM"));
            } else {
                log.error("SAP GR 产生失败,原因:SAP没有回传PO[ITAB_ITEM]信息");
            }

            return Result.data(-100, po, grNo);
        }

    }

    /**
     * VMI 生成GR 无PO，入良品仓，良品状态
     *
     * @param inputEntity
     * @return
     */
    public Result doGenerateVmiGr(String sapClient, GenerateVmiGrDto inputEntity) throws JCoException {

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        JCoFunction function = pool.getRepository().getFunction("Z_MMFM032");

        JCoParameterList inputParams = function.getImportParameterList();

        JCoStructure headerSAP = inputParams.getStructure("ITAB_HEADER");

        // GR日期
        headerSAP.setValue("PSTNG_DATE", inputEntity.getTransactionDate());
        //不能少
        headerSAP.setValue("DOC_DATE", inputEntity.getTransactionDate());
        //SH单号

        headerSAP.setValue("REF_DOC_NO", inputEntity.getReceiptNumber());
        //内交单号
        if (StringUtils.isNotBlank(inputEntity.getLocalDealNumber())) {
            headerSAP.setValue("HEADER_TXT", inputEntity.getLocalDealNumber());
        }

        inputParams.setValue("ITAB_HEADER", headerSAP);

        // VMI收货必传，非保税收货不用传
        inputParams.setValue("ASNNO", inputEntity.getReceiptNumber());

        JCoTable detail = function.getTableParameterList().getTable("ITAB_ITEM");
        detail.appendRow();
        detail.setRow(0);
        //工厂
        detail.setValue("PLANT", inputEntity.getPlant());

        //VENDOR
        if (StringUtils.isNotBlank(inputEntity.getVendor())) {
            detail.setValue("VENDOR", inputEntity.getVendor());
        }

        // 料號
        detail.setValue("MATERIAL", inputEntity.getPartNo());
        if (StringUtils.isNotBlank(inputEntity.getPartVersion())) {
            // 版次
            detail.setValue("BATCH", inputEntity.getPartVersion());
        }
        // 數量
        detail.setValue("ENTRY_QNT", inputEntity.getQty());
        //仓码
        if (StringUtils.isNotBlank(inputEntity.getWarehouseName())) {
            detail.setValue("STGE_LOC", inputEntity.getWarehouseName());
        }

        //内交项次
        if (StringUtils.isNotBlank(inputEntity.getLocalDealItem())) {
            detail.setValue("ITEM_TEXT", inputEntity.getLocalDealItem());
        }

        function.execute(pool);

        JCoParameterList exportlist = function.getExportParameterList();

        // GR单号
        String grNo = String.valueOf(exportlist.getValue("MATERIALDOCUMENT"));

        if (StringUtils.isBlank(grNo)) {
            // error message
            JCoTable messgeTable = function.getTableParameterList().getTable("RETURN");
            if (messgeTable != null && messgeTable.getNumRows() > 0) {
                messgeTable.setRow(0);
                log.error("SAP GR 产生失败,原因:" + messgeTable.getString("MESSAGE"));
                return Result.failure(messgeTable.getString("MESSAGE"));
            } else {
                log.error("SAP沒有回傳異常信息");
                return Result.failure("SAP沒有回傳異常信息");
            }
        } else {
            PoItemInfoDto po = new PoItemInfoDto();
            // PO info
            JCoTable poTable = function.getTableParameterList().getTable("ITAB_ITEM");

            if (poTable != null && poTable.getNumRows() > 0) {
                poTable.setRow(0);
                po.setPartNo(poTable.getString("MATERIAL"));
                po.setPlantCode(poTable.getString("PLANT"));
                po.setWarehouseCode(poTable.getString("STGE_LOC"));
                po.setQuantity(poTable.getBigDecimal("ENTRY_QNT"));
                po.setUnit(poTable.getString("ENTRY_UOM"));
                po.setPoNumber(poTable.getString("PO_NUMBER"));
                po.setPoItem(poTable.getString("PO_ITEM"));
            }

            JCoTable poInfoTable = function.getTableParameterList().getTable("PO_MATNR");

            if (poInfoTable != null && poInfoTable.getNumRows() > 0) {
                poInfoTable.setRow(0);
                po.setMfrPartNo(poInfoTable.getString("MFRPN"));
                // po.setMfrNr(poInfoTable.getString("MFRNR"));
                po.setMfrName(poInfoTable.getString("NAME1"));
                //po.setLifNr(poInfoTable.getString("LIFNR"));
                //po.setEmatn(poInfoTable.getString("EMATN"));
            }

            return Result.data(0, po, grNo);
        }

    }

    /**
     * 物料待验状态转良品状态
     *
     * @param inputDto
     * @return
     */
    public Result doChangeMaterialToGoodStatus(String sapClient, ChangeMaterialToGoodStatusDto inputDto) throws JCoException {

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        JCoFunction function = pool.getRepository().getFunction("Z_MMFM033");

        JCoTable goodsmvtTable = function.getTableParameterList().getTable("GOODSMVT");

        goodsmvtTable.appendRow();
        goodsmvtTable.setRow(0);
        goodsmvtTable.setValue("MATERIAL", inputDto.getPartNo());
        goodsmvtTable.setValue("PLANT", inputDto.getPlant());
        goodsmvtTable.setValue("STO_LOC", inputDto.getToWarehouseName());
        goodsmvtTable.setValue("QTY", inputDto.getQty());
        goodsmvtTable.setValue("GRN", inputDto.getGrNumber());
        goodsmvtTable.setValue("GR_YEAR", inputDto.getGrDate());

        function.execute(pool);

        JCoTable returnTable = function.getTableParameterList().getTable("RETURN");

        String grNo = String.valueOf(returnTable.getString("MBLNR"));

        if (StringUtils.isNotBlank(grNo)) {

            return Result.success(grNo);

        } else {

            return Result.failure(returnTable.getString("MEG"));
        }
    }

    /**
     * 取GR list
     *
     * @return
     */
    public List<GrInfoDto> doGetGrInfo(String sapClient, String plantCode, String costCenterCode, String startDt, String endDt) throws JCoException {

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        JCoFunction function = pool.getRepository().getFunction("Z_MMFM038");

        JCoParameterList inputParams = function.getImportParameterList();

        inputParams.setValue("P_CWERKS", plantCode);
        inputParams.setValue("P_CBUKRS", costCenterCode);
        inputParams.setValue("P_DDATUMF", startDt);
        inputParams.setValue("P_DDATUMT", endDt);
        inputParams.setValue("RPT_NAME", "1");

        function.execute(pool);

        JCoTable grItemList = function.getTableParameterList().getTable("GRITEM");

        List<GrInfoDto> grInfoDtos = new ArrayList<>();

        if (grItemList != null && grItemList.getNumRows() > 0) {
            for (int i = 0; i < grItemList.getNumRows(); i++) {
                GrInfoDto g = new GrInfoDto();
                grItemList.setRow(i);
                g.setGrNumber(grItemList.getString("MBLNR"));
                g.setGrItem(grItemList.getString("ZEILE"));
                g.setPlantCode(grItemList.getString("WERKS"));
                g.setTradingCode(grItemList.getString("SUPPLIER"));
                g.setQty(grItemList.getBigDecimal("ERFMG"));
                g.setPartNo(grItemList.getString("MATNR"));
                g.setPartDesc(grItemList.getString("MAKTX"));
                g.setValueType(grItemList.getString("CHARG"));
                g.setPoNumber(grItemList.getString("EBELN"));
                g.setPoItem(grItemList.getString("EBELP"));
                g.setBom(grItemList.getString("ERFME"));
                g.setWarehouseCode(grItemList.getString("LGORT"));
                g.setMovementType(grItemList.getString("MVT"));
                g.setReturnGrNumber(grItemList.getString("LFBNR"));
                grInfoDtos.add(g);
            }

        }
        return grInfoDtos;
    }

    public Result doGenerateTradingInGrByPoNumber(String sapClient, GenerateTradingInGrByPoNumberDto inputEntity) throws JCoException {
        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);
        // SAP wo header interface
        JCoFunction function = pool.getRepository().getFunction("Z_MMFM031");
        JCoParameterList inputParams = function.getImportParameterList();
        JCoStructure headerSAP = inputParams.getStructure("ITAB_HEADER");
        // GR日期
        headerSAP.setValue("PSTNG_DATE", inputEntity.getTransactionDate());
        headerSAP.setValue("DOC_DATE", inputEntity.getDocDate());
        headerSAP.setValue("REF_DOC_NO", inputEntity.getRefDocNo());
        //内交入加的
        headerSAP.setValue("HEADER_TXT", inputEntity.getRefDocNo());
        JCoTable detail = function.getTableParameterList().getTable("ITAB_ITEM");
        detail.appendRow();
        detail.setRow(0);
        // 料号
        detail.setValue("MATERIAL", inputEntity.getPartNo());
        detail.setValue("PLANT", inputEntity.getPlant());
        //空是待驗, 良品
        if (StringUtils.isNotBlank(inputEntity.getStckType())) {
            detail.setValue("STCK_TYPE", inputEntity.getStckType());
        }
        if (!StringUtils.isBlank(inputEntity.getWarehouseName())) {
            detail.setValue("STGE_LOC", inputEntity.getWarehouseName());
        }
        detail.setValue("ENTRY_QNT", inputEntity.getQty());
        detail.setValue("ENTRY_UOM", inputEntity.getUnit());
        detail.setValue("PO_NUMBER", inputEntity.getPoNumber());
        detail.setValue("PO_ITEM", inputEntity.getPoItem());
        detail.setValue("MOVE_TYPE", "101");
        detail.setValue("VENDOR", inputEntity.getVendor());
        detail.setValue("ITEM_TEXT", inputEntity.getItemText());
        if (StringUtils.isNotBlank(inputEntity.getBatch())) {
            detail.setValue("BATCH", inputEntity.getBatch());
        }
        function.execute(pool);
        JCoParameterList exportlist = function.getExportParameterList();
        // GR单号
        String grNo = String.valueOf(exportlist.getValue("MATERIALDOCUMENT"));
        if (StringUtils.isNotBlank(grNo)) {
            return Result.success(grNo);
        } else {
            // message
            JCoTable messgeTable = function.getTableParameterList().getTable("RETURN");
            if (messgeTable != null && messgeTable.getNumRows() > 0) {
                messgeTable.setRow(0);
                log.error("SAP GR 产生失败,原因:" + messgeTable.getString("MESSAGE"));
                return Result.failure(messgeTable.getString("MESSAGE"));
            } else {
                log.error("SAP沒有回傳異常信息");
                return Result.failure("SAP沒有回傳異常信息");
            }
        }

    }
}


