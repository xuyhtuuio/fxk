package com.maxnerva.cloudmes.service.sap.po.model;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 创建SO、DN 结果
 *
 * @author H7109018
 */
@Data
public class CreateDnResultDto implements Serializable {

    private static final long serialVersionUID = -1L;

    /**
     * DN
     */
    private String dnNumber;

    /**
     * SO
     */
    private String soNumber;

    /**
     * result
     */
    private String result;

}
