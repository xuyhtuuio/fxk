package com.maxnerva.cloudmes.service.doc;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpResponse;
import cn.hutool.json.JSONUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.config.Constants;
import com.maxnerva.cloudmes.entity.doc.WmsDocTransfer;
import com.maxnerva.cloudmes.entity.spm.TransferDocToSpmVO;
import com.maxnerva.cloudmes.mapper.doc.WmsDocTransferMapper;
import com.maxnerva.cloudmes.service.datahub.DataHubService;
import com.maxnerva.cloudmes.service.sap.material.MaterialRfcService;
import com.maxnerva.cloudmes.service.sap.wh.WhRfcService;
import com.maxnerva.cloudmes.service.sap.wh.model.TransferDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Description 转仓单过账服务
 * @Author Likun
 * @Date 2022/8/30
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Service
@Slf4j
public class TransferDocPostingService {

    @Autowired
    WmsDocTransferMapper docTransferMapper;

    @Autowired
    WhRfcService whRfcService;

    @Autowired
    MaterialRfcService materialRfcService;

    @Autowired
    DataHubService dataHubService;

    /**
     * 转仓单过账SAP 311 跨工厂过账301
     */
    public void docTransferPosting(String sapClientCode, String orgCode, List<String> indentifyList, String postDate) {

        if ("N".equalsIgnoreCase(postDate)) {
            return;
        }

        //需过账DOC transfer list
        List<WmsDocTransfer> docList = docTransferMapper.selectList(Wrappers.<WmsDocTransfer>lambdaQuery()
                .eq(WmsDocTransfer::getOrgCode, orgCode)
                .eq(WmsDocTransfer::getIsUpload, "0")
                .in(WmsDocTransfer::getIdentify, indentifyList)
        );

        if (CollUtil.isEmpty(docList)) {
            return;
        }

        docList.forEach(w -> {
            if ("N".equalsIgnoreCase(Constants.continueJob)) {
                return;
            }
            try {
                log.info("TransferPosting content: {}", JSONUtil.toJsonStr(w));
                /*//如果组织为CABG_VN,则赋值版次为A
                if ("CABG_VN".equals(orgCode)) {
                    w.setOldMaterialVersion("A");
                }*/
                // 仓码 + 料号 取value type from sap
//                String s1 = materialRfcService.doGetMaterialValueType(sapClientCode, w.getOldPlantCode(), w.getOldMaterialCode(), w.getOldWarehoseCode());
                String s1 = materialRfcService.getValueType(sapClientCode, orgCode, w.getOldPlantCode(),
                        w.getOldMaterialCode(), w.getOldMaterialVersion(), w.getOldWarehoseCode());
                if (StringUtils.isBlank(s1)) {
                    String error = String.format("TransferDoc[%s] warehouseCode [%s] partNo [%s] not found value type from SAP", w.getId(), w.getOldWarehoseCode(),
                            w.getOldMaterialCode());
                    log.error(error);
                    throw new RuntimeException("not found value type from SAP");

                }

                TransferDto dto = setTransfer311Dto(w, postDate);

                dto.setValueType(s1);

                //posting 311
                String s = whRfcService.doTransfer(sapClientCode, dto);
                log.info("TransferPosting success content: {} , sap result: {}", JSONUtil.toJsonStr(w), s);

                // update
                WmsDocTransfer updateDetail = new WmsDocTransfer();
                updateDetail.setId(w.getId());
                updateDetail.setIsUpload("1");
                updateDetail.setSapReturnMessage("OK");
                updateDetail.setSapReturnNumber(s);
                updateDetail.setSapReturnResult(s1);
                updateDetail.setSapUploadData(new Date());
                updateDetail.updateById();

            } catch (Exception e) {
                WmsDocTransfer updateDetail = new WmsDocTransfer();
                updateDetail.setId(w.getId());
                updateDetail.setSapReturnMessage(e.getMessage());
                updateDetail.setSapUploadData(new Date());
                updateDetail.updateById();
                log.error("TransferPosting 311 doc: {} ,errorMsg:{}", JSONUtil.toJsonStr(w), e.getMessage());

            }
        });


    }

    private TransferDto setTransfer311Dto(WmsDocTransfer w, String postDate) {
        TransferDto dto = new TransferDto();
        dto.setTransactionDate(postDate);
        dto.setDocDate(postDate);
        if(!w.getOldPlantCode().equals(w.getTargetPlantCode())) {
            dto.setMoveType("301");
        }else {
            dto.setMoveType("311");
        }
        dto.setGmCode("04");
        //默认 NOCOST
        //dto.setValueType("COSTRM");
        dto.setQty(w.getConfirmPostingQty().toString());
        dto.setUnit(StringUtils.isNotBlank(w.getUom()) ? w.getUom() : "EA");
        //301 夸工厂转仓   04
        //311 同工厂转仓   04
        //309 料调        04
        dto.setFromPlant(w.getOldPlantCode());
        dto.setFromWarehouseName(w.getOldWarehoseCode());
        dto.setFromPartNo(w.getOldMaterialCode());
        if (StringUtils.isNotBlank(w.getOldMaterialVersion())) {
            dto.setFromPartVersion(w.getOldMaterialVersion());
            dto.setToPartVersion(w.getOldMaterialVersion());
        }
        dto.setToPlant(w.getTargetPlantCode());
        dto.setToWarehouseName(w.getTargetWarehoseCode());
        dto.setToPartNo(w.getTargetMaterialCode());
        dto.setHeaderText(w.getDocNo());
        return dto;
    }

    public void syncTransferToSpm(String orgCode) {
        List<WmsDocTransfer> wmsDocTransferList = docTransferMapper.selectSyncTransferDoc(orgCode);
        List<TransferDocToSpmVO> transferDocToSpmVOList = CollUtil.newArrayList();
        for (WmsDocTransfer wmsDocTransfer : wmsDocTransferList) {
            TransferDocToSpmVO transferDocToSpmVO = new TransferDocToSpmVO();
            transferDocToSpmVO.setDocNo(wmsDocTransfer.getFromDocNo());
            transferDocToSpmVO.setOrgCode(wmsDocTransfer.getOrgCode());
            transferDocToSpmVOList.add(transferDocToSpmVO);
        }
        log.info("orgCode:{},syncTransferToSpm request:{}", orgCode, JSONUtil.toJsonStr(transferDocToSpmVOList));
        if (CollUtil.isNotEmpty(transferDocToSpmVOList)) {
            HttpResponse httpResponse = dataHubService.syncTransferToSpm(transferDocToSpmVOList);
            log.info("orgCode:{},syncTransferToSpm request:{},response:{}", orgCode,
                    JSONUtil.toJsonStr(transferDocToSpmVOList), httpResponse.body());
            String body = httpResponse.body();
            if (StrUtil.isNotEmpty(body) && 200 == httpResponse.getStatus()) {
                JSONObject dataHubReturnInfo = JSON.parseObject(body);
                int code = dataHubReturnInfo.getInteger("code");
                if (200 == code) {
                   /* List<Integer> idList = wmsDocTransferList.stream().map(WmsDocTransfer::getId)
                            .collect(Collectors.toList());*/
                    List<String> fromDocNoList = transferDocToSpmVOList.stream().map(TransferDocToSpmVO::getDocNo)
                            .collect(Collectors.toList());
                    docTransferMapper.update(null, Wrappers.<WmsDocTransfer>lambdaUpdate()
                            .in(WmsDocTransfer::getFromDocNo, fromDocNoList)
                            .set(WmsDocTransfer::getToSpmFlag, "1"));
                }
            }
        }
    }
}
