package com.maxnerva.cloudmes.service.sap.material.model;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author H7109018
 */
@Data
public class MaterialStandardPriceDto implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * 工厂
     */
    private String plant;

    /**
     * 料号
     */
    private String partNo;

    /**
     * 版次
     */
    private String partVersion;

    /**
     * 币别
     */
    private String currency;

    /**
     * 标准单价
     */
    private BigDecimal standardPrice;

    /**
     * 标准单价数量
     */
    private BigDecimal priceUnit;


}
