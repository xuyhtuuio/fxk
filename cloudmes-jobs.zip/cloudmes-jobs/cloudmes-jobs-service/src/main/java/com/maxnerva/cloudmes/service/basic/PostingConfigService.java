package com.maxnerva.cloudmes.service.basic;

import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.entity.basic.WmsPostingScheduleSettingEntity;
import com.maxnerva.cloudmes.mapper.basic.WmsPostingScheduleSettingMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @ClassName IWoService
 * @Description 工单管理service
 * @Author Likun
 * @Date 2022/8/30
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Service
@Slf4j
public class PostingConfigService {

    @Autowired
    WmsPostingScheduleSettingMapper wmsPostingScheduleSettingMapper;


    /**
     * 取过账日期
     */
    public String getPostDate(String orgCode, LocalDateTime nowDateTime) {

        LocalDateTime nowDatetime = nowDateTime == null ? LocalDateTime.now() : nowDateTime;

        WmsPostingScheduleSettingEntity scheduleSetting = wmsPostingScheduleSettingMapper.selectOne(Wrappers.<WmsPostingScheduleSettingEntity>lambdaQuery()
                .eq(WmsPostingScheduleSettingEntity::getOrdCode, orgCode)
                .le(WmsPostingScheduleSettingEntity::getBeginDatetime, nowDatetime)
                .ge(WmsPostingScheduleSettingEntity::getEndDatetime, nowDatetime)
                .last("limit 1")
        );

        if (ObjectUtil.isNotNull(scheduleSetting)) {
            if ("Y".equalsIgnoreCase(scheduleSetting.getPostingFlag())) {
                return scheduleSetting.getPostingDate().toString().replaceAll("-", "").replaceAll("/", "");
            } else {
                return "N";

            }
        }

        return LocalDate.now().toString().toString().replaceAll("-", "").replaceAll("/", "");

    }


    public String getTradingStatus(String orgCode, LocalDateTime nowDateTime) {
        LocalDateTime nowDatetime = nowDateTime == null ? LocalDateTime.now() : nowDateTime;

        WmsPostingScheduleSettingEntity scheduleSetting = wmsPostingScheduleSettingMapper.selectOne(Wrappers.<WmsPostingScheduleSettingEntity>lambdaQuery()
                .eq(WmsPostingScheduleSettingEntity::getOrdCode, orgCode)
                .le(WmsPostingScheduleSettingEntity::getTradingStartTime, nowDatetime)
                .ge(WmsPostingScheduleSettingEntity::getTradingEndTime, nowDatetime)
                .last("limit 1")
        );
        return ObjectUtil.isNotNull(scheduleSetting) ? "Y" : "N";
    }

    public String getCkdShipPgiStatus(String orgCode, LocalDateTime nowDateTime) {
        LocalDateTime nowDatetime = nowDateTime == null ? LocalDateTime.now() : nowDateTime;
        WmsPostingScheduleSettingEntity scheduleSetting = wmsPostingScheduleSettingMapper.selectOne(Wrappers.<WmsPostingScheduleSettingEntity>lambdaQuery()
                .eq(WmsPostingScheduleSettingEntity::getOrdCode, orgCode)
                .le(WmsPostingScheduleSettingEntity::getCkdShipPgiStartTime, nowDatetime)
                .ge(WmsPostingScheduleSettingEntity::getCkdShipPgiEndTime, nowDatetime)
                .last("limit 1")
        );
        return ObjectUtil.isNotNull(scheduleSetting) ? "Y" : "N";
    }
}
