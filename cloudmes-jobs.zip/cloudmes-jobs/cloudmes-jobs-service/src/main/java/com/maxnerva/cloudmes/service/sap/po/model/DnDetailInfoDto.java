package com.maxnerva.cloudmes.service.sap.po.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @author H7109018
 */
@Data
public class DnDetailInfoDto implements Serializable {

    private static final long serialVersionUID = -1L;
    private String dnNo;
    private String dnItem;
    private String partNo;
    private String custNo;
    private String warehouseCode;
    private Double requestQty;
    private String custPo;
}
