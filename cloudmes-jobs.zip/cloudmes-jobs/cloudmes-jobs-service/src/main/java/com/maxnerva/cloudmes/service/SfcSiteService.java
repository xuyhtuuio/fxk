package com.maxnerva.cloudmes.service;

import cn.hutool.core.util.StrUtil;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2023/06/13 14:13
 * @Version: 1.0
 */
public class SfcSiteService {

    // N ---> SFC
    // Y ---> MES
    public static String ENABLED_MES_INTERFACE = "N";

    /**
     * 获取sfc调用节点
     *
     * @param orgCode   组织
     * @param plantCode 工厂编码
     * @return sfc节点
     */
    public static String getSfcSite(String orgCode, String plantCode) {
        //SFC
        if ("N".equalsIgnoreCase(ENABLED_MES_INTERFACE)) {
            return StrUtil.isNotEmpty(plantCode) ? orgCode + "_" + plantCode : orgCode;
        }
        //MES
        return orgCode;
    }
}
