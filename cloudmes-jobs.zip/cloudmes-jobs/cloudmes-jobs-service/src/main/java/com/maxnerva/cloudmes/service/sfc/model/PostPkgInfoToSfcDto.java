package com.maxnerva.cloudmes.service.sfc.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/09/19 16:50
 * @Version: 1.0
 */
@Data
public class PostPkgInfoToSfcDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * pkg id
     */
    private String pkgId;
    /**
     * 鸿海料号
     */
    private String partNo;
    /**
     * 原始数量
     */
    private String qty;
    /**
     * 制造商名称
     */
    private String mfgName;
    /**
     * 制造商料号
     */
    private String mfgPartNo;
    /**
     * lot code
     */
    private String lotCode;
    /**
     * date Code
     */
    private String dateCode;
    /**
     * 当前数量
     */
    private String remainQty;
    /**
     * 操作员
     */
    private String empNo;
    /**
     * 发料工单
     */
    private String workOrderNo;
    /**
     * 被拆分PKGID
     */
    private String parentPkgId;
    /**
     * 原产地(2码)
     */
    private String placeOfOrigin;
    /**
     * 烧录check sum
     */
    private String checkSum;
    /**
     * OK/错误信息
     */
    private String result;

    private String plantCode;

    private String dataSource;

    @ApiModelProperty("有效期")
    private Integer effectiveDate;

    @ApiModelProperty("有效期截止日期")
    private String endDate;

    @ApiModelProperty("储位")
    private String binCode;

    @ApiModelProperty("载具")
    private String vehicleCode;

    @ApiModelProperty("产品料号")
    private String productNo;

    @ApiModelProperty("轨道号")
    private String feederNo;

    @ApiModelProperty("机台号")
    private String machineCode;
}
