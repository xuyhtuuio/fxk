package com.maxnerva.cloudmes.entity.basic;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @name:
 * @author: zhangyang
 * @dateTime: 2023/3/18 9:49
 */
@Data
@ApiModel("产品bom返回参数对象")
public class ProductBomFeignDTO implements Serializable {

    private static final long serialVersionUID = 4308094593390681134L;

    @ApiModelProperty("主键id")
    private Integer id;

    @ApiModelProperty("项次")
    private String item;

    @ApiModelProperty("零件料号")
    private String materialNo;

    @ApiModelProperty("单位")
    private String uom;

    @ApiModelProperty("主/替料")
    private String alternative;

    @ApiModelProperty("物料群组")
    private String altgroup;

    @ApiModelProperty("优先级")
    private String priority;

    @ApiModelProperty("位置")
    private String location;

    @ApiModelProperty("备注")
    private String bomnotes;

    @ApiModelProperty("主料料号")
    private String priMaterial;

    @ApiModelProperty("产品料号")
    private String productNo;

    @ApiModelProperty("基本用量")
    private Integer basicQty;

    @ApiModelProperty("ECN变更单号")
    private String ecnumber;

    @ApiModelProperty("产品分类")
    private String productType;

    @ApiModelProperty("工厂组织")
    private String orgCode;

    @ApiModelProperty("制造商料号")
    private String mfgMaterialCode;

    @ApiModelProperty("制造商名称")
    private String mfgName;

    @ApiModelProperty("混用标记")
    private String mixFlag;
}
