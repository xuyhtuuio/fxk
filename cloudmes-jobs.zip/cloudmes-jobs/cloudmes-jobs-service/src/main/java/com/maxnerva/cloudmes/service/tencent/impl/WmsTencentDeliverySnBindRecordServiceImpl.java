package com.maxnerva.cloudmes.service.tencent.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.entity.tencent.WmsTencentDeliverySnBindRecord;
import com.maxnerva.cloudmes.mapper.tencent.WmsTencentDeliverySnBindRecordMapper;
import com.maxnerva.cloudmes.service.tencent.IWmsTencentDeliverySnBindRecordService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 腾讯订单sn绑定记录表 服务实现类
 * </p>
 *
 * @author likun
 * @since 2025-05-21
 */
@Service
public class WmsTencentDeliverySnBindRecordServiceImpl extends ServiceImpl<WmsTencentDeliverySnBindRecordMapper, WmsTencentDeliverySnBindRecord> implements IWmsTencentDeliverySnBindRecordService {

}
