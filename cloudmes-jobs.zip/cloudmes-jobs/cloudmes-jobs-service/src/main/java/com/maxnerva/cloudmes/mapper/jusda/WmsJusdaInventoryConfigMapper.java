package com.maxnerva.cloudmes.mapper.jusda;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.jusda.WmsJusdaInventoryConfig;

public interface WmsJusdaInventoryConfigMapper extends BaseMapper<WmsJusdaInventoryConfig> {
}
