package com.maxnerva.cloudmes.service.wo.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class CusInfoDTO {
    @ApiModelProperty(value = "預報關單號")
    private String BSI01;

    @ApiModelProperty(value = "預報關單項次")
    private String BSI02;

    @ApiModelProperty(value = "報關單")
    private String BSI011;

    @ApiModelProperty(value = "报关单2")
    private String INVT_NO;

    @ApiModelProperty(value = "報關單項次")
    private String BSI25;

    @ApiModelProperty(value = "商品編號")
    private String BSI031;

    @ApiModelProperty(value = "商品名稱")
    private String BSI032;

    @ApiModelProperty(value = "申報要素（規格）")
    private String BSI033;

    @ApiModelProperty(value = "數量")
    private BigDecimal BSI04;

    @ApiModelProperty(value = "單位  007 pc 054 kpc")
    private String BSI05;

    @ApiModelProperty(value = "原產國")
    private String BSI06;

    @ApiModelProperty(value = "單價 不处理直接存")
    private BigDecimal BSI07;

    @ApiModelProperty(value = "实际單價 不处理直接存实际价格")
    private BigDecimal BSI26;

    @ApiModelProperty(value = "申報幣別")
    private String BSI08;

    @ApiModelProperty(value = "申報單位（部門）")
    private String BSI09;

    @ApiModelProperty(value = "PO")
    private String BSI12;

    @ApiModelProperty(value = "PO ITEM")
    private String BSI13;

    @ApiModelProperty(value = "料號")
    private String BSI14;

    @ApiModelProperty(value = "來源數量 換算單位後的")
    private BigDecimal BSI28;

    @ApiModelProperty(value = "起運國")
    private String BSH09;

    @ApiModelProperty(value = "目的地運國 （抵運國）")
    private String BSI35;

    @ApiModelProperty(value = "起運港")
    private String BSH13;

    @ApiModelProperty(value = "申报时间")
    private String BSH28;
}
