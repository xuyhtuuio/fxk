package com.maxnerva.cloudmes.entity.qms;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 从qms同步有效期log表
 * </p>
 *
 * @author likun
 * @since 2024-11-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsSyncMfgMaterialFromQmsLog对象", description="从qms同步有效期log表")
public class WmsSyncMfgMaterialFromQmsLog extends BaseEntity<WmsSyncMfgMaterialFromQmsLog> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "组织")
    private String orgCode;

    @ApiModelProperty(value = "厂商")
    private String mfg;

    @ApiModelProperty(value = "厂商料号")
    private String mfgMaterialNo;

    @ApiModelProperty(value = "期限")
    private String deadline;
}
