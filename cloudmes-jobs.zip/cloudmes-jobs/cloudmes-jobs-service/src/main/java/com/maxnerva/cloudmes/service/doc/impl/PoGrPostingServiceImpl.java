package com.maxnerva.cloudmes.service.doc.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.common.response.Result;
import com.maxnerva.cloudmes.entity.doc.WmsDocReceive;
import com.maxnerva.cloudmes.entity.outsourcing.WmsOutsourcingSapTransactionLog;
import com.maxnerva.cloudmes.entity.outsourcing.WmsOutsourcingWorkOrderDetail;
import com.maxnerva.cloudmes.entity.outsourcing.WmsOutsourcingWorkOrderHeader;
import com.maxnerva.cloudmes.entity.trading.WmsTradingRecordEntity;
import com.maxnerva.cloudmes.mapper.outsourcing.WmsOutsourcingSapTransactionLogMapper;
import com.maxnerva.cloudmes.mapper.outsourcing.WmsOutsourcingWorkOrderDetailMapper;
import com.maxnerva.cloudmes.mapper.outsourcing.WmsOutsourcingWorkOrderHeaderMapper;
import com.maxnerva.cloudmes.service.doc.IDocPostingService;
import com.maxnerva.cloudmes.service.sap.gr.GrRfcService;
import com.maxnerva.cloudmes.service.sap.gr.model.GenerateGrByPoNumberDto;
import com.maxnerva.cloudmes.service.sap.gr.model.GenerateTradingInGrByPoNumberDto;
import com.maxnerva.cloudmes.service.sap.gr.model.OutsourcingGrDto;
import com.maxnerva.cloudmes.service.sap.gr.model.OutsourcingGrItemDto;
import com.maxnerva.cloudmes.service.sap.material.MaterialRfcService;
import com.maxnerva.cloudmes.service.sap.po.PoRfcService;
import com.maxnerva.cloudmes.service.sap.wh.WhRfcService;
import com.maxnerva.cloudmes.service.sap.wh.model.MaterialStockInfoDto;
import com.sap.conn.jco.JCoException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Description: PG GR 过账
 * @Author: Chao Zhang
 * @Date: 2022/09/12 08:17
 * @Version: 1.0
 */
@Service
@Component("PO_GR")
@Slf4j
public class PoGrPostingServiceImpl implements IDocPostingService {

    @Autowired
    GrRfcService grRfcService;

    @Resource
    private PoRfcService poRfcService;

    @Resource
    private WmsOutsourcingWorkOrderDetailMapper wmsOutsourcingWorkOrderDetailMapper;

    @Resource
    private WmsOutsourcingWorkOrderHeaderMapper wmsOutsourcingWorkOrderHeaderMapper;

    @Resource
    private WmsOutsourcingSapTransactionLogMapper wmsOutsourcingSapTransactionLogMapper;

    @Resource
    private MaterialRfcService materialRfcService;

    @Resource
    private WhRfcService whRfcService;


    @Override
    public Result doPost(String sapClientCode, WmsDocReceive wmsDoc, String stckType, String postDate) {

        GenerateGrByPoNumberDto input = new GenerateGrByPoNumberDto();
        input.setTransactionDate(postDate);
        input.setDocDate(postDate);
        input.setRefDocNo(wmsDoc.getFromDocNo());
        input.setPartNo(wmsDoc.getPartNo());
        input.setPlant(wmsDoc.getPlantCode());
        input.setWarehouseName(wmsDoc.getSapWarehouseCode());
        input.setQty(wmsDoc.getConfirmQty().toString());
        input.setUnit(wmsDoc.getUomCode());
        input.setPoNumber(wmsDoc.getPoNo());
        input.setPoItem(wmsDoc.getPoItem());
        input.setBatch(wmsDoc.getPartNoVersion());
        input.setInvoiceNo(wmsDoc.getInvoiceNo());
        //待验状态传入 X ，不传入良品
        if (StringUtils.isNotBlank(stckType)) {
            input.setStckType(stckType);
        }


        try {
            Result result = grRfcService.doGenerateGrByPoNumber(sapClientCode, input);
            return result;

        } catch (Exception e) {
            log.error("PoGrPostingService error {}", e.getMessage());
            return Result.failure(e.getMessage());
        }

//        return Result.failure("SAP error");


    }

    @Override
    public Result doTradingInPosting(String sapClientCode, WmsDocReceive wmsDoc, WmsTradingRecordEntity tradingRecord, String stckType, String postDate) {
        GenerateTradingInGrByPoNumberDto input = new GenerateTradingInGrByPoNumberDto();
        input.setTransactionDate(postDate);
        input.setDocDate(postDate);
        input.setRefDocNo(tradingRecord.getTradingMsg());
        input.setPartNo(wmsDoc.getPartNo());
        input.setPlant(wmsDoc.getPlantCode());
        input.setWarehouseName(wmsDoc.getSapWarehouseCode());
        input.setQty(wmsDoc.getConfirmQty().toString());
        input.setUnit(wmsDoc.getUomCode());
        input.setPoNumber(wmsDoc.getPoNo());
        input.setPoItem(wmsDoc.getPoItem());

        input.setVendor(tradingRecord.getTradingFromCode());
        input.setBatch(tradingRecord.getToPartVersion());
        if (ListUtil.toList("CMB", "CMB_VN").contains(tradingRecord.getToOrgCode())) {
            input.setItemText("10");
        } else {
            if (StringUtils.isNotBlank(tradingRecord.getPartVersion())) {
                input.setItemText("10@" + tradingRecord.getPartNo() + "-" + tradingRecord.getPartVersion());
            } else {
                input.setItemText("10@" + tradingRecord.getPartNo());
            }
        }

        //待验状态传入 X ，不传入良品
        if (StringUtils.isNotBlank(stckType)) {
            input.setStckType(stckType);
        }
        log.info("doTradingInPosting, request {}", JSONUtil.toJsonStr(input));
        try {
            Result result = grRfcService.doGenerateTradingInGrByPoNumber(sapClientCode, input);
            log.info("doTradingInPosting, request {}，result：{}", JSONUtil.toJsonStr(input), JSONUtil.toJsonStr(result));
            return result;
        } catch (Exception e) {
            log.error("PoGrPostingService error {}", e.getMessage());
            return Result.failure(e.getMessage());
        }
    }

    @Override
    public Result doOutsourcingPosting(String sapClientCode, WmsDocReceive wmsDocReceive, String postDate) throws JCoException {
        String orgCode = wmsDocReceive.getOrgCode();
        String plantCode = wmsDocReceive.getPlantCode();
        OutsourcingGrDto dto = new OutsourcingGrDto();
        //待验状态传入 X ，不传入良品
        dto.setDocDate(postDate);
        dto.setGmCode("01");
        dto.setHeaderTxt("");
        List<OutsourcingGrItemDto> items = new ArrayList<>();
        //成品
        BigDecimal docQty = wmsDocReceive.getDocQty();
        OutsourcingGrItemDto poHeader = new OutsourcingGrItemDto();
        poHeader.setMovType("101");
        poHeader.setLineId("000001");
        poHeader.setParentId("000000");
        poHeader.setMvtInd("B");
        poHeader.setMatDocItem("0001");
        poHeader.setSerialNo("1");
        poHeader.setPartNo(wmsDocReceive.getPartNo());
        poHeader.setPartVersion(wmsDocReceive.getPartNoVersion());
        poHeader.setPlantCode(plantCode);
        poHeader.setWarehouseCode(wmsDocReceive.getSapWarehouseCode());
        poHeader.setVendorCode(wmsDocReceive.getVendorCode());
        String valueType = materialRfcService.getValueType(sapClientCode, orgCode, plantCode,
                wmsDocReceive.getPartNo(), wmsDocReceive.getPartNoVersion(), wmsDocReceive.getSapWarehouseCode());
        poHeader.setValueType(valueType);
        poHeader.setQty(wmsDocReceive.getDocQty().toString());
        poHeader.setBom(wmsDocReceive.getUomCode());
        poHeader.setPoNo(wmsDocReceive.getPoNo());
        poHeader.setPoItem(wmsDocReceive.getPoItem());
        items.add(poHeader);
        List<WmsOutsourcingWorkOrderDetail> detailList = wmsOutsourcingWorkOrderDetailMapper
                .selectList(Wrappers.<WmsOutsourcingWorkOrderDetail>lambdaQuery()
                        .eq(WmsOutsourcingWorkOrderDetail::getOrgCode, orgCode)
                        .eq(WmsOutsourcingWorkOrderDetail::getPlantCode, plantCode)
                        .eq(WmsOutsourcingWorkOrderDetail::getPoNo, wmsDocReceive.getPoNo()));
        //按群组分组
        int i = 2;
        Map<String, List<WmsOutsourcingWorkOrderDetail>> collect = detailList.stream()
                .collect(Collectors.groupingBy(WmsOutsourcingWorkOrderDetail::getPoItem));
        for (Map.Entry<String, List<WmsOutsourcingWorkOrderDetail>> entry : collect.entrySet()) {
            List<WmsOutsourcingWorkOrderDetail> details = entry.getValue();
            //是否有替代料
            long count = details.stream().filter(a -> a.getPartRelationship().equals("S")).count();
            if (count > 0) {
                //优先判断主料
                details.sort(Comparator.comparing(WmsOutsourcingWorkOrderDetail::getPartRelationship));
                WmsOutsourcingWorkOrderDetail detailM = details.stream()
                        .filter(a -> "M".equals(a.getPartRelationship())).findFirst().orElse(null);
                if (ObjectUtil.isNull(detailM) || detailM.getRatio().compareTo(BigDecimal.ZERO) == 0) {
                    continue;
                }
                //群组需过账数量
//                BigDecimal totalQty = detailM.getRatio().multiply(docQty).divide(detailM.getBasicUsage(),
//                        3, BigDecimal.ROUND_UP);
                BigDecimal totalQty = detailM.getRatio().multiply(docQty).setScale(3, BigDecimal.ROUND_UP);
                //sap群组库存总量
                BigDecimal sapStockQty = BigDecimal.ZERO;
                for (WmsOutsourcingWorkOrderDetail detail : details) {
                    List<MaterialStockInfoDto> sapDtoList = whRfcService.doGetStockInfo(sapClientCode,
                            plantCode, null, Arrays.asList(detail.getPartNo()),
                            Arrays.asList(detail.getPartVersion()));
                    if (CollUtil.isEmpty(sapDtoList)) {
                        continue;
                    }
                    MaterialStockInfoDto stockInfoDto = sapDtoList.stream().filter(s -> wmsDocReceive.getVendorCode()
                            .equals(s.getVendor())).findFirst().orElse(null);
                    if (ObjectUtil.isNull(stockInfoDto)) {
                        continue;
                    }
                    BigDecimal sapStock = stockInfoDto.stockTotalQty();
                    BigDecimal qty = sapStock.compareTo(totalQty) >= 0 ? totalQty : sapStock;
                    OutsourcingGrItemDto item1 = new OutsourcingGrItemDto();
                    item1.setMovType("543");
                    item1.setLineId("00000" + i);
                    item1.setParentId("000001");
                    item1.setMvtInd("");
                    item1.setMatDocItem("0002");
                    item1.setSerialNo(String.valueOf(i));
                    item1.setPartNo(detail.getPartNo());
                    item1.setPartVersion(detail.getPartVersion());
                    item1.setPlantCode(detail.getPlantCode());
                    item1.setWarehouseCode(detail.getSapWarehouseCode());
                    item1.setVendorCode(wmsDocReceive.getVendorCode());
                    String vt = materialRfcService.getValueType(sapClientCode, orgCode, plantCode, detail.getPartNo(),
                            detail.getPartVersion(), detail.getSapWarehouseCode());
                    item1.setValueType(vt);
                    item1.setBom(detail.getUomCode());
                    item1.setPoNo(detail.getPoNo());
                    item1.setPoItem(wmsDocReceive.getPoItem());
                    item1.setQty(qty.toString());
                    item1.setDetailId(detail.getId());
                    items.add(item1);
                    totalQty = totalQty.subtract(qty);
                    sapStockQty = sapStockQty.add(sapStock);
                    i++;
                    if (totalQty.compareTo(BigDecimal.ZERO) == 0) {
                        break;
                    }
                }
                if (totalQty.compareTo(sapStockQty) > 0) {
                    return Result.failure(String.format("poitem:%s sap stock is not enough", entry.getKey()));
                }
            } else {
                for (WmsOutsourcingWorkOrderDetail d : details) {
                    OutsourcingGrItemDto item1 = new OutsourcingGrItemDto();
                    item1.setMovType("543");
                    item1.setLineId("00000" + i);
                    item1.setParentId("000001");
                    item1.setMvtInd("");
                    item1.setMatDocItem("0002");
                    item1.setSerialNo(String.valueOf(i));
                    item1.setPartNo(d.getPartNo());
                    item1.setPartVersion(d.getPartVersion());
                    item1.setPlantCode(d.getPlantCode());
                    item1.setWarehouseCode(d.getSapWarehouseCode());
                    item1.setVendorCode(wmsDocReceive.getVendorCode());
                    String vt = materialRfcService.getValueType(sapClientCode, orgCode, plantCode, d.getPartNo(),
                            d.getPartVersion(), d.getSapWarehouseCode());
                    item1.setValueType(vt);
//                    BigDecimal qty = docQty.multiply(d.getRatio()).divide(d.getBasicUsage(), 3, BigDecimal.ROUND_UP);
                    BigDecimal qty = docQty.multiply(d.getRatio()).setScale(3, BigDecimal.ROUND_UP);
                    item1.setQty(qty.toString());
                    item1.setBom(d.getUomCode());
                    item1.setPoNo(d.getPoNo());
                    item1.setPoItem(wmsDocReceive.getPoItem());
                    item1.setDetailId(d.getId());
                    items.add(item1);
                    i++;
                }
            }
        }
        dto.setItems(items);
        log.info("dto:{}", JSONUtil.toJsonStr(dto));
        try {
            String actual = poRfcService.doOutsourcingGr(sapClientCode, dto);
            log.info("doOutsourcingGr, request {}，result：{}", JSONUtil.toJsonStr(dto), actual);
            insertTransactionLog(orgCode, wmsDocReceive.getDocNo(), dto, detailList, actual);
            return Result.success(actual);
        } catch (Exception e) {
            log.error("doOutsourcingGr error {}", e.getMessage());
            return Result.failure(e.getMessage());
        }
    }

    private void insertTransactionLog(String orgCode, String docNo, OutsourcingGrDto outsourcingGrDto,
                                      List<WmsOutsourcingWorkOrderDetail> detailList, String sapReturnMsg) {
        List<OutsourcingGrItemDto> items = outsourcingGrDto.getItems();
        WmsOutsourcingWorkOrderHeader outsourcingWorkOrderHeader = wmsOutsourcingWorkOrderHeaderMapper
                .selectOne(Wrappers.<WmsOutsourcingWorkOrderHeader>lambdaQuery()
                        .eq(WmsOutsourcingWorkOrderHeader::getOrgCode, orgCode)
                        .eq(WmsOutsourcingWorkOrderHeader::getPlantCode, items.get(0).getPlantCode())
                        .eq(WmsOutsourcingWorkOrderHeader::getPoNo, items.get(0).getPoNo())
                        .last("limit 1"));
        items.forEach(item -> {
            WmsOutsourcingSapTransactionLog transactionLog = new WmsOutsourcingSapTransactionLog();
            if ("101".equals(item.getMovType())) {
                transactionLog.setRequiredQuantity(outsourcingWorkOrderHeader.getRequiredQuantity());
            } else {
                WmsOutsourcingWorkOrderDetail detail = detailList.stream().filter(
                        d -> item.getDetailId().equals(d.getId())).findFirst().orElse(null);
                transactionLog.setStockQty(detail.getStockQty());
                transactionLog.setRequiredQuantity(detail.getRequiredQuantity());
            }
            transactionLog.setOrgCode(orgCode);
            transactionLog.setPlantCode(item.getPlantCode());
            transactionLog.setPoNo(item.getPoNo());
            transactionLog.setPoItem(item.getPoItem());
            transactionLog.setPartNo(item.getPartNo());
            transactionLog.setUomCode(item.getBom());
            transactionLog.setSapWarehouseCode(item.getWarehouseCode());
            transactionLog.setPartVersion(item.getPartVersion());
            transactionLog.setVendorCode(item.getVendorCode());
            transactionLog.setOutsourcingPostingNo(docNo);
            transactionLog.setPostType(item.getMovType());
            transactionLog.setTransactionQty(new BigDecimal(item.getQty()));
            transactionLog.setTransactionSapQty(new BigDecimal(item.getQty()));
            transactionLog.setTransactionDate(LocalDateTime.now());
            transactionLog.setPostSapReturnMsg(sapReturnMsg);
            transactionLog.setPostSapReturnDt(LocalDateTime.now());
            transactionLog.setPostSapReturnFlag(1);
            transactionLog.setCreatedDt(LocalDateTime.now());
            wmsOutsourcingSapTransactionLogMapper.insert(transactionLog);
        });
    }
}
