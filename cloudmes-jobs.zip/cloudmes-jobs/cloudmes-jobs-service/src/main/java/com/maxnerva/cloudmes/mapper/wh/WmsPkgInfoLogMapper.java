package com.maxnerva.cloudmes.mapper.wh;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.wh.WmsPkgInfoLog;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2022-08-05
 */
public interface WmsPkgInfoLogMapper extends BaseMapper<WmsPkgInfoLog> {


}
