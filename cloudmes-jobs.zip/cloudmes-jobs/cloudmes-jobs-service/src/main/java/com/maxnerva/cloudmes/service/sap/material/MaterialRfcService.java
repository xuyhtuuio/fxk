package com.maxnerva.cloudmes.service.sap.material;


import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.github.pagehelper.util.StringUtil;
import com.maxnerva.cloudmes.entity.basic.SysDict;
import com.maxnerva.cloudmes.entity.deliver.WmsShipPkgBindRecord;
import com.maxnerva.cloudmes.mapper.basic.SysDictMapper;
import com.maxnerva.cloudmes.service.sap.material.model.AvlDto;
import com.maxnerva.cloudmes.service.sap.material.model.MaterialInfoDto;
import com.maxnerva.cloudmes.service.sap.material.model.MaterialStandardPriceDto;
import com.maxnerva.cloudmes.service.sap.util.SapPoolFactory;
import com.sap.conn.jco.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author H7109018
 */
@Slf4j
@Service
public class MaterialRfcService {

    @Autowired
    SapPoolFactory sapPoolFactory;

    @Autowired
    SysDictMapper sysDictMapper;

    /**
     * 取SAP 物料主档信息
     *
     * @return
     */
    public List<MaterialInfoDto> doGetMaterialInfo(String sapClient, String plant, String partNo, String fromDate, String endDate) throws JCoException {

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);
        // SAP wo header interface
        JCoFunction function = pool.getRepository().getFunction("Z_MMFM034");

        JCoParameterList inputParams = function.getImportParameterList();
        inputParams.setValue("P_WERKS", plant);

        if (StringUtils.isNotBlank(partNo)) {
            inputParams.setValue("P_MATNR", partNo);
        } else {
            if (StringUtils.isNotEmpty(fromDate)) {
                JCoTable itemTable = function.getTableParameterList().getTable("P_DATE");
                itemTable.appendRow();
                itemTable.setRow(0);
                itemTable.setValue("SIGN", "I");
                itemTable.setValue("OPTION", "BT");
                itemTable.setValue("LOW", fromDate);
                itemTable.setValue("HIGH", endDate);
            }
        }

        function.execute(pool);

        JCoTable messgeTable = function.getTableParameterList().getTable("ITAB");

        List<MaterialInfoDto> results = new ArrayList<>();

        if (messgeTable != null && messgeTable.getNumRows() == 0) {
            return results;
        }

        MaterialInfoDto materialEntity;
        for (int i = 0, rows = messgeTable.getNumRows(); i < rows; i++) {
            messgeTable.setRow(i);
            materialEntity = new MaterialInfoDto();
            materialEntity.setPlant(plant);
            materialEntity.setPartNo(messgeTable.getString("MATNR"));
            materialEntity.setPartVersion(messgeTable.getString("REVLV"));
            materialEntity.setMaterialType(
                    StringUtils.isBlank(messgeTable.getString("MAABC")) ? "X" : messgeTable.getString("MAABC"));
            materialEntity.setBuyer(messgeTable.getString("EKGRP"));
            materialEntity.setUnit(messgeTable.getString("MEINS"));
            materialEntity.setBuyerName(messgeTable.getString("EKNAM"));
            materialEntity.setContact(messgeTable.getString("EKTEL"));
            materialEntity.setPartDesc(messgeTable.getString("MAKTXE"));
            materialEntity.setProductType(messgeTable.getString("MTART"));
            //materialEntity.setLevel(
            //        StringUtils.isBlank(messgeTable.getString("ZEIAR")) ? "XX" : messgeTable.getString("ZEIAR"));
            results.add(materialEntity);
        }

        messgeTable.clear();

        return results;
    }

    /**
     * 取SAP AVL 信息
     *
     * @return
     */
    public List<AvlDto> doGetAvlInfo(String sapClient, String plant, String fromDate, String endDate) throws JCoException {

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        // SAP wo header interface
        JCoFunction function = pool.getRepository().getFunction("Z_MMFM025");

        JCoTable itemTable = function.getTableParameterList().getTable("PLANT");
        itemTable.appendRow();
        itemTable.setRow(0);
        itemTable.setValue("WERKS", plant);
        itemTable.setValue("FROMDATE", fromDate);
        itemTable.setValue("TODATE", endDate);

        function.execute(pool);

        JCoParameterList exportlist = function.getExportParameterList();
        JCoTable avlTable = function.getTableParameterList().getTable("IT_031");

        List<AvlDto> results = new ArrayList<>();

        if (avlTable != null && avlTable.getNumRows() == 0) {
            return results;
        }

        AvlDto dto;

        for (int i = 0, rows = avlTable.getNumRows(); i < rows; i++) {
            avlTable.setRow(i);
            dto = new AvlDto();
            dto.setPlant(plant);
            dto.setPartNo(avlTable.getString("LIN03"));
            dto.setSupplierPartNo(avlTable.getString("SLN14"));
            dto.setSupplierName(avlTable.getString("SLN01"));
            dto.setSupplierCode(avlTable.getString("BCT02"));
            dto.setFromValidity(avlTable.getString("SLN10"));
            dto.setToValidity(avlTable.getString("SLN12"));
            dto.setFlag(avlTable.getString("FLAG"));
            results.add(dto);
        }

        avlTable.clear();

        return results;

    }

    /**
     * 取SAP AVL 信息
     *
     * @return
     */
    public List<AvlDto> doGetAvlInfoByPartno(String sapClient, String plant, List<String> partList) throws JCoException {

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        // SAP wo header interface
        JCoFunction function = pool.getRepository().getFunction("Z_MMFM025");

        JCoTable itemTable = function.getTableParameterList().getTable("IMATNR");

        for (int i = 0; i < partList.size(); i++) {
            itemTable.appendRow();
            itemTable.setRow(i);
            itemTable.setValue("WERKS", plant);
            itemTable.setValue("MATNR", partList.get(i));
        }

        function.execute(pool);

        JCoParameterList exportlist = function.getExportParameterList();
        JCoTable avlTable = function.getTableParameterList().getTable("AML");

        if (avlTable != null && avlTable.getNumRows() > 0) {

            List<AvlDto> results = new ArrayList<>();

            AvlDto dto;

            for (int i = 0, rows = avlTable.getNumRows(); i < rows; i++) {
                avlTable.setRow(i);
                dto = new AvlDto();
                dto.setPlant(plant);
                dto.setPartNo(avlTable.getString("MATNR"));
                dto.setSupplierPartNo(avlTable.getString("IDNLF"));
                dto.setSupplierName(avlTable.getString("SORTL"));
                dto.setSupplierCode(avlTable.getString("PROCODE"));
                dto.setFromValidity(avlTable.getString("SLN10"));
                dto.setToValidity(avlTable.getString("SLN12"));
                dto.setFlag(avlTable.getString("FLAG"));
                results.add(dto);
            }

            return results;

        }
        return null;
    }

    /**
     * 取物料单价及币别
     *
     * @return
     */
    public MaterialStandardPriceDto doGetMaterialStandardPrice(String sapClient, String plant, String valuationArea, String partNo, String valuationType) throws JCoException {

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        // SAP wo header interface
        JCoFunction function = pool.getRepository().getFunction("BAPI_MATERIAL_GET_DETAIL");

        JCoParameterList inputParams = function.getImportParameterList();
        inputParams.setValue("PLANT", plant);
        inputParams.setValue("MATERIAL", partNo);

        if (StringUtils.isNotBlank(valuationArea)) {
            inputParams.setValue("VALUATIONAREA", valuationArea);
        } else {
            inputParams.setValue("VALUATIONAREA", plant);
        }

        if (StringUtils.isNotBlank(valuationType)) {
            inputParams.setValue("VALUATIONTYPE", valuationType);
        }

        function.execute(pool);

        JCoParameterList exportlist = function.getExportParameterList();
        JCoStructure outData = exportlist.getStructure("MATERIALVALUATIONDATA");
        if (outData == null) {
            return null;
        }

        MaterialStandardPriceDto out = new MaterialStandardPriceDto();
        out.setPlant(plant);
        out.setPartNo(partNo);
        out.setCurrency(outData.getString("CURRENCY"));
        out.setStandardPrice(outData.getBigDecimal("STD_PRICE"));
        out.setPriceUnit(outData.getBigDecimal("PRICE_UNIT"));

        return out;

    }

    /**
     * 取valueType
     *
     * @return
     */
    public String doGetMaterialValueType(String sapClient, String plant, String partNo, String warehouseCode) throws JCoException {

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        // SAP interface
        JCoFunction function = pool.getRepository().getFunction("ZRFC_MM_PCE_0054");

        JCoParameterList inputParams = function.getImportParameterList();
        inputParams.setValue("PLANT", plant);
        inputParams.setValue("PARTNO", partNo);
        inputParams.setValue("SLOC", warehouseCode);

        function.execute(pool);

        JCoParameterList exportlist = function.getExportParameterList();
        String valueType = exportlist.getString("VALUATION_TYPE");

        if (StringUtils.isNotBlank(valueType)) {
            return valueType;
        }
        return null;
    }

    public String doGetMaterialNo(String sapClient,String partNo) throws JCoException {
        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);
        // SAP interface
        JCoFunction function = pool.getRepository().getFunction("ZCONVERSION_EXIT_MATN1_INPUT");
        JCoParameterList inputParams = function.getImportParameterList();
        inputParams.setValue("INPUT1", partNo);
        function.execute(pool);
        JCoParameterList exportlist = function.getExportParameterList();
        partNo = exportlist.getString("OUTPUT1");
        if (StringUtils.isNotBlank(partNo)) {
            return partNo;
        }
        return null;
    }

    public String getValueType(String sapClient, String orgCode, String plantCode,
                               String partNo, String partVersion, String warehouseCode) throws JCoException {
        //判断料号是否纯数字且未满18位
        if (org.apache.commons.lang3.StringUtils.isNumeric(partNo) && partNo.length() < 18) {
            partNo = doGetMaterialNo(sapClient, partNo);
        }
        //查询数据字典是否有配置
        List<SysDict> sysDictList = sysDictMapper.selectDictList(plantCode);
        String valueType;
        if (CollUtil.isNotEmpty(sysDictList)) {
            //版次不允许为空
            if (StringUtil.isEmpty(partVersion)) {
                return null;
            }
            List<MaterialInfoDto> materialInfoDtos = doGetMaterialInfo(sapClient, plantCode, partNo, "", "");
            if (CollUtil.isEmpty(materialInfoDtos) || materialInfoDtos.size() == 0) {
                return null;
            }
            MaterialInfoDto materialInfoDto = materialInfoDtos.get(0);
            SysDict sysDict = sysDictList.stream().filter(dict ->
                    materialInfoDto.getProductType().equals(dict.getDictCode())).findFirst().orElse(null);
            if (ObjectUtil.isNull(sysDict)) {
                return null;
            }
            valueType = sysDict.getDictName();
            if (org.apache.commons.lang3.StringUtils.left(partVersion, 1).equalsIgnoreCase("N")) {
                valueType = "N" + valueType;
            }
            return valueType;
        }
        if ("WI".equalsIgnoreCase(orgCode)) {
            valueType = "COST";
        } else {
            valueType = doGetMaterialValueType(sapClient, plantCode, partNo, warehouseCode);
        }
        return valueType;
    }
}


