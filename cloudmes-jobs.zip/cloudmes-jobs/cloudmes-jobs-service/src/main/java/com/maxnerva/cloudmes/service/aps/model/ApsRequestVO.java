package com.maxnerva.cloudmes.service.aps.model;

import lombok.Data;

/**
 * @Description:
 * @Author: Yang Jun Wen
 * @Date: 2023/06/13 10:15
 * @Version: 1.0
 */
@Data
public class ApsRequestVO {

    private String orgCode;
    private String BeginDate;
    private String EndDate;
}
