package com.maxnerva.cloudmes.mapper.wo;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderHeader;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 工单header信息表  Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2022-08-30
 */
public interface WmsWorkOrderHeaderMapper extends BaseMapper<WmsWorkOrderHeader> {

    int insertWoHeaderInfo(WmsWorkOrderHeader wmsWorkOrderHeader);

    /**
     * 根据工单号查询head表满足条件的ID
     * @param plantCode 工厂
     * @param workOrderNo 工单号
     * @return
     */
    Integer getWoHeaderId(@Param("plantCode") String plantCode, @Param("workOrderNo")String workOrderNo);


}
