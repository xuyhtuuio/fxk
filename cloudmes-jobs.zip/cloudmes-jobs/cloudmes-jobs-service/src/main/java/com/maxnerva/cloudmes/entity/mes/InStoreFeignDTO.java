package com.maxnerva.cloudmes.entity.mes;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel("查询入库数据参数对象")
public class InStoreFeignDTO implements Serializable {

    @ApiModelProperty("条码")
    private String barcode;

    @ApiModelProperty("所属BU")
    private String orgCode;
}
