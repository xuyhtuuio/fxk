package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.TableName;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import lombok.Data;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2024-06-27
 */
@TableName("wms_file_download_log")
@ApiModel(value = "WmsFileDownloadLog对象", description = "")
@Data
public class WmsFileDownloadLog extends BaseEntity<WmsFileDownloadLog> {

    private static final long serialVersionUID = 1L;

    private Integer id;

    private String fileName;

    private String link;

    private String orgCode;

    private String type;

    private Integer fileId;
}
