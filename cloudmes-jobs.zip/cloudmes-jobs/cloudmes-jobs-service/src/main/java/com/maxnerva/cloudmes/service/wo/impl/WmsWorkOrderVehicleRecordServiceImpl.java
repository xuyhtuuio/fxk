package com.maxnerva.cloudmes.service.wo.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderVehicleRecord;
import com.maxnerva.cloudmes.mapper.wo.WmsWorkOrderVehicleRecordMapper;
import com.maxnerva.cloudmes.service.wo.IWmsWorkOrderVehicleRecordService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 工单绑定载具记录表 服务实现类
 * </p>
 *
 * @author likun
 * @since 2022-09-03
 */
@Service
public class WmsWorkOrderVehicleRecordServiceImpl extends ServiceImpl<WmsWorkOrderVehicleRecordMapper,
        WmsWorkOrderVehicleRecord> implements IWmsWorkOrderVehicleRecordService {

}
