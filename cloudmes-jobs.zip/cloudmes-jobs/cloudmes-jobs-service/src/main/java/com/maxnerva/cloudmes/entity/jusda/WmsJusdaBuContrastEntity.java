package com.maxnerva.cloudmes.entity.jusda;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * <p>
 * 准时达BU对照表
 * </p>
 *
 * @author Chao Zhang
 * @since 2022-11-22
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("wms_jusda_bu_contrast")
public class WmsJusdaBuContrastEntity extends Model<WmsJusdaBuContrastEntity> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * SAP工厂code
     */
    @TableField("plant_code")
    private String plantCode;

    @TableField("org_code")
    private String orgCode;

    /**
     * 送货类型
     */
    @TableField("delivery_type")
    private String deliveryType;

    /**
     * Foxconn BU代码
     */
    @TableField("customer_name")
    private String customerName;

    /**
     * 创建人
     */
    @TableField("creator")
    private String creator;

    /**
     * 创建人id
     */
    @TableField("creator_id")
    private Integer creatorId;

    /**
     * 创建时间
     */
    @TableField("created_dt")
    private Long createdDt;

    /**
     * 最后编辑人
     */
    @TableField("last_editor")
    private String lastEditor;

    /**
     * 最后编辑人id
     */
    @TableField("last_editor_id")
    private Integer lastEditorId;

    /**
     * 最后编辑时间
     */
    @TableField("last_edited_dt")
    private Long lastEditedDt;

    /**
     * 0=正常、1=删除
     */
    @TableField("is_deleted")
    private Boolean isDeleted;

    /**
     * supplierName
     */
    @TableField("supplier_name")
    private String supplierName;

    /**
     * 转出仓
     */
    @TableField("transfer_from")
    private String transferFrom;

    /**
     * 转入仓
     */
    @TableField("transfer_to")
    private String transferTo;

    /**
     * 客户
     */
    @TableField("customer")
    private String customer;

    /**
     * 制程分类
     */
    @TableField("seg_type")
    private String segType;

    /**
     * 行政组织
     */
    @TableField("admin_org")
    private String adminOrg;

    /**
     * mrpController
     */
    @TableField("mrp_controller")
    private String mrpController;

    /**
     * 进出模式
     */
    @TableField("model")
    private String model;

    /**
     * 保税性质
     */
    @TableField("bonded")
    private String bonded;

    /**
     * mrp Area
     */
    @TableField("mrp_area")
    private String mrpArea;


    @Override
    public Serializable pkVal() {
        return this.id;
    }

}
