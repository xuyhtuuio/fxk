package com.maxnerva.cloudmes.service.sap.po.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @author H7109018
 */
@Data
public class MfrInfoDto implements Serializable {

    private static final long serialVersionUID = -1L;

    private String mfrCode;
    private String mfrName;



}
