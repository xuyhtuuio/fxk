package com.maxnerva.cloudmes.entity.scrap;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * <p>
 * 工单明细报废单入库明细表
 * </p>
 *
 * @author Chao Zhang
 * @since 2023-07-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("wms_work_order_detail_scrap_in_storage_detail")
public class WmsWorkOrderDetailScrapInStorageDetailEntity extends Model<WmsWorkOrderDetailScrapInStorageDetailEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 报废入库单头id
     */
    @TableField("scrap_in_storage_id")
    private Integer scrapInStorageId;

    /**
     * BU
     */
    @TableField("org_code")
    private String orgCode;

    /**
     * 工厂
     */
    @TableField("plant_code")
    private String plantCode;

    /**
     * 厂商
     */
    @TableField("manufacturer")
    private String manufacturer;

    /**
     * 成品料号
     */
    @TableField("finished_product_no")
    private String finishedProductNo;

    /**
     * PPID
     */
    @TableField("pp_id")
    private String ppId;

    /**
     * 异常描述
     */
    @TableField("abnormal_desc")
    private String abnormalDesc;

    /**
     * D/C
     */
    @TableField("date_code")
    private String dateCode;

    /**
     * confirm result
     */
    @TableField("confirm_result")
    private String confirmResult;

    /**
     * 序号
     */
    @TableField("item_no")
    private String itemNo;

    /**
     * 报废描述
     */
    @TableField("scrap_desc")
    private String scrapDesc;

    /**
     * 报废原因code
     */
    @TableField("scrap_reason_code")
    private String scrapReasonCode;

    /**
     * 报废原因
     */
    @TableField("scrap_reason")
    private String scrapReason;

    /**
     * DEBIT编号
     */
    @TableField("debit_no")
    private String debitNo;

    /**
     * 报废分类
     */
    @TableField("scrap_type")
    private String scrapType;

    /**
     * 报废分类名称
     */
    @TableField("scrap_type_name")
    private String scrapTypeName;

    /**
     * 报废工厂
     */
    @TableField("manufacturing_place")
    private String manufacturingPlace;

    /**
     * flownet单据状态
     */
    @TableField("flownet_form_status")
    private String flownetFormStatus;

    /**
     * 工单号
     */
    @TableField("work_order_no")
    private String workOrderNo;

    /**
     * 来源仓码
     */
    @TableField("from_wh_code")
    private String fromWhCode;

    /**
     * 目标仓码
     */
    @TableField("to_wh_code")
    private String toWhCode;

    /**
     * flownet最后修改日期
     */
    @TableField("flownet_last_update_dt")
    private String flownetLastUpdateDt;

    /**
     * instance id
     */
    @TableField("flowable_instance_id")
    private String flowableInstanceId;

    /**
     * fownet单据唯一值
     */
    @TableField("flownet_form_id")
    private String flownetFormId;

    /**
     * 入库状态 Y-已入库 N-未入库
     */
    @TableField("in_storage_status")
    private String inStorageStatus;

    /**
     * 抛转sfc标识
     */
    @TableField("post_sfc_flag")
    private Integer postSfcFlag;

    /**
     * 抛转sfc时间
     */
    @TableField("post_sfc_dt")
    private LocalDateTime postSfcDt;

    /**
     * 抛转sfc返回信息
     */
    @TableField("post_sfc_return_message")
    private String postSfcReturnMessage;

    /**
     * 创建人
     */
    @TableField("creator")
    private String creator;

    /**
     * 创建人员工id，冗余字段
     */
    @TableField("creator_id")
    private Integer creatorId;

    /**
     * 创建时间
     */
    @TableField("created_dt")
    private LocalDateTime createdDt;

    /**
     * 修改人
     */
    @TableField("last_editor")
    private String lastEditor;

    /**
     * 修改人员工id，冗余字段
     */
    @TableField("last_editor_id")
    private Integer lastEditorId;

    /**
     * 修改时间
     */
    @TableField("last_edited_dt")
    private LocalDateTime lastEditedDt;

    /**
     * flownet单号
     */
    @TableField("business_request_no")
    private String businessRequestNo;

    @TableField("sfc_mfg_name")
    private String sfcMfgName;

    @TableField("sfc_ipn")
    private String sfcIpn;

    @TableField("sfc_rev")
    private String sfcRev;

    @TableField("sfc_assetid")
    private String sfcAssetid;

    @TableField("sfc_mfg_part_no")
    private String sfcMfgPartNo;

    /**
     * 入库数量
     */
    @TableField("in_storage_qty")
    private BigDecimal inStorageQty;

    /**
     * 过账数量
     */
    @TableField("post_sap_qty")
    private BigDecimal postSapQty;

    /**
     * 过账单号
     */
    @TableField("post_sap_no")
    private String postSapNo;

    /**
     * 过账结果
     */
    @TableField("post_sap_message")
    private String postSapMessage;

    /**
     * 过账时间
     */
    @TableField("post_sap_date")
    private LocalDateTime postSapDate;

    /**
     * 抛flownet标识
     */
    @TableField("post_flownet_flag")
    private String postFlownetFlag;

    /**
     * 抛flownet返回msg
     */
    @TableField("post_flownet_msg")
    private String postFlownetMsg;

    /**
     * 抛flownet时间
     */
    @TableField("post_flownet_date")
    private LocalDateTime postFlownetDate;

    /**
     * 抛flownet返回msg
     */
    @TableField("post_flownet_warehouse")
    private String postFlownetWarehouse;

    @TableField("pkg_id")
    private String pkgId;


    @Override
    public Serializable pkVal() {
        return this.id;
    }

}
