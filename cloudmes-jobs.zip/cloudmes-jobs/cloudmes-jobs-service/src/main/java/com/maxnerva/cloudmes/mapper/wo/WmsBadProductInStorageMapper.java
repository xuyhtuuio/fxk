package com.maxnerva.cloudmes.mapper.wo;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.scrap.WmsBadProductInStorageEntity;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Chao Zhang
 * @since 2023-07-08
 */
public interface WmsBadProductInStorageMapper extends BaseMapper<WmsBadProductInStorageEntity> {

}
