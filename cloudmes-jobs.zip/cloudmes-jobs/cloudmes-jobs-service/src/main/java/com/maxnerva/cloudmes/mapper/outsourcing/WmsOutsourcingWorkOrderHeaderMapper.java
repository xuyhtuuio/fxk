package com.maxnerva.cloudmes.mapper.outsourcing;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.outsourcing.WmsOutsourcingWorkOrderHeader;

/**
 * <p>
 * 委外工单信息header表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2023-11-30
 */
public interface WmsOutsourcingWorkOrderHeaderMapper extends BaseMapper<WmsOutsourcingWorkOrderHeader> {

}
