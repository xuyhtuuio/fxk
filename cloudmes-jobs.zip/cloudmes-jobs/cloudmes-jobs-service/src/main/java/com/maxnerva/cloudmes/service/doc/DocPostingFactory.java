package com.maxnerva.cloudmes.service.doc;

import com.maxnerva.cloudmes.common.response.Result;
import com.maxnerva.cloudmes.entity.doc.WmsDocReceive;
import com.maxnerva.cloudmes.entity.trading.WmsTradingRecordEntity;
import com.sap.conn.jco.JCoException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/09/12 08:13
 * @Version: 1.0
 */
@Service
public class DocPostingFactory {

    /**
     * 自动注入策略接口的实现
     */
    @Autowired
    Map<String, IDocPostingService> postingServiceMap = new ConcurrentHashMap<>(5);

    /**
     * 执行过账
     *
     * @param wmsDocReceive
     * @return
     */

    public Result doPosting(String sapClientCode, WmsDocReceive wmsDocReceive, String stckType,String postDate) {

        IDocPostingService postService = postingServiceMap.get(wmsDocReceive.getPostingMethodName());

        Assert.notNull(postService, "init postingService error");

        Result b = postService.doPost(sapClientCode, wmsDocReceive, stckType,postDate);
        return b;


    }

    public Result doTradingInPosting(String sapClientCode, WmsDocReceive wmsDocReceive, WmsTradingRecordEntity tradingRecordEntity, String stckType, String postDate) {
        IDocPostingService postService = postingServiceMap.get(wmsDocReceive.getPostingMethodName());

        Assert.notNull(postService, "init postingService error");

        Result b = postService.doTradingInPosting(sapClientCode, wmsDocReceive, tradingRecordEntity, stckType,postDate);
        return b;
    }

    public Result doOutsourcingPosting(String sapClientCode, WmsDocReceive wmsDocReceive, String postDate) throws JCoException {
        IDocPostingService postService = postingServiceMap.get(wmsDocReceive.getPostingMethodName());

        Assert.notNull(postService, "init postingService error");

        Result b = postService.doOutsourcingPosting(sapClientCode, wmsDocReceive, postDate);
        return b;
    }
}
