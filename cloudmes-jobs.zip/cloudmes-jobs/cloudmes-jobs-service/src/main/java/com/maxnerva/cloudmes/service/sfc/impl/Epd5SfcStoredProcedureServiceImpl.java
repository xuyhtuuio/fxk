package com.maxnerva.cloudmes.service.sfc.impl;

import cn.hutool.core.collection.CollUtil;
import com.maxnerva.cloudmes.entity.wo.WmsBomFeeder;
import com.maxnerva.cloudmes.mapper.sfc.Epd5OracleProcedureMapper;
import com.maxnerva.cloudmes.service.sfc.SfcStoredProcedureService;
import com.maxnerva.cloudmes.service.sfc.model.*;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @ClassName Epd5SfcStoredProcedureServiceImpl
 * @Description TODO
 * @Author Likun
 * @Date 2024/1/15
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Service
@Component("SFC_E5T1")
public class Epd5SfcStoredProcedureServiceImpl implements SfcStoredProcedureService {

    @Resource
    Epd5OracleProcedureMapper oracleProcedureMapper;

    @Override
    public List<WmsBomFeeder> getWmsBomFeeder(String partNo, String lineNo, String processType, String orgCode, String plantCode) {
        return CollUtil.newArrayList();
    }

    @Override
    public String postingSfcPkgInfo(PostPkgInfoToSfcDto postPkgInfoToSfcDto, String orgCode, String plantCode) {
        return null;
    }

    @Override
    public PkgStatusInfoDto getPkgStatusInfo(PkgStatusInfoDto pkgStatusInfoDto, String orgCode, String plantCode) {
        return null;
    }

    @Override
    public List<SfcPalletInfoDto> getSfcPalletInfo(String barcode, String orgCode, String plantCode) {
        Map input = new HashMap();
        input.put("i_pallet", barcode);
        oracleProcedureMapper.getSfcPalletInfo(input);
        String result = (String) input.get("o_res");
        Assert.isTrue("OK".equalsIgnoreCase(result), "SFC error " + result);
        List<SfcPalletInfoDto> palletInfo = (List<SfcPalletInfoDto>) input.get("o_dataset");
        if (CollUtil.isEmpty(palletInfo)) {
            return null;
        }
        return palletInfo;
    }

    @Override
    public List<PkgLinkListDto> getPkgLinkList(String pkgId) {
        return null;
    }

    @Override
    public String clearPkgStatusToSfc(String pkgId, String currentQty, String orgCode, String plantCode) {
        return null;
    }

    @Override
    public String sendSnDnRelationshipToSfc(String orgCode, String plantCode, String mrpArea,
                                            SnDnRelationshipDto dto) {
        Map input = new HashMap();
        input.put("i_sn", dto.getSn());
        input.put("i_po", dto.getPo());
        input.put("i_group_name", dto.getSfcWorkstation());
        input.put("i_bt", dto.getTemporaryPoOfHub());
        input.put("i_dn", dto.getDn());
        oracleProcedureMapper.sendSnDnRelationshipToSfc(input);
        String result = (String) input.get("o_res");
        return result;
    }

    @Override
    public String doWarehousingPassSnStation(WarehousingPassSnStationDto dto,
                                             String orgCode, String plantCode) {
        return "OK";
    }

    @Override
    public Map getSfcExtendInfoBySn(String sn) {
        return null;
    }

    @Override
    public String insertAmazonLog(InsertAmazonLogDto amazonLogDto) {
        return null;
    }

    @Override
    public String sendProductShippingToSfc(PostProductShippingToSfcDto toSfcDto) {
        Map input = new HashMap();
        input.put("i_EMP", toSfcDto.getEmp());
        input.put("i_VEHICLE", toSfcDto.getVehicle());
        input.put("i_DESTINATION", toSfcDto.getDestination());
        input.put("i_CARTON", toSfcDto.getCarton());
        input.put("i_MYGROUP", toSfcDto.getMygroup());
        input.put("i_DN", toSfcDto.getDn());
//        input.put("i_CUST",toSfcDto.getCusName());
        input.put("i_DNFLAG",toSfcDto.getDnFlag());
        input.put("i_PO", toSfcDto.getPo());
        oracleProcedureMapper.testInputShipping(input);
        String result = (String) input.get("o_RES");
        return result;
    }

    @Override
    public List<SfcWoUsePkgInfoDto> getSfcWoUsePkgInfo(String startDateTime) {
        return null;
    }

    @Override
    public Map getPkgRelation(String pkgId) {
        return null;
    }

    @Override
    public SfcWoDto getSfcWoInfo(String sn) {
        return null;
    }

    @Override
    public List<SfcCartonInfoDTO> getSfcPalletInfoByCartonNo(String cartonNo, String orgCode, String plantCode) {
        return oracleProcedureMapper.getSfcPalletInfoByCartonNo(cartonNo);
    }

    @Override
    public String getSfcErrorDesc(String orgCode, String plantCode, String errorCode) {
        return null;
    }

    @Override
    public String getWoNoByPkgId(String orgCode, String plantCode, String pkgId) {
        return null;
    }

    @Override
    public List<SfcBurnValueDto> getSFCBurnValue(String productPartNo) {
        return null;
    }

    @Override
    public List<String> getSFCPkgId(String orgCode, String plantCode, String pkgId) {
        return null;
    }
}
