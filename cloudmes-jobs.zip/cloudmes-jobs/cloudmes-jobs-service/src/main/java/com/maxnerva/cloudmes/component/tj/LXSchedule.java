package com.maxnerva.cloudmes.component.tj;

import cn.hutool.core.collection.CollUtil;
import com.maxnerva.cloudmes.enums.PostingScheduleTransactionTypeEnum;
import com.maxnerva.cloudmes.service.basic.PostingConfigService;
import com.maxnerva.cloudmes.service.basic.PostingScheduleLockConfigService;
import com.maxnerva.cloudmes.service.doc.AdjustDocPostingService;
import com.maxnerva.cloudmes.service.doc.CostDocPostingService;
import com.maxnerva.cloudmes.service.doc.ReceiveDocPostingService;
import com.maxnerva.cloudmes.service.doc.TransferDocPostingService;
import com.maxnerva.cloudmes.service.jusda.JusdaService;
import com.maxnerva.cloudmes.service.mes.PostingMesService;
import com.maxnerva.cloudmes.service.sfc.PostingSfcService;
import com.maxnerva.cloudmes.service.wo.WmsBadPostingService;
import com.maxnerva.cloudmes.service.wo.WmsWorkOrderPrepareCkdShipService;
import com.maxnerva.cloudmes.service.wo.WoPostingNewModeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

/**
 * @author H7109018
 */
@ConditionalOnProperty(value = "cope.code", havingValue = "F_TJ")
@Component
@EnableScheduling
@Slf4j
public class LXSchedule {

    private static final String ORG_CODE = "LX";
    private static final String SAP_CLIENT_CODE = "sap";
    private static final String DATE_FORMAT = "yyyyMMdd";
    private static String postDate = "N";

    @Autowired
    CostDocPostingService costDocPostingService;

    @Autowired
    PostingConfigService postingConfigService;

    @Autowired
    ReceiveDocPostingService docPostingService;

    @Autowired
    AdjustDocPostingService adjustDocPostingService;

    @Autowired
    TransferDocPostingService transferDocPostingService;

    @Autowired
    WoPostingNewModeService woPostingNewModeService;

    @Autowired
    WmsBadPostingService wmsBadPostingService;

    @Autowired
    PostingSfcService postingSfcService;

    @Autowired
    JusdaService jusdaService;

    @Autowired
    PostingScheduleLockConfigService postingScheduleLockConfigService;

    @Autowired
    WmsWorkOrderPrepareCkdShipService wmsWorkOrderPrepareCkdShipService;

    @Autowired
    PostingMesService postingMesService;


    /**
     * 修改过账时间
     * 频率：10分钟执行一次
     */
    @Scheduled(initialDelay = 5000, fixedDelay = 300000)
    public void updatePostDate() {
        String s = postingConfigService.getPostDate(ORG_CODE, null);
        postDate = s;
    }


    /**
     * 费领退及报废单过账SAP
     * 频率：5分钟执行一次
     */
    @Scheduled(initialDelay = 33000, fixedDelay = 600000)
    public void costDocPostingService() {
        log.info("costLXDocPostingService start :" + System.currentTimeMillis());
        costDocPostingService.costDocTransferPosting(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("costLXDocPostingService end :" + System.currentTimeMillis());
    }

    /**
     * 收货单据确认且不需要抛Q需要过账的直接入良品仓良品状态
     */
    @Scheduled(initialDelay = 140000, fixedDelay = 900000)
    public void docPostingToGoodProduct() {
        log.info("docPostingToGoodProduct start :" + System.currentTimeMillis());
        docPostingService.docPostingToGoodProduct(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("docPostingToGoodProduct end :" + System.currentTimeMillis());
    }

    /**
     * 收货单据确认收货后转良品仓待验状态
     */
    @Scheduled(initialDelay = 150000, fixedDelay = 900000)
    public void postingToBeInspected() {
        log.info("postingToBeInspected start :" + System.currentTimeMillis());
        docPostingService.docPostingToBeInspected(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("postingToBeInspected end :" + System.currentTimeMillis());
    }

    /**
     * 收货单据，QMS有返回结果后转良品仓良品状态
     */
    @Scheduled(initialDelay = 160000, fixedDelay = 900000)
    public void postingGoodProductStatus() {
        log.info("postingGoodProductStatus start :" + System.currentTimeMillis());
        docPostingService.docPostingGoodProductStatus(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("postingGoodProductStatus end :" + System.currentTimeMillis());
    }

    /**
     * 料调单过账
     */
    @Scheduled(initialDelay = 120000, fixedDelay = 600000)
    public void docAdjustPosting() {
        log.info("docAdjustPosting start :" + System.currentTimeMillis());
        adjustDocPostingService.docAdjustPosting(SAP_CLIENT_CODE, ORG_CODE, Arrays.asList("5"), postDate);
        log.info("docAdjustPosting end :" + System.currentTimeMillis());
    }

    /**
     * 转仓单过账
     */
    @Scheduled(initialDelay = 130000, fixedDelay = 900000)
    public void docTransferPosting() {
        log.info("docTransferPosting start :" + System.currentTimeMillis());
        transferDocPostingService.docTransferPosting(SAP_CLIENT_CODE, ORG_CODE, Arrays.asList("5"), postDate);
        log.info("docTransferPosting end :" + System.currentTimeMillis());
    }

    /**
     * 工单成品入库 101
     * 频率：10分钟执行一次
     */
    @Scheduled(initialDelay = 16000, fixedDelay = 600000)
    public void postingWoHeader101Test() {
        log.info("postingLXWoHeader101Test start :" + System.currentTimeMillis());
        woPostingNewModeService.postingCmbWoHeader101(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingLXWoHeader101Test end :" + System.currentTimeMillis());
    }

    /**
     * 工单备料量过账261
     * 频率：10分钟执行一次
     */
    @Scheduled(initialDelay = 15000, fixedDelay = 600000)
    public void postingWoDetail261NewModeTest() {
        //工单备料量过账261
        log.info("postingWoDetail261NewModeTest start :" + System.currentTimeMillis());
        woPostingNewModeService.postingWoDetail261NewMode(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoDetail261NewModeTest end :" + System.currentTimeMillis());

        //工单退料量过账262
        log.info("postingWoDetail262NewModeTest start :" + System.currentTimeMillis());
        woPostingNewModeService.postingWoDetail262NewMode(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoDetail262NewModeTest end :" + System.currentTimeMillis());

        //工单移出量过账 262
        log.info("postingWoRemove262NewModeTest start :" + System.currentTimeMillis());
        woPostingNewModeService.postingWoRemove262NewMode(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoRemove262NewModeTest end :" + System.currentTimeMillis());

        //工单移入量过账 261
        log.info("postingWoMoveIn261NewModeTest start :" + System.currentTimeMillis());
        woPostingNewModeService.postingWoMoveIn261NewMode(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoMoveIn261NewModeTest end :" + System.currentTimeMillis());

        //重工工单过账SAP 531
        log.info("postingWoDetail531NewMode start :" + System.currentTimeMillis());
        woPostingNewModeService.postingWoDetail531NewMode(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoDetail531NewMode end :" + System.currentTimeMillis());

        //不良品退料过账
        log.info("postingReturnBadGoods start :" + System.currentTimeMillis());
        wmsBadPostingService.postingReturnBadGoods(ORG_CODE, postDate);
        log.info("postingReturnBadGoods end :" + System.currentTimeMillis());

        //报废入库过账311
        log.info("postingScrap311 start :" + System.currentTimeMillis());
        woPostingNewModeService.postingScrap311(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingScrap311 end :" + System.currentTimeMillis());

        //不良品QMS领用过账到QMS仓码 311
        log.info("scrapPostingQmsWarehouseCodeBy311 start :" + System.currentTimeMillis());
        woPostingNewModeService.scrapPostingQmsWarehouseCodeBy311(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("scrapPostingQmsWarehouseCodeBy311 end :" + System.currentTimeMillis());

        //不良品QMS退回过账至指定仓码 311
        log.info("scrapPostingQmsReturnBy311 start :" + System.currentTimeMillis());
        woPostingNewModeService.scrapPostingQmsReturnBy311(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("scrapPostingQmsReturnBy311 end :" + System.currentTimeMillis());
    }

    /**
     * 工单备料PKG信息抛SFC
     */
    @Scheduled(initialDelay = 90000, fixedDelay = 300000)
    public void postingWoPreparePkgInfoToSFC() {
        log.info("postingWoPreparePkgInfoToSFC start :" + System.currentTimeMillis());
        postingSfcService.postingWoPreparePkgInfoToSFC(ORG_CODE);
        log.info("postingWoPreparePkgInfoToSFC end:" + System.currentTimeMillis());
    }

    /**
     * 内交单过账
     */
    @Scheduled(initialDelay = 190000, fixedDelay = 600000)
    public void tradingPosting() {
        log.info("getTradingLXStatus start :" + System.currentTimeMillis());
        String s = postingConfigService.getTradingStatus(ORG_CODE, null);
        log.info("getTradingLXStatus status :" + s);
        log.info("getTradingLXStatus end :" + System.currentTimeMillis());
        if ("N".equalsIgnoreCase(s)) {
            return;
        }
        //内交出过账
        log.info("tradingPosting start :" + System.currentTimeMillis());
        docPostingService.tradingPosting(ORG_CODE, postDate);
        log.info("tradingPosting end :" + System.currentTimeMillis());

        //PGI
        log.info("tradingPosting start :" + System.currentTimeMillis());
        docPostingService.tradingPGI(ORG_CODE, postDate);
        log.info("tradingPosting end :" + System.currentTimeMillis());

        //内交入过账
        log.info("doTradingInPosting start :" + System.currentTimeMillis());
        docPostingService.doTradingInPosting(ORG_CODE, postDate);
        log.info("doTradingInPosting end :" + System.currentTimeMillis());
    }

    /**
     * jusda VMI 收货过账SAP
     */
    @Scheduled(initialDelay = 110000, fixedDelay = 700000)
    public void jusdaReceiveInfoPostingSAP() {
        log.info("jusdaReceiveInfoPostingSAP start :" + System.currentTimeMillis());
        jusdaService.jusdaReceiveInfoPostingSAP(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("jusdaReceiveInfoPostingSAP end:" + System.currentTimeMillis());
    }

    /**
     * 成品出货后扣账
     */
    @Scheduled(initialDelay = 260000, fixedDelay = 800000)
    public void productShipPgi() {
        log.info("getShipPgiStatus start :" + System.currentTimeMillis());
        String s = postingConfigService.getCkdShipPgiStatus(ORG_CODE, null);
        log.info("getShipPgiStatus end :" + System.currentTimeMillis());
        if ("N".equalsIgnoreCase(s)) {
            return;
        }
        // 允许过账的工厂
        List<String> allowRunPlantCodeList = postingScheduleLockConfigService.allowRun(ORG_CODE, PostingScheduleTransactionTypeEnum.DN_TRANSACTION.getDictCode());
        if (CollUtil.isEmpty(allowRunPlantCodeList)){
            return;
        }
        log.info("productShipPgi start :" + System.currentTimeMillis());
        wmsWorkOrderPrepareCkdShipService.productShipPgi(SAP_CLIENT_CODE, ORG_CODE, allowRunPlantCodeList);
        log.info("productShipPgi end :" + System.currentTimeMillis());
    }

    /**
     * 抛转po sn信息到mes
     */
//    @Scheduled(initialDelay = 170000, fixedDelay = 600000)
    public void postPoSnDataToMes() {
        log.info("postPoSnDataToMes start :" + System.currentTimeMillis());
        postingMesService.postPoSnDataToMes(ORG_CODE);
        log.info("postPoSnDataToMes end:" + System.currentTimeMillis());
    }

    /**
     * 回写DN、SN的绑定关系
     */
    @Scheduled(initialDelay = 180000, fixedDelay = 600000)
    public void sendSnDnRelationshipToSfc() {
        log.info("sendSnDnRelationshipToSfc start :" + System.currentTimeMillis());
        postingSfcService.sendSnDnRelationshipToSfc(ORG_CODE);
        log.info("sendSnDnRelationshipToSfc end:" + System.currentTimeMillis());
    }
}
