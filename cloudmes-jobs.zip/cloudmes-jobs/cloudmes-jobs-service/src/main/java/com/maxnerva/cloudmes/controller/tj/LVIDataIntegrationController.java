package com.maxnerva.cloudmes.controller.tj;

import cn.hutool.core.date.DateUtil;
import com.maxnerva.cloudmes.entity.R;
import com.maxnerva.cloudmes.service.basic.PostingConfigService;
import com.maxnerva.cloudmes.service.doc.AdjustDocPostingService;
import com.maxnerva.cloudmes.service.doc.CostDocPostingService;
import com.maxnerva.cloudmes.service.doc.ReceiveDocPostingService;
import com.maxnerva.cloudmes.service.doc.TransferDocPostingService;
import com.maxnerva.cloudmes.service.sfc.PostingSfcService;
import com.maxnerva.cloudmes.service.wo.WoPostingService;
import com.maxnerva.cloudmes.service.wo.WorkOrderService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.Arrays;

/**
 * @author H7109018
 */
@Api(tags = "LVI数据集成调用接口")
@Slf4j
@RestController
@RequestMapping("/LVIDataIntegration")
public class LVIDataIntegrationController {

    private static final String ORG_CODE = "LVI";
    private static final String SAP_CLIENT_CODE = "sap";
    private static final String DATE_FORMAT = "yyyyMMdd";
    private static String postDate = "N";

    @Autowired
    WorkOrderService workOrderService;

    @Autowired
    WoPostingService woPostingService;

    @Autowired
    ReceiveDocPostingService docPostingService;

    @Autowired
    TransferDocPostingService transferDocPostingService;

    @Autowired
    AdjustDocPostingService adjustDocPostingService;

    @Autowired
    CostDocPostingService costDocPostingService;

    @Autowired
    PostingSfcService postingSfcService;

    @Autowired
    PostingConfigService postingConfigService;

    /**
     * 修改过账时间
     * 频率：10分钟执行一次
     */
    @ApiOperation("修改过账时间")
    @GetMapping("/updatePostDate")
    public void updatePostDate() {
        String s = postingConfigService.getPostDate(ORG_CODE, null);
        postDate = s;
        log.info(">>>>>>>>>LVI过账时间:{}",postDate);
    }

    /**
     * 同步SAP workOrder header info,
     * 频率：60分钟执行一次
     */
    @ApiOperation("同步SAP workOrder header info")
    @GetMapping("/syncSapWorkOrderHeader")
    public void syncSapWorkOrderHeader() {

        log.info(" syncSapWorkOrderHeader start :" + System.currentTimeMillis());
        String startDate = DateUtil.format(LocalDateTime.now().plusDays(-3), DATE_FORMAT);
        String endDate = DateUtil.format(LocalDateTime.now().plusDays(2), DATE_FORMAT);

        workOrderService.syncSapWorkOrderHeader(ORG_CODE, startDate, endDate);
        log.info(" syncSapWorkOrderHeader end :" + System.currentTimeMillis());

//        log.info("syncSapWorkOrderDetail start :" + System.currentTimeMillis());
//        workOrderService.syncSapWorkOrderDetail(ORG_CODE, null, SAP_CLIENT_CODE);
//        log.info("syncSapWorkOrderDetail end :" + System.currentTimeMillis());
    }

    /**
     * 同步SAP workOrder detail info,
     * 频率：30分钟执行一次
     */
    @ApiOperation("同步SAP workOrder detail info")
    @GetMapping("/syncSapWorkOrderDetail")
    public void syncSapWorkOrderDetail() {
        log.info("syncSapWorkOrderDetail start :" + System.currentTimeMillis());
        workOrderService.syncSapWorkOrderDetail(ORG_CODE, null, SAP_CLIENT_CODE);
        log.info("syncSapWorkOrderDetail end :" + System.currentTimeMillis());
    }

    /**
     * 同步SFC 上料表和备料方向
     * 频率：30分钟执行一次
     */
    @ApiOperation("同步SFC 上料表和备料方向")
    @GetMapping("/syncBomFeederFromSfc")
    public void syncBomFeederFromSfc() {
        log.info("syncBomFeederFromSfc start :" + System.currentTimeMillis());
        workOrderService.syncBomFeederFromSfc(ORG_CODE, null);
        log.info("syncBomFeederFromSfc end :" + System.currentTimeMillis());
    }

    /**
     * 工单detail过账311
     * 频率：30分钟执行一次
     */
    @ApiOperation("工单detail过账311")
    @GetMapping("/postingWoDetail311")
    public void postingWoDetail311() {
        log.info("postingWoDetail311 start :" + System.currentTimeMillis());
        woPostingService.postingWoDetail311(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoDetail311 end :" + System.currentTimeMillis());
    }

    /**
     * 工单detail过账 261
     * 频率：30分钟执行一次
     */
    @ApiOperation("工单detail过账 261")
    @GetMapping("/postingWoDetail261")
    public void postingWoDetail261() {
        log.info("postingWoDetail261 start :" + System.currentTimeMillis());
        woPostingService.postingWoDetail261(ORG_CODE, SAP_CLIENT_CODE, postDate);
        log.info("postingWoDetail261 end :" + System.currentTimeMillis());
    }

    /**
     * 收货确认并上架完成后，收货单抛QMS
     * 频率：5分钟执行一次
     */
    @ApiOperation("收货确认并上架完成后，收货单抛QMS")
    @GetMapping("/docReceivePostQms")
    public void docReceivePostQms() {
        log.info("docReceivePostQms start :" + System.currentTimeMillis());
        docPostingService.docReceivePostQms(ORG_CODE, null);
        log.info("docReceivePostQms end :" + System.currentTimeMillis());
    }



    /**
     * 收货单据确认且不需要抛Q需要过账的直接入良品仓良品状态
     * 频率：5分钟执行一次
     */
    @ApiOperation("收货单据确认且不需要抛Q需要过账的直接入良品仓良品状态")
    @GetMapping("/docPostingToGoodProduct")
    public void docPostingToGoodProduct() {
        log.info("docPostingToGoodProduct start :" + System.currentTimeMillis());
        docPostingService.docPostingToGoodProduct(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("docPostingToGoodProduct end :" + System.currentTimeMillis());
    }
    /**
     * 收货单据，QMS有返回结果后转良品仓良品状态
     * 频率：5分钟执行一次
     */
    @ApiOperation("收货单据，QMS有返回结果后转良品仓良品状态")
    @GetMapping("/postingGoodProductStatus")
    public void postingGoodProductStatus() {
        log.info("postingGoodProductStatus start :" + System.currentTimeMillis());
        docPostingService.docPostingGoodProductStatus(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("postingGoodProductStatus end :" + System.currentTimeMillis());
    }

    /**
     * 收货单据，依据Q的结果判断是否需要转不良品仓
     * 频率：5分钟执行一次
     */
    @ApiOperation("收货单据，依据Q的结果判断是否需要转不良品仓")
    @GetMapping("/docPosting311ToRejectsWarehouse")
    public void docPosting311ToRejectsWarehouse() {
        log.info("docPosting311ToRejectsWarehouse start :" + System.currentTimeMillis());
        docPostingService.docPosting311ToRejectsWarehouse(SAP_CLIENT_CODE, ORG_CODE, "", postDate);
        log.info("docPosting311ToRejectsWarehouse end :" + System.currentTimeMillis());
    }

    /**
     * 转仓单过账
     * 频率：5分钟执行一次
     */
    @ApiOperation("转仓单过账")
    @GetMapping("/docTransferPosting")
    public void docTransferPosting() {
        log.info("docTransferPosting start :" + System.currentTimeMillis());
        transferDocPostingService.docTransferPosting(SAP_CLIENT_CODE, ORG_CODE, Arrays.asList("5"), postDate);
        log.info("docTransferPosting end :" + System.currentTimeMillis());
    }

    /**
     * 料调单过账
     * 频率：5分钟执行一次
     */
    @ApiOperation("料调单过账")
    @GetMapping("/docAdjustPosting")
    public void docAdjustPosting() {
        log.info("docAdjustPosting start :" + System.currentTimeMillis());
        adjustDocPostingService.docAdjustPosting(SAP_CLIENT_CODE, ORG_CODE, Arrays.asList("5"), postDate);
        log.info("docAdjustPosting end :" + System.currentTimeMillis());
    }

    /**
     * 费领退及报废单过账SAP
     * 频率：5分钟执行一次
     */
    @ApiOperation("费领退及报废单过账SAP")
    @GetMapping("/costDocPostingService")
    public void costDocPostingService() {
        log.info("costDocPostingService start :" + System.currentTimeMillis());
        costDocPostingService.costDocTransferPosting(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("costDocPostingService end :" + System.currentTimeMillis());
    }

    /**
     * 成品入库过账
     * 频率：30分钟执行一次
     */
    @ApiOperation("成品入库过账")
    @GetMapping("/postingWoHeader101")
    public void postingWoHeader101() {
        log.info("postingWoHeader101 start :" + System.currentTimeMillis());
        woPostingService.postingWoHeader101(SAP_CLIENT_CODE, ORG_CODE, postDate);
        log.info("postingWoHeader101 start :" + System.currentTimeMillis());
    }

    ///**
    // * 上架PKG信息抛SFC
    // * 频率：10分钟执行一次
    // */
    //@Scheduled(initialDelay = 10000, fixedDelay = 600000)
    //public void postingUpShelfPkgInfoToSFC() {
    //    log.info("postingUpShelfPkgInfoToSFC start :" + System.currentTimeMillis());
    //    postingSfcService.postingUpShelfPkgInfoToSFC(ORG_CODE);
    //    log.info("postingUpShelfPkgInfoToSFC end:" + System.currentTimeMillis());
    //}
    //
    ///**
    // * 工单备料PKG信息抛SFC
    // * 频率：10分钟执行一次
    // */
    //@Scheduled(initialDelay = 10000, fixedDelay = 600000)
    //public void postingWoPreparePkgInfoToSFC() {
    //    log.info("postingUpShelfPkgInfoToSFC start :" + System.currentTimeMillis());
    //    postingSfcService.postingWoPreparePkgInfoToSFC(ORG_CODE);
    //    log.info("postingUpShelfPkgInfoToSFC end:" + System.currentTimeMillis());
    //}
    /**
     * 工单Detail同步单价
     */
    @ApiOperation("工单Detail同步单价")
    @GetMapping("/syncWorkDetailMaterialStandardPrice")
    public R syncWorkDetailMaterialStandardPrice(){
        log.info("{} {}", "开始同步单价", LocalDateTime.now());
        workOrderService.syncWorkDetailMaterialStandardPrice(ORG_CODE, SAP_CLIENT_CODE);
        log.info("{} {}", "结束同步单价", LocalDateTime.now());
        return R.ok();
    }

}
