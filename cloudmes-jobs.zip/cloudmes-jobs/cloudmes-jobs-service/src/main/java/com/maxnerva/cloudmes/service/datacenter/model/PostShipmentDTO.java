package com.maxnerva.cloudmes.service.datacenter.model;

import cn.hutool.core.annotation.Alias;
import cn.hutool.core.annotation.PropIgnore;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Data
public class PostShipmentDTO {
    @ApiModelProperty("厂区")
    private String site;

    @ApiModelProperty("BU名称")
    @Alias(value = "business_unit_name")
    private String businessUnitName;

    @ApiModelProperty("客户")
    private String customer;

    @ApiModelProperty("出货单号")
    private String deliverynotes;

    @ApiModelProperty("出货单号项次")
    @Alias(value = "deliverynotes_Item")
    private String deliverynotesItem;

    @ApiModelProperty("鸿海料号")
    @Alias(value = "model_name")
    private String modelName;

    @ApiModelProperty("版次")
    @Alias(value = "model_rev")
    private String modelRev;

    @ApiModelProperty("计划出货数量")
    @PropIgnore
    private BigDecimal plannedQty;

    private String planned_qty;
    public String getPlanned_qty() {
        if (ObjectUtil.isNotNull(plannedQty)){
            return StrUtil.emptyIfNull(plannedQty.stripTrailingZeros().toPlainString());
        } else {
            return StrUtil.EMPTY;
        }
    }

    @ApiModelProperty("计划出货时间")
    @PropIgnore
    private LocalDateTime plannedShipmentDatetime;

    @ApiModelProperty("计划出货时间")
    private String planned_shipment_datetime;
    public String getPlanned_shipment_datetime() {
        if (ObjectUtil.isNotNull(plannedShipmentDatetime)){
            return plannedShipmentDatetime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        } else {
            return StrUtil.EMPTY;
        }
    }

    @ApiModelProperty("实际完成出货数量")
    @PropIgnore
    private BigDecimal shippedQuantity;

    private String shipped_quantity;
    public String getShipped_quantity() {
        if (ObjectUtil.isNotNull(shippedQuantity)){
            return StrUtil.emptyIfNull(shippedQuantity.stripTrailingZeros().toPlainString());
        } else {
            return StrUtil.EMPTY;
        }
    }

    @ApiModelProperty("最近一次维护人")
    private String lasteditby;

    @ApiModelProperty("最近一次维护时间")
    private LocalDateTime lasteditdt;

    @ApiModelProperty("最近一次维护时间 0时区")
    @Alias(value = "lasteditdt_utc")
    private LocalDateTime lasteditdtUtc;

    @ApiModelProperty("时区 utc+8 填8 utc-1 填-1")
    @Alias(value = "utc_zone")
    private String utcZone;

    @ApiModelProperty(value = "写入资料系统")
    @Alias(value = "add_user")
    private String addUser;

    @ApiModelProperty(value = "写入资料时间")
    @Alias(value = "add_date")
    private LocalDateTime addDate;

    @ApiModelProperty(value = "写入资料时间UTC+0")
    @Alias(value = "add_date_utc")
    private LocalDateTime addDateUtc;

    @ApiModelProperty(value = "新增/刪除(N/D)")
    @Alias(value = "data_status")
    private String dataStatus;

    public String getCustomer() {
        return StrUtil.emptyIfNull(customer);
    }

    public String getDeliverynotes() {
        return StrUtil.emptyIfNull(deliverynotes);
    }

    public String getDeliverynotesItem() {
        return StrUtil.emptyIfNull(deliverynotesItem);
    }

    public String getModelName() {
        return StrUtil.emptyIfNull(modelName);
    }

    public String getModelRev() {
        return StrUtil.emptyIfNull(modelRev);
    }

    public String getLasteditby() {
        return StrUtil.emptyIfNull(lasteditby);
    }
}
