package com.maxnerva.cloudmes.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.basic.BasicVendor;

import java.util.List;

/**
 * <p>
 * 单据表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2022-07-28
 */
public interface BasicVendorMapper extends BaseMapper<BasicVendor> {

    List<BasicVendor> getBasicVendorList();

}
