package com.maxnerva.cloudmes.mapper.trading;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.trading.WmsTradingConfig;

/**
 * @author sclq
 * @date 2022/9/22 11:04
 */
public interface WmsTradingConfigMapper extends BaseMapper<WmsTradingConfig> {

}
