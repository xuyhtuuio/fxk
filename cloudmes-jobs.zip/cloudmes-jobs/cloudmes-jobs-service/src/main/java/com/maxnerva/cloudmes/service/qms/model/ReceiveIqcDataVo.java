package com.maxnerva.cloudmes.service.qms.model;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/11/09 10:52
 * @Version: 1.0
 */

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.util.Date;

@Data
@ApiModel("IQC数据被动数据下载")
public class ReceiveIqcDataVo {
    @ApiModelProperty("验收单号")
    private String grnNo;
    @ApiModelProperty("采购单号")
    private String poNo;
    @ApiModelProperty("PO文档类型")
    private String poDocumentType;
    @ApiModelProperty("鸿海料号")
    private String materialNo;
    @ApiModelProperty("鸿海料号版本")
    private String materialVersion;
    @ApiModelProperty("厂商编号")
    private String mfg;
    @ApiModelProperty("厂商名称")
    private String mfgName;
    @ApiModelProperty("厂商料号")
    private String mfgMaterialNo;
    @ApiModelProperty("厂商料号版本")
    private String mfgMaterialVersion;
    @ApiModelProperty("客户")
    private String clientele;
    @ApiModelProperty("数量")
    private BigDecimal qty;
    @ApiModelProperty("单位")
    private String unit;
    @ApiModelProperty("PLANT")
    private String plant;
    @ApiModelProperty("VMI客户编号")
    private String vmiCustomerNo;
    @ApiModelProperty("仓码")
    private String location;
    @ApiModelProperty("储位")
    private String bin;
    @ApiModelProperty("收料人")
    private String collectPerson;
    @ApiModelProperty("收料时间")
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private Date collectDate;
    @ApiModelProperty("收账时间")
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private Date receiveAccountDate;
    @ApiModelProperty("物料类型  样品，量产，内交，现货，会根据实际情况，到时可能会分成多个栏位")
    private String materialType;
    @ApiModelProperty("单据来源")

    private String grnResource;
    @ApiModelProperty("是否外箱破损  f:否  t:是")
    private Boolean isCartonBroken;
    @ApiModelProperty("是否急件")
    private Boolean isDispatch;
    @ApiModelProperty("所属BU")
    private String orgCode;

    @ApiModelProperty("采购组织")
    private String purchaseOrg;

    @ApiModelProperty(value = "po项次")
    private String poItem;

    @ApiModelProperty("供应商")
    private String vendorCode;

    @ApiModelProperty(value = "品名")
    private String invoiceNumber;
}