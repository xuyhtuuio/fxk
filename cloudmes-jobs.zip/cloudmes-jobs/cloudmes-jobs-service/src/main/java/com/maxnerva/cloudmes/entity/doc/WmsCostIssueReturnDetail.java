package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * <p>
 * 
 * </p>
 *
 * @author Chao Zhang
 * @since 2022-12-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("wms_cost_issue_return_detail")
public class WmsCostIssueReturnDetail extends Model<WmsCostIssueReturnDetail> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 是否保税
     */
    @TableField("is_bonded")
    private Boolean isBonded;

    /**
     * 仓码
     */
    @TableField("warehouse_code")
    private String warehouseCode;

    /**
     * 名称
     */
    @TableField("name")
    private String name;

    /**
     * 数量
     */
    @TableField("qty")
    private BigDecimal qty;

    /**
     * 总价
     */
    @TableField("total_price")
    private BigDecimal totalPrice;

    /**
     * 所属bu
     */
    @TableField("org_code")
    private String orgCode;

    /**
     * 创建人
     */
    @TableField("creator")
    private String creator;

    /**
     * 创建人id
     */
    @TableField("creator_id")
    private Integer creatorId;

    /**
     * 创建时间
     */
    @TableField("created_dt")
    private Long createdDt;

    /**
     * 最后编辑人
     */
    @TableField("last_editor")
    private String lastEditor;

    /**
     * 最后编辑人id
     */
    @TableField("last_editor_id")
    private Integer lastEditorId;

    /**
     * 最后编辑时间
     */
    @TableField("last_edited_dt")
    private Long lastEditedDt;

    /**
     * 费领/退主表id
     */
    @TableField("wms_cost_issue_return_id")
    private Integer wmsCostIssueReturnId;

    /**
     * 0=正常、1=删除
     */
    @TableField("is_deleted")
    private Boolean isDeleted;

    /**
     * 单价
     */
    @TableField("price")
    private BigDecimal price;

    /**
     * 行号
     */
    @TableField("line_no")
    private Integer lineNo;

    /**
     * 鸿海料号
     */
    @TableField("part_no")
    private String partNo;

    /**
     * 物料采购员
     */
    @TableField("mcid")
    private String mcid;

    /**
     * 料号版次
     */
    @TableField("part_no_version")
    private String partNoVersion;

    /**
     * 完成数量
     */
    @TableField("completed_qty")
    private BigDecimal completedQty;

    /**
     * 报废原因
     */
    @TableField("scrap_reason")
    private String scrapReason;

    /**
     * 是否成本
     */
    @TableField("valuation_type")
    private String valuationType;

    /**
     * 物料单位
     */
    @TableField("uom_code")
    private String uomCode;

    /**
     * 币别
     */
    @TableField("coin_type")
    private String coinType;

    /**
     * 用户手动确认过账Y，N没确认
     */
    @TableField("user_confirm_posting_flag")
    private String userConfirmPostingFlag;

    @TableField("confirm_posting_qty")
    private BigDecimal confirmPostingQty;

    @TableField("post_sap_return_number")
    private String postSapReturnNumber;

    @TableField("post_sap_return_msg")
    private String postSapReturnMsg;

    @TableField("post_sap_datetime")
    private LocalDateTime postSapDatetime;

    @ApiModelProperty(value = "LRR箱号（只有LRR费退导入使用，其它情况不要用！）")
    @TableField("lrr_carton_no")
    private String lrrCartonNo;

    @Override
    public Serializable pkVal() {
        return this.id;
    }

}
