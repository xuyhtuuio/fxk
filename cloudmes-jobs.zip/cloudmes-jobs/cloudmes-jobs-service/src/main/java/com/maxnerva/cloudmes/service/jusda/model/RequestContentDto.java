package com.maxnerva.cloudmes.service.jusda.model;

import lombok.Data;

import java.util.List;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2023/04/21 18:16
 * @Version: 1.0
 */
@Data
public class RequestContentDto {
    private String createBatchAsnType;
    private List<CreateAsnListDto> createAsnList;
}
