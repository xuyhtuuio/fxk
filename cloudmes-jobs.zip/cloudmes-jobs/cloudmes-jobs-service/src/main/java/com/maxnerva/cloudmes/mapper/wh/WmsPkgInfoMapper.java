package com.maxnerva.cloudmes.mapper.wh;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.wh.WmsPkgInfo;
import com.maxnerva.cloudmes.entity.wh.WmsPkgInfoDTO;
import com.maxnerva.cloudmes.service.wh.model.SyncInventoryForFiiDTO;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2022-08-05
 */
public interface WmsPkgInfoMapper extends BaseMapper<WmsPkgInfo> {


    int expireLockMaterial();

    List<WmsPkgInfo> selectUsedPkgInfos(@Param("vehicleCode") String vehicleCode,
                                        @Param("orgCode") String orgCode);

    List<WmsPkgInfoDTO> selectExpiredAndNotTcPkgInfo(String orgCode, String plantCode, String warehouseCode, String partNo, LocalDate minDate, LocalDate now);

    void updatePkgEndDate(@Param("orgCode") String orgCode,
                          @Param("mfg") String mfg,
                          @Param("mfgMaterialNo") String mfgMaterialNo,
                          @Param("validPeriod") BigDecimal validPeriod);
                          
    List<SyncInventoryForFiiDTO> selectInventory(String orgCode);
}
