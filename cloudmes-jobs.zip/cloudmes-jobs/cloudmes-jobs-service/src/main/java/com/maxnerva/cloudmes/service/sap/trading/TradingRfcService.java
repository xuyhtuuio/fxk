package com.maxnerva.cloudmes.service.sap.trading;

import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.maxnerva.cloudmes.entity.R;
import com.maxnerva.cloudmes.service.sap.trading.model.GenerateTradingNumberDto;
import com.maxnerva.cloudmes.service.sap.util.SapPoolFactory;
import com.sap.conn.jco.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author H7109018
 */
@Slf4j
@Service
public class TradingRfcService {

    @Autowired
    SapPoolFactory sapPoolFactory;

    /**
     * 内交出，产生内交单号
     *
     * @return
     */
    public String doGenerateTradingNumber(String sapClient, GenerateTradingNumberDto tradingDto) throws JCoException {
        log.info("doGenerateTradingNumber request json:{}", JSONUtil.toJsonStr(tradingDto));
        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);
        JCoFunction function = pool.getRepository().getFunction("ZRFC_SD_WMS_VL01NO");

        JCoParameterList inputParams = function.getImportParameterList();

        inputParams.setValue("P_MODE", "1");
        JCoStructure dnItem = inputParams.getStructure("DN_ITEM");
        dnItem.setValue("SHIPPING_POINT", tradingDto.getFromPlant());
        dnItem.setValue("DELIVERY_TYPE", tradingDto.getDeliveryType());
        dnItem.setValue("SALESORG", tradingDto.getSalesOrg());
        dnItem.setValue("DISTRI_CHAN", tradingDto.getDistriChan());
        dnItem.setValue("DIVISION", tradingDto.getDivision());
        dnItem.setValue("SHIP_TO", tradingDto.getTradingToCode());
        dnItem.setValue("GI_DATE", tradingDto.getGiDate());
        dnItem.setValue("MATERIAL", tradingDto.getMaterial());
        dnItem.setValue("QUANTITY", tradingDto.getQuantity());
        dnItem.setValue("LOCATION", tradingDto.getLocation());
        dnItem.setValue("BWTAR", tradingDto.getValueType());
        if (StringUtils.isNotBlank(tradingDto.getBatch())) {
            dnItem.setValue("BATCH", tradingDto.getBatch());
        }

        function.execute(pool);

        JCoParameterList exportlist = function.getExportParameterList();

        String flag = String.valueOf(exportlist.getValue("FLAG"));

        String newOrderNo = (String) exportlist.getValue("ODN");

        if (StringUtils.isBlank(newOrderNo)) {
            String newMsg = String.valueOf(exportlist.getValue("MSG")); //?取失?信息
            throw new RuntimeException(newMsg);
        }
        return newOrderNo;
    }

    /**
     * 内交出，产生内交单号
     *
     * @return
     */
    public String doGenerateTradingNumber2(String sapClient, GenerateTradingNumberDto tradingDto) throws JCoException {
        log.info("doGenerateTradingNumber request json:{}", JSONUtil.toJsonStr(tradingDto));
        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);
        JCoFunction function = pool.getRepository().getFunction("ZRFC_SD_CES_0026");

        JCoParameterList inputParams = function.getImportParameterList();
        inputParams.setValue("P_SHIPPT", tradingDto.getFromPlant());
        inputParams.setValue("P_LEVEL", "2");
        JCoTable zsoheader = function.getTableParameterList().getTable("ZSOHEADER");
        zsoheader.appendRow();
        zsoheader.setRow(0);
        zsoheader.setValue("DOC_TYPE", "ZINS");
        zsoheader.setValue("SALES_ORG", tradingDto.getSalesOrg());
        zsoheader.setValue("DISTR_CHAN", tradingDto.getDistriChan());
        zsoheader.setValue("DIVISION", tradingDto.getDivision());
        JCoTable zpartners = function.getTableParameterList().getTable("ZPARTNERS");
        zpartners.appendRow();
        zpartners.setRow(0);
        zpartners.setValue("PARTN_ROLE", "AG");
        zpartners.setValue("PARTN_NUMB", tradingDto.getTradingToCode());
        zpartners.appendRow();
        zpartners.setRow(1);
        zpartners.setValue("PARTN_ROLE", "WE");
        zpartners.setValue("PARTN_NUMB", tradingDto.getTradingToCode());
        JCoTable zsoitem = function.getTableParameterList().getTable("ZSOITEM");
        zsoitem.appendRow();
        zsoitem.setRow(0);
        zsoitem.setValue("ITM_NUMBER", "000010");
        zsoitem.setValue("STORE_LOC", tradingDto.getLocation());
        zsoitem.setValue("PLANT", tradingDto.getFromPlant());
        zsoitem.setValue("MATERIAL", tradingDto.getMaterial());
        zsoitem.setValue("VAL_TYPE", tradingDto.getValueType());
        JCoTable zschedules = function.getTableParameterList().getTable("ZSCHEDULES");
        zschedules.appendRow();
        zschedules.setRow(0);
        zschedules.setValue("REQ_QTY", tradingDto.getQuantity());
        zschedules.setValue("ITM_NUMBER", "000010");
        function.execute(pool);
        log.info(JSONUtil.toJsonStr(tradingDto));
        JCoTable resultTable = function.getTableParameterList().getTable("ZRETSUC");
        if (resultTable == null || resultTable.getNumRows() == 0) {
            log.error("SdoGenerateTradingNumber2 error,SAP return empty");
            throw new RuntimeException("SAP return empty");
        }
        resultTable.setRow(0);
        String zso = resultTable.getString("ZSO");
        String zdn = resultTable.getString("ZDN");
        String zmessage = resultTable.getString("ZMESSAGE");
        if (StringUtils.isBlank(zdn)) {
            throw new RuntimeException(zmessage);
        }
        return zdn;
    }

    /**
     * PGI
     *
     * @return
     */
    public String doPgi(String sapClient, String tradingNumber) throws JCoException {

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);
        JCoFunction function = pool.getRepository().getFunction("ZRFC_SD_WMS_VL01NO");
        JCoParameterList inputParams = function.getImportParameterList();

        inputParams.setValue("P_MODE", "2");
        inputParams.setValue("IDN", tradingNumber);

        function.execute(pool);

        JCoParameterList exportlist = function.getExportParameterList();

        String newOrderNo = String.valueOf(exportlist.getValue("PGI")); //?取PGI?

        if (StringUtils.isBlank(newOrderNo)) {
            String newMsg = String.valueOf(exportlist.getValue("MSG")); //?取失?信息
            throw new RuntimeException(newMsg);
        }
        return newOrderNo;
    }

    /**
     * 取内交入PO
     *
     * @return
     */
    public String doGetTradingPoInfo(String sapClient, String plant, String partNo, String vendorCode, String qty) throws JCoException {

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        // SAP RFC
        JCoFunction function = pool.getRepository().getFunction("ZRFC_CES_MM_INTRASALES_PO");

        JCoTable itemTable = function.getTableParameterList().getTable("ITAB");
        itemTable.appendRow();
        itemTable.setRow(0);
        itemTable.setValue("MATERIAL", partNo);
        itemTable.setValue("PLANT", plant);
        itemTable.setValue("VENDOR", vendorCode);
        itemTable.setValue("ENTRY_QNT", qty);

        function.execute(pool);

        JCoTable infoTable = function.getTableParameterList().getTable("PO_HEADER");

        if (infoTable == null && infoTable.getNumRows() == 0) {
            return null;
        }
        infoTable.setRow(0);
        String poNumber = infoTable.getString("PO_NUMBER");

        return poNumber;
    }


}


