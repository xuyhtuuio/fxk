package com.maxnerva.cloudmes.service.sfc.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("回写DN、SN的绑定关系抛MES-VO")
public class SendSnDnRelationShipToMesVO {

    @ApiModelProperty("交货单号 DN")
    private String dn;

    @ApiModelProperty("成品料号")
    private String productNo;

    @ApiModelProperty("server SN 或者 rack SN")
    private String snsStr;

    @ApiModelProperty("客户采购单号")
    private String poNo;

    @ApiModelProperty("出厂地")
    private String destination;

    @ApiModelProperty("出货时间，格式：yyyy-MM-dd HH:mm:ss")
    private String shippingDt;

    @ApiModelProperty("客户")
    private String customer;

    @ApiModelProperty("载具号(预留)")
    private String vehicleNo;

    @ApiModelProperty("运输方式")
    private String transportType;

    @ApiModelProperty("WMS出货单号")
    private String wmsNo;

    @ApiModelProperty("工厂CODE")
    private String plantCode;

    @ApiModelProperty("所属BU")
    private String orgCode;
}
