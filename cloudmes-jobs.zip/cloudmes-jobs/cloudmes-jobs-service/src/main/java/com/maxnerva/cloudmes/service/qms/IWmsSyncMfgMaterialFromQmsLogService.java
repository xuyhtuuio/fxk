package com.maxnerva.cloudmes.service.qms;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.entity.qms.WmsSyncMfgMaterialFromQmsLog;

/**
 * <p>
 * 从qms同步有效期log表 服务类
 * </p>
 *
 * @author likun
 * @since 2024-11-27
 */
public interface IWmsSyncMfgMaterialFromQmsLogService extends IService<WmsSyncMfgMaterialFromQmsLog> {

}
