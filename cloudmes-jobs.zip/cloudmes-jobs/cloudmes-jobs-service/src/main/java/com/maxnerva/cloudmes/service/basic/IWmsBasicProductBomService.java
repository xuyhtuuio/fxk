package com.maxnerva.cloudmes.service.basic;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.entity.basic.WmsBasicProductBom;

/**
 * <p>
 * 同步basic产品bom表 服务类
 * </p>
 *
 * @author likun
 * @since 2024-12-23
 */
public interface IWmsBasicProductBomService extends IService<WmsBasicProductBom> {

}
