package com.maxnerva.cloudmes.service.basic;

import cn.hutool.core.collection.CollUtil;
import com.maxnerva.cloudmes.entity.basic.BasicVendor;
import com.maxnerva.cloudmes.service.sap.po.PoRfcService;
import com.maxnerva.cloudmes.service.sap.po.model.MfrInfoDto;
import com.sap.conn.jco.JCoException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/10/25 16:42
 * @Version: 1.0
 */
@Service
@Slf4j
public class BasicVendorService {
    @Autowired
    IBasicVendorService basicVendorService;

    @Autowired
    PoRfcService poRfcService;

    public void syncBasicVendor(String sapClient, String fromDate, String endDate) throws JCoException {

        List<MfrInfoDto> sapVendors = poRfcService.doGetMfrNameByDate(sapClient, fromDate, endDate);


        if (CollUtil.isNotEmpty(sapVendors)) {
            List<BasicVendor> basicVendors = new ArrayList<>();
            sapVendors.forEach(mfrInfoDto -> {
                basicVendors.add(new BasicVendor()
                        .setVendorCode(mfrInfoDto.getMfrCode())
                        .setVendorName(mfrInfoDto.getMfrName())
                        .setOrgCode("EPDVI")
                );
            });

            //basicVendorService.saveBatch(basicVendors, 500);
            boolean b = basicVendorService.saveOrUpdateBatch(basicVendors);

        }


    }
}
