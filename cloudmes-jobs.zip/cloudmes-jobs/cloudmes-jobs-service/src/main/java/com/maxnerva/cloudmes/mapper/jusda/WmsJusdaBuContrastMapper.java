package com.maxnerva.cloudmes.mapper.jusda;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.jusda.WmsJusdaBuContrastEntity;

/**
 * <p>
 * 准时达BU对照表 Mapper 接口
 * </p>
 *
 * @author Chao Zhang
 * @since 2022-11-22
 */
public interface WmsJusdaBuContrastMapper extends BaseMapper<WmsJusdaBuContrastEntity> {

}
