package com.maxnerva.cloudmes.service.sap.po;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.maxnerva.cloudmes.service.sap.gr.model.OutsourcingGrDto;
import com.maxnerva.cloudmes.service.sap.gr.model.OutsourcingGrItemDto;
import com.maxnerva.cloudmes.service.sap.po.model.*;
import com.maxnerva.cloudmes.service.sap.util.SapPoolFactory;
import com.maxnerva.cloudmes.service.wo.model.CreateCkdPoDto;
import com.maxnerva.cloudmes.service.wo.model.CreateCkdPoItemDto;
import com.maxnerva.cloudmes.service.wo.model.CreateCkdPoResultDto;
import com.sap.conn.jco.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * @author H7109018
 */
@Slf4j
@Service
public class PoRfcService {

    @Autowired
    SapPoolFactory sapPoolFactory;


    /**
     * 取 PO info
     *
     * @param sapClient
     * @param poNumber
     * @param items
     * @param history
     * @return
     * @throws JCoException
     */
    public List<PoItemInfoDto> doGetPoInfo(String sapClient, String poNumber, String items, String history) throws JCoException {

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        // SAP wo header interface
        JCoFunction function = pool.getRepository().getFunction("BAPI_PO_GETDETAIL");

        JCoParameterList inputParams = function.getImportParameterList();
        inputParams.setValue("PURCHASEORDER", poNumber);
        //默认 X
        inputParams.setValue("ITEMS", items);
        //默认 X
        inputParams.setValue("HISTORY", history);

        function.execute(pool);

        JCoTable poItems = function.getTableParameterList().getTable("PO_ITEMS");

        List<PoItemInfoDto> poItemInfoDtoList = new ArrayList<>();

        if (poItems != null && poItems.getNumRows() > 0) {

            JCoStructure headerInfo = function.getExportParameterList().getStructure("PO_HEADER");

            String docType = headerInfo.getString("DOC_TYPE");
            String purchaseOrg = headerInfo.getString("PURCH_ORG");
            String purchaseGroup = headerInfo.getString("PUR_GROUP");
            String vendorCode = headerInfo.getString("VENDOR");
            String vendorName = headerInfo.getString("VEND_NAME");


            JCoTable tabOutHistory = function.getTableParameterList().getTable("PO_ITEM_HISTORY_TOTALS");

            PoItemInfoDto tt;

            List<PoItemInfoDto> receiveQtyList = new ArrayList<>();

            if (tabOutHistory != null && tabOutHistory.getNumRows() > 0) {
                for (int j = 0, rows = tabOutHistory.getNumRows(); j < rows; j++) {
                    tt = new PoItemInfoDto();
                    tabOutHistory.setRow(j);
                    tt.setPoItem(tabOutHistory.getString("PO_ITEM"));
                    tt.setReceivedQty(tabOutHistory.getBigDecimal("DELIV_QTY"));
                    receiveQtyList.add(tt);
                }
            }

            PoItemInfoDto poItemEntity;

            for (int i = 0, rows = poItems.getNumRows(); i < rows; i++) {
                poItems.setRow(i);
                poItemEntity = new PoItemInfoDto();
                poItemEntity.setDocType(docType);
                poItemEntity.setPurchaseOrg(purchaseOrg);
                poItemEntity.setPurchaseGroup(purchaseGroup);
                poItemEntity.setVendorCode(vendorCode);
                poItemEntity.setVendorName(vendorName);
                poItemEntity.setPoNumber(poItems.getString("PO_NUMBER"));
                poItemEntity.setPoItem(poItems.getString("PO_ITEM"));
                poItemEntity.setPartNo(poItems.getString("MATERIAL"));
                poItemEntity.setPartVersion(poItems.getString("REV_LEV"));
                poItemEntity.setPartDesc(poItems.getString("SHORT_TEXT"));
                poItemEntity.setPlantCode(poItems.getString("PLANT"));
                poItemEntity.setWarehouseCode(poItems.getString("STORE_LOC"));
                poItemEntity.setQuantity(poItems.getBigDecimal("QUANTITY"));
                poItemEntity.setUnit(poItems.getString("UNIT"));
                poItemEntity.setPoDate(poItems.getString("CHANGED_ON"));
                poItemEntity.setMfrCode(poItems.getString("MFR_NO"));
                poItemEntity.setMfrPartNo(poItems.getString("MANU_MAT"));
                poItemEntity.setReceivedQty(BigDecimal.ZERO);
                // ITEM 收货完成
                poItemEntity.setCloseStatus(poItems.getString("DEL_COMPL"));
                for (PoItemInfoDto a : receiveQtyList) {
                    if (poItems.getString("PO_ITEM").equalsIgnoreCase(a.getPoItem())) {
                        poItemEntity.setReceivedQty(a.getReceivedQty());
                        break;
                    }
                }
                poItemInfoDtoList.add(poItemEntity);
            }
        }

        return poItemInfoDtoList;
    }


    /**
     * 獲取dn detail
     *
     * @param dnNo
     * @return
     */
    public DnInfoDto doGetDnHeaderAndDetailInfo(String sapClient, String plantCode, String dnNo) throws JCoException {

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        // SAP wo header interface
        JCoFunction function = pool.getRepository().getFunction("Z_SDFM032");

        JCoParameterList inputParams = function.getImportParameterList();
        inputParams.setValue("PLANT0", plantCode);
        inputParams.setValue("VBELN0", dnNo);

        function.execute(pool);

        JCoTable headerTable = function.getTableParameterList().getTable("SHIPORDERHEADER");
        JCoTable detailTable = function.getTableParameterList().getTable("SHIPORDERDETAIL");

        DnInfoDto dnInfoDto = new DnInfoDto();

        if (headerTable == null && headerTable.getNumRows() == 0) {
            return null;
        }
        headerTable.appendRow();
        headerTable.setRow(0);
        dnInfoDto.setDnNo(headerTable.getString("VBELN"));
        dnInfoDto.setCustPoNo(headerTable.getString("BSTKD"));
        dnInfoDto.setCustCode(headerTable.getString("KUNNR"));
        dnInfoDto.setShipCity(headerTable.getString("SH_CITY1"));
        dnInfoDto.setShipToNo(headerTable.getString("KUNAG"));
        dnInfoDto.setSapTotalQty(headerTable.getDouble("TOTQTY"));
        dnInfoDto.setDnCreateTime(headerTable.getString("AEDAT") + " " + headerTable.getString("ERZET"));

        List<DnDetailInfoDto> detailList = new ArrayList<>();
        DnDetailInfoDto dnDetail;

        for (int i = 0, rows = detailTable.getNumRows(); i < rows; i++) {
            detailTable.setRow(i);
            dnDetail = new DnDetailInfoDto();
            dnDetail.setDnNo(detailTable.getString("VBELN"));
            dnDetail.setDnItem(detailTable.getString("POSNR"));
            dnDetail.setWarehouseCode(detailTable.getString("LGORT"));
            dnDetail.setPartNo(detailTable.getString("MATNR"));
            dnDetail.setCustNo(detailTable.getString("KDMAT"));
            dnDetail.setRequestQty(Double.valueOf(detailTable.getString("LFIMG")));
            dnDetail.setCustPo(detailTable.getString("BSTKD"));
            detailList.add(dnDetail);
        }

        dnInfoDto.setDnDetailInfoDtos(detailList);

        return dnInfoDto;
    }

    /**
     * 獲取制造商名称
     *
     * @return
     */
    public MfrInfoDto doGetMfrNameByCode(String sapClient, String mfrCode) throws JCoException {

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        // SAP wo header interface
        JCoFunction function = pool.getRepository().getFunction("Z_MMFM040");

        JCoTable itemTable = function.getTableParameterList().getTable("LIFNR");
        itemTable.appendRow();
        itemTable.setRow(0);
        itemTable.setValue("SIGN", "I");
        itemTable.setValue("OPTION", "EQ");
        itemTable.setValue("LOW", mfrCode);
        itemTable.setValue("HIGH", mfrCode);


        function.execute(pool);

        JCoTable infoTable = function.getTableParameterList().getTable("IT_OUT");

        if (infoTable == null && infoTable.getNumRows() == 0) {
            return null;
        }
        System.out.println("aaaaaa" + infoTable);

        MfrInfoDto dto = new MfrInfoDto();
        infoTable.appendRow();
        infoTable.setRow(0);
        dto.setMfrName(infoTable.getString("NAME1"));
        return dto;
    }

    /**
     * 獲取制造商名称
     *
     * @return
     */
    public List<MfrInfoDto> doGetMfrNameByDate(String sapClient, String fromDate, String endDate) throws JCoException {

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        // SAP wo header interface
        JCoFunction function = pool.getRepository().getFunction("Z_MMFM040");

        JCoTable itemTable = function.getTableParameterList().getTable("ERDAT");
        itemTable.appendRow();
        itemTable.setRow(0);
        itemTable.setValue("SIGN", "I");
        itemTable.setValue("OPTION", "BT");
        itemTable.setValue("LOW", fromDate);
        itemTable.setValue("HIGH", endDate);

        function.execute(pool);

        JCoTable infoTable = function.getTableParameterList().getTable("IT_OUT");

        if (infoTable == null && infoTable.getNumRows() == 0) {
            return null;
        }

        List<MfrInfoDto> mfrInfoDtos = new ArrayList<>();
        MfrInfoDto dto;
        for (int i = 0, rows = infoTable.getNumRows(); i < rows; i++) {
            infoTable.setRow(i);
            dto = new MfrInfoDto();
            dto.setMfrCode(infoTable.getString("LIFNR"));
            dto.setMfrName(infoTable.getString("NAME1"));
            mfrInfoDtos.add(dto);
        }

        return mfrInfoDtos;
    }

    /**
     * 委外批量过账
     * 541 发料
     * 542 反转
     *
     * @param sapClient
     * @param dtos      过账dto
     * @return 成功则返回单号
     * @throws JCoException
     */
    public String doBatchTransferOutsourcing(String sapClient, List<TransferOutsourcingDto> dtos) throws JCoException {

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        // SAP wo header interface
        JCoFunction function = pool.getRepository().getFunction("Z_MMFM030");

        JCoParameterList inputParams = function.getImportParameterList();
        JCoStructure header = inputParams.getStructure("GOODSMVT_HEADER");
        //转仓日期
        header.setValue("PSTNG_DATE", dtos.get(0).getTransactionDate());
        //转仓日期
        header.setValue("DOC_DATE", dtos.get(0).getDocDate());
        //单号
        header.setValue("HEADER_TXT", dtos.get(0).getPoNo());
        //专案名称
        if (StrUtil.isNotBlank(dtos.get(0).getRefDocNo())) {
            header.setValue("REF_DOC_NO", dtos.get(0).getRefDocNo());
        }

        inputParams.setValue("GOODSMVT_HEADER", header);

        JCoStructure code = inputParams.getStructure("GOODSMVT_CODE");
        code.setValue("GM_CODE", "04");
        inputParams.setValue("GOODSMVT_CODE", code);

        JCoTable itemTable = function.getTableParameterList().getTable("GOODSMVT_ITEM");
        for (int i = 0; i < dtos.size(); i++) {
            itemTable.appendRow();
            itemTable.setRow(i);

            //过账类型
            itemTable.setValue("MOVE_TYPE", dtos.get(i).getMoveType());

            itemTable.setValue("PLANT", dtos.get(i).getPlantCode());
            //转出料号
            itemTable.setValue("MATERIAL", dtos.get(i).getPartNo());
            itemTable.setValue("BATCH", dtos.get(i).getPartNoVersion());
            itemTable.setValue("STGE_LOC", dtos.get(i).getWarehouseCode());
            itemTable.setValue("VENDOR", dtos.get(i).getVendorCode());
            //数量
            itemTable.setValue("ENTRY_QNT", dtos.get(i).getQty());
            //单位
            itemTable.setValue("ENTRY_UOM", dtos.get(i).getBom());
            itemTable.setValue("PO_NUMBER", dtos.get(i).getPoNo());
            itemTable.setValue("PO_ITEM", dtos.get(i).getPoItem());
        }

        function.execute(pool);

        JCoParameterList exportlist = function.getExportParameterList();
        //获取转仓后产生的单号
        String transferNo = String.valueOf(exportlist.getValue("MATERIALDOCUMENT"));

        if (StrUtil.isBlank(transferNo)) {
            //转仓失败，未获取单号，需要在表return中获取失败原因
            String errorMessage = "Sap error：";

            JCoTable returnTable = function.getTableParameterList().getTable("RETURN");

            if (returnTable != null && returnTable.getNumRows() > 0) {
                for (int i = 0; i < returnTable.getNumRows(); i++) {
                    returnTable.setRow(i);
                    errorMessage = errorMessage + returnTable.getString("MESSAGE") + ",[item]:"
                            + returnTable.getString("ROW") + ";";
                }
            } else {
                errorMessage = errorMessage + "SAP do not give failure reason";
            }
            throw new RuntimeException(errorMessage);
        }

        return transferNo;

    }

    public String doOutsourcingGr(String sapClient, OutsourcingGrDto dto) throws JCoException {

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        // SAP wo header interface
        JCoFunction function = pool.getRepository().getFunction("Z_MMFM030");

        JCoParameterList inputParams = function.getImportParameterList();
        JCoStructure header = inputParams.getStructure("GOODSMVT_HEADER");
        //收货日期
        header.setValue("PSTNG_DATE", dto.getDocDate());
        //收货日期
        header.setValue("DOC_DATE", dto.getDocDate());
        //单号
        header.setValue("HEADER_TXT", dto.getHeaderTxt());

        inputParams.setValue("GOODSMVT_HEADER", header);

        JCoStructure code = inputParams.getStructure("GOODSMVT_CODE");
        code.setValue("GM_CODE", dto.getGmCode());
        inputParams.setValue("GOODSMVT_CODE", code);

        List<OutsourcingGrItemDto> items = dto.getItems();

        JCoTable itemTable = function.getTableParameterList().getTable("GOODSMVT_ITEM");
        JCoTable serialTable = function.getTableParameterList().getTable("GOODSMVT_SERIALNUMBER");
        for (int i = 0; i < items.size(); i++) {
            itemTable.appendRow();
            itemTable.setRow(i);
            //过账类型
            itemTable.setValue("MATERIAL", items.get(i).getPartNo());
            itemTable.setValue("PLANT", items.get(i).getPlantCode());
            if (i == 0) {
                itemTable.setValue("STGE_LOC", items.get(i).getWarehouseCode());
                itemTable.setValue("PO_NUMBER", items.get(i).getPoNo());
                itemTable.setValue("PO_ITEM", items.get(i).getPoItem());
            } else {
                itemTable.setValue("SPEC_STOCK", "O");
            }
            itemTable.setValue("BATCH", items.get(i).getPartVersion());
            itemTable.setValue("MOVE_TYPE", items.get(i).getMovType());
            itemTable.setValue("VENDOR", items.get(i).getVendorCode());
            itemTable.setValue("VAL_TYPE", items.get(i).getValueType());
            //数量
            itemTable.setValue("ENTRY_QNT", items.get(i).getQty());
            //单位
            itemTable.setValue("ENTRY_UOM", items.get(i).getBom());
            if (StringUtils.isNotEmpty(items.get(i).getMvtInd())) {
                itemTable.setValue("MVT_IND", items.get(i).getMvtInd());
            }
            itemTable.setValue("LINE_ID", items.get(i).getLineId());
            itemTable.setValue("PARENT_ID", items.get(i).getParentId());

            serialTable.appendRow();
            serialTable.setRow(i);

            serialTable.setValue("MATDOC_ITM", items.get(i).getMatDocItem());
            serialTable.setValue("SERIALNO", items.get(i).getSerialNo());

        }

        function.execute(pool);

        JCoParameterList exportlist = function.getExportParameterList();
        //获取转仓后产生的单号
        String transferNo = String.valueOf(exportlist.getValue("MATERIALDOCUMENT"));

        if (StrUtil.isBlank(transferNo)) {
            //转仓失败，未获取单号，需要在表return中获取失败原因
            String errorMessage = "Sap error：";

            JCoTable returnTable = function.getTableParameterList().getTable("RETURN");

            if (returnTable != null && returnTable.getNumRows() > 0) {
                for (int i = 0; i < returnTable.getNumRows(); i++) {
                    returnTable.setRow(i);
                    errorMessage = errorMessage + returnTable.getString("MESSAGE") + ",[item]:"
                            + returnTable.getString("ROW") + ";";
                }
            } else {
                errorMessage = errorMessage + "SAP do not give failure reason";
            }
            throw new RuntimeException(errorMessage);
        }

        return transferNo;

    }

    public CreateCkdPoResultDto doCreateCkdPo(String sapClient, CreateCkdPoDto dto) throws JCoException, RuntimeException {

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        JCoFunction function = pool.getRepository().getFunction("Z_MMFM062");

        JCoStructure headerTable = function.getImportParameterList().getStructure("PO_HEADER");
        headerTable.setValue("COMP_CODE", dto.getCompCode());
        headerTable.setValue("DOC_TYPE", dto.getDocType());
        headerTable.setValue("CREAT_DATE", dto.getCreateDate());
        headerTable.setValue("VENDOR", dto.getVendorCode());
        headerTable.setValue("PURCH_ORG", dto.getPurchaseOrg());
        headerTable.setValue("PUR_GROUP", dto.getPurchaseGroup());
        headerTable.setValue("DOC_DATE", dto.getCreateDate());

        JCoTable itemTable = function.getTableParameterList().getTable("PO_ITEMS");
        List<CreateCkdPoItemDto> poItems = dto.getPoItem();
        for (int i = 0; i < poItems.size(); i++) {
            itemTable.appendRow();
            itemTable.setRow(i);
            itemTable.setValue("PO_ITEM", poItems.get(i).getPoItem());
            itemTable.setValue("MATERIAL", poItems.get(i).getMaterial());
            itemTable.setValue("MATERIAL_EXTERNAL", poItems.get(i).getMaterialExternal());
            itemTable.setValue("EMATERIAL_EXTERNAL", poItems.get(i).getEmaterialExternal());
            itemTable.setValue("PLANT", poItems.get(i).getPlantCode());
            itemTable.setValue("STGE_LOC", poItems.get(i).getStgeLoc());
            itemTable.setValue("QUANTITY", poItems.get(i).getQty());
            itemTable.setValue("PO_UNIT", poItems.get(i).getBom());
            itemTable.setValue("VAL_TYPE", poItems.get(i).getValType());
        }
        JCoTable poPartner = function.getTableParameterList().getTable("PO_PARTNER");
        poPartner.appendRow();
        poPartner.setRow(0);
        poPartner.setValue("PARTNERDESC", dto.getPartnerDesc());
        poPartner.setValue("LANGU", dto.getLangu());
        poPartner.setValue("BUSPARTNO", dto.getBuspartNo());

        if (StringUtils.isNotEmpty(dto.getBuyTextId())) {
            JCoTable poTextHeader = function.getTableParameterList().getTable("PO_TEXTHEADER");
            poTextHeader.appendRow();
            poTextHeader.setRow(0);
            poTextHeader.setValue("TEXT_ID", dto.getBuyTextId());
            poTextHeader.setValue("TEXT_LINE", dto.getBuyTextLine());
            poTextHeader.appendRow();
            poTextHeader.setRow(1);
            poTextHeader.setValue("TEXT_ID", dto.getSellTextId());
            poTextHeader.setValue("TEXT_LINE", dto.getSellTextLine());
        }
        function.execute(pool);
        CreateCkdPoResultDto resultDto = new CreateCkdPoResultDto();
        String po1 = String.valueOf(function.getExportParameterList().getValue("PURCHASEORDER"));
        String po2 = String.valueOf(function.getExportParameterList().getValue("PURCHASEORDER_PO2"));
        if (StringUtils.isNotEmpty(po1) && StringUtils.isNotEmpty(po2)) {
            resultDto.setCode(0);
            resultDto.setPo1Number(po1);
            resultDto.setPo2Number(po2);
            resultDto.setMessage("OK");
            return resultDto;
        }
        if (StringUtils.isEmpty(po1) && StringUtils.isEmpty(po2)) {
            resultDto.setCode(1);
        } else {
            resultDto.setCode(2);
        }
        resultDto.setPo1Number(StringUtils.isEmpty(po1) ? "" : po1);
        resultDto.setPo2Number(StringUtils.isEmpty(po2) ? "" : po2);
        String errorMessage = "SAP do not give failure reason";
        JCoTable returnTable = function.getTableParameterList().getTable("RETURN");
        if (returnTable != null && returnTable.getNumRows() > 0) {
            errorMessage = returnTable.getString("MESSAGE");
        }

        resultDto.setMessage(errorMessage);
        return resultDto;
    }

    /**
     * 创建DN
     *
     * @param sapClient
     * @param dto
     * @return
     * @throws JCoException
     * @throws RuntimeException
     */

    public CreateDnResultDto doCreateDn(String sapClient, CreateDnInputDto dto) throws JCoException, RuntimeException {

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        JCoFunction function = pool.getRepository().getFunction("Z_SDFM083");

        JCoParameterList inputParams = function.getImportParameterList();
        inputParams.setValue("P_CHOOSE", dto.getCreateDocType());
        inputParams.setValue("P_SOLDTO", "1712311G01");
        inputParams.setValue("P_SHIPTO", "BPT101TJ");
//        inputParams.setValue("BUYERDEPTCODE", dto.getBuyerDeptCode());
//        inputParams.setValue("SELLERDEPTCODE", dto.getSellerDeptCode());
//        inputParams.setValue("P_SHIP", dto.getShippingPoint());

        // ZSOHEADER
        JCoTable soHeader = function.getTableParameterList().getTable("ZSOHEADER_");
        soHeader.appendRow();
        soHeader.setRow(0);
        soHeader.setValue("DOC_TYPE", dto.getSalesDocType());
        soHeader.setValue("SALES_ORG", dto.getSalesOrganization());
        soHeader.setValue("DISTR_CHAN", dto.getDistributionChannel());
        soHeader.setValue("DIVISION", dto.getDivision());

//        soHeader.setValue("PURCH_NO_C", dto.getCustomerPO());

        // items
        JCoTable itemTable = function.getTableParameterList().getTable("ZSOITEM_");
//        JCoTable scheduleTable = function.getTableParameterList().getTable(" ZSCHEDULES");

        List<CreateDnItemInputDto> items = dto.getItems();
        for (int i = 0; i < items.size(); i++) {
            itemTable.appendRow();
            itemTable.setRow(0);
            itemTable.setValue("ITM_NUMBER", items.get(i).getItemNumber());
            itemTable.setValue("MATERIAL", items.get(i).getPartNo());
            if (StringUtils.isNotEmpty(items.get(i).getPartVersion())) {
                itemTable.setValue("BATCH", items.get(i).getPartVersion());
            }
            itemTable.setValue("PLANT", items.get(i).getPlantCode());
            itemTable.setValue("STORE_LOC", items.get(i).getWarehouseCode());
            itemTable.setValue("REQ_QTY", items.get(i).getQty());
            itemTable.setValue("VAL_TYPE", items.get(i).getValueType());
//            scheduleTable.appendRow();
//            scheduleTable.setRow(0);
//            scheduleTable.setValue("ITM_NUMBER", items.get(i).getItemNumber());
//            scheduleTable.setValue("REQ_QTY", items.get(i).getQty());
        }

//        JCoTable partnerTable = function.getTableParameterList().getTable("ZPARTNERS");
//        partnerTable.appendRow();
//        partnerTable.setRow(0);
//        partnerTable.setValue("PARTN_ROLE", dto.getPartnerBuyerFunction());
//        partnerTable.setValue("PARTN_NUMB", dto.getPartnerBuyerFunctionNumber());
//        partnerTable.appendRow();
//        partnerTable.setRow(1);
//        partnerTable.setValue("PARTN_ROLE", dto.getPartnerSellerFunction());
//        partnerTable.setValue("PARTN_NUMB", dto.getPartnerSellerFunctionNumber());

        function.execute(pool);

        JCoTable returnTable = function.getTableParameterList().getTable("ZRETSUC");

        CreateDnResultDto resultDto = new CreateDnResultDto();
        resultDto.setDnNumber("");
        resultDto.setSoNumber("");
        resultDto.setResult("SAP Error: No reason");

        if (returnTable != null && returnTable.getNumRows() > 0) {
            returnTable.setRow(0);
            String soNumber = returnTable.getString("ZSO");
            String dnNumber = returnTable.getString("ZDN");

            if (StringUtils.isNotEmpty(dnNumber)) {
                resultDto.setDnNumber(dnNumber);
                resultDto.setSoNumber(soNumber);
                resultDto.setResult("OK");

            } else {
                resultDto.setResult("SAP Error: " + returnTable.getString("ZMESSAGE"));
            }
        }

        return resultDto;
    }


    /**
     * CKD出货后扣账
     */
    public CkdShipPgiResultDto ckdShipPgi(String sapClient, String dnNo, String date) throws JCoException {

        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

        JCoFunction function = pool.getRepository().getFunction("Z_SDFM084");

        JCoTable itemTable = function.getTableParameterList().getTable("ZSDDN_PGI");
        itemTable.appendRow();
        itemTable.setRow(0);
        itemTable.setValue("VBELN", dnNo);
        itemTable.setValue("PGIDATE", date);
        function.execute(pool);
        JCoTable returnTable = function.getTableParameterList().getTable("ZSDDN_PGI");

        CkdShipPgiResultDto resultDto = new CkdShipPgiResultDto();
        resultDto.setDnNo("");
        resultDto.setPgiNo("");
        resultDto.setMsg("SAP Error: No reason");
        if (returnTable != null && returnTable.getNumRows() > 0) {
            returnTable.setRow(0);
            String pgiNo = returnTable.getString("PGI_DOCUMENT");
            if (StringUtils.isNotEmpty(pgiNo)) {
                resultDto.setPgiNo(pgiNo);
                resultDto.setDnNo(dnNo);
                resultDto.setMsg("OK");
            } else {
                resultDto.setMsg("SAP Error: " + returnTable.getString("MESSAGE"));
            }
        }
        return resultDto;
    }
}