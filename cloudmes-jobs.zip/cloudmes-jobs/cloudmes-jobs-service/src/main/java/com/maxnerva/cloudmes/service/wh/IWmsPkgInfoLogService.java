package com.maxnerva.cloudmes.service.wh;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.entity.wh.WmsPkgInfoLog;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author likun
 * @since 2022-08-05
 */
public interface IWmsPkgInfoLogService extends IService<WmsPkgInfoLog> {

}
