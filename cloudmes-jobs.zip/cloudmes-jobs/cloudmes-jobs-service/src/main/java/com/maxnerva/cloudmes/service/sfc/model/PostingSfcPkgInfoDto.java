package com.maxnerva.cloudmes.service.sfc.model;

import lombok.Data;

/**
 * @Author hgx
 * @Description 抛PKG info资料给SFC
 * @Date 2023/6/8
 */
@Data
public class PostingSfcPkgInfoDto {
    private String orgCode;

    private PostPkgInfoToSfcDto postPkgInfoToSfcDto;
}
