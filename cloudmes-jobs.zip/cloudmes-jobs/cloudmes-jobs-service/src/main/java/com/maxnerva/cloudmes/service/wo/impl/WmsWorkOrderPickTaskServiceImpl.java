package com.maxnerva.cloudmes.service.wo.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderPickTask;
import com.maxnerva.cloudmes.mapper.wo.WmsWorkOrderPickTaskMapper;
import com.maxnerva.cloudmes.service.wo.IWmsWorkOrderPickTaskService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 捡料任务表 服务实现类
 * </p>
 *
 * @author likun
 * @since 2023-07-11
 */
@Slf4j
@Service
public class WmsWorkOrderPickTaskServiceImpl extends ServiceImpl<WmsWorkOrderPickTaskMapper, WmsWorkOrderPickTask>
        implements IWmsWorkOrderPickTaskService {

}
