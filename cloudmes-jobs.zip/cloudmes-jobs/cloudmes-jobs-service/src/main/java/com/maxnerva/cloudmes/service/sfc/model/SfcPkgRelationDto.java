package com.maxnerva.cloudmes.service.sfc.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @ClassName SfcPkgRelationDto
 * @Description TODO
 * @Author Likun
 * @Date 2023/2/9
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Data
public class SfcPkgRelationDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String oldPkgId;

    private String remainQty;

    private String hhPn;

    private String mfgPn;

    private String dateCode;

    private String lotNo;
}
