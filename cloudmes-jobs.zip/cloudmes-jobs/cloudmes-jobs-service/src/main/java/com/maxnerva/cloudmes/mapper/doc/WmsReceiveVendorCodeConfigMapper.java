package com.maxnerva.cloudmes.mapper.doc;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.doc.WmsReceiveVendorCodeConfig;

/**
 * (WmsReceiveVenderCodeConfig)表数据库访问层
 *
 * @author hgx
 * @since 2023-12-28
 */
public interface WmsReceiveVendorCodeConfigMapper extends BaseMapper<WmsReceiveVendorCodeConfig> {

}

