package com.maxnerva.cloudmes.service.flownet.model;

import lombok.Data;

/**
 * @Author hgx
 * @Description 报废入库抛flownet 明细dto
 * @Date 2023/8/15
 */
@Data
public class ScrapInStorageFlownetDetailDto {
    private String PPID;
    private String warehouse;
    private String BillingNO;
}
