package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName PostingScheduleTransactionTypeEnum
 * @Description 过账方式枚举
 **/
public enum PostingScheduleTransactionTypeEnum {
    DN_TRANSACTION("DN_TRANSACTION","DN扣账");

    private final String dictCode;

    private final String dictName;

    PostingScheduleTransactionTypeEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (PostingScheduleTransactionTypeEnum sectionTypeEnum : values()) {
            if (sectionTypeEnum.getDictCode().equals(dictCode)) {
                return sectionTypeEnum.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

    public static PostingScheduleTransactionTypeEnum getByValue(String dictCode) {
        for (PostingScheduleTransactionTypeEnum sectionTypeEnum : values()) {
            if (sectionTypeEnum.getDictCode().equals(dictCode)) {
                return sectionTypeEnum;
            }
        }
        return null;
    }
}
