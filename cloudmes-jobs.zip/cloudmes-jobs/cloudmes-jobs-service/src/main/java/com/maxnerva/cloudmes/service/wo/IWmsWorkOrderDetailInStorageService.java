package com.maxnerva.cloudmes.service.wo;

import com.baomidou.mybatisplus.extension.service.IService;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderDetailInStorage;

/**
 * <p>
 * 工单明细531入库信息表 服务类
 * </p>
 *
 * @author likun
 * @since 2023-03-01
 */
public interface IWmsWorkOrderDetailInStorageService extends IService<WmsWorkOrderDetailInStorage> {

}
