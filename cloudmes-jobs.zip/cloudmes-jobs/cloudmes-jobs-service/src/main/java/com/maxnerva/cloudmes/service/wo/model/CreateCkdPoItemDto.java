package com.maxnerva.cloudmes.service.wo.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @author H7109018
 */
@Data
public class CreateCkdPoItemDto implements Serializable {

    private static final long serialVersionUID = -1L;

    //PO ITEM
    // 00010
    private String poItem;
    //料号
    // 41040GQ00-030-G
    private String material;
    //制造商料号
    //BR24G02NUX-3TTR
    private String materialExternal;
    //制造商简称
    // ROHM
    private String ematerialExternal;

    //E6V1
    private String plantCode;

    //仓码
    // D2RG
    private String stgeLoc;

    // 价格，币别

    //数量 10
    private String qty;
    //单位
    private String bom;

    // COSTRM
    private String valType;








}
