package com.maxnerva.cloudmes.entity.wo;

import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>
 * 工单detail信息表
 * </p>
 *
 * @author likun
 * @since 2022-08-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value = "WmsWorkOrderDetail对象", description = "工单detail信息表")
public class WmsWorkOrderDetail extends Model<WmsWorkOrderDetail> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "reservationNumber")
    private String reservationNumber;

    @ApiModelProperty(value = "reservationItem")
    private String reservationItem;

    @ApiModelProperty(value = "主键id;")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "工单号，aufnr;//工单號")
    private String workOrderNo;

    @ApiModelProperty(value = "SAP工单item")
    private String itemNumber;

    @ApiModelProperty(value = "工单群组，posnr，备料以工单群组推荐;//群組")
    private String workOrderItem;

    @ApiModelProperty(value = "物料类别")
    private String materialType;

    @ApiModelProperty(value = "物料描述，maktx;//物料描述")
    private String materialDescription;

    @ApiModelProperty(value = "物料组别，matkl;//物料组别")
    private String materialGroup;

    @ApiModelProperty(value = "物料组别描述，wgbez;//物料组别描述")
    private String materialGroupDescription;

    @ApiModelProperty(value = "料号，matnr;//鴻海料號")
    private String partNo;

    @ApiModelProperty(value = "料号版次")
    private String partVersion;

    @ApiModelProperty(value = "主料料号")
    private String mainPartNo;

    @ApiModelProperty(value = "主料料号版本")
    private String mainPartVersion;

    @ApiModelProperty(value = "料号关系类型,M主料,S替代料")
    private String partRelationship;

    @ApiModelProperty(value = "客户料号，kdmat;//属于客户的材料")
    private String customerMaterialNo;

    @ApiModelProperty(value = "sap需求量")
    private BigDecimal requiredQuantitySap;

    @ApiModelProperty(value = "按单位转换后的WMS需求量")
    private BigDecimal requiredQuantity;

    @ApiModelProperty(value = "移入工单")
    private String moveInOrder;

    @ApiModelProperty(value = "移入数量")
    private BigDecimal moveInQty;

    @ApiModelProperty(value = "移入盘数")
    private BigDecimal moveInPkgIdQty;

    @ApiModelProperty(value = "移出工单")
    private String removeOrder;

    @ApiModelProperty(value = "移出数量")
    private BigDecimal removeQty;

    @ApiModelProperty(value = "移出盘数")
    private BigDecimal removePkgIdQty;

    @ApiModelProperty(value = "备料量")
    private BigDecimal stockQty;

    @ApiModelProperty(value = "备料盘数")
    private BigDecimal addPkgIdQty;

    @ApiModelProperty(value = "备料总量")
    private BigDecimal stockTotalQty;

    @ApiModelProperty(value = "备料总盘数")
    private BigDecimal addPkgIdTotalQty;

    @ApiModelProperty(value = "wms单位")
    private String uomCode;

    @ApiModelProperty(value = "基本计量单位fromsap，meins;//基本计量单位fromsap")
    private String sapUomCode;

    @ApiModelProperty(value = "版本标识，revlv;//版本标识、修订版本")
    private String reversionLevel;

    @ApiModelProperty(value = "上级总成料号，baugr，待确认;//上级总成料号")
    private String higherLevelMaterialNo;

    @ApiModelProperty(value = "更改人的姓名，aenam;//更改人的姓名")
    private String sapCreateBy;

    @ApiModelProperty(value = "上次更改时间，aedat;//上次更改时间")
    private LocalDate startDate;

    @ApiModelProperty(value = "指示器：替代项目，alpos;//指示器：替代项目")
    private String indicatorAlternativeItem;

    @ApiModelProperty(value = "存储位置-来源倉碼，lgort;//存储位置-倉碼")
    private String fromWarehouseCode;

    @ApiModelProperty(value = "撤回数量，enmng;//撤回数量")
    private BigDecimal withdrawnQuantity;

    @ApiModelProperty(value = "虚拟项目指示器，dumps，未启用;//虚拟项目指示器")
    private String phantomItemIndicator;

    @ApiModelProperty(value = "原来的材料编号，bismt，未启用;//原来的材料编号")
    private String oldMaterialNo;

    @ApiModelProperty(value = "被删除的项目，xloek,未启用;//被删除的项目")
    private String deletedItem;

    @ApiModelProperty(value = "借方，贷方指标，shkzg,未启用;//借方/贷方指标")
    private String debitCreditIndicator;

    @ApiModelProperty(value = "批次号，charg，未启用;//批次号")
    private String batchNo;

    @ApiModelProperty(value = "预定/从属需求的项目编号，spos，未启用;//预定/从属需求的项目编号")
    private String reservationDependentRequireNo;

    @ApiModelProperty(value = "操作/活动编号，vornr，未启用;//操作/活动编号")
    private String operationActivityNo;

    @ApiModelProperty(value = "备选项目：组，alpgr，未启用;//备选项目：组")
    private String alternativeItemGroup;

    @ApiModelProperty(value = "成品料號，fgMatnr;//成品料號")
    private String finishGoodsNo;

    @ApiModelProperty(value = "采购人")
    private String buyer;

    @ApiModelProperty(value = "目标仓码,kitting仓仓码")
    private String toWarehouseCode;

    @ApiModelProperty(value = "目标仓码类型编码，用字典区分")
    private String toWarehouseTypeCode;

    @ApiModelProperty(value = "仓管員")
    private String materialManager;

    @ApiModelProperty(value = "1默认，参与备料进度显示（包材物料不猜与备料），0，不参与;参与备料进度显示，0，不参与")
    private Integer materialPreparationOperationFlag;

    @ApiModelProperty(value = "261消耗量")
    private BigDecimal postTo261Qty;

    @ApiModelProperty(value = "961超耗量")
    private BigDecimal postTo961Qty;

    @ApiModelProperty(value = "311备料量")
    private BigDecimal postTo311Qty;

    @ApiModelProperty(value = "261反转量")
    private BigDecimal postTo262Qty;

    @ApiModelProperty(value = "超耗退回数量，未启用")
    private BigDecimal returnOver261Qty;

    @ApiModelProperty(value = "311退料过账量")
    private BigDecimal postReturnTo311Qty;

    @ApiModelProperty(value = "反转量")
    private BigDecimal reverseQty;

    @ApiModelProperty(value = "消耗量")
    private BigDecimal consumeQty;

    @ApiModelProperty(value = "退料量")
    private BigDecimal returnQty;

    @ApiModelProperty(value = "mrpArea")
    private String mrpArea;

    @ApiModelProperty(value = "mrpController")
    private String mrpController;

    @ApiModelProperty(value = "valueType")
    private String valueType;

    @ApiModelProperty(value = "scanMode")
    private String scanMode;

    @ApiModelProperty(value = "postTo311ReturnMsg")
    private String postTo311ReturnMsg;

    @ApiModelProperty(value = "postTo311LastDt")
    private LocalDateTime postTo311LastDt;

    @ApiModelProperty(value = "postTo261ReturnMsg")
    private String postTo261ReturnMsg;

    @ApiModelProperty(value = "postTo261LastDt")
    private LocalDateTime postTo261LastDt;

    @ApiModelProperty(value = "postReturn311Msg")
    private String postReturn311Msg;

    @ApiModelProperty(value = "post262Msg")
    private String post262Msg;

    @ApiModelProperty("已分配备料量")
    private BigDecimal allocatedStockQty;

    @ApiModelProperty("已分配退料量")
    private BigDecimal allocatedReturnQty;

    /**
     * 移出262过账number
     */
    @ApiModelProperty(value = "postingSapRemoveNumber")
    private String postingSapRemoveNumber;

    /**
     * 移出262过账结果
     */
    @ApiModelProperty(value = "postingSapRemoveMsg")
    private String postingSapRemoveMsg;

    /**
     * 移出262过账时间
     */
    @ApiModelProperty(value = "postingSapRemoveDt")
    private LocalDateTime postingSapRemoveDt;

    /**
     * 移入261过账number
     */
    @ApiModelProperty(value = "postingSapMoveInNumber")
    private String postingSapMoveInNumber;

    /**
     * 移入261过账结果
     */
    @ApiModelProperty(value = "postingSapMoveInMsg")
    private String postingSapMoveInMsg;

    /**
     * 移入261过账时间
     */
    @ApiModelProperty(value = "postingSapMoveInDt")
    private LocalDateTime postingSapMoveInDt;

    /**
     * (默认0) ，其他值为历史版本号后续不参与过账
     */
    @ApiModelProperty(value = "postingSapStatus")
    private Integer postingSapStatus;

    /**
     * 移出262过账成功数量
     */
    @ApiModelProperty(value = "postingSapRemoveQty")
    private BigDecimal postingSapRemoveQty;

    /**
     * 移入过账261成功数量
     */
    @ApiModelProperty(value = "postingSapMoveInQty")
    private BigDecimal postingSapMoveInQty;

    /**
     * 是否合盘物料 N:不是，Y:是
     */
    @ApiModelProperty(value = "是否合盘物料 N:不是，Y:是")
    private String mergeFlag;

    @ApiModelProperty(value = "是否为烧录物料")
    private Boolean isBurn;

    @ApiModelProperty(value = "烧录值")
    private String burnValue;

    @ApiModelProperty(value = "制程分类")
    private String materialProductProcess;

    @ApiModelProperty(value = "需求总盘数")
    private BigDecimal requiredPkgQty;

    @ApiModelProperty(value = "N:不是剪角物料，Y:剪角物料")
    private String cutOffFlag;

    @ApiModelProperty(value = "当前捡料数量")
    private BigDecimal pickQty;

    @ApiModelProperty(value = "当前捡料盘数")
    private BigDecimal pickPkgQty;

    @ApiModelProperty(value = "群组捡料数量")
    private BigDecimal pickTotalQty;

    @ApiModelProperty(value = "群组捡料盘数")
    private BigDecimal pickPkgTotalQty;

    @ApiModelProperty(value = "制程类型")
    private String materialProductType;

    @ApiModelProperty(value = "不良品入库数量")
    private BigDecimal badInStorageQty;

    @ApiModelProperty(value = "不良品过账数量")
    private BigDecimal badPostSapQty;

    @ApiModelProperty(value = "采购组织")
    private String purchaseOrg;

    @ApiModelProperty(value = "JIT物料标识(Y--JIT物料 N--非JIT物料)")
    private String jitMaterialFlag;

    @ApiModelProperty(value = "单价")
    BigDecimal unitPrice;

    @ApiModelProperty(value = "币别")
    String currency;

    /**
     * 创建时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(hidden = true)
    private LocalDateTime createdDt;

    @ApiModelProperty(hidden = true)
    private String creator;

    /**
     * 最后修改人
     */
    @ApiModelProperty(hidden = true)
    private String lastEditor;

    /**
     * 最后一次编辑时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(hidden = true)
    private LocalDateTime lastEditedDt;

    @ApiModelProperty(value = "961备料量")
    private BigDecimal stockTo961Qty;

    @ApiModelProperty(value = "961过账信息")
    private String postTo961ReturnMsg;

    @ApiModelProperty(value = "961过账时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime postTo961LastDt;

    @ApiModelProperty(value = "标记类型")
    private String markerType;

    @ApiModelProperty(value = "标记")
    private String mark;

    @ApiModelProperty(value = "制造商")
    private String mfg;

    @ApiModelProperty(value = "制造商料号")
    private String mfgMaterialCode;

    @ApiModelProperty(value = "配套组")
    private String matingGroup;

    @ApiModelProperty(value = "料号是否可用标识，默认Y：可用，N：不可用")
    private String partNoUseFlag;
}
