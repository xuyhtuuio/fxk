package com.maxnerva.cloudmes.service.wo.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderDetailInStorage;
import com.maxnerva.cloudmes.mapper.wo.WmsWorkOrderDetailInStorageMapper;
import com.maxnerva.cloudmes.service.wo.IWmsWorkOrderDetailInStorageService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 工单明细531入库信息表 服务实现类
 * </p>
 *
 * @author likun
 * @since 2023-03-01
 */
@Service
public class WmsWorkOrderDetailInStorageServiceImpl extends ServiceImpl<WmsWorkOrderDetailInStorageMapper, WmsWorkOrderDetailInStorage> implements IWmsWorkOrderDetailInStorageService {

}
