package com.maxnerva.cloudmes.entity.outsourcing;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * <p>
 * 委外过账清单
 * </p>
 *
 * @author likun
 * @since 2023-12-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsOutsourcingSapTransactionLog对象", description="委外过账清单")
public class WmsOutsourcingSapTransactionLog extends BaseEntity<WmsOutsourcingSapTransactionLog> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "PO号")
    private String poNo;

    @ApiModelProperty(value = "群组")
    private String poItem;

    @ApiModelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "需求量")
    private BigDecimal requiredQuantity;

    @ApiModelProperty(value = "备料量")
    private BigDecimal stockQty;

    @ApiModelProperty(value = "过账数量")
    private BigDecimal transactionQty;

    @ApiModelProperty(value = "过账sap数量")
    private BigDecimal transactionSapQty;

    @ApiModelProperty(value = "过账日期")
    private LocalDateTime transactionDate;

    @ApiModelProperty(value = "过账类型")
    private String postType;

    @ApiModelProperty(value = "过账sap返回状态")
    private Integer postSapReturnFlag;

    @ApiModelProperty(value = "过账sap返回信息")
    private String postSapReturnMsg;

    @ApiModelProperty(value = "过账sap时间")
    private LocalDateTime postSapReturnDt;

    @ApiModelProperty(value = "过账流水号")
    private String outsourcingPostingNo;

    @ApiModelProperty("仓码")
    private String sapWarehouseCode;

    @ApiModelProperty("供应商编码")
    private String vendorCode;

    @ApiModelProperty("版次")
    private String partVersion;

    @ApiModelProperty("单位编码")
    private String uomCode;
}
