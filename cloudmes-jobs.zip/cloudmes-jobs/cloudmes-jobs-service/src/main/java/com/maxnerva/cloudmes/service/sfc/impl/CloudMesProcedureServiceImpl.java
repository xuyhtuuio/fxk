package com.maxnerva.cloudmes.service.sfc.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpStatus;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.entity.WmsSapPlant;
import com.maxnerva.cloudmes.entity.basic.WmsPlantCustomerConfig;
import com.maxnerva.cloudmes.entity.deliver.WmsShipPkgBindRecord;
import com.maxnerva.cloudmes.entity.mes.*;
import com.maxnerva.cloudmes.entity.wo.WmsBomFeeder;
import com.maxnerva.cloudmes.entity.wo.WmsPkgBurnInfo;
import com.maxnerva.cloudmes.enums.SectionTypeEnum;
import com.maxnerva.cloudmes.mapper.WmsSapPlantMapper;
import com.maxnerva.cloudmes.mapper.basic.BasicMaterialMapper;
import com.maxnerva.cloudmes.mapper.basic.WmsPlantCustomerConfigMapper;
import com.maxnerva.cloudmes.mapper.sfc.Epd6OracleProcedureMapper;
import com.maxnerva.cloudmes.mapper.wo.WmsPkgBurnInfoMapper;
import com.maxnerva.cloudmes.service.mes.MesService;
import com.maxnerva.cloudmes.service.mes.model.PkgInfoDTO;
import com.maxnerva.cloudmes.service.sfc.SfcStoredProcedureService;
import com.maxnerva.cloudmes.service.sfc.model.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/09/02 08:34
 * @Version: 1.0
 */
@Slf4j
@Service
@Component("MES")
public class CloudMesProcedureServiceImpl implements SfcStoredProcedureService {

    @Resource
    Epd6OracleProcedureMapper oracleProcedureMapper;
    private static final String ORG_CODE = "EPDVI";

    @Resource
    private MesService mesService;

    @Resource
    private WmsPlantCustomerConfigMapper wmsPlantCustomerConfigMapper;

    @Resource
    private WmsSapPlantMapper wmsSapPlantMapper;

    @Resource
    private BasicMaterialMapper basicMaterialMapper;

    @Resource
    private WmsPkgBurnInfoMapper wmsPkgBurnInfoMapper;

    @Override
    public List<WmsBomFeeder> getWmsBomFeeder(String partNo, String lineNo, String processType,
                                              String orgCode, String plantCode) {
        FeedBomFeignDTO feedBomFeignDTO = new FeedBomFeignDTO();
        feedBomFeignDTO.setPartNo(partNo);
        feedBomFeignDTO.setLineNo(lineNo);
        feedBomFeignDTO.setProcessType(StrUtil.EMPTY);
        feedBomFeignDTO.setPlantCode(StrUtil.EMPTY);
        feedBomFeignDTO.setOrgCode(orgCode);
        System.out.println("get feed bom content :" + JSONUtil.toJsonStr(feedBomFeignDTO));
        HttpResponse response = mesService.getFeedBom(feedBomFeignDTO);
        String body = response.body();
        log.info("getWmsBomFeeder content:{},return:{}", JSONUtil.toJsonStr(feedBomFeignDTO), body);
        if (StrUtil.isEmpty(body)) {
            log.error("mes getFeedBom error");
        }
        List<WmsBomFeeder> wmsBomFeeders = CollUtil.newArrayList();
        if (response.getStatus() == HttpStatus.HTTP_OK) {
            JSONObject mesReturnInfo = JSONUtil.parseObj(body);
            String code = mesReturnInfo.getStr("code");
            if (com.baomidou.mybatisplus.core.toolkit.StringUtils.isNotBlank(code) && "200".equalsIgnoreCase(code)) {
                wmsBomFeeders = JSONUtil.toList(JSONUtil.parseArray(mesReturnInfo.get("data")), WmsBomFeeder.class);
            }
        }
        long count = wmsBomFeeders.stream().filter(ObjectUtil::isNull).count();
        if (count > 0) {
            return CollUtil.newArrayList();
        }
        if (StringUtils.isNotBlank(processType)) {
            return wmsBomFeeders.stream().filter(o -> o.getProductProcess().equalsIgnoreCase(processType))
                    .collect(Collectors.toList());
        }
        return wmsBomFeeders;
    }

    @Override
    public String postingSfcPkgInfo(PostPkgInfoToSfcDto dto, String orgCode, String plantCode) {
        String result;
        PkgInfoDTO p = new PkgInfoDTO();
        p.setPkgId(dto.getPkgId());
        p.setSourceType(1);
        p.setComponentNo(dto.getPartNo());
        p.setOriginalQty(new BigDecimal(dto.getQty()));
        p.setCurrentQty(new BigDecimal(dto.getRemainQty()));
        p.setMfgName(dto.getMfgName());
        p.setMfgPn(dto.getMfgPartNo());
        p.setDateCode(dto.getDateCode());
        p.setLotNo(dto.getLotCode());
        p.setPlaceOfOrigin(dto.getPlaceOfOrigin());
        p.setOrgCode(orgCode);
        p.setSapWoNo(dto.getWorkOrderNo());
        p.setBurnValue(dto.getCheckSum());
        p.setPlantCode(plantCode);
        p.setEffectiveDate(dto.getEffectiveDate());
        p.setEndDate(dto.getEndDate());
        p.setVehicleCode(dto.getVehicleCode());
        p.setBinCode(dto.getBinCode());
        p.setProductNo(dto.getProductNo());
        p.setFeederNo(dto.getFeederNo());
        p.setMachineCode(dto.getMachineCode());
        //用org_code+pkg去wms_burn_pkg_info找信息,如果找到了就塞入burnDatetime
        WmsPkgBurnInfo wmsPkgBurnInfoDb = wmsPkgBurnInfoMapper.selectOne(Wrappers.<WmsPkgBurnInfo>lambdaQuery()
                .eq(WmsPkgBurnInfo::getOrgCode, orgCode)
                .eq(WmsPkgBurnInfo::getPkgId, dto.getPkgId())
                .orderByDesc(WmsPkgBurnInfo::getId)
                .last("limit 1"));
        if (ObjectUtil.isNotNull(wmsPkgBurnInfoDb)) {
            p.setBurnDatetime(ObjectUtil.isNotNull(wmsPkgBurnInfoDb.getBurnDatetime()) ?
                    wmsPkgBurnInfoDb.getBurnDatetime()
                            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) : StrUtil.EMPTY);
        }
        List<PkgInfoDTO> pkgInfoDTOList = CollUtil.newArrayList();
        pkgInfoDTOList.add(p);
        log.info("postingPreparePkgInfoToMes requestBody:{}", JSONUtil.toJsonStr(pkgInfoDTOList));
        HttpResponse httpResponse = mesService.postingWoPreparePkgInfoToMes(pkgInfoDTOList);
        String body = httpResponse.body();
        log.info("postingPreparePkgInfoToMes requestBody:{} responseBody:{}", JSONUtil.toJsonStr(pkgInfoDTOList), body);
        if (StrUtil.isEmpty(body)) {
            result = "INVOKE MES FAIL";
            return result;
        }
        if (httpResponse.getStatus() == HttpStatus.HTTP_OK) {
            JSONObject mesReturnInfo = JSONUtil.parseObj(body);
            String code = mesReturnInfo.getStr("code");
            String msg = mesReturnInfo.getStr("msg");
            if (StringUtils.isNotBlank(code) && "200".equalsIgnoreCase(code)) {
                result = "OK";
            } else {
                result = msg;
            }
        } else {
            result = "INVOKE MES FAIL";
        }
        return result;

    }

    @Override
    public PkgStatusInfoDto getPkgStatusInfo(PkgStatusInfoDto pkgStatusInfoDto, String orgCode,
                                             String plantCode) {
        PkgIdDTO pkgIdDTO = new PkgIdDTO();
        pkgIdDTO.setPkgId(pkgStatusInfoDto.getPkgId());
        pkgIdDTO.setOrgCode(orgCode);
        HttpResponse httpResponse = mesService.queryPkgId(pkgIdDTO);
        String body = httpResponse.body();
        if (StrUtil.isNotEmpty(body) && httpResponse.getStatus() == 200) {
            com.alibaba.fastjson.JSONObject dataHubReturnInfo = JSON.parseObject(body);
            int code = dataHubReturnInfo.getInteger("code");
            com.alibaba.fastjson.JSONObject data = dataHubReturnInfo.getJSONObject("data");
            if (code == 200) {
                if (ObjectUtil.isNotNull(data)) {
                    PkgIdVO pkgIdVO = data.toJavaObject(PkgIdVO.class);
                    if (ObjectUtil.isNotNull(pkgIdVO)) {
                        pkgStatusInfoDto.setIsOnline(pkgIdVO.getOfflineFlag() ? "N" : "Y");
                    }
                }
            }
        }
        return pkgStatusInfoDto;
    }

    @Override
    public List<SfcPalletInfoDto> getSfcPalletInfo(String barcode, String orgCode, String plantCode) {
        InStoreFeignDTO inStoreFeignDTO = new InStoreFeignDTO();
        inStoreFeignDTO.setBarcode(barcode);
        inStoreFeignDTO.setOrgCode(orgCode);
        log.info("get mes pallet content :{}", JSONUtil.toJsonStr(inStoreFeignDTO));
        HttpResponse response = mesService.getInstoreProduct(inStoreFeignDTO);
        String body = response.body();
        if (StrUtil.isEmpty(body)) {
            System.out.println("mes pallet error");
        }
        List<SfcPalletInfoDto> sfcPalletInfoDtoList = CollUtil.newArrayList();
        if (response.getStatus() == HttpStatus.HTTP_OK) {
            JSONObject mesReturnInfo = JSONUtil.parseObj(body);
            String code = mesReturnInfo.getStr("code");
            String msg = mesReturnInfo.getStr("msg");
            if (StringUtils.isNotBlank(code) && "200".equalsIgnoreCase(code)) {
                sfcPalletInfoDtoList = JSONUtil.toList(JSONUtil.parseArray(mesReturnInfo.get("data")), SfcPalletInfoDto.class);
                System.out.println(sfcPalletInfoDtoList);
            } else {
                throw new RuntimeException(msg);
            }
        }
        long count = sfcPalletInfoDtoList.stream().filter(ObjectUtil::isNull).count();
        if (count > 0) {
            return CollUtil.newArrayList();
        }
        return sfcPalletInfoDtoList;
    }

    @Override
    public List<PkgLinkListDto> getPkgLinkList(String pkgId) {
        Map input = new HashMap();
        input.put("i_pkgid", pkgId);

        oracleProcedureMapper.getPkgLinkList(input);
        List<PkgLinkListDto> result = (List<PkgLinkListDto>) input.get("o_dataset");

        return result;

    }

    @Override
    public String clearPkgStatusToSfc(String pkgId, String currentQty, String orgCode, String plantCode) {
        String result;
        PkgInfoReturnDTO pkgInfoReturnDTO = new PkgInfoReturnDTO();
        pkgInfoReturnDTO.setPkgId(pkgId);
        pkgInfoReturnDTO.setReturnQty(new BigDecimal(currentQty));
        pkgInfoReturnDTO.setOrgCode(orgCode);
        HttpResponse httpResponse = mesService.returnPkgInfo(pkgInfoReturnDTO);
        String body = httpResponse.body();
        if (StrUtil.isEmpty(body)) {
            result = "INVOKE MES FAIL";
            return result;
        }
        if (httpResponse.getStatus() == HttpStatus.HTTP_OK) {
            JSONObject mesReturnInfo = JSONUtil.parseObj(body);
            String code = mesReturnInfo.getStr("code");
            String msg = mesReturnInfo.getStr("msg");
            if (StringUtils.isNotBlank(code) && "200".equalsIgnoreCase(code)) {
                result = "OK";
            } else {
                result = msg;
            }
        } else {
            result = "INVOKE MES FAIL";
        }
        return result;
    }

    @Override
    public String sendSnDnRelationshipToSfc(String orgCode, String plantCode, String mrpArea, SnDnRelationshipDto dto) {
        SendSnDnRelationShipToMesVO toMesVO = new SendSnDnRelationShipToMesVO();
        BeanUtils.copyProperties(dto, toMesVO);
        toMesVO.setPoNo(StringUtils.isNotBlank(dto.getPo()) ? dto.getPo() : "");
        toMesVO.setSnsStr(dto.getSn());
        toMesVO.setPlantCode(plantCode);
        toMesVO.setOrgCode(orgCode);
        toMesVO.setVehicleNo("");
        WmsSapPlant wmsSapPlant = wmsSapPlantMapper.selectOne(Wrappers.<WmsSapPlant>lambdaQuery()
                .eq(WmsSapPlant::getOrgCode, orgCode)
                .eq(WmsSapPlant::getFactoryCode, plantCode)
                .last("limit 1"));
        String sectionType = wmsSapPlant.getSectionType();
        if (StrUtil.equals(SectionTypeEnum.ASSEMBLY_SECTION.getDictCode(), sectionType)) {
            String customerName = basicMaterialMapper.selectCustomerNameByMaterialNoCusNo(orgCode, plantCode,
                    dto.getProductNo(), dto.getCusNo());
            toMesVO.setCustomer(StringUtils.isNotEmpty(customerName) ? customerName : "");
        } else {
            WmsPlantCustomerConfig wmsPlantCustomerConfig = wmsPlantCustomerConfigMapper
                    .selectOne(Wrappers.<WmsPlantCustomerConfig>lambdaQuery()
                            .eq(WmsPlantCustomerConfig::getOrgCode, orgCode)
                            .eq(WmsPlantCustomerConfig::getMrpArea, mrpArea)
                            .last("limit 1"));
            if (ObjectUtil.isNull(wmsPlantCustomerConfig)) {
                return String.format("sendSnDnRelationshipToSfc orgCode:%s, mrpArea:%s," +
                        "wmsPlantCustomerConfig is null", orgCode, mrpArea);
            }
            toMesVO.setCustomer(wmsPlantCustomerConfig.getCustomerName());
        }
        log.info("sendSnDnRelationshipToSfc_MES request:{}", JSONUtil.toJsonStr(toMesVO));
        HttpResponse response = mesService.receiveShippingData(toMesVO);
        String body = response.body();
        if (StrUtil.isEmpty(body)) {
            log.error("mes sendSnDnRelationshipToSfc_MES return empty");
        }
        JSONObject jsonObject = JSONUtil.parseObj(body);
        return jsonObject.getStr("msg");
    }

    @Override
    public String doWarehousingPassSnStation(WarehousingPassSnStationDto dto,
                                             String orgCode, String plantCode) {
        InStorePassStationDTO inStorePassStationDTO = new InStorePassStationDTO();
        inStorePassStationDTO.setUserName(dto.getUserName());
        inStorePassStationDTO.setLine(dto.getLine());
        inStorePassStationDTO.setSection(dto.getSection());
        inStorePassStationDTO.setWStation(dto.getWStation());
        inStorePassStationDTO.setBadCode(dto.getBadCode());
        inStorePassStationDTO.setSn(dto.getSn());
        inStorePassStationDTO.setMyGroup(dto.getMyGroup());
        inStorePassStationDTO.setOrgCode(orgCode);
        log.info("doWarehousingPassSnStation content :{}", JSONUtil.toJsonStr(inStorePassStationDTO));
        HttpResponse response = mesService.inStorePassStation(inStorePassStationDTO);
        String body = response.body();
        if (StrUtil.isEmpty(body)) {
            log.error("doWarehousingPassSnStation error");
        }
        String result = StrUtil.EMPTY;
        if (response.getStatus() == HttpStatus.HTTP_OK) {
            JSONObject mesReturnInfo = JSONUtil.parseObj(body);
            String code = mesReturnInfo.getStr("code");
            if (StrUtil.isNotBlank(code) && "200".equalsIgnoreCase(code)) {
                result = mesReturnInfo.getStr("data");
            } else {
                result = mesReturnInfo.getStr("msg");
            }
        }
        return result;
    }

    @Override
    public Map getSfcExtendInfoBySn(String sn) {
        return null;
    }

    @Override
    public String insertAmazonLog(InsertAmazonLogDto amazonLogDto) {
        Map input = new HashMap();
        input.put("i_DEMAND_TYPE", amazonLogDto.getDemandType());
        input.put("i_AMAZON_ID", amazonLogDto.getAmazonId());
        input.put("i_REQUEST_ID", amazonLogDto.getRequestId());
        input.put("i_BUILD_TRIGGER_ID", amazonLogDto.getBuildTriggerId());
        input.put("i_ASSET_ID", amazonLogDto.getAssetId());
        input.put("i_QUANTITY", amazonLogDto.getQty());
        input.put("i_IPN", amazonLogDto.getIPn());
        input.put("i_ASSET_CATEGORY", amazonLogDto.getAssetCategory());
        input.put("i_TEST_ITEM", amazonLogDto.getTestItem());
        input.put("i_ITEM_DESCRIPTION", amazonLogDto.getItemDescription());
        input.put("i_SITE_CODE", amazonLogDto.getSiteCode());
        input.put("i_IN_STOCK_HUB", amazonLogDto.getInStockHub());
        input.put("i_MANUFACTURING_START_DATE", amazonLogDto.getManufacturingStartDate());
        input.put("i_ESTIMATED_READY_DATE", amazonLogDto.getEstimatedReadyDate());
        input.put("i_COMMENTS", amazonLogDto.getComments());
        oracleProcedureMapper.insertAmazonLog(input);
        String result = (String) input.get("o_res");
        return result;
    }

    @Override
    public String sendProductShippingToSfc(PostProductShippingToSfcDto toSfcDto) {
        System.out.println("sendProductShippingToSfc request:" + JSONUtil.toJsonStr(toSfcDto));
        HttpResponse response = mesService.shippingPassStation(toSfcDto);
        String body = response.body();
        if (StrUtil.isEmpty(body)) {
            log.error("mes sendSnDnRelationshipToSfc_MES return empty");
        }
        JSONObject mesReturnInfo = JSONUtil.parseObj(body);
        return mesReturnInfo.getStr("msg");
    }

    @Override
    public List<SfcWoUsePkgInfoDto> getSfcWoUsePkgInfo(String startDateTime) {
        Map input = new HashMap();
        input.put("i_date", startDateTime);

        oracleProcedureMapper.getSfcWoUsePkgInfo(input);
        List<SfcWoUsePkgInfoDto> result = (List<SfcWoUsePkgInfoDto>) input.get("o_dataset");

        return result;
    }

    @Override
    public Map getPkgRelation(String pkgId) {
        Map input = new HashMap();
        input.put("i_pkgid", pkgId);
        oracleProcedureMapper.getPdPkgId(input);
        return input;
    }

    @Override
    public SfcWoDto getSfcWoInfo(String sn) {
        MesWoInfoVo mesWoInfoVo = new MesWoInfoVo();
        mesWoInfoVo.setSn(sn);
        HttpResponse response = mesService.getSfcWoInfo(mesWoInfoVo);
        log.info("getSfcWoInfo request:{}, return:{}", JSONUtil.toJsonStr(mesWoInfoVo), response.body());
        String body = response.body();
        if (StrUtil.isEmpty(body)) {
            throw new RuntimeException("call MES getSfcWoInfo return empty");
        }
        JSONObject mesReturnInfo = JSONUtil.parseObj(body);
        int code = mesReturnInfo.getInt("code");
        String msg = mesReturnInfo.getStr("msg");
        if (code != 200) {
            throw new RuntimeException("MES error:" + msg);
        }
        SfcWoDto sfcWoDto = JSON.parseObject(mesReturnInfo.getStr("data"), SfcWoDto.class);
        if (ObjectUtil.isNull(sfcWoDto)) {
            throw new RuntimeException("call MES getSfcWoInfo return data is null");
        }
        return sfcWoDto;
    }

    @Override
    public List<SfcCartonInfoDTO> getSfcPalletInfoByCartonNo(String cartonNo, String orgCode, String plantCode) {
        SfcCartonNoDTO sfcCartonNoDTO = new SfcCartonNoDTO();
        sfcCartonNoDTO.setCartonNo(cartonNo);
        sfcCartonNoDTO.setPlantCode(StrUtil.EMPTY);
        sfcCartonNoDTO.setOrgCode(orgCode);
        HttpResponse httpResponse = mesService.queryPalletInfo(sfcCartonNoDTO);
        String body = httpResponse.body();
        if (StrUtil.isEmpty(body)) {
            System.out.println("mes carton error");
        }
        List<SfcCartonInfoDTO> sfcCartonInfoDTOList = CollUtil.newArrayList();
        if (httpResponse.getStatus() == HttpStatus.HTTP_OK) {
            JSONObject mesReturnInfo = JSONUtil.parseObj(body);
            String code = mesReturnInfo.getStr("code");
            if (StringUtils.isNotBlank(code) && "200".equalsIgnoreCase(code)) {
                sfcCartonInfoDTOList = JSONUtil.toList(JSONUtil.parseArray(mesReturnInfo.get("data")),
                        SfcCartonInfoDTO.class);
            }
        }
        long count = sfcCartonInfoDTOList.stream().filter(ObjectUtil::isNull).count();
        if (count > 0) {
            return CollUtil.newArrayList();
        }
        return sfcCartonInfoDTOList;
    }

    @Override
    public String getSfcErrorDesc(String orgCode, String plantCode, String errorCode) {
        MesErrorDescVo mesErrorDescVo = new MesErrorDescVo();
        mesErrorDescVo.setOrgCode(orgCode);
        mesErrorDescVo.setErrorCode(errorCode);
        HttpResponse httpResponse = mesService.getSfcErrorDesc(mesErrorDescVo);
        String body = httpResponse.body();
        if (StrUtil.isEmpty(body)) {
            System.out.println("call mes getSfcErrorDesc return empty");
        }
        JSONObject mesReturnInfo = JSONUtil.parseObj(body);
        int code = mesReturnInfo.getInt("code");
        String msg = mesReturnInfo.getStr("msg");
        if (code != 200) {
            throw new RuntimeException(msg);
        }
        String data = mesReturnInfo.getStr("data");
        if (StringUtils.isBlank(data)) {
            throw new RuntimeException("call MES getSfcWoInfo return data is null");
        }
        List<MesErrorDescDto> mesErrorDescDto = JSON.parseArray(data, MesErrorDescDto.class);
        return mesErrorDescDto.get(0).getErrorName();
    }

    @Override
    public String getWoNoByPkgId(String orgCode, String plantCode, String pkgId) {
        WoNoByPkgIdVo woNoByPkgIdVo = new WoNoByPkgIdVo();
        woNoByPkgIdVo.setOrgCode(orgCode);
        woNoByPkgIdVo.setSn(pkgId);
        HttpResponse httpResponse = mesService.getWoNoByPkgId(woNoByPkgIdVo);
        String body = httpResponse.body();
        log.info("getWoNoByPkgId request:{},return:{}", JSONUtil.toJsonStr(woNoByPkgIdVo), body);
        if (StrUtil.isEmpty(body)) {
            System.out.println("call mes getSfcErrorDesc return empty");
        }
        JSONObject mesReturnInfo = JSONUtil.parseObj(body);
        int code = mesReturnInfo.getInt("code");
        String msg = mesReturnInfo.getStr("msg");
        if (code != 200) {
            throw new RuntimeException(msg);
        }
        return mesReturnInfo.getStr("data");
    }

    @Override
    public List<SfcBurnValueDto> getSFCBurnValue(String productPartNo) {
        return null;
    }

    @Override
    public List<String> getSFCPkgId(String orgCode, String plantCode, String pkgId) {
        return null;
    }
}

