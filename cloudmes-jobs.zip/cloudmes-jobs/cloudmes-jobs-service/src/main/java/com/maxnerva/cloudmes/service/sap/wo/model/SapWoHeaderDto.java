package com.maxnerva.cloudmes.service.sap.wo.model;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * @Description:
 * @Author: Chao Zhang
 * @Date: 2022/07/12 09:14
 * @Version: 1.0
 */
@Data
public class SapWoHeaderDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 工单
     */
    private String workOrderNo;

    /**
     * WERKS 工厂
     */
    private String plant;

    /**
     * 成品入库仓码
     */
    private String toWarehouseName;

    /**
     * auart 工单类型
     */
    private String workOrderType;

    /**
     * atnr 料号
     */
    private String partNo;

    /**
     * 料号版次
     */
    private String partVersion;

    /**
     * gstrs 计划开始时间
     */
    private LocalDate planStartDate;

    /**
     * 生产数量
     */
    private BigDecimal qty;

    /**
     * 工单状态
     */
    private String status;

    /**
     * 生产线别
     */
    private String lineNo;

    /**
     * 工单制程
     * J00  J01  J02  组装  J03板端
     */
    private String processType;


    private String virtualFlag;
}

