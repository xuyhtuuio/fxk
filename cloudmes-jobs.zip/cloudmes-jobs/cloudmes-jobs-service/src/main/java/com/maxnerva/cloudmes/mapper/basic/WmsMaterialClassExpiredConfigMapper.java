package com.maxnerva.cloudmes.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.basic.WmsMaterialClassExpiredConfig;

public interface WmsMaterialClassExpiredConfigMapper extends BaseMapper<WmsMaterialClassExpiredConfig> {
}
