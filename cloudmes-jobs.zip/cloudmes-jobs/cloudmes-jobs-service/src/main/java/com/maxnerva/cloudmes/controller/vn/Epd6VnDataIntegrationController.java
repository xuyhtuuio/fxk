package com.maxnerva.cloudmes.controller.vn;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.maxnerva.cloudmes.common.response.Result;
import com.maxnerva.cloudmes.entity.R;
import com.maxnerva.cloudmes.entity.datacenter.WmsPostFiiLog;
import com.maxnerva.cloudmes.entity.qms.SyncQmsMsdLevelVO;
import com.maxnerva.cloudmes.entity.qms.SyncQmsValidVO;
import com.maxnerva.cloudmes.service.alarm.IWmsDeclareFilingAlarmRecordService;
import com.maxnerva.cloudmes.service.aps.ApsService;
import com.maxnerva.cloudmes.service.aps.model.ApsRequestVO;
import com.maxnerva.cloudmes.service.basic.PostingConfigService;
import com.maxnerva.cloudmes.service.datacenter.IDataCenterService;
import com.maxnerva.cloudmes.service.doc.DocJitReceiveRecordService;
import com.maxnerva.cloudmes.service.doc.ReceiveDocPostingService;
import com.maxnerva.cloudmes.service.doc.TradingDocService;
import com.maxnerva.cloudmes.service.flownet.FlownetService;
import com.maxnerva.cloudmes.service.wh.IWmsPkgInfoService;
import com.maxnerva.cloudmes.service.wo.WmsWorkOrderPrepareCkdShipService;
import com.maxnerva.cloudmes.service.wo.WorkOrderService;
import com.maxnerva.cloudmes.service.wo.model.CreateCkdPoResultDto;
import com.maxnerva.cloudmes.service.wo.model.JsonStringVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * @ClassName EpdviVnDataIntegrationController
 * @Description EPDVI_VN数据集成调用接口
 * @Author Likun
 * @Date 2023/12/13
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "EPDVI_VN数据集成调用接口")
@Slf4j
@RestController
@RequestMapping("/epd6VnDataIntegration")
public class Epd6VnDataIntegrationController {

    private static final String ORG_CODE = "EPDVI_VN";
    private static final String SAP_CLIENT_CODE = "sapvn";
    private static final String DATE_FORMAT = "yyyyMMdd";
    private static String postDate = "N";

    @Autowired
    ReceiveDocPostingService docPostingService;

    @Autowired
    WorkOrderService workOrderService;

    @Autowired
    private IWmsDeclareFilingAlarmRecordService wmsDeclareFilingAlarmRecordService;

    @Autowired
    private FlownetService flownetService;

    @Autowired
    private ApsService apsService;

    @Autowired
    PostingConfigService postingConfigService;

    @Autowired
    WmsWorkOrderPrepareCkdShipService wmsWorkOrderPrepareCkdShipService;

    @Autowired
    DocJitReceiveRecordService jitDocService;

    @Autowired
    TradingDocService tradingDocService;

    @Resource
    IWmsPkgInfoService wmsPkgInfoService;

    @Autowired
    IDataCenterService dataCenterService;

    /**
     * 修改过账时间
     * 频率：10分钟执行一次
     */
    @ApiOperation("修改过账时间")
    @GetMapping("/updatePostDate")
    public void updatePostDate() {
        String s = postingConfigService.getPostDate(ORG_CODE, null);
        postDate = s;
        log.info(">>>>>>>>>EPDVI_VN过账时间:{}", postDate);
    }

    /**
     * 收货确认并上架完成后，收货单抛QMS
     * 频率：5分钟执行一次
     */
    @ApiOperation("收货确认并上架完成后，收货单抛QMS")
    @GetMapping("/docReceivePostQms")
    public void docReceivePostQms() {
        log.info("docEpd6VnReceivePostQms start :" + System.currentTimeMillis());
        docPostingService.docReceivePostQms(ORG_CODE, null);
        log.info("docEpd6VnReceivePostQms end :" + System.currentTimeMillis());
    }

    /**
     * 收货单据，依据Q的结果判断是否需要转不良品仓
     * 频率：5分钟执行一次
     */
    @ApiOperation("收货单据，依据Q的结果判断是否需要转不良品仓")
    @GetMapping("/docPosting311ToRejectsWarehouse")
    public void docPosting311ToRejectsWarehouse() {
        log.info("docPosting311ToRejectsWarehouse start :" + System.currentTimeMillis());
        docPostingService.docPosting311ToRejectsWarehouse(SAP_CLIENT_CODE, ORG_CODE, "", postDate);
        log.info("docPosting311ToRejectsWarehouse end :" + System.currentTimeMillis());
    }

    /**
     *
     * 从SAP产生JIT收货单
     *
     */
    @ApiOperation("从SAP产生JIT收货单")
    @GetMapping("/syncJitDoc")
    public void syncJitDoc() {
        log.info("syncJitDoc start :" + System.currentTimeMillis());
        String date = DateUtil.format(LocalDateTime.now(), DATE_FORMAT);
        jitDocService.syncJitDoc(SAP_CLIENT_CODE,ORG_CODE,date,date,"");
        log.info("syncJitDoc end :" + System.currentTimeMillis());
    }

    /**
     * 同步SAP workOrder header info,
     * 频率：60分钟执行一次
     */
    @ApiOperation("同步SAP workOrder header info")
    @GetMapping("/syncSapWorkOrderHeader")
    public Result syncSapWorkOrderHeader() {
        log.info("Epd6VnsyncSapWorkOrderHeader start :" + System.currentTimeMillis());
        String startDate = DateUtil.format(LocalDateTime.now().plusDays(-3), DATE_FORMAT);
        String endDate = DateUtil.format(LocalDateTime.now().plusDays(2), DATE_FORMAT);
        workOrderService.syncSapWorkOrderHeader(ORG_CODE, startDate, endDate);
        log.info("Epd6VnsyncSapWorkOrderHeader end :" + System.currentTimeMillis());
        return Result.success();
    }

    /**
     * 同步SAP workOrder detail info,
     * 频率：30分钟执行一次
     */
    @ApiOperation("同步SAP workOrder detail info")
    @GetMapping("/syncSapWorkOrderDetail")
    public void syncSapWorkOrderDetail() {
        log.info("Epd6VnsyncSapWorkOrderDetail " + ORG_CODE + "start :" + System.currentTimeMillis());
        workOrderService.syncSapWorkOrderDetail(ORG_CODE, null, SAP_CLIENT_CODE);
        log.info("Epd6VnsyncSapWorkOrderDetail " + ORG_CODE + "end :" + System.currentTimeMillis());
    }

    /**
     * 同步SFC 上料表和备料方向
     * 频率：30分钟执行一次
     */
    @ApiOperation("同步SFC 上料表和备料方向")
    @GetMapping("/syncBomFeederFromSfc")
    public void syncBomFeederFromSfc() {
        log.info("Epd6VnsyncBomFeederFromSfc start :" + System.currentTimeMillis());
        workOrderService.syncBomFeederFromSfc(ORG_CODE, null);
        log.info("Epd6VnsyncBomFeederFromSfc end :" + System.currentTimeMillis());
    }

    /**
     * 备案预警发邮件
     */
    @ApiOperation("备案预警发邮件")
    @GetMapping("/sendMailBatch")
    public void sendMailBatch(){
        log.info("Epd6VnsendMailBatch start :" + System.currentTimeMillis());
        wmsDeclareFilingAlarmRecordService.sendMailBatch(ORG_CODE);
        log.info("Epd6VnsendMailBatch end :" + System.currentTimeMillis());
    }

    /**
     * 报废入库单过账后抛flownet
     */
    @ApiOperation("报废入库单过账后抛flownet")
    @GetMapping("/postingScrapFlownet")
    public void postingScrapFlownet() {
        log.info("Epd6VnpostingScrapFlownet start :" + System.currentTimeMillis());
        flownetService.postingScrapFlownet(ORG_CODE);
        log.info("Epd6VnpostingScrapFlownet end :" + System.currentTimeMillis());
    }

    @ApiOperation(value = "同步APS信息")
    @PostMapping("/aps")
    public R<Void> syncWorkOrderApsInfo(@RequestBody ApsRequestVO apsRequestVO){
        log.info("Epd6VnsyncWorkOrderApsInfo start :" + System.currentTimeMillis());
        String DATE_FORMAT = "yyyy-MM-dd";
        //获取当前时间
        String startDate = DateUtil.format(LocalDateTime.now().plusDays(-0), DATE_FORMAT);
        //获取当前时间七天后的
        String endDate = DateUtil.format(LocalDateTime.now().plusDays(7), DATE_FORMAT);
        apsRequestVO.setBeginDate(startDate);
        apsRequestVO.setOrgCode(ORG_CODE);
        apsRequestVO.setEndDate(endDate);
        apsService.doGetApsInfolist(apsRequestVO);
        log.info("Epd6VnsyncWorkOrderApsInfo end :" + System.currentTimeMillis());
        return R.ok();
    }

    @ApiOperation("VN创建PO")
    @PostMapping("/vnCreatePo")
    public R<CreateCkdPoResultDto> createPo(@RequestBody JsonStringVO vnCreatePoVO) {
        return wmsWorkOrderPrepareCkdShipService.vnCreatePo(vnCreatePoVO);
    }

    @ApiOperation("VN创建CKD收货单")
    @PostMapping("/saveCkdDocReceive")
    public R<Void> saveCkdDocReceive(@RequestBody JsonStringVO jsonStringVO) {
        return wmsWorkOrderPrepareCkdShipService.saveCkdDocReceive(jsonStringVO);
    }

    /**
     *
     * 根据gr信息产生内交入收货单
     *
     */
    @ApiOperation("根据gr信息产生内交入收货单")
    @GetMapping("/syncTradingDoc")
    public void syncTradingDoc() {
        log.info("syncTradingDoc start :" + System.currentTimeMillis());
//        String startDate = DateUtil.format(LocalDateTime.now().plusDays(-2), DATE_FORMAT);
        String date = DateUtil.format(LocalDateTime.now(), DATE_FORMAT);
        tradingDocService.syncTradingDoc(SAP_CLIENT_CODE,ORG_CODE,date,date);
        log.info("syncTradingDoc end :" + System.currentTimeMillis());
    }

    /**
     * 工单Detail同步单价
     */
    @ApiOperation("工单Detail同步单价")
    @GetMapping("/syncWorkDetailMaterialStandardPrice")
    public R syncWorkDetailMaterialStandardPrice(){
        log.info("{} {}", "开始同步单价", LocalDateTime.now());
        workOrderService.syncWorkDetailMaterialStandardPrice(ORG_CODE, SAP_CLIENT_CODE);
        log.info("{} {}", "结束同步单价", LocalDateTime.now());
        return R.ok();
    }

    @ApiOperation("同步qms有效期")
    @PostMapping("/materialMfgSyncFromQms")
    public R<Void> materialMfgSyncFromQms(@RequestBody List<SyncQmsValidVO> syncQmsValidVOList){
        wmsPkgInfoService.materialMfgSyncFromQms(syncQmsValidVOList);
        return R.ok();
    }

    @ApiOperation("同步qms level等级")
    @PostMapping("/materialMfgLevel")
    public R<Void> materialMfgLevel(@RequestBody List<SyncQmsMsdLevelVO> syncQmsMsdLevelVOList){
        wmsPkgInfoService.materialMfgLevel(syncQmsMsdLevelVOList);
        return R.ok();
    }

    @ApiOperation("抛转FII出货数据")
    @GetMapping("/syncShipInfoForFii")
    public R syncShipInfo(String now){
        log.info("开始抛转FII出货数据 {}", LocalDateTime.now());
        dataCenterService.syncShipInfoForFii(ORG_CODE, StrUtil.isBlank(now) ? LocalDateTime.now() : LocalDateTime.parse(now, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        log.info("结束抛转FII出货数据 {}", LocalDateTime.now());
        return R.ok();
    }

    @ApiOperation("抛转FII库存数据")
    @GetMapping("/syncInventoryForFii")
    public R syncInventoryForFii(){
        log.info("开始抛转FII库存数据 {}", LocalDateTime.now());
        dataCenterService.syncInventoryForFii(ORG_CODE, LocalDateTime.now());
        log.info("结束抛转FII库存数据 {}", LocalDateTime.now());
        return R.ok();
    }

    @ApiOperation("抛转FII-GR数据")
    @GetMapping("/syncGrInfoForFii")
    public R syncGrInfoForFii(String beginDateTime, String endDateTime){
        log.info("开始抛转FII-GR数据 {} {}-{}", LocalDateTime.now(), beginDateTime, endDateTime);
        WmsPostFiiLog wmsPostFiiLog = dataCenterService.syncGrInfoForFii(ORG_CODE, LocalDateTime.now(),
                LocalDateTime.parse(beginDateTime, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")),
                LocalDateTime.parse(endDateTime, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        log.info("结束抛转FII-GR数据 {}", LocalDateTime.now());
        if ("N".equals(wmsPostFiiLog.getStatus())) {
            return R.no();
        }
        return R.ok();
    }
}
