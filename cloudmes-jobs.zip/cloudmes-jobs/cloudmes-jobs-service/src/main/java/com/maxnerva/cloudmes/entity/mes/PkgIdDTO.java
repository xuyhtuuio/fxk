package com.maxnerva.cloudmes.entity.mes;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * <p>
 * 查询PKG信息入参
 * </p>
 *
 * @author hej
 * @since 2023-01-30
 */
@Data
@ApiModel(value = "PkgIdDTO", description = "PkgIdDTO")
public class PkgIdDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    @NotBlank(message = "pkgId不能为空")
    @ApiModelProperty("pkgId")
    private String pkgId;

    @NotBlank(message = "组织代码不能为空")
    @ApiModelProperty("组织代码")
    private String orgCode;

}
