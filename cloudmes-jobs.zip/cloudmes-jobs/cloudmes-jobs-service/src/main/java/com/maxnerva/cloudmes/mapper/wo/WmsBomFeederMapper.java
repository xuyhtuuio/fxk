package com.maxnerva.cloudmes.mapper.wo;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.wo.WmsBomFeeder;
import com.maxnerva.cloudmes.models.newProcess.dto.wo.BomFeederRequiredDTO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 上料表信息 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2022-08-30
 */
public interface WmsBomFeederMapper extends BaseMapper<WmsBomFeeder> {
    List<BomFeederRequiredDTO> getRequiredLsit(@Param("orgCode") String orgCode,
                                               @Param("workOrderNo") String workOrderNo,
                                               @Param("partNoList") List<String> partNoList);
}
