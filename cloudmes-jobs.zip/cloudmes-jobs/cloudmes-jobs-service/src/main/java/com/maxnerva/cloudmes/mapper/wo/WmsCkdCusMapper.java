package com.maxnerva.cloudmes.mapper.wo;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.wo.WmsCkdCus;
import java.math.BigDecimal;
import java.util.List;

public interface WmsCkdCusMapper extends BaseMapper<WmsCkdCus> {
    void insertCkdCusList(List<WmsCkdCus> list);

}
