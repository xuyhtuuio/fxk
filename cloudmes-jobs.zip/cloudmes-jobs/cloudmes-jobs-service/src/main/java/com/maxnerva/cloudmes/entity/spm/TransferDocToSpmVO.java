package com.maxnerva.cloudmes.entity.spm;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName TransferDocToSpmVO
 * @Description TODO
 * @Author Likun
 * @Date 2024/10/12
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("转仓单抛转spm")
@Data
public class TransferDocToSpmVO {

    @ApiModelProperty("转仓单来源单号")
    private String docNo;

    @ApiModelProperty("组织")
    private String orgCode;
}
