package com.maxnerva.cloudmes.mapper.deliver;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.deliver.WmsDocProductShipDetail;

public interface WmsProductShipDetailMapper extends BaseMapper<WmsDocProductShipDetail> {
}
