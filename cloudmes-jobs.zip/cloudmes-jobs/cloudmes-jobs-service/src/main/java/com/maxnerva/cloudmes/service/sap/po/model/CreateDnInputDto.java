package com.maxnerva.cloudmes.service.sap.po.model;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 创建SO、DN入参DTO
 *
 * @author H7109018
 */
@Data
public class CreateDnInputDto implements Serializable {

    private static final long serialVersionUID = -1L;

    /**
     * 创建的单据类型
     * 1：SO; 2:DN; 3:PGI; 4:billing
     * 一次性按顺序创建，不能分开进行
     */
    private String createDocType;

    /**
     * 买方
     */
    private String buyerDeptCode;
    /**
     * 卖方
     */
    private String sellerDeptCode;
    /**
     * 出货点
     * E6T1、 E1T1
     */
    private String shippingPoint;
    /**
     * 销单类型
     * ZBTO：正常出货
     */
    private String salesDocType;

    /**
     * 销售组织
     * CN09
     */
    private String salesOrganization;

    /**
     * 分销渠道
     * 内外销
     * E0 外销
     */
    private String distributionChannel;

    /**
     * 部门
     * E1，E6
     */
    private String division;

    /**
     * 客户PO
     */
    private String customerPO;

    /**
     * Partner Function
     * SP/SH
     */
    private String partnerBuyerFunction;

    /**
     * Customer Number
     */
    private String partnerBuyerFunctionNumber;

    /**
     * Partner Function
     * SP/SH
     */
    private String partnerSellerFunction;

    /**
     * Customer Number
     */
    private String partnerSellerFunctionNumber;

    /**
     * items
     */
    List<CreateDnItemInputDto> items;

}
