package com.maxnerva.cloudmes.entity.pkg;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * <p>
 *
 * </p>
 *
 * @author Chao Zhang
 * @since 2022-12-14
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("wms_pkg_sfc_info")
public class WmsPkgSfcInfoEntity extends Model<WmsPkgSfcInfoEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * ORG_CODE
     */
    @TableField("org_code")
    private String orgCode;

    /**
     * 栈板号
     */
    @TableField("pallet_no")
    private String palletNo;

    /**
     * 箱号
     */
    @TableField("carton_no")
    private String cartonNo;

    /**
     * sn号
     */
    @TableField("sn_no")
    private String snNo;

    /**
     * 数量
     */
    @TableField("qty")
    private BigDecimal qty;

    /**
     * 单位
     */
    @TableField("uom_code")
    private String uomCode;

    /**
     * 工单号
     */
    @TableField("worker_order_no")
    private String workerOrderNo;

    /**
     * 成品料号
     */
    @TableField("part_no")
    private String partNo;

    /**
     * 制作商料号
     */
    @TableField("mfg_part_no")
    private String mfgPartNo;

    /**
     * 生产日期
     */
    @TableField("date_code")
    private String dateCode;

    /**
     * 生产批次
     */
    @TableField("lot_code")
    private String lotCode;

    /**
     * 生产控制 BOARD ASSY
     */
    @TableField("manufacture_type")
    private String manufactureType;

    /**
     * 产品类型 RACK SERVER PCBA
     */
    @TableField("finished_product")
    private String finishedProduct;

    /**
     * 创建人
     */
    @TableField("creator")
    private String creator;

    /**
     * 创建时间
     */
    @TableField("created_dt")
    private LocalDateTime createdDt;

    /**
     * 修改人
     */
    @TableField("last_editor")
    private String lastEditor;

    /**
     * 修改时间
     */
    @TableField("last_edited_dt")
    private LocalDateTime lastEditedDt;

    /**
     * 创建人id
     */
    @TableField("creator_id")
    private Integer creatorId;

    /**
     * 修改人id
     */
    @TableField("last_editor_id")
    private Integer lastEditorId;

    /**
     * mes_sn
     */
    @TableField("assert_id")
    private String assertId;

    @TableField("post_sfc_pass_station_flag")
    private String postSfcPassStationFlag;

    @TableField("post_sfc_message")
    private String postSfcMessage;

    @TableField("post_sfc_datatime")
    private LocalDateTime postSfcDatatime;

    /**
     * 同步SFC扩展信息结果OK表示完成
     */
    @TableField("sync_sfc_extend_info_result")
    private String syncSfcExtendInfoResult;

    /**
     * 机种
     */
    @TableField("sfc_model_name")
    private String sfcModelName;

    /**
     * 版次
     */
    @TableField("sfc_rev")
    private String sfcRev;

    /**
     * 系列
     */
    @TableField("sfc_model_serial")
    private String sfcModelSerial;

    @TableField("sfc_ipn")
    private String sfcIpn;

    @TableField("sfc_assetid")
    private String sfcAssetid;

    @TableField("shipping_to_sfc_flag")
    private String shippingToSfcFlag;

    @TableField("shipping_to_sfc_msg")
    private String shippingToSfcMsg;

    @TableField("shipping_flag")
    private String shippingFlag;

    @TableField("shipping_detail_id")
    private Integer shippingDetailId;

    @TableField("plant_code")
    private String plantCode;

    @ApiModelProperty("入库类型(默认BY_PALLET-栈板入库  BY_CARTON-箱号入库)")
    private String inStorageType;

    @ApiModelProperty("pkg")
    private String pkgId;

    @ApiModelProperty("锁定状态 0--正常；1--已锁定")
    private Integer lockStatus;

    @Override
    public Serializable pkVal() {
        return this.id;
    }

}
