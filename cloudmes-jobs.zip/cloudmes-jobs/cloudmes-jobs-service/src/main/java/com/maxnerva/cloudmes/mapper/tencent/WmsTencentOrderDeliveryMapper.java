package com.maxnerva.cloudmes.mapper.tencent;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.tencent.WmsTencentOrderDelivery;

/**
 * <p>
 * MES腾讯订单配送信息表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2025-05-20
 */
public interface WmsTencentOrderDeliveryMapper extends BaseMapper<WmsTencentOrderDelivery> {

}
