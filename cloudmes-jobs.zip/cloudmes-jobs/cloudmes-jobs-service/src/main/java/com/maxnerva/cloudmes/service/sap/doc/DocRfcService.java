package com.maxnerva.cloudmes.service.sap.doc;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.google.common.collect.Lists;
import com.maxnerva.cloudmes.service.sap.doc.model.BlendIngCusDTO;
import com.maxnerva.cloudmes.service.sap.doc.model.JitReceiptDto;
import com.maxnerva.cloudmes.service.sap.util.SapPoolFactory;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoTable;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author hgx
 * @Date 2023/3/17 16:24
 */
@Slf4j
@Service
public class DocRfcService {
    @Autowired
    SapPoolFactory sapPoolFactory;


    /**
     * 取JIT收货资料
     *
     * @param plant
     * @param fromDate
     * @param EndDate
     * @param receiptNumber
     * @return
     */
    public List<JitReceiptDto> doGetJITReceipt(String sapClient, String plant, String fromDate, String EndDate, String receiptNumber) {

        try {

            JCoDestination pool = sapPoolFactory.getSapPool(sapClient);

            JCoFunction function = pool.getRepository().getFunction("ZRFC_CES_MM_WMS03");
            JCoParameterList inputParams = function.getImportParameterList();
            inputParams.setValue("WERKS", plant);
            inputParams.setValue("PTYPE", "JIT");
            if (!StringUtils.isBlank(receiptNumber)) {
                inputParams.setValue("ASNNO", receiptNumber);
            }

            JCoTable itemTable = function.getTableParameterList().getTable("ASNDATE");
            itemTable.appendRow();
            itemTable.setRow(0);
            itemTable.setValue("SIGN", "I");
            itemTable.setValue("OPTION", "BT");
            itemTable.setValue("LOW", fromDate);
            itemTable.setValue("HIGH", EndDate);

            function.execute(pool);

            JCoParameterList exportlist = function.getExportParameterList();

            JCoTable tabOutTable = function.getTableParameterList().getTable("TAB_OUT");

            if (tabOutTable != null && tabOutTable.getNumRows() > 0) {

                List<JitReceiptDto> results = new ArrayList<>();

                JitReceiptDto jitReceiptDto;

                for (int i = 0, rows = tabOutTable.getNumRows(); i < rows; i++) {
                    tabOutTable.setRow(i);
                    jitReceiptDto = new JitReceiptDto();
                    jitReceiptDto.setPlant(tabOutTable.getString("PLANT"));

                    //JIT
                    jitReceiptDto.setReceiptType(2);

                    jitReceiptDto.setReceiptNumber(tabOutTable.getString("ASNNO"));
                    jitReceiptDto.setReceiptItem("10");

                    jitReceiptDto.setSupplierName(tabOutTable.getString("MANUFACTURER"));
                    jitReceiptDto.setPartNo(tabOutTable.getString("MATNR"));

                    jitReceiptDto.setPoNumber(tabOutTable.getString("EBELN"));
                    jitReceiptDto.setPoItem(tabOutTable.getString("EBELP"));

                    String grNumber = "";
                    //EPD1
                    if (StringUtils.isNotBlank(tabOutTable.getString("REF2"))) {
                        grNumber = grNumber + tabOutTable.getString("REF2");

                    }
                    //EPD5
                    if (StringUtils.isNotBlank(tabOutTable.getString("MBLNR"))) {
                        grNumber = grNumber + tabOutTable.getString("MBLNR");

                    }
                    jitReceiptDto.setQty(new BigDecimal(tabOutTable.getString("ASNQTY")));
                    jitReceiptDto.setUnit(tabOutTable.getString("UOM"));

                    jitReceiptDto.setCustomer(tabOutTable.getString("CUSTOMER"));
                    jitReceiptDto.setVendor(tabOutTable.getString("VENDOR"));
                    jitReceiptDto.setType(tabOutTable.getString("TYPE"));
                    jitReceiptDto.setAsnDate(tabOutTable.getString("ASNDATE"));
                    jitReceiptDto.setDnNo(tabOutTable.getString("DNNO"));
                    jitReceiptDto.setDnItem(tabOutTable.getString("DNITEM"));
                    jitReceiptDto.setCompanyCode(tabOutTable.getString("COMPANYCODE"));

                    results.add(jitReceiptDto);
                }

                return results;

            } else {
                return Lists.newArrayList();
            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new RuntimeException(e.getMessage());
        }
    }

    // 收货单勾兑报关单
    public BlendIngCusDTO doBlendIngDocReceiveCus(String sapClient, String grNumber, String yearStr, String cusNo, String cusItem) throws Exception{
        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);
        log.info("doBlendIngDocReceiveCus grNumber: {}, year: {}, cusNo: {}, cusItem: {}", grNumber,yearStr, cusNo, cusItem);
        JCoFunction function = pool.getRepository().getFunction("ZRFC_CTBS_CFA_AUTO_GRSAVE");
        JCoParameterList inputParams = function.getImportParameterList();
        inputParams.setValue("P_MBLNR", grNumber);
        inputParams.setValue("P_MJAHR", yearStr);
        inputParams.setValue("P_ZEILE", "0001");
        inputParams.setValue("P_BSI011", cusNo);
        inputParams.setValue("P_BSI02", cusItem);
        function.execute(pool);
        JCoTable table = function.getTableParameterList().getTable("MSG");
        BlendIngCusDTO dto = new BlendIngCusDTO();
        for (int i = 0; i < table.getNumRows(); i ++){
            table.setRow(i);
            log.info("doBlendIngDocReceiveCus CODE: {}, MESSAGE {}", table.getString("CODE"), table.getString("MESSAGE"));
            dto.setCode(table.getString("CODE"));
            dto.setMsg(table.getString("MESSAGE"));
        }
        return dto;
    }

    // VMI勾兑报关单
    public BlendIngCusDTO doBlendIngJusdaVmiCus(String sapClient, String grNumber, String yearStr, String cusNo, String cusItem)throws Exception{
        JCoDestination pool = sapPoolFactory.getSapPool(sapClient);
        log.info("doBlendIngJusdaVmiCus grNumber: {}, year: {}, cusNo: {}, cusItem: {}", grNumber,yearStr, cusNo, cusItem);
        JCoFunction function = pool.getRepository().getFunction("ZRFC_CTBS_CFA_AUTO_GRSAVE_VMI");
        JCoParameterList inputParams = function.getImportParameterList();
        inputParams.setValue("P_MBLNR", grNumber);
        inputParams.setValue("P_MJAHR", yearStr);
        inputParams.setValue("P_ZEILE", "0001");
        inputParams.setValue("P_BSI011", cusNo);
        inputParams.setValue("P_BSI02", cusItem);
        function.execute(pool);
        JCoTable table = function.getTableParameterList().getTable("MSG");
        BlendIngCusDTO dto = new BlendIngCusDTO();
        for (int i = 0; i < table.getNumRows(); i ++){
            table.setRow(i);
            log.info("doBlendIngJusdaVmiCus CODE: {}, MESSAGE {}", table.getString("CODE"), table.getString("MESSAGE"));
            dto.setCode(table.getString("CODE"));
            dto.setMsg(table.getString("MESSAGE"));
        }
        return dto;
    }
}
