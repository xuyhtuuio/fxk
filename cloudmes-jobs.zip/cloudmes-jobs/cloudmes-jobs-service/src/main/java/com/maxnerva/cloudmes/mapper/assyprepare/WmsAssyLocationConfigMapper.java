package com.maxnerva.cloudmes.mapper.assyprepare;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.assyprepare.WmsAssyLocationConfig;

/**
 * <p>
 * 机构段上料表导入信息表 Mapper 接口
 * </p>
 *
 * @author likun
 * @since 2024-04-30
 */
public interface WmsAssyLocationConfigMapper extends BaseMapper<WmsAssyLocationConfig> {

}
