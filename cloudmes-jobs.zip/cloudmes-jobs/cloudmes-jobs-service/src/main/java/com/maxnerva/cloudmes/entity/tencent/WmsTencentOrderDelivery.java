package com.maxnerva.cloudmes.entity.tencent;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * MES腾讯订单配送信息表
 * </p>
 *
 * @author likun
 * @since 2025-05-20
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsTencentOrderDelivery对象", description="MES腾讯订单配送信息表")
public class WmsTencentOrderDelivery extends BaseEntity<WmsTencentOrderDelivery> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键")
    private Integer id;

    @ApiModelProperty(value = "订货单产生时间")
    private String createTime;

    @ApiModelProperty(value = "供应商国别")
    private String country;

    @ApiModelProperty(value = "订货单编码（唯一）")
    private String poNumber;

    @ApiModelProperty(value = "订货单明细 ID")
    private String detailId;

    @ApiModelProperty(value = "订货单（BO）明细 ID")
    private String boDetailId;

    @ApiModelProperty(value = "采购明细 ID")
    private String formItemId;

    @ApiModelProperty(value = "需求单号")
    private String prNumber;

    @ApiModelProperty(value = "订货单号")
    private String boNumber;

    @ApiModelProperty(value = "bo 单反馈的日期")
    private String estDeliveryDate;

    @ApiModelProperty(value = "备注")
    private String memo;

    @ApiModelProperty(value = "SN 码")
    private String snCode;

    @ApiModelProperty(value = "物料编码")
    private String matiCode;

    @ApiModelProperty(value = "物料名称")
    private String matiName;

    @ApiModelProperty(value = "资产编码，BOPO 解绑前下的订单有值，解绑后下的订单不再有值")
    private String assetCode;

    @ApiModelProperty(value = "腾讯机型")
    private String modelName;

    @ApiModelProperty(value = "版本")
    private String version;

    @ApiModelProperty(value = "BO 单的物料编码")
    private String boMatiCode;

    @ApiModelProperty(value = "BO 单的物料名称")
    private String boMatiName;

    @ApiModelProperty(value = "数量")
    private Integer quantity;

    @ApiModelProperty(value = "期望的配送日期")
    private String deliveryDate;

    @ApiModelProperty(value = "业务期望的配送日期")
    private String businessDeliveryDate;

    @ApiModelProperty(value = "配送地址")
    private String address;

    @ApiModelProperty(value = "配送仓库")
    private String deliveryStorage;

    @ApiModelProperty(value = "机架名称")
    private String positionName;

    @ApiModelProperty(value = "机位名称")
    private String subPositionName;

    @ApiModelProperty(value = "Raid 类型")
    private String raidName;

    @ApiModelProperty(value = "配置说明(bios)")
    private String configDesc;

    @ApiModelProperty(value = "预留字段")
    private String conf1;

    @ApiModelProperty(value = "预留字段")
    private String conf2;

    @ApiModelProperty(value = "预留字段")
    private String conf3;

    @ApiModelProperty(value = "预留字段")
    private String conf4;

    @ApiModelProperty(value = "预留字段")
    private String conf5;

    @ApiModelProperty(value = "下单主体")
    private String ouName;

    @ApiModelProperty(value = "订单类型：自用、转售")
    private String poType;

    @ApiModelProperty(value = "机位启用时间")
    private String posEnableTime;

    @ApiModelProperty(value = "服务器、多节点-机框")
    private String nodeType;

    @ApiModelProperty(value = "报表类型，固定值: ODM/OEM")
    private String reportType;

    @ApiModelProperty(value = "组织编码")
    private String orgCode;

    @ApiModelProperty(value = "0：有效，1：删除")
    private Boolean isDeleted;

    @ApiModelProperty(value = "删除时间")
    private Long deletedDt;

    @ApiModelProperty(value = "地址编码")
    private String addressCode;
}
