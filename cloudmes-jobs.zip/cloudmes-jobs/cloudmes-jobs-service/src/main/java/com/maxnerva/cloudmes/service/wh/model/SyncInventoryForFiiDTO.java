package com.maxnerva.cloudmes.service.wh.model;

import cn.hutool.core.annotation.Alias;
import cn.hutool.core.annotation.PropIgnore;
import cn.hutool.core.util.StrUtil;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class SyncInventoryForFiiDTO {

    @ApiModelProperty(value = "厂区")
    private String site;

    @ApiModelProperty(value = "BU")
    @Alias(value = "business_unit_name")
    private String orgCode;

    @ApiModelProperty(value = "客户")
    @Alias(value = "mrp_area")
    private String mrpArea;

    @ApiModelProperty(value = "sap仓码")
    @Alias(value = "sap_warehouse_code")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "料号")
    @Alias(value = "hhpn")
    private String partNo;

    @ApiModelProperty(value = "厂商料号")
    @Alias(value = "mfg_pn")
    private String supplierPartNo;

    @ApiModelProperty(value = "制造商名称")
    @Alias(value = "mfg_name")
    private String mfgName;

    @ApiModelProperty(value = "工厂编码")
    @Alias(value = "plant_code")
    private String plantCode;

    @ApiModelProperty(value = "数量")
    @PropIgnore
    private BigDecimal currentQty = BigDecimal.ZERO;

    @ApiModelProperty(value = "抛转数量（转String）")
    private String qty;

    public String getQty(){
        return StrUtil.emptyIfNull(currentQty.stripTrailingZeros().toPlainString());
    }

    @ApiModelProperty(value = "单位")
    private String unit;

    @ApiModelProperty(value = "是否成品")
    @PropIgnore
    private Boolean productFlag;

    @ApiModelProperty(value = "是否成品 MATERIAL或GOODS")
    @Alias(value = "material_type")
    private String materialType;

    @ApiModelProperty(value = "数据来源")
    @Alias(value = "data_source")
    private String dataSource;

    @ApiModelProperty("最近一次维护人")
    @Alias(value = "last_edit_by")
    private String lastEditBy;

    @ApiModelProperty("最近一次维护时间")
    @Alias(value = "last_edit_dt")
    private LocalDateTime lastEditDt;

    @ApiModelProperty("最近一次维护时间 0时区")
    @Alias(value = "last_edit_dt_utc")
    private LocalDateTime lastEditDtUtc;

    @ApiModelProperty("时区 utc+8 填8 utc-1 填-1")
    @Alias(value = "utc_zone")
    private String utcZone;

    @ApiModelProperty(value = "写入资料系统")
    @Alias(value = "add_user")
    private String addUser;

    @ApiModelProperty(value = "写入资料时间")
    @Alias(value = "add_date")
    private LocalDateTime addDate;

    @ApiModelProperty(value = "写入资料时间UTC+0")
    @Alias(value = "add_date_utc")
    private LocalDateTime addDateUtc;

    @ApiModelProperty(value = "新增/刪除(N/D)")
    @Alias(value = "data_status")
    private String dataStatus;

    public String getMrpArea() {
        return StrUtil.emptyIfNull(mrpArea);
    }

    public String getSapWarehouseCode() {
        return StrUtil.emptyIfNull(sapWarehouseCode);
    }

    public String getPartNo() {
        return StrUtil.emptyIfNull(partNo);
    }

    public String getSupplierPartNo() {
        return StrUtil.emptyIfNull(supplierPartNo);
    }

    public String getMfgName() {
        return StrUtil.emptyIfNull(mfgName);
    }

    public String getMaterialType() {
        return StrUtil.emptyIfNull(materialType);
    }

    public String getLastEditBy() {
        return StrUtil.emptyIfNull(lastEditBy);
    }

    public String getDataSource() {
        return StrUtil.emptyIfNull(dataSource);
    }
}
