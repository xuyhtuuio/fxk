package com.maxnerva.cloudmes.mapper.deliver;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.maxnerva.cloudmes.entity.deliver.WmsDeliver;

/**
 * @author sclq
 * @date 2022/9/8 16:48
 */
public interface WmsDeliverMapper extends BaseMapper<WmsDeliver> {


}
