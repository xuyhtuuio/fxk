package com.maxnerva.cloudmes.service.sfc.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Author hgx
 * @Description
 * @Date 2023/6/6
 */
@Data
public class SfcWoDto {

    @ApiModelProperty("鸿海料号")
    private String hhPn;

    @ApiModelProperty("工单号")
    private String moNumber;

    private String vendorSn;

    @ApiModelProperty("物料类型")
    private String keyPartType;

    private String serialNumber;

    @ApiModelProperty("不良代码")
    private String testCode;

    @ApiModelProperty("不良原因")
    private String errorDesc;

    @ApiModelProperty("sfcPkgId")
    private String pkgId;
    
    private String unlinkTime;
}
