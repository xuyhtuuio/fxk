package com.maxnerva.cloudmes.service.wo.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderDetail;
import com.maxnerva.cloudmes.mapper.wo.WmsWorkOrderDetailMapper;
import com.maxnerva.cloudmes.service.wo.IWmsWorkOrderDetailService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 工单detail信息表 服务实现类
 * </p>
 *
 * @author likun
 * @since 2022-08-30
 */
@Service
public class WmsWorkOrderDetailServiceImpl extends ServiceImpl<WmsWorkOrderDetailMapper, WmsWorkOrderDetail>
        implements IWmsWorkOrderDetailService {

}
