package com.maxnerva.cloudmes.entity.prepare.outsourcing;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * <p>
 * 委外退料记录表
 * </p>
 *
 * @author likun
 * @since 2025-07-02
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsOutsourcingMaterialReturnLog对象", description="委外退料记录表")
public class WmsOutsourcingMaterialReturnLog extends BaseEntity<WmsOutsourcingMaterialReturnLog> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "条码")
    private String pkgId;

    @ApiModelProperty(value = "父条码(旧条码)")
    private String parentPkgId;

    @ApiModelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "数量")
    private BigDecimal qty;

    @ApiModelProperty(value = "批次号")
    private String lotNo;

    @ApiModelProperty(value = "原始D/C")
    private String originalDateCode;

    @ApiModelProperty(value = "D/C")
    private LocalDate dateCode;

    @ApiModelProperty(value = "制造商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "载具编码")
    private String vehicleCode;

    @ApiModelProperty(value = "储位编码")
    private String binCode;

    @ApiModelProperty(value = "po")
    private String poNo;

    @ApiModelProperty(value = "po项次")
    private String poItem;

    @ApiModelProperty(value = "退料标识")
    private String returnFlag;

    @ApiModelProperty(value = "退料类型")
    private String returnType;

    @ApiModelProperty(value = "制造商名称")
    private String mfgName;

    @ApiModelProperty(value = "工厂编码")
    private String plantCode;

    @ApiModelProperty(value = "供应商料号")
    private String supplierPartNo;

    @ApiModelProperty(value = "鸿海料号版次")
    private String partVersion;
}
