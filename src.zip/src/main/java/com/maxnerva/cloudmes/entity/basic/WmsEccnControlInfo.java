package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.TableId;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value = "WmsEccnControlInfo对象", description = "ECCN調查物料管控清單")
public class WmsEccnControlInfo extends BaseEntity<WmsEccnControlInfo> {
    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    @TableId
    private Integer id;

    @ApiModelProperty(value = "ECCN号")
    private String eccnNo;

    @ApiModelProperty(value = "是否删除")
    private Boolean isDeleted;
}
