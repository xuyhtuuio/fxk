package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * SWR单头
 * </p>
 *
 * @author baomidou
 * @since 2025-04-08
 */
@EqualsAndHashCode(callSuper = true)
@TableName("wms_doc_swr_log_header")
@ApiModel(value = "WmsDocSwrLogHeader对象", description = "SWR单头")
@Data
public class WmsDocSwrLogHeader extends BaseEntity<WmsDocSwrLogHeader> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("工厂")
    private String plantCode;

    @ApiModelProperty("单号")
    private String docNo;

    @ApiModelProperty("抛Agile实际单号")
    private String actualDocNo;

    @ApiModelProperty("0 新建，2已发送，1，已回写完成，3抛转失败，4抛转中,5拒签")
    private String identify;

    @ApiModelProperty("物控")
    private String originator;

    @ApiModelProperty("有效期限")
    private LocalDateTime expirationDate;

    @ApiModelProperty("机种名")
    private String finishPartNo;

    @ApiModelProperty("料号")
    private String partNo;

    @ApiModelProperty("客户")
    private String customer;

    @ApiModelProperty("数量")
    private BigDecimal qty;

    @ApiModelProperty("N签核，Y免签")
    private String mark;

    @ApiModelProperty("抛转信息")
    private String postMessage;

    @ApiModelProperty("接口返回报错")
    private String postReturnMessage;

    @ApiModelProperty("抛转时间")
    private LocalDateTime postDt;

    @ApiModelProperty("回写信息")
    private String replyMessage;

    @ApiModelProperty("回写时间")
    private LocalDateTime replyDt;

    @ApiModelProperty("拒签原因")
    private String reason;

    @ApiModelProperty("附件名")
    private String fileName;

    @ApiModelProperty("附件地址")
    private String fileUrl;

    @ApiModelProperty("工单")
    private String workOrderNo;

    @ApiModelProperty("物料描述")
    private String materialDesc;
}
