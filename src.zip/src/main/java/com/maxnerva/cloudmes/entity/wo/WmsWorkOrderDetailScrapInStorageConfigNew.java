package com.maxnerva.cloudmes.entity.wo;

import com.maxnerva.cloudmes.entity.BaseEntity;
import lombok.Data;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * (WmsWorkOrderDetailScrapInStorageConfigNew)实体类
 *
 * @author hgx
 * @since 2023-08-17
 */
@Data
@ApiModel("WmsWorkOrderDetailScrapInStorageConfigNew实体类")
public class WmsWorkOrderDetailScrapInStorageConfigNew extends BaseEntity<WmsWorkOrderDetailScrapInStorageConfigNew> {

    
    @ApiModelProperty("id")
    private Integer id;

    @ApiModelProperty("组织")
    private String orgCode;
    
    @ApiModelProperty("报废类型")
    private String scrapTrype;
    
    @ApiModelProperty("报废描述")
    private String scrapDesc;
    
    @ApiModelProperty("工厂")
    private String plantCode;
    /**
     * 工单仓码
     */
    @ApiModelProperty("工单仓码")
    private String fromWarehouseCode;
    /**
     * 目的仓码
     */
    @ApiModelProperty("目的仓码")
    private String toWarehouseCode;
}

