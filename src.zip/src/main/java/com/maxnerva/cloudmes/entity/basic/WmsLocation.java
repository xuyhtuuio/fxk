package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.TableId;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 库位表
 * </p>
 *
 * @author likun
 * @since 2022-07-22
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsLocation对象", description="库位表")
public class WmsLocation extends BaseEntity<WmsLocation> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    @TableId
    private Integer id;

    @ApiModelProperty(value = "BU(业务单元)")
    private String orgCode;

    @ApiModelProperty(value = "关联库区表(wms_area)主键id")
    private Integer wmsAreaId;

    @ApiModelProperty(value = "库区编码")
    private String areaCode;

    @ApiModelProperty(value = "库位编码")
    private String locationCode;

    @ApiModelProperty(value = "库位名称")
    private String locationName;

    @ApiModelProperty(value = "sap仓码,多个用逗号隔开，默认ALL")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "库位坐标")
    private String locationMark;

    @ApiModelProperty(value = "是否计入wms库存(false-否 true-是)，默认false")
    private Boolean isWmsInventory;

    @ApiModelProperty(value = "库位类型(R-实体，V-虚拟)")
    private String locationType;
}
