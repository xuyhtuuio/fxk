package com.maxnerva.cloudmes.entity.warehouse;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import com.maxnerva.cloudmes.entity.BaseEntity;
import lombok.Data;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * (WmsPkgidLcrLog)实体类
 *
 * @author hgx
 * @since 2023-07-10
 */
@Data
@ApiModel("WmsPkgidLcrLog实体类")
public class WmsPkgidLcrLog extends BaseEntity<WmsPkgidLcrLog> {

    
    @ApiModelProperty("id")
    private Long id;
    
    @ApiModelProperty("pkgId")
    private String pkgId;
    
    @ApiModelProperty("制造商名称")
    private String mfgName;

    @ApiModelProperty("制造商料号")
    private String mfgPartNo;
    
    @ApiModelProperty("检验结果")
    private String checkResult;
    
    @ApiModelProperty("检验时间")
    private LocalDateTime checkTime;
    
    @ApiModelProperty("检验值")
    private BigDecimal checkValue;

    @ApiModelProperty("检验结果信息")
    private String checkMsg;
    
    @ApiModelProperty("测量单位")
    private String uomCode;
    
    @ApiModelProperty("plantCode")
    private String plantCode;
    
    @ApiModelProperty("orgCode")
    private String orgCode;

    @ApiModelProperty("qms标准值返回结果")
    private String qmsReturnResult;

    /**
     * qms-lcr上限
     */
    @ApiModelProperty("qms-lcr上限")
    private BigDecimal qmsLcrTop;
    /**
     * qms-lcr下限
     */
    @ApiModelProperty("qms-lcr下限")
    private BigDecimal qmsLcrLow;

    @ApiModelProperty(value = "锁定状态")
    private String lockStatus;

    @ApiModelProperty(value = "锁定时间")
    private LocalDateTime lockDt;

    @ApiModelProperty(value = "测值次数")
    private Integer lcrTimes;
}

