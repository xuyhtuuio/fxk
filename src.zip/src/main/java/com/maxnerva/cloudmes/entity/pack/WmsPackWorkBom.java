package com.maxnerva.cloudmes.entity.pack;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

/**
 * <p>
 * 包材BOM明细
 * </p>
 *
 * @author likun
 * @since 2024-12-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsPackWorkBom对象", description="包材BOM明细")
public class WmsPackWorkBom extends BaseEntity<WmsPackWorkBom> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "工单群组(项次)")
    private String workOrderItem;

    @ApiModelProperty(value = "仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "料号版次")
    private String partVersion;

    @ApiModelProperty(value = "需求量")
    private BigDecimal requiredQuantity;

    @ApiModelProperty(value = "已发量")
    private BigDecimal issuedQty;

    @ApiModelProperty(value = "单位")
    private String uomCode;

    @ApiModelProperty(value = "成本中心")
    private String costCenter;

    @ApiModelProperty(value = "异动类型")
    private String moveType;

    @ApiModelProperty(value = "异动原因")
    private String reasonCode;

    @ApiModelProperty(value = "专案名称")
    private String itemText;

    @ApiModelProperty(value = "用量")
    private BigDecimal usage;
}
