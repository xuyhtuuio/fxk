package com.maxnerva.cloudmes.entity.doc;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@ApiModel("flownet回调记录")
@Data
public class WmsCostFlownetRequestLog extends BaseEntity<WmsCostFlownetRequestLog> {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "请求json")
    private String requestJson;

    @ApiModelProperty(value = "返回json")
    private String responseJson;
}
