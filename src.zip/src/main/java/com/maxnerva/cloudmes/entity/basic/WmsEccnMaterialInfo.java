package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDate;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * ECCN調查物料清單
 * </p>
 *
 * @author baomidou
 * @since 2024-01-08
 */
@ApiModel(value = "WmsEccnMaterialInfo对象", description = "ECCN調查物料清單")
@Data
public class WmsEccnMaterialInfo extends BaseEntity<WmsEccnMaterialInfo> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    @TableId
    private Integer id;

    private String mfgPartNo;

    @ApiModelProperty("料号描述")
    private String mfgPartDesc;

    @ApiModelProperty("制造商名称")
    private String mfgName;

    private String eccnNo;

    @ApiModelProperty("来源")
    private String eccnFrom;

    @ApiModelProperty("licence号")
    private String licenceNo;

    @ApiModelProperty("licence描述")
    private String licenceDesc;

    @ApiModelProperty("linence来源")
    private String linenceFrom;

    @ApiModelProperty("开始时间")
    private LocalDate licenceBeginDt;

    @ApiModelProperty("结束时间")
    private LocalDate licenceEndDt;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty(value = "鸿海料号 部分BU启用")
    private String partNo;

    @ApiModelProperty(value = "許可證簽發國")
    private String licenseSignCountry;
}
