package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 报废处理单税务信息
 * </p>
 *
 * @author baomidou
 * @since 2024-11-14
 */
@TableName("wms_scrap_handle_tax")
@ApiModel(value = "WmsScrapHandleTax对象", description = "报废处理单税务信息")
@Data
public class WmsScrapHandleTax extends BaseEntity<WmsScrapHandleTax> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("工厂")
    private String plantCode;

    @ApiModelProperty("单号")
    private String docNo;

    @ApiModelProperty("报废品分类 RAW原物料，SEMI半成品，PROD成品")
    private String type;

    @ApiModelProperty("关税")
    private BigDecimal customsTax;

    @ApiModelProperty("增值税")
    private BigDecimal valueAddedTax;
}
