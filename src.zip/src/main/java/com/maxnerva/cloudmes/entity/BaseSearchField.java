package com.maxnerva.cloudmes.entity;

import lombok.Data;

@Data
public class BaseSearchField {
	private String name;
	private String searchType;
	private String val;
	private String val1;
}
