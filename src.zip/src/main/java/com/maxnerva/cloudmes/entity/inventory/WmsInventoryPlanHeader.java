package com.maxnerva.cloudmes.entity.inventory;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 盘点计划单头
 * </p>
 *
 * @author likun
 * @since 2023-03-25
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value = "WmsInventoryPlanHeader对象", description = "盘点计划单头")
public class WmsInventoryPlanHeader extends BaseEntity<WmsInventoryPlanHeader> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "盘点计划编号")
    private String inventoryPlanNo;

    @ApiModelProperty(value = "描述")
    private String description;

    @ApiModelProperty(value = "盘点状态")
    private String inventoryStatus;

    @ApiModelProperty(value = "盘点人员工编号")
    private String inventoryExecutorCode;

    @ApiModelProperty(value = "盘点人名称")
    private String inventoryExecutorName;

    @ApiModelProperty(value = "盘点范围")
    private String inventoryRange;

    @ApiModelProperty(value = "盘点类型")
    private String inventoryType;

    @ApiModelProperty(value = "载具位置")
    private String vehiclePlace;

    @ApiModelProperty(value = "载具编码")
    private String vehicleCode;
}
