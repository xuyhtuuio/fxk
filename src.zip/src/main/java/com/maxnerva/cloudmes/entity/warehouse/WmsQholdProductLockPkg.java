package com.maxnerva.cloudmes.entity.warehouse;

import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import lombok.Data;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 成品QHOLD锁料pkg(WmsQholdProductLockPkg)实体类
 *
 * @author hgx
 * @since 2023-09-26
 */
@Data
@ApiModel("WmsQholdProductLockPkg实体类")
public class WmsQholdProductLockPkg extends BaseEntity<WmsQholdProductLockPkg> {


    @ApiModelProperty("id")
    private Integer id;
    /**
     * qhold单号
     */
    @ApiModelProperty("qhold单号")
    private String qholdNo;
    /**
     * 产品料号
     */
    @ApiModelProperty("产品料号")
    private String partNo;

    /**
     * 箱号
     */
    @ApiModelProperty("箱号")
    private String cartonNo;

    @ApiModelProperty("锁定原因")
    private String lockMsg;

    @ApiModelProperty("orgCode")
    private String orgCode;

    @ApiModelProperty("状态（1:锁定，2:解锁）")
    private String status;

    @ApiModelProperty("解锁时间")
    private LocalDateTime unlockDate;

    @ApiModelProperty("锁定时间")
    private LocalDateTime lockDate;

    @ApiModelProperty("良品：Y，不良品：N")
    private String type;

    @ApiModelProperty("解锁的qhold单号")
    private String unlockQholdNo;
}

