package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * SWR沾锡验证单详情
 * </p>
 *
 * @author baomidou
 * @since 2025-03-29
 */
@EqualsAndHashCode(callSuper = true)
@TableName("wms_doc_swr_detail")
@ApiModel(value = "WmsDocSwrDetail对象", description = "SWR沾锡验证单详情")
@Data
public class WmsDocSwrDetail extends BaseEntity<WmsDocSwrDetail> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("工厂")
    private String plantCode;

    @ApiModelProperty("仓码")
    private String warehouseCode;

    @ApiModelProperty("单号")
    private String docNo;

    @ApiModelProperty("条码号")
    private String pkgId;

    @ApiModelProperty("父条码")
    private String parentPkgId;

    @ApiModelProperty("鸿海料号")
    private String partNo;

    @ApiModelProperty("厂商料号")
    private String supplierPartNo;

    @ApiModelProperty("厂商")
    private String mfgName;

    @ApiModelProperty("原始DC")
    private String originalDateCode;

    @ApiModelProperty("LOT")
    private String lotCode;

    @ApiModelProperty("GR单号")
    private String grNo;

    @ApiModelProperty("WMS收货单号")
    private String wmsNo;

    @ApiModelProperty("数量")
    private BigDecimal qty;

    @ApiModelProperty("到期日")
    private LocalDate endDate;

    @ApiModelProperty("物料描述")
    private String materialDesc;

    @ApiModelProperty("物料分类")
    private String classCode;

    @ApiModelProperty("是否MSD物料N,Y")
    private String msdFlag;

    @ApiModelProperty("是否烘烤 N,Y")
    private String bakeFlag;

    @ApiModelProperty("是否取料 N,Y")
    private String pickFlag;

    @ApiModelProperty("是否返仓N,Y")
    private String returnFlag;

    @ApiModelProperty(value = "载具")
    private String vehicleCode;

    @ApiModelProperty(value = "储位")
    private String binCode;

    @ApiModelProperty("同步msd标识")
    private Integer postMsdFlag;

    @ApiModelProperty("同步msd信息描述")
    private String postMsdMsg;

    @ApiModelProperty("同步msd时间")
    private LocalDateTime postMsdDateTime;
}
