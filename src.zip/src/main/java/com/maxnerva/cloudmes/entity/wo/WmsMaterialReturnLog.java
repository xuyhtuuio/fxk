package com.maxnerva.cloudmes.entity.wo;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>
 * 退料记录表
 * </p>
 *
 * @author likun
 * @since 2023-02-09
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsMaterialReturnLog对象", description="退料记录表")
public class WmsMaterialReturnLog extends BaseEntity<WmsMaterialReturnLog> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "条码")
    private String pkgId;

    @ApiModelProperty(value = "父条码(旧条码)")
    private String parentPkgId;

    @ApiModelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "数量")
    private BigDecimal qty;

    @ApiModelProperty(value = "批次号")
    private String lotNo;

    @ApiModelProperty(value = "原始D/C")
    private String originalDateCode;

    @ApiModelProperty(value = "D/C")
    private LocalDate dateCode;

    @ApiModelProperty(value = "制造商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "载具编码")
    private String vehicleCode;

    @ApiModelProperty(value = "储位编码")
    private String binCode;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "工单群组")
    private String workOrderItem;

    @ApiModelProperty(value = "退料标识")
    private String returnFlag;

    @ApiModelProperty(value = "退料类型")
    private String returnType;

    @ApiModelProperty(value = "macNum")
    private String macNum;

    @ApiModelProperty(value = "macUser")
    private String macUser;

    @ApiModelProperty(value = "制造商名称")
    private String mfgName;

    @ApiModelProperty(value = "工厂编码")
    private String plantCode;

    @ApiModelProperty(value = "sap料号")
    private String supplierPartNo;

    @ApiModelProperty("料号版次")
    private String partVersion;

    @ApiModelProperty("锁料单号")
    private String lockDocNo;

    @ApiModelProperty(value = "锁定状态")
    private String lockStatus;

    @ApiModelProperty(value = "锁定时间")
    private LocalDateTime lockDate;

    @ApiModelProperty(value = "lock原因")
    private String lockMessage;
}
