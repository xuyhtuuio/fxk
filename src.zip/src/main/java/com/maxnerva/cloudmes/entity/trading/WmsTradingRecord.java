package com.maxnerva.cloudmes.entity.trading;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 内交单据表
 * @TableName wms_trading_record
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class WmsTradingRecord extends BaseEntity<WmsTradingRecord> {
    /**
     * 主键id
     */
    @ApiModelProperty(value = "主键id")
    private Integer id;

    /**
     * 内交单号
     */
    @ApiModelProperty(value = "内交单号")
    private String tradingNumber;

    /**
     * 内交出BU
     */
    @ApiModelProperty(value = "内交出BU")
    private String fromOrgCode;

    /**
     * 内交出工厂
     */
    @ApiModelProperty(value = "内交出工厂")
    private String fromPlantCode;

    /**
     * 鸿海料号
     */
    @ApiModelProperty(value = "鸿海料号")
    private String partNo;

    /**
     * 鸿海料号版次
     */
    @ApiModelProperty(value = "鸿海料号版次")
    private String partVersion;

    /**
     * 内交出数量
     */
    @ApiModelProperty(value = "内交出数量")
    private BigDecimal tradingQty;

    /**
     * 内交入数量
     */
    @ApiModelProperty(value = "内交入数量")
    private BigDecimal confirmQty;

    /**
     * 单位
     */
    @ApiModelProperty(value = "单位")
    private String uomCode;

    /**
     * 转出仓码
     */
    @ApiModelProperty(value = "转出仓码")
    private String fromWarehouseCode;

    /**
     * 内交类型
     */
    @ApiModelProperty(value = "内交类型")
    private String tradingType;

    /**
     * 配銷通路
     */
    @ApiModelProperty(value = "配銷通路")
    private String salesChain;

    /**
     * 产品部
     */
    @ApiModelProperty(value = "产品部")
    private String productDepartment;

    /**
     * 内交入bu
     */
    @ApiModelProperty(value = "内交入bu")
    private String toOrgCode;

    /**
     * 内交出代码
     */
    @ApiModelProperty(value = "内交出代码")
    private String tradingFromCode;

    /**
     * 内交入代码
     */
    @ApiModelProperty(value = "内交入代码")
    private String tradingToCode;

    /**
     * 内交入工厂
     */
    @ApiModelProperty(value = "内交入工厂")
    private String toPlantCode;

    /**
     * 内交入料号
     */
    @ApiModelProperty(value = "内交入料号")
    private String toPartNo;

    /**
     * 内交入版次
     */
    @ApiModelProperty(value = "内交入版次")
    private String toPartVersion;

    /**
     * 内交入仓码;
     */
    @ApiModelProperty(value = "内交入仓码")
    private String toWarehouseCode;

    /**
     * 内交标识，内交出过账sap用
     */
    @ApiModelProperty(value = "内交标识，内交出过账sap用")
    private Integer tradingFlag;

    /**
     * 内交信息，内交出过账sap用
     */
    @ApiModelProperty(value = "内交信息，内交出过账sap用")
    private String tradingMsg;

    /**
     * 内交日期，内交出过账sap用
     */
    @ApiModelProperty(value = "内交日期，内交出过账sap用")
    private LocalDateTime tradingDate;

    /**
     * 内交人，内交出过账sap用
     */
    @ApiModelProperty(value = "内交人，内交出过账sap用")
    private String tradingBy;

    /**
     * pgi标识，内交出过账sap用
     */
    @ApiModelProperty(value = "pgi标识，内交出过账sap用")
    private Integer pgiFlag;

    /**
     * pgi信息，内交出过账sap用
     */
    @ApiModelProperty(value = "pgi信息，内交出过账sap用")
    private String pgiMsg;

    /**
     * pgi日期，内交出过账sap用
     */
    @ApiModelProperty(value = "pgi日期，内交出过账sap用")
    private LocalDateTime pgiDate;

    /**
     * pgi人，内交出过账sap用
     */
    @ApiModelProperty(value = "pgi人，内交出过账sap用")
    private String pgiBy;

    /**
     * gr标识，内交入过账sap用
     */
    @ApiModelProperty(value = "gr标识，内交入过账sap用")
    private Object grFlag;

    /**
     * gr工厂，内交入过账sap用
     */
    @ApiModelProperty(value = "gr工厂，内交入过账sap用")
    private String grPlantCode;

    /**
     * gr信息，内交入过账sap用
     */
    @ApiModelProperty(value = "gr信息，内交入过账sap用")
    private String grMsg;

    /**
     * gr日期，内交入过账sap用
     */
    @ApiModelProperty(value = "gr日期，内交入过账sap用")
    private LocalDateTime grDate;

    /**
     * gr人，内交入过账sap用
     */
    @ApiModelProperty(value = "gr人，内交入过账sap用")
    private String grBy;

    /**
     * 内交出确认人
     */
    @ApiModelProperty(value = "内交出确认人")
    private String tradingFromConfirmBy;

    /**
     * 内交出确认时间
     */
    @ApiModelProperty(value = "内交出确认时间")
    private LocalDateTime tradingFromConfirmDate;

    /**
     * 内交出确认标识
     */
    @ApiModelProperty(value = "内交出确认标识")
    private String tradingFromConfirmFlag;

    /**
     * 内交入确认人
     */
    @ApiModelProperty(value = "内交入确认人")
    private String tradingToConfirmBy;

    /**
     * 内交入确认时间
     */
    @ApiModelProperty(value = "内交入确认时间")
    private LocalDateTime tradingToConfirmDate;

    /**
     * 内交入确认数量
     */
    @ApiModelProperty(value = "内交入确认数量")
    private BigDecimal tradingToConfirmQty;

    /**
     * 内交入确认标识
     */
    @ApiModelProperty(value = "内交入确认标识")
    private String tradingToConfirmFlag;

    @ApiModelProperty("是否虚拟过账")
    private String isTrading;

    @ApiModelProperty("出库数量")
    private BigDecimal deliveryQty;


    @ApiModelProperty(value = "制造商料号")
    private String toMfgPartNo;

    @ApiModelProperty(value = "制造商名称")
    private String toMfgName;

    @ApiModelProperty(value = "制造商编码")
    private String toMfgCode;

    @ApiModelProperty("是否保税")
    private Boolean isBonded;

    @ApiModelProperty(value = "PO")
    private String poNumber;

    @ApiModelProperty(value = "PO项次")
    private String poItem;

    @ApiModelProperty(value = "收货单号")
    private String receiveNo;

    @ApiModelProperty(value = "供应商code")
    private String vendorCode;

    @ApiModelProperty(value = "po文件类型")
    private String poDocumentType;
}