package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * WMS库龄报表仓码配置
 * </p>
 *
 * @author baomidou
 * @since 2024-11-19
 */
@TableName("wms_inventory_age_warehouse_config")
@ApiModel(value = "WmsInventoryAgeWarehouseConfig对象", description = "WMS库龄报表仓码配置")
@Data
public class WmsInventoryAgeWarehouseConfig extends BaseEntity<WmsInventoryAgeWarehouseConfig> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("工厂")
    private String plantCode;

    @ApiModelProperty("仓码")
    private String warehouseCode;
}
