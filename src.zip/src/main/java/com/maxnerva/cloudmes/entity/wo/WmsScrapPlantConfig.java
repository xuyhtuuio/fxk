package com.maxnerva.cloudmes.entity.wo;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;


/**
 * <p>
 * 报废单工厂配置表
 * </p>
 *
 * @author likun
 * @since 2023-03-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value = "WmsScrapPlantConfig对象", description = "报废单工厂配置表")
public class WmsScrapPlantConfig extends BaseEntity<WmsScrapPlantConfig> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "报废单BU")
    private String scrapOrgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;
}
