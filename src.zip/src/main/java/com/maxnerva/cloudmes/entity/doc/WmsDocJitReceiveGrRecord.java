package com.maxnerva.cloudmes.entity.doc;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import net.sf.cglib.core.Local;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>
 * JIT收货GR记录表
 * </p>
 *
 * @author likun
 * @since 2025-02-11
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsDocJitReceiveGrRecord对象", description="JIT收货GR记录表")
public class WmsDocJitReceiveGrRecord extends BaseEntity<WmsDocJitReceiveGrRecord> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "ASN NO")
    private String asnNo;

    @ApiModelProperty(value = "GR号")
    private String grNumber;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate grDate;

    @ApiModelProperty(value = "PO")
    private String poNo;

    @ApiModelProperty(value = "PO ITEM")
    private String poItem;

    @ApiModelProperty(value = "vendor code")
    private String vendorCode;

    @ApiModelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "料号描述")
    private String partDesc;

    @ApiModelProperty(value = "料号版次")
    private String partVersion;

    @ApiModelProperty(value = "数量")
    private BigDecimal qty;

    @ApiModelProperty(value = "po类型")
    private String poDocumentType;

    @ApiModelProperty(value = "厂商编码")
    private String mfgCode;

    @ApiModelProperty(value = "厂商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "厂商名称")
    private String mfgName;

    @ApiModelProperty(value = "单位")
    private String uomCode;

    @ApiModelProperty(value = "仓码")
    private String warehouseCode;

    @ApiModelProperty(value = "原产国")
    private String placeOfOrigin;

    @ApiModelProperty(value = "采购员组")
    private String purchaseGroup;

    @ApiModelProperty(value = "采购员org")
    private String purchaseOrg;

    @ApiModelProperty(value = "建单标识(Y-成功 N-失败)")
    private String docCreateFlag;

    @ApiModelProperty(value = "建单信息")
    private String docCreateMsg;

    @ApiModelProperty(value = "移动类型")
    private String movementType;

    @ApiModelProperty(value = "返单gr号")
    private String returnGrNumber;

    @ApiModelProperty(value = "條碼六合一料號")
    private String pkgPartNo;

    @ApiModelProperty(value = "條碼六合一料號")
    private BigDecimal pkgQty;

    @ApiModelProperty(value = "條碼六合一製造商料號")
    private String pkgMfgPartNo;

    @ApiModelProperty(value = "條碼六合一原始DC")
    private String pkgOriginalDateCode;

    @ApiModelProperty(value = "條碼六合一lot")
    private String pkgLotCode;

    @ApiModelProperty(value = "條碼六合一 PKGID")
    private String pkgId;

    @ApiModelProperty(value = "採集時間")
    private LocalDateTime collectDt;

    @ApiModelProperty(value = "當前採集人")
    private String collector;

    @ApiModelProperty(value = "採集狀態 默認N")
    private String collectFlag;

    @ApiModelProperty(value = "是否發送郵件")
    private String isSendMail;

    @ApiModelProperty(value = "發送郵件時間")
    private LocalDateTime sendMailDt;


}
