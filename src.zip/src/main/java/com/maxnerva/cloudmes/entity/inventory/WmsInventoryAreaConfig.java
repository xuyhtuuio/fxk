package com.maxnerva.cloudmes.entity.inventory;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

/**
 * <p>
 * 盘点库区配置
 * </p>
 *
 * @author likun
 * @since 2024-11-11
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsInventoryAreaConfig对象", description="盘点库区配置")
public class WmsInventoryAreaConfig extends BaseEntity<WmsInventoryAreaConfig> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "组织")
    private String orgCode;

    @ApiModelProperty(value = "库区编码")
    private String areaCode;

    @ApiModelProperty(value = "库区名称")
    private String areaName;

    @ApiModelProperty(value = "盘点周期")
    private String inventoryCycle;

    @ApiModelProperty(value = "开始区间值")
    private Integer startIntervalValue;

    @ApiModelProperty(value = "结束区间值")
    private Integer endIntervalValue;

    @ApiModelProperty(value = "月次数")
    private Integer monthTimes;

    @ApiModelProperty(value = "周次数")
    private Integer weekTimes;

    @ApiModelProperty(value = "盘点类型")
    private String inventoryType;

    @ApiModelProperty(value = "上次载具编码")
    private String lastVehicleCode;

    @ApiModelProperty(value = "设定基数")
    private String baseCount;

    @ApiModelProperty(value = "盘点时间")
    private LocalDateTime inventoryDate;

    @ApiModelProperty(value = "是否启用")
    private Boolean isUsed;

    @ApiModelProperty(value = "是否清空上次盘点载具标识")
    private Boolean cleanLastVehicleFlag;
}
