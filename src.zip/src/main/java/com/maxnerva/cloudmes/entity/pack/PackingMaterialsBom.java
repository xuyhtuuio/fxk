package com.maxnerva.cloudmes.entity.pack;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.maxnerva.cloudmes.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

/**
 * @ClassName PackingMaterialsBom
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/6/10 下午 01:36
 * @Version 1.0
 **/
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("wms_packing_materials_bom")
public class PackingMaterialsBom extends Model<PackingMaterialsBom> {

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    //鸿海料号
    @TableField("hh_pn")
    private String hhPn;
    //包材料号
    @TableField("packing_materials_pn")
    private String packingMaterialsPn;
    //包材品名
    @TableField("packing_materials_name")
    private String packingMaterialsName;
    //用量
    private Double dosage;
    //运输方式
    private String transportation;
    //创建人
    @TableField("create_by")
    private String createBy;
    //创建时间
    @TableField("create_dt")
    private LocalDateTime createDt;
    //修改人
    @TableField("update_by")
    private String updateBy;
    //修改时间
    @TableField("update_dt")
    private LocalDateTime updateDt;
    //供应商名称 用于前端展示 使用
    @TableField(exist = false)
    private String supplier;

    public void setDosage(Double dosage) {
        //使用字符串切割  使用BigDecimal.ROUND_DOWN策略时 如果小数位小于 设定的小数位 则会出现补全到设定小数位 不可取
        //1、判断不为空 为空直接赋值为0.0
        if(dosage != null) {
            //设定小数位数
            int decimalPlaces = 6;
            //2、转换为字符串
            String dosageStr = dosage.toString();
            //3、整数不转换
            //判断是否为整数   判断依据为小数点下标索引
            int index = dosageStr.indexOf(".");
            if(index != -1) {
                //截取小数位
                String decimal = dosageStr.substring(index + 1);
                //4、小数位大于预设小数位 直接截取
                if(decimalPlaces < decimal.length()) {
                    String dosageHandle = dosageStr.substring(0,index) + "." +dosageStr.substring(index+1,index+1+decimalPlaces);
                    this.dosage = Double.valueOf(dosageHandle);
                }else {
                    //5、小数位小于预设小数位 则不进行处理
                    this.dosage = dosage;
                }
            }else {
                this.dosage = dosage;
            }
        }else {
            this.dosage = 0.0;
        }
//       this.dosage = new BigDecimal(dosage).setScale(6, BigDecimal.ROUND_DOWN).doubleValue();
    }
}
