package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("basic_sys.sys_staff")
public class BasicSysStaffEntity {
    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    private String depName;

    private String staffCode;

    private String staffName;

    private String job;

    private Integer depId;

    private Integer jobStatus;
}
