package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 报废处理单头
 * </p>
 *
 * @author baomidou
 * @since 2024-08-01
 */
@TableName("wms_scrap_handle_header")
@ApiModel(value = "WmsScrapHandleHeader对象", description = "报废处理单头")
@Data
public class WmsScrapHandleHeader extends BaseEntity<WmsScrapHandleHeader> {

    private Integer id;

    @ApiModelProperty("组织")
    private String orgCode;

    @ApiModelProperty("工厂")
    private String plantCode;

    @ApiModelProperty("单号")
    private String docNo;

    @ApiModelProperty("0 新建，1审核中，2 已审核，3 出货，4 待出货")
    private String identify;

    @ApiModelProperty("单据日期")
    private LocalDateTime docDate;

    @ApiModelProperty("申请部门")
    private String applyDeptName;

    @ApiModelProperty("申请人工号")
    private String applyStaffCode;

    @ApiModelProperty("申请人姓名")
    private String applyStaffName;

    @ApiModelProperty("申请人分机")
    private String applyStaffExtension;

    @ApiModelProperty("图片地址列表 JSONArray")
    private String imageUrlList;

    @ApiModelProperty("说明")
    private String description;

    @ApiModelProperty(value = "报废文件列表")
    private String scrapFileList;

    @ApiModelProperty(value = "出货时间")
    private LocalDateTime shipDt;

    @ApiModelProperty(value = "单据类型")
    private String docType;

    @ApiModelProperty(value = "装货地点")
    private String loadingLocation;
}
