package com.maxnerva.cloudmes.entity.pack;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * <p>
 * 包材工单header信息表
 * </p>
 *
 * @author likun
 * @since 2024-12-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsPackWorkOrderHeader对象", description="包材工单header信息表")
public class WmsPackWorkOrderHeader extends BaseEntity<WmsPackWorkOrderHeader> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id;")
    private Integer id;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "BU（业务单元）")
    private String orgCode;

    @ApiModelProperty(value = "sap工厂")
    private String plantCode;

    @ApiModelProperty(value = "工单类型")
    private String workOrderType;

    @ApiModelProperty(value = "成品料号")
    private String partNo;

    @ApiModelProperty(value = "成品料号描述")
    private String partDesc;

    @ApiModelProperty(value = "线别")
    private String lineNo;

    @ApiModelProperty(value = "料号版次")
    private String partVersion;

    @ApiModelProperty(value = "计划日期,来源sap")
    private LocalDate scheduledDate;

    @ApiModelProperty(value = "工单数量")
    private BigDecimal workOrderQty;

    @ApiModelProperty(value = "工单状态")
    private String workOrderStatus;
}
