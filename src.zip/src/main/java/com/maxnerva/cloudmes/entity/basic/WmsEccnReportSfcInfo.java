package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2024-01-20
 */
@Data
@TableName("wms_eccn_report_sfc_info")
@ApiModel(value = "WmsEccnReportSfcInfo对象", description = "")
public class WmsEccnReportSfcInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer id;

    private String orgCode;

    @ApiModelProperty("栈板")
    private String palletNo;

    @ApiModelProperty("箱")
    private String cartonNo;

    @ApiModelProperty("入库数量")
    private BigDecimal inStorageQty;

    @ApiModelProperty("工单")
    private String workOrderNo;

    @ApiModelProperty("入库时间")
    private LocalDateTime inStorageDt;

    private String dnNo;

    @ApiModelProperty("出货数量")
    private BigDecimal shipQty;

    @ApiModelProperty("出货时间")
    private LocalDateTime shipDt;

    @ApiModelProperty("出货地")
    private String siteCode;

    @ApiModelProperty("出货计划数量")
    private BigDecimal shipPlanQty;

    @ApiModelProperty(value = "ECCN NO")
    private String eccnNo;

    @ApiModelProperty(value = "出货SO")
    private String soNo;

    @ApiModelProperty(value = "单位")
    private String uomCode;
}
