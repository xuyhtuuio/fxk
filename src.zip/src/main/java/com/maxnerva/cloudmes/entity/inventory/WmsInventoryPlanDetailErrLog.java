package com.maxnerva.cloudmes.entity.inventory;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @Author yjw
 * @Description 盘点计划详情异常Log表
 * @Date 2023/6/1 16:56
 */
@Data
@ApiModel(value="WmsInventoryPlanDetailLog异常对象", description="盘点计划详情Log异常信息")
public class WmsInventoryPlanDetailErrLog {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "盘点计划编号")
    private String inventoryPlanNo;

    @ApiModelProperty(value = "条码号")
    private String pkgId;

    @ApiModelProperty(value = "盘点pkg id")
    private String inventoryPkgId;

    @ApiModelProperty(value = "盘点时间")
    private LocalDateTime inventoryDateTime;

    @ApiModelProperty(value = "盘点人编码")
    private String inventoryExecutorCode;

    @ApiModelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "数量")
    private BigDecimal qty;

    @ApiModelProperty(value = "库区")
    private String areaCode;

    @ApiModelProperty(value = "库位")
    private String locationCode;

    @ApiModelProperty(value = "载具")
    private String vehicleCode;

    @ApiModelProperty(value = "储位")
    private String binCode;

    @ApiModelProperty(value = "仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "异常原因")
    private String abnormalCause;

    @ApiModelProperty(value = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "创建人")
    private String creator;

    @ApiModelProperty(value = "最后操作人")
    private String lastEditor;

    @ApiModelProperty(value = "最后操作人")
    private String lastOperator;

    @ApiModelProperty(value = "最后一次操作时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime lastOperationTime;


    @ApiModelProperty(value = "最后一次编辑时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime lastEditedDt;

}
