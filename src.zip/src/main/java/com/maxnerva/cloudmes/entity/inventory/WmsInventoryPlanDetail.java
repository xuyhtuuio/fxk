package com.maxnerva.cloudmes.entity.inventory;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * <p>
 * 盘点计划单身
 * </p>
 *
 * @author likun
 * @since 2023-03-25
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value = "WmsInventoryPlanDetail对象", description = "盘点计划单身")
public class WmsInventoryPlanDetail extends BaseEntity<WmsInventoryPlanDetail> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "盘点计划编号")
    private String inventoryPlanNo;

    @ApiModelProperty(value = "条码号")
    private String pkgId;

    @ApiModelProperty(value = "盘点pkg id")
    private String inventoryPkgId;

    @ApiModelProperty(value = "盘点时间")
    private LocalDateTime inventoryDateTime;

    @ApiModelProperty(value = "盘点人编码")
    private String inventoryExecutorCode;

    @ApiModelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "数量")
    private BigDecimal qty;

    @ApiModelProperty(value = "库区")
    private String areaCode;

    @ApiModelProperty(value = "库位")
    private String locationCode;

    @ApiModelProperty(value = "载具")
    private String vehicleCode;

    @ApiModelProperty(value = "储位")
    private String binCode;

    @ApiModelProperty(value = "仓码")
    private String sapWarehouseCode;
}
