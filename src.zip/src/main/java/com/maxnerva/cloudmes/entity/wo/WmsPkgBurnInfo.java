package com.maxnerva.cloudmes.entity.wo;

import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import lombok.Data;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * (WmsPkgBurnInfo)实体类
 *
 * @author hgx
 * @since 2023-07-28
 */
@Data
@ApiModel("WmsPkgBurnInfo实体类")
public class WmsPkgBurnInfo extends BaseEntity<WmsPkgBurnInfo> {


    @ApiModelProperty("id")
    private Integer id;

    @ApiModelProperty("pkgId")
    private String pkgId;

    @ApiModelProperty("parentPkgId")
    private String parentPkgId;
    /**
     * BU
     */
    @ApiModelProperty("BU")
    private String orgCode;
    /**
     * SAP工厂
     */
    @ApiModelProperty("SAP工厂")
    private String plantCode;
    /**
     * 料号
     */
    @ApiModelProperty("料号")
    private String partNo;
    /**
     * 烧录后料号
     */
    @ApiModelProperty("烧录后料号")
    private String burnPartNo;
    /**
     * 供应商料号
     */
    @ApiModelProperty("供应商料号")
    private String supplierPartNo;
    /**
     * 制造商料号
     */
    @ApiModelProperty("制造商料号")
    private String mfgPartNo;
    /**
     * 工单号
     */
    @ApiModelProperty("工单号")
    private String workOrderNo;
    /**
     * 烧录值
     */
    @ApiModelProperty("烧录值")
    private String burnValue;
    /**
     * 烧录开始时间
     */
    @ApiModelProperty("烧录开始时间")
    private LocalDateTime burnDatetime;
    /**
     * 烧录结束时间
     */
    @ApiModelProperty("烧录结束时间")
    private LocalDateTime burnEndDatetime;
    /**
     * 烧录人
     */
    @ApiModelProperty("烧录人")
    private String burnEmpNo;
    /**
     * 成品料号
     */
    @ApiModelProperty("成品料号")
    private String finishedPartNo;

    @ApiModelProperty("DC")
    private String dateCode;

    @ApiModelProperty("LC")
    private String lotCode;

}

