package com.maxnerva.cloudmes.entity.doc;

import com.maxnerva.cloudmes.common.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@ApiModel("ASN上传JUSDA")
@Data
public class WmsAsnUploadBuConfig extends BaseEntity {

    private Integer id;

    @ApiModelProperty(value = "orgCode")
    private String orgCode;

    @ApiModelProperty(value = "plantCode")
    private String plantCode;

    @ApiModelProperty(value = "BU")
    private String buCode;

    @ApiModelProperty(value = "進出模式")
    private String inOutMode;

    @ApiModelProperty(value = "保稅性質")
    private String natureOfBond;

    @ApiModelProperty(value = "恒溫否")
    private String thermostatic;

    @ApiModelProperty(value = "適用于物料情況")
    private String partCondition;

    private Boolean isDeleted;

    @ApiModelProperty(value = "senderId")
    private String senderId;

    @ApiModelProperty(value = "msgType")
    private String msgType;

    @ApiModelProperty(value = "receiverId")
    private String receiverId;

    @ApiModelProperty(value = "customerName")
    private String customerName;

    @ApiModelProperty(value = "采购组织")
    private String purchaseOrg;

}
