package com.maxnerva.cloudmes.entity.warehouse;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

/**
 * <p>
 * 成品退回表
 * </p>
 *
 * @author likun
 * @since 2024-03-26
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsProductReturnRecord对象", description="成品退回表")
public class WmsProductReturnRecord extends BaseEntity<WmsProductReturnRecord> {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "单号")
    private String docNo;

    @ApiModelProperty(value = "PKG")
    private String pkgId;

    @ApiModelProperty(value = "postSfc过站标识")
    private String postSfcPassStationFlag;

    @ApiModelProperty(value = "postSfc信息")
    private String postSfcMessage;

    @ApiModelProperty(value = "postSfc时间")
    private LocalDateTime postSfcDatatime;
}
