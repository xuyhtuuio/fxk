package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 特采物料类别延期配置
 * </p>
 *
 * @author baomidou
 * @since 2024-11-13
 */
@EqualsAndHashCode(callSuper = true)
@TableName("wms_material_class_expired_config")
@ApiModel(value = "WmsMaterialClassExpiredConfig对象", description = "特采物料类别有效期配置")
@Data
public class WmsMaterialClassExpiredConfig extends BaseEntity<WmsMaterialClassExpiredConfig> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("物料类别")
    private String classCode;

    @ApiModelProperty("有效期")
    private Integer expiredDay;

    @ApiModelProperty("制程")
    private String materialProductType;
}
