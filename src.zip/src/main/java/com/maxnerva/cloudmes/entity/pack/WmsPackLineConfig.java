package com.maxnerva.cloudmes.entity.pack;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 包材线体配置表
 * </p>
 *
 * @author likun
 * @since 2024-12-16
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsPackLineConfig对象", description="包材线体配置表")
public class WmsPackLineConfig extends BaseEntity<WmsPackLineConfig> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "线体")
    private String lineNo;

    @ApiModelProperty(value = "厂部")
    private String factoryCode;

    @ApiModelProperty(value = "仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "仓码描述")
    private String sapWarehouseName;
}
