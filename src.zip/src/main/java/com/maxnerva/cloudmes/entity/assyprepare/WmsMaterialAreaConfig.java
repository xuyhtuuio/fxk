package com.maxnerva.cloudmes.entity.assyprepare;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 料号库区配置表
 * </p>
 *
 * @author likun
 * @since 2024-06-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsMaterialAreaConfig对象", description="料号库区配置表")
public class WmsMaterialAreaConfig extends BaseEntity<WmsMaterialAreaConfig> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "库区编码")
    private String areaCode;

    @ApiModelProperty(value = "料号编码")
    private String materialNo;
}
