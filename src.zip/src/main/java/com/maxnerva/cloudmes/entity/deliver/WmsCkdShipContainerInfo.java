package com.maxnerva.cloudmes.entity.deliver;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * CKD货柜信息
 * </p>
 *
 * @author baomidou
 * @since 2024-07-25
 */
@TableName("wms_ckd_ship_container_info")
@ApiModel(value = "WmsCkdShipContainerInfo对象", description = "CKD货柜信息")
@Data
public class WmsCkdShipContainerInfo extends BaseEntity<WmsCkdShipContainerInfo> {

    private Integer id;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("工厂")
    private String plantCode;

    @ApiModelProperty("车牌号")
    private String licenseNo;

    @ApiModelProperty("货柜号")
    private String containerNo;

    @ApiModelProperty("码头号")
    private String dockNo;

    @ApiModelProperty("到厂时间")
    private LocalDateTime arriveTime;

    @ApiModelProperty("离厂时间")
    private LocalDateTime leaveTime;

    @ApiModelProperty("出货地")
    private String siteCode;

    @ApiModelProperty("运输方式")
    private String transportMode;

    @ApiModelProperty("N:未出货，Y:已出货")
    private String shipFlag;

    @ApiModelProperty("默认0，1：已抛Q")
    private String toQmsFlag;

    @ApiModelProperty("抛qms时间")
    private LocalDateTime toQmsDate;

    @ApiModelProperty("qms返回信息")
    private String toQmsMsg;
}
