package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.common.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;

@ApiModel("准时达收货明细")
@Data
public class WmsJusdaReceiptPallet extends BaseEntity {

    @TableId(type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "SAP工厂")
    private String plantCode;

    @ApiModelProperty(value = "准时达出货id")
    private Integer wmsJusdaDeliveryId;

    @ApiModelProperty(value = "栈板号")
    private String palletNo;


    //Delivery表复制过来的字段
    @ApiModelProperty(value = "VMIHUB 中的工厂别")
    private String siteName;

    @ApiModelProperty(value = "供应商名称别")
    private String supplierName;

    @ApiModelProperty(value = "Foxconn BU代碼")
    private String customerName;

    @ApiModelProperty(value = "出货单号")
    private String shipId;

    @ApiModelProperty(value = "來源國")
    private String originOfCountry;

    @ApiModelProperty(value = "供應商代碼")
    private String customerSupplierNo;

    @ApiModelProperty(value = "供應商料號")
    private String supplierPartNo;

    @ApiModelProperty(value = "BU料號")
    private String customerPartNo;

    @ApiModelProperty(value = "供應商料號版次")
    private String spnVersion;

    @ApiModelProperty(value = "BU料號版次")
    private String cpnVersion;

    @ApiModelProperty(value = "制造商簡稱")
    private String manufacture;

    @ApiModelProperty(value = "出貨時間")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date shipDt;

    @ApiModelProperty(value = "出貨數量")
    private BigDecimal shipedQty;

    @ApiModelProperty(value = "棧板PC數量")
    private BigDecimal packedQty;

    @ApiModelProperty(value = "單位")
    private String uom;

    @ApiModelProperty(value = "EDI862 ID")
    private String pullListNo;

    @ApiModelProperty(value = "EDI862文件ID號碼項次")
    private String pullListItem;

    @ApiModelProperty(value = "報關PO號碼")
    private String customPo;

    @ApiModelProperty(value = "報關PO項次")
    private String customPoItem;

    @ApiModelProperty(value = "報關單號")
    private String customDocNo;

    @ApiModelProperty(value = "報關單項次")
    private String customDocItemNo;

    @ApiModelProperty(value = "VMI GRN NO")
    private String grnNo;

    @ApiModelProperty(value = "工單號")
    private String workOrderNo;

    @ApiModelProperty(value = "Supplier PO單號")
    private String customerPo;

    @ApiModelProperty(value = "Supplier Po單項次")
    private String customerPoItem;

    @ApiModelProperty(value = "物料進口類型")
    private String inboundType;

    @ApiModelProperty(value = "預計到貨時間")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date eta;

    @ApiModelProperty(value = "最小出货单位包规")
    private String boxQty;

    @ApiModelProperty(value = "箱数")
    private BigDecimal thuQty;

    @ApiModelProperty(value = "EDI856文件唯一的ID")
    private String documentId;

    @ApiModelProperty(value = "出貨類型(H2S,H2C)")
    private String soType;

    @ApiModelProperty(value = "內交單號")
    private String innerTransferNo;

    @ApiModelProperty(value = "內交單號項次")
    private String innerTransferNoItem;

    @ApiModelProperty(value = "物料單價")
    private String unitPrice;

    @ApiModelProperty(value = "参考栏位1")
    private String reference1;

    @ApiModelProperty(value = "参考栏位2")
    private String reference2;

    @ApiModelProperty(value = "参考栏位3")
    private String reference3;

    @ApiModelProperty(value = "参考栏位4")
    private String reference4;

    @ApiModelProperty(value = "参考栏位5")
    private String reference5;

    @ApiModelProperty(value = "收货类型（VMI、CMI）")
    private String receivedType;

    @ApiModelProperty(value = "上架数量")
    private BigDecimal shelfQty;

    @ApiModelProperty(value = "采集数量")
    private BigDecimal collectQty;

    @ApiModelProperty(value = "组织")
    private String orgCode;

    @ApiModelProperty(value = "库位编码")
    private String locationCode;

    @ApiModelProperty("备料标识")
    private Integer prepareFlag;

    @ApiModelProperty("备料时间")
    private LocalDateTime prepareDate;

    @ApiModelProperty("备料信息")
    private String prepareMessage;
}
