package com.maxnerva.cloudmes.entity.doc;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * <p>
 * 报关进口信息导入信息表
 * </p>
 *
 * @author likun
 * @since 2024-07-17
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsDocReceiveCusRecord对象", description="报关进口信息导入信息表")
public class WmsDocReceiveCusRecord extends BaseEntity<WmsDocReceiveCusRecord> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "po")
    private String poNo;

    @ApiModelProperty(value = "poItem")
    private String poItem;

    @ApiModelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "收货数量")
    private BigDecimal receiveQty;

    @ApiModelProperty(value = "净重(备案净重*进口数量)")
    private BigDecimal netWeight;

    @ApiModelProperty(value = "单价")
    private BigDecimal price;

    @ApiModelProperty(value = "预计到厂时间")
    private LocalDate eta;

    @ApiModelProperty(value = "来源单号")
    private String fromDocNo;

    @ApiModelProperty(value = "来源项次")
    private String fromDocItem;

    @ApiModelProperty(value = "原产国1")
    private String placeOfOrigin1;

    @ApiModelProperty(value = "起运国")
    private String shipOfOrigin;

    @ApiModelProperty(value = "毛重")
    private BigDecimal grossWeight;

    @ApiModelProperty(value = "箱数")
    private Integer cartonQty;

    @ApiModelProperty(value = "板数")
    private Integer palletQty;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "DC")
    private String dc;

    @ApiModelProperty(value = "INVOICE NO")
    private String invoiceNo;

    @ApiModelProperty(value = "ECCN NO")
    private String eccnNo;

    @ApiModelProperty(value = "应收代付PO2")
    private String poNo2;

    @ApiModelProperty(value = "PO2 Item")
    private String poItem2;

    @ApiModelProperty(value = "金额(单价*数量)")
    private BigDecimal amount;

    @ApiModelProperty(value = "固定值 默认NEW 100%")
    private String remain;

    @ApiModelProperty(value = "单位")
    private String uomCode;

    @ApiModelProperty(value = "904厂商全称")
    private String shipper;

    @ApiModelProperty(value = "904厂商地址")
    private String shipperAddress;

    @ApiModelProperty(value = "收货单号")
    private String docNo;
}
