package com.maxnerva.cloudmes.entity.wo;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

/**
 * <p>
 * kitting载具移转记录
 * </p>
 *
 * @author likun
 * @since 2023-04-26
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsKittingVehicleMoveRecord对象", description="kitting载具移转记录")
public class WmsKittingVehicleMoveRecord extends BaseEntity<WmsKittingVehicleMoveRecord> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "工单备料记录id")
    private Integer wmsWorkOrderPrepareLogId;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "条码号")
    private String pkgId;

    @ApiModelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "数量")
    private BigDecimal currentQty;

    @ApiModelProperty(value = "原始载具")
    private String vehicleCode;

    @ApiModelProperty(value = "原始储位")
    private String binCode;

    @ApiModelProperty(value = "目标载具")
    private String toVehicleCode;

    @ApiModelProperty(value = "目标储位")
    private String toBinCode;

}
