package com.maxnerva.cloudmes.entity.doc;

import com.maxnerva.cloudmes.common.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel("费领退成本中心关系")
@Data
public class WmsCostRelation extends BaseEntity {
    private Integer id;

    @ApiModelProperty("组织")
    private String orgCode;

    @ApiModelProperty("异动原因代码")
    private String reasonCode;

    @ApiModelProperty("异动原因中文描述")
    private String movementTypeDesc;

    @ApiModelProperty("异动原因英文描述")
    private String movementTypeEnDesc;

    @ApiModelProperty("单据小类编码")
    private String docTypeCode;

    @ApiModelProperty("成本中心编码")
    private String costCenter;

    @ApiModelProperty("成本中心描述")
    private String costDesc;

    @ApiModelProperty("成本中心英文描述")
    private String costEnDesc;

    @ApiModelProperty("异动原因描述")
    private String reasonDesc;

    @ApiModelProperty("异动原因英文描述")
    private String reasonEnDesc;

    @ApiModelProperty("异动类型")
    private String movementType;
}
