package com.maxnerva.cloudmes.entity.trading;

import com.maxnerva.cloudmes.common.models.entity.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 内交单据表
 * @TableName wms_trading_record
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class WmsTradingDeliveryLog extends BaseEntity {
    /**
     * 主键id
     */
    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "内交单id")
    private Integer wmsTradingRecordId;

    @ApiModelProperty(value = "出库条码")
    private String pkgId;

    @ApiModelProperty(value = "储位")
    private String binCode;

    @ApiModelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "出库数量")
    private BigDecimal qty;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "库位")
    private String locationCode;

    @ApiModelProperty(value = "版次")
    private String partVersion;

    @ApiModelProperty(value = "载具")
    private String vehicleCode;

    @ApiModelProperty(value = "出货打印pkgId")
    private String printPkgId;
}