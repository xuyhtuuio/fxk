package com.maxnerva.cloudmes.entity.dsi;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

/**
 * <p>
 * wms接收dsi信息表
 * </p>
 *
 * @author likun
 * @since 2025-06-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsDsiReceiveInfo对象", description="wms接收dsi信息表")
public class WmsDsiReceiveInfo extends BaseEntity<WmsDsiReceiveInfo> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "版本")
    private String version;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "mrp area")
    private String mrpArea;

    @ApiModelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "机种")
    private String platform;

    @ApiModelProperty(value = "DSI")
    private BigDecimal dsi;

    @ApiModelProperty(value = "第一周DSI目标")
    private BigDecimal firstWeekDsiTarget;
}
