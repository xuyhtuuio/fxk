package com.maxnerva.cloudmes.entity.pack;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * <p>
 * 包材发料单detail
 * </p>
 *
 * @author likun
 * @since 2024-12-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsPackStockDetail对象", description="包材发料单detail")
public class WmsPackStockDetail extends BaseEntity<WmsPackStockDetail> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "工单群组(项次)")
    private String workOrderItem;

    @ApiModelProperty(value = "仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "发料单号")
    private String docNo;

    @ApiModelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "料号版次")
    private String partVersion;

    @ApiModelProperty(value = "发料量")
    private BigDecimal issueQty;

    @ApiModelProperty(value = "单位")
    private String uomCode;

    @ApiModelProperty(value = "成本中心")
    private String costCenter;

    @ApiModelProperty(value = "异动类型")
    private String moveType;

    @ApiModelProperty(value = "异动原因")
    private String reasonCode;

    @ApiModelProperty(value = "过账单号")
    private String postSapReturnNumber;

    @ApiModelProperty(value = "过账信息")
    private String postSapReturnMsg;

    @ApiModelProperty(value = "过账时间")
    private LocalDateTime postSapDate;

    @ApiModelProperty(value = "专案名称")
    private String itemText;

    @ApiModelProperty(value = "valueType")
    private String valueType;
}
