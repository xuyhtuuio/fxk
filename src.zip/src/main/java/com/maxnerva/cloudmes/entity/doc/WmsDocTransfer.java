package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.maxnerva.cloudmes.common.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.math.BigDecimal;
import java.util.Date;

@ApiModel("转仓单")
@Data
public class WmsDocTransfer extends BaseEntity {

    @TableId(type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "工厂组织")
    private String orgCode;

    @ApiModelProperty(value = "单据类型")
    private String docType;

    @ApiModelProperty(value = "申请数量")
    private BigDecimal applyQty;

    @ApiModelProperty(value = "标识")
    private String identify;

    @ApiModelProperty(value = "是否上传")
    private String isUpload;

    @ApiModelProperty(value = "日期")
    private Date date;

    @ApiModelProperty(value = "单号")
    private String docNo;

    @ApiModelProperty(value = "项次")
    private String item;

    @ApiModelProperty(value = "SAP工厂")
    private String oldPlantCode;

    @ApiModelProperty(value = "原仓码")
    private String oldWarehoseCode;

    @ApiModelProperty(value = "原鸿海料号")
    private String oldMaterialCode;

    @ApiModelProperty(value = "料号名称")
    private String materialName;

    @ApiModelProperty(value = "原鸿海版次")
    private String oldMaterialVersion;



    @ApiModelProperty(value = "原供应商料号")
    private String oldVendorMaterial;

    @ApiModelProperty(value = "原供应商版次")
    private String oldVendorVersion;

    @ApiModelProperty(value = "单位")
    private String uom;

    @ApiModelProperty(value = "目的工厂")
    private String targetPlantCode;

    @ApiModelProperty(value = "目的仓码")
    private String targetWarehoseCode;

    @ApiModelProperty(value = "目的鸿海料号")
    private String targetMaterialCode;

    @ApiModelProperty(value = "目的鸿海版次")
    private String targetMaterialVersion;

    @ApiModelProperty(value = "目的供应商料号")
    private String targetVendorMaterial;

    @ApiModelProperty(value = "目的供应商版次")
    private String targetVendorVersion;

    @ApiModelProperty(value = "费用代码")
    private String costCode;

    @ApiModelProperty(value = "原因")
    private String reason;

    @ApiModelProperty(value = "上传日期")
    private Date sapUploadData;

    @ApiModelProperty(value = "上传SAP结果")
    private String sapReturnResult;

    @ApiModelProperty(value = "SAP返回信息")
    private String sapReturnMessage;

    @ApiModelProperty(value = "SAP返回单号")
    private String sapReturnNumber;

    @ApiModelProperty(value = "完成数量")
    private BigDecimal completeQty;

    @ApiModelProperty(value = "手动确认过账数量")
    private BigDecimal confirmPostingQty;

    @ApiModelProperty(value = "物料采购人")
    private String mcid;

    @ApiModelProperty(value = "flownet流程id")
    private String flownetProcessId;

    @ApiModelProperty(value = "flownet返回描述")
    private String flownetMsg;

    @ApiModelProperty(value = "flownet审批结果")
    private String flownetApprovalResult;

    @ApiModelProperty(value = "flownet表单地址")
    private String flownetUrl;

    @ApiModelProperty(value = "flownet调用结果,SUCCESS")
    private String flownetFlag;

    @ApiModelProperty(value = "flownet返回表单id")
    private String flownetFormId;

    @ApiModelProperty(value = "删除标识")
    private Boolean isDeleted;

    @ApiModelProperty(value = "抛转SPM标识,Y-需要 N-不需要")
    private String postSpmFlag;

    @ApiModelProperty(value = "抛转SPM成功标识 0-未成功 1-成功")
    private String toSpmFlag;

    @ApiModelProperty(value = "来源单号")
    private String fromDocNo;

    @ApiModelProperty(value = "已入库数量")
    private BigDecimal enterNum;

    @ApiModelProperty(value = "已出库数量")
    private BigDecimal outNum;
}
