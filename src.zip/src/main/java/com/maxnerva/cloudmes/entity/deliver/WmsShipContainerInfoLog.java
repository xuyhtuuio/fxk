package com.maxnerva.cloudmes.entity.deliver;

import java.time.LocalDateTime;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * (WmsShipContainerInfoLog)实体类
 *
 * @author hgx
 * @since 2023-11-30
 */

@ApiModel("WmsShipContainerInfoLog实体类")
@Data
public class WmsShipContainerInfoLog extends BaseEntity<WmsShipContainerInfoLog> {
 
   
    @ApiModelProperty("id")
    private Integer id;
   
    @ApiModelProperty("BU")
    private String orgCode;
   
    @ApiModelProperty("工厂")
    private String plantCode;
   
    @ApiModelProperty("车牌号")
    private String licenseNo;
   
    @ApiModelProperty("货柜号")
    private String containerNo;
   
    @ApiModelProperty("码头号")
    private String dockNo;
   
    @ApiModelProperty("到厂时间")
    private LocalDateTime arriveTime;
   
    @ApiModelProperty("离厂时间")
    private LocalDateTime leaveTime;
   
    @ApiModelProperty("出货地")
    private String siteCode;
   
    @ApiModelProperty("运输方式")
    private String transportMode;
   
    @ApiModelProperty("N:未出货，Y:已出货")
    private String shipFlag;
   
    @ApiModelProperty("绑定DN号")
    private String dnNo;
}

