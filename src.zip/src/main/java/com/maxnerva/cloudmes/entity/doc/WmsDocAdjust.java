package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.maxnerva.cloudmes.common.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;

@ApiModel("调整单")
@Data
public class WmsDocAdjust extends BaseEntity {

    @TableId(type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "工厂组织")
    private String orgCode;

    @ApiModelProperty(value = "单据类型")
    private String docType;

    @ApiModelProperty(value = "申请数量")
    private BigDecimal applyQty;

    @ApiModelProperty(value = "标识")
    private String identify;

    @ApiModelProperty(value = "是否上传")
    private String isUpload;

    @ApiModelProperty(value = "日期")
    private LocalDateTime date;

    @ApiModelProperty(value = "单号")
    private String docNo;

    @ApiModelProperty(value = "项次")
    private String item;

    @ApiModelProperty(value = "SAP工厂")
    private String oldPlantCode;

    @ApiModelProperty(value = "原仓码")
    private String oldWarehoseCode;

    @ApiModelProperty(value = "原鸿海料号")
    private String oldMaterialCode;

    @ApiModelProperty(value = "料号名称")
    private String materialName;

    @ApiModelProperty(value = "原鸿海版次")
    private String oldMaterialVersion;

    @ApiModelProperty(value = "原制造商")
    private String oldMfgName;

    @ApiModelProperty(value = "原制造商料号")
    private String oldMfgMaterial;

    @ApiModelProperty(value = "原制造商版次")
    private String oldMfgVersion;

    @ApiModelProperty(value = "单位")
    private String uom;

    @ApiModelProperty(value = "目的工厂")
    private String targetPlantCode;

    @ApiModelProperty(value = "目的仓码")
    private String targetWarehoseCode;

    @ApiModelProperty(value = "目的鸿海料号")
    private String targetMaterialCode;

    @ApiModelProperty(value = "目的鸿海版次")
    private String targetMaterialVersion;

    @ApiModelProperty(value = "目的制造商")
    private String targetMfgName;

    @ApiModelProperty(value = "目的制造商料号")
    private String targetMfgMaterial;

    @ApiModelProperty(value = "目的制造商版次")
    private String targetMfgVersion;

    @ApiModelProperty(value = "费用代码")
    private String costCode;

    @ApiModelProperty(value = "原因")
    private String reason;

    @ApiModelProperty(value = "上传日期")
    private Date sapUploadData;
    @ApiModelProperty(value = "上传SAP结果")
    private String sapReturnResult;
    @ApiModelProperty(value = "SAP返回信息")
    private String sapReturnMessage;
    @ApiModelProperty(value = "SAP返回单号")
    private String sapReturnNumber;
    @ApiModelProperty(value = "完成数量")
    private BigDecimal completeQty;
    @ApiModelProperty(value = "agileMsg")
    private String agileMsg;

    @ApiModelProperty(value = "成品料号")
    private String productPartNo;

    @ApiModelProperty(value = "手动确认过账数量")
    private BigDecimal confirmPostingQty;

    @ApiModelProperty(value = "flownet流程id")
    private String flownetProcessId;

    @ApiModelProperty(value = "flownet返回描述")
    private String flownetMsg;

    @ApiModelProperty(value = "flownet审批结果")
    private String flownetApprovalResult;

    @ApiModelProperty(value = "flownet表单地址")
    private String flownetUrl;

    @ApiModelProperty(value = "flownet调用结果,SUCCESS")
    private String flownetFlag;

    @ApiModelProperty(value = "flownet返回表单id")
    private String flownetFormId;

    @ApiModelProperty(value = "原料号单价")
    private BigDecimal oldPartNoPrice;

    @ApiModelProperty(value = "原客户名称")
    private String oldCustomerName;

    @ApiModelProperty(value = "目的料号单价")
    private BigDecimal targetPartNoPrice;

    @ApiModelProperty(value = "目的客户名称")
    private String targetCustomerName;

    @ApiModelProperty(value = "刪除标识符")
    private Boolean isDeleted;
}
