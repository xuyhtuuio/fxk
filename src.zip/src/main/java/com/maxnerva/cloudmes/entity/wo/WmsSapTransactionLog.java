package com.maxnerva.cloudmes.entity.wo;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * <p>
 * 过账sap记录表
 * </p>
 *
 * @author likun
 * @since 2022-08-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsSapTransactionLog对象", description="过账sap记录表")
public class WmsSapTransactionLog extends BaseEntity<WmsSapTransactionLog> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id;")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "来源仓码")
    private String fromWarehouseCode;

    @ApiModelProperty(value = "目标仓码")
    private String toWarehouseCode;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "来源单号")
    private String fromDocNo;

    @ApiModelProperty(value = "来源单项次")
    private String fromDocItem;

    @ApiModelProperty(value = "工单detail主键id")
    private Integer wmsWorkOrderDetailId;

    @ApiModelProperty(value = "过账数量")
    private BigDecimal transactionQty;

    @ApiModelProperty(value = "过账sap数量")
    private BigDecimal transactionSapQty;

    @ApiModelProperty(value = "过账日期")
    private LocalDateTime transactionDate;

    @ApiModelProperty(value = "wms单位")
    private String uomCode;

    @ApiModelProperty(value = "sap单位")
    private String sapUomCode;

    @ApiModelProperty(value = "过账类型,参考字典值")
    private String postType;

    @ApiModelProperty(value = "过账sap返回状态")
    private Integer postSapReturnFlag;

    @ApiModelProperty(value = "过账sap返回信息")
    private String postSapReturnMsg;

    @ApiModelProperty(value = "过账sap时间")
    private LocalDateTime postSapReturnDt;
}
