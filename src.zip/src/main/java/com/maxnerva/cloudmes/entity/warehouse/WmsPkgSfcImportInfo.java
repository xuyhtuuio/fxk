package com.maxnerva.cloudmes.entity.warehouse;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2024-10-29
 */
@TableName("wms_pkg_sfc_import_info")
@ApiModel(value = "WmsPkgSfcImportInfo对象", description = "")
@Data
public class WmsPkgSfcImportInfo extends BaseEntity<WmsPkgSfcImportInfo> {

    private static final long serialVersionUID = 1L;

    private Integer id;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("工厂")
    private String plantCode;

    @ApiModelProperty("料号")
    private String partNo;

    @ApiModelProperty("制造商料号")
    private String mfgPartNo;

    @ApiModelProperty("数量")
    private BigDecimal qty;

    @ApiModelProperty("单位")
    private String uomCode;

    @ApiModelProperty("机种")
    private String sfcModelName;

    @ApiModelProperty("版次")
    private String sfcRev;

    @ApiModelProperty("产品系列")
    private String sfcModelSerial;

    @ApiModelProperty("SN")
    private String snNo;
}
