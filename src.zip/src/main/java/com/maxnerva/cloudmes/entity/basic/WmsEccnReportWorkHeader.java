package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2024-01-20
 */
@Data
@TableName("wms_eccn_report_work_header")
@ApiModel(value = "WmsEccnReportWorkHeader对象", description = "")
public class WmsEccnReportWorkHeader implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer id;

    private String orgCode;

    private String workOrderNo;

    @ApiModelProperty(value = "入库数量")
    private BigDecimal inboundQty;

}
