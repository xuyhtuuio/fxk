package com.maxnerva.cloudmes.entity.wo;

import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2024-01-19
 */
@Data
@TableName("wms_work_order_prepare_ckd_ship_header")
@ApiModel(value = "WmsWorkOrderPrepareCkdShipHeader对象", description = "")
public class WmsWorkOrderPrepareCkdShipHeader extends BaseEntity<WmsWorkOrderPrepareCkdShipHeader> {

    private static final long serialVersionUID = 1L;

    private Integer id;

    @ApiModelProperty(value = "流水码")
    private String serialNo;

    @ApiModelProperty(value = "工单")
    private String workOrderNo;

    private String orgCode;

    private String plantCode;

    private String poNo1;

    private String poNo2;

    private String soNo;

    private String dnNo;

    @ApiModelProperty(value = "出货地")
    private String siteCode;

    @ApiModelProperty(value = "出货标识，所有detail是否出货完成 0未完成，1完成")
    private String shipFlag;

    @ApiModelProperty("创建PO：未抛：0，已抛：1")
    private String poPostSapFlag;

    @ApiModelProperty("创建PO抛SAP返回信息")
    private String poPostSapMsg;

    @ApiModelProperty("创建PO抛SAP时间")
    private LocalDateTime poPostSapDate;

    @ApiModelProperty("创建DN：未抛：0，已抛：1")
    private String dnPostSapFlag;

    @ApiModelProperty("创建DN抛SAP返回信息")
    private String dnPostSapMsg;

    @ApiModelProperty("创建DN抛SAP返回信息")
    private LocalDateTime dnPostSapDate;

    @ApiModelProperty("同步收货单结果：0：失败，1：成功")
    private String syncReceiveDocFlag;

    @ApiModelProperty("同步收货单结果描述")
    private String syncReceiveDocMsg;

    @ApiModelProperty("同步收货单时间")
    private LocalDateTime syncReceiveDocDate;

    @ApiModelProperty(value = "货柜ID")
    private Integer containerId;
}
