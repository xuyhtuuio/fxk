package com.maxnerva.cloudmes.entity.trading;

import java.io.Serializable;
import java.util.Date;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 内交对照表
 * @TableName wms_trading_part_relation
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class WmsTradingPartRelation extends BaseEntity<WmsTradingPartRelation> {

    /**
     * 主键id
     */
    @ApiModelProperty(value = "主键id")
    private Integer id;

    /**
     * 內交入bu
     */
    @ApiModelProperty(value = "內交入bu")
    private String fromOrgCode;

    /**
     * 內交出bu
     */
    @ApiModelProperty(value = "內交出bu")
    private String toOrgCode;

    /**
     * 內交出鸿海料号
     */
    @ApiModelProperty(value = "內交出鸿海料号")
    private String fromBuPartNo;

    /**
     * 內交入鸿海料号
     */
    @ApiModelProperty(value = "內交入鸿海料号")
    private String toBuPartNo;

    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;

    /**
     * sap工厂 来源
     */
    @ApiModelProperty(value = "sap工厂 来源")
    private String fromPlantCode;

    /**
     * sap工厂 目标
     */
    @ApiModelProperty(value = "sap工厂 目标")
    private String toPlantCode;

}