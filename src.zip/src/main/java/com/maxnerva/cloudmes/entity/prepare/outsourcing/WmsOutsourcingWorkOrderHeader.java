package com.maxnerva.cloudmes.entity.prepare.outsourcing;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

/**
 * <p>
 * 委外工单信息header表
 * </p>
 *
 * @author likun
 * @since 2023-11-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsOutsourcingWorkOrderHeader对象", description="委外工单信息header表")
public class WmsOutsourcingWorkOrderHeader extends BaseEntity<WmsOutsourcingWorkOrderHeader> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "po编码")
    private String poNo;

    @ApiModelProperty(value = "成品料号")
    private String productPartNo;

    @ApiModelProperty(value = "成品料号版次")
    private String productPartVersion;

    @ApiModelProperty(value = "仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "需求量")
    private BigDecimal requiredQuantity;

    @ApiModelProperty(value = "已入库数量")
    private BigDecimal inboundQty;

    @ApiModelProperty(value = "供应商代码")
    private String vendorCode;
}
