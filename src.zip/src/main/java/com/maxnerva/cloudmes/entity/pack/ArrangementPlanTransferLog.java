package com.maxnerva.cloudmes.entity.pack;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;
import java.util.Date;

/**
 * @ClassName ArrangementPlanTransferLog
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/6/10 上午 10:41
 * @Version 1.0
 **/
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("wms_arrangement_plan_transfer_log")
public class ArrangementPlanTransferLog {

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    //排配计划类型 日排/周排 目前只有日排，周排不做抛转   1：日排
    @TableField("plan_type")
    private Integer planType;
    //日排配日期
    @JsonFormat(pattern="yyyy-MM-dd",timezone="GMT+8")
    @TableField("arrangement_date")
    private Date arrangementDate;
    //抛转方名称，目前只有JIT-EDI
    @TableField("transfer_to_name")
    private String transferToName;
    //抛转结果状态 0：成功 1：失败 2：未抛转
    @TableField("transfer_result_status")
    private Integer transferResultStatus;
    //抛转结果信息
    @TableField("transfer_result_msg")
    private String transferResultMsg;
    //返回抛转结果时间
    @TableField("return_result_date")
    private LocalDateTime returnResultDate;
    //抛转日期
    @TableField("transfer_date")
    private LocalDateTime transferDate;
    //数据抛转人
    @TableField("transfer_by")
    private String transferBy;

    /**
     * @description:    添加bu信息用于区分 各个bu数据
     * @author:  BZG
     * @date:  2021/9/29
     */
    //所属bu
    @TableField("bu")
    private String bu;
    //bu编码
    @TableField("bu_code")
    private String buCode;

    public ArrangementPlanTransferLog(){}
    public ArrangementPlanTransferLog(Integer planType,Date arrangementDate,String transferToName,
                                      Integer transferResultStatus,LocalDateTime transferDate,String transferBy,String bu,String buCode) {
        this.planType = planType;
        this.arrangementDate = arrangementDate;
        this.transferToName = transferToName;
        this.transferResultStatus = transferResultStatus;
        this.transferDate = transferDate;
        this.transferBy = transferBy;
        this.bu = bu;
        this.buCode = buCode;
    }

}
