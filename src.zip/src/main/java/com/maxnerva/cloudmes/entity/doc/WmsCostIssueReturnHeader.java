package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.common.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;

@ApiModel("费领退管理dto")
@Data
public class WmsCostIssueReturnHeader extends BaseEntity {

    @TableId(type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "工厂组织")
    private String orgCode;

    @ApiModelProperty(value = "SAP工厂")
    private String plantCode;

    @ApiModelProperty(value = "费领/退单号(系统根据规则自动生成)")
    private String docNo;

    @ApiModelProperty(value = "单据类型")
    private String type;

    @ApiModelProperty(value = "单据小类")
    private String docType;

    @ApiModelProperty(value = "单据日期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime docDate;

    @ApiModelProperty(value = "费用代码")
    private String costCode;

    @ApiModelProperty(value = "单据状态")
    private String status;

    @ApiModelProperty(value = "审批进度")
    private String approvalProgress;

    @ApiModelProperty(value = "申请部门")
    private Integer applyDeptId;

    @ApiModelProperty(value = "申请部门名称")
    private String applyDeptName;

    @ApiModelProperty(value = "领料类型")
    private String issueType;

    @ApiModelProperty(value = "领料区分")
    private String issueDiff;

    @ApiModelProperty(value = "费用吸收")
    private String costAbsorb;

    @ApiModelProperty(value = "申请人工号")
    private String applyStaffCode;

    @ApiModelProperty(value = "申请人姓名")
    private String applyStaffName;

    @ApiModelProperty(value = "申请人分机")
    private String applyStaffExtension;

    @ApiModelProperty(value = "原因")
    private String reason;

    @ApiModelProperty(value = "异动类型")
    private String movementType;

    @ApiModelProperty(value = "说明")
    private String docDesc;

    @ApiModelProperty(value = "客户名称")
    private String customerName;

    @ApiModelProperty(value = "专案名称")
    private String projectName;

    @ApiModelProperty(value = "专案编码")
    private String projectCode;

    @ApiModelProperty(value = "报废类别")
    private String scrapCategory;

    @ApiModelProperty(value = "报废类型")
    private String scrapType;

    @ApiModelProperty(value = "报废区分")
    private String scrapDiff;

    @ApiModelProperty(value = "费领退分类")
    private String costClassify;

    @ApiModelProperty(value = "索赔单号")
    private String claimNo;

    @ApiModelProperty(value = "总金额")
    private String totalPrice;

    @ApiModelProperty(value = "币别")
    private String coinType;

    @ApiModelProperty(value = "flownet返回url")
    private String flownetUrl;

    @ApiModelProperty(value = "flownet调用结果")
    private String flownetFlag;

    @ApiModelProperty(value = "flownet返回表单id")
    private String flownetFormId;

    @ApiModelProperty(value = "flownet返回描述")
    private String flownetMsg;

    @ApiModelProperty(value = "flownet审批结果")
    private String flownetApprovalResult;

    @ApiModelProperty(value = "flownet流程id")
    private String flownetProcessId;

    @ApiModelProperty(value = "是否整体过账")
    private Boolean bulkPosting;

    @ApiModelProperty(value = "删除标识")
    private Boolean isDeleted;
}
