package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.maxnerva.cloudmes.common.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.math.BigDecimal;

@ApiModel(value = "费领退明细管理")
@Data
public class WmsCostIssueReturnDetail extends BaseEntity {
    @TableId(type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "工厂组织")
    private String orgCode;

    @ApiModelProperty(value = "行号")
    private Integer lineNo;

    @ApiModelProperty(value = "费领退主表id")
    private Integer wmsCostIssueReturnId;

    @ApiModelProperty(value = "是否保税")
    private Boolean isBonded;

    @ApiModelProperty(value = "仓码")
    private String warehouseCode;

    @ApiModelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "物料单位")
    private String uomCode;

    @ApiModelProperty(value = "鸿海料号版次")
    private String partNoVersion;

    @ApiModelProperty(value = "名称")
    private String name;

    @ApiModelProperty(value = "valuationType")
    private String valuationType;

    @ApiModelProperty(value = "数量")
    private BigDecimal qty;

    @ApiModelProperty(value = "单价")
    private BigDecimal price;

    @ApiModelProperty(value = "总价")
    private BigDecimal totalPrice;

    @ApiModelProperty(value = "物料采购员")
    private String mcid;

    @ApiModelProperty(value = "完成数量")
    private BigDecimal completedQty;

    @ApiModelProperty(value = "报废原因")
    private String scrapReason;

    @ApiModelProperty(value = "币别")
    private String coinType;

    @ApiModelProperty(value = "用户手动确认过账Y，N没确认")
    private String userConfirmPostingFlag;

    @ApiModelProperty(value = "用户手动确认过账数量")
    private BigDecimal confirmPostingQty;

    @ApiModelProperty(value = "物料描述")
    private String partDesc;

    @ApiModelProperty(value = "删除标识")
    private Boolean isDeleted;

    @ApiModelProperty(value = "确认过账人")
    private String confirmBy;

    @ApiModelProperty("汇率")
    private BigDecimal exchangeRate;

    @ApiModelProperty(value = "抛转SPM标识,Y-需要 N-不需要")
    private String postSpmFlag;

    @ApiModelProperty(value = "抛转SPM成功标识 0-未成功 1-成功")
    private String toSpmFlag;

    @ApiModelProperty(value = "报废处理栈板号（只有报废处理导入使用，其它情况不要用！）")
    private String scrapHandlePalletNo;

    @ApiModelProperty(value = "LRR箱号（只有LRR费退导入使用，其它情况不要用！）")
    private String lrrCartonNo;

    @ApiModelProperty(value = "SWR任务单号（只有SWR费退，报废导入时使用，其它情况不要用！！！）")
    private String swrDocNo;
}
