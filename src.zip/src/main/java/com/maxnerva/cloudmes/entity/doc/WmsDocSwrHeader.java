package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.Valid;

/**
 * <p>
 * SWR沾锡验证单
 * </p>
 *
 * @author baomidou
 * @since 2025-03-29
 */
@EqualsAndHashCode(callSuper = true)
@TableName("wms_doc_swr_header")
@ApiModel(value = "WmsDocSwrHeader对象", description = "SWR沾锡验证单")
@Data
public class WmsDocSwrHeader extends BaseEntity<WmsDocSwrHeader> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("工厂")
    private String plantCode;

    @ApiModelProperty("仓码")
    private String warehouseCode;

    @ApiModelProperty("任务单号")
    private String docNo;

    @ApiModelProperty("工单号")
    private String workOrderNo;

    @ApiModelProperty("鸿海料号")
    private String partNo;

    @ApiModelProperty("厂商料号")
    private String supplierPartNo;

    @ApiModelProperty("厂商名")
    private String mfgName;

    @ApiModelProperty("原始DC")
    private String originalDateCode;

    @ApiModelProperty("成品料号")
    private String finishPartNo;

    @ApiModelProperty("客户")
    private String customer;

    @ApiModelProperty("验证PKGID")
    private String checkPkgId;

    @ApiModelProperty("验证数量")
    private BigDecimal checkQty;

    @ApiModelProperty("分盘操作人")
    private String splitPkgEmpNo;

    @ApiModelProperty("PKG明细附件地址")
    private String pkgInfoFileUrl;

    @ApiModelProperty("PKG附件名")
    private String pkgInfoFileName;

    @ApiModelProperty("物控")
    private String originator;

    @ApiModelProperty("验证接收人")
    private String checkAcceptEmpNo;

    @ApiModelProperty("沾锡报告文件列表")
    private String checkReportFileList;

    @ApiModelProperty("沾锡验证结果 NG,OK")
    private String checkResult;

    @ApiModelProperty("SQE确认 N,Y（是否上传沾锡报告）")
    private String sqeConfirmFlag;

    @ApiModelProperty("沾锡说明")
    private String checkRemark;

    @ApiModelProperty("单据状态")
    private String status;

    @ApiModelProperty("是否MSD物料 N,Y")
    private String msdFlag;

    @ApiModelProperty("客户邮件文件地址")
    private String customerMailFileList;

    @ApiModelProperty("客户邮件确认 N,Y")
    private String customerConfirmFlag;

    @ApiModelProperty("客人是否同意 OK,NG")
    private String customerResult;

    @ApiModelProperty(value = "客人确认备注")
    private String customerRemark;

    @ApiModelProperty("报废单号")
    private String scrapDocNo;

    @ApiModelProperty("费退单号")
    private String returnDocNo;

    @ApiModelProperty("物料描述")
    private String materialDesc;

    @ApiModelProperty("验证接收时间")
    private LocalDateTime checkAcceptDt;

    @ApiModelProperty("上传沾锡报告时间")
    private LocalDateTime checkDt;

    @ApiModelProperty("客人确认时间")
    private LocalDateTime customerDt;

    @ApiModelProperty("工单计划时间")
    private LocalDateTime apsWoBeginDatetime;

    @ApiModelProperty("费退仓码")
    private String toScrapWarehouseCode;

    @ApiModelProperty("验证PKG的原条码")
    private String checkOriginalPkgId;
}
