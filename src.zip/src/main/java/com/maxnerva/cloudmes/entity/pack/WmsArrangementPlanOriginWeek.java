package com.maxnerva.cloudmes.entity.pack;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;
import java.util.Date;

/**
 * @ClassName WmsArrangementPlanOriginWeek
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/6/9 下午 03:56
 * @Version 1.0
 **/
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("wms_arrangement_plan_origin_week")
public class WmsArrangementPlanOriginWeek extends Model<WmsArrangementPlanOriginWeek> {
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    //日期
    @JsonFormat(pattern="yyyy-MM-dd",timezone="GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @TableField("arrangement_date")
    private Date arrangementDate;
    //日期 用于接收前端Excel解析出long类型的日期
    @TableField(exist = false)
    private Long dateReceive;
    //鸿海料号
    @TableField("hh_pn")
    private String hhPn;
    //运输方式
    private String transportation;
    //排配数量
    @TableField("arrangement_num")
    private Integer arrangementNum;
    //周别
    private String week;
    //客户料号
    @TableField("customer_pn")
    private String customerPn;
    //出货地
    @TableField("shipment_to")
    private String shipmentTo;
    //so
    private String so;
    //导入年份
    @TableField("import_year")
    private Integer importYear;
    //导入周别
    @TableField("import_week")
    private String importWeek;
    //导入人
    @TableField("import_by")
    private String importBy;
    //导入时间
    @TableField("import_dt")
    private LocalDateTime importDt;
    //计算状态 0:未计算1:计算中2:完成3:失败
    @TableField("calculate_state")
    private Integer calculateState;
    //计算信息
    @TableField("calculate_mes")
    private String calculateMes;
    /**
     * @description:    添加bu信息用于区分 各个bu数据
     * @author:  BZG
     * @date:  2021/9/29
     */
    //所属bu
    @TableField("bu")
    private String bu;
    //bu编码
    @TableField("bu_code")
    private String buCode;
}
