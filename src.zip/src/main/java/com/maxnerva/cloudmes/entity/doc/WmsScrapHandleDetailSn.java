package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 报废品处理绑定SN
 * </p>
 *
 * @author baomidou
 * @since 2024-08-01
 */
@TableName("wms_scrap_handle_detail_sn")
@ApiModel(value = "WmsScrapHandleDetailSn对象", description = "报废品处理绑定SN")
@Data
public class WmsScrapHandleDetailSn extends BaseEntity<WmsScrapHandleDetailSn> {
    private Integer id;

    @ApiModelProperty("工厂组织")
    private String orgCode;

    @ApiModelProperty("工厂")
    private String plantCode;

    @ApiModelProperty("单号（关联detail）")
    private String docNo;

    @ApiModelProperty("条码")
    private String pkgId;

    @ApiModelProperty("料号")
    private String partNo;

    @ApiModelProperty(value = "版次")
    private String partVersion;

    @ApiModelProperty("SN")
    private String snNo;
}
