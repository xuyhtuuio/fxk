package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="員工工時", description="員工工時")
public class WmsStaffWorkingHour {
    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    @TableId
    private Integer id;

    String orgCode;

    LocalDate workDate;

    @ApiModelProperty(value = "员工工时，例：8、8.5")
    BigDecimal hour;

    String staffCode;

}
