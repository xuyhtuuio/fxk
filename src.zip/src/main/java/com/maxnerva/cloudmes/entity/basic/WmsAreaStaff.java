package com.maxnerva.cloudmes.entity.basic;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 库区员工绑定表
 * </p>
 *
 * @author likun
 * @since 2022-09-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsAreaStaff对象", description="库区员工绑定表")
public class WmsAreaStaff extends BaseEntity<WmsAreaStaff> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "自增主键")
    private Integer id;

    @ApiModelProperty(value = "库区主键id")
    private Integer wmsAreaId;

    @ApiModelProperty(value = "员工id")
    private Integer staffId;

    @ApiModelProperty(value = "BU(业务单元)")
    private String orgCode;

    @ApiModelProperty(value = "库区编码")
    private String areaCode;
}
