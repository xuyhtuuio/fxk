package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.common.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;

@ApiModel("准时达收货")
@Data
public class WmsJusdaReceipt extends BaseEntity {

    @TableId(type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "SAP工厂")
    private String plantCode;

    @ApiModelProperty(value = "VMIHUB 中的工厂别")
    private String siteName;

    @ApiModelProperty(value = "供应商名称别")
    private String supplierName;

    @ApiModelProperty(value = "Foxconn BU代碼")
    private String customerName;

    @ApiModelProperty(value = "出货单号")
    private String shipId;

    @ApiModelProperty(value = "來源國")
    private String originOfCountry;

    @ApiModelProperty(value = "供應商代碼")
    private String customerSupplierNo;

    @ApiModelProperty(value = "供應商料號")
    private String supplierPartNo;

    @ApiModelProperty(value = "BU料號")
    private String customerPartNo;

    @ApiModelProperty(value = "供應商料號版次")
    private String spnVersion;

    @ApiModelProperty(value = "BU料號版次")
    private String cpnVersion;

    @ApiModelProperty(value = "制造商簡稱")
    private String manufacture;

    @ApiModelProperty(value = "出貨時間")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date shipDt;

    @ApiModelProperty(value = "出貨數量")
    private BigDecimal shipedQty;

    @ApiModelProperty(value = "單位")
    private String uom;

    @ApiModelProperty(value = "EDI862 ID")
    private String pullListNo;

    @ApiModelProperty(value = "EDI862文件ID號碼項次")
    private String pullListItem;

    @ApiModelProperty(value = "報關PO號碼")
    private String customPo;

    @ApiModelProperty(value = "報關PO項次")
    private String customPoItem;

    @ApiModelProperty(value = "報關單號")
    private String customDocNo;

    @ApiModelProperty(value = "報關單項次")
    private String customDocItemNo;

    @ApiModelProperty(value = "VMI GRN NO")
    private String grnNo;

    @ApiModelProperty(value = "工單號")
    private String workOrderNo;

    @ApiModelProperty(value = "Supplier PO單號")
    private String customerPo;

    @ApiModelProperty(value = "Supplier Po單項次")
    private String customerPoItem;

    @ApiModelProperty(value = "物料進口類型")
    private String inboundType;

    @ApiModelProperty(value = "預計到貨時間")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date eta;

    @ApiModelProperty(value = "最小出货单位包规")
    private String boxQty;

    @ApiModelProperty(value = "EDI856文件唯一的ID")
    private String documentId;

    @ApiModelProperty(value = "出貨類型(H2S,H2C)")
    private String soType;

    @ApiModelProperty(value = "內交單號")
    private String innerTransferNo;

    @ApiModelProperty(value = "內交單號項次")
    private String innerTransferNoItem;

    @ApiModelProperty(value = "物料單價")
    private String unitPrice;

    @ApiModelProperty(value = "参考栏位1")
    private String reference1;

    @ApiModelProperty(value = "参考栏位2")
    private String reference2;

    @ApiModelProperty(value = "参考栏位3")
    private String reference3;

    @ApiModelProperty(value = "参考栏位4")
    private String reference4;

    @ApiModelProperty(value = "参考栏位5")
    private String reference5;


    @ApiModelProperty(value = "收货类型（VMI、CMI）")
    private String receivedType;

    @ApiModelProperty(value = "上传日期")
    private String sapUploadData;

    @ApiModelProperty(value = "上传SAP结果（0：失败；1：成功）")
    private String sapReturnResult;

    @ApiModelProperty(value = "SAP返回信息")
    private String sapReturnMessage;

    @ApiModelProperty(value = "SAP返回单号")
    private String sapReturnNumber;

    @ApiModelProperty(value = "收货数量")
    private BigDecimal receivedQty;

    @ApiModelProperty(value = "组织")
    private String orgCode;

    @ApiModelProperty("抛jusda标识")
    private Boolean postJusdaFlag;

    @ApiModelProperty("抛jusda日期")
    private LocalDateTime postJusdaDate;

    @ApiModelProperty("抛jusda信息")
    private String postJusdaMessage;

    @ApiModelProperty("vmi采购单号")
    private String vmiPoNumber;

    @ApiModelProperty("vmi采购项次")
    private String vmiPoItem;

    @ApiModelProperty("vmiWarehouseCode")
    private String vmiWarehouseCode;

    @ApiModelProperty("postJusdaRecevieCompletedFlag")
    private Boolean postJusdaRecevieCompletedFlag;

    @ApiModelProperty("postJusdaRecevieCompletedDate")
    private LocalDateTime postJusdaRecevieCompletedDate;

    @ApiModelProperty("postJusdaRecevieCompletedMsg")
    private String postJusdaRecevieCompletedMsg;

    @ApiModelProperty("customerReceiveType")
    private String customerReceiveType;

    @ApiModelProperty("收货完成时间")
    private LocalDateTime receiveCompletedDate;

    @ApiModelProperty("fromWarehouseCode")
    private String fromWarehouseCode;

    @ApiModelProperty("toWarehouseCode")
    private String toWarehouseCode;

    @ApiModelProperty("勾兌报关单号")
    private String blendingCusNo;

    @ApiModelProperty("勾兌报关单项次")
    private String blendingCusItem;

    @ApiModelProperty("勾兑报关单异常信息")
    private String blendingCusMessage;

    @ApiModelProperty("勾兑报关单时间")
    private LocalDateTime blendingCusDatetime;

    @ApiModelProperty(value = "0 未勾兑，1勾兑成功，2ecus未查询到报关单")
    private String blendingCusFlag;
}
