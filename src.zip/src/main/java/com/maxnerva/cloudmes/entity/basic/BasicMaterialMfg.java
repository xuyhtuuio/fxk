package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDate;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 制造商料号表	
 * </p>
 *
 * @author baomidou
 * @since 2023-12-11
 */
@TableName("basic_sys.basic_material_mfg")
@ApiModel(value = "BasicMaterialMfg对象", description = "制造商料号表")
@Data
public class BasicMaterialMfg implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键id")
    private Integer id;

    @ApiModelProperty("物料ID")
    private Integer materialId;

    @ApiModelProperty("制造商料号")
    private String mfgMaterialCode;

    @ApiModelProperty("制造商料号描述")
    private String mfgMaterialName;

    @ApiModelProperty("制造商版次")
    private String mfgMaterialVersion;

    @ApiModelProperty("制造商原始料号")
    private String mfgOriginalMaterial;

    @ApiModelProperty("有效期（天）")
    private Integer validPeriod;

    @ApiModelProperty("有效期开始时间")
    private LocalDate startValidDate;

    @ApiModelProperty("有效期结束时间")
    private LocalDate endValidDate;

    @ApiModelProperty("生产日期格式")
    private String datecodeFormat;

    @ApiModelProperty("MSD等级")
    private String msdLevel;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty("创建人code")
    private String creator;

    @ApiModelProperty("创建人id")
    private Integer creatorId;

    @ApiModelProperty("创建时间")
    private Long createdDt;

    @ApiModelProperty("最后一次编辑人code")
    private String lastEditor;

    @ApiModelProperty("最后一次编辑人id")
    private Integer lastEditorId;

    @ApiModelProperty("最后一次编辑时间")
    private Long lastEditedDt;

    private String orgCode;

    @ApiModelProperty("是否删除")
    private Boolean isDeleted;

    @ApiModelProperty("制造商名称")
    private String mfgName;

    @ApiModelProperty("料号")
    private String materialNo;

    @ApiModelProperty("包装数量")
    private Integer packQty;

    @ApiModelProperty("品名")
    private String category;

    @ApiModelProperty("sap工厂编码")
    private String plantCode;

    @ApiModelProperty(value = "箱包规")
    private String packRule;

    @ApiModelProperty(value = "包装形式")
    private String packType;

    @ApiModelProperty(value = "盘尺寸")
    private String feedSize;
}
