package com.maxnerva.cloudmes.entity.tencent;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 腾讯订单sn绑定记录表
 * </p>
 *
 * @author likun
 * @since 2025-05-21
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsTencentDeliverySnBindRecord对象", description="腾讯订单sn绑定记录表")
public class WmsTencentDeliverySnBindRecord extends BaseEntity<WmsTencentDeliverySnBindRecord> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "订货单编码")
    private String poNumber;

    @ApiModelProperty(value = "订货单明细ID")
    private String detailId;

    @ApiModelProperty(value = "sn号")
    private String snNo;

    @ApiModelProperty(value = "出货明细id")
    private Integer shipDetailId;

    @ApiModelProperty("箱号")
    private String cartonNo;
}
