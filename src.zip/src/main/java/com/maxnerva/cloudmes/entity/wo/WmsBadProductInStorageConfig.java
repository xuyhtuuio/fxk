package com.maxnerva.cloudmes.entity.wo;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Description 不良品入库仓码配置
 **/
@EqualsAndHashCode(callSuper = true)
@ApiModel("不良品入库仓码配置")
@Data
public class WmsBadProductInStorageConfig extends BaseEntity<WmsBadProductInStorageConfig> {

    @ApiModelProperty("主键id")
    private Integer id;

    @ApiModelProperty("orgCode")
    private String orgCode;

    @ApiModelProperty("SAP工厂")
    private String plantCode;

    @ApiModelProperty("from仓码")
    private String fromWarehouseCode;

    @ApiModelProperty("from仓码描述")
    private String fromWarehouseRemark;

    @ApiModelProperty("to仓码")
    private String toWarehouseCode;

    @ApiModelProperty("to仓码描述")
    private String toWarehouseRemark;

    @ApiModelProperty("不良分类")
    private String badClassify;
}
