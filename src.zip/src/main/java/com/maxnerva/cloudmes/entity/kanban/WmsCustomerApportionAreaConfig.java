package com.maxnerva.cloudmes.entity.kanban;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2025-05-30
 */
@EqualsAndHashCode(callSuper = true)
@TableName("wms_customer_apportion_area_config")
@ApiModel(value = "WmsCustomerApportionAreaConfig对象", description = "")
@Data
public class WmsCustomerApportionAreaConfig extends BaseEntity<WmsCustomerApportionAreaConfig> {

    private static final long serialVersionUID = 1L;

    private Integer id;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("区域名称")
    private String areaName;

    @ApiModelProperty("总面积")
    private BigDecimal areaNum;

    @ApiModelProperty("库区集合【,隔开】")
    private String areaCode;

    @ApiModelProperty("面积分配方式描述")
    private String description;

    @ApiModelProperty("排序")
    private Integer index;
}
