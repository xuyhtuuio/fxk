package com.maxnerva.cloudmes.entity.wo;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>
 * 工单ckd备料记录表
 * </p>
 *
 * @author likun
 * @since 2022-09-19
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsWorkOrderPrepareCkdLog对象", description="工单ckd备料记录表")
public class WmsWorkOrderPrepareCkdLog extends BaseEntity<WmsWorkOrderPrepareCkdLog> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "pkg")
    private String pkgId;

    @ApiModelProperty(value = "父pkg")
    private String parentPkgId;

    @ApiModelProperty(value = "BU（业务单元）")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "储位id")
    private Integer wmsBinId;

    @ApiModelProperty(value = "储位编码")
    private String binCode;

    @ApiModelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "原始数量")
    private BigDecimal originalQty;

    @ApiModelProperty(value = "当前数量")
    private BigDecimal currentQty;

    @ApiModelProperty(value = "操作数量")
    private BigDecimal transactionQty;

    @ApiModelProperty(value = "供应商料号")
    private String supplierPartNo;

    @ApiModelProperty(value = "制造商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "解析dateCode")
    private LocalDate dateCode;

    @ApiModelProperty(value = "原始dateCode")
    private String originalDateCode;

    @ApiModelProperty(value = "批次号")
    private String lotNo;

    @ApiModelProperty(value = "上架时间")
    private LocalDateTime shelfDate;

    @ApiModelProperty(value = "wms单号")
    private String wmsNo;

    @ApiModelProperty(value = "锁定标识")
    private Integer lockFlag;

    @ApiModelProperty(value = "锁定状态")
    private String lockStatus;

    @ApiModelProperty(value = "锁定时间")
    private LocalDateTime lockDt;

    @ApiModelProperty(value = "lock原因")
    private String lockMessage;

    @ApiModelProperty(value = "工单")
    private String workOrderNo;

    @ApiModelProperty(value = "异动类型编码，参考字典")
    private String transactionType;

    @ApiModelProperty(value = "异动类型字典值")
    private String transactionMessage;

    @ApiModelProperty(value = "检验日期")
    private LocalDate checkDate;

    @ApiModelProperty(value = "有效日期")
    private Integer effectiveDate;

    @ApiModelProperty(value = "有效期截止时间")
    private LocalDate endDate;

    @ApiModelProperty(value = "载具id")
    private Integer wmsVehicleId;

    @ApiModelProperty(value = "载具编码")
    private String vehicleCode;

    @ApiModelProperty(value = "是否抛转sfc标识")
    private Boolean wmsToSfcFlag;

    @ApiModelProperty(value = "wms抛转sfc标识")
    private Integer postSfcFlag;

    @ApiModelProperty(value = "wms抛转sfc时间")
    private LocalDateTime postSfcDt;

    @ApiModelProperty(value = "抛转sfc返回信息")
    private String postSfcReturnMessage;

    @ApiModelProperty(value = "工单绑定位置")
    private String workOrderToLocation;

    @ApiModelProperty(value = "来源仓码")
    private String fromWarehouseCode;

    @ApiModelProperty(value = "工单群组")
    private String workOrderItem;

    @ApiModelProperty(value = "消耗数量")
    private BigDecimal consumeQty;

    @ApiModelProperty(value = "栈板编号")
    private String palletCode;

    @ApiModelProperty(value = "箱号")
    private String cartonCode;

    @ApiModelProperty(value = "制造商名称")
    private String mfgName;

    @ApiModelProperty(value = "原产国1")
    private String placeOfOrigin1;

    @ApiModelProperty(value = "原产国2")
    private String placeOfOrigin2;

    @ApiModelProperty(value = "干燥剂")
    private String desiccant;

    @ApiModelProperty(value = "电池")
    private String battery;

    @ApiModelProperty(value = "风扇")
    private String fan;

    @ApiModelProperty(value = "栈板材质")
    private String palletMaterial;

    @ApiModelProperty(value = "是否箱出")
    private Boolean isCartonOut;

    @ApiModelProperty(value = "毛重")
    private BigDecimal grossWeight;

    @ApiModelProperty(value = "体积")
    private String volume;

    @ApiModelProperty(value = "位置")
    private String positionCode;

    @ApiModelProperty(value = "货柜号")
    private String containerCode;

    @ApiModelProperty(value = "是否出货，0未出货, 1出货完成")
    private Integer shipFlag;

    @ApiModelProperty(value = "收货PO")
    private String po;

    @ApiModelProperty(value = "收货PO项次")
    private String poItem;

    @ApiModelProperty(value = "报关料号")
    private String customsPartNo;

    @ApiModelProperty(value = "报关单号")
    private String cusNo ;

    @ApiModelProperty(value = "报关项次")
    private String cusItem ;

    @ApiModelProperty(value = "报关单价")
    private BigDecimal cusPrice;

    @ApiModelProperty(value = "单位净重")
    private BigDecimal cusWeightUne;

    @ApiModelProperty(value = "该项次净重 （cus_weight_une * 数量）")
    private BigDecimal cusWeight;

    @ApiModelProperty(value = "中文品名")
    private String cusGoodName;

    @ApiModelProperty(value = "商品编码")
    private String cusGoodNo;

    @ApiModelProperty(value = "包装方式")
    private String packingMethod;

    @ApiModelProperty(value = "CUS申报要素")
    private String cusSpec;

    @ApiModelProperty(value = "CUS原产国")
    private String cusPlaceOfOrigin1;

    @ApiModelProperty(value = "出货生成DN序列号")
    private String serialNo;

    @ApiModelProperty(value = "运输方式")
    private String transportMode;

    @ApiModelProperty(value = "保税性质")
    private String bondedType;

    @ApiModelProperty(value = "是否为成品")
    private Boolean productFlag;

    @ApiModelProperty(value = "进口时间")
    private LocalDate cusDate;

    @ApiModelProperty(value = "物料类型 0 一般物料，1 电池")
    private String materialSort;
}
