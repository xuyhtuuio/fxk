package com.maxnerva.cloudmes.entity.deliver;

import com.maxnerva.cloudmes.common.models.entity.BaseEntity;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class WmsShipPkgRecord extends BaseEntity {
    private Integer id;

    private Integer shipDetailId;

    private String pkgId;

    private String partNo;
    private BigDecimal qty;
    private String sapWarehouseCode;
    private String binCode;
    private String assetId;
    private String workOrder;
    private String vehicleCode;
    private String locationCode;
    private String orgCode;
    private String ipn;
    private String modelSerial;
    private String modelNameSfc;
    private Boolean isDeleted;
    private String palletNo;
}
