package com.maxnerva.cloudmes.entity.deliver;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

/**
 * <p>
 * 成品出货称重表
 * </p>
 *
 * @author likun
 * @since 2023-09-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsShipProductWeigh对象", description="成品出货称重表")
public class WmsShipProductWeigh extends BaseEntity<WmsShipProductWeigh> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "条码")
    private String pkgId;

    @ApiModelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "单位")
    private String uomCode;

    @ApiModelProperty(value = "物料分类")
    private String materialCategory;

    @ApiModelProperty(value = "客户名称")
    private String cusName;

    @ApiModelProperty(value = "重量")
    private BigDecimal weight;

    @ApiModelProperty(value = "毛重上限值（KG）")
    private BigDecimal uslKg;

    @ApiModelProperty(value = "毛重下限值（KG）")
    private BigDecimal lslKg;

    @ApiModelProperty(value = "出货单号")
    private String docNo;

    @ApiModelProperty(value = "dn单号")
    private String dnNo;
}
