package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.TableId;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 库区表
 * </p>
 *
 * @author likun
 * @since 2022-07-20
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsArea对象", description="库区表")
public class WmsArea extends BaseEntity<WmsArea> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    @TableId
    private Integer id;

    @ApiModelProperty(value = "BU(业务单元)")
    private String orgCode;

    @ApiModelProperty(value = "库区编码")
    private String areaCode;

    @ApiModelProperty(value = "库区名称")
    private String areaName;

    @ApiModelProperty(value = "sap仓码，多个用逗号隔开,默认ALL")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "厂区名称，wms系统")
    private String factoryAreaName;

    @ApiModelProperty(value = "楼栋")
    private String building;

    @ApiModelProperty(value = "楼层")
    private String storey;

    @ApiModelProperty(value = "排序")
    private Integer operateSequence;

    @ApiModelProperty(value = "是否启用(false-否 true-是)，默认false")
    private Boolean isEnable;

    @ApiModelProperty(value = "描述")
    private String remark;

    @ApiModelProperty(value = "库区类别")
    private String areaCategory;

    @ApiModelProperty(value = "是否Eccn,默认false")
    private Boolean isEccn;
}
