package com.maxnerva.cloudmes.entity.prepare;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * <p>
 * 捡料任务表
 * </p>
 *
 * @author likun
 * @since 2023-07-11
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value = "WmsWorkOrderPickTask对象", description = "捡料任务表")
public class WmsWorkOrderPickTask extends BaseEntity<WmsWorkOrderPickTask> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU（业务单元）")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "工单群组")
    private String workOrderItem;

    @ApiModelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "需求数")
    private BigDecimal reqQty;

    @ApiModelProperty(value = "备料量")
    private BigDecimal stockQty;

    @ApiModelProperty(value = "机台编号")
    private String machineCode;

    @ApiModelProperty(value = "轨道号")
    private String feederNo;

    @ApiModelProperty(value = "紧急叫料信息")
    private String urgentPickMessage;

    @ApiModelProperty(value = "锁料人")
    private String lockEmpNo;

    @ApiModelProperty(value = "锁料时间")
    private LocalDateTime lockDateTime;

    @ApiModelProperty(value = "任务号")
    private String taskNo;

    @ApiModelProperty(value = "任务类型(ASSY,叫料)")
    private String taskType;

    @ApiModelProperty(value = "任务完成标识")
    private String taskCompletedFlag;

    @ApiModelProperty(value = "优先级")
    private Integer priority;

    @ApiModelProperty(value = "管控模式")
    private String scanMode;

    @ApiModelProperty(value = "版次")
    private String partVersion;
}
