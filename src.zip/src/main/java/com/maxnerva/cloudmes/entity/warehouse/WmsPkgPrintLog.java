package com.maxnerva.cloudmes.entity.warehouse;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>
 * 条码打印信息记录表
 * </p>
 *
 * @author likun
 * @since 2022-09-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsPkgPrintLog对象", description="条码打印信息记录表")
public class WmsPkgPrintLog extends BaseEntity<WmsPkgPrintLog> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "条码号")
    private String pkgId;

    @ApiModelProperty(value = "父pkgid")
    private String parentPkgId;

    @ApiModelProperty(value = "父条码数量")
    private BigDecimal parentQty;

    @ApiModelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "条码数量")
    private BigDecimal qty;

    @ApiModelProperty(value = "打印类型编码,参考字典")
    private String printType;

    @ApiModelProperty(value = "打印类型编码名称,参考字典值")
    private String printMessage;

    @ApiModelProperty(value = "制造商名称")
    private String mfgName;

    @ApiModelProperty(value = "制造商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "解析d/c")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate dateCode;

    @ApiModelProperty(value = "原始d/c")
    private String originalDateCode;

    @ApiModelProperty(value = "lot code")
    private String lotCode;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "BU(业务单元)")
    private String orgCode;

    @ApiModelProperty(value = "打印操作员")
    private String printOperator;

    @ApiModelProperty(value = "打印时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime printDt;
}
