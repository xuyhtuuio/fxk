package com.maxnerva.cloudmes.entity.warehouse;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * buySell物料采集表
 * </p>
 *
 * @author likun
 * @since 2023-09-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsBuySellMaterialCollectRecord对象", description="buySell物料采集表")
public class WmsBuySellMaterialCollectRecord extends BaseEntity<WmsBuySellMaterialCollectRecord> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "条码")
    private String pkgId;

    @ApiModelProperty(value = "BOXID")
    private String boxId;

    @ApiModelProperty(value = "SN")
    private String snNo;

    @ApiModelProperty(value = "采集类型")
    private String scanMethod;
}
