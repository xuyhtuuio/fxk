package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.common.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@ApiModel("费领退管理dto")
@Data
public class WmsCostCenterConfig extends BaseEntity {

    private Integer id;

    @ApiModelProperty(value = "工厂组织")
    private String orgCode;

    @ApiModelProperty(value = "SAP工厂")
    private String plantCode;

    @ApiModelProperty("费用代码")
    private String costCenter;

    @ApiModelProperty("费用代码描述")
    private String costCenterDesc;

    private String profitCenter;

    private String group1;

    private String group2;

    private String remark;

}
