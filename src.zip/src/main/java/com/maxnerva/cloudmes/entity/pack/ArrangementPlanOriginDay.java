package com.maxnerva.cloudmes.entity.pack;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;
import java.util.Date;

/**
 * @ClassName ArrangementPlanOriginDay
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/6/10 上午 10:28
 * @Version 1.0
 **/
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("wms_arrangement_plan_origin_day")
public class ArrangementPlanOriginDay extends Model<ArrangementPlanOriginDay> {
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    //日期
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern="yyyy-MM-dd",timezone="GMT+8")
//    @JSONField(format="yyyy-MM-dd")
    @TableField("arrangement_date")
    private Date arrangementDate;
    //接收前端日期  前端是long类型
    @TableField(exist = false)
    private Long dateReceive;
    //鸿海料号
    @TableField("hh_pn")
    private String hhPn;
    //运输方式
    private String transportation;
    //排配数量
    @TableField("arrangement_num")
    private Integer arrangementNum;
    //排班班别 1:白班/2:夜班
    private String schedule;
    //出货地
    @TableField("shipment_to")
    private String shipmentTo;
    //工令
    @TableField("work_order")
    private String workOrder;
    //导入人
    @TableField("import_by")
    private String importBy;
    //导入时间
    @TableField("import_dt")
    private LocalDateTime importDt;
    //计算状态 0:未计算1:计算中2:完成3:失败
    @TableField("calculate_state")
    private Integer calculateState;
    //计算信息
    @TableField("calculate_mes")
    private String calculateMes;

    /**
     * @description:    添加bu信息用于区分 各个bu数据
     * @author:  BZG
     * @date:  2021/9/29
     */
    //所属bu
    @TableField("bu")
    private String bu;
    //bu编码
    @TableField("bu_code")
    private String buCode;
}
