package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.TableId;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 工厂属性维护表
 * </p>
 *
 * @author caijun
 * @since 2022-08-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value = "WmsSapPlant对象", description = "工厂属性维护表")
public class WmsSapPlant extends BaseEntity<WmsSapPlant> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    @TableId
    private Integer id;

    @ApiModelProperty(value = "工厂编码")
    private String factoryCode;

    @ApiModelProperty(value = "工厂名称")
    private String factoryName;

    @ApiModelProperty(value = "启用版次")
    private String enableVersion;

    @ApiModelProperty(value = "ErpInterface")
    private String erpInterface;

    @ApiModelProperty(value = "LCR")
    private String lcr;

    @ApiModelProperty(value = "丝印")
    private String silkScreen;

    @ApiModelProperty(value = "MSD")
    private String msd;

    @ApiModelProperty(value = "烧录")
    private String burn;

    @ApiModelProperty(value = "超耗比例（‰）")
    private String overConsumptionRatio;

    @ApiModelProperty(value = "备料类型")
    private String preparationType;

    @ApiModelProperty(value = "是否启用(false-否 true-是)，默认false")
    private Boolean isEnable;

    @ApiModelProperty(value = "工厂组织")
    private String orgCode;

    @ApiModelProperty(value = "板端类型")
    private String boardProcessType;

    @ApiModelProperty(value = "打印模板id")
    private Integer printTemplateId;

    @ApiModelProperty(value = "打印模板名称")
    private String printTemplateName;

    @ApiModelProperty(value = "内交出是否需要扫描")
    private String tradingIsScan;

    @ApiModelProperty(value = "内交出是否需要上架")
    private String tradingIsShelf;

    @ApiModelProperty(value = "内交出是否需要打印")
    private String tradingIsPrint;

    @ApiModelProperty(value = "客供料poType")
    private String buySellPoType;

    @ApiModelProperty(value = "采购组织配置")
    private String jitBuyerCode;

    @ApiModelProperty(value = "管理方式 默认值:ELECTRONIC_SEGMENT,参考字典值：WMS-SECTION-TYPE")
    private String sectionType;

    @ApiModelProperty(value = "是否启用mrpArea")
    private String enableJusdaMrpArea;

    @ApiModelProperty(value = "是否启用有效期管控")
    private Boolean enableValidDateControl;
}
