package com.maxnerva.cloudmes.entity.prepare;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>
 * 捡料记录表
 * </p>
 *
 * @author likun
 * @since 2023-05-12
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value = "WmsWorkOrderPreProcessLog对象", description = "捡料记录表")
public class WmsWorkOrderPreProcessLog extends BaseEntity<WmsWorkOrderPreProcessLog> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "pkg")
    private String pkgId;

    @ApiModelProperty(value = "父pkg")
    private String parentPkgId;

    @ApiModelProperty(value = "BU（业务单元）")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "来源仓码")
    private String fromWarehouseCode;

    @ApiModelProperty(value = "目标仓码")
    private String toWarehouseCode;

    @ApiModelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "原始数量")
    private BigDecimal originalQty;

    @ApiModelProperty(value = "当前数量")
    private BigDecimal currentQty;

    @ApiModelProperty(value = "异动数量")
    private BigDecimal transactionQty;

    @ApiModelProperty(value = "供应商料号")
    private String supplierPartNo;

    @ApiModelProperty(value = "制造商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "制造商名称")
    private String mfgName;

    @ApiModelProperty(value = "解析datecode")
    private LocalDate dateCode;

    @ApiModelProperty(value = "原始datecode")
    private String originalDateCode;

    @ApiModelProperty(value = "批次号")
    private String lotNo;

    @ApiModelProperty(value = "锁定状态")
    private String lockStatus;

    @ApiModelProperty(value = "锁定时间")
    private LocalDateTime lockDate;

    @ApiModelProperty(value = "lock原因")
    private String lockMessage;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "工单群组")
    private String workOrderItem;

    @ApiModelProperty(value = "制程分类")
    private String materialProductProcess;

    @ApiModelProperty(value = "制程类型")
    private String materialProductType;

    @ApiModelProperty(value = "是否为烧录物料 默认false")
    private Boolean isBurn;

    @ApiModelProperty(value = "计划烧录值")
    private String planBurnValue;

    @ApiModelProperty(value = "烧录值")
    private String burnValue;

    @ApiModelProperty(value = "是否合盘物料 N:不是，Y:是")
    private String mergeFlag;

    @ApiModelProperty(value = "N:不是剪角物料，Y:剪角物料")
    private String cutOffFlag;

    @ApiModelProperty(value = "物料类型（A/B/C)")
    private String materialType;

    @ApiModelProperty(value = "异动类型编码，参考字典")
    private String transactionType;

    @ApiModelProperty(value = "异动类型字典值")
    private String transactionMessage;

    @ApiModelProperty(value = "异动类型单号")
    private String transactionNumber;

    @ApiModelProperty(value = "有效日期")
    private Integer effectiveDate;

    @ApiModelProperty(value = "有效期截止时间")
    private LocalDate endDate;

    @ApiModelProperty(value = "载具编码")
    private String vehicleCode;

    @ApiModelProperty(value = "载具编码")
    private String binCode;

    @ApiModelProperty(value = "捡料人")
    private String materialPicker;

    @ApiModelProperty(value = "捡料时间")
    private LocalDateTime pickingTime;

    @ApiModelProperty(value = "转料人")
    private String transferPerson;

    @ApiModelProperty(value = "转料时间")
    private LocalDateTime transferTime;

    @ApiModelProperty(value = "操作人")
    private String operator;

    @ApiModelProperty(value = "操作时间")
    private LocalDateTime operationDt;

    @ApiModelProperty(value = "工单绑定位置")
    private String workOrderToLocation;

    @ApiModelProperty(value = "上料表工单群组")
    private String feederWorkOrderItem;

    @ApiModelProperty(value = "原产国1")
    private String placeOfOrigin1;

    @ApiModelProperty(value = "轨道号")
    private String feederNo;

    @ApiModelProperty(value = "机台编号")
    private String machineCode;

    @ApiModelProperty(value = "成品料号")
    private String productPartNo;

    @ApiModelProperty(value = "线别")
    private String lineNo;

}
