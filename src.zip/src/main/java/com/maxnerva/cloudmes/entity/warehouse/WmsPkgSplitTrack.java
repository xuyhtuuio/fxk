package com.maxnerva.cloudmes.entity.warehouse;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2024-04-27
 */
@TableName("wms_pkg_split_track")
@ApiModel(value = "WmsPkgSplitTrack对象", description = "")
@Data
public class WmsPkgSplitTrack extends BaseEntity<WmsPkgSplitTrack> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty("祖宗pkg")
    private String rootPkgId;

    @ApiModelProperty("父PKG")
    private String parentPkgId;

    @ApiModelProperty("当前pkg")
    private String pkgId;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("工厂")
    private String plantCode;
}
