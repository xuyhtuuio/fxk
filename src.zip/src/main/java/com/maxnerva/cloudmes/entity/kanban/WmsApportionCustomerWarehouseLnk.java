package com.maxnerva.cloudmes.entity.kanban;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 客户分摊面积报表，客户-仓码关联关系
 * </p>
 *
 * @author baomidou
 * @since 2025-05-30
 */
@EqualsAndHashCode(callSuper = true)
@TableName("wms_apportion_customer_warehouse_lnk")
@ApiModel(value = "WmsApportionCustomerWarehouseLnk对象", description = "客户分摊面积报表，客户-仓码关联关系")
@Data
public class WmsApportionCustomerWarehouseLnk extends BaseEntity<WmsApportionCustomerWarehouseLnk> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("客户")
    private String customer;

    @ApiModelProperty("仓码")
    private String warehouseCode;
}
