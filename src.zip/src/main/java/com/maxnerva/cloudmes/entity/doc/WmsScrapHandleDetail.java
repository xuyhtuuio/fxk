package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 报废处理详情
 * </p>
 *
 * @author baomidou
 * @since 2024-08-01
 */
@TableName("wms_scrap_handle_detail")
@ApiModel(value = "WmsScrapHandleDetail对象", description = "报废处理详情")
@Data
public class WmsScrapHandleDetail extends BaseEntity<WmsScrapHandleDetail> {
    private Integer id;

    @ApiModelProperty("工厂组织")
    private String orgCode;

    @ApiModelProperty("工厂")
    private String plantCode;

    @ApiModelProperty("单号（关联header）")
    private String docNo;

    @ApiModelProperty("条码")
    private String pkgId;

    @ApiModelProperty("料号")
    private String partNo;

    @ApiModelProperty(value = "版次")
    private String partVersion;

    @ApiModelProperty("单位")
    private String uomCode;

    @ApiModelProperty("数量")
    private BigDecimal qty;

    @ApiModelProperty("仓码")
    private String warehouseCode;

    @ApiModelProperty("描述")
    private String description;

    @ApiModelProperty("载具")
    private String vehicleCode;

    @ApiModelProperty("储位")
    private String binCode;

    @ApiModelProperty("绑定SN个数")
    private BigDecimal bindSnQty;

    @ApiModelProperty("出货状态 0 未出货， 1已出货")
    private String shipFlag;

    @ApiModelProperty("图片URL列表（JSONArray）")
    private String imageUrlList;

    @ApiModelProperty("来源类型 PKGID or LIST")
    private String sourceType;

    @ApiModelProperty("销账单号")
    private String balanceNo;

    @ApiModelProperty(value = "栈板号")
    private String palletNo;

    @ApiModelProperty(value = "报废类别")
    private String scrapType;

    @ApiModelProperty(value = "净重")
    private BigDecimal netWeight;

    @ApiModelProperty(value = "毛重")
    private BigDecimal grossWeight;

    @ApiModelProperty(value = "称重人")
    private String weighEmpNo;

    @ApiModelProperty(value = "称重时间")
    private LocalDateTime weighDt;

    @ApiModelProperty(value = "備案序號")
    private String filingNo;

    @ApiModelProperty(value = "物料分類")
    private String materialGroup;

    @ApiModelProperty(value = "是否关键物料")
    private Boolean isKeyPartNo;

    @ApiModelProperty(value = "出货人")
    private String shipEmpNo;

    @ApiModelProperty(value = "出货时间")
    private LocalDateTime shipDt;

    @ApiModelProperty(value = "抛转SDS标识")
    private String postSdsFlag;

    @ApiModelProperty(value = "抛转SDS时间")
    private LocalDateTime postSdsDt;

    @ApiModelProperty(value = "抛转SDS信息")
    private String postSdsMessage;
}
