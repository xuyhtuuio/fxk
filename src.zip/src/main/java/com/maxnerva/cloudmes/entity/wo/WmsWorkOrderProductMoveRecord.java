package com.maxnerva.cloudmes.entity.wo;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 成品工单101移转记录
(WmsWorkOrderProductMoveRecord)实体类
 *
 * @author hgx
 * @since 2024-01-02
 */

@ApiModel("WmsWorkOrderProductMoveRecord实体类")
@Data
public class WmsWorkOrderProductMoveRecord extends BaseEntity<WmsWorkOrderProductMoveRecord> {
 
   
    @ApiModelProperty("id")
    private Integer id;
   
    @ApiModelProperty("BU")
    private String orgCode;
   
    @ApiModelProperty("工厂")
    private String plantCode;
   
    @ApiModelProperty("原工单")
    private String workOrderNo;
   
    @ApiModelProperty("原工单可移出量")
    private BigDecimal oldEnabledQty;
   
    @ApiModelProperty("成品料号")
    private String partNo;
   
    @ApiModelProperty("目的工单")
    private String targetWorkOrderNo;
   
    @ApiModelProperty("目的工单可移入量")
    private BigDecimal targetEnabledQty;
   
    @ApiModelProperty("移动量")
    private BigDecimal moveQty;

}

