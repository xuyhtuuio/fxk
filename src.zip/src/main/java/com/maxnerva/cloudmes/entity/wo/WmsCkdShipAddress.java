package com.maxnerva.cloudmes.entity.wo;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

/**
 * <p>
 * CKD出货地址管理
 * </p>
 *
 * @author baomidou
 * @since 2023-12-12
 */
@TableName("wms_ckd_ship_address")
@Data
@ApiModel(value = "WmsCkdShipAddress对象", description = "CKD出货地址管理")
public class WmsCkdShipAddress extends BaseEntity<WmsCkdShipAddress> {

    private static final long serialVersionUID = 1L;

    private Integer id;

    private String orgCode;

    private String plantCode;

    private String workOrderNo;

    @ApiModelProperty("出货地址")
    private String shipAddress;

    @ApiModelProperty("出货公司")
    private String shipCompany;

    private String co;

    @ApiModelProperty("收货详细地址")
    private String shipAddressDetail;

    private String shipTerm;

    @ApiModelProperty("退运方式")
    private String returnTransportMethod;

    @ApiModelProperty("费用单位")
    private String costOffice;

    @ApiModelProperty("退货处理方式")
    private String returnGoodsMethod;

    @ApiModelProperty("退运时间")
    private String returnTransportDt;

    @ApiModelProperty("目的地")
    private String destination;

    @ApiModelProperty("收货人")
    private String receiver;

    @ApiModelProperty("联系方式")
    private String tel;

    private String fax;

    @ApiModelProperty("费用代码")
    private String costCode;

    @ApiModelProperty("出货部门")
    private String dept;

    private String soldToParty;

    private String shipToParty;

    private String warehouseCode;

    @ApiModelProperty("订单类型")
    private String docType;

    @ApiModelProperty("配销通路")
    private String distributionChannel;

    @ApiModelProperty(value = "出货地")
    private String siteCode;
}
