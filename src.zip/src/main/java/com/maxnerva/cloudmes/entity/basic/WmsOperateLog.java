package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2024-06-20
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="操作记录", description="库位表")
public class WmsOperateLog extends BaseEntity<WmsOperateLog> {

    private static final long serialVersionUID = 1L;

    private Integer id;

    @ApiModelProperty("操作类型")
    private String operateType;

    @ApiModelProperty("操作信息")
    private String operateMessage;

    @ApiModelProperty("其它")
    private String content;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty(value = "参数")
    private String param;
}
