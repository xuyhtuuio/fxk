package com.maxnerva.cloudmes.entity.wo;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

/**
 * <p>
 * 工单移转记录表
 * </p>
 *
 * @author likun
 * @since 2023-02-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsWorkOrderMoveRecord对象", description="工单移转记录表")
public class WmsWorkOrderMoveRecord extends BaseEntity<WmsWorkOrderMoveRecord> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "移出工单")
    private String fromWorkOrderNo;

    @ApiModelProperty(value = "移出工单群组")
    private String fromWorkOrderItem;

    @ApiModelProperty(value = "移出料号")
    private String fromPartNo;

    @ApiModelProperty(value = "群组可转工单数量")
    private BigDecimal workOrderItemMoveQty;

    @ApiModelProperty(value = "sap字段,reservationNumber")
    private String reservationNumber;

    @ApiModelProperty(value = "sap字段,reservationItem")
    private String reservationItem;

    @ApiModelProperty(value = "移出数量")
    private BigDecimal removeQty;

    @ApiModelProperty(value = "移出盘数")
    private BigDecimal removePkgIdQty;

    @ApiModelProperty(value = "mrpController")
    private String mrpController;

    @ApiModelProperty(value = "mrpArea")
    private String mrpArea;

    @ApiModelProperty(value = "item number")
    private String itemNumber;

    @ApiModelProperty(value = "value type")
    private String valueType;

    @ApiModelProperty(value = "来源仓码")
    private String fromWarehouseCode;

    @ApiModelProperty(value = "目标仓码")
    private String toWarehouseCode;

    @ApiModelProperty(value = "移入工单")
    private String toWorkOrderNo;

    @ApiModelProperty(value = "移入工单群组")
    private String toWorkOrderItem;

    @ApiModelProperty(value = "移入料号")
    private String toPartNo;
}
