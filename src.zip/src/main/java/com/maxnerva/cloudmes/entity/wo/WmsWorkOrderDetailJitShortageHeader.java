package com.maxnerva.cloudmes.entity.wo;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * jit缺料信息单头
 * </p>
 *
 * @author likun
 * @since 2023-09-21
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsWorkOrderDetailJitShortageHeader对象", description="jit缺料信息单头")
public class WmsWorkOrderDetailJitShortageHeader extends BaseEntity<WmsWorkOrderDetailJitShortageHeader> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "缺料流水号")
    private String materialShortageNo;

    @ApiModelProperty(value = "缺料工单号,多个用逗号隔开")
    private String workOrderNo;
}
