package com.maxnerva.cloudmes.entity.wo;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import lombok.Data;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * (WmsBadProductInStorageLog)实体类
 *
 * @author hgx
 * @since 2023-04-26
 */
@Data
@ApiModel("WmsBadProductInStorageLog实体类")
public class WmsBadProductInStorageLog extends BaseEntity<WmsBadProductInStorageLog> {

    
    @ApiModelProperty("主键id")
    private Integer id;
    
    @ApiModelProperty("单号")
    private String docNo;
    /**
     * BU
     */
    @ApiModelProperty("BU")
    private String orgCode;
    /**
     * 工厂
     */
    @ApiModelProperty("工厂")
    private String plantCode;
    /**
     * 操作类型
     */
    @ApiModelProperty("操作类型")
    private String operationType;
    /**
     * 条码
     */
    @ApiModelProperty("条码")
    private String pkgId;
    /**
     * 料号
     */
    @ApiModelProperty("料号")
    private String partNo;
    /**
     * 制造商名称
     */
    @ApiModelProperty("制造商名称")
    private String mfgName;
    /**
     * 制造商料号
     */
    @ApiModelProperty("制造商料号")
    private String mfgPartNo;
    /**
     * 数量
     */
    @ApiModelProperty("数量")
    private BigDecimal qty;
    /**
     * 创建人
     */
    @ApiModelProperty("创建人")
    private String creator;
    /**
     * 创建时间
     */
    @ApiModelProperty("创建时间")
    private LocalDateTime createdDt;
    /**
     * 仓码
     */
    @ApiModelProperty("仓码")
    private String warehouseCode;
    /**
     * 工单号
     */
    @ApiModelProperty("工单号")
    private String workOrderNo;
}

