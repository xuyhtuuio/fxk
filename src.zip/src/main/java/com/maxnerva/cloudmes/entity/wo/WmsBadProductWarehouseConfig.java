package com.maxnerva.cloudmes.entity.wo;

import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import lombok.Data;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 不良品领用/归还仓码配置(WmsBadProductWarehouseConfig)实体类
 *
 * @author hgx
 * @since 2023-09-22
 */
@Data
@ApiModel("WmsBadProductWarehouseConfig实体类")
public class WmsBadProductWarehouseConfig extends BaseEntity<WmsBadProductWarehouseConfig> {

    
    @ApiModelProperty("id")
    private Integer id;
    
    @ApiModelProperty("orgCode")
    private String orgCode;
    /**
     * 工厂
     */
    @ApiModelProperty("工厂")
    private String plantCode;
    /**
     * 不良品仓码
     */
    @ApiModelProperty("不良品仓码")
    private String badWarehouseCode;
    /**
     * 不良品倉碼描述
     */
    @ApiModelProperty("不良品倉碼描述")
    private String badWarehouseCodeDesc;
    /**
     * 品保仓码描述
     */
    @ApiModelProperty("品保仓码描述")
    private String qualityWarehouseCode;
    /**
     * 品保倉碼描述
     */
    @ApiModelProperty("品保倉碼描述")
    private String qualityWarehouseCodeDesc;
    /**
     * 类型
     */
    @ApiModelProperty("类型")
    private String type;
    /**
     * 良品仓
     */
    @ApiModelProperty("良品仓")
    private String goodWarehouseCode;
}

