package com.maxnerva.cloudmes.entity.alarm;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 邮件配置表
 * </p>
 *
 * @author likun
 * @since 2023-12-19
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value = "WmsSendMailConfig对象", description = "邮件配置表")
public class WmsSendMailConfig extends BaseEntity<WmsSendMailConfig> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty("用户名")
    private String userId;

    @ApiModelProperty("密码")
    private String passWord;

    @ApiModelProperty(value = "发送邮件类型,参考字典值")
    private String sendType;

    @ApiModelProperty(value = "发件人邮箱")
    private String fromAddress;

    @ApiModelProperty(value = "收件人邮箱")
    private String toAddress;

    @ApiModelProperty(value = "抄送邮箱")
    private String ccAddress;

    @ApiModelProperty(value = "主旨")
    private String mailTitle;

    @ApiModelProperty(value = "内容")
    private String mailContent;

    @ApiModelProperty(value = "邮件参数")
    private String mailRel;

    @ApiModelProperty(value = "备注")
    private String remark;
}
