package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2024-01-20
 */
@Data
@TableName("wms_eccn_report_pkg_info")
@ApiModel(value = "WmsEccnReportPkgInfo对象", description = "")
public class WmsEccnReportPkgInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer id;

    @ApiModelProperty("eccn单号")
    private String eccnNo;

    @ApiModelProperty("鸿海料号")
    private String partNo;

    @ApiModelProperty("料号描述")
    private String partDesc;

    @ApiModelProperty("厂商名")
    private String mfgName;

    @ApiModelProperty("厂商料号")
    private String mfgPartNo;

    @ApiModelProperty("来源单号")
    private String poNo;

    @ApiModelProperty("来源单号数量")
    private BigDecimal poQty;

    @ApiModelProperty("报关单号")
    private String cusNo;

    @ApiModelProperty("天津工厂入库单号（GR）")
    private String grNo;

    @ApiModelProperty("入库时间")
    private LocalDateTime inWarehouseDt;

    @ApiModelProperty("GR数量")
    private BigDecimal grQty;

    @ApiModelProperty("PKG")
    private String pkgId;

    @ApiModelProperty("PKG数量")
    private BigDecimal pkgQty;

    @ApiModelProperty("创建人")
    private String creator;

    @ApiModelProperty("创建时间")
    private LocalDateTime createdDt;

    @ApiModelProperty("修改人")
    private String lastEditor;

    @ApiModelProperty("修改时间")
    private LocalDateTime lastEditedDt;

    @ApiModelProperty("创建人id")
    private Integer creatorId;

    @ApiModelProperty("修改人id")
    private Integer lastEditorId;

    private String wmsNo;

    private String orgCode;

    private String poItem;

    @ApiModelProperty("PO是否同步完成")
    private Boolean poSyncFlag;

    private String vendorCode;

    @ApiModelProperty("报关单项次")
    private String cusItem;

    @ApiModelProperty("中转PKG")
    private String transPkgId;

    @ApiModelProperty("起运国")
    private String transpoartCoo;

    @ApiModelProperty("原产国")
    private String coo;

    @ApiModelProperty("licenceNo")
    private String licenceNo;

    @ApiModelProperty("license有效期")
    private LocalDate licenceEndDt;

    @ApiModelProperty("ECCN来源")
    private String eccnFrom;

    @ApiModelProperty("license申请人")
    private String licenseCreator;

    private String receivePkgId;

    @ApiModelProperty("費領數量")
    private BigDecimal costIssueQty;

    @ApiModelProperty("費領單號")
    private String costIssueDocNo;

    @ApiModelProperty("費領日期")
    private LocalDateTime costIssueDt;

    @ApiModelProperty("費領人")
    private String costIssueCreator;

    @ApiModelProperty("費退數量")
    private BigDecimal costReturnQty;

    @ApiModelProperty("費退單號")
    private String costReturnDocNo;

    @ApiModelProperty("費退時間")
    private LocalDateTime costReturnDt;

    @ApiModelProperty("費退人")
    private String costReturnCreator;

    @ApiModelProperty("報廢數量")
    private BigDecimal costScrapQty;

    @ApiModelProperty("報廢單號")
    private String costScrapDocNo;

    @ApiModelProperty("報廢時間")
    private LocalDateTime costScrapDt;

    @ApiModelProperty("報廢人")
    private String costScrapCreator;

    private BigDecimal adjustQty;

    @ApiModelProperty("料調單號")
    private String adjustDocNo;

    @ApiModelProperty("料調時間")
    private LocalDateTime adjustDt;

    @ApiModelProperty("料調人")
    private String adjustCreator;

    @ApiModelProperty("當前PKG是否消耗完")
    private Boolean consumeComplete;

    @ApiModelProperty("收貨PKG是否消耗完")
    private Boolean allConsumeComplete;

    @ApiModelProperty(value = "入库数量")
    private BigDecimal inWarehouseQty;

}
