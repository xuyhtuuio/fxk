package com.maxnerva.cloudmes.entity.wo;

import com.baomidou.mybatisplus.annotation.TableName;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2024-05-21
 */
@TableName("wms_ckd_pallet_lock")
@ApiModel(value = "WmsCkdPalletConfig对象", description = "")
@Data
public class WmsCkdPalletLock extends BaseEntity<WmsCkdPalletLock> {

    private static final long serialVersionUID = 1L;

    private Integer id;

    private String ckdBarcode;

    @ApiModelProperty("操作次数")
    private Integer operateNum;

    @ApiModelProperty("BU")
    private String orgCode;
}
