package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2025-04-08
 */
@EqualsAndHashCode(callSuper = true)
@TableName("wms_doc_swr_log_detail")
@ApiModel(value = "WmsDocSwrLogDetail对象", description = "")
@Data
public class WmsDocSwrLogDetail extends BaseEntity<WmsDocSwrLogDetail> {

    private static final long serialVersionUID = 1L;

    private Integer id;

    @ApiModelProperty("工厂组织")
    private String orgCode;

    @ApiModelProperty("工厂")
    private String plantCode;

    @ApiModelProperty("条码")
    private String pkgId;

    @ApiModelProperty("特采单号")
    private String docNo;

    @ApiModelProperty("GR单号")
    private String grNo;

    @ApiModelProperty("厂商料号")
    private String supplierPartNo;

    @ApiModelProperty("厂商名")
    private String mfgName;

    private String wmsNo;

    @ApiModelProperty("料号")
    private String partNo;

    @ApiModelProperty("数量")
    private BigDecimal qty;

    @ApiModelProperty("DC")
    private String originalDateCode;

    @ApiModelProperty("LOT")
    private String lotCode;

    @ApiModelProperty("到期日")
    private LocalDate endDate;

    @ApiModelProperty("物料描述")
    private String materialDesc;

    @ApiModelProperty("物料分类")
    private String classCode;
}
