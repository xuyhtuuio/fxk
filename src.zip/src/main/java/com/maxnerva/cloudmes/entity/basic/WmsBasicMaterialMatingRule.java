package com.maxnerva.cloudmes.entity.basic;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 物料配套使用规则
 * </p>
 *
 * @author likun
 * @since 2024-12-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsBasicMaterialMatingRule对象", description="物料配套使用规则")
public class WmsBasicMaterialMatingRule extends BaseEntity<WmsBasicMaterialMatingRule> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "物料id")
    private Integer productId;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "产品料号")
    private String productNo;

    @ApiModelProperty(value = "零件料号")
    private String componentNo;

    @ApiModelProperty(value = "项次")
    private String item;

    @ApiModelProperty(value = "生产分类")
    private String productType;

    @ApiModelProperty(value = "制造商名称")
    private String mfgName;

    @ApiModelProperty(value = "制造商料号")
    private String mfgPn;

    @ApiModelProperty(value = "配套标记")
    private String mark;

    private String orgCode;

    @ApiModelProperty(value = "是否删除")
    private Boolean isDeleted;

    @ApiModelProperty(value = "配套组")
    private String matingGroup;
}
