package com.maxnerva.cloudmes.entity.basic;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @Author yjw
 * @Description WMS过账时间段设置
 * @Date 2023/5/31 14:40
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(value="WmsPostingScheduleSetting对象", description="WMS过账时间段设置信息")
public class WmsPostingScheduleSetting extends BaseEntity<WmsPostingScheduleSetting> {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "组织")
    private String ordCode;

    @ApiModelProperty(value = "关账开始时间")
    private LocalDateTime beginDatetime;

    @ApiModelProperty(value = "关账结束时间")
    private LocalDateTime endDatetime;

    private String postingFlag;

    private LocalDate postingDate;

    @ApiModelProperty(value = "描述")
    private String postingSettingDesc;

    @ApiModelProperty(value = "内交过账开始时间")
    private LocalDateTime tradingStartTime;

    @ApiModelProperty(value = "内交过账结束时间")
    private LocalDateTime tradingEndTime;

    @ApiModelProperty(value = "CKD出货扣账开始时间")
    private LocalDateTime ckdShipPgiStartTime;

    @ApiModelProperty(value = "CKD出货扣账结束时间")
    private LocalDateTime ckdShipPgiEndTime;
}
