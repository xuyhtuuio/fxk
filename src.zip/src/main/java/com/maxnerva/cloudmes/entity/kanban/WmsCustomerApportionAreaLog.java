package com.maxnerva.cloudmes.entity.kanban;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 客戶分攤面積統計
 * </p>
 *
 * @author baomidou
 * @since 2025-05-30
 */
@EqualsAndHashCode(callSuper = true)
@TableName("wms_customer_apportion_area_log")
@ApiModel(value = "WmsCustomerApportionAreaLog对象", description = "客戶分攤面積統計")
@Data
public class WmsCustomerApportionAreaLog extends BaseEntity<WmsCustomerApportionAreaLog> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("区域名称")
    private String areaName;

    @ApiModelProperty("区域总面积")
    private BigDecimal areaTotalNum;

    @ApiModelProperty("涉及的库区")
    private String areaCode;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("客户")
    private String customer;

    @ApiModelProperty("客户面积占比")
    private BigDecimal customerAreaNumPercentage;

    @ApiModelProperty("客户使用储位数")
    private BigDecimal customerBinNum;

    @ApiModelProperty("客户使用储位占比")
    private BigDecimal customerBinNumPercentage;

    @ApiModelProperty("区域总储位数")
    private BigDecimal areaBinTotalNum;

    @ApiModelProperty("yyyy-MM")
    private String logVersion;

    @ApiModelProperty("占比描述")
    private String description;

    @ApiModelProperty("规划总储位数")
    private BigDecimal planBinTotalNum;

    @ApiModelProperty("总储位占用率")
    private BigDecimal totalBindBinNumPercentage;
}
