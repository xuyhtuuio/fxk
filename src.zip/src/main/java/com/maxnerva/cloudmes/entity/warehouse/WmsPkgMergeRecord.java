package com.maxnerva.cloudmes.entity.warehouse;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.common.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@ApiModel("PKG合盘记录")
@Data
public class WmsPkgMergeRecord extends BaseEntity {

    private Integer id;

    @ApiModelProperty(value = "工厂组织")
    private String orgCode;

    @ApiModelProperty(value = "SAP工厂")
    private String plantCode;

    @ApiModelProperty("合完盘pkgId")
    private String mergePkgId;

    @ApiModelProperty("原PKGID")
    private String originalPkgId;

    @ApiModelProperty("合盘后的PKG数量")
    private BigDecimal mergePkgQty;

    @ApiModelProperty("原PKG数量")
    private BigDecimal originalPkgQty;

    @ApiModelProperty("工单号")
    private String workOrderNo;

    @ApiModelProperty("仓码")
    private String fromSapWarehouseCode;

    @ApiModelProperty("仓码")
    private String toSapWarehouseCode;

    @ApiModelProperty(value = "解析datecode  解析D/C")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate dateCode;

    @ApiModelProperty("original_date_code")
    private String originalDateCode;

    @ApiModelProperty("lot_code")
    private String lotCode;

    @ApiModelProperty("endDate")
    private LocalDate endDate;

    @ApiModelProperty("制造商料号")
    private String mfgPartNo;

    @ApiModelProperty("制造商名称")
    private String mfgName;

    @ApiModelProperty("操作人")
    private String mergeUser;

    @ApiModelProperty("状态")
    private String mergeStatus;

    @ApiModelProperty("合盘顺序")
    private Integer mergeSequence;

    @ApiModelProperty("合盘时间")
    private LocalDateTime mergeDt;

}
