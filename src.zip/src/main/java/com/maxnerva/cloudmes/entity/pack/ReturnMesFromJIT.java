package com.maxnerva.cloudmes.entity.pack;

import lombok.Data;

/**
 * @ClassName ReturnMesFromJIT
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/6/10 上午 11:07
 * @Version 1.0
 **/
@Data
public class ReturnMesFromJIT {
    //DN 单号
    private String no;
    //DN 项次
    private String item;
    //料号
    private String partNo;
    //验证结果
    private String result;
    //验证错误信息
    private String errorMsg;

}
