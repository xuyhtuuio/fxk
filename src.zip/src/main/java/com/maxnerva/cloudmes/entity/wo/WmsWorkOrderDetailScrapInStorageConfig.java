package com.maxnerva.cloudmes.entity.wo;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * (WmsWorkOrderDetailScrapInStorageConfig)实体类
 *
 * @author hgx
 * @since 2023-05-16
 */
@Data
@ApiModel("WmsWorkOrderDetailScrapInStorageConfig实体类")
public class WmsWorkOrderDetailScrapInStorageConfig extends BaseEntity<WmsWorkOrderDetailScrapInStorageConfig> {


    @ApiModelProperty("主键id")
    private Integer id;
    /**
     * 报废原因code
     */
    @ApiModelProperty("报废原因code")
    private String scrapReasonCode;
    /**
     * 报废分类
     */
    @ApiModelProperty("报废分类")
    private String scrapType;
    /**
     * 来源仓码
     */
    @ApiModelProperty("来源仓码")
    private String fromWarehouseCode;
    /**
     * 目的仓码
     */
    @ApiModelProperty("目的仓码")
    private String toWarehouseCode;
    /**
     * 工厂
     */
    @ApiModelProperty("工厂")
    private String plantCode;
}

