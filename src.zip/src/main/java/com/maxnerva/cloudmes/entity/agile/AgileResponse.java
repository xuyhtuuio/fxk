package com.maxnerva.cloudmes.entity.agile;

import com.maxnerva.cloudmes.entity.flownet.FlownetResponseData;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel("Agile返回实体")
@Data
public class AgileResponse {

    @ApiModelProperty("返回数据")
    private Body body;

    @ApiModelProperty("返回msg")
    private String msg;
}
