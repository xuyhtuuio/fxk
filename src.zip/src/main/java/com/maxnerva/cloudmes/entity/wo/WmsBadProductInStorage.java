package com.maxnerva.cloudmes.entity.wo;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @Author hgx
 * @Description 不良品管理
 * @Date 2023/4/17 16:25
 */
@Data
@ApiModel(value = "WmsBadInStorage对象", description = "不良品入库表信息")
public class WmsBadProductInStorage extends BaseEntity<WmsBadProductInStorage> {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "单号")
    private String docNo;

    @ApiModelProperty(value = "组织")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "操作类型")
    private String operationType;

    @ApiModelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "制造商名称")
    private String mfgName;

    @ApiModelProperty(value = "制造商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "条码号")
    private String pkgId;

    @ApiModelProperty(value = "数量")
    private BigDecimal qty;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "不良原因")
    private String badReason;

    @ApiModelProperty(value = "物料来源")
    private String materialSource;

    @ApiModelProperty(value = "IQC判定人")
    private String iqcPerson;

    @ApiModelProperty(value = "复判结果")
    private String repeatResult;

    @ApiModelProperty(value = "退料次数")
    private String returnCount;

    @ApiModelProperty(value = "Vendor_OSV")
    private String vendorOsv;

    @ApiModelProperty(value = "sqeOsv")
    private String sqeOsv;

    @ApiModelProperty(value = "库存状态")
    private String inventoryStatus;

    @ApiModelProperty(value = "出库日期")
    private LocalDate shipDate;

    @ApiModelProperty(value = "物控")
    private String materialControl;

    @ApiModelProperty(value = "对策回复人")
    private String responder;

    @ApiModelProperty(value = "处理对策")
    private String dealMethod;

    @ApiModelProperty(value = "物料类型")
    private String materialType;

    @ApiModelProperty("不良品仓码")
    private String badWarehouseCode;

    @ApiModelProperty("单据状态（0：新建；1：已入库；2：已置换）")
    private String status;

    @ApiModelProperty("入库操作人")
    private String inStorageOperator;

    @ApiModelProperty("入库时间")
    private LocalDateTime inStorageDt;

    @ApiModelProperty("置换操作人")
    private String replaceOperator;

    @ApiModelProperty("置换时间")
    private LocalDateTime replaceDt;

    @ApiModelProperty("入库数量")
    private BigDecimal inStorageQty;

    @ApiModelProperty("良品仓码")
    private String goodWarehouseCode;

    @ApiModelProperty("置换PKGID")
    private String replacePkgId;

    @ApiModelProperty(value = "不良原因代码")
    private String badReasonCode;

    @ApiModelProperty("sfcPkgId")
    private String sfcPkgId;

    @ApiModelProperty("退料方式")
    private String returnMethod;

    @ApiModelProperty("SN对应PKGID")
    private String snPkgId;

    @ApiModelProperty("制造商名称")
    private LocalDate dateCode;

    @ApiModelProperty(value = "原始datecode")
    private String originalDateCode;

    @ApiModelProperty("lotCode")
    private String lotCode;

    @ApiModelProperty("原产国")
    private String placeOfOrigin1;

    @ApiModelProperty("抛Q时间")
    private LocalDateTime postQmsDate;

    @ApiModelProperty("外观检验结果标识(成功：Y，失败：N)")
    private String qmsReturnWgResult;

    @ApiModelProperty("外观检验结果描述")
    private String qmsReturnWgMsg;

    @ApiModelProperty("Q外观检验结果返回结果时间")
    private LocalDateTime qmsReturnWgDate;

    @ApiModelProperty("Q返回是否结案")
    private String qmsReturnIsClose;

    @ApiModelProperty("Q返回是否做OSV")
    private String qmsReturnIsDoOsv;

    @ApiModelProperty("Q返回OSV结果")
    private String qmsReturnOsvResult;

    @ApiModelProperty("Q返回OSV结果描述")
    private String qmsReturnOsvMsg;

    @ApiModelProperty("QOSV检验结果返回结果时间")
    private LocalDateTime qmsReturnOsvDate;

    @ApiModelProperty("是否在库")
    private String isInStock;

    @ApiModelProperty("领用下架")
    private String issueFlag;

    @ApiModelProperty("下架人")
    private String issueBy;

    @ApiModelProperty("下架时间")
    private LocalDateTime issueDateTime;

    @ApiModelProperty("归还上架标识")
    private String returnFlag;

    @ApiModelProperty("上架人")
    private String returnBy;

    @ApiModelProperty("上架时间")
    private LocalDateTime returnDateTime;

    @ApiModelProperty("领用仓码")
    private String issueWarehouseCode;

    @ApiModelProperty("领用过账时间")
    private LocalDateTime issuePostDateTime;

    @ApiModelProperty("领用过账单号")
    private String issuePostNo;

    @ApiModelProperty("领用过账信息")
    private String issuePostMsg;

    @ApiModelProperty("归还仓码")
    private String returnWarehouseCode;

    @ApiModelProperty("归还过账时间")
    private LocalDateTime returnPostDateTime;

    @ApiModelProperty("归还过账单号")
    private String returnPostNo;

    @ApiModelProperty("归还过账信息")
    private String returnPostMsg;

    @ApiModelProperty(value = "申请领用人")
    private String applyIssueBy;

    @ApiModelProperty(value = "申请领用时间")
    private LocalDateTime applyIssueDate;

    @ApiModelProperty(value = "申请归还人")
    private String applyReturnBy;

    @ApiModelProperty(value = "申请归还时间")
    private LocalDateTime applyReturnDate;

    @ApiModelProperty(value = "SAP过账单号")
    private String postSapNo;

    @ApiModelProperty(value = "flownet返回描述")
    private String flownetMsg;

    @ApiModelProperty(value = "flownet审批结果")
    private String flownetApprovalResult;

    @ApiModelProperty(value = "flownet表单地址")
    private String flownetUrl;

    @ApiModelProperty(value = "flownet调用结果,SUCCESS")
    private String flownetFlag;

    @ApiModelProperty(value = "flownet返回表单id")
    private String flownetFormId;

    @ApiModelProperty(value = "flownet流程id")
    private String flownetProcessId;

    @ApiModelProperty(value = "标识")
    private String identify;

    @ApiModelProperty(value = "版次")
    private String partVersion;
}
