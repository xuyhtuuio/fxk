package com.maxnerva.cloudmes.entity.assyprepare;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * agv区域用途配置表
 * </p>
 *
 * @author likun
 * @since 2024-08-09
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsAgvAreaConfig对象", description="agv区域用途配置表")
public class WmsAgvAreaConfig extends BaseEntity<WmsAgvAreaConfig> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "来源库区")
    private String fromAreaCode;

    @ApiModelProperty(value = "AGV任务类型")
    private String agvTaskType;

    @ApiModelProperty(value = "厂部")
    private String factoryCode;

    @ApiModelProperty(value = "目标库区")
    private String toAreaCode;

    @ApiModelProperty(value = "来源点位")
    private String fromAgvCode;

    @ApiModelProperty(value = "目标点位")
    private String toAgvCode;
}
