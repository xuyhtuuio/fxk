package com.maxnerva.cloudmes.entity.deliver;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2025-05-22
 */
@EqualsAndHashCode(callSuper = true)
@TableName("wms_ship_vehicle_info")
@ApiModel(value = "WmsShipVehicleInfo对象", description = "")
@Data
public class WmsShipVehicleInfo extends BaseEntity<WmsShipVehicleInfo> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("进厂时间")
    private LocalDateTime entryTime;

    @ApiModelProperty("车牌")
    private String licenseNo;

    private String shipTo;

    @ApiModelProperty("装柜明细")
    private String containerNo;

    @ApiModelProperty("停靠码头")
    private String dockNo;

    @ApiModelProperty("装货板数")
    private String palletNo;

    @ApiModelProperty("运行状态")
    private String status;
}
