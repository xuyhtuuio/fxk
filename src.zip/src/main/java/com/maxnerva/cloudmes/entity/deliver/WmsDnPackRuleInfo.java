package com.maxnerva.cloudmes.entity.deliver;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

/**
 * <p>
 * DN包规信息
 * </p>
 *
 * @author likun
 * @since 2024-08-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsDnPackRuleInfo对象", description="DN包规信息")
public class WmsDnPackRuleInfo extends BaseEntity<WmsDnPackRuleInfo> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "DN")
    private String dnNo;

    @ApiModelProperty(value = "DNLINE")
    private String dnItem;

    @ApiModelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "栈板长")
    private BigDecimal palletLength;

    @ApiModelProperty(value = "栈板宽")
    private BigDecimal palletWidth;

    @ApiModelProperty(value = "栈板高")
    private BigDecimal palletHeight;

    @ApiModelProperty(value = "单位（长度）")
    private String unitDim;

    @ApiModelProperty(value = "每箱数量")
    private Integer perBoxQty;

    @ApiModelProperty(value = "箱数")
    private Integer boxCount;

    @ApiModelProperty(value = "箱子毛重")
    private BigDecimal perBoxGross;

    @ApiModelProperty(value = "单位（重量）")
    private String unitWeight;

    @ApiModelProperty(value = "PO")
    private String po;

    @ApiModelProperty(value = "POLINE")
    private String poItem;

    @ApiModelProperty(value = "箱子长")
    private BigDecimal boxLength;

    @ApiModelProperty(value = "箱子宽")
    private BigDecimal boxWidth;

    @ApiModelProperty(value = "箱子高")
    private BigDecimal boxHeight;

    @ApiModelProperty(value = "箱子长度单位")
    private String unitDimBox;

    @ApiModelProperty(value = "栈板重量")
    private BigDecimal palletWeight;

    @ApiModelProperty(value = "打包膜+角纸")
    private BigDecimal exWeight;
}
