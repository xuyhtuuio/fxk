package com.maxnerva.cloudmes.entity.prepare.outsourcing;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>
 * 委外工单发料清单表
 * </p>
 *
 * @author likun
 * @since 2023-11-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsOutsourcingWorkOrderPrepareLog对象", description="委外工单发料清单表")
public class WmsOutsourcingWorkOrderPrepareLog extends BaseEntity<WmsOutsourcingWorkOrderPrepareLog> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU（业务单元）")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "PO号")
    private String poNo;

    @ApiModelProperty(value = "PO群组")
    private String poItem;

    @ApiModelProperty(value = "pkg")
    private String pkgId;

    @ApiModelProperty(value = "父pkg")
    private String parentPkgId;

    @ApiModelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "料号版次")
    private String partVersion;

    @ApiModelProperty(value = "仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "原始数量")
    private BigDecimal originalQty;

    @ApiModelProperty(value = "当前数量")
    private BigDecimal currentQty;

    @ApiModelProperty(value = "操作数量")
    private BigDecimal transactionQty;

    @ApiModelProperty(value = "退料量")
    private BigDecimal returnQty;

    @ApiModelProperty(value = "解析datecode")
    private LocalDate dateCode;

    @ApiModelProperty(value = "原始datecode")
    private String originalDateCode;

    @ApiModelProperty(value = "批次号")
    private String lotCode;

    @ApiModelProperty(value = "上架时间")
    private LocalDateTime shelfDate;

    @ApiModelProperty(value = "异动类型编码，参考字典")
    private String transactionType;

    @ApiModelProperty(value = "异动类型字典值")
    private String transactionMessage;

    @ApiModelProperty(value = "有效日期")
    private Integer effectiveDate;

    @ApiModelProperty(value = "有效期截止时间")
    private LocalDate endDate;

    @ApiModelProperty(value = "退料标识 0：不退料 1：退料")
    private String returnFlag;
}
