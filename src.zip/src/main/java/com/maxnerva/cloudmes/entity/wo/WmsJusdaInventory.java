package com.maxnerva.cloudmes.entity.wo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;


@Data
@ApiModel("JIT库存")
public class WmsJusdaInventory extends BaseEntity<WmsJusdaInventory> {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String sapPlantCode;

    @ApiModelProperty(value = "版本")
    private String stockVersion;

    @ApiModelProperty(value = "customerNo")
    @JsonAlias("CustomerNo")
    private String customerNo;

    @ApiModelProperty(value = "customerName")
    @JsonAlias("CustomerName")
    private String customerName;

    @ApiModelProperty(value = "supplierNo")
    @JsonAlias("SupplierNo")
    private String supplierNo;

    @ApiModelProperty(value = "supplier_name")
    @JsonAlias("SupplierName")
    private String supplierName;

    @ApiModelProperty(value = "supplierPartNo")
    @JsonAlias("SupplierPartNo")
    private String supplierPartNo;

    @ApiModelProperty(value = "receiverCode")
    @JsonAlias("ReceiverCode")
    private String receiverCode;

    @ApiModelProperty(value = "inventorReference")
    @JsonAlias("InventorReference")
    private String inventorReference;

    @ApiModelProperty(value = "warehouseName")
    @JsonAlias("WarehouseName")
    private String warehouseName;

    @ApiModelProperty(value = "inventoryDescription")
    @JsonAlias("InventoryDescription")
    private String inventoryDescription;

    @ApiModelProperty(value = "customerPartNo")
    @JsonAlias("CustomerPartNo")
    private String customerPartNo;

    @ApiModelProperty(value = "customerSupplierNo")
    @JsonAlias("CustomerSupplierNo")
    private String customerSupplierNo;

    @ApiModelProperty(value = "manufactureName")
    @JsonAlias("ManufactureName")
    private String manufactureName;

    @ApiModelProperty(value = "unknownQty")
    @JsonAlias("UnknownQty")
    private BigDecimal unknownQty;

    @ApiModelProperty(value = "onWayQty")
    @JsonAlias("OnWayQty")
    private BigDecimal onWayQty;

    @ApiModelProperty(value = "holdQty")
    @JsonAlias("HoldQty")
    private BigDecimal holdQty;

    @ApiModelProperty(value = "uom")
    @JsonAlias("UOM")
    private String uom;

    @ApiModelProperty(value = "IsBound")
    @JsonAlias("IsBound")
    private String isBound;

    @ApiModelProperty(value = "quantityOfTRM")
    @JsonAlias("QuantityOfTRM")
    private BigDecimal quantityOfTrm;

    @ApiModelProperty(value = "quantityOfOnWay")
    @JsonAlias("QuantityOfOnWay")
    private BigDecimal quantityOfOnWay;

    @ApiModelProperty(value = "transHuQty")
    @JsonAlias("TransHUQty")
    private BigDecimal transHuQty;

    @ApiModelProperty(value = "HubInvQty")
    @JsonAlias("HubInvQty")
    private BigDecimal hubInvQty;

    @ApiModelProperty(value = "goodQty")
    @JsonAlias("GOODQTY")
    private BigDecimal goodQty;

    @ApiModelProperty(value = "defectQty")
    @JsonAlias("DefectQty")
    private BigDecimal defectQty;

    @ApiModelProperty(value = "confirmQty")
    @JsonAlias("ConfirmQty")
    private BigDecimal confirmQty;

    @ApiModelProperty(value = "reference1")
    @JsonAlias("Reference1")
    private String reference1;

    @ApiModelProperty(value = "reference2")
    @JsonAlias("Reference2")
    private String reference2;

    @ApiModelProperty(value = "reference3")
    @JsonAlias("Reference3")
    private String reference3;

    @ApiModelProperty(value = "qty")
    @JsonAlias("Qty")
    private BigDecimal qty;

    @ApiModelProperty(value = "warehouseNo")
    @JsonAlias("WarehouseNo")
    private String warehouseNo;

    @ApiModelProperty(value = "lastEditBy")
    @JsonAlias("LastEditBy")
    private String lastEditBy;

    @ApiModelProperty(value = "lastEditDt")
    @JsonAlias("LastEditDT")
    private String lastEditDt;

    @ApiModelProperty(value = "enterpriseGroup")
    private String enterpriseGroup;

    @ApiModelProperty(value = "mrpArea")
    private String mrpArea;
}
