package com.maxnerva.cloudmes.entity.pack;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

/**
 * <p>
 * 包材发料单header
 * </p>
 *
 * @author likun
 * @since 2024-12-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsPackStockHeader对象", description="包材发料单header")
public class WmsPackStockHeader extends BaseEntity<WmsPackStockHeader> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "发料单号")
    private String docNo;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "线别")
    private String lineNo;

    @ApiModelProperty(value = "单据状态")
    private String docStatus;

    @ApiModelProperty(value = "申请人")
    private String applyStaffCode;

    @ApiModelProperty(value = "申请时间")
    private LocalDateTime applyDt;

    @ApiModelProperty(value = "过账单号")
    private String postSapReturnNumber;

    @ApiModelProperty(value = "过账信息")
    private String postSapReturnMsg;

    @ApiModelProperty(value = "过账时间")
    private LocalDateTime postSapDate;

    @ApiModelProperty(value = "签核人")
    private String approvalStaffCode;

    @ApiModelProperty(value = "签核时间")
    private LocalDateTime approvalDate;
}
