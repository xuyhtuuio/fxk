package com.maxnerva.cloudmes.entity.basic;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 打印模板配置关系表
 * </p>
 *
 * @author likun
 * @since 2022-12-12
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsPrintTemplateConfig对象", description="打印模板配置关系表")
public class WmsPrintTemplateConfig extends BaseEntity<WmsPrintTemplateConfig> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "打印类型")
    private String printType;

    @ApiModelProperty(value = "打印模板id")
    private Integer printTemplateId;

    @ApiModelProperty(value = "打印模板名称")
    private String printTemplateName;
}
