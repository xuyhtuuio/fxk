package com.maxnerva.cloudmes.entity.pack;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.maxnerva.cloudmes.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

/**
 * @ClassName PackingMaterialsSupplier
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/6/10 下午 01:53
 * @Version 1.0
 **/

@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("wms_packing_materials_supplier")
public class PackingMaterialsSupplier extends Model<PackingMaterialsSupplier> {


    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    //包材料号
    @TableField("packing_materials_pn")
    private String packingMaterialsPn;
    //供应商
    private String supplier;
    //创建人
    @TableField("create_by")
    private String createBy;
    //创建时间
    @TableField("create_dt")
    private LocalDateTime createDt;
    //修改人
    @TableField("update_by")
    private String updateBy;
    //修改时间
    @TableField("update_dt")
    private LocalDateTime updateDt;

    /**
     * @description:  与JIT对接 需要这俩个字段
     * @author:  BZG
     * @date:  2021/7/5
     */
    //供应商编码
    @TableField("supplier_code")
    private String supplierCode;
    //JIT供应商对应场所   一对一关系
    @TableField("jit_facility")
    private String jitFacility;
}
