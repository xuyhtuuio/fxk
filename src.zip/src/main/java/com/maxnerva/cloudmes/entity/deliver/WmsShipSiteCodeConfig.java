package com.maxnerva.cloudmes.entity.deliver;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 成品出货 出货地配置(WmsShipSiteCodeConfig)实体类
 *
 * @author hgx
 * @since 2023-11-28
 */

@ApiModel("WmsShipSiteCodeConfig实体类")
@Data
public class WmsShipSiteCodeConfig extends BaseEntity<WmsShipSiteCodeConfig> {
 
   
    @ApiModelProperty("id")
    private Integer id;

    @ApiModelProperty("组织")
    private String orgCode;

    @ApiModelProperty("工厂")
    private String plantCode;

    @ApiModelProperty("客户名称")
    private String customerName;

    @ApiModelProperty("国家代码")
    private String countryCode;
   
    @ApiModelProperty("出货地-中文")
    private String siteCodeCh;
   
    @ApiModelProperty("出货地-英文")
    private String siteCodeEn;
   
    @ApiModelProperty("出货地")
    private String siteCode;

    @ApiModelProperty("详细地址")
    private String detailAddress;

    @ApiModelProperty("出货区域码")
    private String areaCode;
}

