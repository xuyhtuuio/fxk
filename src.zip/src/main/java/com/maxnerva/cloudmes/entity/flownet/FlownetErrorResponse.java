package com.maxnerva.cloudmes.entity.flownet;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel("Flownet返回实体")
@Data
public class FlownetErrorResponse {

    @ApiModelProperty("返回数据")
    private String data;

    @ApiModelProperty("成功：SUCCESS")
    private String flag;

    @ApiModelProperty("返回信息")
    private String msg;
}
