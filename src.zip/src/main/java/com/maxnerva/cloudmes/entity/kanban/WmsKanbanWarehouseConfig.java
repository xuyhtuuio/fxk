package com.maxnerva.cloudmes.entity.kanban;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2024-07-18
 */
@TableName("wms_kanban_warehouse_config")
@ApiModel(value = "WmsKanbanWarehouseConfig对象", description = "")
@Data
public class WmsKanbanWarehouseConfig extends BaseEntity<WmsKanbanWarehouseConfig> {

    private static final long serialVersionUID = 1L;

    private Integer id;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("厂部")
    private String factoryCode;

    @ApiModelProperty("仓码")
    private String warehouseCode;

    @ApiModelProperty("物料分类")
    private String materialSort;
}
