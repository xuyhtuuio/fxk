package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.maxnerva.cloudmes.common.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


@ApiModel("准时达收货BU对照")
@Data
public class WmsJusdaBuContrast extends BaseEntity {

    @TableId(type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "SAP工厂")
    private String plantCode;

    @ApiModelProperty(value = "组织")
    private String orgCode;

    @ApiModelProperty(value = "收货类型")
    private String deliveryType;

    @ApiModelProperty(value = "Foxconn BU代码")
    private String customerName;


    @ApiModelProperty(value = "supplierName")
    private String supplierName;

    @ApiModelProperty(value = "转出仓")
    private String transferFrom;

    @ApiModelProperty(value = "转入仓")
    private String transferTo;

    @ApiModelProperty(value = "客户")
    private String customer;

    @ApiModelProperty(value = "制程分类")
    private String segType;

    @ApiModelProperty(value = "行政组织")
    private String adminOrg;

    @ApiModelProperty(value = "mrpController")
    private String mrpController;

    @ApiModelProperty(value = "model")
    private String model;

    @ApiModelProperty(value = "bonded")
    private String bonded;

    @ApiModelProperty(value = "mrpArea")
    private String mrpArea;

    @ApiModelProperty(value = "线别")
    private String lineNo;

    @ApiModelProperty(value = "是否刪除")
    private Boolean isDeleted;

}
