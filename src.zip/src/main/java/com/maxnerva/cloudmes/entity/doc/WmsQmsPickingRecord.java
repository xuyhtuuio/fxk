package com.maxnerva.cloudmes.entity.doc;

import com.maxnerva.cloudmes.common.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

/**
 * <p>
 * qms拣料记录
 * </p>
 *
 * @author likun
 * @since 2022-10-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsQmsPickingRecord对象", description="qms拣料记录")
public class WmsQmsPickingRecord extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "BU(业务单元)")
    private String orgCode;

    @ApiModelProperty(value = "收货单号")
    private String docReceiveNo;

    @ApiModelProperty(value = "pkgId")
    private String pkgId;

    @ApiModelProperty(value = "数量")
    private BigDecimal qty;

    @ApiModelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "制造商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "原始D/C")
    private String originalDateCode;

    @ApiModelProperty(value = "批次号")
    private String lotCode;

    @ApiModelProperty(value = "是否归还")
    private Boolean isReturn;

    @ApiModelProperty(value = "拣料时间")
    private Long pickingTime;

    @ApiModelProperty(value = "拣料人")
    private String picker;

    @ApiModelProperty(value = "归还时间")
    private Long returnTime;

    @ApiModelProperty(value = "归还人")
    private String returnee;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty("库位")
    private String locationCode;

    @ApiModelProperty("储位")
    private String binCode;

    @ApiModelProperty("载具")
    private String vehicleCode;
}
