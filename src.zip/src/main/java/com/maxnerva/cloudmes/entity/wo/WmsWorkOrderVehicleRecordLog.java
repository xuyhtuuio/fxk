package com.maxnerva.cloudmes.entity.wo;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 工单位置信息绑定记录日志表
 * </p>
 *
 * @author likun
 * @since 2022-09-08
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsWorkOrderVehicleRecordLog对象", description="工单位置信息绑定记录日志表")
public class WmsWorkOrderVehicleRecordLog extends BaseEntity<WmsWorkOrderVehicleRecordLog> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "工单绑定位置")
    private String workOrderToLocation;

    @ApiModelProperty(value = "载具编码")
    private String vehicleCode;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "制程分类")
    private String productCategory;
}
