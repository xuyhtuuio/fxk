package com.maxnerva.cloudmes.entity.warehouse;


import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2024-03-08
 */
@TableName("wms_special_dc_log")
@ApiModel(value = "WmsSpecialDcLog对象", description = "")
@Data
public class WmsSpecialDcLog implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty("修改到期日员工")
    private String creator;

    @ApiModelProperty("修改到期日时间")
    private LocalDateTime createdDt;

    @ApiModelProperty("pkg")
    private String pkgId;

    private String reason;

    @ApiModelProperty("修改后到期日")
    private LocalDate endDate;

    @ApiModelProperty("修改前到期日")
    private LocalDate beforeEndDate;
}
