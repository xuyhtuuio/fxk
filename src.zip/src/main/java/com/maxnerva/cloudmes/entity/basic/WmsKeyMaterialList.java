package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.TableName;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 关键物料清单
 * </p>
 *
 * @author baomidou
 * @since 2024-10-25
 */
@TableName("wms_key_material_list")
@ApiModel(value = "WmsKeyMaterialList对象", description = "关键物料清单")
@Data
public class WmsKeyMaterialList extends BaseEntity<WmsKeyMaterialList> {

    private static final long serialVersionUID = 1L;

    private Integer id;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("工厂")
    private String plantCode;

    @ApiModelProperty("料号")
    private String partNo;

    @ApiModelProperty("厂商料号")
    private String mfgPartNo;

    @ApiModelProperty("厂商名")
    private String mfgName;

    @ApiModelProperty("物料分类")
    private String classCode;
}
