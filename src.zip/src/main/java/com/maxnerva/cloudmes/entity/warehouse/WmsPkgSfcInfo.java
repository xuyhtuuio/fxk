package com.maxnerva.cloudmes.entity.warehouse;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @author sclq
 * @date 2022/9/6 15:40
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@Builder
public class WmsPkgSfcInfo extends BaseEntity<WmsPkgSfcInfo> {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "工厂组织")
    private String orgCode;

    @ApiModelProperty(value = "栈板号")
    private String palletNo;

    @ApiModelProperty(value = "箱号")
    private String cartonNo;

    @ApiModelProperty(value = "snNo")
    private String snNo;

    @ApiModelProperty(value = "数量")
    private BigDecimal qty;

    @ApiModelProperty(value = "单位")
    private String uomCode;

    @ApiModelProperty(value = "工单号")
    private String workerOrderNo;

    @ApiModelProperty(value = "成品料号")
    private String partNo;

    @ApiModelProperty(value = "制作商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "生产日期")
    private String dateCode;

    @ApiModelProperty(value = "生产批次")
    private String lotCode;

    @ApiModelProperty(value = "生产控制")
    private String manufactureType;

    @ApiModelProperty(value = "产品类型")
    private String finishedProduct;

    @ApiModelProperty("assetId，mes_sn; sfc需要")
    private String assertId;

    @ApiModelProperty("post_sfc_pass_station_flag")
    private String postSfcPassStationFlag;

    @ApiModelProperty("post_sfc_message")
    private String postSfcMessage;

    @ApiModelProperty("post_sfc_datatime")
    private LocalDateTime postSfcDatatime;

    @ApiModelProperty("sync_sfc_extend_info_result")
    private String syncSfcExtendInfoResult;

    @ApiModelProperty("sfc_model_name")
    private String sfcModelName;

    @ApiModelProperty("sfc_rev")
    private String sfcRev;

    @ApiModelProperty("sfc_model_serial")
    private String sfcModelSerial;

    @ApiModelProperty("sfc_ipn")
    private String sfcIpn;

    @ApiModelProperty("sfc_assetid")
    private String sfcAssetid;

    @ApiModelProperty("出货完成时回写，出货完成：ok")
    private String shippingFlag;

    @ApiModelProperty("出货明细id")
    private Integer shippingDetailId;

    @ApiModelProperty("工厂编码")
    private String plantCode;

    @ApiModelProperty("versionCode")
    private String versionCode;

    @ApiModelProperty("入库类型(默认BY_PALLET-栈板入库  BY_CARTON-箱号入库)")
    private String inStorageType;

    @ApiModelProperty("出货抛SFC结果标识")
    private String shippingToSfcFlag;

    @ApiModelProperty("出货抛SFC结果信息")
    private String shippingToSfcMsg;

    @ApiModelProperty("PKGID")
    private String pkgId;

    @ApiModelProperty("锁定状态 0--正常；1--已锁定")
    private Integer lockStatus;

    @ApiModelProperty("锁定原因")
    private String lockReason;

    @ApiModelProperty("SI号")
    private String siNo;

    @ApiModelProperty("po号")
    private String poNo;

    @ApiModelProperty("客户SN")
    private String customerSn;
}
