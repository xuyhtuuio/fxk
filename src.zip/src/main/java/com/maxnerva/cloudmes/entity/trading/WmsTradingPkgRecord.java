package com.maxnerva.cloudmes.entity.trading;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import lombok.Data;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 内交采集记录(WmsTradingPkgRecord)实体类
 *
 * @author hgx
 * @since 2023-08-31
 */
@Data
@ApiModel("WmsTradingPkgRecord实体类")
public class WmsTradingPkgRecord extends BaseEntity<WmsTradingPkgRecord> {

    
    @ApiModelProperty("id")
    private Integer id;
    /**
     * BU
     */
    @ApiModelProperty("BU")
    private String orgCode;
    /**
     * 工厂
     */
    @ApiModelProperty("工厂")
    private String plantCode;
    /**
     * 内交单号
     */
    @ApiModelProperty("内交单号")
    private String docNo;
    /**
     * pkgid
     */
    @ApiModelProperty("pkgid")
    private String pkgId;
    /**
     * 数量
     */
    @ApiModelProperty("数量")
    private BigDecimal qty;
    /**
     * 料号
     */
    @ApiModelProperty("料号")
    private String partNo;
    /**
     * 制造商料号
     */
    @ApiModelProperty("制造商料号")
    private String supplierPartNo;
    /**
     * 原始DC
     */
    @ApiModelProperty("原始DC")
    private String originalDateCode;
    /**
     * 批次号
     */
    @ApiModelProperty("批次号")
    private String lotCode;
    /**
     * 版次
     */
    @ApiModelProperty("版次")
    private String partVersion;
}

