package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2024-01-20
 */
@Data
@TableName("wms_eccn_report_prepare_pkg_info")
@ApiModel(value = "WmsEccnReportPreparePkgInfo对象", description = "")
public class WmsEccnReportPreparePkgInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer id;

    @ApiModelProperty("eccn单号")
    private String eccnNo;

    @ApiModelProperty("鸿海料号")
    private String partNo;

    @ApiModelProperty("料号描述")
    private String partDesc;

    @ApiModelProperty("厂商名")
    private String mfgName;

    @ApiModelProperty("厂商料号")
    private String mfgPartNo;

    @ApiModelProperty("来源单号")
    private String poNo;

    @ApiModelProperty("来源单号数量")
    private BigDecimal poQty;

    @ApiModelProperty("报关单号")
    private String cusNo;

    @ApiModelProperty("天津工厂入库单号（GR）")
    private String grNo;

    @ApiModelProperty("入库时间")
    private LocalDateTime inWarehouseDt;

    @ApiModelProperty("GR数量")
    private BigDecimal grQty;

    @ApiModelProperty("PKG")
    private String pkgId;

    @ApiModelProperty("PKG数量")
    private BigDecimal pkgQty;

    @ApiModelProperty("创建人")
    private String creator;

    @ApiModelProperty("创建时间")
    private LocalDateTime createdDt;

    @ApiModelProperty("修改人")
    private String lastEditor;

    @ApiModelProperty("修改时间")
    private LocalDateTime lastEditedDt;

    @ApiModelProperty("创建人id")
    private Integer creatorId;

    @ApiModelProperty("修改人id")
    private Integer lastEditorId;

    private String wmsNo;

    private String orgCode;

    private String poItem;

    @ApiModelProperty("工单")
    private String workOrderNo;

    @ApiModelProperty("工单群组")
    private String workOrderItem;

    private String vendorCode;

    @ApiModelProperty("报关单项次")
    private String cusItem;

    private String transPkgId;

    private BigDecimal requiredQuantity;

    @ApiModelProperty(value = "发料数量")
    private BigDecimal prepareQty;

    @ApiModelProperty(value = "发料时间")
    private LocalDateTime prepareDt;

    @ApiModelProperty("PO是否同步完成")
    private Boolean poSyncFlag;

    @ApiModelProperty("起运国")
    private String transpoartCoo;

    @ApiModelProperty(value = "原产国")
    private String coo;

    @ApiModelProperty(value = "licenceNo")
    private String licenceNo;

    @ApiModelProperty(value = "license有效期")
    private LocalDate licenceEndDt;

    @ApiModelProperty(value = "ECCN来源")
    private String eccnFrom;

    @ApiModelProperty(value = "License申请人")
    private String licenseCreator;

    @ApiModelProperty(value = "工单超发数量")
    private BigDecimal prepareConsumeQty;

    @ApiModelProperty(value = "收货PKG")
    private String receivePkgId;

    @ApiModelProperty(value = "单位")
    private String uomCode;

    @ApiModelProperty(value = "入库数量")
    private BigDecimal inWarehouseQty;
}
