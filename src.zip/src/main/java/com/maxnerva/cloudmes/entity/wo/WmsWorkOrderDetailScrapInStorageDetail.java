package com.maxnerva.cloudmes.entity.wo;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDateTime;


/**
 * <p>
 * 工单明细报废单入库明细表
 * </p>
 *
 * @author likun
 * @since 2023-03-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value = "WmsWorkOrderDetailScrapInStorageDetail对象", description = "工单明细报废单入库明细表")
public class WmsWorkOrderDetailScrapInStorageDetail extends BaseEntity<WmsWorkOrderDetailScrapInStorageDetail> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "报废入库单头id")
    private Integer scrapInStorageId;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "厂商")
    private String manufacturer;

    @ApiModelProperty(value = "成品料号")
    private String finishedProductNo;

    @ApiModelProperty(value = "PPID")
    private String ppId;

    @ApiModelProperty(value = "异常描述")
    private String abnormalDesc;

    @ApiModelProperty(value = "D/C")
    private String dateCode;

    @ApiModelProperty(value = "confirm result")
    private String confirmResult;

    @ApiModelProperty(value = "序号")
    private String itemNo;

    @ApiModelProperty(value = "报废描述")
    private String scrapDesc;

    @ApiModelProperty(value = "报废原因code")
    private String scrapReasonCode;

    @ApiModelProperty(value = "报废原因")
    private String scrapReason;

    @ApiModelProperty(value = "DEBIT编号")
    private String debitNo;

    @ApiModelProperty(value = "报废分类")
    private String scrapType;

    @ApiModelProperty(value = "报废分类名称")
    private String scrapTypeName;

    @ApiModelProperty(value = "报废工厂")
    private String manufacturingPlace;

    @ApiModelProperty(value = "flownet单据状态")
    private String flownetFormStatus;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "来源仓码")
    private String fromWhCode;

    @ApiModelProperty(value = "目标仓码")
    private String toWhCode;

    @ApiModelProperty(value = "flownet最后修改日期")
    private String flownetLastUpdateDt;

    @ApiModelProperty(value = "instance id")
    private String flowableInstanceId;

    @ApiModelProperty("fownet单据唯一值")
    private String flownetFormId;

    @ApiModelProperty(value = "抛转sfc标识")
    private Integer postSfcFlag;

    @ApiModelProperty(value = "抛转sfc时间")
    private LocalDateTime postSfcDt;

    @ApiModelProperty(value = "抛转sfc返回信息")
    private String postSfcReturnMessage;

    @ApiModelProperty(value = "入库状态")
    private String inStorageStatus;

    @ApiModelProperty(value = "flownet单号")
    private String businessRequestNo;

    @ApiModelProperty(value = "sfc制造商名称")
    private String sfcMfgName;

    @ApiModelProperty(value = "sfcIpn")
    private String sfcIpn;

    @ApiModelProperty(value = "sfcRev")
    private String sfcRev;

    @ApiModelProperty(value = "sfcAssetid")
    private String sfcAssetid;

    @ApiModelProperty(value = "sfc制造商料号")
    private String sfcMfgPartNo;

    @ApiModelProperty(value = "入库数量")
    private BigDecimal inStorageQty;

    @ApiModelProperty(value = "过账数量")
    private BigDecimal postSapQty;

    @ApiModelProperty(value = "是否新表单")
    private Boolean isNewForm;

    @ApiModelProperty(value = "pkgId")
    private String pkgId;

    @ApiModelProperty("PCB光板料号")
    private String materialHhpn;

    @ApiModelProperty("建单人工号")
    private String businessRequestor;

    @ApiModelProperty("建单人姓名")
    private String businessRequestorName;

    @ApiModelProperty("报废料号")
    private String scrapMaterialNo;
}
