package com.maxnerva.cloudmes.entity.wo;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

/**
 * <p>
 * 缺料信息单头
 * </p>
 *
 * @author likun
 * @since 2022-11-21
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsMaterialShortageHeader对象", description="缺料信息单头")
public class WmsMaterialShortageHeader extends BaseEntity<WmsMaterialShortageHeader> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "缺料流水号")
    private String materialShortageNo;

    @ApiModelProperty(value = "缺料工单信息")
    private String workOrderInfo;

    @ApiModelProperty(value = "抛转准时达标识")
    private Boolean toJusdaFlag;

    @ApiModelProperty(value = "抛转准时达时间")
    private LocalDateTime toJusdaDt;

    @ApiModelProperty(value = "准时达返回信息")
    private String jusdaReturnMessage;
}
