package com.maxnerva.cloudmes.entity.wo;

import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import lombok.Data;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * qms不良结果回传(WmsQmsReworkPkg)实体类
 *
 * @author hgx
 * @since 2023-09-21
 */
@Data
@ApiModel("WmsQmsReworkPkg实体类")
public class WmsQmsReworkPkg extends BaseEntity<WmsQmsReworkPkg> {

    
    @ApiModelProperty("id")
    private Integer id;
    
    @ApiModelProperty("orgCode")
    private String orgCode;
    /**
     * 重工序号
     */
    @ApiModelProperty("重工序号")
    private String reworkDocNo;
    /**
     * pkgid
     */
    @ApiModelProperty("pkgid")
    private String pkgId;
    /**
     * 状态（良品：Y，不良品：N）
     */
    @ApiModelProperty("状态（良品：Y，不良品：N）")
    private String pkgStatus;
    /**
     * 重工责任人
     */
    @ApiModelProperty("重工责任人")
    private String reworkUser;
    /**
     * 重工时间
     */
    @ApiModelProperty("重工时间")
    private LocalDateTime datetime;
    /**
     * pkg原仓码
     */
    @ApiModelProperty("pkg原仓码")
    private String oldWarehouseCode;
    /**
     * pkg目标仓码
     */
    @ApiModelProperty("pkg目标仓码")
    private String targetWarehouseCode;
    /**
     * SAP过账单号
     */
    @ApiModelProperty("SAP过账单号")
    private String postSapNo;
    /**
     * SAP过账信息
     */
    @ApiModelProperty("SAP过账信息")
    private String postSapMsg;
    /**
     * SAP过账时间
     */
    @ApiModelProperty("SAP过账时间")
    private LocalDateTime postSapDate;

    @ApiModelProperty("SAP过账标识")
    private String postSapFlag;

}

