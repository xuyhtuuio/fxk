package com.maxnerva.cloudmes.entity.pack;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;
import java.util.Date;

/**
 * @ClassName ArrangementPlanTargetDay
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/6/10 上午 10:29
 * @Version 1.0
 **/
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("wms_arrangement_plan_target_day")
public class ArrangementPlanTargetDay extends Model<ArrangementPlanTargetDay> {
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    //鸿海料号
    @TableField("hh_pn")
    private String hhPn;
    //运输方式
    private String transportation;
    //排班班别 1:白班/2:夜班
    private String schedule;
    //日期
    @JsonFormat(pattern="yyyy-MM-dd",timezone="GMT+8")
    @TableField("arrangement_date")
    private Date arrangementDate;
    //排配数量
    @TableField("arrangement_num")
    private Integer arrangementNum;
    //供应商
    private String supplier;
    //包材料号
    @TableField("packing_materials_pn")
    private String packingMaterialsPn;
    //需求量
    @TableField("demand_num")
    private Integer demandNum;
    //工令
    @TableField("work_order")
    private String workOrder;
    //出货地
    @TableField("shipment_to")
    private String shipmentTo;
    //创建时间
    @TableField("create_dt")
    private LocalDateTime createDt;

    /**
     * @description:    添加bu信息用于区分 各个bu数据
     * @author:  BZG
     * @date:  2021/9/29
     */
    //所属bu
    @TableField("bu")
    private String bu;
    //bu编码
    @TableField("bu_code")
    private String buCode;
}
