package com.maxnerva.cloudmes.entity.doc;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel("agile回调记录")
@Data
public class WmsAdjustAgileRequestLog extends BaseEntity<WmsAdjustAgileRequestLog> {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "请求json")
    private String requestJson;

    @ApiModelProperty(value = "返回json")
    private String responseJson;
}
