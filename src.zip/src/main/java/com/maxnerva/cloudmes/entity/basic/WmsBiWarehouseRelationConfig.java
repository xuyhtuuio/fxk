package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * BI抓取转仓单信息仓码配置表
 * </p>
 *
 * @author baomidou
 * @since 2025-01-10
 */
@TableName("wms_bi_warehouse_relation_config")
@ApiModel(value = "WmsBiWarehouseRelationConfig对象", description = "BI抓取转仓单信息仓码配置表")
@Data
public class WmsBiWarehouseRelationConfig extends BaseEntity<WmsBiWarehouseRelationConfig> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("ID")
    private Integer id;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("工厂")
    private String plantCode;

    @ApiModelProperty("原仓码")
    private String oldWarehouseCode;

    private String targetWarehouseCode;
}
