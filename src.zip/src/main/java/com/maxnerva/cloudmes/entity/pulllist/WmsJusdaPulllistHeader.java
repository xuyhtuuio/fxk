package com.maxnerva.cloudmes.entity.pulllist;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

/**
 * <p>
 * 
 * </p>
 *
 * @author likun
 * @since 2022-12-19
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsJusdaPulllistHeader对象", description="")
public class WmsJusdaPulllistHeader extends BaseEntity<WmsJusdaPulllistHeader> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "工厂组织")
    private String orgCode;

    @ApiModelProperty(value = "工厂组织")
    private String plantCode;

    @ApiModelProperty(value = "pullList单号")
    private String documentId;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "准时达过账标识")
    private String postingJusdaFlag;

    @ApiModelProperty(value = "准时达过账信息")
    private String postingJusdaMessage;

    @ApiModelProperty(value = "准时达过账日期")
    private LocalDateTime postingJusdaDt;
}
