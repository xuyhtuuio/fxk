package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.*;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * <p>
 * 物料主档定义
 * </p>
 *
 * @author likun
 * @since 2023-01-15
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("basic_sys.basic_material")
public class BasicMaterialEntity extends Model<BasicMaterialEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 上级物料id
     */
    @TableField("pid")
    private Integer pid;

    /**
     * 料号
     */
    @TableField("material_no")
    private String materialNo;

    /**
     * 物料名称
     */
    @TableField("material_name")
    private String materialName;

    /**
     * 客户料号
     */
    @TableField("cust_material_no")
    private String custMaterialNo;

    /**
     * 规格
     */
    @TableField("specs")
    private String specs;

    /**
     * 模穴号
     */
    @TableField("mold_part_no")
    private String moldPartNo;

    /**
     * 产品系列
     */
    @TableField("model")
    private Integer model;

    /**
     * 层次范围
     */
    @TableField("hierarchy_scope")
    private String hierarchyScope;

    /**
     * 路由id
     */
    @TableField("workflow_spec_id")
    private Integer workflowSpecId;

    /**
     * 制程代码
     */
    @TableField("process_code")
    private String processCode;

    /**
     * 版次
     */
    @TableField("version")
    @Version
    private String version;

    /**
     * 商品统一代码
     */
    @TableField("upc")
    private String upc;

    /**
     * 体积
     */
    @TableField("volume")
    private BigDecimal volume;

    /**
     * 体积计量单位id
     */
    @TableField("volume_uom_id")
    private Integer volumeUomId;

    /**
     * 体积长
     */
    @TableField("volume_length")
    private BigDecimal volumeLength;

    /**
     * 体积宽
     */
    @TableField("volume_width")
    private BigDecimal volumeWidth;

    /**
     * 体积高
     */
    @TableField("volume_height")
    private BigDecimal volumeHeight;

    /**
     * 数量单位id
     */
    @TableField("vol_dim_uom_id")
    private Integer volDimUomId;

    /**
     * 物料最小数量
     */
    @TableField("min_qty")
    private BigDecimal minQty;

    /**
     * 最小单位id
     */
    @TableField("min_uom_id")
    private Integer minUomId;

    /**
     * 最小单位数量
     */
    @TableField("min_pack_qty")
    private BigDecimal minPackQty;

    /**
     * 基本计量单位
     */
    @TableField("uom_id")
    private Integer uomId;

    /**
     * 包装单位id（现已合到物料单位）
     */
    @TableField("uom_pack_id")
    private Integer uomPackId;

    /**
     * 净重
     */
    @TableField("net_weight")
    private BigDecimal netWeight;

    /**
     * 毛重
     */
    @TableField("gross_weight")
    private BigDecimal grossWeight;

    /**
     * 重量单位id
     */
    @TableField("weight_uom_id")
    private Integer weightUomId;

    /**
     * 图片链接
     */
    @TableField("t_file_photo_id")
    private String tFilePhotoId;

    /**
     * 组装种类：physical，logical,optional: defines the type of the assembly.the defined types are:physical – the components of the assembly are physically connected or in the same area.logical – the components of the assembly are not necessarily physically connected or in the same area.(可选:定义程序集的类型。定义的类型有:物理：从物理上连接或装配的组件在同一地区。逻辑：的组件组装不一定是身体连接或在同一地区。)
     */
    @TableField("assembly_type")
    private String assemblyType;

    /**
     * 组装关系：permanent，transient,optional: defines the type of the relationships.the defined types are:permanent – an assembly that is not intended to be split during the production process.transient – a temporary assembly using during production, such as a pallet of different materials or a batch kit.(可选:定义的类型的关系。定义的类型有:永久：并不是生产过程中分离。瞬态：一个临时组装生产过程中使用,如不同的材料或一批装备的托盘。)
     */
    @TableField("assembly_relationship")
    private String assemblyRelationship;

    /**
     * 描述
     */
    @TableField("material_desc")
    private String materialDesc;

    /**
     * 物料类型(关联sys_dict)
     */
    @TableField("material_type")
    private String materialType;

    /**
     * 物料类别(关联basic_materialtype)
     */
    @TableField("material_category")
    private Integer materialCategory;

    @TableField("material_sub_type")
    private String materialSubType;

    /**
     * 选项：a，b，c
     */
    @TableField("material_value")
    private String materialValue;

    /**
     * 选项：ssn，lot，不管控：no
     */
    @TableField("scan_mode")
    private String scanMode;

    /**
     * 单价
     */
    @TableField("unit_price")
    private String unitPrice;

    /**
     * 价格单位id
     */
    @TableField("price_uom_id")
    private Integer priceUomId;

    /**
     * 材质
     */
    @TableField("texture_material")
    private String textureMaterial;

    /**
     * 是否被使用
     */
    @TableField("is_used")
    private Boolean isUsed;

    /**
     * 责任人
     */
    @TableField("custodin_code")
    private String custodinCode;

    /**
     * sip id
     */
    @TableField("qom_sip_main_id")
    private Integer qomSipMainId;

    /**
     * 供应商id
     */
    @TableField("vendor_id")
    private Integer vendorId;

    /**
     * 抽样方式 1：n-1 2：n-2 3：n-3 4：c=0 5：不适用
     */
    @TableField("sampling_mode")
    private String samplingMode;

    /**
     * 环测评率
     */
    @TableField("around_test")
    private String aroundTest;

    /**
     * 新料加严批数
     */
    @TableField("new_strict_count")
    private String newStrictCount;

    /**
     * 前批异常加严批数
     */
    @TableField("exception_strict_count")
    private String exceptionStrictCount;

    /**
     * 长期未来料时间（月）
     */
    @TableField("not_have_count")
    private String notHaveCount;

    /**
     * 是否管控
     */
    @TableField("is_water_level")
    private Boolean isWaterLevel;

    /**
     * 库存有效
     */
    @TableField("stock_valid_date")
    private Integer stockValidDate;

    /**
     * 最高水位
     */
    @TableField("upper_quantity")
    private Integer upperQuantity;

    /**
     * 最低水位
     */
    @TableField("lower_quantity")
    private Integer lowerQuantity;

    /**
     * 是否水位预警
     */
    @TableField("is_quantity_alarm")
    private Boolean isQuantityAlarm;

    /**
     * 结构分类(刀柄、刀片、组合刀具等)
     */
    @TableField("structure_class")
    private String structureClass;

    /**
     * 制造商
     */
    @TableField("manufacturer")
    private String manufacturer;

    /**
     * 物料展示分类（空、刀具、备品等）
     */
    @TableField("category_display")
    private String categoryDisplay;

    /**
     * 创建人code
     */
    @TableField("creator")
    private String creator;

    /**
     * 创建人id
     */
    @TableField("creator_id")
    private Integer creatorId;

    /**
     * 创建时间
     */
    @TableField("created_dt")
    private Long createdDt;

    /**
     * 最后一次编辑人code
     */
    @TableField("last_editor")
    private String lastEditor;

    /**
     * 最后一次编辑人id
     */
    @TableField("last_editor_id")
    private Integer lastEditorId;

    /**
     * 最后一次编辑时间
     */
    @TableField("last_edited_dt")
    private Long lastEditedDt;

    @TableField("org_code")
    private String orgCode;

    /**
     * 是否删除
     */
    @TableField("is_deleted")
    private Boolean isDeleted;

    /**
     * FIFO管控，0-不管控，1-30天有效期，2-严格管控
     */
    @TableField("fifo")
    private Integer fifo;

    /**
     * 生产类型
     */
    @TableField("product_type")
    private String productType;

    /**
     * 工厂
     */
    @TableField("plant_code")
    private String plantCode;

    @TableField("product_flag")
    private Boolean productFlag;


    @Override
    public Serializable pkVal() {
        return this.id;
    }

}
