package com.maxnerva.cloudmes.entity.warehouse;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class WmsPkgInfoPart {

    @ApiModelProperty(value = "sap仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "鸿海料号")
    private String partNo;
}
