package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.TableId;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import java.math.BigDecimal;

/**
 * <p>
 * PullList管理属性维护表
 * </p>
 *
 * @author caijun
 * @since 2022-09-26
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value = "WmsPullListManagement对象", description = "PullList管理属性维护表")
public class WmsPullListManagement extends BaseEntity<WmsPullListManagement> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    @TableId
    private Integer id;

    @ApiModelProperty(value = "PullList单号")
    private String pullListNo;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "工单Item")
    private String workOrderItem;

    @ApiModelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "鸿海料号版次")
    private String partVersion;

    @ApiModelProperty(value = "供应商料号")
    private String supplierPartNo;

    @ApiModelProperty(value = "供应商版次")
    private String supplierVersion;

    @ApiModelProperty(value = "数量")
    private BigDecimal qty;

    @ApiModelProperty(value = "单位")
    private String unit;

    @ApiModelProperty(value = "是否成功")
    private Boolean isSuccess;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "BU(业务单元)")
    private String orgCode;
}
