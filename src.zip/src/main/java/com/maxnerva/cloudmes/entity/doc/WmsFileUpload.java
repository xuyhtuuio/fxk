package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.TableId;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 单据上传文件记录表
 * </p>
 *
 * @author likun
 * @since 2022-07-25
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value = "WmsFileUpload对象", description = "单据上传文件记录表")
public class WmsFileUpload extends BaseEntity<WmsFileUpload> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    @TableId
    private Integer id;

    @ApiModelProperty(value = "BU(业务单元)")
    private String orgCode;

    @ApiModelProperty(value = "收货单据表(wms_doc_id)主键id")
    private Integer wmsDocId;

    @ApiModelProperty(value = "单据号码")
    private String docNo;

    @ApiModelProperty(value = "文件名")
    private String fileName;

    @ApiModelProperty(value = "文件地址")
    private String link;

    @ApiModelProperty(value = "文件类型")
    private String fileType;

    @ApiModelProperty(value = "文件大小")
    private String fileSize;

    @ApiModelProperty(value = "文件id")
    private Integer fileId;

    @ApiModelProperty(value = "单据类型")
    private String docType;
}
