package com.maxnerva.cloudmes.entity.pulllist;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>
 * 
 * </p>
 *
 * @author likun
 * @since 2022-12-19
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsJusdaPulllistDetail对象", description="")
public class WmsJusdaPulllistDetail extends BaseEntity<WmsJusdaPulllistDetail> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "工厂组织")
    private String orgCode;

    @ApiModelProperty(value = "pullList项次")
    private Integer documentIdItem;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "工单群组")
    private String workOrderItem;

    @ApiModelProperty(value = "成品料号")
    private String productPartNo;

    @ApiModelProperty(value = "线别")
    private String lineNo;

    @ApiModelProperty(value = "生产日期")
    private LocalDate scheduledDate;

    @ApiModelProperty(value = "主替代料关系")
    private String partRelationShip;

    @ApiModelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "主料号")
    private String mainPartNo;

    @ApiModelProperty(value = "wms群组缺料量")
    private BigDecimal wmsItemShortageQty;

    @ApiModelProperty(value = "wms分配量")
    private BigDecimal wmsAllocateQty;

    @ApiModelProperty(value = "wms分配后的群组缺料量")
    private BigDecimal wmsItemAssignedShortageQty;

    @ApiModelProperty(value = "CMI/VMI分配量")
    private BigDecimal jusdaAllocateQty;

    @ApiModelProperty(value = "CMI/VMI分配后的群组缺料量")
    private BigDecimal jusdaItemAssignedShortageQty;

    @ApiModelProperty(value = "CMI/VMI库存版本号")
    private String jusdaStockVersion;

    @ApiModelProperty(value = "包装数量")
    private BigDecimal minPackQty;

    @ApiModelProperty(value = "缺料流水号")
    private String materialShortageNo;

    @ApiModelProperty(value = "抛jusda时间")
    private LocalDateTime postJusdaDt;

    @ApiModelProperty(value = "抛jusda DocumentId（时间戳）")
    private String postJsudaDocumentId;

    @ApiModelProperty(value = "抛jusda flag（0：失败；1：成功）")
    private String postJusdaFlag;

    @ApiModelProperty(value = "jusda返回remark")
    private String jusdaReturnRemark;

    @ApiModelProperty(value = "enterpriseGroup")
    private String enterpriseGroup;

    @ApiModelProperty(value = "制造商")
    private String manufacture;

    @ApiModelProperty(value = "备注")
    private String remark;
}
