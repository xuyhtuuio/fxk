package com.maxnerva.cloudmes.entity.wo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>
 * 工单header信息表;從APS同步
 * </p>
 *
 * @author likun
 * @since 2022-08-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsWorkOrderHeader对象", description="工单header信息表")
public class WmsWorkOrderHeader extends BaseEntity<WmsWorkOrderHeader> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id;")
    private Integer id;

    @ApiModelProperty(value = "工单号，aufnr;工单编号")
    private String workOrderNo;

    @ApiModelProperty(value = "BU（业务单元）")
    private String orgCode;

    @ApiModelProperty(value = "sap工厂，werks;工厂")
    private String plantCode;

    @ApiModelProperty(value = "工单类型，auart;//工单类型")
    private String workOrderType;

    @ApiModelProperty(value = "成品料号，matnr;//料號")
    private String partNo;

    @ApiModelProperty(value = "成品料号描述")
    private String partDesc;

    @ApiModelProperty(value = "线别")
    private String lineNo;

    @ApiModelProperty(value = "版本(料号版次)，revlv;//版本标识、修订版本")
    private String partVersion;

    @ApiModelProperty(value = "计划日期,来源sap")
    private LocalDate scheduledDate;

    @ApiModelProperty(value = "计划开始时间，gstrs，来源aps;//计划开始时间")
    private LocalDateTime scheduledStart;

    @ApiModelProperty(value = "计划结束时间")
    private LocalDateTime scheduledEnd;

    @ApiModelProperty(value = "工单数量")
    private BigDecimal workOrderQty;

    @ApiModelProperty(value = "上次更改时间，aedat，同步sap用")
    private LocalDate lastChangeTime;

    @ApiModelProperty(value = "更改人的姓名，aenam;//更改人的姓名")
    private String nameChange;

    @ApiModelProperty(value = "料号群组，matkl;//物料组别")
    private String materialGroup;

    @ApiModelProperty(value = "料号描述，maktx;//物料描述")
    private String materialDescription;

    @ApiModelProperty(value = "存储位置，lgort，sap仓码;//存储位置")
    private String storageLocation;

    @ApiModelProperty(value = "下载detail标识;")
    private Integer downloadDetailFlag;

    @ApiModelProperty(value = "下載detail信息")
    private String downloadDetailMsg;

    @ApiModelProperty(value = "下载detai的时间")
    private LocalDateTime downloadDetailDt;

    @ApiModelProperty(value = "板端类型")
    private String processType;

    @ApiModelProperty(value = "入库数量")
    private BigDecimal inboundQty;

    @ApiModelProperty(value = "过账数量")
    private BigDecimal postTo101Qty;

    @ApiModelProperty(value = "同步上料表标识")
    private Integer syncBomFeederFlag;

    @ApiModelProperty(value = "同步上料表时间")
    private LocalDateTime syncBomFeederDt;

    @ApiModelProperty(value = "同步工单位置标识")
    private Integer syncWorkOrderLocationFlag;

    @ApiModelProperty(value = "同步工单位置时间")
    private LocalDateTime syncWorkOrderLocationDt;

    @ApiModelProperty(value = "工单状态")
    private String workOrderStatus;

    @ApiModelProperty(value = "mrpArea")
    private String mrpArea;

    @ApiModelProperty(value = "mrpController")
    private String mrpController;

    @ApiModelProperty(value = "单位")
    private String uomCode;

    @ApiModelProperty("valueType")
    private String valueType;

    @ApiModelProperty("postTo101Msg")
    private String postTo101Msg;

    @ApiModelProperty("合备工单来源工单号")
    private String mergeOrderItem;

    @ApiModelProperty("合备工单来源最大工单号")
    private String mergeOrderMaxNo;

    @ApiModelProperty("合备项次")
    private String combineItem;

    @ApiModelProperty("锁料时间")
    private LocalDateTime lockWoDateTime;

    @ApiModelProperty("锁工单人员")
    private String lockWoEmpNo;

    @ApiModelProperty("锁工单盘数")
    private BigDecimal lockWoPkgQty;

    @ApiModelProperty("工单捡料盘数")
    private BigDecimal pickWoPkgQty;

    @ApiModelProperty("报废入库数量")
    private BigDecimal scrapInStorageQty;

    @ApiModelProperty("报废入库过账数量")
    private BigDecimal scrapPostSapQty;

    @ApiModelProperty("wms工单状态")
    private String wmsWoStatus;

    private String wmsWoStatusEditor;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime wmsWoStatusLastEditDt;

    @ApiModelProperty(value = "aps最后同步时间")
    private LocalDateTime syncApsLastDatetime;

    @ApiModelProperty(value = "aps计划时间")
    private LocalDate apsWoScheduleDatetime;

    @ApiModelProperty(value = "aps开始时间")
    private LocalDateTime apsWoBeginDatetime;

    @ApiModelProperty(value = "aps结束时间")
    private LocalDateTime apsWoEndDatetime;

    @ApiModelProperty(value = "紧急程度")
    private String apsWoPriority;

    @ApiModelProperty(value = "MES来源 MES、SFC")
    private String mesDataSource;

    @ApiModelProperty(value = "是否生成SWR任务 0未生成，1已生成")
    private String swrFlag;

    @ApiModelProperty(value = "生成SWR任务时间")
    private LocalDateTime swrDt;

    @ApiModelProperty(value = "生成SWR任务异常信息")
    private String swrMessage;
}
