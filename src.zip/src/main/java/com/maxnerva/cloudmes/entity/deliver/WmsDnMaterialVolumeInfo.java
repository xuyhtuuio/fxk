package com.maxnerva.cloudmes.entity.deliver;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
@ApiModel("DN中料号的材积资料")
public class WmsDnMaterialVolumeInfo extends BaseEntity<WmsDnMaterialVolumeInfo> {

    private Integer id;

    @ApiModelProperty("工厂")
    private String plantCode;

    @ApiModelProperty("料号")
    private String partNo;

    @ApiModelProperty("rev")
    private String rev;

    private String zindex;

    private String kunnr;

    @ApiModelProperty("type")
    private String type;


    private String zdefault;

    private String materialRef;
    private String materialBox;
    private BigDecimal qtyPerBox;
    private BigDecimal unitWeightBox;
    private String unitWeightj;
    private String lenght;
    private String width;
    private String height;
    private String unitd;
    private String materialPal;
    private BigDecimal unitWeightPal;
    private String qtyPerPal;
    private String unitw;
    private String qtyBaseBox;
    private String block;
    private BigDecimal ntgew;

    private String palletLength;

    private String palletWidth;

    private String palletHeight;
}
