package com.maxnerva.cloudmes.entity.wo;

import java.time.LocalDateTime;
import lombok.Data;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * (WmsBadProductOperationTypeConfig)实体类
 *
 * @author hgx
 * @since 2023-08-22
 */
@Data
@ApiModel("WmsBadProductOperationTypeConfig实体类")
public class WmsBadProductOperationTypeConfig {

    
    @ApiModelProperty("id")
    private Integer id;
    
    @ApiModelProperty("orgCode")
    private String orgCode;
    
    @ApiModelProperty("plantCode")
    private String plantCode;
    /**
     * 退料类型代码
     */
    @ApiModelProperty("退料类型代码")
    private String operationTypeCode;
    /**
     * 退料类型名称
     */
    @ApiModelProperty("退料类型名称")
    private String operationTypeName;
    /**
     * 不良分类代码
     */
    @ApiModelProperty("不良分类代码")
    private String materialSourceCode;
    /**
     * 不良分类名称
     */
    @ApiModelProperty("不良分类名称")
    private String materialSourceName;
    /**
     * 创建人
     */
    @ApiModelProperty("创建人")
    private String creator;
    /**
     * 创建人员工id，冗余字段
     */
    @ApiModelProperty("创建人员工id，冗余字段")
    private Integer creatorId;
    /**
     * 创建时间
     */
    @ApiModelProperty("创建时间")
    private LocalDateTime createdDt;
    /**
     * 修改人
     */
    @ApiModelProperty("修改人")
    private String lastEditor;
    /**
     * 修改人员工id，冗余字段
     */
    @ApiModelProperty("修改人员工id，冗余字段")
    private Integer lastEditorId;
    /**
     * 修改时间
     */
    @ApiModelProperty("修改时间")
    private LocalDateTime lastEditedDt;
}

