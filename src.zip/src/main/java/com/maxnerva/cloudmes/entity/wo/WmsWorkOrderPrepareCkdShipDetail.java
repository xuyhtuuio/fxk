package com.maxnerva.cloudmes.entity.wo;

import com.baomidou.mybatisplus.annotation.TableName;
import java.math.BigDecimal;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2024-01-19
 */
@Data
@TableName("wms_work_order_prepare_ckd_ship_detail")
@ApiModel(value = "WmsWorkOrderPrepareCkdShipDetail对象", description = "")
public class WmsWorkOrderPrepareCkdShipDetail extends BaseEntity<WmsWorkOrderPrepareCkdShipDetail> {

    private static final long serialVersionUID = 1L;

    private Integer id;

    private String orgCode;

    private String plantCode;

    @ApiModelProperty("料号")
    private String partNo;

    @ApiModelProperty("打包序列号")
    private String serialNo;

    @ApiModelProperty("数量")
    private BigDecimal qty;

    @ApiModelProperty("工单")
    private String workOrderNo;

    @ApiModelProperty("厂商料号")
    private String supplierPartNo;

    @ApiModelProperty("厂商名")
    private String mfgName;

    @ApiModelProperty("项次")
    private String item;

    @ApiModelProperty("仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "原产国")
    private String placeOfOrigin1;

    @ApiModelProperty(value = "出货标识 0未出货，1出货")
    private String shipFlag;

    @ApiModelProperty(value = "箱出是箱号，板出是板号")
    private String ckdBarcode;

}
