package com.maxnerva.cloudmes.entity.wo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author MFQ
 * @date 2023/10/21 下午 03:36
 */
@Data
@ApiModel(value = "WmsNationalComparison对象", description = "原产国对照表")
public class WmsNationalComparison {

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /*
    * 中文
    * */
    @TableField(value = "chinese")
    private String chinese;
    /*
    * 英文
    * */
    @TableField(value = "english")
    private String english;
    /*
    * 三位简称
    * */
    @TableField(value = "three_abbreviation")
    private String threeAbbreviation;
    /*
    * 两位简称
    * */
    @TableField(value = "two_abbreviation")
    private String twoAbbreviation;

}
