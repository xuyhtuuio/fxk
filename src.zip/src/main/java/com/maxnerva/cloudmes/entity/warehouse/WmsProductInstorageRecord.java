package com.maxnerva.cloudmes.entity.warehouse;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import lombok.experimental.Accessors;
import java.math.BigDecimal;


/**
 * 入库记录
 *
 * @author sclq
 * @date 2022/9/6 9:44
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@Builder
public class WmsProductInstorageRecord extends BaseEntity<WmsProductInstorageRecord> {

    /**
     * 主键id
     * */
    @ApiModelProperty(value = "主键id")
    private Integer id;

    /**
     * 工单号
     */
    @ApiModelProperty(value = "工单号")
    private String workerOrderNo;

    /**
     * 排配数量
     */
    @ApiModelProperty(value = "排配数量")
    private BigDecimal allocateQty;

    /**
     * 生产数量
     */
    @ApiModelProperty(value = "生产数量")
    private BigDecimal productionQty;

    /**
     * 已入库数量
     */
    @ApiModelProperty(value = "已入库数量")
    private BigDecimal warehouseQty;

    /**
     * 未入库数量
     */
    @ApiModelProperty(value = "未入库数量")
    private BigDecimal notWarehouseNum;

    /**
     * 栈板号
     */
    @ApiModelProperty(value = "栈板号")
    private String palletNo;

    /**
     * 箱
     */
    @ApiModelProperty(value = "箱")
    private String cartonNo;

    /**
     * sn号
     */
    @ApiModelProperty(value = "sn号")
    private String snNo;

    /**
     * 条码号
     */
    @ApiModelProperty(value = "条码号")
    private String pkgNo;

    /**
     * 库区id
     */
    @ApiModelProperty(value = "库区id")
    private Integer areaId;

    /**
     * 储位id
     */
    @ApiModelProperty(value = "储位id")
    private Integer binId;

    /**
     * ORG_CODE
     */
    @ApiModelProperty(value = "ORG_CODE")
    private String orgCode;

}
