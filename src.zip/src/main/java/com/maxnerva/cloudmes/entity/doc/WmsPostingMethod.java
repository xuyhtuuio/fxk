package com.maxnerva.cloudmes.entity.doc;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * sap过账方法表
 * </p>
 *
 * @author likun
 * @since 2022-07-25
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsPostingMethod对象", description="sap过账方法表")
public class WmsPostingMethod extends BaseEntity<WmsPostingMethod> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "过账方法名称")
    private String postingMethodName;

    @ApiModelProperty(value = "过账方法描述")
    private String postingMethodDescription;

    @ApiModelProperty(value = "调用sap的rfc接口名称，多个方法用逗号隔开")
    private String sapRfcName;

    @ApiModelProperty(value = "调用sap过账请求返回结构体,多个方法的返回体用逗号隔开")
    private String returnBody;

    @ApiModelProperty(value = "BU(业务单元)")
    private String orgCode;
}
