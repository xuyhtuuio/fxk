package com.maxnerva.cloudmes.entity.warehouse;

import com.baomidou.mybatisplus.annotation.TableField;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

/**
 * <p>
 * 特殊用户盘点记录表
 * </p>
 *
 * @author likun
 * @since 2023-08-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsSpecialUserMachineReturnLog对象", description="特殊用户盘点记录表")
public class WmsSpecialUserMachineReturnLog extends BaseEntity<WmsSpecialUserMachineReturnLog> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "条码")
    private String pkgId;

    @ApiModelProperty(value = "盘点前数量")
    private BigDecimal currentQty;

    @ApiModelProperty(value = "盘点后数量")
    private BigDecimal returnQty;

    @ApiModelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "制造商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "制造商名称")
    private String mfgName;

    @ApiModelProperty(value = "原始datecode")
    private String originalDateCode;

    @ApiModelProperty(value = "批次号")
    private String lotCode;

    @ApiModelProperty(value = "供应商料号")
    private String supplierPartNo;

    @TableField(exist = false)
    @ApiModelProperty("macUser")
    private String macUser;
}
