package com.maxnerva.cloudmes.entity.basic;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author likun
 * @since 2023-09-25
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsPlantCustomerConfig对象", description="")
public class WmsPlantCustomerConfig extends BaseEntity<WmsPlantCustomerConfig> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "组织")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "SAP MRP area")
    private String mrpArea;

    @ApiModelProperty(value = "客户名称")
    private String customerName;

    @ApiModelProperty(value = "MES来源 MES、SFC")
    private String mesDataSource;

    @ApiModelProperty(value = "备注")
    private String remark;
}
