package com.maxnerva.cloudmes.entity.wo;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

/**
 * <p>
 * 工单明细缺料单头
 * </p>
 *
 * @author likun
 * @since 2023-03-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsWorkOrderDetailShortageHeader对象", description="工单明细缺料单头")
public class WmsWorkOrderDetailShortageHeader extends BaseEntity<WmsWorkOrderDetailShortageHeader> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "缺料流水号")
    private String materialShortageNo;

    @ApiModelProperty(value = "缺料工单号,多个用逗号隔开")
    private String workOrderNo;

    @ApiModelProperty(value = "抛转准时达标识")
    private String toJusdaFlag;

    @ApiModelProperty(value = "抛转准时达时间")
    private LocalDateTime toJusdaDt;

    @ApiModelProperty(value = "准时达返回结果")
    private String jusdaReturnMessage;

    @ApiModelProperty(value = "0未生成特采，1已生成，2JOB正在执行")
    private String tcStatus;

    @ApiModelProperty(value = "是否抛转到QMS，N/Y")
    private String urgentToQmsFlag;
}
