package com.maxnerva.cloudmes.entity.kanban;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2024-07-18
 */
@TableName("wms_kanban_area_config")
@ApiModel(value = "WmsKanbanAreaConfig对象", description = "")
@Data
public class WmsKanbanAreaConfig extends BaseEntity<WmsKanbanAreaConfig> {

    private static final long serialVersionUID = 1L;

    private Integer id;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("厂部")
    private String factoryCode;

    @ApiModelProperty("库区编码")
    private String areaCode;

    @ApiModelProperty("物料分类")
    private String materialSort;
}
