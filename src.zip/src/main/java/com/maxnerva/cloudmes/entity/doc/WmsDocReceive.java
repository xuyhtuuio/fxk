package com.maxnerva.cloudmes.entity.doc;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>
 * 单据表
 * </p>
 *
 * @author likun
 * @since 2022-09-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsDocReceive对象", description="单据表")
public class WmsDocReceive extends BaseEntity<WmsDocReceive> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU(业务单元)")
    private String orgCode;

    @ApiModelProperty(value = "单据号(系统根据规则自动生成)")
    private String docNo;

    @ApiModelProperty(value = "单据接收日期")
    private LocalDate docCreateDate;

    @ApiModelProperty(value = "单据状态,参考字典WMS-DOC-STATUS")
    private String docStatus;

    @ApiModelProperty(value = "单据类型主键id")
    private Integer wmsDocTypeId;

    @ApiModelProperty(value = "单据类型编码")
    private String docTypeCode;

    @ApiModelProperty(value = "单据类型名称")
    private String docTypeName;

    @ApiModelProperty(value = "单据大类编码")
    private String docCategoryCode;

    @ApiModelProperty(value = "来源单号")
    private String fromDocNo;

    @ApiModelProperty(value = "来源单项次")
    private String fromDocItem;

    @ApiModelProperty(value = "sap仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "sap工厂")
    private String plantCode;

    @ApiModelProperty(value = "po编码")
    private String poNo;

    @ApiModelProperty(value = "po项次")
    private String poItem;

    @ApiModelProperty(value = "采购单号文件类型")
    private String poDocumentType;

    @ApiModelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "鸿海料号版次")
    private String partNoVersion;

    @ApiModelProperty(value = "制造商编码")
    private String mfgCode;

    @ApiModelProperty(value = "制造商名称")
    private String mfgName;

    @ApiModelProperty(value = "制造商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "制造商料号版次")
    private String mfgVersion;

    @ApiModelProperty(value = "客户料号")
    private String customerPartNo;

    @ApiModelProperty(value = "客户料号版次")
    private String customerVersion;

    @ApiModelProperty(value = "单据数量")
    private BigDecimal docQty;

    @ApiModelProperty(value = "确认数量，未启用，默认等于单据数量")
    private BigDecimal confirmQty;

    @ApiModelProperty(value = "操作数量")
    private BigDecimal operateQty;

    @ApiModelProperty(value = "单位编码")
    private String uomCode;

    @ApiModelProperty(value = "单据创建表单结构体")
    private String wmsContent;

    @ApiModelProperty(value = "原产国1")
    private String placeOfOrigin1;

    @ApiModelProperty(value = "原产国2")
    private String placeOfOrigin2;

    @ApiModelProperty(value = "起运国")
    private String shipOfOrigin;

    @ApiModelProperty(value = "采购员")
    private String purchaser;

    @ApiModelProperty(value = "是否强制检验(f-否，t-是)")
    private Boolean isForceInspect;

    @ApiModelProperty(value = "确认收货标识")
    private Integer confirmReceiptFlag;

    @ApiModelProperty(value = "确认收货人")
    private String confirmDocAccount;

    @ApiModelProperty(value = "确认收货信息,收货员操作备注")
    private String confirmDocMessage;

    @ApiModelProperty(value = "确认收货上传图片地址")
    private String confirmDocFileUrl;

    @ApiModelProperty(value = "确认收货日期")
    private LocalDateTime confirmDocDate;

    @ApiModelProperty(value = "是否调用qms标识（Y-是，N-否）")
    private String postingQmsFlag;

    @ApiModelProperty(value = "是否已经抛转qms状态标识（t-否，f-是）")
    private Boolean toQmsFlag;

    @ApiModelProperty(value = "抛转qms信息")
    private String toQmsMessage;

    @ApiModelProperty(value = "抛转qms时间")
    private LocalDateTime toQmsDate;

    @ApiModelProperty(value = "qms返回标识,0-不合格, 1-合格")
    private Integer qmsReturnFlag;

    @ApiModelProperty(value = "qms回写日期")
    private LocalDateTime qmsReturnDate;

    @ApiModelProperty(value = "qms返回信息")
    private String qmsReturnMessage;

    @ApiModelProperty(value = "是否调用sap标识")
    private String postingSapMethodFlag;

    @ApiModelProperty(value = "调用wms方法名")
    private String postingMethodName;

    @ApiModelProperty(value = "调用sap日期")
    private LocalDateTime postingSapMethodDate;

    @ApiModelProperty(value = "调用sap结果")
    private String postingSapMethodResult;

    @ApiModelProperty(value = "sap返回信息")
    private String sapReturnMessage;

    @ApiModelProperty(value = "sao返回单号")
    private String sapReturnNumber;

    @ApiModelProperty(value = "GR单号")
    private String grNo;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "检验结果(良品,不良品)")
    private String inspectResult;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "质量检验状态")
    private String inspectStatus;

    @ApiModelProperty(value = "是否急件")
    private Boolean isUrgent;

    @ApiModelProperty("采购组织")
    private String purchaseOrg;

    @ApiModelProperty("采购组")
    private String purchaseGroup;

    @ApiModelProperty("转良品单号")
    private String sapConfirmNumber;

    @ApiModelProperty("转良品信息")
    private String sapConfirmMessage;

    @ApiModelProperty("转良品时间")
    private LocalDateTime sapConfirmDatetime;

    @ApiModelProperty("转不良品单号")
    private String sapTransferRejectsNumber;

    @ApiModelProperty("转不良品信息")
    private String sapTransferRejectsMessage;

    @ApiModelProperty("转不良品时间")
    private LocalDateTime sapTransferRejectsDatetime;

    @ApiModelProperty("qms返回msg，合格放OK，不合格放原因")
    private String qmsReturnMsg;

    @ApiModelProperty("供应商")
    private String vendorCode;

    @ApiModelProperty(value = "預計送達時間")
    private LocalDate eta;

    @ApiModelProperty(value = "毛重")
    private BigDecimal grossWeight;

    @ApiModelProperty(value = "箱數")
    private Integer cartonQty;

    @ApiModelProperty(value = "板數")
    private Integer palletQty;

    @ApiModelProperty(value = "dc")
    private String dc;

    @ApiModelProperty(value = "發票號碼")
    private String invoiceNo;

    @ApiModelProperty(value = "ECCN NO")
    private String eccnNo;

    @ApiModelProperty("勾兌报关单号")
    private String blendingCusNo;

    @ApiModelProperty("勾兌报关单项次")
    private String blendingCusItem;

    @ApiModelProperty("勾兑报关单异常信息")
    private String blendingCusMessage;

    @ApiModelProperty("勾兑报关单时间")
    private LocalDateTime blendingCusDatetime;

    @ApiModelProperty(value = "0 未勾兑，1勾兑成功，2ecus未查询到报关单")
    private String blendingCusFlag;

    @ApiModelProperty("是否上传SN  Y--是 N--否，默认N")
    private String uploadSnFlag;

    @ApiModelProperty("同步ASN信息状态 0未完成，1完成")
    private String syncAsnFlag;

    @ApiModelProperty("首次抛转QMS时间")
    private LocalDateTime toQmsFirstDate;

    @ApiModelProperty("协作云放行单号")
    private String scReleaseNo;

    @ApiModelProperty("协作云放行原因")
    private String scReleaseReason;

    @ApiModelProperty("协作云，放行单填写未抛QMS原因")
    private String scImpoundReason;
}
