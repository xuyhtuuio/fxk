package com.maxnerva.cloudmes.entity.wo;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * (WmsCreatePoDnConfig)实体类
 *
 * @author hgx
 * @since 2024-02-03
 */

@ApiModel("WmsCreatePoDnConfig实体类")
@Data
public class WmsCreatePoDnConfig extends BaseEntity<WmsCreatePoDnConfig> {
 
   
    @ApiModelProperty("id")
    private Integer id;
   
    @ApiModelProperty("BU")
    private String orgCode;
   
    @ApiModelProperty("SAP工厂")
    private String plantCode;
   
    @ApiModelProperty("出货地")
    private String siteCode;
   
    @ApiModelProperty("越南法人")
    private String compCode;
   
    @ApiModelProperty("PO 类型")
    private String docType;
   
    @ApiModelProperty("vendorCode")
    private String vendorCode;
   
    @ApiModelProperty("采购组织")
    private String purchaseOrg;
   
    @ApiModelProperty("purchaseGroup")
    private String purchaseGroup;
   
    @ApiModelProperty("仓码")
    private String stgeLoc;
   
    @ApiModelProperty("po Partner")
    private String partnerDesc;
   
    @ApiModelProperty("langu")
    private String langu;
   
    @ApiModelProperty("buspartNo")
    private String buspartNo;
   
    @ApiModelProperty("创建的单据类型（1：SO; 2:DN; 3:PGI; 4:billing）")
    private String createDocType;
   
    @ApiModelProperty("买方")
    private String buyerDeptCode;
   
    @ApiModelProperty("卖方")
    private String sellerDeptCode;
   
    @ApiModelProperty("出货点")
    private String shippingPoint;
   
    @ApiModelProperty("销单类型（ZBTO：正常出货）")
    private String salesDocType;
   
    @ApiModelProperty("销售组织")
    private String salesOrganization;
   
    @ApiModelProperty("分销渠道，内外销，E0 外销")
    private String distributionChannel;
   
    @ApiModelProperty("部门（E1,E6）")
    private String division;
   
    @ApiModelProperty("Partner Function（SP/SH）")
    private String partnerBuyerFunction;
   
    @ApiModelProperty("Customer Number")
    private String partnerBuyerFunctionNumber;
   
    @ApiModelProperty("Partner Function（SP/SH）")
    private String partnerSellerFunction;
   
    @ApiModelProperty("Customer Number")
    private String partnerSellerFunctionNumber;
}

