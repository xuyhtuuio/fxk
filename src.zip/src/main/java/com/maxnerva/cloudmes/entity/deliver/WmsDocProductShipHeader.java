package com.maxnerva.cloudmes.entity.deliver;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.common.models.entity.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class WmsDocProductShipHeader extends BaseEntity {
    private Integer id;

    @ApiModelProperty("出库单号")
    private String docNo;

    @ApiModelProperty("单据类型")
    private String docType;

    @ApiModelProperty("单据状态")
    private String status;

    @ApiModelProperty("工厂组织")
    private String orgCode;

    @ApiModelProperty("SAP工厂")
    private String sapPlantCode;

    @ApiModelProperty("计划出货时间")
    private LocalDateTime planShipTime;

    @ApiModelProperty("客户编码")
    private String cusCode;

    @ApiModelProperty("客户名称")
    private String cusName;

    @ApiModelProperty("DN单号")
    private String dnNo;

    @ApiModelProperty("来源类型")
    private String sourceType;

    @ApiModelProperty("ship_code")
    private String shipCode;

    @ApiModelProperty("ship_place")
    private String shipPlace;

    @ApiModelProperty("ship_address1")
    private String shipAddress1;

    @ApiModelProperty("ship_address2")
    private String shipAddress2;

    @ApiModelProperty("ship_to_party_code")
    private String shipToPartyCode;

    @ApiModelProperty("ship_city")
    private String shipCity;

    @ApiModelProperty("address_code")
    private String addressCode;

    @ApiModelProperty(value = "运输方式")
    private String transportMode;

    @ApiModelProperty(value = "删除标识")
    private Boolean isDeleted;

    @ApiModelProperty(value = "是否调用QMS")
    private Boolean postingQmsFlag;

    @ApiModelProperty(value = "是否已抛Q")
    private Boolean toQmsFlag;

    @ApiModelProperty(value = "抛Q信息")
    private String toQmsMessage;

    @ApiModelProperty(value = "抛Q时间")
    private LocalDateTime toQmsDate;

    @ApiModelProperty(value = "抛Q结果（SUCCESS:成功，FAIL:失败）")
    private String toQmsResult;

    @ApiModelProperty(value = "qms返回标识（NG：失败，OK：成功）")
    private String qmsReturnFlag;

    @ApiModelProperty(value = "qms回写日期")
    private LocalDateTime qmsReturnDate;

    @ApiModelProperty(value = "qms返回信息")
    private String qmsReturnMessage;

    @ApiModelProperty(value = "出货地")
    private String siteCode;

    @ApiModelProperty(value = "货柜id")
    private Integer containerId;

    @ApiModelProperty("DN扣账标识（0：未扣，1：已扣）")
    private String pgiFlag;

    @ApiModelProperty("DN扣账时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime pgiDate;

    @ApiModelProperty("DN扣账信息")
    private String pgiMsg;

    @ApiModelProperty("edi拋轉標識（0：待執行，1：未執行）")
    private String ediFlag;

    @ApiModelProperty("edi扣账时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime ediDt;

    @ApiModelProperty("edi扣账信息")
    private String ediMsg;

    private String shName2;
    private String shipAddress3;
    private String shipAddress4;
    private String shipAddress5;
    private String shipAddress6;
    private String soldtoName1;
    private String soldtoName2;
    private String soldtoStras;

    @ApiModelProperty("PO")
    private String po;

    @ApiModelProperty("PO地址code")
    private String poAddressCode;

    @ApiModelProperty("DN预计出货栈板数")
    private Integer expectPalletCount;
}
