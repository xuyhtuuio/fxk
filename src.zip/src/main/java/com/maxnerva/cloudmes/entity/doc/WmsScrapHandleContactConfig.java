package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 报废处理联络单配置
 * </p>
 *
 * @author baomidou
 * @since 2024-09-03
 */
@TableName("wms_scrap_handle_contact_config")
@ApiModel(value = "WmsScrapHandleContactConfig对象", description = "报废处理联络单配置")
@Data
public class WmsScrapHandleContactConfig extends BaseEntity<WmsScrapHandleContactConfig> {

    private static final long serialVersionUID = 1L;

    private Integer id;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("工厂")
    private String plantCode;

    @ApiModelProperty("受文单位")
    private String toDepart;

    @ApiModelProperty("发文部门")
    private String fromDepart;

    @ApiModelProperty("会办单位")
    private String ccDepart;

    @ApiModelProperty("文号")
    private String docNo;

    @ApiModelProperty("副本呈送")
    private String fileSend;

    @ApiModelProperty("日期")
    private String docDate;

    @ApiModelProperty("主旨")
    private String fileTitle;

    @ApiModelProperty("内容")
    private String content;
}
