package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.TableId;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 单据属性维护表
 * </p>
 *
 * @author likun
 * @since 2022-07-25
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value = "WmsDocField对象", description = "单据属性维护表")
public class WmsDocField extends BaseEntity<WmsDocField> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    @TableId
    private Integer id;

    @ApiModelProperty(value = "属性编码")
    private String fieldCode;

    @ApiModelProperty(value = "属性名称")
    private String fieldName;

    @ApiModelProperty(value = "多语言编码，多个编码用逗号隔开")
    private String langCode;

    @ApiModelProperty(value = "多语言翻译，多个语种翻译用逗号隔开")
    private String translation;

    @ApiModelProperty(value = "是否启用(f-否 t-是)，默认f")
    private Boolean isEnable;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "BU(业务单元)")
    private String orgCode;
}
