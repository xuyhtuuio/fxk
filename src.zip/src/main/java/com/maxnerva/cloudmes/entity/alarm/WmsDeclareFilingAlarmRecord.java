package com.maxnerva.cloudmes.entity.alarm;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>
 * 备案预警表
 * </p>
 *
 * @author likun
 * @since 2023-12-19
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value = "WmsDeclareFilingAlarmRecord对象", description = "备案预警表")
public class WmsDeclareFilingAlarmRecord extends BaseEntity<WmsDeclareFilingAlarmRecord> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "物料分类 参考字典BASIC_MATERIAL_GROUP_PRODUCT")
    private String materialGroup;

    @ApiModelProperty(value = "备案状态 0-未备案 1-已备案 默认0")
    private String filingStatus;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "发邮件标识 Y-发送成功 N-未发送成功")
    private String sendMailFlag;

    @ApiModelProperty(value = "最近一次发邮件时间")
    private LocalDateTime sendMailDate;

    @ApiModelProperty(value = "发邮件数据体")
    private String sendMailBody;

    @ApiModelProperty(value = "发邮件信息")
    private String sendMailMsg;

    @ApiModelProperty(value = "是否删除标记")
    private Boolean isDeleted;

    @ApiModelProperty(value = "APS时间")
    private LocalDate scheduleDate;
}
