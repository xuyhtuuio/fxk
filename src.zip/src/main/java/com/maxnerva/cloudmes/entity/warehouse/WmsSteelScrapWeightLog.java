package com.maxnerva.cloudmes.entity.warehouse;

import com.baomidou.mybatisplus.annotation.TableName;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 
 * </p>
 *
 * @author baomidou
 * @since 2024-07-13
 */
@TableName("wms_steel_scrap_weight_log")
@ApiModel(value = "WmsSteelScrapWeightLog对象", description = "")
@Data
public class WmsSteelScrapWeightLog extends BaseEntity<WmsSteelScrapWeightLog> {

    private static final long serialVersionUID = 1L;

    private Integer id;

    @ApiModelProperty("BU")
    private String orgCode;

    @ApiModelProperty("工厂")
    private String plantCode;

    @ApiModelProperty("钢桶编码")
    private String barcode;

    @ApiModelProperty("空桶重量")
    private BigDecimal packWeight;

    @ApiModelProperty("单位")
    private String uomCode;

    @ApiModelProperty("净重")
    private BigDecimal netWeight;

    @ApiModelProperty("毛重")
    private String grossWeight;

    @ApiModelProperty("称重员工")
    private String weighEmpNo;

    @ApiModelProperty("称重时间")
    private LocalDateTime weighDt;

    @ApiModelProperty(value = "N未称重，Y已称重")
    private String weighFlag;
}
