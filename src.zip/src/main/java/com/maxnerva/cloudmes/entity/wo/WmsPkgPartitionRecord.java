package com.maxnerva.cloudmes.entity.wo;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * <p>
 * 分盘任务清单
 * </p>
 *
 * @author likun
 * @since 2023-04-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsPkgPartitionRecord对象", description="分盘任务清单")
public class WmsPkgPartitionRecord extends BaseEntity<WmsPkgPartitionRecord> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "载具")
    private String vehicleCode;

    @ApiModelProperty(value = "分盘pkgid")
    private String partitionPkgId;

    @ApiModelProperty(value = "分盘数量")
    private BigDecimal partitionQty;

    @ApiModelProperty(value = "分盘标识")
    private String partitionFlag;

    @ApiModelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "制造商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "原始datecode 原始D/C")
    private String originalDateCode;

    @ApiModelProperty(value = "批次号")
    private String lotCode;

    @ApiModelProperty(value = "制造商名称")
    private String mfgName;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "捡料类型")
    private String materialProductType;

    @ApiModelProperty(value = "分盘人")
    private String divider;

    @ApiModelProperty(value = "分盘时间")
    private LocalDateTime divideDt;

    @ApiModelProperty(value = "入库人")
    private String inStorageOperator;

    @ApiModelProperty(value = "入库时间")
    private LocalDateTime inStorageDt;
}
