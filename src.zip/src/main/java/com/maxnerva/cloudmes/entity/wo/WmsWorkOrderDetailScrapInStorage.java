package com.maxnerva.cloudmes.entity.wo;

import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * 工单明细报废单入库表
 * </p>
 *
 * @author likun
 * @since 2023-03-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsWorkOrderDetailScrapInStorage对象", description="工单明细报废单入库表")
public class WmsWorkOrderDetailScrapInStorage extends BaseEntity<WmsWorkOrderDetailScrapInStorage> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "报废入库信息")
    private String docInfo;

    @ApiModelProperty(value = "instance id")
    private String flowableInstanceId;

    @ApiModelProperty("fownet单据唯一值")
    private String flownetFormId;

    @ApiModelProperty(value = "同步报废入库明细结果标识,0-未同步  1-同步成功   2-同步失败")
    private String syncResultFlag;

    @ApiModelProperty(value = "同步信息")
    private String syncMsg;
}
