package com.maxnerva.cloudmes.entity.warehouse;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * (WmsTopMarkingRecordLog)实体类
 *
 * @author hgx
 * @since 2023-07-06
 */
@Data
@ApiModel("WmsTopMarkingRecordLog实体类")
public class WmsTopMarkingRecordLog extends BaseEntity<WmsTopMarkingRecordLog> {

    
    @ApiModelProperty("id")
    private Integer id;
    
    @ApiModelProperty("orgCode")
    private String orgCode;
    
    @ApiModelProperty("plantCode")
    private String plantCode;
    
    @ApiModelProperty("pkgId")
    private String pkgId;
    
    @ApiModelProperty("料号")
    private String partNo;
    /**
     * 制造商名称
     */
    @ApiModelProperty("制造商名称")
    private String mfgName;
    /**
     * 制造商料号
     */
    @ApiModelProperty("制造商料号")
    private String mfgPartNo;
    /**
     * 原始数量
     */
    @ApiModelProperty("原始数量")
    private BigDecimal originalQty;
    /**
     * 可用数量
     */
    @ApiModelProperty("可用数量")
    private BigDecimal currentQty;
    /**
     * 丝印修改原因,init、退料清除、入库丝印、分盘丝印
     */
    @ApiModelProperty("丝印修改原因,init、退料清除、入库丝印、分盘丝印")
    private String tpUpdateReason;
    
    @ApiModelProperty("tpRemark")
    private String tpRemark;
    /**
     * 是否完成丝印，Y：完成 ，N：未完成
     */
    @ApiModelProperty("是否完成丝印，Y：完成 ，N：未完成")
    private String tpCompleted;
    /**
     * 丝印对比方法，value:值对比 ，PIC：图片
     */
    @ApiModelProperty("丝印对比方法，value:值对比 ，PIC：图片")
    private String tpMethod;
    /**
     * 丝印标准值
     */
    @ApiModelProperty("丝印标准值")
    private String tpStandardValue;
    /**
     * 丝印结果
     */
    @ApiModelProperty("丝印结果")
    private String tpValue;
    /**
     * 丝印人员
     */
    @ApiModelProperty("丝印人员")
    private String tpWorker;
    
    @ApiModelProperty("$column.comment")
    private LocalDateTime tpWorkDt;
    /**
     * 丝印失败次数，成功后清0
     */
    @ApiModelProperty("丝印失败次数，成功后清0")
    private Integer tpTimes;
    /**
     * PKG锁定，Y:锁定，N未锁定， 失败3次锁定
     */
    @ApiModelProperty("PKG锁定，Y:锁定，N未锁定， 失败3次锁定")
    private String lockStatus;
}

