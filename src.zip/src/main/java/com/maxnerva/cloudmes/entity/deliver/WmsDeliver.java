package com.maxnerva.cloudmes.entity.deliver;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author sclq
 * @date 2022/9/8 14:18
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class WmsDeliver extends BaseEntity<WmsDeliver> {

    /**
     * 主键id
     */
    @ApiModelProperty(value = "主键id")
    private Integer id;

    /**
     * 出货单号
     */
    @ApiModelProperty(value = "出货单号")
    private String deliverNo;

    /**
     * 单据类型
     */
    @ApiModelProperty(value = "单据类型")
    private String type;

    /**
     * ORG_CODE
     */
    @ApiModelProperty(value = "ORG_CODE")
    private String bu;

    /**
     * 工厂id
     */
    @ApiModelProperty(value = "工厂id")
    private Integer factoryId;

    /**
     * 客户编码
     */
    @ApiModelProperty(value = "客户编码")
    private String customerCode;

    /**
     * 客户名称
     */
    @ApiModelProperty(value = "客户名称")
    private String customerName;

    /**
     * DN单号
     */
    @ApiModelProperty(value = "DN单号")
    private String dnNo;

    /**
     * DN项次
     */
    @ApiModelProperty(value = "DN项次")
    private String dnItem;

    /**
     * 单据状态
     */
    @ApiModelProperty(value = "单据状态")
    private String status;

    /**
     * 计划出货日期
     */
    @ApiModelProperty(value = "计划出货日期")
    private Date plannedShipmentDt;

    /**
     * 鸿海料号
     */
    @ApiModelProperty(value = "鸿海料号")
    private String partNo;

    /**
     * 鸿海物料名称
     */
    @ApiModelProperty(value = "鸿海物料名称")
    private String partName;

    /**
     * 计划出货数量
     */
    @ApiModelProperty(value = "计划出货数量")
    private BigDecimal qty;

    /**
     * 实际出货数量
     */
    @ApiModelProperty(value = "计划出货数量")
    private BigDecimal actualQty;

}
