package com.maxnerva.cloudmes.entity.wo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

/**
 * @author MFQ
 * @date 2023/10/19 下午 05:48
 */
@Data
@ApiModel(value = "WmsCkdFiling对象", description = "备案清单")
public class WmsCkdFiling extends BaseEntity<WmsCkdFiling>{

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    @TableId
    private Integer id;

    /*
    * 鸿海料号
    * */
    @TableField(value = "hh_pn")
    private String hhPn;
    /*
    * 申报要素
    * */
    @TableField(value = "item_desc")
    private String itemDesc;
    /*
    * 备案序号
    * */
    @TableField(value = "cus_no")
    private String cusNo;
    /*
    * 商品编码
    * */
    @TableField(value = "good_no")
    private String goodNo;
    /*
    * 商品品名
    * */
    @TableField(value = "good_name")
    private String goodName;
    /*
    * 申报单位
    * */
    @TableField(value = "cus_une")
    private String cusUne;
    /*
    * 计量单位
    * */
    @TableField(value = "une")
    private String une;
    /*
    * 比例因子
    * */
    @TableField(value = "rate")
    private BigDecimal rate;
    /*
    * 单位净重（申报单位）
    * */
    @TableField(value = "weight_une")
    private BigDecimal weightUne;
    /*
    * 单位净重*比例因子
    * */
    @TableField(value = "weight_cus")
    private BigDecimal weightCus;
    /*
     * 部門
     * */
    @TableField(value = "partment")
    private String partment;
    /*
    * op
    * */
    @TableField(value = "op")
    private String op;
    /*
    * op时间
    * */
    @TableField(value = "op_time")
    private LocalDate opTime;
    /*
     * 组织
     * */
    @TableField(value = "org_code")
    private String orgCode;

    @TableField(value = "up_time")
    private LocalDate upTime;

    // 是否成品 P物料，M成品
    private String materialSort;
}
