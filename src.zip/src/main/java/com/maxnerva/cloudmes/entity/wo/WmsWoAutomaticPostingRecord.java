package com.maxnerva.cloudmes.entity.wo;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * (WmsWoAutomaticPostingRecord)实体类
 *
 * @author makejava
 * @since 2023-10-23 13:30:36
 */
@ApiModel("(WmsWoAutomaticPostingRecord)实体类")
@Data
public class WmsWoAutomaticPostingRecord extends BaseEntity<WmsWoAutomaticPostingRecord> {

    private Integer id;

    private String orgCode;
    /**
     * 过账类型，字典配置
     */
    private String autoPostingType;
    /**
     * 唯一条件，调用方提供
     */
    private String uniqueCondition;
    /**
     * 入库工单号，WO必须存在
     */
    private String warehousingWo;

    /**
     * 入库数量
     */
    private BigDecimal warehousingQty;
    /**
     * 入库附加信息
     */
    private String warehousingInfo;
    /**
     * 备料工单，必须存在
     */
    private String preparationWo;
    /**
     * 料号
     */
    private String partNo;
    /**
     * 仓码
     */
    private String warehouseCode;

    /**
     * 备料状态0:初始值，1：成功，2：失败
     */
    private Integer operationResultFlag;
    /**
     * 备料时间
     */
    private LocalDate operationDt;
    /**
     * 备料结果
     */
    private String operationResult;

}

