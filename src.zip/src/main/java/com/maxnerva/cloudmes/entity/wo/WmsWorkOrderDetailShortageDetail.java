package com.maxnerva.cloudmes.entity.wo;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * <p>
 * 工单明细缺料明细
 * </p>
 *
 * @author likun
 * @since 2023-03-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsWorkOrderDetailShortageDetail对象", description="工单明细缺料明细")
public class WmsWorkOrderDetailShortageDetail extends BaseEntity<WmsWorkOrderDetailShortageDetail> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "工单群组")
    private String workOrderItem;

    @ApiModelProperty(value = "成品料号")
    private String productPartNo;

    @ApiModelProperty(value = "线别")
    private String lineNo;

    @ApiModelProperty(value = "生产日期")
    private LocalDate scheduledDate;

    @ApiModelProperty(value = "主替代料关系")
    private String partRelationShip;

    @ApiModelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "主料号")
    private String mainPartNo;

    @ApiModelProperty(value = "wms群组缺料量")
    private BigDecimal wmsItemShortageQty;

    @ApiModelProperty(value = "wms分配量")
    private BigDecimal wmsAllocateQty;

    @ApiModelProperty(value = "wms分配后的群组缺料量")
    private BigDecimal wmsItemAssignedShortageQty;

    @ApiModelProperty(value = "CMI/VMI分配量")
    private BigDecimal jusdaAllocateQty;

    @ApiModelProperty(value = "CMI/VMI分配后的群组缺料量")
    private BigDecimal jusdaItemAssignedShortageQty;

    @ApiModelProperty(value = "CMI/VMI库存版本号")
    private String jusdaStockVersion;

    @ApiModelProperty(value = "包装数量")
    private BigDecimal minPackQty;

    @ApiModelProperty(value = "缺料流水号")
    private String materialShortageNo;

    @ApiModelProperty("mrpArea")
    private String mrpArea;

    @ApiModelProperty(value = "料号版次")
    private String partVersion;

    @ApiModelProperty(value = "工单需求量")
    private BigDecimal requiredQuantity;

    @ApiModelProperty(value = "仓码")
    private String fromWarehouseCode;

    @ApiModelProperty(value = "制程")
    private String materialProductType;

    @ApiModelProperty(value = "物料类型ABC")
    private String materialType;

    @ApiModelProperty(value = "准时达unknow数量")
    private BigDecimal jusdaUnknowQty;
}
