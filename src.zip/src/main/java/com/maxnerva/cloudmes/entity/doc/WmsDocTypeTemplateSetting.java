package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.TableId;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 单据类型模板参数表
 * </p>
 *
 * @author likun
 * @since 2022-07-25
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value = "WmsDocTypeTemplateSetting对象", description = "单据类型模板参数表")
public class WmsDocTypeTemplateSetting extends BaseEntity<WmsDocTypeTemplateSetting> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    @TableId
    private Integer id;

    @ApiModelProperty(value = "关联单据类型主表id")
    private Integer wmsDocTypeId;

    @ApiModelProperty(value = "单据类型编码")
    private String docTypeCode;

    @ApiModelProperty(value = "控件类型")
    private String type;

    @ApiModelProperty(value = "单据属性主键id")
    private Integer wmsDocFieldId;

    @ApiModelProperty(value = "表单域model字段，对应单据类型属性code")
    private String fieldCode;

    @ApiModelProperty(value = "展示数据列表")
    private String options;

    @ApiModelProperty(value = "栅格占据的列数")
    private Integer span;

    @ApiModelProperty(value = "是否隐藏")
    private Boolean hide;

    @ApiModelProperty(value = "是否必填")
    private Boolean required;

    @ApiModelProperty(value = "顺序")
    private Integer sort;

    @ApiModelProperty(value = "默认值")
    private String defaultValue;

    @ApiModelProperty(value = "BU(业务单元)")
    private String orgCode;
}
