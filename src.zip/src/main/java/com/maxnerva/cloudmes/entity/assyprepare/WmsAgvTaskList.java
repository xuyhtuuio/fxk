package com.maxnerva.cloudmes.entity.assyprepare;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

/**
 * <p>
 * AGV任务列表
 * </p>
 *
 * @author likun
 * @since 2024-05-08
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsAgvTaskList对象", description="AGV任务列表")
public class WmsAgvTaskList extends BaseEntity<WmsAgvTaskList> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "任务单号")
    private String taskNo;

    @ApiModelProperty(value = "AGV任务单号")
    private String agvTaskNo;

    @ApiModelProperty(value = "工单")
    private String workOrderNo;

    @ApiModelProperty(value = "工单位置")
    private String materialProductType;

    @ApiModelProperty(value = "条码")
    private String pkgId;

    @ApiModelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "库区")
    private String areaCode;

    @ApiModelProperty(value = "库位")
    private String locationCode;

    @ApiModelProperty(value = "载具")
    private String vehicleCode;

    @ApiModelProperty(value = "储位")
    private String binCode;

    @ApiModelProperty(value = "AGV目标仓位")
    private String agvTargetWarehouseCode;

    @ApiModelProperty(value = "任务类型")
    private String taskType;

    @ApiModelProperty(value = "任务状态：created（创建）；released（任务执行中）；end（任务结束）")
    private String taskFinishFlag;

    @ApiModelProperty(value = "结案描述")
    private String taskFinishDes;

    @ApiModelProperty(value = "结案时间")
    private LocalDateTime taskFinishDt;

    @ApiModelProperty(value = "结案人")
    private String taskFinishEmp;

    @ApiModelProperty(value = "AGV开始时间")
    private LocalDateTime agvBeginDt;

    @ApiModelProperty(value = "AGV结束时间")
    private LocalDateTime agvEndDt;

    @ApiModelProperty(value = "绑定状态")
    private String bindStatus;

    @ApiModelProperty(value = "采集备货进度标识 默认0 1-成品入库成功 2-成品备货成功")
    private String taskTypeStatus;

    @ApiModelProperty(value = "成品出货明细id")
    private Integer shipDetailId;

    @ApiModelProperty(value = "预出货绑定pkg")
    private String preShipPkgId;
}

