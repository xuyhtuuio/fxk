package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.TableId;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 储位表
 * </p>
 *
 * @author likun
 * @since 2022-07-22
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsBin对象", description="储位表")
public class WmsBin extends BaseEntity<WmsBin> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    @TableId
    private Integer id;

    @ApiModelProperty(value = "BU(业务单元)")
    private String orgCode;

    @ApiModelProperty(value = "关联载具表(wms_vehicle)主键id")
    private Integer wmsVehicleId;

    @ApiModelProperty(value = "载具编码")
    private String vehicleCode;

    @ApiModelProperty(value = "储位编码")
    private String binCode;

    @ApiModelProperty(value = "储位名称")
    private String binName;

    @ApiModelProperty(value = "料号个数")
    private Integer materialCount;

    @ApiModelProperty(value = "pkgId个数")
    private Integer pkgIdCount;

    @ApiModelProperty(value = "管理方式，未启用")
    private String supervisorMode;

    @ApiModelProperty(value = "是否启用(false-否 true-是)，默认false")
    private Boolean isEnable;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "AGV仓位")
    private String agvWarehouseCode;
}
