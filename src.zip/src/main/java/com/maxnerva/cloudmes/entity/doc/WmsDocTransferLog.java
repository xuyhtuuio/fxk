package com.maxnerva.cloudmes.entity.doc;

import com.maxnerva.cloudmes.common.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@ApiModel("转仓单记录表")
@Data
public class WmsDocTransferLog extends BaseEntity {

    private Integer id;

    @ApiModelProperty(value = "工厂组织")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "异动单号")
    private String transactionNo;

    @ApiModelProperty(value = "pkgId")
    private String pkgId;

    @ApiModelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "可用数量")
    private BigDecimal currentQty;

    @ApiModelProperty(value = "制造商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "原始D/C")
    private String originalDateCode;

    @ApiModelProperty(value = "批次号")
    private String lotCode;

    @ApiModelProperty(value = "解析后的D/C")
    private LocalDate dateCode;

    @ApiModelProperty(value = "制造商名称")
    private String mfgName;

    @ApiModelProperty(value = "原仓码")
    private String fromWarehouseCode;

    @ApiModelProperty(value = "目标仓码")
    private String toWarehouseCode;

    @ApiModelProperty(value = "原鸿海版次")
    private String wmsNo;

    @ApiModelProperty(value = "库位编码")
    private String locationCode;

    @ApiModelProperty(value = "储位编码")
    private String binCode;

    @ApiModelProperty(value = "载具")
    private String vehicleCode;

    @ApiModelProperty(value = "版次")
    private String partVersion;

    private Boolean isDeleted;
}
