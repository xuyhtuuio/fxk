package com.maxnerva.cloudmes.entity.wo;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * <p>
 * 工单明细531入库信息表
 * </p>
 *
 * @author likun
 * @since 2023-03-01
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsWorkOrderDetailInStorage对象", description="工单明细531入库信息表")
public class WmsWorkOrderDetailInStorage extends BaseEntity<WmsWorkOrderDetailInStorage> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id;")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "工单群组")
    private String workOrderItem;

    @ApiModelProperty(value = "仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "鴻海料號")
    private String partNo;

    @ApiModelProperty(value = "物料描述")
    private String materialDescription;

    @ApiModelProperty(value = "料号版次")
    private String partVersion;

    @ApiModelProperty(value = "sap需求量")
    private BigDecimal requiredQuantitySap;

    @ApiModelProperty(value = "按单位转换后的WMS需求量")
    private BigDecimal requiredQuantity;

    @ApiModelProperty(value = "wms单位")
    private String uomCode;

    @ApiModelProperty(value = "移动类型")
    private String movementType;

    @ApiModelProperty(value = "sap字段, reservationNumber")
    private String reservationNumber;

    @ApiModelProperty(value = "sap字段, reservationItem")
    private String reservationItem;

    @ApiModelProperty(value = "mrpArea")
    private String mrpArea;

    @ApiModelProperty(value = "mrpController")
    private String mrpController;

    @ApiModelProperty(value = "item number")
    private String itemNumber;

    @ApiModelProperty(value = "value type")
    private String valueType;

    @ApiModelProperty(value = "上架数量")
    private BigDecimal shelfQty;

    @ApiModelProperty(value = "531入库量")
    private BigDecimal postTo531Qty;

    @ApiModelProperty(value = "531入库过账返回信息")
    private String postTo531ReturnMsg;

    @ApiModelProperty(value = "531入库过账返回时间")
    private LocalDateTime postTo531ReturnDt;

    @ApiModelProperty(value = "531入库过账返回单号")
    private String postTo531ReturnNumber;

    @ApiModelProperty(value = "不良品入库数量")
    private BigDecimal badInStorageQty;

    @ApiModelProperty(value = "不良品过账数量")
    private BigDecimal badPostSapQty;
}
