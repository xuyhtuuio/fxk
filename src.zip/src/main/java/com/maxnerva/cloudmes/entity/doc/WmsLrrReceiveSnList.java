package com.maxnerva.cloudmes.entity.doc;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * LRR采集明细
 * </p>
 *
 * @author baomidou
 * @since 2024-09-20
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsLrrReceiveSnList对象", description="LRR采集明细")
public class WmsLrrReceiveSnList extends BaseEntity<WmsLrrReceiveSnList> {

    private static final long serialVersionUID = 1L;

    private Integer id;

    @ApiModelProperty("工厂组织")
    private String orgCode;

    @ApiModelProperty("工厂")
    private String plantCode;

    @ApiModelProperty("WMS单号")
    private String wmsNo;

    @ApiModelProperty("来源单号")
    private String fromDocNo;

    @ApiModelProperty("退货类型")
    private String returnType;

    @ApiModelProperty("预计收货SN")
    private String planSn;

    @ApiModelProperty("仓码")
    private String warehouseCode;

    @ApiModelProperty("不良原因")
    private String badReason;

    @ApiModelProperty("实际扫描SN")
    private String actualSn;

    @ApiModelProperty(value = "SN采集人")
    private String snOperator;

    @ApiModelProperty("SN采集时间")
    private LocalDateTime snScanDt;

    @ApiModelProperty("料号")
    private String partNo;

    @ApiModelProperty("制造商料号")
    private String mfgPartNo;

    @ApiModelProperty("数量")
    private BigDecimal qty;

    @ApiModelProperty("单位")
    private String uomCode;

    private String sfcModelName;

    private String sfcRev;

    private String sfcModelSerial;

    @ApiModelProperty("箱号")
    private String pkgId;

    @ApiModelProperty("开箱标识（0 open, 1 close）")
    private String pkgStatus;

    @ApiModelProperty("关箱时间")
    private LocalDateTime pkgCloseDt;

    @ApiModelProperty("费退单号")
    private String costDocNo;

    @ApiModelProperty("状态 0新建，1已采集，2已开单")
    private String status;

    @ApiModelProperty("SN次数")
    private Integer snTimes;

    @ApiModelProperty("最早出货时间")
    private LocalDateTime firstShipDt;

    @ApiModelProperty("出货DN")
    private String shipDnNo;

    @ApiModelProperty("质保期")
    private LocalDate endDate;

    @ApiModelProperty(value = "是否FA")
    private Boolean isFa;
}
