package com.maxnerva.cloudmes.entity.agile;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel("Agile返回数据")
@Data
public class Body {

    @ApiModelProperty("返回结果")
    private String result;
}
