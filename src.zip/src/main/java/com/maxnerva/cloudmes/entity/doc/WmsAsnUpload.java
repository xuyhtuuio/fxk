package com.maxnerva.cloudmes.entity.doc;

import com.maxnerva.cloudmes.common.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@ApiModel("ASN上传JUSDA")
@Data
public class WmsAsnUpload extends BaseEntity {

    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "sap工厂")
    private String plantCode;

    @ApiModelProperty(value = "单号")
    private String docNo;

    @ApiModelProperty(value = "ASN類型")
    private String asnType;

    @ApiModelProperty(value = "供應商名稱")
    private String supplierName;

    @ApiModelProperty(value = "收貨PO號")
    private String customerPo;

    @ApiModelProperty(value = "收貨PO項次")
    private String customerPoItem;

    @ApiModelProperty(value = "客戶料號")
    private String customerPartNo;

    @ApiModelProperty(value = "出貨數量")
    private Integer shippingQty;

    @ApiModelProperty(value = "預計送達時間")
    private LocalDate eta;

    @ApiModelProperty(value = "發票號碼")
    private String invoiceNo;

    @ApiModelProperty(value = "原產國")
    private String countryOfOriginal;

    @ApiModelProperty(value = "毛重")
    private BigDecimal grossWeight;

    @ApiModelProperty(value = "箱數")
    private Integer cartonQty;

    @ApiModelProperty(value = "板數")
    private Integer palletQty;

    @ApiModelProperty(value = "客戶名稱")
    private String customerName;

    @ApiModelProperty(value = "供應商料號")
    private String supplierPartNo;

    @ApiModelProperty(value = "製造商")
    private String mfr;

    @ApiModelProperty(value = "單價")
    private BigDecimal price;

    @ApiModelProperty(value = "幣別")
    private String currency;

    @ApiModelProperty(value = "ASN類型描述")
    private String asnTypeDescription;

    @ApiModelProperty(value = "進出模式")
    private String inOutMode;

    @ApiModelProperty(value = "保稅性質")
    private String natureOfBond;

    @ApiModelProperty(value = "恒溫否")
    private String thermostatic;

    @ApiModelProperty(value = "適用于物料情況")
    private String partCondition;

    @ApiModelProperty(value = "抛jsda标识（0：未抛，1：已抛）")
    private String postJusdaFlag;

    @ApiModelProperty(value = "jusda返回msg")
    private String postJusdaReturnMsg;

    @ApiModelProperty(value = "post-jusda时间")
    private LocalDateTime postJusdaDate;

    @ApiModelProperty(value = "post-jusda数据")
    private String postJusdaJson;

    @ApiModelProperty(value = "forwarderName")
    private String forwarderName;

    @ApiModelProperty(value = "isIqcRequired")
    private String isIqcRequired;

    @ApiModelProperty(value = "製造商code")
    private String mfrCode;

    @ApiModelProperty(value = "senderId")
    private String senderId;

    @ApiModelProperty(value = "msgType")
    private String msgType;

    @ApiModelProperty(value = "receiverId")
    private String receiverId;

    @ApiModelProperty(value = "remark")
    private String remark;

    @ApiModelProperty(value = "dc")
    private String dc;

    @ApiModelProperty(value = "isDeleted")
    private String isDeleted;

    @ApiModelProperty(value = "關務預報單號項次")
    private String declareItem;

    @ApiModelProperty(value = "發票號")
    private String invoiceNo2;

    @ApiModelProperty(value = "eccnNo")
    private String eccnNo;

    @ApiModelProperty("是否上传SN  Y--是 N--否，默认N")
    private String uploadSnFlag;

    @ApiModelProperty("版次")
    private String partVersion;

    @ApiModelProperty("生成收货单标识 0/1")
    private String syncDocFlag;

    @ApiModelProperty(value = "Vendor")
    private String vendorCode;

    @ApiModelProperty(value = "PO类型")
    private String poDocumentType;

    @ApiModelProperty(value = "仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "单位")
    private String uomCode;

    @ApiModelProperty("采购组织")
    private String purchaseOrg;

    @ApiModelProperty("采购组")
    private String purchaseGroup;
}
