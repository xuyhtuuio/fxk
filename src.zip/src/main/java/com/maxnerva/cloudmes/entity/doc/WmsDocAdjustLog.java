package com.maxnerva.cloudmes.entity.doc;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@ApiModel("调整单记录")
@Data
public class WmsDocAdjustLog extends BaseEntity<WmsDocAdjustLog> {

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "工厂组织")
    private String orgCode;

    @ApiModelProperty(value = "SAP工厂")
    private String plantCode;

    @ApiModelProperty(value = "料调单号")
    private String docNo;

    @ApiModelProperty(value = "原鸿海料号")
    private String fromPartNo;

    @ApiModelProperty(value = "原鸿海料号版次")
    private String fromPartVersion;

    @ApiModelProperty(value = "原仓码")
    private String fromWarehouseCode;

    @ApiModelProperty(value = "原制造商料号")
    private String fromMfgPartNo;

    @ApiModelProperty(value = "原制造商名称")
    private String fromMfgName;

    @ApiModelProperty(value = "原制造商版次")
    private String fromMfgVersion;

    @ApiModelProperty(value = "目标鸿海料号")
    private String toPartNo;

    @ApiModelProperty(value = "目标海料号版次")
    private String toPartVersion;

    @ApiModelProperty(value = "目标仓码")
    private String toWarehouseCode;

    @ApiModelProperty(value = "目标制造商料号")
    private String toMfgPartNo;

    @ApiModelProperty(value = "目标制造商名称")
    private String toMfgName;

    @ApiModelProperty(value = "目标制造商版次")
    private String toMfgVersion;

    @ApiModelProperty(value = "可用数量")
    private BigDecimal currentQty;

    @ApiModelProperty(value = "采集pkgid")
    private String collectPkgId;

    @ApiModelProperty(value = "产生PKGID")
    private String shelfPkgId;

    @ApiModelProperty(value = "原始D/C")
    private String originalDateCode;

    @ApiModelProperty(value = "批次号")
    private String lotCode;

    @ApiModelProperty(value = "目的鸿海料号")
    private LocalDate dateCode;

    @ApiModelProperty(value = "wmsNo")
    private String wmsNo;

    @ApiModelProperty(value = "库位编码")
    private String locationCode;

    @ApiModelProperty(value = "储位编码")
    private String binCode;

    @ApiModelProperty(value = "载具")
    private String vehicleCode;

}
