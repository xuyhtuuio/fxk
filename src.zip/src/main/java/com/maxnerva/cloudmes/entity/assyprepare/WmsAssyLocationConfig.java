package com.maxnerva.cloudmes.entity.assyprepare;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 机构段上料表导入信息表
 * </p>
 *
 * @author likun
 * @since 2024-04-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsAssyLocationConfig对象", description="机构段上料表导入信息表")
public class WmsAssyLocationConfig extends BaseEntity<WmsAssyLocationConfig> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "制程分类")
    private String productProcess;

    @ApiModelProperty(value = "成品料号")
    private String productPartNo;

    @ApiModelProperty(value = "成品料号版次")
    private String productPartVersion;

    @ApiModelProperty(value = "线别")
    private String lineNo;

    @ApiModelProperty(value = "位置")
    private String lineCategory;

    @ApiModelProperty(value = "机台方向")
    private String machineDirection;

    @ApiModelProperty(value = "零件料号")
    private String sparePartNo;

    @ApiModelProperty(value = "零件料号版次")
    private String sparePartVersion;
}
