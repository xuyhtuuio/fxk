package com.maxnerva.cloudmes.entity.basic;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDate;

import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * <p>
 * 序列号生成规则
 * </p>
 *
 * @author baomidou
 * @since 2023-12-11
 */
@TableName("basic_sys.basic_seq")
@ApiModel(value = "BasicSeq对象", description = "序列号生成规则")
public class BasicSeq extends Model<BasicSeq> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键id")
    private Integer id;

    @ApiModelProperty("序列号生成规则名称")
    private String seqName;

    @ApiModelProperty("规则编号")
    private String seqNo;

    @ApiModelProperty("生成时间")
    private LocalDate seqNoDate;

    @ApiModelProperty("长度")
    private Integer length;

    @ApiModelProperty("进制")
    private Integer digits;

    @ApiModelProperty("进制值")
    private String digitString;

    @ApiModelProperty("起始码")
    private String minNo;

    @ApiModelProperty("截止码")
    private String maxNo;

    @ApiModelProperty("编码规则")
    private String seqNoFormat;

    @ApiModelProperty("no_reset: not reset\r\n            daily: reset seq by day\r\n            weekly: reset seq by week\r\n            monthly: reset seq by month\r\n            yearly: reset seq by year\r\n          ")
    private String resetType;

    @ApiModelProperty("星期首日")
    private Integer firstDayOfWeek;

    @ApiModelProperty("描述")
    private String description;

    @ApiModelProperty("是否允许编辑")
    private Boolean isAllowEdit;

    @ApiModelProperty("是否允许删除")
    private Boolean isAllowDelete;

    @ApiModelProperty("进制")
    private String scaleCode;

    @ApiModelProperty("规则类型")
    private String ruleType;

    @ApiModelProperty("重置规则参数下标，用逗号分隔")
    private String resetTypeIndex;

    @ApiModelProperty("创建人code")
    private String creator;

    @ApiModelProperty("创建人id")
    private Integer creatorId;

    @ApiModelProperty("创建时间")
    private Long createdDt;

    @ApiModelProperty("最后一次编辑人code")
    private String lastEditor;

    @ApiModelProperty("最后一次编辑人id")
    private Integer lastEditorId;

    @ApiModelProperty("最后一次编辑时间")
    private Long lastEditedDt;

    private String orgCode;

    @ApiModelProperty("是否删除")
    private Boolean isDeleted;

    @ApiModelProperty("所属模块（工厂id）")
    private Integer factoryId;

    @ApiModelProperty("截取位（格式：{\"参数1\":\"截取位\",\"参数2\":\"截取位\"}）")
    private String extract;

    @ApiModelProperty("客户id")
    private Integer customerId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
    public String getSeqName() {
        return seqName;
    }

    public void setSeqName(String seqName) {
        this.seqName = seqName;
    }
    public String getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }
    public LocalDate getSeqNoDate() {
        return seqNoDate;
    }

    public void setSeqNoDate(LocalDate seqNoDate) {
        this.seqNoDate = seqNoDate;
    }
    public Integer getLength() {
        return length;
    }

    public void setLength(Integer length) {
        this.length = length;
    }
    public Integer getDigits() {
        return digits;
    }

    public void setDigits(Integer digits) {
        this.digits = digits;
    }
    public String getDigitString() {
        return digitString;
    }

    public void setDigitString(String digitString) {
        this.digitString = digitString;
    }
    public String getMinNo() {
        return minNo;
    }

    public void setMinNo(String minNo) {
        this.minNo = minNo;
    }
    public String getMaxNo() {
        return maxNo;
    }

    public void setMaxNo(String maxNo) {
        this.maxNo = maxNo;
    }
    public String getSeqNoFormat() {
        return seqNoFormat;
    }

    public void setSeqNoFormat(String seqNoFormat) {
        this.seqNoFormat = seqNoFormat;
    }
    public String getResetType() {
        return resetType;
    }

    public void setResetType(String resetType) {
        this.resetType = resetType;
    }
    public Integer getFirstDayOfWeek() {
        return firstDayOfWeek;
    }

    public void setFirstDayOfWeek(Integer firstDayOfWeek) {
        this.firstDayOfWeek = firstDayOfWeek;
    }
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    public Boolean getIsAllowEdit() {
        return isAllowEdit;
    }

    public void setIsAllowEdit(Boolean isAllowEdit) {
        this.isAllowEdit = isAllowEdit;
    }
    public Boolean getIsAllowDelete() {
        return isAllowDelete;
    }

    public void setIsAllowDelete(Boolean isAllowDelete) {
        this.isAllowDelete = isAllowDelete;
    }
    public String getScaleCode() {
        return scaleCode;
    }

    public void setScaleCode(String scaleCode) {
        this.scaleCode = scaleCode;
    }
    public String getRuleType() {
        return ruleType;
    }

    public void setRuleType(String ruleType) {
        this.ruleType = ruleType;
    }
    public String getResetTypeIndex() {
        return resetTypeIndex;
    }

    public void setResetTypeIndex(String resetTypeIndex) {
        this.resetTypeIndex = resetTypeIndex;
    }
    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }
    public Integer getCreatorId() {
        return creatorId;
    }

    public void setCreatorId(Integer creatorId) {
        this.creatorId = creatorId;
    }
    public Long getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Long createdDt) {
        this.createdDt = createdDt;
    }
    public String getLastEditor() {
        return lastEditor;
    }

    public void setLastEditor(String lastEditor) {
        this.lastEditor = lastEditor;
    }
    public Integer getLastEditorId() {
        return lastEditorId;
    }

    public void setLastEditorId(Integer lastEditorId) {
        this.lastEditorId = lastEditorId;
    }
    public Long getLastEditedDt() {
        return lastEditedDt;
    }

    public void setLastEditedDt(Long lastEditedDt) {
        this.lastEditedDt = lastEditedDt;
    }
    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }
    public Boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }
    public Integer getFactoryId() {
        return factoryId;
    }

    public void setFactoryId(Integer factoryId) {
        this.factoryId = factoryId;
    }
    public String getExtract() {
        return extract;
    }

    public void setExtract(String extract) {
        this.extract = extract;
    }
    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }
}
