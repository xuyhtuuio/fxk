package com.maxnerva.cloudmes.entity.wo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

/**
 * <p>
 * sfc拣料标识异动记录表
 * </p>
 *
 * @author likun
 * @since 2023-04-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsSfcUnShelfFlagLog对象", description="sfc拣料标识异动记录表")
public class WmsSfcUnShelfFlagLog extends BaseEntity<WmsSfcUnShelfFlagLog> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "pkg")
    private String pkgId;

    @ApiModelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "制造商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "制造商名称")
    private String mfgName;

    @ApiModelProperty(value = "载具")
    private String vehicleCode;

    @ApiModelProperty(value = "储位")
    private String binCode;

    @ApiModelProperty(value = "操作类型")
    private String operateType;

    @ApiModelProperty(value = "操作人")
    private String operator;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "数量")
    private BigDecimal qty;

    @TableField(exist = false)
    @ApiModelProperty(value = "接收人")
    private String acceptEmp;
}
