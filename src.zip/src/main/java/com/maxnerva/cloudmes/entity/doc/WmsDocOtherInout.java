package com.maxnerva.cloudmes.entity.doc;

import com.maxnerva.cloudmes.common.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsDocOtherInout对象", description="单据表")
public class WmsDocOtherInout extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "BU(业务单元)")
    private String orgCode;

    @ApiModelProperty(value = "单据号(系统根据规则自动生成)")
    private String docNo;

    @ApiModelProperty(value = "单据状态,参考字典WMS-DOC-STATUS")
    private String docStatus;

    @ApiModelProperty(value = "单据类型编码")
    private String docTypeCode;

    @ApiModelProperty(value = "单据类型名称")
    private String docTypeName;

    @ApiModelProperty(value = "单据大类编码")
    private String docCategoryCode;

    @ApiModelProperty(value = "sap仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "sap工厂")
    private String plantCode;

    @ApiModelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "鸿海料号版次")
    private String partNoVersion;

    @ApiModelProperty(value = "制造商编码")
    private String mfgCode;

    @ApiModelProperty(value = "制造商名称")
    private String mfgName;

    @ApiModelProperty(value = "制造商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "制造商料号版次")
    private String mfgPartNoVersion;

    @ApiModelProperty(value = "单据数量")
    private BigDecimal docQty;

    @ApiModelProperty(value = "操作数量")
    private BigDecimal operateQty;

    @ApiModelProperty(value = "单位编码")
    private String uomCode;

    @ApiModelProperty(value = "原产国1")
    private String placeOfOrigin1;

    @ApiModelProperty(value = "原产国2")
    private String placeOfOrigin2;

    @ApiModelProperty(value = "是否调用qms标识（Y-是，N-否）")
    private String postingQmsFlag;

    @ApiModelProperty(value = "是否已经抛转qms状态标识（t-否，f-是）")
    private Boolean toQmsFlag;

    @ApiModelProperty(value = "抛转qms信息")
    private String toQmsMessage;

    @ApiModelProperty(value = "抛转qms时间")
    private LocalDateTime toQmsDate;

    @ApiModelProperty(value = "qms返回标识,0-不合格, 1-合格")
    private Integer qmsReturnFlag;

    @ApiModelProperty(value = "qms回写日期")
    private LocalDateTime qmsReturnDate;

    @ApiModelProperty(value = "qms返回信息")
    private String qmsReturnMessage;

    @ApiModelProperty(value = "是否调用sap标识")
    private String postingSapMethodFlag;

    @ApiModelProperty(value = "调用sap日期")
    private LocalDateTime postingSapMethodDate;

    @ApiModelProperty(value = "调用sap结果")
    private String postingSapMethodResult;

    @ApiModelProperty(value = "sap返回信息")
    private String sapReturnMessage;

    @ApiModelProperty(value = "sao返回单号")
    private String sapReturnNumber;

    @ApiModelProperty(value = "GR单号")
    private String grNo;

    @ApiModelProperty(value = "删除标识")
    private Boolean isDeleted;

    @ApiModelProperty(value = "来源单号")
    private String fromDocNo;

    @ApiModelProperty(value = "来源单项次")
    private String fromDocItem;

    @ApiModelProperty(value = "备注")
    private String remark;
}
