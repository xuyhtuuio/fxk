package com.maxnerva.cloudmes.entity.warehouse;

import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import java.math.BigDecimal;

/**
 * <p>
 * 条码位置日志表
 * </p>
 *
 * @author likun
 * @since 2022-08-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value = "WmsPkgPositionLog对象", description = "条码位置日志表")
public class WmsPkgPositionLog extends BaseEntity<WmsPkgPositionLog> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "BU(业务单元)")
    private String orgCode;

    @ApiModelProperty(value = "条码号")
    private String pkgId;

    @ApiModelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "入库状态")
    private String inboundStatus;

    @ApiModelProperty(value = "库位编码")
    private String locationCode;

    @ApiModelProperty(value = "sap仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "异动类型，取字典值编码")
    private String transactionType;

    @ApiModelProperty(value = "异动类型字典值")
    private String transactionMessage;

    @ApiModelProperty(value = "关联储位表(wms_bin)主键id")
    private Integer wmsBinId;

    @ApiModelProperty(value = "储位编码")
    private String binCode;

    @ApiModelProperty(value = "载具编码")
    private String vehicleCode;

    @ApiModelProperty(value = "条码数量")
    private BigDecimal pkgQty;

    @ApiModelProperty(value = "可用数量")
    private BigDecimal availableQty;

    @ApiModelProperty(value = "交易数量")
    private BigDecimal transactionQty;
}
