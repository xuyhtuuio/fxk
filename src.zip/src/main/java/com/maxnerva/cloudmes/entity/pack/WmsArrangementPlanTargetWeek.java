package com.maxnerva.cloudmes.entity.pack;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.maxnerva.cloudmes.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

/**
 * @ClassName WmsArrangementPlanTargetWeek
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/6/9 下午 04:16
 * @Version 1.0
 **/

@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("wms_arrangement_plan_target_week")
public class WmsArrangementPlanTargetWeek extends Model<WmsArrangementPlanTargetWeek> {

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    //鸿海料号
    @TableField("hh_pn")
    private String hhPn;
    //运输方式
    private String transportation;
    //导入年份
    @TableField("import_year")
    private Integer importYear;
    //导入周别
    @TableField("import_week")
    private String importWeek;
    //供应商
    private String supplier;
    //包材料号
    @TableField("packing_materials_pn")
    private String packingMaterialsPn;
    //周一需求量
    @TableField("monday_num")
    private Integer mondayNum;
    //周二需求量
    @TableField("tuesday_num")
    private Integer tuesdayNum;
    //周三需求量
    @TableField("wednesday_num")
    private Integer wednesdayNum;
    //周四需求量
    @TableField("thursday_num")
    private Integer thursdayNum;
    //周五需求量
    @TableField("friday_num")
    private Integer fridayNum;
    //周六需求量
    @TableField("saturday_num")
    private Integer saturdayNum;
    //周日需求量
    @TableField("sunday_num")
    private Integer sundayNum;
    //下一周需求量  注：第一周需求量为周一到周日需求量总和
    @TableField("first_demand_num")
    private Integer firstDemandNum;
    //下二周需求量
    @TableField("second_demand_num")
    private Integer secondDemandNum;
    //下三周需求量
    @TableField("third_demand_num")
    private Integer thirdDemandNum;
    //下四周需求量
    @TableField("fourth_demand_num")
    private Integer fourthDemandNum;
    //下五周需求量
    @TableField("fifth_demand_num")
    private Integer fifthDemandNum;
    //总需求量
    @TableField("total_demand_num")
    private Integer totalDemandNum;
    //创建时间
    @TableField("create_dt")
    private LocalDateTime createDt;
    /**
     * @description:    添加bu信息用于区分 各个bu数据
     * @author:  BZG
     * @date:  2021/9/29
     */
    //所属bu
    @TableField("bu")
    private String bu;
    //bu编码
    @TableField("bu_code")
    private String buCode;
}
