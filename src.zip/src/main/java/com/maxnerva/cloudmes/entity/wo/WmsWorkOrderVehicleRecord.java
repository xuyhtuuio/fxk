package com.maxnerva.cloudmes.entity.wo;

import com.baomidou.mybatisplus.annotation.FieldStrategy;
import com.baomidou.mybatisplus.annotation.TableField;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;


/**
 * <p>
 * 工单绑定载具记录表
 * </p>
 *
 * @author likun
 * @since 2022-09-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="WmsWorkOrderVehicleRecord对象", description="工单绑定载具记录表")
public class WmsWorkOrderVehicleRecord extends BaseEntity<WmsWorkOrderVehicleRecord> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键id")
    private Integer id;

    @ApiModelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "工单绑定位置")
    private String workOrderToLocation;

    @ApiModelProperty(value = "载具编码")
    @TableField(updateStrategy = FieldStrategy.IGNORED)
    private String vehicleCode;

    @ApiModelProperty(value = "BU业务单元")
    private String orgCode;

    @ApiModelProperty(value = "制程分类")
    private String productCategory;
}
