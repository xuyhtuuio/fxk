package com.maxnerva.cloudmes.entity.doc;

import java.time.LocalDateTime;
import com.maxnerva.cloudmes.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * (WmsInvoiceNoList)实体类
 *
 * @author hgx
 * @since 2024-02-26
 */

@ApiModel("WmsInvoiceNoList实体类")
@Data
public class WmsInvoiceNoList extends BaseEntity<WmsInvoiceNoList> {
 
   
    @ApiModelProperty("id")
    private Integer id;
   
    @ApiModelProperty("orgCode")
    private String orgCode;
   
    @ApiModelProperty("invoiceNo")
    private String invoiceNo;
   
    @ApiModelProperty("是否上传文件（N:否，Y:是）")
    private String fileStatus;
   
    @ApiModelProperty("上传人")
    private String uploadUser;
   
    @ApiModelProperty("上传时间")
    private LocalDateTime uploadDate;
}

