package com.maxnerva.cloudmes.entity.doc;

import com.maxnerva.cloudmes.common.models.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


@ApiModel("费领退流程Id配置")
@Data
public class WmsCostFlownetProcessConfig extends BaseEntity {

    @ApiModelProperty(value = "主表id")
    private Integer id;

    @ApiModelProperty(value = "orgCode")
    private String orgCode;

    @ApiModelProperty(value = "单据类型")
    private String docType;

    @ApiModelProperty(value = "流程id")
    private String flownetProcessId;

}
