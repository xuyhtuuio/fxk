package com.maxnerva.cloudmes.entity.warehouse;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.maxnerva.cloudmes.entity.BaseEntity;
import lombok.Data;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * (WmsPkgidLcr)实体类
 *
 * @author hgx
 * @since 2023-08-10
 */
@Data
@ApiModel("WmsPkgidLcr实体类")
public class WmsPkgidLcr extends BaseEntity<WmsPkgidLcr> {

    /**
     * 主键ID
     */
    @ApiModelProperty("主键ID")
    private Long id;
    /**
     * PKGID
     */
    @ApiModelProperty("PKGID")
    private String pkgId;
    
    @ApiModelProperty("orgCode")
    private String orgCode;
    
    @ApiModelProperty("plantCode")
    private String plantCode;
    /**
     * 检验结果
     */
    @ApiModelProperty("检验结果")
    private String checkResult;
    /**
     * 检验时间
     */
    @ApiModelProperty("检验时间")
    private LocalDateTime checkTime;
    /**
     * 检验值
     */
    @ApiModelProperty("检验值")
    private BigDecimal checkValue;
    /**
     * 测量单位
     */
    @ApiModelProperty("测量单位")
    private String uomCode;
    /**
     * qms-lcr上限
     */
    @ApiModelProperty("qms-lcr上限")
    private BigDecimal qmsLcrTop;
    /**
     * qms-lcr下限
     */
    @ApiModelProperty("qms-lcr下限")
    private BigDecimal qmsLcrLow;

    @ApiModelProperty(value = "锁定状态")
    private String lockStatus;

    @ApiModelProperty(value = "锁定时间")
    private LocalDateTime lockDt;

    @ApiModelProperty(value = "测值次数")
    private Integer lcrTimes;
}

