package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("成品料号库存汇总DTO")
@Data
public class CalcProductByPartNoExportDTO {
    @ApiModelProperty(value = "料号")
    @ExcelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "客户")
    @ExcelProperty(value = "客户")
    private String customerName;

    @ApiModelProperty(value = "箱数")
    @ExcelProperty(value = "箱数")
    private BigDecimal cartonQty;

    @ApiModelProperty(value = "产品数（SN数量）")
    @ExcelProperty(value = "产品数量")
    private BigDecimal productQty;
}
