package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;


@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("ASN上传导出DTO")
@Data
public class AnsUploadExportDTO {

    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂", index = 0)
    private String plantCode;

    @ApiModelProperty(value = "单号")
    @ExcelProperty(value = "单号", index = 1)
    private String docNo;

    @ApiModelProperty(value = "ASN类型")
    @ExcelProperty(value = "ASN Type", index = 2)
    private String asnType;

    @ApiModelProperty(value = "關務預報單號")
    @ExcelProperty(value = "關務預報單號", index = 3)
    private String invoiceNo;

    @ApiModelProperty(value = "關務預報單項次")
    @ExcelProperty(value = "關務預報單項次", index = 4)
    private String declareItem;

    @ApiModelProperty(value = "供應商名稱")
    @ExcelProperty(value = "SupplierName", index = 5)
    private String supplierName;

    @ApiModelProperty(value = "客戶名稱")
    @ExcelProperty(value = "CustomerName", index = 6)
    private String customerName;

    @ApiModelProperty(value = "收貨 PO 號")
    @ExcelProperty(value = "CustomerPO", index = 7)
    private String customerPo;

    @ApiModelProperty(value = "收貨 PO 項次")
    @ExcelProperty(value = "CustomerPOItem", index = 8)
    private String customerPoItem;

    @ApiModelProperty(value = "客戶料號")
    @ExcelProperty(value = "CustomerPartNo", index = 9)
    private String customerPartNo;

    @ApiModelProperty(value = "供應商料號")
    @ExcelProperty(value = "SupplierPartNo", index = 10)
    private String supplierPartNo;

    @ApiModelProperty(value = "出貨數量")
    @ExcelProperty(value = "ShippingQty", index = 11)
    private BigDecimal shippingQty;

    @ApiModelProperty(value = "預計送達時間")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @ExcelProperty(value = "ETA", index = 12)
    private String eta;

    @ApiModelProperty(value = "原產國")
    @ExcelProperty(value = "CountryOfOriginal", index = 13)
    private String countryOfOriginal;

    @ApiModelProperty(value = "毛重")
    @ExcelProperty(value = "GrossWeight", index = 14)
    private String grossWeight;

    @ApiModelProperty(value = "箱數")
    @ExcelProperty(value = "CartonQty", index = 15)
    private BigDecimal cartonQty;

    @ApiModelProperty(value = "板數")
    @ExcelProperty(value = "PalletQty", index = 16)
    private BigDecimal palletQty;

    @ApiModelProperty(value = "製造商")
    @ExcelProperty(value = "MFR", index = 17)
    private String mfr;

    @ApiModelProperty(value = "币别")
    @ExcelProperty(value = "Currency", index = 18)
    private String currency;

    @ApiModelProperty(value = "单价")
    @ExcelProperty(value = "Price", index = 19)
    private String price;

    @ApiModelProperty(value = "PartnerReferenceNo")
    @ExcelProperty(value = "PartnerReferenceNo", index = 20)
    private String partnerReferenceNo;

    @ApiModelProperty(value = "ForwarderName")
    @ExcelProperty(value = "ForwarderName", index = 21)
    private String forwarderName;

    @ApiModelProperty(value = "SupplierPackName")
    @ExcelProperty(value = "SupplierPackName", index = 22)
    private String supplierPackName;

    @ApiModelProperty(value = "XOut")
    @ExcelProperty(value = "XOut", index = 23)
    private String xOut;

    @ApiModelProperty(value = "OwnershipType")
    @ExcelProperty(value = "OwnershipType", index = 24)
    private String ownershipType;

    @ApiModelProperty(value = "IsIQCRequired")
    @ExcelProperty(value = "IsIQCRequired", index = 25)
    private String isIqcRequired;

    @ApiModelProperty(value = "上传人")
    @ExcelProperty(value = "上传人", index = 26)
    private String creator;

    @ApiModelProperty(value = "上传人姓名")
    @ExcelProperty(value = "上传人姓名", index = 27)
    private String creatorName;

    @ApiModelProperty(value = "上传时间")
    @ExcelProperty(value = "上传时间", index = 28, converter = LocalDateTimeStringConverter.class)
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "抛jsda标识（0：未抛，1：已抛）")
    @ExcelProperty(value = "抛jsda结果", index = 29)
    private String postJusdaFlag;

    @ApiModelProperty(value = "jusda返回msg")
    @ExcelProperty(value = "jusda返回msg", index = 30)
    private String postJusdaReturnMsg;

    @ApiModelProperty(value = "post-jusda时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "post-jusda时间", index = 31, converter = LocalDateTimeStringConverter.class)
    private LocalDateTime postJusdaDate;

    @ApiModelProperty(value = "發票號")
    @ExcelProperty(value = "發票號", index = 32)
    private String invoiceNo2;

    @ApiModelProperty(value = "eccnNo")
    @ExcelProperty(value = "ECCN NO", index = 33)
    private String eccnNo;

    @ExcelProperty(value = "备注", index = 34)
    @ApiModelProperty(value = "remark")
    private String remark;

    @ExcelProperty(value = "DC", index = 35)
    @ApiModelProperty(value = "dc")
    private String dc;

    @ExcelProperty(value = "版次", index = 36)
    @ApiModelProperty(value = "版次")
    private String partVersion;
}
