package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("制造商信息导出")
@Data
public class GetMaterialMfgExportDTO {
    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "料号")
    @ExcelProperty(value = "料号")
    private String materialNo;

    @ApiModelProperty(value = "制造商料号")
    @ExcelProperty(value = "制造商料号")
    private String mfgMaterialCode;

    @ApiModelProperty(value = "真实制造商料号")
    @ExcelProperty(value = "真实制造商料号")
    private String mfgOriginalMaterial;

    @ApiModelProperty(value = "制造商")
    @ExcelProperty(value = "制造商")
    private String mfgName;

    @ApiModelProperty(value = "DC格式")
    @ExcelProperty(value = "DC格式")
    private String datecodeFormat;

    @ApiModelProperty(value = "最小包装")
    @ExcelProperty(value = "最小包装")
    private BigDecimal packQty;

    @ApiModelProperty(value = "level")
    @ExcelProperty(value = "level")
    private String msdLevel;

    @ApiModelProperty(value = "有效期")
    @ExcelProperty(value = "有效期")
    private String validPeriod;

    @ApiModelProperty(value = "有效期开始")
    @ExcelProperty(value = "有效期开始")
    private String startValidDate;

    @ApiModelProperty(value = "有效期结束")
    @ExcelProperty(value = "有效期结束")
    private String endValidDate;

    @ApiModelProperty(value = "箱包规")
    @ExcelProperty(value = "箱包规")
    private String packRule;

    @ApiModelProperty(value = "包装形式")
    @ExcelProperty(value = "包装形式")
    private String packType;

    @ApiModelProperty(value = "盘尺寸")
    @ExcelProperty(value = "盘尺寸")
    private String feedSize;

    @ApiModelProperty(value = "物料類型")
    @ExcelProperty(value = "物料類型")
    private String materialType;

    @ApiModelProperty(value = "物料分類")
    @ExcelProperty(value = "物料分類")
    private String classCode;

    @ApiModelProperty(value = "管控方式")
    @ExcelProperty(value = "管控方式")
    private String scanMode;

    @ApiModelProperty(value = "FIFO管控")
    @ExcelProperty(value = "FIFO管控")
    private String fifo;

    @ApiModelProperty(value = "LCR")
    @ExcelProperty(value = "LCR")
    private String lcr;

    @ApiModelProperty(value = "Body Markings")
    @ExcelProperty(value = "Body Markings")
    private String bodyMarking;

    @ApiModelProperty(value = "描述")
    @ExcelProperty(value = "描述")
    private String materialName;
}
