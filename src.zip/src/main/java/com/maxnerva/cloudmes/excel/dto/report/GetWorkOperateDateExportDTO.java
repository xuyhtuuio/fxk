package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("工单处理时间DTO")
@Data
public class GetWorkOperateDateExportDTO {
    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "工单")
    @ExcelProperty(value = "工单")
    private String workOrderNo;

    @ApiModelProperty(value = "机种")
    @ExcelProperty(value = "机种")
    private String partNo;

    @ApiModelProperty(value = "线别")
    @ExcelProperty(value = "线别")
    private String lineNo;

    @ApiModelProperty(value = "APS计划日期")
    @ExcelProperty(value = "APS计划日期", converter = LocalDateTimeStringConverter.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime apsWoBeginDatetime;

    @ApiModelProperty(value = "工单数量")
    @ExcelProperty(value = "工单数量")
    private BigDecimal workOrderQty;

    @ApiModelProperty(value = "工单处理开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "工单处理开始时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime woHandleBeginDt;

    @ApiModelProperty(value = "工单处理结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "工单处理结束时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime woHandleEndDt;

    @ApiModelProperty(value = "库区捡料开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "库区捡料开始时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime woPickBeginDt;

    @ApiModelProperty(value = "库区捡料结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "库区捡料结束时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime woPickEndDt;

    @ApiModelProperty(value = "Jusda物料直备开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "Jusda物料直备开始时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime woJusdaBeginDt;

    @ApiModelProperty(value = "Jusda物料直备结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "Jusda物料直备结束时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime woJusdaEndDt;

    @ApiModelProperty(value = "物料拆分开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "物料拆分开始时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime woPartitionBeginDt;

    @ApiModelProperty(value = "物料拆分结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "物料拆分结束时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime woPartitionEndDt;

    @ApiModelProperty(value = "烧录开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "烧录开始时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime woBurnBeginDt;

    @ApiModelProperty(value = "烧录结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "烧录结束时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime woBurnEndDt;

    @ApiModelProperty(value = "剪脚开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "剪脚开始时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime woCutBeginDt;

    @ApiModelProperty(value = "剪脚结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "剪脚结束时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime woCutEndDt;

    @ApiModelProperty(value = "合盘开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "合盘开始时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime woMergeBeginDt;

    @ApiModelProperty(value = "合盘结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "合盘结束时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime woMergeEndDt;

    @ApiModelProperty(value = "分轨开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "分轨开始时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime woDistributeBeginDt;

    @ApiModelProperty(value = "分轨结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "分轨结束时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime woDistributeEndDt;

    @ApiModelProperty(value = "上料车开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "上料车开始时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime woOnlineBeginDt;

    @ApiModelProperty(value = "上料车结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "上料车结束时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime woOnlineEndDt;
}
