package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("CKD在库捡料明细")
@Data
public class PickCkdInStockListExportDTO {
    @ApiModelProperty(value = "料号")
    @ExcelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "工单群组")
    @ExcelProperty(value = "群组")
    private String workOrderItem;

    @ApiModelProperty(value = "主替代料号关系")
    @ExcelProperty(value = "主替代料号关系")
    private String partRelationship;

    @ApiModelProperty(value = "A/B/C")
    @ExcelProperty(value = "A/B/C")
    private String materialType;

    @ApiModelProperty(value = "捡料量")
    @ExcelProperty(value = "捡料量")
    private BigDecimal pickQty;

    @ApiModelProperty(value = "捡料总量")
    @ExcelProperty(value = "捡料总量")
    private BigDecimal pickTotalQty;

    @ApiModelProperty(value = "需求量")
    @ExcelProperty(value = "需求量")
    private BigDecimal requiredQuantitySap;

    @ApiModelProperty(value = "缺料量")
    @ExcelProperty(value = "缺料量")
    private BigDecimal lackQty;

    @ApiModelProperty(value = "Wms库存")
    @ExcelProperty(value = "Wms库存")
    private BigDecimal wmsQty;

    @ApiModelProperty(value = "From仓码")
    @ExcelProperty(value = "From仓码")
    private String fromWarehouseCode;

    @ApiModelProperty(value = "To仓码")
    @ExcelProperty(value = "To仓码")
    private String toWarehouseCode;




}
