package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @ClassName DocCusRecordExportDTO
 * @Description TODO
 * @Author Likun
 * @Date 2024/7/22
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("报关进口信息导出dto")
@Data
public class DocCusRecordExportDTO {

    @ApiModelProperty(value = "po")
    @ExcelProperty(value = "PO", index = 0)
    private String poNo;

    @ApiModelProperty(value = "poItem")
    @ExcelProperty(value = "POItem", index = 1)
    private String poItem;

    @ApiModelProperty(value = "鸿海料号")
    @ExcelProperty(value = "HHPN", index = 2)
    private String partNo;

    @ApiModelProperty(value = "收货数量")
    @ExcelProperty(value = "收货数量", index = 3)
    private BigDecimal receiveQty;

    @ApiModelProperty(value = "净重(备案净重*进口数量)")
    @ExcelProperty(value = "净重", index = 4)
    private BigDecimal netWeight;

    @ApiModelProperty(value = "单价")
    @ExcelProperty(value = "PRICE", index = 5)
    private BigDecimal price;

    @ApiModelProperty(value = "預計送達時間")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @ExcelProperty(value = "预计到厂时间", index = 6)
    private String eta;

    @ApiModelProperty(value = "来源单号")
    @ExcelProperty(value = "来源单号", index = 7)
    private String fromDocNo;

    @ApiModelProperty(value = "来源项次")
    @ExcelProperty(value = "来源项次", index = 8)
    private String fromDocItem;

    @ApiModelProperty(value = "原产国1")
    @ExcelProperty(value = "原产国1", index = 9)
    private String placeOfOrigin1;

    @ApiModelProperty(value = "起运国")
    @ExcelProperty(value = "起运国", index = 10)
    private String shipOfOrigin;

    @ApiModelProperty(value = "毛重")
    @ExcelProperty(value = "毛重", index = 11)
    private BigDecimal grossWeight;

    @ApiModelProperty(value = "箱数")
    @ExcelProperty(value = "箱数", index = 12)
    private Integer cartonQty;

    @ApiModelProperty(value = "板数")
    @ExcelProperty(value = "板数", index = 13)
    private Integer palletQty;

    @ApiModelProperty(value = "备注")
    @ExcelProperty(value = "备注", index = 14)
    private String remark;

    @ApiModelProperty(value = "DC")
    @ExcelProperty(value = "DC", index = 15)
    private String dc;

    @ApiModelProperty(value = "INVOICE NO")
    @ExcelProperty(value = "INVOICE NO", index = 16)
    private String invoiceNo;

    @ApiModelProperty(value = "ECCN NO")
    @ExcelProperty(value = "ECCN NO", index = 17)
    private String eccnNo;

    @ApiModelProperty(value = "应收代付PO2")
    @ExcelProperty(value = "应收代付PO2", index = 18)
    private String poNo2;

    @ApiModelProperty(value = "PO2 Item")
    @ExcelProperty(value = "PO2 Item", index = 19)
    private String poItem2;

    @ApiModelProperty(value = "金额(单价*数量)")
    @ExcelProperty(value = "Amount", index = 20)
    private BigDecimal amount;

    @ApiModelProperty(value = "固定值 默认NEW 100%")
    @ExcelProperty(value = "Remain", index = 21)
    private String remain;

    @ApiModelProperty(value = "单位")
    @ExcelProperty(value = "unit", index = 22)
    private String uomCode;

    @ApiModelProperty(value = "904厂商全称")
    @ExcelProperty(value = "Shipper", index = 23)
    private String shipper;

    @ApiModelProperty(value = "904厂商地址")
    @ExcelProperty(value = "Shipper address", index = 24)
    private String shipperAddress;

    @ApiModelProperty(value = "收货单号")
    @ExcelProperty(value = "收货单号", index = 25)
    private String docNo;

    @ApiModelProperty(value = "制造商名称")
    @ExcelProperty(value = "制造商名称", index = 26)
    private String mfgName;

    @ApiModelProperty(value = "制造商料号")
    @ExcelProperty(value = "制造商料号", index = 27)
    private String mfgPartNo;

    @ApiModelProperty(value = "sap仓码")
    @ExcelProperty(value = "仓码", index = 28)
    private String sapWarehouseCode;

    @ApiModelProperty(value = "单据接收日期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "单据日期", index = 29, converter = LocalDateTimeStringConverter.class)
    private LocalDateTime docCreateDate;

    @ApiModelProperty("是否上传文件（N:否，Y:是）")
    @ExcelProperty(value = "文件状态", index = 30)
    private String fileStatus;

    @ApiModelProperty("工厂")
    @ExcelProperty(value = "工厂", index = 31)
    private String plantCode;
}
