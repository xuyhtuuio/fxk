package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateStringConverter;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;


@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("不良品导出DTO")
@Data
public class BadProductExportDTO {

    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂", index = 0)
    private String plantCode;

    @ApiModelProperty(value = "不良品仓码")
    @ExcelProperty(value = "仓码", index = 1)
    private String badWarehouseCode;

    @ApiModelProperty(value = "单号")
    @ExcelProperty(value = "单号", index = 2)
    private String docNo;

    @ApiModelProperty(value = "操作类型")
    @ExcelProperty(value = "操作类型", index = 3)
    private String operationTypeName;

    @ApiModelProperty(value = "不良分类")
    @ExcelProperty(value = "不良分类", index = 4)
    private String materialSourceName;

    @ApiModelProperty(value = "退料方式")
    @ExcelProperty(value = "退料方式", index = 5)
    private String returnMethodName;

    @ApiModelProperty("是否已领用")
    @ExcelProperty(value = "是否已领用", index = 6)
    private String isInStock;

    @ApiModelProperty(value = "单据状态名称")
    @ExcelProperty(value = "状态", index = 7)
    private String statusName;

    @ApiModelProperty(value = "入库日期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "入库日期", index = 8, converter = LocalDateTimeStringConverter.class)
    private LocalDateTime inStorageDt;

    @ApiModelProperty(value = "鸿海料号")
    @ExcelProperty(value = "鸿海料号", index = 9)
    private String partNo;

    @ApiModelProperty(value = "制造商名称")
    @ExcelProperty(value = "厂商名称", index = 10)
    private String mfgName;

    @ApiModelProperty(value = "制造商料号")
    @ExcelProperty(value = "厂商料号", index = 11)
    private String mfgPartNo;

    @ApiModelProperty(value = "条码号")
    @ExcelProperty(value = "建单条码", index = 12)
    private String pkgId;

    @ApiModelProperty(value = "sn对应pkgid")
    @ExcelProperty(value = "入库条码", index = 13)
    private String snPkgId;

    @ApiModelProperty(value = "数量")
    @ExcelProperty(value = "数量", index = 14)
    private BigDecimal qty;

    @ApiModelProperty(value = "工单号")
    @ExcelProperty(value = "工单号", index = 15)
    private String workOrderNo;

    @ApiModelProperty(value = "良品仓码")
    @ExcelProperty(value = "良品仓码", index = 16)
    private String goodWarehouseCode;

    @ApiModelProperty(value = "不良原因")
    @ExcelProperty(value = "不良原因", index = 17)
    private String badReason;

    @ApiModelProperty("DC")
    @ExcelProperty(value = "DC", index = 18, converter = LocalDateStringConverter.class)
    private LocalDate dateCode;

    @ApiModelProperty("lotCode")
    @ExcelProperty(value = "LC", index = 19)
    private String lotCode;

    @ApiModelProperty(value = "原始datecode")
    @ExcelProperty(value = "原始DC", index = 20)
    private String originalDateCode;

    @ApiModelProperty("原产国")
    @ExcelProperty(value = "原产国", index = 21)
    private String placeOfOrigin1;

    @ApiModelProperty(value = "IQC判定人")
    @ExcelProperty(value = "IQC判定人", index = 22)
    private String iqcPerson;

    @ApiModelProperty(value = "复判结果")
    @ExcelProperty(value = "复判结果", index = 23)
    private String repeatResult;

    @ApiModelProperty(value = "退料次数")
    @ExcelProperty(value = "退料次数", index = 24)
    private String returnCount;

    @ApiModelProperty(value = "库存状态")
    @ExcelProperty(value = "库存状态", index = 25)
    private String inventoryStatus;

    @ApiModelProperty(value = "出库日期")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @ExcelProperty(value = "出库日期", index = 26, converter = LocalDateStringConverter.class)
    private LocalDate shipDate;

    @ApiModelProperty(value = "物控")
    @ExcelProperty(value = "物控", index = 27)
    private String materialControl;

    @ApiModelProperty(value = "对策回复人")
    @ExcelProperty(value = "对策回复人", index = 28)
    private String responder;

    @ApiModelProperty(value = "处理对策")
    @ExcelProperty(value = "处理对策", index = 29)
    private String dealMethod;

    @ApiModelProperty(value = "物料类型")
    @ExcelProperty(value = "物料类型", index = 30)
    private String materialType;

    @ApiModelProperty("是否结案")
    @ExcelProperty(value = "是否结案", index = 31)
    private String qmsReturnIsClose;

    @ApiModelProperty("外观检验结果")
    @ExcelProperty(value = "外观检验结果", index = 32)
    private String qmsReturnWgResult;

    @ApiModelProperty("是否做OSV")
    @ExcelProperty(value = "是否做OSV", index = 33)
    private String qmsReturnIsDoOsv;

    @ApiModelProperty("OSV检验结果")
    @ExcelProperty(value = "OSV检验结果", index = 34)
    private String qmsReturnOsvResult;

    @ApiModelProperty("创建人")
    @ExcelProperty(value = "创建人", index = 35)
    private String creator;

}
