package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDate;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("CKD在库捡料库区库存明细")
@Data
public class PickCkdInPkgStockListExportDTO {
    @ApiModelProperty(value = "pkg")
    @ExcelProperty(value = "条码")
    private String pkgId;

    @ApiModelProperty(value = "数量")
    @ExcelProperty(value = "数量")
    private BigDecimal currentQty;

    @ApiModelProperty(value = "原始D/C")
    @ExcelProperty(value = "原始D/C")
    private String originalDateCode;

    @ApiModelProperty(value = "LOT#")
    @ExcelProperty(value = "LOT#")
    private String lotCode;

    @ApiModelProperty(value = "到期日")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @ExcelProperty(value = "到期日", converter = LocalDateStringConverter.class)
    private LocalDate endDate;

    @ApiModelProperty(value = "制造商料号")
    @ExcelProperty(value = "制造商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "制造商")
    @ExcelProperty(value = "制造商")
    private String mfgName;

    @ApiModelProperty(value = "不良品条码")
    @ExcelProperty(value = "不良品条码")
    private String snPkgId;

    @ApiModelProperty(value = "锁定状态")
    @ExcelProperty(value = "锁定状态")
    private String lockStatus;
}
