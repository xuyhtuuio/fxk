package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.maxnerva.cloudmes.config.LocalDateStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDate;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("成品库存DTO")
@Data
public class FinishStoreExportDTO {
    @ApiModelProperty(value = "库存条码")
    @ExcelProperty(value = "库存条码")
    String pkgId;

    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    String plantCode;

    @ApiModelProperty(value = "仓码")
    @ExcelProperty(value = "仓码")
    String sapWarehouseCode;

    @ApiModelProperty(value = "仓名")
    @ExcelProperty(value = "仓名")
    String warehouseName;

    @ApiModelProperty(value = "可用(0为可用,其他锁定)")
    @ExcelProperty(value = "可用")
    String lockStatusName;

    @ApiModelProperty(value = "锁定原因")
    @ExcelProperty(value = "锁定原因")
    String lockMessage;

    @ApiModelProperty(value = "料号")
    @ExcelProperty(value = "料号")
    String partNo;

    @ApiModelProperty(value = "IPN")
    @ExcelProperty(value = "IPN")
    String sfcIpn;

    @ApiModelProperty(value = "机种名")
    @ExcelProperty(value = "机种名")
    String sfcModelSerial;

    @ApiModelProperty(value = "数量")
    @ExcelProperty(value = "数量")
    BigDecimal currentQty;

    @ApiModelProperty(value = "成品分类")
    @ExcelProperty(value = "成品分类")
    String dictName;

    @ApiModelProperty(value = "库位")
    @ExcelProperty(value = "库位")
    String locationCode;

    @ApiModelProperty(value = "载具")
    @ExcelProperty(value = "载具")
    String vehicleCode;

    @ApiModelProperty(value = "储位")
    @ExcelProperty(value = "储位")
    String binCode;

    @ApiModelProperty(value = "入库日期")
    @ExcelProperty(value = "入库日期", converter = LocalDateStringConverter.class)
    LocalDate dateCode;

    @ApiModelProperty(value = "作业员")
    @ExcelProperty(value = "作业员")
    String staffName;

    @ApiModelProperty(value = "责任单位")
    @ExcelProperty(value = "责任单位")
    String ownerDept;

    @ApiModelProperty(value = "在库天数")
    @ExcelProperty(value = "在库天数")
    Integer datePart;

    @ApiModelProperty(value = "版次")
    @ExcelProperty(value = "版次")
    String partVersion;
}
