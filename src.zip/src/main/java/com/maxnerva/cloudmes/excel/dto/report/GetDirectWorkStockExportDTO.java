package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("直备区作业看板")
@Data
public class GetDirectWorkStockExportDTO {
    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "栈板")
    @ExcelProperty(value = "栈板")
    private String palletNo;

    @ApiModelProperty(value = "送货单号")
    @ExcelProperty(value = "送货单号")
    private String shipId;

    @ApiModelProperty(value = "料号")
    @ExcelProperty(value = "料号")
    private String customerPartNo;

    @ApiModelProperty(value = "送货数量")
    @ExcelProperty(value = "送货数量")
    private BigDecimal packedQty;

    @ApiModelProperty(value = "上架数量")
    @ExcelProperty(value = "上架数量")
    private BigDecimal shelfQty;

    @ApiModelProperty(value = "工单")
    @ExcelProperty(value = "工单")
    private String workOrderNo;

    @ApiModelProperty(value = "转入仓")
    @ExcelProperty(value = "转入仓")
    private String toWarehouseCode;

    @ApiModelProperty(value = "APS日期")
    @ExcelProperty(value = "APS日期")
    private String apsWoScheduleDatetime;

    @ApiModelProperty(value = "单据日期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "单据日期", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime shipDt;

    @ApiModelProperty(value = "线别")
    @ExcelProperty(value = "线别")
    private String lineNo;

    @ApiModelProperty(value = "位置")
    @ExcelProperty(value = "位置")
    private String locationCode;
}
