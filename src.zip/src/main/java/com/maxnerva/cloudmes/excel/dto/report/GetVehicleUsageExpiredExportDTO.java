package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("载具使用超期DTO")
@Data
public class GetVehicleUsageExpiredExportDTO {
    @ApiModelProperty(value = "工厂编码,sap工厂编码;")
    @ExcelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "pkg")
    @ExcelProperty(value = "PKG")
    private String pkgId;

    @ApiModelProperty(value = "鸿海料号")
    @ExcelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "当前数量(在库数量);")
    @ExcelProperty(value = "数量")
    private BigDecimal currentQty;

    @ApiModelProperty(value = "制造商名称")
    @ExcelProperty(value = "制造商名称")
    private String mfgName;

    @ApiModelProperty(value = "制造商料号")
    @ExcelProperty(value = "制造商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "sap仓码")
    @ExcelProperty(value = "sap仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "载具编码")
    @ExcelProperty(value = "载具编码")
    private String vehicleCode;

    @ApiModelProperty(value = "储位编码")
    @ExcelProperty(value = "储位编码")
    private String binCode;

    @ApiModelProperty(value = "上架时间，记录第一次产生条码信息的时间;")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "上架时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime shelfDate;

    @ApiModelProperty(value = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "创建时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "创建人")
    @ExcelProperty(value = "创建人")
    private String creator;

    @ApiModelProperty(value = "锁定原因")
    @ExcelProperty(value = "锁定原因")
    private String lockMessage;

    @ApiModelProperty(value = "异动类型")
    @ExcelProperty(value = "异动类型")
    private String dictName;

    @ApiModelProperty(value = "超期天数")
    @ExcelProperty(value = "超期天数")
    private Integer dayCount;

    @ApiModelProperty(value = "物料位置")
    @ExcelProperty(value = "物料位置")
    private String materialPositionName;
}
