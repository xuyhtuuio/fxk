package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.maxnerva.cloudmes.config.LocalDateStringConverter;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("原物料库存DTO")
@Data
public class GetRawMaterialExportDTO {
    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    String plantCode;

    @ApiModelProperty(value = "仓码")
    @ExcelProperty(value = "仓码")
    String sapWarehouseCode;

    @ApiModelProperty(value = "可用")
    @ExcelProperty(value = "可用")
    String lockStatusName;

    @ApiModelProperty(value = "库存条码")
    @ExcelProperty(value = "库存条码")
    String pkgId;

    @ApiModelProperty(value = "料号")
    @ExcelProperty(value = "料号")
    String partNo;

    @ApiModelProperty(value = "数量")
    @ExcelProperty(value = "数量")
    BigDecimal currentQty;

    @ApiModelProperty(value = "库区")
    @ExcelProperty(value = "库区")
    String areaCode;

    @ApiModelProperty(value = "库位")
    @ExcelProperty(value = "库位")
    String locationCode;

    @ApiModelProperty(value = "载具")
    @ExcelProperty(value = "载具")
    String vehicleCode;

    @ApiModelProperty(value = "储位")
    @ExcelProperty(value = "储位")
    String binCode;

    @ApiModelProperty(value = "制造商料号")
    @ExcelProperty(value = "制造商料号")
    String mfgPartNo;

    @ApiModelProperty(value = "SAP制造商料号")
    @ExcelProperty(value = "SAP制造商料号")
    String supplierPartNo;

    @ApiModelProperty(value = "制造商")
    @ExcelProperty(value = "制造商")
    String mfgName;

    @ApiModelProperty(value = "解析D/C")
    @ExcelProperty(value = "解析D/C", converter = LocalDateStringConverter.class)
    LocalDate dateCode;

    @ApiModelProperty(value = "endDate")
    @ExcelProperty(value = "endDate", converter = LocalDateStringConverter.class)
    LocalDate endDate;

    @ApiModelProperty(value = "原始D/C")
    @ExcelProperty(value = "原始D/C")
    String originalDateCode;

    @ApiModelProperty(value = "Lot")
    @ExcelProperty(value = "Lot")
    String lotCode;

    @ApiModelProperty(value = "仓名")
    @ExcelProperty(value = "仓名")
    String warehouseName;

    @ApiModelProperty(value = "锁定原因")
    @ExcelProperty(value = "锁定原因")
    String lockMessage;

    @ApiModelProperty(value = "物料分类")
    @ExcelProperty(value = "物料分类")
    String classCode;

    @ApiModelProperty(value = "在库天数")
    @ExcelProperty(value = "在库天数")
    String dayCount;

    @ApiModelProperty(value = "责任单位")
    @ExcelProperty(value = "责任单位")
    String ownerDept;

    @ApiModelProperty(value = "最后上架时间")
    @ExcelProperty(value = "最后上架时间", converter = LocalDateTimeStringConverter.class)
    LocalDateTime shelfDate;

    @ApiModelProperty(value = "创建人")
    @ExcelProperty(value = "创建人")
    String creator;

    @ApiModelProperty(value = "创建时间")
    @ExcelProperty(value = "创建时间", converter = LocalDateTimeStringConverter.class)
    LocalDateTime createdDt;

    @ApiModelProperty(value = "修改人")
    @ExcelProperty(value = "修改人")
    String lastEditor;

    @ApiModelProperty(value = "最后修改时间")
    @ExcelProperty(value = "最后修改时间", converter = LocalDateTimeStringConverter.class)
    LocalDateTime lastEditedDt;
}
