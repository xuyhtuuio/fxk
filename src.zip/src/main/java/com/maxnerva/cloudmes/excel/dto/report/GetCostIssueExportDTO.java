package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("费领退过账DTO")
@Data
public class GetCostIssueExportDTO {
    @ApiModelProperty(value = "BU")
    @ExcelProperty(value = "BU")
    String orgCode;


    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    String plantCode;


    @ApiModelProperty(value = "单号")
    @ExcelProperty(value = "单号")
    String docNo;


    @ApiModelProperty(value = "单据类型")
    @ExcelProperty(value = "单据类型")
    String docTypeName;


    @ApiModelProperty(value = "料号")
    @ExcelProperty(value = "料号")
    String partNo;


    @ApiModelProperty(value = "仓码")
    @ExcelProperty(value = "仓码")
    String warehouseCode;


    @ApiModelProperty(value = "是否保税")
    @ExcelProperty(value = "是否保税")
    String isBonded;


    @ApiModelProperty(value = "过账信息")
    @ExcelProperty(value = "过账信息")
    String postSapReturnMsg;


    @ApiModelProperty(value = "申请数量")
    @ExcelProperty(value = "申请数量")
    BigDecimal qty;


    @ApiModelProperty(value = "确认数量")
    @ExcelProperty(value = "确认数量")
    BigDecimal confirmPostingQty;


    @ApiModelProperty(value = "完成数量")
    @ExcelProperty(value = "完成数量")
    BigDecimal completedQty;


    @ApiModelProperty(value = "是否确认")
    @ExcelProperty(value = "是否确认")
    String userConfirmPostingFlag;


    @ApiModelProperty(value = "创建时间")
    @ExcelProperty(value = "创建时间", converter = LocalDateTimeStringConverter.class)
    LocalDateTime createdDt;


    @ApiModelProperty(value = "创建人")
    @ExcelProperty(value = "创建人")
    String creator;


    @ApiModelProperty(value = "创建人")
    @ExcelProperty(value = "创建人")
    String staffName;
}
