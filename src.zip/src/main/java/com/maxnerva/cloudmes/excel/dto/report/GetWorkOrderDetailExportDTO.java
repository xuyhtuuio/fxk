package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("工单发料信息DTO")
@Data
public class GetWorkOrderDetailExportDTO {
    @ApiModelProperty(value = "工单")
    @ExcelProperty(value = "工单")
    String workOrderNo;

    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    String plantCode;

    @ApiModelProperty(value = "Item number")
    @ExcelProperty(value = "Item number")
    String itemNumber;

    @ApiModelProperty(value = "MS关系")
    @ExcelProperty(value = "MS关系")
    String partRelationship;

    @ApiModelProperty(value = "料号")
    @ExcelProperty(value = "料号")
    String partNo;

    @ApiModelProperty(value = "工单群组")
    @ExcelProperty(value = "工单群组")
    String workOrderItem;

    @ApiModelProperty(value = "物料类别")
    @ExcelProperty(value = "物料类别")
    String materialType;

    @ApiModelProperty(value = "SAP需求量")
    @ExcelProperty(value = "SAP需求量")
    BigDecimal requiredQuantitySap;

    @ApiModelProperty(value = "备料量")
    @ExcelProperty(value = "备料量")
    BigDecimal stockQty;

    @ApiModelProperty(value = "备料总量")
    @ExcelProperty(value = "备料总量")
    BigDecimal stockTotalQty;

    @ApiModelProperty(value = "欠发量")
    @ExcelProperty(value = "欠发量")
    BigDecimal lackNum;

    @ApiModelProperty(value = "仓码")
    @ExcelProperty(value = "仓码")
    String fromWarehouseCode;

    @ApiModelProperty(value = "目标仓码")
    @ExcelProperty(value = "目标仓码")
    String toWarehouseCode;

    @ApiModelProperty(value = "261消耗量")
    @ExcelProperty(value = "261消耗量")
    BigDecimal postTo261Qty;

    @ApiModelProperty(value = "262过账量")
    @ExcelProperty(value = "262过账量")
    BigDecimal postTo262Qty;

    @ApiModelProperty(value = "退料量")
    @ExcelProperty(value = "退料量")
    BigDecimal returnQty;

    @ApiModelProperty(value = "移出量")
    @ExcelProperty(value = "移出量")
    BigDecimal removeQty;
}
