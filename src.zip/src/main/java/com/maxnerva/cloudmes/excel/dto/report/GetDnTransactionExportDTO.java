package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("DN扣账DTO")
@Data
public class GetDnTransactionExportDTO {
    @ApiModelProperty(value = "BU")
    @ExcelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "单号")
    @ExcelProperty(value = "单号")
    private String workOrderNo;

    @ApiModelProperty(value = "鸿海料号")
    @ExcelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "数量")
    @ExcelProperty(value = "数量")
    private String qty;

    @ApiModelProperty(value = "仓码")
    @ExcelProperty(value = "仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "DN单号")
    @ExcelProperty(value = "DN单号")
    private String dnNo;

    @ApiModelProperty(value = "项次")
    @ExcelProperty(value = "项次")
    private String item;

    @ApiModelProperty(value = "DN扣账信息")
    @ExcelProperty(value = "DN扣账信息")
    private String pgiMsg;

    @ApiModelProperty(value = "PGI单号")
    @ExcelProperty(value = "PGI单号")
    private String pgiNo;

    @ApiModelProperty(value = "DN扣账标识（0：未扣，1：已扣）")
    @ExcelProperty(value = "DN扣账")
    private String pgiFlagDes;

    @ApiModelProperty(value = "DN扣账时间")
    @ExcelProperty(value = "DN扣账时间", converter = LocalDateTimeStringConverter.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime pgiDate;

    @ApiModelProperty(value = "出货类型")
    @ExcelProperty(value = "出货类型")
    private String shipTypeDes;
}
