package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateStringConverter;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @ClassName ProductScheduleExportDTO
 * @Description TODO
 * @Author Likun
 * @Date 2025/3/17
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("生产排配导出DTO")
@Data
public class ProductScheduleExportDTO {

    @ApiModelProperty("工厂")
    @ExcelProperty(value = "工厂", index = 0)
    private String plantCode;

    @ApiModelProperty("工单")
    @ExcelProperty(value = "工单号", index = 1)
    private String workOrderNo;

    @ApiModelProperty("状态")
    @ExcelProperty(value = "状态", index = 2)
    private String workOrderStatus;

    @ApiModelProperty("类型")
    @ExcelProperty(value = "类型", index = 3)
    private String workOrderType;

    @ApiModelProperty("成品料号")
    @ExcelProperty(value = "成品料号", index = 4)
    private String partNo;

    @ApiModelProperty("计划日期")
    @ExcelProperty(value = "计划日期", index = 5,converter = LocalDateStringConverter.class)
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate scheduledDate;

    @ApiModelProperty("线别")
    @ExcelProperty(value = "线别", index = 6)
    private String lineNo;

    @ApiModelProperty("仓码")
    @ExcelProperty(value = "仓码", index = 7)
    private String storageLocation;

    @ApiModelProperty("计划数量")
    @ExcelProperty(value = "计划数量", index = 8)
    private BigDecimal workOrderQty;

    @ApiModelProperty("备料进度")
    @ExcelProperty(value = "备料进度", index = 9)
    private String prepareProgress;

    @ApiModelProperty("待捡料数量")
    @ExcelProperty(value = "待捡盘数", index = 10)
    private BigDecimal noPickQty;

    @ApiModelProperty("锁料人")
    @ExcelProperty(value = "锁料人", index = 11)
    private String lockWoEmpNo;

    @ApiModelProperty("锁料时间")
    @ExcelProperty(value = "锁料时间", index = 12,converter = LocalDateTimeStringConverter.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime lockWoDateTime;
}
