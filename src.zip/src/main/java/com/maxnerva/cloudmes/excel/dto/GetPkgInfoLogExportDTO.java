package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateStringConverter;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("PKG追踪记录")
@Data
public class GetPkgInfoLogExportDTO {
    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "仓码")
    @ExcelProperty(value = "仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "PKG")
    @ExcelProperty(value = "PKG")
    private String pkgId;

    @ApiModelProperty(value = "料号")
    @ExcelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "原始数量")
    @ExcelProperty(value = "原始数量")
    private BigDecimal originalQty;

    @ApiModelProperty(value = "数量")
    @ExcelProperty(value = "数量")
    private BigDecimal currentQty;

    @ApiModelProperty(value = "异动数量")
    @ExcelProperty(value = "异动数量")
    private BigDecimal transactionQty;

    @ApiModelProperty(value = "异动描述")
    @ExcelProperty(value = "异动描述")
    private String transactionTypeName;

    @ApiModelProperty(value = "异动描述2")
    @ExcelProperty(value = "异动描述2")
    private String transactionMessage;

    @ApiModelProperty(value = "异动单号")
    @ExcelProperty(value = "异动单号")
    private String transactionNumber;

    @ApiModelProperty(value = "wms单号")
    @ExcelProperty(value = "wms单号")
    private String wmsNo;

    @ApiModelProperty(value = "创建人")
    @ExcelProperty(value = "创建人")
    private String creator;

    @ApiModelProperty(value = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "创建时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "制造商料号")
    @ExcelProperty(value = "制造商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "SAP制造商料号")
    @ExcelProperty(value = "SAP制造商料号")
    private String supplierPartNo;

    @ApiModelProperty(value = "制造商")
    @ExcelProperty(value = "制造商")
    private String mfgName;

    @ApiModelProperty(value = "原始D/C")
    @ExcelProperty(value = "原始D/C")
    private String originalDateCode;

    @ApiModelProperty(value = "解析D/C")
    @ExcelProperty(value = "解析D/C", converter = LocalDateStringConverter.class)
    private LocalDate dateCode;

    @ApiModelProperty(value = "endDate")
    @ExcelProperty(value = "endDate", converter = LocalDateStringConverter.class)
    private LocalDate endDate;

    @ApiModelProperty(value = "LOT")
    @ExcelProperty(value = "LOT")
    private String lotCode;

    @ApiModelProperty(value = "父PKG")
    @ExcelProperty(value = "父PKG")
    private String parentPkgId;

    @ApiModelProperty(value = "库区")
    @ExcelProperty(value = "库区")
    private String areaCode;

    @ApiModelProperty(value = "库位")
    @ExcelProperty(value = "库位")
    private String locationCode;

    @ApiModelProperty(value = "载具")
    @ExcelProperty(value = "载具")
    private String vehicleCode;

    @ApiModelProperty(value = "储位")
    @ExcelProperty(value = "储位")
    private String binCode;

    @ApiModelProperty(value = "锁定解锁工单")
    @ExcelProperty(value = "锁定解锁工单")
    private String lockWorkOrderNo;
}
