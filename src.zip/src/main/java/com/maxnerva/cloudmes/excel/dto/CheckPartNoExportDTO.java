package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @Author hgx
 * @Description 验料单导出DTO
 * @Date 2023/5/30
 */
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("验料单导出DTO")
@Data
public class CheckPartNoExportDTO {

    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂", index = 0)
    private String plantCode;

    @ApiModelProperty(value = "WMS单号")
    @ExcelProperty(value = "WMS单号", index = 1)
    private String docNo;

    @ApiModelProperty(value = "鸿海料号")
    @ExcelProperty(value = "料号", index = 2)
    private String partNo;

    @ApiModelProperty(value = "数量")
    @ExcelProperty(value = "数量", index = 3)
    private BigDecimal docQty;

    @ApiModelProperty(value = "抽检数量")
    @ExcelProperty(value = "抽检数量", index = 4)
    private BigDecimal pickQty;

    @ApiModelProperty(value = "制造商料号")
    @ExcelProperty(value = "制造商料号", index = 5)
    private String mfgPartNo;

    @ApiModelProperty(value = "制造商编码")
    @ExcelProperty(value = "制造商编码", index = 6)
    private String mfgCode;

    @ApiModelProperty(value = "是否已经抛转qms状态标识（t-否，f-是）")
    @ExcelProperty(value = "抛Q", index = 7)
    private String toQmsFlag;

    @ApiModelProperty(value = "是否急件")
    @ExcelProperty(value = "是否急料", index = 8)
    private String isUrgent;

    @ApiModelProperty(value = "抛转qms时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "toQ时间", index = 9, converter = LocalDateTimeStringConverter.class)
    private LocalDateTime toQmsDate;

    @ApiModelProperty(value = "确认收货上传图片地址")
    @ExcelProperty(value = "收货异常图片", index = 10)
    private String confirmDocFileUrl;

    @ApiModelProperty(value = "sap仓码")
    @ExcelProperty(value = "仓码", index = 11)
    private String sapWarehouseCode;

    @ApiModelProperty(value = "po编码")
    @ExcelProperty(value = "PO", index = 12)
    private String poNo;
}
