package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("SWR单头导出DTO")
@Data
public class DocSwrHeaderExportDTO {

    @ApiModelProperty("BU")
    @ExcelProperty(value = "工厂组织")
    private String orgCode;

    @ApiModelProperty("工厂")
    @ExcelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty("仓码")
    @ExcelProperty(value = "仓码")
    private String warehouseCode;

    @ApiModelProperty("任务单号")
    @ExcelProperty(value = "任务单号")
    private String docNo;

    @ApiModelProperty("工单号")
    @ExcelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty("工单计划时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "工单计划时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime apsWoBeginDatetime;

    @ApiModelProperty("鸿海料号")
    @ExcelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty("厂商料号")
    @ExcelProperty(value = "厂商料号")
    private String supplierPartNo;

    @ApiModelProperty("厂商名")
    @ExcelProperty(value = "厂商")
    private String mfgName;

    @ApiModelProperty("原始DC")
    @ExcelProperty(value = "原始DC")
    private String originalDateCode;

    @ApiModelProperty("成品料号")
    @ExcelProperty(value = "成品料号")
    private String finishPartNo;

    @ApiModelProperty("客户")
    @ExcelProperty(value = "客户")
    private String customer;

    @ApiModelProperty("验证PKGID")
    @ExcelProperty(value = "验证PKGID")
    private String checkPkgId;

    @ApiModelProperty("验证数量")
    @ExcelProperty(value = "验证数量")
    private BigDecimal checkQty;

    @ApiModelProperty("分盘操作人")
    @ExcelProperty(value = "分盘操作人")
    private String splitPkgEmpNo;

    @ApiModelProperty("物控")
    @ExcelProperty(value = "物控")
    private String originator;

    @ApiModelProperty("验证接收人")
    @ExcelProperty(value = "验证接收人")
    private String checkAcceptEmpNo;

    @ApiModelProperty("验证接收时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "验证接收时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime checkAcceptDt;

    @ApiModelProperty("沾锡验证结果 NG,OK")
    @ExcelProperty(value = "沾锡验证结果")
    private String checkResult;

    @ApiModelProperty("上传沾锡报告时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "上传沾锡报告时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime checkDt;

    @ApiModelProperty("SQE确认 N,Y（是否上传沾锡报告）")
    @ExcelProperty(value = "SQE确认")
    private String sqeConfirmFlag;

    @ApiModelProperty("沾锡说明")
    @ExcelProperty(value = "沾锡说明")
    private String checkRemark;

    @ApiModelProperty("单据状态")
    @ExcelProperty(value = "单据状态")
    private String statusName;

    @ApiModelProperty("是否MSD物料 N,Y")
    @ExcelProperty(value = "是否MSD物料")
    private String msdFlag;

    @ApiModelProperty("客户邮件确认 N,Y")
    @ExcelProperty(value = "客户邮件确认")
    private String customerConfirmFlag;

    @ApiModelProperty("客人确认时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "客人确认时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime customerDt;

    @ApiModelProperty("客人是否同意 OK,NG")
    @ExcelProperty(value = "客人是否同意")
    private String customerResult;

    @ApiModelProperty(value = "客人确认备注")
    @ExcelProperty(value = "客人确认备注")
    private String customerRemark;

    @ApiModelProperty("报废单号")
    @ExcelProperty(value = "报废单号")
    private String scrapDocNo;

    @ApiModelProperty("费退单号")
    @ExcelProperty(value = "费退单号")
    private String returnDocNo;
}
