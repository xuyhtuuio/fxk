package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateStringConverter;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @author MFQ
 * @date 2023/11/17 上午 10:36
 */
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("CKD备案清单报表导出DTO")
@Data
public class CkdFilingExportDTO {
    @ApiModelProperty(value = "企業料號")
    @ExcelProperty(value = "企業料號", index = 0)
    private String hhPn;

    @ApiModelProperty(value = "申報要素")
    @ExcelProperty(value = "申報要素", index = 1)
    private String itemDesc;

    @ApiModelProperty(value = "備案序號")
    @ExcelProperty(value = "備案序號", index = 2)
    private String cusNo;

    @ApiModelProperty(value = "商品編碼")
    @ExcelProperty(value = "商品編碼", index = 3)
    private String goodNo;

    @ApiModelProperty(value = "商品品名")
    @ExcelProperty(value = "商品品名", index = 4)
    private String goodName;

    @ApiModelProperty(value = "申報單位")
    @ExcelProperty(value = "申報單位", index = 5)
    private String cusUne;

    @ApiModelProperty(value = "計量單位")
    @ExcelProperty(value = "計量單位", index = 6)
    private String une;

    @ApiModelProperty(value = "比例因子")
    @ExcelProperty(value = "比例因子", index = 7)
    private BigDecimal rate;

    @ApiModelProperty(value = "單位淨重（申報單位）")
    @ExcelProperty(value = "單位淨重（申報單位）", index = 8)
    private BigDecimal weightUne;

    @ApiModelProperty(value = "單位净重*比例因子")
    @ExcelProperty(value = "單位净重*比例因子", index = 9)
    private BigDecimal weightCus;

    @ApiModelProperty(value = "部門")
    @ExcelProperty(value = "部門", index = 10)
    private String partment;

    @ApiModelProperty(value = "OP")
    @ExcelProperty(value = "OP", index = 11)
    private String op;

    @ApiModelProperty(value = "OP時間")
    @ExcelProperty(value = "OP時間", index = 12, converter = LocalDateStringConverter.class)
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate opTime;

}
