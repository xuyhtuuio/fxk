package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("LRR入库明细导入异常信息DTO")
@Data
public class LrrReceiveExportErrDTO {
    @ApiModelProperty("来源单号")
    @ExcelProperty(value = "来源单号")
    private String fromDocNo;

    @ApiModelProperty("工厂")
    @ExcelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty("退货类型")
    @ExcelProperty(value = "退货类型")
    private String returnType;

    @ApiModelProperty("预计收货SN")
    @ExcelProperty(value = "预计收货SN")
    private String planSn;

    @ApiModelProperty("仓码")
    @ExcelProperty(value = "仓码")
    private String warehouseCode;

    @ApiModelProperty("不良现象")
    @ExcelProperty(value = "不良现象")
    private String badReason;

    @ApiModelProperty("是否FA")
    @ExcelProperty(value = "是否FA（Y/N）")
    private String isFa;

    @ApiModelProperty(value = "异常原因")
    @ExcelProperty(value = "异常原因")
    private String errMsg;
}
