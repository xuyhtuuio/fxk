package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;

/**
 * @ClassName PackShortageExportDTO
 * @Description TODO
 * @Author Likun
 * @Date 2024/12/17
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("包材缺料明细导出dto")
@Data
public class PackShortageExportDTO {

    @ApiModelProperty(value = "工单号")
    @ExcelProperty(value = "工单号",index = 0)
    private String workOrderNo;

    @ApiModelProperty(value = "成品料号")
    @ExcelProperty(value = "成品料号",index = 1)
    private String finishNo;

    @ApiModelProperty(value = "料号")
    @ExcelProperty(value = "包材料号",index = 2)
    private String partNo;

    @ApiModelProperty(value = "料号版次")
    @ExcelProperty(value = "版次",index = 3)
    private String partVersion;

    @ApiModelProperty(value = "仓码")
    @ExcelProperty(value = "仓码",index = 4)
    private String sapWarehouseCode;

    @ApiModelProperty(value = "需求量")
    @ExcelProperty(value = "需求量",index = 5)
    private BigDecimal requiredQuantity;

    @ApiModelProperty(value = "发料量")
    @ExcelProperty(value = "已发数量",index = 6)
    private BigDecimal issuedQty;

    @ApiModelProperty(value = "欠发量")
    @ExcelProperty(value = "欠发量",index = 7)
    private BigDecimal unIssuedQty;

    @ApiModelProperty(value = "单位")
    @ExcelProperty(value = "单位",index = 8)
    private String uomCode;
}
