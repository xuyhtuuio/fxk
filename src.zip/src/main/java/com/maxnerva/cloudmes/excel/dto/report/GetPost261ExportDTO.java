package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("工单发料261过账DTO")
@Data
public class GetPost261ExportDTO {
    @ApiModelProperty(value = "工廠")
    @ExcelProperty(value = "工厂")
    String plantCode;

    @ApiModelProperty(value = "線別")
    @ExcelProperty(value = "線別")
    String lineNo;

    @ApiModelProperty(value = "工單狀態")
    @ExcelProperty(value = "工單狀態")
    String workOrderStatus;

    @ApiModelProperty(value = "工單號")
    @ExcelProperty(value = "工單號")
    String workOrderNo;

    @ApiModelProperty(value = "APS计划时间")
    @ExcelProperty(value = "APS计划时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime apsWoBeginDatetime;

    @ApiModelProperty(value = "料號")
    @ExcelProperty(value = "料號")
    String partNo;

    @ApiModelProperty(value = "倉碼")
    @ExcelProperty(value = "倉碼")
    String fromWarehouseCode;

    @ApiModelProperty(value = "發料數")
    @ExcelProperty(value = "發料數")
    BigDecimal stockQty;

    @ApiModelProperty(value = "261數")
    @ExcelProperty(value = "261數")
    BigDecimal postTo261Qty;

    @ApiModelProperty(value = "過帳信息")
    @ExcelProperty(value = "過帳信息")
    String postTo261ReturnMsg;
}
