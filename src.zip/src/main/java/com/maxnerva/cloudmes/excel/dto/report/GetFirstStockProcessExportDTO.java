package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.maxnerva.cloudmes.config.LocalDateStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDate;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("首套料进度DTO")
@Data
public class GetFirstStockProcessExportDTO {
    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    String plantCode;

    @ApiModelProperty(value = "工单")
    @ExcelProperty(value = "工单")
    String workOrderNo;

    @ApiModelProperty(value = "成品料号")
    @ExcelProperty(value = "成品料号")
    String partNo;

    @ApiModelProperty(value = "线别")
    @ExcelProperty(value = "线别")
    String lineNo;

    @ApiModelProperty(value = "计划日期")
    @ExcelProperty(value = "计划日期", converter = LocalDateStringConverter.class)
    LocalDate apsWoScheduleDatetime;

    @ApiModelProperty(value = "工单数量")
    @ExcelProperty(value = "工单数量")
    BigDecimal workOrderQty;

    @ApiModelProperty(value = "入库数量")
    @ExcelProperty(value = "入库数量")
    BigDecimal inboundQty;

    @ApiModelProperty(value = "已备料群组数")
    @ExcelProperty(value = "已备料群组数")
    Integer stockNum;

    @ApiModelProperty(value = "总群组数")
    @ExcelProperty(value = "总群组数")
    Integer stockTotal;
}
