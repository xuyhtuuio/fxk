package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("准时达库存DTO")
@Data
public class GetJusdaInventoryExportDTO {
    @ApiModelProperty(value = "库存版本")
    @ExcelProperty(value = "库存版本")
    String stockVersion;

    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    String sapPlantCode;

    @ApiModelProperty(value = "供应商名称")
    @ExcelProperty(value = "供应商名称")
    String customerNo;

    @ApiModelProperty(value = "V/C")
    @ExcelProperty(value = "V/C")
    String deliveryType;

    @ApiModelProperty(value = "制造商")
    @ExcelProperty(value = "制造商")
    String manufactureName;

    @ApiModelProperty(value = "料号")
    @ExcelProperty(value = "料号")
    String customerPartNo;

    @ApiModelProperty(value = "库存总量")
    @ExcelProperty(value = "库存总量")
    BigDecimal qty;

    @ApiModelProperty(value = "可用数量")
    @ExcelProperty(value = "可用数量")
    BigDecimal hubInvQty;

    @ApiModelProperty(value = "GoodQty")
    @ExcelProperty(value = "GoodQty")
    BigDecimal goodQty;

    @ApiModelProperty(value = "UnknownQty")
    @ExcelProperty(value = "UnknownQty")
    BigDecimal unknownQty;

    @ApiModelProperty(value = "DefectQty")
    @ExcelProperty(value = "DefectQty")
    BigDecimal defectQty;

    @ApiModelProperty(value = "OnWayQty")
    @ExcelProperty(value = "OnWayQty")
    BigDecimal onWayQty;

    @ApiModelProperty(value = "HoldQty")
    @ExcelProperty(value = "HoldQty")
    BigDecimal holdQty;

    @ApiModelProperty(value = "单位")
    @ExcelProperty(value = "单位")
    String uom;

    @ApiModelProperty(value = "供应商代码")
    @ExcelProperty(value = "供应商代码")
    String customerSupplierNo;

    @ApiModelProperty(value = "仓库")
    @ExcelProperty(value = "仓库")
    String warehouseName;

    @ApiModelProperty(value = "制造商料号")
    @ExcelProperty(value = "制造商料号")
    private String supplierPartNo;
}
