package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateStringConverter;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("LRR入库明细导出DTO")
@Data
public class LrrReceiveSnListExportDTO {
    @ApiModelProperty("工厂组织")
    @ExcelProperty(value = "工厂组织")
    private String orgCode;

    @ApiModelProperty("工厂")
    @ExcelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty("WMS单号")
    @ExcelProperty(value = "WMS单号")
    private String wmsNo;

    @ApiModelProperty("来源单号")
    @ExcelProperty(value = "来源单号")
    private String fromDocNo;

    @ApiModelProperty("退货类型")
    @ExcelProperty(value = "退货类型")
    private String returnType;

    @ApiModelProperty("预计收货SN")
    @ExcelProperty(value = "预计收货SN")
    private String planSn;

    @ApiModelProperty("仓码")
    @ExcelProperty(value = "仓码")
    private String warehouseCode;

    @ApiModelProperty("不良原因")
    @ExcelProperty(value = "不良原因")
    private String badReason;

    @ApiModelProperty("实际扫描SN")
    @ExcelProperty(value = "实际扫描SN")
    private String actualSn;

    @ApiModelProperty(value = "SN采集人")
    @ExcelProperty(value = "SN采集人")
    private String snOperator;

    @ApiModelProperty("SN采集时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "SN采集时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime snScanDt;

    @ApiModelProperty("料号")
    @ExcelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty("制造商料号")
    @ExcelProperty(value = "制造商料号")
    private String mfgPartNo;

    @ApiModelProperty("数量")
    @ExcelProperty(value = "数量")
    private BigDecimal qty;

    @ApiModelProperty("单位")
    @ExcelProperty(value = "单位")
    private String uomCode;

    @ApiModelProperty("机种")
    @ExcelProperty(value = "机种")
    private String sfcModelName;

    @ApiModelProperty("版次")
    @ExcelProperty(value = "版次")
    private String sfcRev;

    @ApiModelProperty("系列")
    @ExcelProperty(value = "系列")
    private String sfcModelSerial;

    @ApiModelProperty("箱号")
    @ExcelProperty(value = "箱号")
    private String pkgId;

    @ApiModelProperty("开箱标识")
    @ExcelProperty(value = "开箱标识")
    private String pkgStatusName;

    @ApiModelProperty("关箱时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "关箱时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime pkgCloseDt;

    @ApiModelProperty("费退单号")
    @ExcelProperty(value = "费退单号")
    private String costDocNo;


    @ApiModelProperty("状态")
    @ExcelProperty(value = "状态")
    private String statusName;

    @ApiModelProperty("SN次数")
    @ExcelProperty(value = "SN次数")
    private Integer snTimes;

    @ApiModelProperty("最早出货时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "最早出货时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime firstShipDt;

//    @ApiModelProperty("出货DN")
//    @ExcelProperty(value = "出货DN")
//    private String shipDnNo;

    @ApiModelProperty("质保期")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @ExcelProperty(value = "质保期", converter = LocalDateStringConverter.class)
    private LocalDate endDate;

    @ApiModelProperty("是否FA")
    @ExcelProperty(value = "是否FA")
    private String isFaName;

    @ApiModelProperty(value = "创建人")
    @ExcelProperty(value = "创建人")
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "创建时间", converter = LocalDateTimeStringConverter.class)
    @ApiModelProperty(value = "创建时间")
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "修改人")
    @ExcelProperty(value = "修改人")
    private String lastEditor;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "修改时间")
    @ExcelProperty(value = "修改时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime lastEditedDt;
}
