package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("工单成品损耗DTO")
@Data
public class GetWorkOrderCostLossExportDTO {
    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "工单")
    @ExcelProperty(value = "工单")
    private String workOrderNo;

    @ApiModelProperty(value = "成品料号")
    @ExcelProperty(value = "成品料号")
    private String partNo;

    @ApiModelProperty(value = "工单BOM标准用量成本")
    @ExcelProperty(value = "工单BOM标准用量成本")
    private BigDecimal sapRequiredTotalPrice;

    @ApiModelProperty(value = "工单发料实际成本")
    @ExcelProperty(value = "工单发料实际成本")
    private BigDecimal stockTotalPrice;

    @ApiModelProperty(value = "差异-Variance的加总")
    @ExcelProperty(value = "差异-Variance的加总")
    private BigDecimal consumptionTotalPrice;

    @ApiModelProperty(value = "耗损率")
    @ExcelProperty(value = "耗损率")
    private String percentage;

    @ApiModelProperty(value = "LRR重工")
    @ExcelProperty(value = "LRR重工")
    private BigDecimal lrrConsumptionTotalPrice;

    @ApiModelProperty(value = "NPI")
    @ExcelProperty(value = "NPI")
    private BigDecimal npiConsumptionTotalPrice;

    @ApiModelProperty(value = "量产")
    @ExcelProperty(value = "量产")
    private BigDecimal massConsumptionTotalPrice;

    @ApiModelProperty(value = "量产重工")
    @ExcelProperty(value = "量产重工")
    private BigDecimal massReConsumptionTotalPrice;

    @ApiModelProperty(value = "类别")
    @ExcelProperty(value = "类别")
    private String workOrderConsumeDiffTypeName;

    @ApiModelProperty(value = "工单类型")
    @ExcelProperty(value = "工单类型")
    private String workOrderConsumeTypeName;
}
