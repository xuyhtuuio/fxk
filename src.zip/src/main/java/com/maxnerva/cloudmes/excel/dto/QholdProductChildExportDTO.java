package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @Author hgx
 * @Description 成品hold查询子分布DTO
 * @Date 2023/9/26
 */
@ApiModel("成品hold查询子分布DTO")
@Data
public class QholdProductChildExportDTO {

    @ApiModelProperty("箱号")
    @ExcelProperty(value = "箱号", index = 0)
    private String cartonNo;

    @ApiModelProperty("数量")
    @ExcelProperty(value = "数量", index = 1)
    private BigDecimal currentQty;
}
