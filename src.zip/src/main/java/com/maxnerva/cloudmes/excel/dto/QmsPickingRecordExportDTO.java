package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;

/**
 * @ClassName QmsPickingRecordExportDTO
 * @Description qms拣料记录导出dto
 * @Author Likun
 * @Date 2024/7/26
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("qms捡料记录导出DTO")
@Data
public class QmsPickingRecordExportDTO {

    @ApiModelProperty(value = "BU(业务单元)")
    @ExcelProperty(value = "BU", index = 0)
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂", index = 1)
    private String plantCode;

    @ApiModelProperty(value = "收货单号")
    @ExcelProperty(value = "WMS单号", index = 2)
    private String docReceiveNo;

    @ApiModelProperty(value = "pkgId")
    @ExcelProperty(value = "PKG", index = 3)
    private String pkgId;

    @ApiModelProperty(value = "数量")
    @ExcelProperty(value = "数量", index = 4)
    private BigDecimal qty;

    @ApiModelProperty(value = "是否归还")
    @ExcelProperty(value = "是否归还", index = 5)
    private String isReturnName;

    @ApiModelProperty(value = "来源储位")
    @ExcelProperty(value = "来源储位", index = 6)
    private String fromBinCode;

    @ApiModelProperty(value = "来源载具")
    @ExcelProperty(value = "来源载具", index = 7)
    private String fromVehicleCode;

    @ApiModelProperty(value = "来源库位")
    @ExcelProperty(value = "来源库位", index = 8)
    private String fromLocationCode;

    @ApiModelProperty(value = "拣料人")
    @ExcelProperty(value = "拣料人", index = 9)
    private String picker;

    @ApiModelProperty(value = "拣料时间")
    @ExcelProperty(value = "拣料时间", index = 10)
    private String pickingTime;

    @ApiModelProperty(value = "当前载具")
    @ExcelProperty(value = "当前载具", index = 11)
    private String vehicleCode;

    @ApiModelProperty(value = "当前储位")
    @ExcelProperty(value = "当前储位", index = 12)
    private String binCode;

    @ApiModelProperty(value = "归还人")
    @ExcelProperty(value = "归还人", index = 13)
    private String returnee;

    @ApiModelProperty(value = "归还时间")
    @ExcelProperty(value = "归还时间", index = 14)
    private String returnTime;
}
