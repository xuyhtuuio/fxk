package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @ClassName DocReceiveCheckExportDTO
 * @Description TODO
 * @Author Likun
 * @Date 2024/8/2
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("收货单明细导出DTO")
@Data
public class DocReceiveCheckExportDTO {

    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "WMS单号")
    @ExcelProperty(value = "WMS单号")
    private String docNo;

    @ApiModelProperty(value = "PO/ASN")
    @ExcelProperty(value = "PO/ASN")
    private String checkDocNo;

    @ApiModelProperty(value = "单据类型名称")
    @ExcelProperty(value = "单据类型")
    private String docTypeName;

    @ApiModelProperty(value = "Vendor")
    @ExcelProperty(value = "Vendor")
    private String vendorCode;

    @ApiModelProperty(value = "鸿海料号")
    @ExcelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "版次")
    @ExcelProperty(value = "版次")
    private String partNoVersion;

    @ApiModelProperty(value = "数量")
    @ExcelProperty(value = "数量")
    private BigDecimal docQty;

    @ApiModelProperty(value = "制造商料号")
    @ExcelProperty(value = "制造商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "制造商编码")
    @ExcelProperty(value = "制造商编码")
    private String mfgCode;

    @ApiModelProperty(value = "是否已经抛转qms状态标识（t-否，f-是）")
    @ExcelProperty(value = "抛Q")
    private String toQmsFlag;

    @ApiModelProperty(value = "抛Q信息")
    @ExcelProperty(value = "抛Q信息")
    private String toQmsMessage;

    @ApiModelProperty(value = "抛转qms时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "toQ时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime toQmsDate;

    @ApiModelProperty(value = "qms返回标识")
    @ExcelProperty(value = "Q返回")
    private String qmsReturnFlag;

    @ApiModelProperty(value = "sap返回结果")
    @ExcelProperty(value = "Q结果")
    private String qmsReturnMessage;

    @ApiModelProperty(value = "sap返回信息")
    @ExcelProperty(value = "Q返回信息")
    private String qmsReturnMsg;

    @ApiModelProperty(value = "qms回写日期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "Q返回时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime qmsReturnDate;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "创建时间")
    @ExcelProperty(value = "导入时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "sap仓码")
    @ExcelProperty(value = "仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "GR单号")
    @ExcelProperty(value = "GR单号")
    private String sapReturnNumber;

    @ApiModelProperty(value = "调用sap日期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "SAP过账日期", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime postingSapMethodDate;

    @ApiModelProperty(value = "sap返回信息")
    @ExcelProperty(value = "sap返回信息")
    private String sapReturnMessage;

    @ApiModelProperty(value = "转良品单号")
    @ExcelProperty(value = "转良品单号")
    private String sapConfirmNumber;

    @ApiModelProperty(value = "转良品信息")
    @ExcelProperty(value = "转良品信息")
    private String sapConfirmMessage;

    @ApiModelProperty(value = "转良品时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "转良品时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime sapConfirmDatetime;

    @ApiModelProperty(value = "不良品单号")
    @ExcelProperty(value = "不良品单号")
    private String sapTransferRejectsNumber;

    @ApiModelProperty(value = "不良品信息")
    @ExcelProperty(value = "不良品信息")
    private String sapTransferRejectsMessage;

    @ApiModelProperty(value = "转不良品时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "不良品时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime sapTransferRejectsDatetime;

    @ApiModelProperty(value = "po编码")
    @ExcelProperty(value = "PO")
    private String poNo;

    @ApiModelProperty(value = "po项次")
    @ExcelProperty(value = "PO项次")
    private String poItem;

    @ApiModelProperty(value = "来源单号")
    @ExcelProperty(value = "来源单号")
    private String fromDocNo;

    @ApiModelProperty(value = "来源单项次")
    @ExcelProperty(value = "来源项次")
    private String fromDocItem;

    @ApiModelProperty(value = "INVOICE NO")
    @ExcelProperty(value = "INVOICE NO")
    private String invoiceNo;

    @ApiModelProperty(value = "是否异常收货")
    @ExcelProperty(value = "是否异常收货")
    private String inspectResult;

    @ApiModelProperty(value = "收货备注")
    @ExcelProperty(value = "收货备注")
    private String confirmDocMessage;

    @ApiModelProperty(value = "确认收货日期")
    @ExcelProperty(value = "收货日期", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime confirmDocDate;

    @ApiModelProperty("协作云放行单号")
    @ExcelProperty(value = "协作云放行单号")
    private String scReleaseNo;

    @ApiModelProperty("协作云放行原因")
    @ExcelProperty(value = "协作云放行原因")
    private String scReleaseReason;

    @ApiModelProperty("放行单填写未抛QMS原因")
    @ExcelProperty(value = "放行单填写未抛QMS原因")
    private String scImpoundReason;

    @ApiModelProperty(value = "首次调用协作云时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "首次调用协作云时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime toQmsFirstDate;
}
