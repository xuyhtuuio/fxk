package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("531入库失败明细DTO")
@Data
public class Get531FailExportDTO {
    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    String plantCode;

    @ApiModelProperty(value = "APS计划时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "APS计划时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime apsWoBeginDatetime;

    @ApiModelProperty(value = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "创建时间", converter = LocalDateTimeStringConverter.class)
    LocalDateTime createdDt;

    @ApiModelProperty(value = "工单")
    @ExcelProperty(value = "工单")
    String workOrderNo;

    @ApiModelProperty(value = "群组")
    @ExcelProperty(value = "群组")
    String workOrderItem;

    @ApiModelProperty(value = "料号")
    @ExcelProperty(value = "料号")
    String partNo;

    @ApiModelProperty(value = "仓码")
    @ExcelProperty(value = "仓码")
    String sapWarehouseCode;

    @ApiModelProperty(value = "SAP需求量")
    @ExcelProperty(value = "SAP需求量")
    BigDecimal requiredQuantitySap;

    @ApiModelProperty(value = "上架数量")
    @ExcelProperty(value = "上架数量")
    BigDecimal shelfQty;

    @ApiModelProperty(value = "531过账数量")
    @ExcelProperty(value = "531过账数量")
    BigDecimal postTo531Qty;

    @ApiModelProperty(value = "过账信息")
    @ExcelProperty(value = "过账信息")
    String postTo531ReturnMsg;
}
