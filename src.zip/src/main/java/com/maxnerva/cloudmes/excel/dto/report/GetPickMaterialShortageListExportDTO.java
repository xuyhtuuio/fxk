package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("工单捡料缺料by bomfeeder")
@Data
public class GetPickMaterialShortageListExportDTO {
    @ApiModelProperty(value = "工单")
    @ExcelProperty(value = "工单")
    private String workOrderNo;

    @ApiModelProperty(value = "机种")
    @ExcelProperty(value = "机种")
    private String productPartNo;

    @ApiModelProperty(value = "制程")
    @ExcelProperty(value = "制程")
    private String productProcess;

    @ApiModelProperty(value = "群组")
    @ExcelProperty(value = "群组")
    private String workOrderItem;

    @ApiModelProperty(value = "M/S")
    @ExcelProperty(value = "M/S")
    private String partNoType;

    @ApiModelProperty(value = "料号")
    @ExcelProperty(value = "料号")
    private String sparePartNo;

    @ApiModelProperty(value = "需求量")
    @ExcelProperty(value = "需求量")
    private BigDecimal requestQty;

    @ApiModelProperty(value = "已分量")
    @ExcelProperty(value = "已分量")
    private BigDecimal allocateQty;

    @ApiModelProperty(value = "欠分量")
    @ExcelProperty(value = "欠分量")
    private BigDecimal shortageQty;

    @ApiModelProperty(value = "待分量")
    @ExcelProperty(value = "待分量")
    private BigDecimal notAllocateQty;

    @ApiModelProperty(value = "WMS良品库存")
    @ExcelProperty(value = "WMS良品库存")
    private BigDecimal pkgTotalQty;

    @ApiModelProperty(value = "WMS锁定库存")
    @ExcelProperty(value = "WMS锁定库存")
    private BigDecimal lockPkgQty;

    @ApiModelProperty(value = "机台编号")
    @ExcelProperty(value = "机台编号")
    private String machineCode;

    @ApiModelProperty(value = "轨道号")
    @ExcelProperty(value = "轨道号")
    private String feederNo;

    @ApiModelProperty(value = "AB面")
    @ExcelProperty(value = "AB面")
    private String lineCategory;

    @ApiModelProperty(value = "位置")
    @ExcelProperty(value = "位置")
    private String machineDirection;

    @ApiModelProperty(value = "上料表创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "上料表创建时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "采购组")
    @ExcelProperty(value = "采购组")
    private String buyerCode;

    @ApiModelProperty(value = "Buyer")
    @ExcelProperty(value = "Buyer")
    private String purchaserName;

    @ApiModelProperty(value = "物料管理方式")
    @ExcelProperty(value = "物料管理方式")
    private String scanMode;

}
