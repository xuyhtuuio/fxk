package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;

/**
 * @ClassName ProductShortageDetailExportDTO
 * @Description 生产缺料明细导出DTO
 * @Author Likun
 * @Date 2023/8/1
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("生产缺料明细导出DTO")
@Data
public class ProductShortageDetailExportDTO {

    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂", index = 0)
    private String plantCode;

    @ApiModelProperty(value = "工单号")
    @ExcelProperty(value = "工单号", index = 1)
    private String workOrderNo;

    @ApiModelProperty(value = "成品料号")
    @ExcelProperty(value = "机种", index = 2)
    private String productPartNo;

    @ApiModelProperty(value = "SMT、PTH、ASSY")
    @ExcelProperty(value = "制程", index = 3)
    private String materialProductProcess;

    @ApiModelProperty(value = "工单群组")
    @ExcelProperty(value = "群组", index = 4)
    private String workOrderItem;

    @ApiModelProperty(value = "M:主料，S替代料")
    @ExcelProperty(value = "M/S", index = 5)
    private String partNoType;

    @ApiModelProperty(value = "替代号")
    @ExcelProperty(value = "料号", index = 6)
    private String sparePartNo;

    @ApiModelProperty(value = "需求数量")
    @ExcelProperty(value = "需求量", index = 7)
    private BigDecimal requestQty;

    @ApiModelProperty(value = "已分料量")
    @ExcelProperty(value = "已分量", index = 8)
    private BigDecimal distributedQty;

    @ApiModelProperty(value = "欠分料量")
    @ExcelProperty(value = "欠分量", index = 9)
    private BigDecimal underDistributeQty;

    @ApiModelProperty(value = "待分料量")
    @ExcelProperty(value = "待分量", index = 10)
    private BigDecimal toBeDistributeQty;

    @ApiModelProperty(value = "机台编号")
    @ExcelProperty(value = "机台编号", index = 11)
    private String machineCode;

    @ApiModelProperty(value = "feeder号,轨道号")
    @ExcelProperty(value = "轨道号", index = 12)
    private String feederNo;

    @ApiModelProperty(value = "工单绑定位置")
    @ExcelProperty(value = "工单位置信息", index = 13)
    private String workOrderToLocation;

}
