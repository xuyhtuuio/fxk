package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ApiModel("工单整体备料进度DTO")
@ContentStyle(horizontalAlignment = HorizontalAlignment.CENTER, verticalAlignment = VerticalAlignment.CENTER)
@Data
public class GeneralWoStockProgressExportDTO {

    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "客户")
    @ExcelProperty(value = "客户")
    private String mrpArea;

    @ApiModelProperty(value = "成品料号")
    @ExcelProperty(value = "成品料号")
    private String partNo;

    @ApiModelProperty(value = "工单号")
    @ExcelProperty(value = "工单")
    private String workOrderNo;

    @ApiModelProperty(value = "线别")
    @ExcelProperty(value = "线别")
    private String lineNo;

    @ApiModelProperty(value = "APS上线时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "APS上线时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime apsWoBeginDatetime;

    @ApiModelProperty(value = "工单数量")
    @ExcelProperty(value = "工单数量")
    private BigDecimal workOrderQty;

    @ApiModelProperty(value = "检料缺料SMT（总群组数）")
    @ExcelProperty(value = {"检料缺料SMT", "总群组"})
    private Integer pickSmtTotalNum;

    @ApiModelProperty(value = "检料缺料SMT（备料群组数）")
    @ExcelProperty(value = {"检料缺料SMT", "备料群组"})
    private Integer pickSmtNum;

    @ApiModelProperty(value = "检料缺料SMT（达成率）")
    @ExcelProperty(value = {"检料缺料SMT", "达成率"})
    private String pickSmtProgress;

    @ApiModelProperty(value = "检料缺料PTH（总群组数）")
    @ExcelProperty(value = {"检料缺料PTH", "总群组"})
    private Integer pickPthTotalNum;

    @ApiModelProperty(value = "检料缺料PTH（备料群组数）")
    @ExcelProperty(value = {"检料缺料PTH", "备料群组"})
    private Integer pickPthNum;

    @ApiModelProperty(value = "检料缺料PTH（达成率）")
    @ExcelProperty(value = {"检料缺料PTH", "达成率"})
    private String pickPthProgress;

    @ApiModelProperty(value = "上线缺料SMT（总群组数）")
    @ExcelProperty(value = {"上线缺料SMT", "总群组"})
    private Integer onLineSmtTotalNum;

    @ApiModelProperty(value = "上线缺料SMT（备料群组数）")
    @ExcelProperty(value = {"上线缺料SMT", "备料群组"})
    private Integer onLineSmtNum;

    @ApiModelProperty(value = "上线缺料SMT（达成率）")
    @ExcelProperty(value = {"上线缺料SMT", "达成率"})
    private String onLineSmtProgress;

    @ApiModelProperty(value = "上线缺料PTH（总群组数）")
    @ExcelProperty(value = {"上线缺料PTH", "总群组"})
    private Integer onLinePthTotalNum;

    @ApiModelProperty(value = "上线缺料PTH（备料群组数）")
    @ExcelProperty(value = {"上线缺料PTH", "备料群组"})
    private Integer onLinePthNum;

    @ApiModelProperty(value = "上线缺料PTH（达成率）")
    @ExcelProperty(value = {"上线缺料PTH", "达成率"})
    private String onLinePthProgress;

    @ApiModelProperty(value = "上料车轨道缺料SMT（总群组数）")
    @ExcelProperty(value = {"上料车轨道缺料SMT", "总群组"})
    private Integer onVehicleSmtTotalNum;

    @ApiModelProperty(value = "上料车轨道缺料SMT（备料群组数）")
    @ExcelProperty(value = {"上料车轨道缺料SMT", "备料群组"})
    private Integer onVehicleSmtNum;

    @ApiModelProperty(value = "上料车轨道缺料SMT（达成率）")
    @ExcelProperty(value = {"上料车轨道缺料SMT", "达成率"})
    private String onVehicleSmtProgress;

    @ApiModelProperty(value = "上料车轨道缺料PTH（总群组数）")
    @ExcelProperty(value = {"上料车轨道缺料PTH", "总群组"})
    private Integer onVehiclePthTotalNum;

    @ApiModelProperty(value = "上料车轨道缺料PTH（备料群组数）")
    @ExcelProperty(value = {"上料车轨道缺料PTH", "备料群组"})
    private Integer onVehiclePthNum;

    @ApiModelProperty(value = "上料车轨道缺料PTH（达成率）")
    @ExcelProperty(value = {"上料车轨道缺料PTH", "达成率"})
    private String onVehiclePthProgress;

    @ApiModelProperty("前加工（物料拆分）")
    @ExcelProperty(value = {"前加工", "物料拆分"})
    private Integer taskDividePkg;

    @ApiModelProperty("前加工（SMT-BURN）")
    @ExcelProperty(value = {"前加工", "烧录"})
    private Integer taskSmtBurn;

    @ApiModelProperty("前加工（SMT-MARG）")
    @ExcelProperty(value = {"前加工", "合盘"})
    private Integer taskSmtMarg;

    @ApiModelProperty("前加工（剪角）")
    @ExcelProperty(value = {"前加工", "剪脚"})
    private Integer taskCutCorner;

    @ApiModelProperty("前加工（分轨）")
    @ExcelProperty(value = {"前加工", "分轨"})
    private Integer taskDividePartNo;

    @ApiModelProperty("上料車 非ASSY")
    @ExcelProperty(value = {"上料车", "SMT上料车"})
    private Integer pickOnlineNoAssy;

    @ApiModelProperty("上料車 ASSY")
    @ExcelProperty(value = {"上料车", "PTH上料车"})
    private Integer pickOnlineAssy;

}
