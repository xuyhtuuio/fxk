package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("费领退单据明细导出DTO")
@Data
public class CostIssueDetailExportDTO {
    @ApiModelProperty(value = "工厂组织")
    @ExcelProperty(value = "工厂组织")
    private String orgCode;

    @ApiModelProperty(value = "单号")
    @ExcelProperty(value = "单号")
    private String docNo;

    @ApiModelProperty(value = "是否保税")
    @ExcelProperty(value = "是否保税")
    private String bondedTypeName;

    @ApiModelProperty(value = "仓码")
    @ExcelProperty(value = "仓码")
    private String warehouseCode;

    @ApiModelProperty(value = "鸿海料号")
    @ExcelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "过账信息")
    @ExcelProperty(value = "过账信息")
    private String postSapReturnMsg;

    @ApiModelProperty(value = "过账单号")
    @ExcelProperty(value = "过账单号")
    private String postSapReturnNumber;

    @ApiModelProperty(value = "过账人")
    @ExcelProperty(value = "过账人")
    private String confirmBy;

    @ApiModelProperty(value = "单位")
    @ExcelProperty(value = "单位")
    private String uomCode;

    @ApiModelProperty(value = "数量")
    @ExcelProperty(value = "数量")
    private BigDecimal qty;

    @ApiModelProperty(value = "完成数量")
    @ExcelProperty(value = "完成数量")
    private BigDecimal completedQty;

    @ApiModelProperty(value = "确认过账数量")
    @ExcelProperty(value = "确认过账数量")
    private BigDecimal confirmPostingQty;

    @ApiModelProperty(value = "单价")
    @ExcelProperty(value = "单价")
    private BigDecimal price;

    @ApiModelProperty(value = "总价")
    @ExcelProperty(value = "总价")
    private BigDecimal totalPrice;
}
