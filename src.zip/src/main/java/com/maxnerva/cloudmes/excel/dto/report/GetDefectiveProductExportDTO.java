package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.maxnerva.cloudmes.config.LocalDateStringConverter;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("不良品库存DTO")
@Data
public class GetDefectiveProductExportDTO {
    @ApiModelProperty(value = "库存条码")
    @ExcelProperty(value = "库存条码")
    String pkgId;

    @ApiModelProperty(value = "料号")
    @ExcelProperty(value = "料号")
    String partNo;

    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    String plantCode;

    @ApiModelProperty(value = "仓码")
    @ExcelProperty(value = "仓码")
    String sapWarehouseCode;

    @ApiModelProperty(value = "数量")
    @ExcelProperty(value = "数量")
    BigDecimal currentQty;

    @ApiModelProperty(value = "制造商料号")
    @ExcelProperty(value = "制造商料号")
    String mfgPartNo;

    @ApiModelProperty(value = "SAP制造商料号")
    @ExcelProperty(value = "SAP制造商料号")
    String supplierPartNo;

    @ApiModelProperty(value = "制造商")
    @ExcelProperty(value = "制造商")
    String mfgName;

    @ApiModelProperty(value = "实物料号")
    @ExcelProperty(value = "实物料号")
    String scrapMaterialNo;

    @ApiModelProperty(value = "原始D/C")
    @ExcelProperty(value = "原始D/C")
    String originalDateCode;

    @ApiModelProperty(value = "解析D/C")
    @ExcelProperty(value = "解析D/C", converter = LocalDateStringConverter.class)
    LocalDate dateCode;

    @ApiModelProperty(value = "Lot")
    @ExcelProperty(value = "Lot")
    String lotCode;

    @ApiModelProperty(value = "endDate")
    @ExcelProperty(value = "endDate", converter = LocalDateStringConverter.class)
    LocalDate endDate;

    @ApiModelProperty(value = "退料类型")
    @ExcelProperty(value = "退料类型")
    String dictName;

    @ApiModelProperty(value = "不良分类")
    @ExcelProperty(value = "不良分类")
    String dictName2;

    @ApiModelProperty(value = "不良原因")
    @ExcelProperty(value = "不良原因")
    String badReason;

    @ApiModelProperty(value = "物料分类")
    @ExcelProperty(value = "物料分类")
    String classDesc;

    @ApiModelProperty(value = "料件SN")
    @ExcelProperty(value = "料件SN")
    String snId;

    @ApiModelProperty(value = "SFC条码")
    @ExcelProperty(value = "SFC条码")
    String sfcPkgId;

    @ApiModelProperty(value = "PCB厂商")
    @ExcelProperty(value = "PCB厂商")
    String manufacturer;

    @ApiModelProperty(value = "PCB_DC")
    @ExcelProperty(value = "PCB_DC")
    String pcbDateCode;

    @ApiModelProperty(value = "PCB料号")
    @ExcelProperty(value = "PCB料号")
    String materialHhpn;

    @ApiModelProperty(value = "Buysell")
    @ExcelProperty(value = "Buysell")
    private String buySellType;


    @ApiModelProperty(value = "库区")
    @ExcelProperty(value = "库区")
    String areaCode;

    @ApiModelProperty(value = "库位")
    @ExcelProperty(value = "库位")
    String locationCode;

    @ApiModelProperty(value = "载具")
    @ExcelProperty(value = "载具")
    String vehicleCode;

    @ApiModelProperty(value = "储位")
    @ExcelProperty(value = "储位")
    String binCode;

    @ApiModelProperty(value = "不良单号")
    @ExcelProperty(value = "不良单号")
    String docNo;

    @ApiModelProperty(value = "在库天数")
    @ExcelProperty(value = "在库天数")
    Integer dayCount;

    @ApiModelProperty(value = "仓码归属")
    @ExcelProperty(value = "仓码归属")
    String ownerDept;

    @ApiModelProperty(value = "BuyerName")
    @ExcelProperty(value = "BuyerName")
    String purchaserName;

    @ApiModelProperty(value = "退料人")
    @ExcelProperty(value = "退料人")
    String creator;

    @ApiModelProperty(value = "创建时间")
    @ExcelProperty(value = "创建时间", converter = LocalDateTimeStringConverter.class)
    LocalDateTime createdDt;

    @ApiModelProperty(value = "入库人")
    @ExcelProperty(value = "入库人")
    String inStorageOperator;

    @ApiModelProperty(value = "入库时间")
    @ExcelProperty(value = "入库时间", converter = LocalDateTimeStringConverter.class)
    LocalDateTime shelfDate;
}
