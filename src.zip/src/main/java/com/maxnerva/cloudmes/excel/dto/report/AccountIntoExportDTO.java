package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("库存统计DTO")
@Data
public class AccountIntoExportDTO {
    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    String plantCode;

    @ApiModelProperty(value = "料号")
    @ExcelProperty(value = "料号")
    String partNo;

    @ApiModelProperty(value = "仓码")
    @ExcelProperty(value = "仓码")
    String sapWarehouseCode;

    @ApiModelProperty(value = "数量")
    @ExcelProperty(value = "数量")
    BigDecimal confirmQty;

    @ApiModelProperty(value = "status")
    @ExcelProperty(value = "status")
    String status;

    @ApiModelProperty(value = "单号")
    @ExcelProperty(value = "单号")
    String docNo;
}
