package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("首套料缺料DTO")
@Data
public class GetFirstNotStockExportDTO {
    @ApiModelProperty(value = "工单")
    @ExcelProperty(value = "工单")
    String workOrderNo;

    @ApiModelProperty(value = "机种")
    @ExcelProperty(value = "机种")
    String productPartNo;

    @ApiModelProperty(value = "制程")
    @ExcelProperty(value = "制程")
    String productProcess;

    @ApiModelProperty(value = "群组")
    @ExcelProperty(value = "群组")
    String workOrderItem;

    @ApiModelProperty(value = "M/S")
    @ExcelProperty(value = "M/S")
    String partNoType;

    @ApiModelProperty(value = "料号")
    @ExcelProperty(value = "料号")
    String sparePartNo;

    @ApiModelProperty(value = "机台编号")
    @ExcelProperty(value = "机台编号")
    String machineCode;

    @ApiModelProperty(value = "轨道号")
    @ExcelProperty(value = "轨道号")
    String feederNo;

    @ApiModelProperty(value = "工单绑定位置")
    @ExcelProperty(value = "工单绑定位置")
    String workOrderToLocation;

    @ApiModelProperty(value = "需求量")
    @ExcelProperty(value = "需求量")
    BigDecimal requestQty;

    @ApiModelProperty(value = "烧录值")
    @ExcelProperty(value = "烧录值")
    String burnValue;

    @ApiModelProperty(value = "上料表创建时间")
    @ExcelProperty(value = "上料表创建时间", converter = LocalDateTimeStringConverter.class)
    LocalDateTime createdDt;
}
