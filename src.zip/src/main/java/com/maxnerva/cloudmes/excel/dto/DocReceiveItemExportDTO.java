package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateStringConverter;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @ClassName DocReceiveItemExportDTO
 * @Description TODO
 * @Author Likun
 * @Date 2024/2/26
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("收货明细导出dto")
@Data
public class DocReceiveItemExportDTO {

    @ApiModelProperty(value = "单据号(系统根据规则自动生成)")
    @ExcelProperty(value = "收货单号", index = 0)
    private String docNo;

    @ApiModelProperty(value = "鸿海料号")
    @ExcelProperty(value = "鸿海料号", index = 1)
    private String partNo;

    @ApiModelProperty(value = "单据数量")
    @ExcelProperty(value = "数量", index = 2)
    private BigDecimal docQty;

    @ApiModelProperty(value = "单位编码")
    @ExcelProperty(value = "单位", index = 3)
    private String uomCode;

    @ApiModelProperty(value = "制造商名称")
    @ExcelProperty(value = "制造商编码", index = 4)
    private String mfgName;

    @ApiModelProperty(value = "制造商料号")
    @ExcelProperty(value = "制造商料号", index = 5)
    private String mfgPartNo;

    @ApiModelProperty(value = "sap工厂")
    @ExcelProperty(value = "工厂", index = 6)
    private String plantCode;

    @ApiModelProperty(value = "sap仓码")
    @ExcelProperty(value = "仓码", index = 7)
    private String sapWarehouseCode;

    @ApiModelProperty(value = "单据接收日期")
    @ExcelProperty(value = "单据日期", index = 8, converter = LocalDateTimeStringConverter.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime docCreateDate;

    @ApiModelProperty(value = "预计到厂日期")
    @ExcelProperty(value = "預計到廠時間", index = 9, converter = LocalDateStringConverter.class)
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate eta;

    @ApiModelProperty(value = "单据类型名称")
    @ExcelProperty(value = "单据类型", index = 10)
    private String docTypeName;

    @ApiModelProperty(value = "单据状态名称")
    @ExcelProperty(value = "单据状态", index = 11)
    private String docStatusName;

    @ApiModelProperty(value = "来源单号")
    @ExcelProperty(value = "来源单号", index = 12)
    private String fromDocNo;

    @ApiModelProperty(value = "来源单项次")
    @ExcelProperty(value = "来源项次", index = 13)
    private String fromDocItem;

    @ApiModelProperty(value = "po编码")
    @ExcelProperty(value = "po", index = 14)
    private String poNo;

    @ApiModelProperty(value = "po项次")
    @ExcelProperty(value = "po项次", index = 15)
    private String poItem;

    @ApiModelProperty(value = "采购单号文件类型")
    @ExcelProperty(value = "po类型", index = 16)
    private String poDocumentType;

    @ApiModelProperty(value = "原产国1")
    @ExcelProperty(value = "原产国1", index = 17)
    private String placeOfOrigin1;

    @ApiModelProperty(value = "原产国2")
    @ExcelProperty(value = "原产国2", index = 18)
    private String placeOfOrigin2;

    @ApiModelProperty(value = "毛重")
    @ExcelProperty(value = "毛重", index = 19)
    private BigDecimal grossWeight;

    @ApiModelProperty(value = "箱數")
    @ExcelProperty(value = "箱數", index = 20)
    private Integer cartonQty;

    @ApiModelProperty(value = "板數")
    @ExcelProperty(value = "板數", index = 21)
    private Integer palletQty;

    @ApiModelProperty(value = "DC")
    @ExcelProperty(value = "DC", index = 22)
    private String dc;

    @ApiModelProperty(value = "INVOICE NO")
    @ExcelProperty(value = "INVOICE NO", index = 23)
    private String invoiceNo;

    @ApiModelProperty(value = "ECCN NO")
    @ExcelProperty(value = "ECCN NO", index = 24)
    private String eccnNo;

    @ApiModelProperty(value = "创建人")
    @ExcelProperty(value = "创建人", index = 25)
    private String creator;

    @ApiModelProperty(value = "修改人")
    @ExcelProperty(value = "最后编辑人", index = 26)
    private String lastEditor;

    @ApiModelProperty(value = "修改时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "最后编辑时间", index = 27, converter = LocalDateTimeStringConverter.class)
    private LocalDateTime lastEditedDt;

    @ApiModelProperty("是否上传SN  Y--是 N--否，默认N")
    @ExcelProperty(value = "是否上传SN", index = 28)
    private String uploadSnFlag;
}
