package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("勾兑报关单失败DTO")
@Data
public class DocBlendingCusFailExportDTO {
    @ExcelProperty(value = "BU")
    @ApiModelProperty(value = "BU")
    private String orgCode;

    @ExcelProperty(value = "工厂")
    @ApiModelProperty(value = "工厂编码,sap工厂编码;")
    private String plantCode;

    @ExcelProperty(value = "单号")
    @ApiModelProperty(value = "单号")
    private String docNo;

    @ExcelProperty(value = "GR单号")
    @ApiModelProperty(value = "GR单号")
    private String sapReturnNumber;

    @ExcelProperty(value = "GR过账时间", converter = LocalDateTimeStringConverter.class)
    @ApiModelProperty(value = "GR过账时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime postingSapMethodDate;

    @ExcelProperty(value = "PO")
    @ApiModelProperty(value = "PO")
    private String poNo;

    @ExcelProperty(value = "PO项次")
    @ApiModelProperty(value = "PO项次")
    private String poItem;

    @ExcelProperty(value = "预报关单号")
    @ApiModelProperty(value = "预报关单号")
    private String fromDocNo;

    @ExcelProperty(value = "预报关项次")
    @ApiModelProperty(value = "预报关项次")
    private String fromDocItem;

    @ExcelProperty(value = "报关单号")
    @ApiModelProperty(value = "报关单号")
    private String customDocNo;

    @ExcelProperty(value = "报关单项次")
    @ApiModelProperty(value = "报关单项次")
    private String customDocItemNo;

    @ApiModelProperty(value = "勾兑报关单号")
    @ExcelProperty(value = "勾兑报关单号")
    private String blendingCusNo;

    @ApiModelProperty(value = "勾兑报关单项次")
    @ExcelProperty(value = "勾兑报关单项次")
    private String blendingCusItem;

    @ExcelProperty(value = "勾兑报关单信息")
    @ApiModelProperty(value = "勾兑信息")
    private String blendingCusMessage;

    @ExcelProperty(value = "勾兑报关单时间", converter = LocalDateTimeStringConverter.class)
    @ApiModelProperty(value = "勾兑时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime blendingCusDatetime;

    @ExcelProperty(value = "勾兑报关单状态")
    @ApiModelProperty(value = "勾兑状态")
    private String blendingCusFlagName;
}
