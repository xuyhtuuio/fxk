package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("关键物料DTO")
@Data
public class KeyMaterialListExportDTO {

    @ApiModelProperty("BU")
    @ExcelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty("工厂")
    @ExcelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty("料号")
    @ExcelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty("厂商料号")
    @ExcelProperty(value = "厂商料号")
    private String mfgPartNo;

    @ApiModelProperty("厂商名")
    @ExcelProperty(value = "厂商名")
    private String mfgName;

    @ApiModelProperty("物料分类")
    @ExcelProperty(value = "物料分类")
    private String classCode;

    @ApiModelProperty(value = "创建人")
    @ExcelProperty(value = "创建人")
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "创建时间", converter = LocalDateTimeStringConverter.class)
    @ApiModelProperty(value = "创建时间")
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "修改人")
    @ExcelProperty(value = "修改人")
    private String lastEditor;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "修改时间")
    @ExcelProperty(value = "修改时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime lastEditedDt;
}
