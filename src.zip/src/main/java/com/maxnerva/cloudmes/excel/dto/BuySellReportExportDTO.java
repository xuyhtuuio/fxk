package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @ClassName BuySellReportExportDTO
 * @Description buySell报表导出DTO
 * @Author Likun
 * @Date 2023/12/15
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("buySell报表导出DTO")
@Data
public class BuySellReportExportDTO {

    @ApiModelProperty(value = "工厂组织")
    @ExcelProperty(value = "工厂组织", index = 0)
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂", index = 1)
    private String plantCode;

    @ApiModelProperty(value = "仓码")
    @ExcelProperty(value = "仓码", index = 2)
    private String sapWarehouseCode;

    @ApiModelProperty(value = "条码")
    @ExcelProperty(value = "条码", index = 3)
    private String pkgId;

    @ApiModelProperty(value = "boxId")
    @ExcelProperty(value = "boxId", index = 4)
    private String boxId;

    @ApiModelProperty(value = "sn")
    @ExcelProperty(value = "sn", index = 5)
    private String snNo;

    @ApiModelProperty(value = "料号")
    @ExcelProperty(value = "料号", index = 6)
    private String partNo;

    @ApiModelProperty(value = "原始数量")
    @ExcelProperty(value = "数量", index = 7)
    private BigDecimal originalQty;

    @ApiModelProperty(value = "制造商料号")
    @ExcelProperty(value = "制造商料号", index = 8)
    private String mfgPartNo;

    @ApiModelProperty(value = "供应商料号")
    @ExcelProperty(value = "供应商料号", index = 9)
    private String supplierPartNo;

    @ApiModelProperty(value = "制造商名称")
    @ExcelProperty(value = "制造商名称", index = 10)
    private String mfgName;

    @ApiModelProperty(value = "采集类型")
    @ExcelProperty(value = "采集类型", index = 11)
    private String scanMethod;

    @ApiModelProperty(value = "原产国")
    @ExcelProperty(value = "原产国", index = 12)
    private String placeOfOrigin1;

    @ApiModelProperty(value = "当前数量")
    @ExcelProperty(value = "当前数量", index = 13)
    private BigDecimal currentQty;

    @ApiModelProperty(value = "采集人")
    @ExcelProperty(value = "采集人", index = 14)
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "采集时间")
    @ExcelProperty(value = "采集时间", index = 15, converter = LocalDateTimeStringConverter.class)
    private LocalDateTime createdDt;
}
