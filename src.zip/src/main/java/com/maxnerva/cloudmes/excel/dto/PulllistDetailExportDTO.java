package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateStringConverter;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;


@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("pulllist详情导出DTO")
@Data
public class PulllistDetailExportDTO {

    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂", index = 0)
    private String plantCode;

    @ApiModelProperty(value = "工单号")
    @ExcelProperty(value = "工单号", index = 1)
    private String workOrderNo;

    @ApiModelProperty(value = "工单群组")
    @ExcelProperty(value = "工单群组", index = 2)
    private String workOrderItem;

    @ApiModelProperty(value = "成品料号")
    @ExcelProperty(value = "成品料号", index = 3)
    private String productPartNo;

    @ApiModelProperty(value = "生产日期")
    @ExcelProperty(value = "生产日期", index = 4, converter = LocalDateStringConverter.class)
    private LocalDate scheduledDate;

    @ApiModelProperty(value = "线别")
    @ExcelProperty(value = "线别", index = 5)
    private String lineNo;

    @ApiModelProperty(value = "缺料流水号")
    @ExcelProperty(value = "缺料流水号", index = 6)
    private String materialShortageNo;

    @ApiModelProperty(value = "料号")
    @ExcelProperty(value = "料号", index = 7)
    private String partNo;

    @ApiModelProperty(value = "主料号")
    @ExcelProperty(value = "主料号", index = 8)
    private String mainPartNo;

    @ApiModelProperty(value = "主替代料关系")
    @ExcelProperty(value = "主替代料关系", index = 9)
    private String partRelationShip;

    @ApiModelProperty(value = "wms群组缺料量")
    @ExcelProperty(value = "wms群组缺料量", index = 10)
    private BigDecimal wmsItemShortageQty;

    @ApiModelProperty(value = "wms分配量")
    @ExcelProperty(value = "wms分配量", index = 11)
    private BigDecimal wmsAllocateQty;

    @ApiModelProperty(value = "wms分配后的群组缺料量")
    @ExcelProperty(value = "wms分配后的群组缺料量", index = 12)
    private BigDecimal wmsItemAssignedShortageQty;

    @ApiModelProperty(value = "CMI/VMI分配量")
    @ExcelProperty(value = "CMI/VMI分配量", index = 13)
    private BigDecimal jusdaAllocateQty;

    @ApiModelProperty(value = "CMI/VMI分配后的群组缺料量")
    @ExcelProperty(value = "CMI/VMI分配后的群组缺料量", index = 14)
    private String jusdaItemAssignedShortageQty;

    @ApiModelProperty(value = "CMI/VMI库存版本号")
    @ExcelProperty(value = "CMI/VMI库存版本号", index = 15)
    private String jusdaStockVersion;

    @ApiModelProperty(value = "包装数量")
    @ExcelProperty(value = "包装数量", index = 16)
    private BigDecimal minPackQty;

    @ApiModelProperty(value = "pulljusda标识")
    @ExcelProperty(value = "pulljusda标识", index = 17)
    private String postJusdaFlag;

    @ApiModelProperty(value = "jusda返回信息")
    @ExcelProperty(value = "jusda返回信息", index = 18)
    private String jusdaReturnRemark;

}
