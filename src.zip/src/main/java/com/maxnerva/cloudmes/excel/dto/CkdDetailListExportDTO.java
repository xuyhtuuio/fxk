package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("CKD 工单Detail 报表导出DTO")
@Data
public class CkdDetailListExportDTO {
    @ApiModelProperty(value = "料号")
    @ExcelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "工单群组，posnr，备料以工单群组推荐;//群組")
    @ExcelProperty(value = "群组")
    private String workOrderItem;

    @ApiModelProperty(value = "料号关系类型,M主料,S替代料")
    @ExcelProperty(value = "M/S")
    private String partRelationship;

    @ApiModelProperty(value = "需求量")
    @ExcelProperty(value = "需求量")
    private BigDecimal requiredQuantity;

    @ApiModelProperty(value = "发料量")
    @ExcelProperty(value = "发料量")
    private BigDecimal stockQty;

    @ApiModelProperty(value = "发料总量")
    @ExcelProperty(value = "发料总量")
    private BigDecimal stockTotalQty;

    @ApiModelProperty(value = "差异量")
    @ExcelProperty(value = "差异量")
    private BigDecimal differenceQty;

    @ApiModelProperty(value = "版次")
    @ExcelProperty(value = "版次")
    private String partVersion;

    @ApiModelProperty(value = "A/B/C")
    @ExcelProperty(value = "A/B/C")
    private String materialType;

    @ApiModelProperty(value = "from 仓码")
    @ExcelProperty(value = "from 仓码")
    private String fromWarehouseCode;

    @ApiModelProperty(value = "to 仓码")
    @ExcelProperty(value = "to 仓码")
    private String toWarehouseCode;

    @ApiModelProperty(value = "post311数量")
    @ExcelProperty(value = "post311数量")
    private BigDecimal postTo311Qty;

    @ApiModelProperty(value = "post311返回信息")
    @ExcelProperty(value = "post311返回信息")
    private String postTo311ReturnMsg;

    @ApiModelProperty(value = "post311时间")
    @ExcelProperty(value = "post311时间", converter = LocalDateTimeStringConverter.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime postTo311LastDt;
}
