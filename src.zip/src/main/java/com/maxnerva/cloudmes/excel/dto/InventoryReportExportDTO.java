package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @ClassName InventoryReportExportDTO
 * @Description TODO
 * @Author Likun
 * @Date 2024/6/25
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("盘点报表导出DTO")
@Data
public class InventoryReportExportDTO {

    @ApiModelProperty("组织")
    @ExcelProperty(value = "组织", index = 0)
    private String orgCode;

    @ApiModelProperty("工厂")
    @ExcelProperty(value = "工厂", index = 1)
    private String plantCode;

    @ApiModelProperty("盘点单号")
    @ExcelProperty(value = "盘点单号", index = 2)
    private String inventoryPlanNo;

    @ApiModelProperty("盘点描述")
    @ExcelProperty(value = "盘点描述", index = 3)
    private String description;

    @ApiModelProperty("状态")
    @ExcelProperty(value = "状态", index = 4)
    private String inventoryStatusName;

    @ApiModelProperty("计划盘点人")
    @ExcelProperty(value = "计划盘点人", index = 5)
    private String inventoryExecutorName;

    @ApiModelProperty("盘点范围")
    @ExcelProperty(value = "盘点范围", index = 6)
    private String inventoryRange;

    @ApiModelProperty("建单人")
    @ExcelProperty(value = "建单人", index = 7)
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "建单时间")
    @ExcelProperty(value = "建单时间", index = 8, converter = LocalDateTimeStringConverter.class)
    private LocalDateTime createdDt;

    @ApiModelProperty("盘点类型")
    @ExcelProperty(value = "盘点类型", index = 9)
    private String inventoryTypeName;

    @ApiModelProperty("库存pkg")
    @ExcelProperty(value = "库存pkg", index = 10)
    private String pkgId;

    @ApiModelProperty("扫描pkg")
    @ExcelProperty(value = "扫描pkg", index = 11)
    private String inventoryPkgId;

    @ApiModelProperty(value = "盘点时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "盘点时间", index = 12, converter = LocalDateTimeStringConverter.class)
    private LocalDateTime inventoryDateTime;

    @ApiModelProperty(value = "实际盘点人")
    @ExcelProperty(value = "实际盘点人", index = 13)
    private String inventoryExecutorCode;

    @ApiModelProperty(value = "料号")
    @ExcelProperty(value = "料号", index = 14)
    private String partNo;

    @ApiModelProperty(value = "数量")
    @ExcelProperty(value = "数量", index = 15)
    private BigDecimal qty;

    @ApiModelProperty(value = "库区")
    @ExcelProperty(value = "库区", index = 16)
    private String areaCode;

    @ApiModelProperty(value = "库位")
    @ExcelProperty(value = "库位", index = 17)
    private String locationCode;

    @ApiModelProperty(value = "载具")
    @ExcelProperty(value = "载具", index = 18)
    private String vehicleCode;

    @ApiModelProperty(value = "储位")
    @ExcelProperty(value = "储位", index = 19)
    private String binCode;

    @ApiModelProperty(value = "仓码")
    @ExcelProperty(value = "仓码", index = 20)
    private String sapWarehouseCode;

    @ApiModelProperty(value = "报错原因")
    @ExcelProperty(value = "报错原因", index = 21)
    private String abnormalCause;

    @ApiModelProperty(value = "版次")
    @ExcelProperty(value = "版次", index = 22)
    private String partVersion;
}
