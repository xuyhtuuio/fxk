package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.time.LocalDateTime;

/**
 * @ClassName InventoryPlanHeaderDTO
 * @Description TODO
 * @Author Likun
 * @Date 2024/6/25
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("盘点计划单头导出DTO")
@Data
public class InventoryPlanHeaderExportDTO {

    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂", index = 0)
    private String plantCode;

    @ApiModelProperty(value = "盘点计划编号")
    @ExcelProperty(value = "编号", index = 1)
    private String inventoryPlanNo;

    @ApiModelProperty(value = "盘点类型名称")
    @ExcelProperty(value = "盘点类型名称", index = 2)
    private String inventoryTypeName;

    @ApiModelProperty(value = "盘点范围")
    @ExcelProperty(value = "盘点范围", index = 3)
    private String inventoryRange;

    @ApiModelProperty(value = "描述")
    @ExcelProperty(value = "描述", index = 4)
    private String description;

    @ApiModelProperty(value = "盘点状态名称")
    @ExcelProperty(value = "状态", index = 5)
    private String inventoryStatusName;

    @ApiModelProperty(value = "盘点人名称")
    @ExcelProperty(value = "执行人", index = 6)
    private String inventoryExecutorName;

    @ApiModelProperty(value = "创建人")
    @ExcelProperty(value = "创建人", index = 7)
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "创建时间")
    @ExcelProperty(value = "创建时间", index = 8, converter = LocalDateTimeStringConverter.class)
    private LocalDateTime createdDt;
}
