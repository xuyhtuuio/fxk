package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("出貨區作業看板DTO")
@Data
public class GetShipWorkDataExportDTO {
    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    private String sapPlantCode;

    @ApiModelProperty(value = "出库单号")
    @ExcelProperty(value = "出货单号")
    private String docNo;

    @ApiModelProperty(value = "DN单号")
    @ExcelProperty(value = "DN单号")
    private String dnNo;

    @ApiModelProperty(value = "单据类型")
    @ExcelProperty(value = "单据类型")
    private String docTypeName;

    @ApiModelProperty(value = "计划出货时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "计划出货时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime planShipTime;

    @ApiModelProperty(value = "出貨地")
    @ExcelProperty(value = "出货地")
    private String siteCode;

    @ApiModelProperty(value = "运输方式")
    @ExcelProperty(value = "运输方式")
    private String transportModeName;

    @ApiModelProperty(value = "已備貨棧板個數")
    @ExcelProperty(value = "已備貨棧板個數")
    private Integer qty;

    @ApiModelProperty(value = "已出貨棧板個數")
    @ExcelProperty(value = "已出貨棧板個數")
    private Integer qty1;

    @ApiModelProperty(value = "码头号")
    @ExcelProperty(value = "码头号")
    private String dockNo;

    @ApiModelProperty(value = "车牌号")
    @ExcelProperty(value = "车牌号")
    private String licenseNo;

    @ApiModelProperty(value = "货柜号")
    @ExcelProperty(value = "货柜号")
    private String containerNo;

    @ApiModelProperty(value = "到厂时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "到厂时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime arriveTime;

    @ApiModelProperty(value = "离厂时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "离厂时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime leaveTime;

    @ApiModelProperty(value = "状态")
    @ExcelProperty(value = "状态")
    private String statusName;
}
