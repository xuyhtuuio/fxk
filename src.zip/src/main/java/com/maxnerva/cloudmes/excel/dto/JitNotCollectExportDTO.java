package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateStringConverter;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import jodd.typeconverter.impl.LocalDateConverter;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @ClassName JitNotCollectExportDTO
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/5/27 下午 06:24
 * @Version 1.0
 **/

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("JIT未采集邮件提醒DTO")
@Data
public class JitNotCollectExportDTO {


    @ApiModelProperty(value = "组织")
    @ExcelProperty(value = "组织")
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "ASN号")
    @ExcelProperty(value = "ASN号")
    private String asnNo;

    @ApiModelProperty(value = "GR号")
    @ExcelProperty(value = "GR号")
    private String grNumber;

    @ApiModelProperty(value = "GR日期")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @ExcelProperty(value = "GR日期", converter = LocalDateStringConverter.class)
    private LocalDate grDate;

    @ApiModelProperty(value = "PO号")
    @ExcelProperty(value = "PO号")
    private String poNo;

    @ApiModelProperty(value = "PO ITEM")
    @ExcelProperty(value = "PO ITEM")
    private String poItem;

    @ApiModelProperty(value = "vendor code")
    @ExcelProperty(value = "vendor code")
    private String vendorCode;

    @ApiModelProperty(value = "ASN料号")
    @ExcelProperty(value = "ASN料号")
    private String partNo;

    @ApiModelProperty(value = "料号描述")
    @ExcelProperty(value = "ASN料号描述")
    private String partDesc;

    @ApiModelProperty(value = "料号版次")
    @ExcelProperty(value = "ASN料号版次")
    private String partVersion;

    @ApiModelProperty(value = "数量")
    @ExcelProperty(value = "ASN料号数量")
    private BigDecimal qty;

    @ApiModelProperty(value = "po类型")
    @ExcelProperty(value = "po类型")
    private String poDocumentType;

    @ApiModelProperty(value = "厂商编码")
    @ExcelProperty(value = "厂商编码")
    private String mfgCode;

    @ApiModelProperty(value = "厂商料号")
    @ExcelProperty(value = "厂商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "厂商名称")
    @ExcelProperty(value = "厂商名称")
    private String mfgName;

    @ApiModelProperty(value = "单位")
    @ExcelProperty(value = "单位")
    private String uomCode;

    @ApiModelProperty(value = "仓码")
    @ExcelProperty(value = "仓码")
    private String warehouseCode;

    @ApiModelProperty(value = "原产国")
    @ExcelProperty(value = "原产国")
    private String placeOfOrigin;

    @ApiModelProperty(value = "采购员组")
    @ExcelProperty(value = "采购员组")
    private String purchaseGroup;

    @ApiModelProperty(value = "采购员org")
    @ExcelProperty(value = "采购员org")
    private String purchaseOrg;

    @ApiModelProperty(value = "建单标识(Y-成功 N-失败)")
    @ExcelProperty(value = "建单标识(Y-成功 N-失败)")
    private String docCreateFlag;

    @ApiModelProperty(value = "建单信息")
    @ExcelProperty(value = "建单信息")
    private String docCreateMsg;

    @ApiModelProperty(value = "移动类型")
    @ExcelProperty(value = "移动类型")
    private String movementType;

    @ApiModelProperty(value = "返单gr号")
    @ExcelProperty(value = "返单gr号")
    private String returnGrNumber;


}
