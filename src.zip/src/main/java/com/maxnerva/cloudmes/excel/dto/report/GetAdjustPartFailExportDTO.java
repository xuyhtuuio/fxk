package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("料调过账DTO")
@Data
public class GetAdjustPartFailExportDTO {
    @ApiModelProperty(value = "SAP工厂")
    @ExcelProperty(value = "工廠")
    private String oldPlantCode;

    @ApiModelProperty(value = "仓码")
    @ExcelProperty(value = "仓码")
    private String oldWarehoseCode;

    @ApiModelProperty(value = "单号")
    @ExcelProperty(value = "单号")
    private String docNo;


    @ApiModelProperty(value = "状态名称")
    @ExcelProperty(value = "状态")
    String identifyName;

    @ApiModelProperty(value = "原鸿海料号")
    @ExcelProperty(value = "原鸿海料号")
    private String oldMaterialCode;

    @ApiModelProperty(value = "Buyer")
    @ExcelProperty(value = "Buyer")
    private String buyerName;

    @ApiModelProperty(value = "原厂商料号")
    @ExcelProperty(value = "原厂商料号")
    private String oldMfgMaterial;

    @ApiModelProperty(value = "原厂商")
    @ExcelProperty(value = "原厂商")
    private String oldMfgName;

    @ApiModelProperty(value = "目的鸿海料号")
    @ExcelProperty(value = "目的鸿海料号")
    private String targetMaterialCode;

    @ApiModelProperty(value = "目的厂商")
    @ExcelProperty(value = "目的厂商")
    private String targetMfgName;

    @ApiModelProperty(value = "开单时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "开单时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime date;

    @ApiModelProperty(value = "开单人")
    @ExcelProperty(value = "开单人")
    private String creator;

    @ApiModelProperty(value = "确认人")
    @ExcelProperty(value = "确认人")
    private String confirmPerson;

    @ApiModelProperty(value = "申请数量")
    @ExcelProperty(value = "申请数量")
    BigDecimal applyQty;

    @ApiModelProperty(value = "完成数量")
    @ExcelProperty(value = "完成数量")
    BigDecimal completeQty;

    @ApiModelProperty(value = "过账信息")
    @ExcelProperty(value = "过账信息")
    String sapReturnMessage;

    @ApiModelProperty(value = "过账时间")
    @ExcelProperty(value = "过账时间", converter = LocalDateTimeStringConverter.class)
    LocalDateTime sapUploadData;

}
