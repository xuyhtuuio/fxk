package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @ClassName MaterialShortageExportDTO
 * @Description 缺料报表导出DTO
 * @Author Likun
 * @Date 2022/11/29
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("缺料报表导出DTO")
@Data
public class MaterialShortageExportDTO {

    @ApiModelProperty(value = "工单号")
    @ExcelProperty(value = "工单号", index = 0)
    private String workOrderNo;

    @ApiModelProperty(value = "主料号")
    @ExcelProperty(value = "主料号", index = 1)
    private String keyPartNo;

    @ApiModelProperty(value = "替代号")
    @ExcelProperty(value = "替代号", index = 2)
    private String sparePartNo;

    @ApiModelProperty(value = "成品料号")
    @ExcelProperty(value = "成品料号", index = 3)
    private String productPartNo;

    @ApiModelProperty(value = "机台编号")
    @ExcelProperty(value = "机台编号", index = 4)
    private String machineCode;

    @ApiModelProperty(value = "线别")
    @ExcelProperty(value = "线别", index = 5)
    private String lineNo;

    @ApiModelProperty(value = "AB面")
    @ExcelProperty(value = "工艺面", index = 6)
    private String lineCategory;

    @ApiModelProperty(value = "机台方向（13、 24）")
    @ExcelProperty(value = "机台方向", index = 7)
    private String machineDirection;

    @ApiModelProperty(value = "工单群组")
    @ExcelProperty(value = "工单群组", index = 8)
    private String workOrderItem;

    @ApiModelProperty(value = "主料号版次")
    @ExcelProperty(value = "主料号版次", index = 9)
    private String keyPartVersion;

    @ApiModelProperty(value = "替代料版次")
    @ExcelProperty(value = "零件料号版次", index = 10)
    private String sparePartNoVersion;

    @ApiModelProperty(value = "M:主料，S替代料")
    @ExcelProperty(value = "主/替", index = 11)
    private String partNoType;

    @ApiModelProperty(value = "feeder号,轨道号")
    @ExcelProperty(value = "轨道号", index = 12)
    private String feederNo;

    @ApiModelProperty(value = "连板数")
    @ExcelProperty(value = "连板数", index = 13)
    private BigDecimal cardsPerPanel;

    @ApiModelProperty(value = "是否需要烧录")
    @ExcelProperty(value = "是否需要烧录", index = 14)
    private String isBurn;

    @ApiModelProperty(value = "需求量")
    @ExcelProperty(value = "需求量", index = 15)
    private BigDecimal requestQty;

    @ApiModelProperty(value = "分配量")
    @ExcelProperty(value = "分配量", index = 16)
    private BigDecimal allocateQty;

    @ApiModelProperty(value = "缺料量")
    @ExcelProperty(value = "缺料量", index = 17)
    private BigDecimal shortageQty;

    @ApiModelProperty(value = "包装数量")
    @ExcelProperty(value = "包装数量", index = 18)
    private BigDecimal minPackQty;

    @ApiModelProperty(value = "SMT、PTH、ASSY")
    @ExcelProperty(value = "生产类型", index = 19)
    private String productProcess;

    @ApiModelProperty(value = "成品料号版次")
    @ExcelProperty(value = "成品料号版次", index = 20)
    private String productPartVersion;

    @ApiModelProperty(value = "检料量")
    @ExcelProperty(value = "检料量", index = 21)
    private BigDecimal pickedQty;

    @ApiModelProperty(value = "缺料流水号")
    @ExcelProperty(value = "缺料流水号", index = 22)
    private String materialShortageNo;

    @ApiModelProperty(value = "BU")
    @ExcelProperty(value = "工厂组织", index = 23)
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂", index = 24)
    private String plantCode;

    @ApiModelProperty(value = "创建人")
    @ExcelProperty(value = "创建人", index = 25)
    private String creator;

    @ApiModelProperty(value = "创建时间")
    @ExcelProperty(value = "创建时间", index = 26, converter = LocalDateTimeStringConverter.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdDt;
}
