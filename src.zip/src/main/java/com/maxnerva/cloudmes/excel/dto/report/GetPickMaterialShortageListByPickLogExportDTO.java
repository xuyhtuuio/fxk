package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("工单检料缺料（byWorkOrderDetail, 算捡料量(沒有到prepare_log的量)）")
@Data
public class GetPickMaterialShortageListByPickLogExportDTO {
    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "工单")
    @ExcelProperty(value = "工单")
    private String workOrderNo;

    @ApiModelProperty(value = "线别")
    @ExcelProperty(value = "线别")
    private String lineNo;

    @ApiModelProperty(value = "群组")
    @ExcelProperty(value = "群组")
    private String workOrderItem;

    @ApiModelProperty(value = "M/S")
    @ExcelProperty(value = "M/S")
    private String partRelationship;

    @ApiModelProperty(value = "料号")
    @ExcelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "描述")
    @ExcelProperty(value = "描述")
    private String materialDescription;

    @ApiModelProperty(value = "物料类别")
    @ExcelProperty(value = "物料类别")
    private String materialType;

    @ApiModelProperty(value = "SAP需求量")
    @ExcelProperty(value = "SAP需求量")
    private BigDecimal requiredQuantitySap;

    @ApiModelProperty(value = "发料量(发料量+转入量)")
    @ExcelProperty(value = "发料量(发料量+转入量)")
    private BigDecimal stockQty;

    @ApiModelProperty(value = "退料量+转出量")
    @ExcelProperty(value = "退料量+转出量")
    private BigDecimal return262Qty;

    @ApiModelProperty(value = "当前捡料量")
    @ExcelProperty(value = "当前捡料量")
    private BigDecimal prePickQty;

    @ApiModelProperty(value = "发料总量")
    @ExcelProperty(value = "发料总量")
    private BigDecimal stockTotalQty;

    @ApiModelProperty(value = "缺料量")
    @ExcelProperty(value = "缺料量")
    private BigDecimal lackQty;

    @ApiModelProperty(value = "WMS良品库存")
    @ExcelProperty(value = "WMS良品库存")
    private BigDecimal pkgTotalQty;

    @ApiModelProperty(value = "最后缺发量")
    @ExcelProperty(value = "最后缺发量")
    private BigDecimal lackFinishQty;

    @ApiModelProperty(value = "WMS锁定库存")
    @ExcelProperty(value = "WMS锁定库存")
    private BigDecimal lockPkgQty;

    @ApiModelProperty(value = "锁定原因")
    @ExcelProperty(value = "锁定原因")
    private String lockMessage;

    @ApiModelProperty(value = "Pull量")
    @ExcelProperty(value = "Pull量")
    private String pullNum;

    @ApiModelProperty(value = "收货待上架")
    @ExcelProperty(value = "收货待上架")
    private String preShelfNum;

    @ApiModelProperty(value = "仓码")
    @ExcelProperty(value = "仓码")
    private String fromWarehouseCode;

    @ApiModelProperty(value = "制程")
    @ExcelProperty(value = "制程")
    private String materialProductType;

    @ApiModelProperty(value = "采购组")
    @ExcelProperty(value = "采购组")
    private String buyerCode;

    @ApiModelProperty(value = "Buyer")
    @ExcelProperty(value = "Buyer")
    private String purchaserName;

    @ApiModelProperty(value = "物料管理方式")
    @ExcelProperty(value = "物料管理方式")
    private String scanMode;
}
