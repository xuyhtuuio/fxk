package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.time.LocalDateTime;

/**
 * @ClassName MaterialUsageExportDTO
 * @Description TODO
 * @Author Likun
 * @Date 2025/1/8
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("工单锁料配置导出DTO")
@Data
public class MaterialUsageExportDTO {

    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂", index = 0)
    private String plantCode;

    @ApiModelProperty(value = "mrpArea")
    @ExcelProperty(value = "mrpArea", index = 1)
    private String mrpArea;

    @ApiModelProperty("成品料号")
    @ExcelProperty(value = "成品料号", index = 2)
    private String productPartNo;

    @ApiModelProperty("零件料号")
    @ExcelProperty(value = "零件料号", index = 3)
    private String partNo;

    @ApiModelProperty("制造商料号")
    @ExcelProperty(value = "制造商料号", index = 4)
    private String mfgPartNo;

    @ApiModelProperty("制造商名称")
    @ExcelProperty(value = "制造商名称", index = 5)
    private String mfgName;

    @ApiModelProperty("料号配置标识名称")
    @ExcelProperty(value = "料号配置标识", index = 6)
    private String partNoUseFlagName;

    @ApiModelProperty("创建人")
    @ExcelProperty(value = "创建人", index = 7)
    private String creator;

    @ApiModelProperty("创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "创建时间", index = 8,converter = LocalDateTimeStringConverter.class)
    private LocalDateTime createdDt;
}
