package com.maxnerva.cloudmes.excel.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @ClassName ImportResultVO
 * @Description excel导入结果
 * @Author Likun
 * @Date 2022/10/27
 * @Version 1.0
 * @Since JDK 1.8
 **/
@ApiModel("excel导入结果")
@Data
public class ImportResultDTO {

    private static final long serialVersionUID = 1L;

    /**
     * 导入结果：true-成功 false-失败
     */
    @ApiModelProperty(value = "导入结果：true-成功 false-失败")
    private Boolean result;

    /**
     * 导入异常信息列表
     */
    @ApiModelProperty(value = "导入异常信息列表")
    private List<String> msgList;

    /**
     * 导入异常信息字符串
     */
    @ApiModelProperty(value = "导入异常信息字符串")
    private String msgStr;

    public String getMsgStr() {
        StringBuilder stringBuilder = new StringBuilder();
        for (String str : msgList){
            stringBuilder.append(str);
            stringBuilder.append(";");
            stringBuilder.append("\n");
        }
        return stringBuilder.toString();
    }

    public Boolean getResult() {
        return msgList.size() == 0;
    }
}
