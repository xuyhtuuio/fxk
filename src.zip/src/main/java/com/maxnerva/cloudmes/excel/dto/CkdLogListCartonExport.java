package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("CKD打包清单(箱号)导出DTO")
@Data
public class CkdLogListCartonExport {
    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "工单号")
    @ExcelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "箱号")
    @ExcelProperty(value = "箱号")
    private String cartonCode;

    @ApiModelProperty(value = "状态")
    @ExcelProperty(value = "状态")
    private String packTypeName;

    @ApiModelProperty(value = "位置")
    @ExcelProperty(value = "位置")
    private String positionCode;

    @ApiModelProperty(value = "货柜号")
    @ExcelProperty(value = "货柜号")
    private String containerCode;

    @ApiModelProperty(value = "是否生成DN")
    @ExcelProperty(value = "是否生成DN")
    private String dnStatusName;

    @ApiModelProperty(value = "毛重")
    @ExcelProperty(value = "毛重")
    private BigDecimal grossWeight;

    @ApiModelProperty(value = "体积")
    @ExcelProperty(value = "体积")
    private String volume;

    @ApiModelProperty(value = "运输方式")
    @ExcelProperty(value = "运输方式")
    private String transportMode;

    @ApiModelProperty(value = "单据序列号")
    @ExcelProperty(value = "单据序列号")
    private String serialNo;
}
