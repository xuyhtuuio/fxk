package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.time.LocalDateTime;

/**
 * @ClassName AgvTaskListExportDTO
 * @Description TODO
 * @Author Likun
 * @Date 2024/5/8
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("AGV任务列表信息导出DTO")
@Data
public class AgvTaskListExportDTO {

    @ApiModelProperty(value = "BU")
    @ExcelProperty(value = "组织", index = 0)
    private String orgCode;

    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂", index = 1)
    private String plantCode;

    @ApiModelProperty(value = "任务单号")
    @ExcelProperty(value = "任务单号", index = 2)
    private String taskNo;

    @ApiModelProperty(value = "AGV任务单号")
    @ExcelProperty(value = "AGV任务单号", index = 3)
    private String agvTaskNo;

    @ApiModelProperty(value = "工单")
    @ExcelProperty(value = "工单", index = 4)
    private String workOrderNo;

    @ApiModelProperty(value = "工单位置")
    @ExcelProperty(value = "工单位置", index = 5)
    private String materialProductType;

    @ApiModelProperty(value = "库区")
    @ExcelProperty(value = "库区", index = 6)
    private String areaCode;

    @ApiModelProperty(value = "库位")
    @ExcelProperty(value = "库位", index = 7)
    private String locationCode;

    @ApiModelProperty(value = "载具")
    @ExcelProperty(value = "载具", index = 8)
    private String vehicleCode;

    @ApiModelProperty(value = "储位")
    @ExcelProperty(value = "储位", index = 9)
    private String binCode;

    @ApiModelProperty(value = "储位对应的AGV仓位")
    @ExcelProperty(value = "AGV仓位", index = 10)
    private String agvWarehouseCode;

    @ApiModelProperty(value = "AGV目标仓位")
    @ExcelProperty(value = "AGV目标仓位", index = 11)
    private String agvTargetWarehouseCode;

    @ApiModelProperty(value = "任务类型")
    @ExcelProperty(value = "任务类型", index = 12)
    private String taskType;

    @ApiModelProperty(value = "任务状态：0（创建）；1（任务执行中）；2（任务结束）")
    @ExcelProperty(value = "任务状态", index = 13)
    private String taskFinishFlag;

    @ApiModelProperty(value = "结案描述")
    @ExcelProperty(value = "结案描述", index = 14)
    private String taskFinishDes;

    @ApiModelProperty(value = "结案时间")
    @ExcelProperty(value = "结案时间", index = 15, converter = LocalDateTimeStringConverter.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime taskFinishDt;

    @ApiModelProperty(value = "结案人")
    @ExcelProperty(value = "结案人", index = 16)
    private String taskFinishEmp;

    @ApiModelProperty(value = "AGV开始时间")
    @ExcelProperty(value = "AGV开始时间", index = 17, converter = LocalDateTimeStringConverter.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime agvBeginDt;

    @ApiModelProperty(value = "AGV结束时间")
    @ExcelProperty(value = "AGV结束时间", index = 18, converter = LocalDateTimeStringConverter.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime agvEndDt;

    @ApiModelProperty(value = "条码")
    @ExcelProperty(value = "条码", index = 19)
    private String pkgId;

    @ApiModelProperty(value = "料号")
    @ExcelProperty(value = "料号", index = 20)
    private String partNo;
}
