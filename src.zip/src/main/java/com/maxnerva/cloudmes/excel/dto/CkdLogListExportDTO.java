package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateStringConverter;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("CKD打包清单导出DTO")
@Data
public class CkdLogListExportDTO {
    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "状态")
    @ExcelProperty(value = "状态")
    private String packTypeName;

    @ApiModelProperty(value = "位置")
    @ExcelProperty(value = "位置")
    private String positionCode;

    @ApiModelProperty(value = "货柜号")
    @ExcelProperty(value = "货柜号")
    private String containerCode;

    @ApiModelProperty(value = "工单号")
    @ExcelProperty(value = "工单号")
    private String workOrderNo;

    @ApiModelProperty(value = "是否生成DN")
    @ExcelProperty(value = "是否生成DN")
    private String dnStatusName;

    @ApiModelProperty(value = "栈板编号")
    @ExcelProperty(value = "栈板号")
    private String palletCode;

    @ApiModelProperty(value = "箱号")
    @ExcelProperty(value = "箱号")
    private String cartonCode;

    @ApiModelProperty(value = "鸿海料号")
    @ExcelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "数量")
    @ExcelProperty(value = "数量")
    private BigDecimal currentQty;

    @ApiModelProperty(value = "毛重")
    @ExcelProperty(value = "毛重")
    private BigDecimal grossWeight;

    @ApiModelProperty(value = "体积")
    @ExcelProperty(value = "体积")
    private String volume;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "扫描时间", converter = LocalDateTimeStringConverter.class)
    @ApiModelProperty(value = "扫描时间")
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "pkg")
    @ExcelProperty(value = "pkgId")
    private String pkgId;

    @ApiModelProperty(value = "制造商")
    @ExcelProperty(value = "制造商")
    private String mfgName;

    @ApiModelProperty(value = "供应商料号")
    @ExcelProperty(value = "供应商料号")
    private String supplierPartNo;

    @ApiModelProperty(value = "原始DC")
    @ExcelProperty(value = "原始DC")
    private String originalDateCode;

    @ApiModelProperty(value = "解析DC")
    @ExcelProperty(value = "解析DC", converter = LocalDateStringConverter.class)
    private LocalDate dateCode;

    @ApiModelProperty(value = "LOT")
    @ExcelProperty(value = "LOT")
    private String lotNo;

    @ApiModelProperty(value = "制造商料号")
    @ExcelProperty(value = "制造商料号")
    private String mfgPartNo;

    @ApiModelProperty(value = "原产国")
    @ExcelProperty(value = "原产国")
    private String placeOfOrigin1;

    @ApiModelProperty(value = "CUS原产国")
    @ExcelProperty(value = "CUS原产国")
    private String cusPlaceOfOrigin1;

    @ApiModelProperty(value = "干燥剂")
    @ExcelProperty(value = "干燥剂")
    private String desiccant;

    @ApiModelProperty(value = "电池")
    @ExcelProperty(value = "电池")
    private String battery;

    @ApiModelProperty(value = "风扇")
    @ExcelProperty(value = "风扇")
    private String fan;

    @ApiModelProperty(value = "栈板材质")
    @ExcelProperty(value = "栈板材质")
    private String palletMaterial;

    @ApiModelProperty(value = "收货PO")
    @ExcelProperty(value = "收货PO")
    private String po;

    @ApiModelProperty(value = "收货PO项次")
    @ExcelProperty(value = "收货PO项次")
    private String poItem;

    @ApiModelProperty(value = "报关料号")
    @ExcelProperty(value = "报关料号")
    private String customsPartNo;

    @ApiModelProperty(value = "报关单号")
    @ExcelProperty(value = "报关单号")
    private String cusNo ;

    @ApiModelProperty(value = "报关项次")
    @ExcelProperty(value = "报关项次")
    private String cusItem ;

    @ApiModelProperty(value = "报关单价")
    @ExcelProperty(value = "报关单价")
    BigDecimal cusPrice;

    @ApiModelProperty(value = "单位净重")
    @ExcelProperty(value = "单位净重")
    BigDecimal cusWeightUne;

    @ApiModelProperty(value = "该项次净重 （cus_weight_une * 数量）")
    @ExcelProperty(value = "该项次净重")
    BigDecimal cusWeight;

    @ApiModelProperty(value = "中文品名")
    @ExcelProperty(value = "中文品名")
    String cusGoodName;

    @ApiModelProperty(value = "商品编码")
    @ExcelProperty(value = "商品编码")
    String cusGoodNo;

    @ApiModelProperty(value = "包装方式")
    @ExcelProperty(value = "包装方式")
    private String packingMethod;

    @ApiModelProperty(value = "CUS申报要素")
    @ExcelProperty(value = "申报要素")
    private String cusSpec;

    @ApiModelProperty(value = "CUS申报要素")
    @ExcelProperty(value = "ECCN#")
    private String eccnNo;

    @ApiModelProperty(value = "运输方式")
    @ExcelProperty(value = "运输方式")
    private String transportMode;

    @ApiModelProperty(value = "保税性质")
    @ExcelProperty(value = "保税性质")
    private String bondedTypeName;

    @ApiModelProperty(value = "是否成品")
    @ExcelProperty(value = "是否成品")
    private String productFlagName;

    @ApiModelProperty(value = "单据序列号")
    @ExcelProperty(value = "单据序列号")
    private String serialNo;
}
