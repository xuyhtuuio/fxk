package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("工单作业任务前加工区DTO")
@Data
public class GetPickTaskExportPreDTO {
    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "工单")
    @ExcelProperty(value = "工单")
    private String workOrderNo;

    @ApiModelProperty(value = "线别")
    @ExcelProperty(value = "线别")
    private String lineNo;

    @ApiModelProperty(value = "机种")
    @ExcelProperty(value = "机种")
    private String partNo;

    @ApiModelProperty(value = "APS计划时间")
    @ExcelProperty(value = "APS计划时间", converter = LocalDateTimeStringConverter.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime apsWoBeginDatetime;

    @ApiModelProperty(value = "物料拆分")
    @ExcelProperty(value = {"前加工任务", "物料拆分"})
    private Integer taskDividePkg;

    @ApiModelProperty(value = "烧录")
    @ExcelProperty(value = {"前加工任务", "烧录"})
    private Integer taskSmtBurn;

    @ApiModelProperty(value = "合盘")
    @ExcelProperty(value = {"前加工任务", "合盘"})
    private Integer taskSmtMarg;

    @ApiModelProperty(value = "剪脚")
    @ExcelProperty(value = {"前加工任务", "剪脚"})
    private Integer taskCutCorner;
}
