package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.maxnerva.cloudmes.config.LocalDateStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.time.LocalDate;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("ECCN导出dto")
@Data
public class EccnMaterialInfoExportDTO {
    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "鸿海料号")
    @ExcelProperty(value = "鸿海料号")
    private String materialNo;

    @ExcelProperty(value = "制造商料号")
    @ApiModelProperty("制造商料号")
    private String mfgPartNo;

    @ExcelProperty(value = "料号描述")
    @ApiModelProperty("料号描述")
    private String mfgPartDesc;

    @ExcelProperty(value = "制造商名称")
    @ApiModelProperty("制造商名称")
    private String mfgName;

    @ExcelProperty(value = "eccnNo")
    private String eccnNo;

    @ExcelProperty(value = "是否管控")
    private String hasControl;

    @ExcelProperty(value = "eccnNo来源")
    @ApiModelProperty("来源")
    private String eccnFrom;

    @ExcelProperty(value = "licenceNo")
    @ApiModelProperty("licence号")
    private String licenceNo;

    @ExcelProperty(value = "licence描述")
    @ApiModelProperty("licence描述")
    private String licenceDesc;

    @ExcelProperty(value = "licence来源")
    @ApiModelProperty("linence来源")
    private String linenceFrom;

    @ExcelProperty(value = "licence开始时间", converter = LocalDateStringConverter.class)
    @ApiModelProperty("开始时间")
    private LocalDate licenceBeginDt;

    @ExcelProperty(value = "licence结束时间", converter = LocalDateStringConverter.class)
    @ApiModelProperty("结束时间")
    private LocalDate licenceEndDt;

    @ExcelProperty(value = "许可证签发国")
    @ApiModelProperty(value = "許可證簽發國")
    private String licenseSignCountry;

    @ExcelProperty(value = "备注")
    @ApiModelProperty("备注")
    private String remark;
}
