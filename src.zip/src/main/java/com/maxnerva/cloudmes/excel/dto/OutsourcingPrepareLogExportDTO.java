package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateStringConverter;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @ClassName OutsourcingPrepareLogExportDTO
 * @Description 委外备料清单报表导出DTO
 * @Author Likun
 * @Date 2023/12/4
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("委外备料清单报表导出DTO")
@Data
public class OutsourcingPrepareLogExportDTO {

    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂", index = 0)
    private String plantCode;

    @ApiModelProperty(value = "PO号")
    @ExcelProperty(value = "PO号", index = 1)
    private String poNo;

    @ApiModelProperty(value = "PO群组")
    @ExcelProperty(value = "PO群组", index = 2)
    private String poItem;

    @ApiModelProperty(value = "PKGID")
    @ExcelProperty(value = "PKGID", index = 3)
    private String pkgId;

    @ApiModelProperty(value = "父pkg")
    @ExcelProperty(value = "父pkg", index = 4)
    private String parentPkgId;

    @ApiModelProperty(value = "鸿海料号")
    @ExcelProperty(value = "鸿海料号", index = 5)
    private String partNo;

    @ApiModelProperty(value = "版次")
    @ExcelProperty(value = "版次", index = 6)
    private String partVersion;

    @ApiModelProperty(value = "仓码")
    @ExcelProperty(value = "仓码", index = 7)
    private String sapWarehouseCode;

    @ApiModelProperty(value = "备料量")
    @ExcelProperty(value = "备料量", index = 8)
    private BigDecimal currentQty;

    @ApiModelProperty(value = "退料量")
    @ExcelProperty(value = "退料量", index = 9)
    private BigDecimal returnQty;

    @ApiModelProperty(value = "D/C")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @ExcelProperty(value = "D/C", index = 10, converter = LocalDateStringConverter.class)
    private LocalDate dateCode;

    @ApiModelProperty(value = "原始datecode")
    @ExcelProperty(value = "原始D/C", index = 11)
    private String originalDateCode;

    @ApiModelProperty(value = "批次号")
    @ExcelProperty(value = "批次号", index = 12)
    private String lotCode;

    @ApiModelProperty(value = "上架时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "上架时间", index = 13, converter = LocalDateTimeStringConverter.class)
    private LocalDateTime shelfDate;

    @ApiModelProperty(value = "异动类型")
    @ExcelProperty(value = "异动类型", index = 14)
    private String transactionType;

    @ApiModelProperty(value = "异动类型描述")
    @ExcelProperty(value = "异动类型描述", index = 15)
    private String transactionMessage;

    @ApiModelProperty(value = "有效日期")
    @ExcelProperty(value = "有效日期", index = 16)
    private Integer effectiveDate;

    @ApiModelProperty(value = "有效期截止时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @ExcelProperty(value = "有效期截止时间", index = 17, converter = LocalDateStringConverter.class)
    private LocalDate endDate;

    @ApiModelProperty(value = "扫描人")
    @ExcelProperty(value = "扫描人", index = 18)
    private String creator;

    @ApiModelProperty(value = "扫描时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "扫描时间", index = 19, converter = LocalDateTimeStringConverter.class)
    private LocalDateTime createdDt;
}
