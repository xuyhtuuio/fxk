package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;

/**
 * @author MFQ
 * @date 2023/11/17 上午 10:36
 */
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("CKD CUS 报表导出DTO")
@Data
public class CkdCusExportDTO {

    @ApiModelProperty(value = "申报时间")
    @ExcelProperty(value = "申报时间", index = 0, converter = LocalDateStringConverter.class)
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate date;

    @ApiModelProperty(value = "鸿海料号")
    @ExcelProperty(value = "鸿海料号", index = 1)
    private String hhPn;

    @ApiModelProperty(value = "报关单号")
    @ExcelProperty(value = "报关单号", index = 2)
    private String cusNo;

    @ApiModelProperty(value = "报关项次")
    @ExcelProperty(value = "报关项次", index = 3)
    private String cusItem;

    @ApiModelProperty(value = "报关单价")
    @ExcelProperty(value = "报关单价", index = 4)
    private BigDecimal price;

    @ApiModelProperty(value = "数量")
    @ExcelProperty(value = "数量", index = 5)
    private BigDecimal qty;

    @ApiModelProperty(value = "原产国")
    @ExcelProperty(value = "原产国", index = 6)
    private String coo;

    @ApiModelProperty(value = "申报要素")
    @ExcelProperty(value = "申报要素", index = 7)
    private String spec;

    @ApiModelProperty(value = "预报关单号")
    @ExcelProperty(value = "预报关单号", index = 8)
    private String cutNo;

    @ApiModelProperty(value = "预报关项次")
    @ExcelProperty(value = "预报关项次", index = 9)
    private String cusUne;

    @ApiModelProperty(value = "来源单号")
    @ExcelProperty(value = "来源单号", index = 10)
    private String po;

    @ApiModelProperty(value = "来源项次")
    @ExcelProperty(value = "来源项次", index = 11)
    private String poItem;

    @ApiModelProperty(value = "创建人")
    @ExcelProperty(value = "创建人", index = 12)
    private String creator;

}
