package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * @ClassName FirstMaterialDetailExportDTO
 * @Description 首套料详情导出DTO
 * @Author Likun
 * @Date 2023/1/2
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("首套料详情导出DTO")
@Data
public class FirstMaterialDetailExportDTO {

    @ApiModelProperty(value = "pkgId")
    @ExcelProperty(value = "pkgId", index = 0)
    private String pkgId;

    @ApiModelProperty(value = "仓码")
    @ExcelProperty(value = "仓码", index = 1)
    private String sapWarehouseCode;

    @ApiModelProperty(value = "储位编码")
    @ExcelProperty(value = "储位编码", index = 2)
    private String binCode;

    @ApiModelProperty(value = "鸿海料号")
    @ExcelProperty(value = "鸿海料号", index = 3)
    private String partNo;

    @ApiModelProperty(value = "数量")
    @ExcelProperty(value = "数量", index = 4)
    private BigDecimal currentQty;

    @ApiModelProperty(value = "制造商料号")
    @ExcelProperty(value = "制造商料号", index = 5)
    private String mfgPartNo;

    @ApiModelProperty(value = "制造商名称")
    @ExcelProperty(value = "制造商名称", index = 6)
    private String mfgName;

    @ApiModelProperty(value = "解析datecode")
    @ExcelProperty(value = "D/C", index = 7, converter = LocalDateStringConverter.class)
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate dateCode;

    @ApiModelProperty(value = "批次号")
    @ExcelProperty(value = "批次号", index = 8)
    private String lotNo;

    @ApiModelProperty(value = "载具编码")
    @ExcelProperty(value = "载具编码", index = 9)
    private String vehicleCode;

    @ApiModelProperty(value = "工单绑定位置")
    @ExcelProperty(value = "工单绑定位置", index = 10)
    private String workOrderToLocation;

    @ApiModelProperty(value = "上料表工单群组")
    @ExcelProperty(value = "上料表工单群组", index = 11)
    private String feederWorkOrderItem;

    @ApiModelProperty(value = "机台编号")
    @ExcelProperty(value = "机台编号", index = 12)
    private String machineCode;

    @ApiModelProperty(value = "feeder号,轨道号")
    @ExcelProperty(value = "轨道号", index = 13)
    private String feederNo;
}
