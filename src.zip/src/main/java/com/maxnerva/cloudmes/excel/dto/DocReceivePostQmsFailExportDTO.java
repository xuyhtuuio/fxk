package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("抛QMS异常邮件通知DTO")
@Data
public class DocReceivePostQmsFailExportDTO {
    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "WMS单号")
    @ExcelProperty(value = "WMS单号")
    private String docNo;

    @ApiModelProperty(value = "PO/ASN")
    @ExcelProperty(value = "PO/ASN")
    private String checkDocNo;

    @ApiModelProperty(value = "单据类型名称")
    @ExcelProperty(value = "单据类型")
    private String docTypeName;

    @ApiModelProperty(value = "鸿海料号")
    @ExcelProperty(value = "料号")
    private String partNo;

    @ApiModelProperty(value = "版次")
    @ExcelProperty(value = "版次")
    private String partNoVersion;

    @ApiModelProperty(value = "数量")
    @ExcelProperty(value = "数量")
    private BigDecimal docQty;

    @ApiModelProperty(value = "Vendor")
    @ExcelProperty(value = "Vendor")
    private String vendorCode;

    @ApiModelProperty(value = "抛Q信息")
    @ExcelProperty(value = "抛转QMS失败异常信息")
    private String toQmsMessage;

    @ApiModelProperty(value = "抛转QMS时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "抛转QMS时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime toQmsDate;

    @ApiModelProperty(value = "首次抛转QMS时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "首次调用协作云时间", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime toQmsFirstDate;

    @ApiModelProperty(value = "po编码")
    @ExcelProperty(value = "PO")
    private String poNo;

    @ApiModelProperty(value = "po项次")
    @ExcelProperty(value = "PO项次")
    private String poItem;

    @ApiModelProperty(value = "来源单号")
    @ExcelProperty(value = "来源单号")
    private String fromDocNo;

    @ApiModelProperty(value = "来源单项次")
    @ExcelProperty(value = "来源项次")
    private String fromDocItem;

    @ApiModelProperty(value = "GR单号")
    @ExcelProperty(value = "GR单号")
    private String sapReturnNumber;

    @ApiModelProperty(value = "sap仓码")
    @ExcelProperty(value = "仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "确认收货日期")
    @ExcelProperty(value = "收货日期", converter = LocalDateTimeStringConverter.class)
    private LocalDateTime confirmDocDate;

    @ApiModelProperty("协作云放行单号")
    @ExcelProperty(value = "协作云放行单号")
    private String scReleaseNo;

    @ApiModelProperty("协作云放行原因")
    @ExcelProperty(value = "协作云放行原因")
    private String scReleaseReason;

    @ApiModelProperty("放行单填写未抛QMS原因")
    @ExcelProperty(value = "放行单填写未抛QMS原因")
    private String scImpoundReason;
}
