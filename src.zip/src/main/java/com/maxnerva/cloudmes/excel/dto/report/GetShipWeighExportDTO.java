package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.maxnerva.cloudmes.config.LocalDateStringConverter;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.time.LocalDate;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("出货称重信息DTO")
@Data
public class GetShipWeighExportDTO {
    @ApiModelProperty(value = "BU")
    @ExcelProperty(value = "BU")
    private String orgCode;

    @ApiModelProperty(value = "SAP工厂")
    @ExcelProperty(value = "SAP工厂")
    private String sapPlantCode;

    @ApiModelProperty(value = "出库单号")
    @ExcelProperty(value = "出库单号")
    private String docNo;

    @ApiModelProperty(value = "DN单号")
    @ExcelProperty(value = "DN单号")
    private String dnNo;

    @ApiModelProperty(value = "鸿海料号")
    @ExcelProperty(value = "鸿海料号")
    private String partNo;

    @ApiModelProperty(value = "仓码")
    @ExcelProperty(value = "仓码")
    private String sapWarehouseCode;

    @ApiModelProperty(value = "出貨地")
    @ExcelProperty(value = "出貨地")
    private String siteCode;

    @ApiModelProperty(value = "栈板号")
    @ExcelProperty(value = "栈板号")
    private String palletNo;

    @ApiModelProperty(value = "重量")
    @ExcelProperty(value = "重量")
    private String weight;

    @ApiModelProperty(value = "毛重上限值（KG）")
    @ExcelProperty(value = "毛重上限值（KG）")
    private String uslKg;

    @ApiModelProperty(value = "毛重下限值（KG）")
    @ExcelProperty(value = "毛重下限值（KG）")
    private String lslKg;

    @ApiModelProperty(value = "单位")
    @ExcelProperty(value = "单位")
    private String uomCode;

    @ApiModelProperty(value = "车牌号")
    @ExcelProperty(value = "车牌号")
    private String licenseNo;

    @ApiModelProperty(value = "货柜号")
    @ExcelProperty(value = "货柜号")
    private String containerNo;

    @ApiModelProperty(value = "计划出货时间")
    @ExcelProperty(value = "计划出货时间", converter = LocalDateStringConverter.class)
    private LocalDate planShipTime;
}
