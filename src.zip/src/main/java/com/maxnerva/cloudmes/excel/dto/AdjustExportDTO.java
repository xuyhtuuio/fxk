package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;


@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("料调单导出DTO")
@Data
public class AdjustExportDTO {


    @ApiModelProperty(value = "单号")
    @ExcelProperty(value = "单号", index = 0)
    private String docNo;

    @ApiModelProperty(value = "申请数量")
    @ExcelProperty(value = "申请数量", index = 1)
    private BigDecimal applyQty;

    @ApiModelProperty(value = "完成数量")
    @ExcelProperty(value = "完成数量", index = 2)
    private BigDecimal completeQty;

    @ApiModelProperty(value = "单位")
    @ExcelProperty(value = "单位", index = 3)
    private String uom;

    @ApiModelProperty(value = "SAP工厂")
    @ExcelProperty(value = "工厂", index = 4)
    private String oldPlantCode;

    @ApiModelProperty(value = "原仓码")
    @ExcelProperty(value = "原仓码", index = 5)
    private String oldWarehoseCode;

    @ApiModelProperty(value = "原鸿海料号")
    @ExcelProperty(value = "原鸿海料号", index = 6)
    private String oldMaterialCode;

    @ApiModelProperty(value = "原制造商料号")
    @ExcelProperty(value = "原供应商料号", index = 7)
    private String oldMfgMaterial;

    @ApiModelProperty(value = "目的仓码")
    @ExcelProperty(value = "目的仓码", index = 8)
    private String targetWarehoseCode;

    @ApiModelProperty(value = "目的鸿海料号")
    @ExcelProperty(value = "目的鸿海料号", index = 9)
    private String targetMaterialCode;

    @ApiModelProperty(value = "目的供应商料号")
    @ExcelProperty(value = "目的供应商料号", index = 10)
    private String targetMfgMaterial;

    @ApiModelProperty(value = "原制造商")
    @ExcelProperty(value = "原制造商", index = 11)
    private String oldMfgName;

    @ApiModelProperty(value = "目的制造商")
    @ExcelProperty(value = "目的制造商", index = 12)
    private String targetMfgName;

    @ApiModelProperty(value = "状态")
    @ExcelProperty(value = "单据状态", index = 13)
    private String identifyName;

    @ApiModelProperty(value = "日期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "日期", index = 14, converter = LocalDateTimeStringConverter.class)
    private LocalDateTime date;

    @ApiModelProperty(value = "是否上传")
    @ExcelProperty(value = "上传SAP", index = 15)
    private String isUploadName;

    @ApiModelProperty(value = "SAP返回单号")
    @ExcelProperty(value = "SAP返回单号", index = 16)
    private String sapReturnNumber;

    @ApiModelProperty(value = "SAP返回信息")
    @ExcelProperty(value = "SAP返回信息", index = 17)
    private String sapReturnMessage;

    @ApiModelProperty(value = "上传SAP时间")
    @ExcelProperty(value = "上传SAP时间", index = 18)
    private String sapUploadData;

    @ApiModelProperty(value = "开立人")
    @ExcelProperty(value = "开立人", index = 19)
    private String creator;

    @ApiModelProperty(value = "原因")
    @ExcelProperty(value = "备注", index = 20)
    private String reason;
}
