package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.time.LocalDateTime;

/**
 * @ClassName ReceiveSnListExportDTO
 * @Description TODO
 * @Author Likun
 * @Date 2024/9/3
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel(value = "收货SN清单导出DTO")
@Data
public class ReceiveSnListExportDTO {

    @ApiModelProperty(value = "单据号(系统根据规则自动生成)")
    @ExcelProperty(value = "收货单号", index = 0)
    private String docNo;

    @ApiModelProperty(value = "鸿海料号")
    @ExcelProperty(value = "鸿海料号", index = 1)
    private String partNo;

    @ApiModelProperty(value = "po编码")
    @ExcelProperty(value = "PO", index = 2)
    private String poNo;

    @ApiModelProperty(value = "po项次")
    @ExcelProperty(value = "PO项次", index = 3)
    private String poItem;

    @ApiModelProperty(value = "收货时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "收货时间", index = 4)
    private String confirmDocDate;

    @ApiModelProperty(value = "来源单号")
    @ExcelProperty(value = "来源单号", index = 5)
    private String fromDocNo;

    @ApiModelProperty(value = "来源项次")
    @ExcelProperty(value = "来源单项次", index = 6)
    private String fromDocItem;

    @ApiModelProperty(value = "sn")
    @ExcelProperty(value = "SN", index = 7)
    private String snNo;

    @ApiModelProperty(value = "料号")
    @ExcelProperty(value = "客户料号", index = 8)
    private String partNumber;

    @ApiModelProperty(value = "版次")
    @ExcelProperty(value = "版次", index = 9)
    private String partRev;

    @ApiModelProperty(value = "厂商")
    @ExcelProperty(value = "厂商", index = 10)
    private String vendor;

    @ApiModelProperty(value = "厂商料号")
    @ExcelProperty(value = "厂商料号", index = 11)
    private String vendorPn;

    @ApiModelProperty(value = "是否抛给MES")
    @ExcelProperty(value = "是否抛给MES", index = 12)
    private String postMesFlag;

    @ApiModelProperty(value = "抛MES时间")
    @ExcelProperty(value = "抛MES时间", index = 13, converter = LocalDateTimeStringConverter.class)
    private LocalDateTime postMesDt;

    @ApiModelProperty(value = "创建人")
    @ExcelProperty(value = "创建人", index = 14)
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "创建时间")
    @ExcelProperty(value = "创建时间", index = 15, converter = LocalDateTimeStringConverter.class)
    private LocalDateTime createdDt;

    @ApiModelProperty("INVOICE NO")
    @ExcelProperty(value = "INVOICE NO", index = 16)
    private String invoiceNo;
}
