package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;


@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("在库差异报表导出DTO")
@Data
public class DifferentInstockExportDTO {

    @ApiModelProperty(value = "基础数据来源")
    @ExcelProperty(value = "基础数据来源", index = 0)
    private String type;

    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂", index = 1)
    private String plantCode;

    @ApiModelProperty(value = "料号")
    @ExcelProperty(value = "料号", index = 2)
    private String partNo;

    @ApiModelProperty(value = "仓码")
    @ExcelProperty(value = "仓码", index = 3)
    private String sapWarehouseCode;

    @ApiModelProperty(value = "WMS库存")
    @ExcelProperty(value = "WMS库存", index = 4)
    private BigDecimal wmsStockQty;

    @ApiModelProperty(value = "WMS待上架数量")
    @ExcelProperty(value = "WMS待上架数量", index = 5)
    private BigDecimal wmsNoShelfQty;

    @ApiModelProperty(value = "SAP良品数量")
    @ExcelProperty(value = "SAP良品数量", index = 6)
    private BigDecimal sapGoodProductsQty;

    @ApiModelProperty(value = "SAP待验数量")
    @ExcelProperty(value = "SAP待验数量", index = 7)
    private BigDecimal sapInspectedQty;

    @ApiModelProperty(value = "SAP冻结数量")
    @ExcelProperty(value = "SAP冻结数量", index = 8)
    private BigDecimal sapBlockQty;

    @ApiModelProperty(value = "SAP库存")
    @ExcelProperty(value = "SAP库存", index = 9)
    private BigDecimal sapStockQty;

    @ApiModelProperty(value = "SAP待入账数量")
    @ExcelProperty(value = "SAP待入账数量", index = 10)
    private BigDecimal sapNoInQty;

    @ApiModelProperty(value = "SAP待出账数量")
    @ExcelProperty(value = "SAP待出账数量", index = 11)
    private BigDecimal sapNoOutQty;

    @ApiModelProperty(value = "单价")
    @ExcelProperty(value = "库存差异（WMS-SAP）", index = 12)
    private BigDecimal differentQty;

    @ApiModelProperty(value = "special")
    @ExcelProperty(value = "special", index = 13)
    private String special;

    @ApiModelProperty(value = "vendor")
    @ExcelProperty(value = "vendor", index = 14)
    private String vendor;

    @ApiModelProperty(value = "仓码描述")
    @ExcelProperty(value = "仓码描述", index = 15)
    private String sapWarehouseName;

    @ApiModelProperty(value = "责任部门")
    @ExcelProperty(value = "责任部门", index = 16)
    private String ownerDept;




}
