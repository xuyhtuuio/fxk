package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

/**
 * @ClassName DocReceiveMailExportDTO
 * @Description TODO
 * @Author Likun
 * @Date 2024/9/3
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("收货单未上传SN导出dto")
@Data
public class DocReceiveMailExportDTO {

    @ApiModelProperty("来源单号")
    @ExcelProperty(value = "来源单号",index = 0)
    private String fromDocNo;

    @ApiModelProperty("来源单号项次")
    @ExcelProperty(value = "来源单号项次",index = 1)
    private String fromDocItem;

    @ApiModelProperty("收货单号")
    @ExcelProperty(value = "收货单号",index = 2)
    private String docNo;

    @ApiModelProperty("料号")
    @ExcelProperty(value = "料号",index = 3)
    private String partNo;

    @ApiModelProperty("poNo")
    @ExcelProperty(value = "PO",index = 4)
    private String poNo;

    @ApiModelProperty("poItem")
    @ExcelProperty(value = "PO ITEM",index = 5)
    private String poItem;

    @ApiModelProperty("invoiceNo")
    @ExcelProperty(value = "INVOICE NO",index = 6)
    private String invoiceNo;

    @ApiModelProperty("是否上传SN")
    @ExcelProperty(value = "是否上传SN",index = 7)
    private String uploadSnFlag;
}
