package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.time.LocalDateTime;

/**
 * @ClassName AssyLocationConfigExportDTO
 * @Description TODO
 * @Author Likun
 * @Date 2024/4/30
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("上料表信息导出DTO")
@Data
public class AssyLocationConfigExportDTO {

    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂", index = 0)
    private String plantCode;

    @ApiModelProperty(value = "线别")
    @ExcelProperty(value = "线别", index = 1)
    private String lineNo;

    @ApiModelProperty(value = "成品料号")
    @ExcelProperty(value = "成品料号", index = 2)
    private String productPartNo;

    @ApiModelProperty(value = "成品料号版次")
    @ExcelProperty(value = "成品料号版次", index = 3)
    private String productPartVersion;

    @ApiModelProperty(value = "零件料号")
    @ExcelProperty(value = "零件料号", index = 4)
    private String sparePartNo;

    @ApiModelProperty(value = "零件料号版次")
    @ExcelProperty(value = "零件料号版次", index = 5)
    private String sparePartVersion;

    @ApiModelProperty(value = "位置")
    @ExcelProperty(value = "位置", index = 6)
    private String lineCategory;

    @ApiModelProperty(value = "创建人")
    @ExcelProperty(value = "创建人", index = 7)
    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "创建时间")
    @ExcelProperty(value = "创建时间", index = 8, converter = LocalDateTimeStringConverter.class)
    private LocalDateTime createdDt;

    @ApiModelProperty(value = "修改人")
    @ExcelProperty(value = "修改人", index = 9)
    private String lastEditor;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "修改时间")
    @ExcelProperty(value = "修改时间", index = 10, converter = LocalDateTimeStringConverter.class)
    private LocalDateTime lastEditedDt;
}
