package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("工单作业任务作业区DTO")
@Data
public class GetPickTaskExportWorkDTO {
    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    private String plantCode;

    @ApiModelProperty(value = "工单")
    @ExcelProperty(value = "工单")
    private String workOrderNo;

    @ApiModelProperty(value = "线别")
    @ExcelProperty(value = "线别")
    private String lineNo;

    @ApiModelProperty(value = "机种")
    @ExcelProperty(value = "机种")
    private String partNo;

    @ApiModelProperty(value = "APS计划时间")
    @ExcelProperty(value = "APS计划时间", converter = LocalDateTimeStringConverter.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime apsWoBeginDatetime;

    @ApiModelProperty(value = "分轨SMT")
    @ExcelProperty(value = {"作业任务", "分轨SMT"})
    private Integer onVehicleSmtNum;

    @ApiModelProperty(value = "分轨SMT（总）")
    @ExcelProperty(value = {"作业任务", "分轨SMT（总）"})
    private Integer onVehicleSmtTotalNum;

    @ApiModelProperty(value = "分轨道")
    @ExcelProperty(value = {"作业任务", "分轨道"})
    private Integer taskDividePartNo;

    @ApiModelProperty(value = "待回大仓")
    @ExcelProperty(value = {"作业任务", "待回大仓"})
    private Integer pickReturn;

    @ApiModelProperty("上料车-非ASSY")
    @ExcelProperty(value = {"作业任务", "上料车-非ASSY"})
    private Integer pickOnlineNoAssy;

    @ApiModelProperty(value = "上料车-ASSY")
    @ExcelProperty(value = {"作业任务", "上料车-ASSY"})
    private Integer pickOnlineAssy;

    @ApiModelProperty(value = "前加工")
    @ExcelProperty(value = {"作业任务", "前加工"})
    private Integer preWorkTotalNum;
}
