package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.time.LocalDateTime;
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("CKD 出货地址报表导出DTO")
@Data
public class CkdShipAddressExportDTO {
    @ApiModelProperty("出货地址")
    @ExcelProperty(value = "出货地址")
    private String shipAddress;

    @ApiModelProperty("目的地国家")
    @ExcelProperty(value = "目的地国家")
    private String shipCompany;

    @ExcelProperty(value = "C/O")
    private String co;

    @ApiModelProperty("收货详细地址")
    @ExcelProperty(value = "收货详细地址")
    private String shipAddressDetail;

    @ExcelProperty(value = "shipTerm")
    private String shipTerm;

    @ApiModelProperty("退运方式")
    @ExcelProperty(value = "退运方式")
    private String returnTransportMethod;

    @ApiModelProperty("费用单位")
    @ExcelProperty(value = "费用单位")
    private String costOffice;

    @ApiModelProperty("退货处理方式")
    @ExcelProperty(value = "退货处理方式")
    private String returnGoodsMethod;

    @ApiModelProperty("退运时间")
    @ExcelProperty(value = "退运时间")
    private String returnTransportDt;

    @ApiModelProperty("目的地")
    @ExcelProperty(value = "目的地")
    private String destination;

    @ApiModelProperty("收货人")
    @ExcelProperty(value = "收货人")
    private String receiver;

    @ApiModelProperty("联系方式")
    @ExcelProperty(value = "联系方式")
    private String tel;

    @ExcelProperty(value = "fax")
    private String fax;

    @ApiModelProperty("费用代码")
    @ExcelProperty(value = "费用代码")
    private String costCode;

    @ApiModelProperty("出货部门")
    @ExcelProperty(value = "出货部门")
    private String dept;

    @ExcelProperty(value = "soldToParty")
    private String soldToParty;

    @ExcelProperty(value = "shipToParty")
    private String shipToParty;

    @ExcelProperty(value = "工单")
    private String workOrderNo;

    @ExcelProperty(value = "工厂")
    private String plantCode;

    @ExcelProperty(value = "关单仓码")
    private String warehouseCode;

    @ApiModelProperty("订单类型")
    @ExcelProperty(value = "订单类型")
    private String docType;

    @ApiModelProperty("配销通路")
    @ExcelProperty(value = "配销通路")
    private String distributionChannel;

    @ApiModelProperty("出货目的地")
    @ExcelProperty(value = "出货目的地")
    private String siteCode;
}
