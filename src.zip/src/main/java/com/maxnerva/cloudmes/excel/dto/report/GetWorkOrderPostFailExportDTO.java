package com.maxnerva.cloudmes.excel.dto.report;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, wrapped = false)
@HeadRowHeight(value = 20)
@HeadFontStyle(fontHeightInPoints = 12)
@ContentRowHeight(value = 20)
@ApiModel("工单过账失败DTO")
@Data
public class GetWorkOrderPostFailExportDTO {
    @ApiModelProperty(value = "工厂")
    @ExcelProperty(value = "工厂")
    String plantCode;


    @ApiModelProperty(value = "工单")
    @ExcelProperty(value = "工单")
    String workOrderNo;


    @ApiModelProperty(value = "群组")
    @ExcelProperty(value = "群组")
    String workOrderItem;

    @ApiModelProperty(value = "工单状态")
    @ExcelProperty(value = "工单状态")
    private String workOrderStatus;

    @ApiModelProperty(value = "料号")
    @ExcelProperty(value = "料号")
    String partNo;


    @ApiModelProperty(value = "过账仓码")
    @ExcelProperty(value = "过账仓码")
    String fromWarehouseCode;


    @ApiModelProperty(value = "待过账量")
    @ExcelProperty(value = "待过账量")
    BigDecimal postSapQty;


    @ApiModelProperty(value = "过账类型")
    @ExcelProperty(value = "过账类型")
    String postType;


    @ApiModelProperty(value = "过账信息")
    @ExcelProperty(value = "过账信息")
    String postSapMsg;


    @ApiModelProperty(value = "过账时间")
    @ExcelProperty(value = "过账时间", converter = LocalDateTimeStringConverter.class)
    LocalDateTime postSapDt;
}
