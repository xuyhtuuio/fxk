package com.maxnerva.cloudmes.excel.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.maxnerva.cloudmes.config.LocalDateStringConverter;
import com.maxnerva.cloudmes.config.LocalDateTimeStringConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.poi.ss.usermodel.FillPatternType;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @ClassName DocReceiveExportDTO
 * @Description 收货单导出dto
 * @Author Likun
 * @Date 2023/9/21
 * @Version 1.0
 * @Since JDK 1.8
 **/
@HeadStyle(fillPatternType = FillPatternType.SOLID_FOREGROUND, fillForegroundColor = 57)
@HeadRowHeight(value = 20)
@ContentRowHeight(value = 20)
@ColumnWidth(25)
@ApiModel("收货单导出dto")
@Data
public class DocReceiveExportDTO {

    @ApiModelProperty(value = "单据号(系统根据规则自动生成)")
    @ExcelProperty(value = "收货单号", index = 0)
    private String docNo;

    @ApiModelProperty(value = "鸿海料号")
    @ExcelProperty(value = "鸿海料号", index = 1)
    private String partNo;

    @ApiModelProperty(value = "上架数量")
    @ExcelProperty(value = "上架数量", index = 2)
    private BigDecimal operateQty;

    @ApiModelProperty(value = "单据数量")
    @ExcelProperty(value = "数量", index = 3)
    private BigDecimal docQty;

    @ApiModelProperty(value = "单位编码")
    @ExcelProperty(value = "单位", index = 4)
    private String uomCode;

    @ApiModelProperty(value = "制造商名称")
    @ExcelProperty(value = "制造商编码", index = 5)
    private String mfgName;

    @ApiModelProperty(value = "制造商料号")
    @ExcelProperty(value = "制造商料号", index = 6)
    private String mfgPartNo;

    @ApiModelProperty(value = "sap工厂")
    @ExcelProperty(value = "工厂", index = 7)
    private String plantCode;

    @ApiModelProperty(value = "sap仓码")
    @ExcelProperty(value = "仓码", index = 8)
    private String sapWarehouseCode;

    @ApiModelProperty(value = "单据接收日期")
    @ExcelProperty(value = "单据日期", index = 9, converter = LocalDateTimeStringConverter.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime docCreateDate;

    @ApiModelProperty(value = "单据类型名称")
    @ExcelProperty(value = "单据类型", index = 10)
    private String docTypeName;

    @ApiModelProperty(value = "单据状态名称")
    @ExcelProperty(value = "单据状态", index = 11)
    private String docStatusName;

    @ApiModelProperty(value = "来源单号")
    @ExcelProperty(value = "来源单号", index = 12)
    private String fromDocNo;

    @ApiModelProperty(value = "来源单项次")
    @ExcelProperty(value = "来源项次", index = 13)
    private String fromDocItem;

    @ApiModelProperty(value = "po编码")
    @ExcelProperty(value = "po", index = 14)
    private String poNo;

    @ApiModelProperty(value = "po项次")
    @ExcelProperty(value = "po项次", index = 15)
    private String poItem;

    @ApiModelProperty(value = "采购单号文件类型")
    @ExcelProperty(value = "po类型", index = 16)
    private String poDocumentType;

    @ApiModelProperty(value = "原产国1")
    @ExcelProperty(value = "原产国1", index = 17)
    private String placeOfOrigin1;

    @ApiModelProperty(value = "原产国2")
    @ExcelProperty(value = "原产国2", index = 18)
    private String placeOfOrigin2;

    @ApiModelProperty(value = "起运国")
    @ExcelProperty(value = "起运国", index = 19)
    private String shipOfOrigin;

    @ApiModelProperty(value = "创建人")
    @ExcelProperty(value = "创建人", index = 20)
    private String creator;

    @ApiModelProperty(value = "修改人")
    @ExcelProperty(value = "最后编辑人", index = 21)
    private String lastEditor;

    @ApiModelProperty(value = "修改时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = "最后编辑时间", index = 22, converter = LocalDateTimeStringConverter.class)
    private LocalDateTime lastEditedDt;

    @ApiModelProperty(value = "INVOICE NO")
    @ExcelProperty(value = "INVOICE NO", index = 23)
    private String invoiceNo;

    @ApiModelProperty(value = "预计到厂日期")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @ExcelProperty(value = "预计到厂日期", index = 24, converter = LocalDateStringConverter.class)
    private LocalDate eta;
}
