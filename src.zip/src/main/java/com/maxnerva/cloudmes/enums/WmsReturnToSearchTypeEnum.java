package com.maxnerva.cloudmes.enums;
import cn.hutool.core.util.StrUtil;

public enum WmsReturnToSearchTypeEnum {

    ALL("ALL", "所有"),
    RETURN_COMPLETE("RETURN_COMPLETE", "已回大仓"),
    NOT_RETURN("NOT_RETURN", "未回大仓"),
    NOT_BIND("NOT_BIND", "待绑定");

    private String dictCode;

    private String dictName;

    WmsReturnToSearchTypeEnum(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (WmsReturnToSearchTypeEnum commonConstant : values()) {
            if (commonConstant.getDictCode().equals(dictCode)) {
                return commonConstant.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

}