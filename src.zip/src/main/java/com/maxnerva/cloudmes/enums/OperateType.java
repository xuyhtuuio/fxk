package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName OperateType
 * @Description 操作类型
 * @Author Likun
 * @Date 2022/10/7
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum  OperateType {

    /**
     * 操作类型
     */
    ON_SHELF("ON_SHELF","上架"),
    UN_SHELF("UN_SHELF","下架"),
    NULL_SHELF("NULL_SHELF","不操作");

    private String dictCode;

    private String dictName;

    OperateType(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (OperateType operateType : values()) {
            if (operateType.getDictCode().equals(dictCode)) {
                return operateType.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }
}
