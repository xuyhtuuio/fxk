package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName DocCategoryCode
 * @Description 单据大类编码
 * @Author Likun
 * @Date 2022/8/3
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum  DocCategoryCode {

    /**
     * 单据大类编码
     */
    RECEIVE("RECEIVE_DOC","收货单"),
    COST("COST_DOC","费领/退单"),
    ADJUST("ADJUST_DOC","调整单"),
    SCRAP("Scrap","报废单"),
    DELIVER("Deliver","出货单"),
    INTERNAL_DOC("INTERNAL_DOC","内交单"),
    PRODUCT_DELIVERY("PRODUCT_DELIVERY","成品出货单"),
    OTHER_DOC("OTHER_DOC","其他出入库"),
    LOCK_DOC("LOCK_DOC","锁料单");

    private String dictCode;

    private String dictName;

    DocCategoryCode(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (DocCategoryCode docCategoryCode : values()) {
            if (docCategoryCode.getDictCode().equals(dictCode)) {
                return docCategoryCode.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }
}
