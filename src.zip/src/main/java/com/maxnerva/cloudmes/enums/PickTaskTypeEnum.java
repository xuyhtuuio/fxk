package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName PickTaskTypeEnum
 * @Description 捡料记录任务类型枚举
 * @Author Likun
 * @Date 2023/7/25
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum PickTaskTypeEnum {

    /**
     * 捡料记录任务类型
     */
    UN_BURN_PARTITION("UN_BURN_PARTITION", "待烧录分盘"),
    UN_DISTRIBUTE_PARTITION("UN_DISTRIBUTE_PARTITION", "待分料分盘"),
    UN_RETURN_TO_WH("UN_RETURN_TO_WH", "待回大仓"),
    WO_PICK("WO_PICK", "工单捡料"),
    WO_JUSDA_PICK("WO_JUSDA_PICK", "工单准时达捡料"),
    ASSEMBLE_PICK("ASSEMBLE_PICK", "组装捡料"),
    IN_STOCK_PICK("IN_STOCK_PICK", "在库捡料"),
    UN_DISTRIBUTE("UN_DISTRIBUTE", "待分料"),
    IN_STOCK_A_PICK("IN_STOCK_A_PICK", "在库A类物料捡料"),
    IN_STOCK_B_OR_C_PICK("IN_STOCK_B_OR_C_PICK", "在库B,C类物料捡料");

    private String dictCode;

    private String dictName;

    PickTaskTypeEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (PickTaskTypeEnum pickTaskTypeEnum : values()) {
            if (pickTaskTypeEnum.getDictCode().equals(dictCode)) {
                return pickTaskTypeEnum.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

    /**
     * 提前判断，用于解决
     * Case中出现的Constant expression required
     *
     * @param dictCode 值
     * @return pickingTypeEnum
     */
    public static PickTaskTypeEnum getByValue(String dictCode) {
        for (PickTaskTypeEnum pickTaskTypeEnum : values()) {
            if (pickTaskTypeEnum.getDictCode().equals(dictCode)) {
                return pickTaskTypeEnum;
            }
        }
        return null;
    }
}
