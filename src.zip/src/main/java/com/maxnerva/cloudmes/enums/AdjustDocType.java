package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

public enum AdjustDocType {
    /**
     * 调整单单据类型
     */
    ADJUST("ADJUST_PART_DOC", "调整单"),
    ROLL_OVER("ADJUST_TRANSFER_DOC", "转仓单"),

    /**
     * 调整/转仓单单据状态
     * 0：新建；1：待审核；2：已审核；3：审批拒绝；4：处理中；5：完成
     */
    STATUS_CARETE("0","新建"),
    STATUS_TO_CHECK("1","待审核"),
    STATUS_CHECKED("2","已审核"),
    STATUS_REFUSED("3","审批拒绝"),
    STATUS_DOING("4","处理中"),
    STATUS_COMPLETED("5","完成"),
    STATUS_TRANSFERRED("6","已转出");

    private String dictCode;

    private String dictName;

    AdjustDocType(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public void setDictCode(String dictCode) {
        this.dictCode = dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public void setDictName(String dictName) {
        this.dictName = dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (AdjustDocType adjustDocType : values()) {
            if (adjustDocType.getDictCode().equals(dictCode)) {
                return adjustDocType.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }
}
