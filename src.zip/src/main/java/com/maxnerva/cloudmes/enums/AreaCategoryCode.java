package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName AreaCategoryCode
 * @Description 库区类别
 * @Author Likun
 * @Date 2022/9/9
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum AreaCategoryCode {

    /**
     * 库区类别编码
     */
    RAW("RAW_MATERIAL_WH", "物料区"),
    KITTING("WORKSHOP_WH", "待上线区"),
    OPERATION_WH("OPERATION_WH", "作业区"),
    PRE_WORK_WH("PRE_WORK_WH", "前加工区");

    private String dictCode;

    private String dictName;

    AreaCategoryCode(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (AreaCategoryCode areaCategoryCode : values()) {
            if (areaCategoryCode.getDictCode().equals(dictCode)) {
                return areaCategoryCode.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

    /**
     * 提前判断，用于解决
     * Case中出现的Constant expression required
     *
     * @param dictCode 值
     * @return areaCategoryCode
     */
    public static AreaCategoryCode getByValue(String dictCode) {
        for (AreaCategoryCode areaCategoryCode : values()) {
            if (areaCategoryCode.getDictCode().equals(dictCode)) {
                return areaCategoryCode;
            }
        }
        return null;
    }
}
