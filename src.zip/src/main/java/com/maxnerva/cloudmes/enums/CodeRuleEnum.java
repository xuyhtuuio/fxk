package com.maxnerva.cloudmes.enums;

/**
 * @ClassName CodeRuleEnum
 * @Description 编码规则枚举
 * @Author Likun
 * @Date 2022/9/21
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum  CodeRuleEnum {

    /**
     *  编码规则
     */
    WMS_DOC_NO("WMS_DOC_NO","WMS单号"),
    WMS_DOC_RECEIVE_NO("WMS_DOC_RECEIVE_NO","WMS收货单号"),
    WMS_CKD_WORK_ORDER_NO("WMS_CKD_WORK_ORDER_NO","CKD工单号"),
    WMS_MATERIAL_SHORTAGE_NO("WMS_MATERIAL_SHORTAGE_NO","缺料流水号"),
    WMS_DOC_OTHER_INOUT_NO("WMS_DOC_OTHER_INOUT_NO","其它出入库单号"),
    WMS_MERGE_WORK_ORDER_NO("WMS_MERGE_WORK_ORDER_NO","合备工单号"),
    WMS_ASN_UPLOAD_NO("WMS_ASN_UPLOAD_NO","ASN上传JUSDA单号"),
    WMS_INVENTORY_PLAN_NO("WMS_INVENTORY_PLAN_NO","盘点计划编号"),
    WMS_BAD_PRODUCT_DOC_NO("WMS_BAD_PRODUCT_DOC_NO","不良品管理编号"),
    WMS_PICK_TASK_NO("WMS_PICK_TASK_NO","捡料任务编号"),
    WMS_PKG_NO("PKGNO","物料区条码号"),
    WMS_KITTING_PKG_NO("WMS_KITTING_PKG_NO","kitting条码号"),
    WMS_COST_DOC_NO("WMS_COST_DOC_NO","费领退单号"),
    WMS_SCRAP_DOC_NO("WMS_SCRAP_DOC_NO","报废单号"),
    WMS_ADJUST_DOC_NO("WMS_ADJUST_DOC_NO","料调单号"),
    WMS_INNER_DOC_NO("WMS_INNER_DOC_NO","内交单号"),
    WMS_MACHINE_SPLIT_PKG_NO("WMS_MACHINE_SPLIT_PKG_NO","盘点机特殊用户sfc分盘条码号"),
    WMS_JIT_MATERIAL_SHORTAGE_NO("WMS_JIT_MATERIAL_SHORTAGE_NO","JIT缺料流水号"),
    WMS_OUTSOURCING_POSTING_NO("WMS_OUTSOURCING_POSTING_NO","委外备料确认过账流水号"),
    CKD_SHIP_DN_NO("CKD_SHIP_DN_NO", "CKD打包生成DN流水码"),
    WMS_WO_STOCK_VEHICLE("WMS_WO_STOCK_VEHICLE", "工单发料载具"),
    WMS_VENDOR_PKG("WMS_VENDOR_PKG", "CMB-PDA打印条码"),
    WMS_LOT_NO("WMS_LOT_NO", "CMB-PDA打印条码LOT生成规则"),
    WMS_SPLIT_PKG_NO("WMS_SPLIT_PKG_NO", "PKG-32进制32进制拆分规则"),
    WMS_AGV_LIST_TASK_NO("WMS_AGV_LIST_TASK_NO", "WMS AGV任务列表任务单号"),
    WMS_SCRAP_HANDLE_NO("WMS_SCRAP_HANDLE_NO", "报废处理单号"),
    WMS_SCRAP_HANDLE_PALLET_NO("WMS_SCRAP_HANDLE_PALLET_NO", "报废处理栈板号"),
    WMS_SCRAP_CONTACT_DOC_NO("WMS_SCRAP_CONTACT_DOC_NO", "报废处理联络单文号"),
    WMS_PACK_STOCK_DOC_NO("WMS_PACK_STOCK_DOC_NO", "包材发料单号"),
    WMS_PRODUCT_MERGE_PALLET_ID("WMS_PRODUCT_MERGE_PALLET_ID", "成品出货合板打印PALLET_ID"),
    WMS_HPE_SHIPPING_LABEL_PKG_ID("WMS_HPE_SHIPPING_LABEL_PKG_ID", "hpe 合板打印生产pkgId");
    private String dictCode;

    private String dictName;

    CodeRuleEnum(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }
}
