package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName AgvTaskTypeEnum
 * @Description AGV任务类型枚举
 * @Author Likun
 * @Date 2024/5/8
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum AgvTaskTypeEnum {

    WH_AGV("WH_AGV", "仓库内移动物料"),
    ONLINE_AGV("ONLINE_AGV", "备料区移动物料"),
    RETURN_AGV("RETURN_AGV", "余料返仓"),
    STAMP_AGV("STAMP_AGV", "冲压成品移料"),
    SHELF_AGV("SHELF_AGV", "收货移料"),
    SEND_AGV("SEND_AGV", "产线送料"),
    STAMP_AGV2("STAMP_AGV2", "冲压成品移料电梯2"),
    INSTORE_AGV("INSTORE_AGV", "MES采集入库"),
    INSTORE_AGV_SFC("INSTORE_AGV_SFC", "SFC采集入库"),
    PRE_SHIP_AGV("PRE_SHIP_AGV", "成品备货"),
    INSTORE_PRE_SHIP_AGV_SFC("INSTORE_PRE_SHIP_AGV_SFC", "SFC采集备货"),
    INSTORE_PRE_SHIP_AGV("INSTORE_PRE_SHIP_AGV", "采集备货");


    private String dictCode;

    private String dictName;

    AgvTaskTypeEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (AgvTaskTypeEnum agvTaskTypeEnum : values()) {
            if (agvTaskTypeEnum.getDictCode().equals(dictCode)) {
                return agvTaskTypeEnum.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

    /**
     * 提前判断，用于解决
     * Case中出现的Constant expression required
     *
     * @param dictCode 值
     * @return agvTaskTypeEnum
     */
    public static AgvTaskTypeEnum getByValue(String dictCode) {
        for (AgvTaskTypeEnum agvTaskTypeEnum : values()) {
            if (agvTaskTypeEnum.getDictCode().equals(dictCode)) {
                return agvTaskTypeEnum;
            }
        }
        return null;
    }
}
