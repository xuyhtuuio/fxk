package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * 来源类型
 */
public enum SourceType {

    IN("0","自建"),
    OUT("1","外部系统");

    private String dictCode;

    private String dictName;

    SourceType(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public void setDictCode(String dictCode) {
        this.dictCode = dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public void setDictName(String dictName) {
        this.dictName = dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (SourceType sourceType : values()) {
            if (sourceType.getDictCode().equals(dictCode)) {
                return sourceType.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }
}
