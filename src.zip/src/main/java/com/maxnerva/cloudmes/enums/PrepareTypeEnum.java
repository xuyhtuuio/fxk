package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName PrepareTypeEnum
 * @Description 备料类型枚举
 * @Author Likun
 * @Date 2023/9/12
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum PrepareTypeEnum {

    CKD_WO_DIRECT_PREPARE("CKD_WO_DIRECT_PREPARE", "CKD工单直备"),
    JUSDA_CKD_WO_DIRECT_PREPARE("CKD_JUSDA_WO_DIRECT_PREPARE", "JUSDA CKD工单直备"),
    JUSDA_WO_DIRECT_PREPARE("JUSDA_WO_DIRECT_PREPARE", "JUSDA 工单直备");


    private String dictCode;

    private String dictName;

    PrepareTypeEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (PrepareTypeEnum prepareTypeEnum : values()) {
            if (prepareTypeEnum.getDictCode().equals(dictCode)) {
                return prepareTypeEnum.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

    /**
     * 提前判断，用于解决
     * Case中出现的Constant expression required
     *
     * @param dictCode 值
     * @return pickingTypeEnum
     */
    public static PrepareTypeEnum getByValue(String dictCode) {
        for (PrepareTypeEnum prepareTypeEnum : values()) {
            if (prepareTypeEnum.getDictCode().equals(dictCode)) {
                return prepareTypeEnum;
            }
        }
        return null;
    }
}
