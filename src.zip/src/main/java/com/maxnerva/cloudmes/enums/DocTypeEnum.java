package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName DocTypeEnum
 * @Description 单据类型
 * @Author Likun
 * @Date 2023/9/6
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum DocTypeEnum {

    BUY_SELL_RECEIVE_DOC("BUY_SELL_RECEIVE_DOC","Buy-Sell收货单"),
    OUTSOURCING_DOC("OUTSOURCING_DOC","委外收货单"),
    TRADING_PRODUCT_DELIVERY("TRADING_PRODUCT_DELIVERY","内交成品出货单"),
    DN_PRODUCT_DELIVERY("DN_PRODUCT_DELIVERY","DN成品出货单"),
    TRANSFER_RECEIVE_DOC("TRANSFER_RECEIVE_DOC","转仓收货单");

    private final String dictCode;

    private final String dictName;

    DocTypeEnum(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (DocTypeEnum docTypeEnum : values()) {
            if (docTypeEnum.getDictCode().equals(dictCode)) {
                return docTypeEnum.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }
}
