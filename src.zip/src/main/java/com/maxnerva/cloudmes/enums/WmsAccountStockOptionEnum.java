package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

public enum WmsAccountStockOptionEnum {

    SAP_PRE_INTO_ACCOUNT("SAP_PRE_INTO_ACCOUNT", "SAP待入账"),
    SAP_PRE_OUT_ACCOUNT("SAP_PRE_OUT_ACCOUNT", "SAP待出账"),
    WMS_PRE_SHELF("WMS_PRE_SHELF", "WMS待上架"),
    WMS_STOCK("WMS_STOCK", "WMS库存");

    private String dictCode;

    private String dictName;

    WmsAccountStockOptionEnum(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (WmsAccountStockOptionEnum commonConstant : values()) {
            if (commonConstant.getDictCode().equals(dictCode)) {
                return commonConstant.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

}