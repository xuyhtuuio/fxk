package com.maxnerva.cloudmes.enums;

/**
 * @Author hgx
 * @Description PKG位置枚举
 * @Date 2023/8/10
 */
public enum PkgLocationEnum {

    WMS_PKG_INFO("WMS_PKG_INFO", "库存表"),
    WMS_WORK_ORDER_PICK_LOG("WMS_WORK_ORDER_PICK_LOG", "捡料表"),
    WMS_WORK_ORDER_PREPARE_LOG("WMS_WORK_ORDER_PREPARE_LOG", "已上线表"),
    WMS_MATERIAL_RETURN_LOG("WMS_MATERIAL_RETURN_LOG", "退料表");

    private String dictCode;

    private String dictName;

    PkgLocationEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }
}
