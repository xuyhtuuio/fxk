package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName MaterialTypeEnum
 * @Description 物料类型
 * @Author Likun
 * @Date 2023/7/17
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum MaterialTypeEnum {

    /**
     * 物料类型
     */
    A("A","A类物料"),
    B("B","B类物料"),
    C("C","C类物料"),
    M("M","主料号"),
    S("S","替代料");

    private String dictCode;

    private String dictName;

    MaterialTypeEnum(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (MaterialTypeEnum materialTypeEnum : values()) {
            if (materialTypeEnum.getDictCode().equals(dictCode)) {
                return materialTypeEnum.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }
}
