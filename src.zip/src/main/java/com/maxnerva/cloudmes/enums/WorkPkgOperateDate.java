package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

public enum WorkPkgOperateDate {
    WO_HANDLE_BEGIN_DT("wo_handle_begin_dt", "工單處理開始時間"),
    WO_PICK_BEGIN_DT("wo_pick_begin_dt", "庫區撿料開始時間"),
    WO_JUSDA_BEGIN_DT("wo_jusda_begin_dt", "Jusda直備開始時間"),
    WO_PARTITION_BEGIN_DT("wo_partition_begin_dt", "物料拆分開始時間"),
    WO_BURN_BEGIN_DT("wo_burn_begin_dt", "燒錄開始時間"),
    WO_MERGE_BEGIN_DT("wo_merge_begin_dt", "合盤開始時間"),
    WO_DISTRIBUTE_BEGIN_DT("wo_distribute_begin_dt", "分軌開始時間"),
    WO_ONLINE_BEGIN_DT("wo_online_begin_dt", "上料車開始時間"),
    WO_UNLOCK_DT("wo_unlock_dt", "工单解锁开始时间"),
    WO_CUT_OFF("wo_cut_off", "剪角开始时间");


    private String dictCode;

    private String dictName;

    WorkPkgOperateDate(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public void setDictCode(String dictCode) {
        this.dictCode = dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public void setDictName(String dictName) {
        this.dictName = dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (WorkPkgOperateDate areaCategoryCode : values()) {
            if (areaCategoryCode.getDictCode().equals(dictCode)) {
                return areaCategoryCode.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }
}
