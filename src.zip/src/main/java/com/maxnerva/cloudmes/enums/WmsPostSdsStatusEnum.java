package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

public enum WmsPostSdsStatusEnum {

    N("N", "未抛转"),
    Y("Y", "已抛转"),
    PRE("PRE", "待抛转");

    private String dictCode;

    private String dictName;

    WmsPostSdsStatusEnum(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (WmsPostSdsStatusEnum commonConstant : values()) {
            if (commonConstant.getDictCode().equals(dictCode)) {
                return commonConstant.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

}