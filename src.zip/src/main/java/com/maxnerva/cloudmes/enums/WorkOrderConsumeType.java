package com.maxnerva.cloudmes.enums;

// 工单成本报表中的工单类型
public enum WorkOrderConsumeType {

    LRR_RE_WORK("LRR_RE_WORK", "LRR重工"),
    MASS_WORK("MASS_WORK", "量产"),
    NPI_WORK("NPI_WORK", "NPI"),
    MASS_RE_WORK("MASS_RE_WORK", "量产重工");

    private String dictCode;

    private String dictName;

    WorkOrderConsumeType(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }
}
