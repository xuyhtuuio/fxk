package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName VehicleStatusEnum
 * @Description 载具状态枚举
 * @Author Likun
 * @Date 2022/12/30
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum VehicleStatusEnum {

    /**
     * 载具状态
     */
    RAW("RAW","原物料仓"),
    PREPARE("PREPARE","备料"),
    RETURN_MATERIAL("RETURN_MATERIAL","退料");

    private String dictCode;

    private String dictName;

    VehicleStatusEnum(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (VehicleStatusEnum vehicleStatusEnum : values()) {
            if (vehicleStatusEnum.getDictCode().equals(dictCode)) {
                return vehicleStatusEnum.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }
}
