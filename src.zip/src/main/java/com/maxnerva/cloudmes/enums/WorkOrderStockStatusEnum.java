package com.maxnerva.cloudmes.enums;

public enum WorkOrderStockStatusEnum {
    /**
     * 工单类型
     */
    ALL("ALL", "全部"),
    LACK("LACK", "欠发");

    private String dictCode;

    private String dictName;

    WorkOrderStockStatusEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }
}
