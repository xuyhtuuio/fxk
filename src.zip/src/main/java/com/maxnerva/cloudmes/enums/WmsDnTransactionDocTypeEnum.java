package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

public enum WmsDnTransactionDocTypeEnum {

    ALL("ALL", "全部"),
    SHIP_DOC("SHIP_DOC", "出货单"),
    CKD_SHIP_DOC("CKD_SHIP_DOC", "CKD出货单");

    private String dictCode;

    private String dictName;

    WmsDnTransactionDocTypeEnum(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (WmsDnTransactionDocTypeEnum commonConstant : values()) {
            if (commonConstant.getDictCode().equals(dictCode)) {
                return commonConstant.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

}
