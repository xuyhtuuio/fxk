package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

public enum CkdPackStatusEnum {

    PACKING("PACKING", "包装中"),
    PRE_SHIP("PRE_SHIP","待出货"),
    SHIP("SHIP", "已出货");

    private String dictCode;

    private String dictName;

    CkdPackStatusEnum(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

}
