package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName AgvStatusEnum
 * @Description AGV状态
 * @Author Likun
 * @Date 2024/5/10
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum AgvStatusEnum {

    CREATED("created", "任务创建"),
    RELEASED("released", "下发任务"),
    START("start", "开始执行"),
    OUTBIN("outbin", "走出储位"),
    END("end", "任务执行完成"),
    CANCEL("cancel", "任务取消"),
    DELETE("delete", "任务删除");


    private String dictCode;

    private String dictName;

    AgvStatusEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (AgvStatusEnum agvStatusEnum : values()) {
            if (agvStatusEnum.getDictCode().equals(dictCode)) {
                return agvStatusEnum.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

    /**
     * 提前判断，用于解决
     * Case中出现的Constant expression required
     *
     * @param dictCode 值
     * @return agvTaskTypeEnum
     */
    public static AgvStatusEnum getByValue(String dictCode) {
        for (AgvStatusEnum agvStatusEnum : values()) {
            if (agvStatusEnum.getDictCode().equals(dictCode)) {
                return agvStatusEnum;
            }
        }
        return null;
    }
}
