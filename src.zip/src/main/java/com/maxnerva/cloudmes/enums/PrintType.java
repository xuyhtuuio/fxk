package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName PrintType
 * @Description 打印类型
 **/
public enum PrintType {

    /**
     * 打印类型
     */
    PRINT_OUT_STOCK("PRINT_OUT_STOCK","条码列印"),
    DOC_OTHER_IN_OUT("DOC_OTHER_IN_OUT","其它出入库上架"),
    VMI_ONSHELF("VMI_ONSHELF","VMI上架"),
    MERGE_PLATE("MERGE_PLATE","kitting合盘"),
    ASSY_RETURN("ASSY_RETURN","ASSY退料"),
    KTIING_SPLIT_PLATE("KTIING_SPLIT_PLATE","KITTING-分盘"),
    KITTING_RETURN("KITTING_RETURN","KITTING-退料"),
    BIG_PLATE("BIG_PLATE","大盘退料"),
    FIVE_IN_STORAGE("FIVE_IN_STORAGE","531入库"),
    BARCODE_REPRINT("BARCODE_REPRINT","条码重印"),
    DOC_RECEIVE("DOC_RECEIVE","收货单上架"),
    PKG_SPLIT_PLATE("PKG_SPLIT_PLATE","条码分盘"),
    DOC_ADJUST("DOC_ADJUST","料调单"),
    BARCODE_WAREHOUSE_REPRINT("BARCODE_WAREHOUSE_REPRINT","大仓条码重印"),
    BARCODE_RETURN_REPRINT("BARCODE_RETURN_REPRINT","退料条码重印"),
    BARCODE_PREPARE_REPRINT("BARCODE_PREPARE_REPRINT","发料条码重印"),
    PICK_LOG_REPRINT("PICK_LOG_REPRINT","捡料条码重印"),
    BAD_PRODUCT("BAD_PRODUCT","不良品入库"),
    CKD_PREPARE_PALLET("CKD_PREPARE_PALLET","CKD在库直备-结束栈板"),
    CKD_PREPARE_CARTON("CKD_PREPARE_CARTON","CKD在库直备-结束装箱"),
    CKD_LOCK_PREPARE_PALLET("CKD_LOCK_PREPARE_PALLET","CKD锁料备料-结束栈板"),
    CKD_LOCK_PREPARE_CARTON("CKD_LOCK_PREPARE_CARTON","CKD锁料备料-结束装箱"),
    CKD_UP_PALLET("CKD_UP_PALLET","CKD上栈板"),
    PARTITION("PARTITION","分料分盘"),
    BURN_PARTITION("BURN_PARTITION","烧录分盘"),
    TRADING_OUT("TRADING_OUT","内交出货"),
    REPEAT_TRADING_OUT("REPEAT_TRADING_OUT","内交出货重印"),
    BURN_LABEL("BURN_LABEL","烧录标签"),
    PKG_MARGE_PLATE("PKG_MERGE_PLATE","条码合盘"),
    SHIPPING_LABEL("SHIPPING_LABEL","SHIPPING_LABEL"),
    COUNTING_SPLIT("COUNTING_SPLIT","盘点拆盘"),
    SHPPING_LABEL3C("SHPPING_LABEL3C","3C条码"),
    SHPPING_LABELN3C("SHPPING_LABELN3C","非3C条码"),
    SHPPING_LABEL_PALLET("SHPPING_LABEL_PALLET","出货合板"),
    SCRAP_IN_STORAGE("SCRAP_IN_STORAGE","报废入库"),
    MERGE_MATERIAL_RETURN("MERGE_MATERIAL_RETURN","合盘工单退料"),
    REMAIN_RETURN("REMAIN_RETURN", "余料返仓"),
    WO_STOCK("WO_STOCK", "工单发料"),
    PKG_LINK_PRINT("PKG_LINK_PRINT", "打散接料"),
    LRR_PKG_NO("LRR_PKG_NO", "LRR理貨"),
    SHPPING_DELL("SHPPING_DELL", "SHPPING_DELL"),
    MS_SHPPING_PALLET("MS_SHPPING_PALLET", "MS_SHPPING_PALLET"),
    SHIPPING_QOLSYS_DUBAI("SHIPPING_QOLSYS_DUBAI", "SHIPPING_QOLSYS_DUBAI"),
    SHPPING_DELL_ZPL("SHPPING_DELL_ZPL", "SHPPING_DELL_ZPL"),
    HPE_3S_4S_SHPPING_PALLET("HPE_3S_4S_SHPPING_PALLET", "HPE_3S_4S_SHPPING_PALLET"),
    BD_SHPPING_PALLET("BD_SHPPING_PALLET", "BD_SHPPING_PALLET"),
    SWR_PKG_DIVIDE("SWR_PKG_DIVIDE", "沾锡验证分盘"),
    SWR_PKG_REPEAT("SWR_PKG_REPEAT", "沾锡条码重印"),
    CMB_PDA_PKG_ZPL("CMB-PDA-PKG-ZPL", "PDA zpl条码打印"),
    OUTSOURCING_MATERIAL_RETURN("OUTSOURCING_MATERIAL_RETURN", "委外退料");

    private String dictCode;

    private String dictName;

    PrintType(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (PrintType printType : values()) {
            if (printType.getDictCode().equals(dictCode)) {
                return printType.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }
}
