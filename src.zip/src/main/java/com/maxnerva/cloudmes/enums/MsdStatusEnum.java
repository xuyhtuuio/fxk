package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @ClassName MsdStatusEnum
 * @Description msd状态枚举
 * @Author Likun
 * @Date 2023/12/14
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Getter
@AllArgsConstructor
public enum MsdStatusEnum {

    SEAL("SEAL", "封装"),
    UNSEAL("UNSEAL", "开封"),
    ONLINE("ONLINE", "上线"),
    OFFLINE("OFFLINE", "下线"),
    INDRYBOX("INDRYBOX", "进防潮箱"),
    OUTDRYBOX("OUTDRYBOX", "出防潮箱"),
    BAKING("BAKING", "烘烤中"),
    BAKEEND("BAKEEND", "烘烤结束"),
    /** 回收状态改为 回收 */
    EXHAUST("EXHAUST", "回收"),
    ;

    private String dictCode;
    private String dictName;

    public static String getDictNameByDictCode(String dictCode) {
        for (MsdStatusEnum msdStatusEnum : values()) {
            if (msdStatusEnum.getDictCode().equals(dictCode)) {
                return msdStatusEnum.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }
}
