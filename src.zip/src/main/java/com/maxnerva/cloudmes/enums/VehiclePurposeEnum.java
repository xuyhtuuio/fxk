package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName VehiclePurposeEnum
 * @Description 载具使用用途
 * @Author Likun
 * @Date 2023/5/17
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum VehiclePurposeEnum {

    /**
     * 载具使用用途
     */
    TRANSFER("TRANSFER", "中转载具"),
    STORAGE("STORAGE", "存储载具");

    private String dictCode;

    private String dictName;

    VehiclePurposeEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (VehiclePurposeEnum vehiclePurposeEnum : values()) {
            if (vehiclePurposeEnum.getDictCode().equals(dictCode)) {
                return vehiclePurposeEnum.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }
}
