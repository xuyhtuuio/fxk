package com.maxnerva.cloudmes.enums;

public enum QholdProductSelectEnum {

    PKG_ID("PKGID", "通过原物料查询成品分布"),
    PRODUCT("PRODUCT","通过成品查询成品分布");

    private String dictCode;

    private String dictName;

    QholdProductSelectEnum(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }
}
