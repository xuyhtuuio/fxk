package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName PkgLockStatusEnum
 * @Description 条码锁定状态枚举
 * @Author Likun
 * @Date 2023/9/6
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum PkgLockStatusEnum {

    NORMAL("0","正常"),
    WORK_ORDER_LOCK("1","工单锁"),
    QMS_HOLD_LOCK("2","QMS hold锁"),
    END_DATE_LOCK("3","end_date过期锁"),
    BUY_SELL_LOCK("4","buySell锁"),
    POST_QMS_LOCK("5","收货抛QMS锁"),
    WAREHOUSE_MANUAL_LOCK("6","仓库物料手动锁"),
    BUY_SELL_NOT_AVAILABLE("7","buySell不可用锁"),
    EXCEPTION_LOCK("8","异常手动锁"),
    MSD_EXPIRED_LOCK("9","MSD过期锁"),
    AGV_RETURN_WAREHOUSE_LOCK("10","AGV余料返仓锁"),
    STAMP_AGV_LOCK("11","AGV冲压移料组装锁"),
    PRODUCT_IN_STORAGE_AGV_LOCK("21","AGV采集入库锁定");

    private final String dictCode;

    private final String dictName;

    PkgLockStatusEnum(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (PkgLockStatusEnum pkgLockStatusEnum : values()) {
            if (pkgLockStatusEnum.getDictCode().equals(dictCode)) {
                return pkgLockStatusEnum.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }
}
