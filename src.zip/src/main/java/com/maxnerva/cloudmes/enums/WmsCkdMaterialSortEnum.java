package com.maxnerva.cloudmes.enums;

public enum WmsCkdMaterialSortEnum {
    COMMON("0", "一般物料"),
    BATTERY("1","电池");

    private String dictCode;

    private String dictName;

    WmsCkdMaterialSortEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }
}
