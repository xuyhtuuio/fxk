package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName CodeRuleEnum
 * @Description 成品出货运输方式语言枚举
 **/
public enum TransportModeEnum {

    /**
     *  简体
     */
    SIMPLIFIED_LAND("LAND","陆运"),
    SIMPLIFIED_SEA("SEA","海运"),
    SIMPLIFIED_AIR("AIR","空运"),

    /**
     *  繁体
     */
    COMPLEX_LAND("LAND","陸運"),
    COMPLEX_SEA("SEA","海運"),
    COMPLEX_AIR("AIR","空運");

    private String dictCode;

    private String dictName;

    TransportModeEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictCodeByDictName(String dictName) {
        for (TransportModeEnum mode : values()) {
            if (mode.getDictName().equals(dictName)) {
                return mode.getDictCode();
            }
        }
        return StrUtil.EMPTY;
    }
}
