package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName StatusCode
 * @Description 状态枚举
 * @Author Likun
 * @Date 2022/8/4
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum  StatusCode {

    /**
     * 状态编码
     */
    Y("Y","是"),
    N("N","否"),
    NOT_INSPECTED("NOT_INSPECTED", "待检验"),
    QUALIFIED("QUALIFIED", "合格"),
    UN_QUALIFIED("UN_QUALIFIED", "不合格"),
    NOT_RECEIVED("NOT_RECEIVED","待收货"),
    RECEIVED_COMPLETED("RECEIVED_COMPLETED","收货完成"),
    SHELVING("SHELVING","上架中"),
    SHELF_COMPLETED("SHELF_COMPLETED","上架完成"),
    REMOVE_SHELF_COMPLETED("SHELF_COMPLETED","下架完成"),
    NOT_PICK_OUT("NOT_PICK_OUT","待下架"),
    DELIVER_CREATE("CREATE","出货状态-创建"),
    DELIVER_COMPLETE("COMPLETE","出货状态-完成"),
    REL("REL","工单header状态-发行"),
    DElETE("DElETE","工单header状态-删除"),
    CLOSE("CLOSE","工单header状态-关闭"),
    LOCK("LOCK","锁定"),
    USABLE("USABLE","可用"),
    RETURN_FLAG_N("RETURN_FLAG_N","未回大仓"),
    OK("OK","成功"),
    NG("NG","失败"),

    //成品出货单状态
    PRODUCT_CREATE("0","新建"),
    PRODUCT_AUDIT("1","待绑定"),
    PRODUCT_PROCESS("2","处理中"),
    PRODUCT_COMPLETED("3","出库完成"),
    PRODUCT_TO_BE_SHIPPED("4","待出货"),

    //其他出入库单据状态
    OTHER_INOUT_CREATE("0","新建"),
    OTHER_INOUT_AUDIT("1","审核"),
    OTHER_INOUT_PROCESS("2","处理中"),
    OTHER_INOUT_COMPLETED("3","完成"),

    INVENTORY_PLAN_CREATE("CREATE","新建"),
    INVENTORY_PLAN_COMPLETED("COMPLETED","完成"),
    PART_NO_USE_FLAG_Y("Y","正向配置"),
    PART_NO_USE_FLAG_N("N","反向配置"),
    PART_NO_USE_FLAG_M("M","指定料号");

    private String dictCode;

    private String dictName;

    StatusCode(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (StatusCode statusCode : values()) {
            if (statusCode.getDictCode().equals(dictCode)) {
                return statusCode.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }
}
