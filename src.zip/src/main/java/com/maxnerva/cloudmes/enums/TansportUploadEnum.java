package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

public enum TansportUploadEnum {

    NO_UPLOAD("0", "未上传"),
    UPLOADED("1", "已上传");

    private String dictCode;

    private String dictName;

    TansportUploadEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public void setDictCode(String dictCode) {
        this.dictCode = dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public void setDictName(String dictName) {
        this.dictName = dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (TansportUploadEnum mode : values()) {
            if (mode.getDictCode().equals(dictCode)) {
                return mode.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }
}
