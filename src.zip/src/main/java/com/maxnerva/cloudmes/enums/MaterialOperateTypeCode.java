package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName MaterialOperateTypeCode
 * @Description 物料操作类型枚举
 * @Author Likun
 * @Date 2022/8/11
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum  MaterialOperateTypeCode {

    /**
     * 物料操作类型枚举
     */
    DOC_SHELF("DOC_SHELF","单据上架"),
    DOC_TYPE_SHELF("DOC_TYPE_SHELF","单据类型上架");

    private String dictCode;

    private String dictName;

    MaterialOperateTypeCode(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (MaterialOperateTypeCode materialOperateTypeCode : values()) {
            if (materialOperateTypeCode.getDictCode().equals(dictCode)) {
                return materialOperateTypeCode.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }
}
