package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

public enum WmsSwrDocStatusEnum {
    
    NEW("0", "新建"),
    STOCKING("2", "备货中"),
    COMPLETE("1", "完成"),
    BURN("4", "已烘烤"),
    STOCKED("3", "已备货"),
    CHECKING("6", "验证中"),
    CHECKED("7", "已验证"),
    DIVIDE("5", "已分料");

    private String dictCode;

    private String dictName;

    WmsSwrDocStatusEnum(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (WmsSwrDocStatusEnum commonConstant : values()) {
            if (commonConstant.getDictCode().equals(dictCode)) {
                return commonConstant.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

}