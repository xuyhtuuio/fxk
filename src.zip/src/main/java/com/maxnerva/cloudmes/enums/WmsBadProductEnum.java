package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * 不良品单据枚举
 */
public enum WmsBadProductEnum {

    /**
     * 操作类型
     */
    OPERATION_TYPE_IN_STORAGE("OPERATION_TYPE_IN_STORAGE", "不良品入库"),
    OPERATION_TYPE_REPLACE("BAD_REPLACEMENT", "不良品置换"),
    BAD_RETURN("BAD_RETURN", "不良退料"),
    POOR_DISASSEMBLY("POOR_DISASSEMBLY", "拆解不良"),
    PROCESS_SCRAP("PROCESS_SCRAP", "制程报废"),
    REPAIR_SCRAP("REPAIR_SCRAP", "维修报废"),
    /**
     * 单据状态
     */
    STATUS_CREATE("0","新建"),
    STATUS_IN_STORAGE("1","已入库"),
    STATUS_REPLACE("2","已置换");
    private String dictCode;

    private String dictName;

    WmsBadProductEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (WmsBadProductEnum operationType : values()) {
            if (operationType.getDictCode().equals(dictCode)) {
                return operationType.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

    public static String getDictCodeByDictName(String dictName) {
        for (WmsBadProductEnum operationType : values()) {
            if (operationType.getDictName().equals(dictName)) {
                return operationType.getDictCode();
            }
        }
        return StrUtil.EMPTY;
    }
}
