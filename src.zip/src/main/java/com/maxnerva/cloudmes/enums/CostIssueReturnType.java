package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName CostIssueReturnType
 * @Description 状态枚举
 * @Author Likun
 * @Date 2022/8/4
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum CostIssueReturnType {
    /**
     * 单据类型
     */
    DOC_COST_ISSUE("COST_ISSUE", "费领单"),
    DOC_COST_RETURN("COST_RETURN", "费退单"),
    DOC_COST_SCRAP("COST_SCRAP", "报废单"),

    /**
     * 单据状态
     */
    STATUS_NOT_DELIVERY("NOT_DELIVERY", "待出货"),
    STATUS_DELIVERY_COMPLETED("DELIVERY_COMPLETED", "出货完成"),
    STATUS_NOT_RECEIVED("NOT_RECEIVED", "待收货"),
    STATUS_RECEIVED_COMPLETED("RECEIVED_COMPLETED","收货完成"),
    STATUS_NOT_SHELF("NOT_SHELF","待上架"),
    STATUS_CLOSED("CLOSED","关闭"),
    /**
     * 审批进度
     */
    APPROVAL_NOT_SEND("NOT_SEND","未送签"),
    APPROVAL_COMPLETED("COMPLETED","审核完成"),
    APPROVAL_SEND("SEND","已送签"),
    APPROVAL_REFUSED("REFUSED","拒签"),
    /**
     * 确认过账
     */
    USER_CONFIRM_POSTING_FLAG_Y("Y","确认过账"),
    USER_CONFIRM_POSTING_FLAG_N("N","没确认");


    private String dictCode;

    private String dictName;

    CostIssueReturnType(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (CostIssueReturnType statusCode : values()) {
            if (statusCode.getDictCode().equals(dictCode)) {
                return statusCode.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }
}
