package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * 环境原产国枚举
 */
public enum CopyCodeEnum {

    F_TJ("F_TJ","CN"),
    F_VN("F_VN","VN");

    private String dictCode;

    private String dictName;

    CopyCodeEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (CopyCodeEnum copyCodeEnum : values()) {
            if (copyCodeEnum.getDictCode().equals(dictCode)) {
                return copyCodeEnum.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }
}
