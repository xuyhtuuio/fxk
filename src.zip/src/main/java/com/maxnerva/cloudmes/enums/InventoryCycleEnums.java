package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName InventoryCycleEnums
 * @Description 盘点周期枚举
 * @Author Likun
 * @Date 2024/11/11
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum InventoryCycleEnums {

    /**
     * 盘点周期
     */
    DAY("DAY", "日"),
    WEEK("WEEK", "周"),
    MONTH("MONTH", "月");

    private String dictCode;

    private String dictName;

    InventoryCycleEnums(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (InventoryCycleEnums inventoryCycleEnums : values()) {
            if (inventoryCycleEnums.getDictCode().equals(dictCode)) {
                return inventoryCycleEnums.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

    /**
     * 提前判断，用于解决
     * Case中出现的Constant expression required
     *
     * @param dictCode 值
     * @return inventoryCycleEnums
     */
    public static InventoryCycleEnums getByValue(String dictCode) {
        for (InventoryCycleEnums inventoryCycleEnums : values()) {
            if (inventoryCycleEnums.getDictCode().equals(dictCode)) {
                return inventoryCycleEnums;
            }
        }
        return null;
    }
}
