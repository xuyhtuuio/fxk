package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName ProductBySnDocTypeEnum
 * @Description TODO
 * @Author Likun
 * @Date 2024/9/27
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum ProductBySnDocTypeEnum {

    COST_DOC("COST_DOC","费用单"),
    TRANSFER_DOC("TRANSFER_DOC","转仓单");

    private final String dictCode;

    private final String dictName;

    ProductBySnDocTypeEnum(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (ProductBySnDocTypeEnum productBySnDocTypeEnum : values()) {
            if (productBySnDocTypeEnum.getDictCode().equals(dictCode)) {
                return productBySnDocTypeEnum.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

    /**
     * 提前判断，用于解决
     * Case中出现的Constant expression required
     *
     * @param dictCode 值
     * @return productBySnDocTypeEnum
     */
    public static ProductBySnDocTypeEnum getByValue(String dictCode) {
        for (ProductBySnDocTypeEnum productBySnDocTypeEnum : values()) {
            if (productBySnDocTypeEnum.getDictCode().equals(dictCode)) {
                return productBySnDocTypeEnum;
            }
        }
        return null;
    }
}
