package com.maxnerva.cloudmes.enums;

/**
 * @Author hgx
 * @Description 盘点枚举
 * @Date 2023/7/24  INVENTORYPLANTYPE
 */
public enum InventoryPlanType {
    /**
     * 盘点类型
     */
    STATIC_INVENTORY("STATIC_INVENTORY","静态盘点"),
    INKIND_INVENTORY("INKIND_INVENTORY","实物盘点"),

    /**
     * 料车位置
     */
    RAW("RAW","原物料仓"),
    KITTING("KITTING","KITTING仓");

    private String dictCode;

    private String dictName;

    InventoryPlanType(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }
}
