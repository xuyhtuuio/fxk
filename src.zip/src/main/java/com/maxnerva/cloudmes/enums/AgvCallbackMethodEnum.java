package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName AgvCallbackMethodEnum
 * @Description AGV回调方法枚举
 * @Author Likun
 * @Date 2024/5/20
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum AgvCallbackMethodEnum {

    START("start", "任务开始"),
    OUTBIN("outbin", "走出储位"),
    END("end", "任务结束"),
    CANCEL("cancel", "任务单取消");


    private String dictCode;

    private String dictName;

    AgvCallbackMethodEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (AgvCallbackMethodEnum agvCallbackMethodEnum : values()) {
            if (agvCallbackMethodEnum.getDictCode().equals(dictCode)) {
                return agvCallbackMethodEnum.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }
}
