package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

public enum CmbWmsFactoryTypeEnum {

    ASSY("ASSY", "组装厂"),
    STAMP("STAMP", "冲压厂");

    private String dictCode;

    private String dictName;

    CmbWmsFactoryTypeEnum(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (CmbWmsFactoryTypeEnum commonConstant : values()) {
            if (commonConstant.getDictCode().equals(dictCode)) {
                return commonConstant.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

}