package com.maxnerva.cloudmes.enums;


import cn.hutool.core.util.StrUtil;

public enum WmsBarcodeUsageStatusEnum {

    ALL("ALL", "全部"),
    USAGE("USAGE", "可用"),
    LOCK("LOCK", "锁定");

    private String dictCode;

    private String dictName;

    WmsBarcodeUsageStatusEnum(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (WmsBarcodeUsageStatusEnum commonConstant : values()) {
            if (commonConstant.getDictCode().equals(dictCode)) {
                return commonConstant.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

}