package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

public enum WarehouseType {

    /**
     * 载具使用位置
     */
    bigWarehouse("bigWarehouse", "大仓"),
    KittingWarehouse("kittingWarehouse", "Kitting仓");

    private String dictCode;

    private String dictName;

    WarehouseType(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (WarehouseType warehouseType : values()) {
            if (warehouseType.getDictCode().equals(dictCode)) {
                return warehouseType.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }
}
