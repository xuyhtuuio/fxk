package com.maxnerva.cloudmes.enums;

public enum WmsWeighTypeEnum {
    L12_RACK("L12_RACK", "L12_RACK"),
    COMMON("COMMON", "COMMON");

    private String dictCode;

    private String dictName;

    WmsWeighTypeEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }
}
