package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName ProductCategoryCode
 * @Description 制程分类
 * @Author Likun
 * @Date 2022/9/9
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum  ProductCategoryCode {

    /**
     * 制程分类编码
     */
    SMT("SMT","SMT"),
    PTH("PTH","PTH"),
    ASSY("ASSY","ASSY"),
    BURN("BURN","BURN");

    private String dictCode;

    private String dictName;

    ProductCategoryCode(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (ProductCategoryCode productCategoryCode : values()) {
            if (productCategoryCode.getDictCode().equals(dictCode)) {
                return productCategoryCode.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }
}
