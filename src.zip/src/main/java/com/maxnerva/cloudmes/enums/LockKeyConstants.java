package com.maxnerva.cloudmes.enums;

/**
 * @ClassName LockKeyConstants
 * @Description TODO
 * @Author Likun
 * @Date 2024/5/29
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum LockKeyConstants {

    //物料上线
    MATERIAL_ONLINE("MATERIAL_ONLINE","物料上线"),
    //收货单单据上架
    RECEIVE_DOC_SHELF("RECEIVE_DOC_SHELF","收货单单据上架"),
    //盘点机盘点
    COUNTING_MACHINE("COUNTING_MACHINE","盘点机盘点"),
    // LRR箱锁 orgCode+pkgId
    LRR_PKG_ID("lrr#4028165e-fc3d-4ec9-9b0e-7f0bad704734", "LRR箱锁"),
    //工单捡料
    SUBMIT_PICKING_INFO("SUBMIT_PICKING_INFO","工单捡料"),
    //紧急叫料
    URGENT_PICK("URGENT_PICK","紧急叫料"),
    //退料盘点
    RETURN_LARGE_MATERIAL("RETURN_LARGE_MATERIAL","退料盘点"),
    //成品入库
    IN_STORAGE("IN_STORAGE","成品入库"),
    //PDA转仓扫描PKG
    DOC_TRANSFER_PKG("doc_transfer_pkg#3e86abf7-412d-4948-8b13-4ea8fa2f2cca", "PDA转仓扫描PKG"),
    //沾锡取料提交
    DOC_SWR_PICK("swr_pick#a7840b06-2860-41c2-b66f-c4c0f42e3c55", "沾锡取料提交");


    private String dictCode;

    private String dictName;

    LockKeyConstants(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }
}
