package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName CommonConstant
 * @Description 通用常量
 * @Author Likun
 * @Date 2023/3/28
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum CommonConstant {

    /**
     * 通用常量
     */
    EMPTY_POSITION("00-00", "空位置"),
    BY_PALLET("BY_PALLET", "栈板入库"),
    BY_CARTON("BY_CARTON", "箱号入库"),
    BOX("BOX", "BOX采集"),
    SN("SN", "SN采集"),
    EMPTY_NO("000-000", "空单号"),
    DELIVERY_SN_IN_STORE("DELIVERY_SN_IN_STORE", "领用治具入库"),
    UN_AUDITED("UN_AUDITED", "未审核"),
    AUDITED("AUDITED", "已审核");

    private String dictCode;

    private String dictName;

    CommonConstant(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (CommonConstant commonConstant : values()) {
            if (commonConstant.getDictCode().equals(dictCode)) {
                return commonConstant.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }
}
