package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

public enum WmsVehicleTypeEnum {

    car("car", "料车"),
    rack("rack", "料架"),
    pallet("pallet", "栈板"),
    tray("tray", "托盘");

    private String dictCode;

    private String dictName;

    WmsVehicleTypeEnum(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (WmsVehicleTypeEnum commonConstant : values()) {
            if (commonConstant.getDictCode().equals(dictCode)) {
                return commonConstant.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

}