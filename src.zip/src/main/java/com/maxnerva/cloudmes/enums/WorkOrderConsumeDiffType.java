package com.maxnerva.cloudmes.enums;

public enum WorkOrderConsumeDiffType {
    MORE("MORE", "超发"),
    LESS("LESS", "欠发"),
    NOT_DIFF("NOT_DIFF", "无差异"),
    LRR_NOT_DIFF("LRR_NOT_DIFF", "LRR工单无差异"),
    MASS_RE_NOT_DIFF("MASS_RE_NOT_DIFF", "重工工单无差异");

    private String dictCode;

    private String dictName;

    WorkOrderConsumeDiffType(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }
}
