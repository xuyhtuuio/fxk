package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName SfcUnShelfOperateType
 * @Description sfc拣料标识操作类型标识
 * @Author Likun
 * @Date 2023/4/3
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum SfcUnShelfOperateType {

    /**
     * sfc拣料标识操作类型
     */
    PICK_UN_SHELF("PICK_UN_SHELF", "拣料下架"),
    MOVE_ORDER("MOVE_ORDER", "工单移转"),
    CLEAR_VEHICLE("CLEAR_VEHICLE", "载具初始化"),
    COUNTING_MACHINE("COUNTING_MACHINE", "盘点机退料"),
    COUNTING_MACHINE_ON_SHELF("COUNTING_MACHINE_ON_SHELF", "盘点机退料上架"),
    SFC_ON_SHELF("SFC_ON_SHELF", "SFC退料上架"),
    ASSY_ON_SHELF("ASSY_ON_SHELF", "ASSY退料上架"),
    PTH_ON_SHELF("PTH_ON_SHELF", "PTH退料上架"),
    RETURN_BIND_WMS_WAREHOUSE("RETURN_BIND_WMS_WAREHOUSE", "退料绑大仓"),
    KITTING_FIRST_SET_PKG_UNSHELF("KITTING_FIRST_SET_PKG_UNSHELF", "KITTING首套料下架"),
    LARGE_PLATE_MATERIAL_RETURN("LARGE_PLATE_MATERIAL_RETURN", "SFC大盘退料"),
    MERGE_MATERIAL_RETURN("MERGE_MATERIAL_RETURN", "合盘工单退料"),
    ACCEPT_VEHICLE("ACCEPT_VEHICLE", "载具接收");

    private String dictCode;

    private String dictName;

    SfcUnShelfOperateType(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (SfcUnShelfOperateType sfcUnShelfOperateType : values()) {
            if (sfcUnShelfOperateType.getDictCode().equals(dictCode)) {
                return sfcUnShelfOperateType.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }
}
