package com.maxnerva.cloudmes.enums;

/**
 * @ClassName WorkOrderType
 * @Description 工单类型枚举
 * @Author Likun
 * @Date 2022/10/17
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum WorkOrderType {

    /**
     * 工单类型
     */
    AWO0("AWO0", "正常生产工单"),
    RWO0("RWO0", "重工工单"),
    DWO0("DWO0", "拆解工单"),
    NWO0("NWO0", "NPI 工单"),
    NRW0("NRW0", "NPI 重工工单"),
    NDW0("NDW0", "NPI 拆解工单"),
    CKD("CKD", "CKD工单"),
    MERGE("MERGE", "合备工单"),
    RRWO("RRWO", "LRR重工工单"),
    RMWO("RMWO", "量产重工");

    private String dictCode;

    private String dictName;

    WorkOrderType(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }
}
