package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

public enum WorkOrderInboundType {
    FINISH_PRODUCT("0", "成品入库"),
    SCRAP_PRODUCT("1", "报废入库");

    private String dictCode;

    private String dictName;

    WorkOrderInboundType(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public void setDictCode(String dictCode) {
        this.dictCode = dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public void setDictName(String dictName) {
        this.dictName = dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (WorkOrderInboundType areaCategoryCode : values()) {
            if (areaCategoryCode.getDictCode().equals(dictCode)) {
                return areaCategoryCode.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }
}
