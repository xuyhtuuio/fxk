package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

public enum WmsVehicleUsageStatusEnum {

    EMPTY("EMPTY", "闲置"),
    USAGE("USAGE", "可用"),
    FULL("FULL", "满载");

    private String dictCode;

    private String dictName;

    WmsVehicleUsageStatusEnum(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (WmsVehicleUsageStatusEnum commonConstant : values()) {
            if (commonConstant.getDictCode().equals(dictCode)) {
                return commonConstant.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

}