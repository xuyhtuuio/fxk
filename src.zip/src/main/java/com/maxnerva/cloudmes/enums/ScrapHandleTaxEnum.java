package com.maxnerva.cloudmes.enums;

public enum ScrapHandleTaxEnum {

    RAW("RAW","原物料"),
    SEMI("SEMI","半成品"),
    PROD("PROD", "成品");

    private final String dictCode;

    private final String dictName;

    ScrapHandleTaxEnum(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }
}
