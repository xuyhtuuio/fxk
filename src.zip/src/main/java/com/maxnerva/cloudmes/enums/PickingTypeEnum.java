package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName PickingTypeEnum
 * @Description 捡料类型
 * @Author Likun
 * @Date 2023/5/17
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum PickingTypeEnum {

    /**
     * 捡料类型
     */
    PTH("PTH", "PTH类物料"),
    ASSY("ASSY", "系统组装物料"),
    SMT("SMT", "SMT类物料，非前加工物料"),
    SMT_BURN("SMT-BURN", "SMT烧录类物料,前加工物料"),
    SMT_MARGE("SMT-MARGE", "SMT合盘类物料，前加工物料"),
    SMT_CUT("SMT-CUT", "SMT剪角类物料，前加工物料"),
    URGENT_PICK("URGENT-PICK", "紧急叫料");

    private String dictCode;

    private String dictName;

    PickingTypeEnum(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (PickingTypeEnum pickingTypeEnum : values()) {
            if (pickingTypeEnum.getDictCode().equals(dictCode)) {
                return pickingTypeEnum.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

    /**
     * 提前判断，用于解决
     * Case中出现的Constant expression required
     *
     * @param dictCode 值
     * @return pickingTypeEnum
     */
    public static PickingTypeEnum getByValue(String dictCode) {
        for (PickingTypeEnum pickingTypeEnum : values()) {
            if (pickingTypeEnum.getDictCode().equals(dictCode)) {
                return pickingTypeEnum;
            }
        }
        return null;
    }
}
