package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

public enum WmsSteelScrapWeighStatusEnum {

    ALL("ALL", "全部"),
    NOT_WEIGH("NOT_WEIGH", "未称重"),
    WEIGH("WEIGH", "已称重");

    private String dictCode;

    private String dictName;

    WmsSteelScrapWeighStatusEnum(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (WmsSteelScrapWeighStatusEnum commonConstant : values()) {
            if (commonConstant.getDictCode().equals(dictCode)) {
                return commonConstant.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

}