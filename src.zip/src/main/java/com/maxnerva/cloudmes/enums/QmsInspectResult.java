package com.maxnerva.cloudmes.enums;

/**
 * @ClassName QmsInspectResult
 * @Description qms检验结果
 * @Author Likun
 * @Date 2022/10/18
 * @Version 1.0
 * @Since JDK 1.8
 **/
public enum  QmsInspectResult {

    /**
     * qms检验结果
     */
    ACCEPT("A", "合格"),
    REJECT("R", "拒收"),
    REWORK("S", "重工"),
    WAIVE("W", "特采"),
    OK("OK","成功"),
    FAIL("FAIL","失败");

    private String dictCode;

    private String dictName;

    QmsInspectResult(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }
}
