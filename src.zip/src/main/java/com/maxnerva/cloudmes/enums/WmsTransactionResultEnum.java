package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

public enum WmsTransactionResultEnum {

    ALL("ALL", "全部"),
    NOT_COMPLETE("NOT_COMPLETE", "未完成"),
    COMPLETE("COMPLETE", "已完成"),
    EXCEPTION("EXCEPTION", "过账异常");

    private String dictCode;

    private String dictName;

    WmsTransactionResultEnum(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (WmsTransactionResultEnum commonConstant : values()) {
            if (commonConstant.getDictCode().equals(dictCode)) {
                return commonConstant.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

}