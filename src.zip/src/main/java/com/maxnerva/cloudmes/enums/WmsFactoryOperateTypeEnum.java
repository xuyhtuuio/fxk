package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

public enum WmsFactoryOperateTypeEnum {

    RE_DOWN_WO_HEADER("RE_DOWN_WO_HEADER", "重DOWN工单"),
    RE_DOWN_WO_DETAIL("RE_DOWN_WO_DETAIL", "重DOWN工单详情"),
    RE_DOWN_BOM_FEEDER("RE_DOWN_BOM_FEEDER", "重DOWN上料表"),
    UPDATE_WO_FROM_WAREHOUSE("UPDATE_WO_FROM_WAREHOUSE", "修改工单发料仓码"),
    UPDATE_WO_DATA_SOURCE("UPDATE_WO_DATA_SOURCE", "修改工单数据源"),
    CKD_UPDATE_ABC("CKD_UPDATE_ABC", "CKD修改ABC"),
    CKD_UPDATE_REQ_QTY("CKD_UPDATE_REQ_QTY", "CKD修改需求量"),
    UPDATE_STEEL_SCRAP_PACK_WEIGHT("UPDATE_STEEL_SCRAP_PACK_WEIGHT", "修改钢桶重量"),
    DELETE_STEEL_SCRAP_PACK_WEIGHT("DELETE_STEEL_SCRAP_PACK_WEIGHT", "删除钢桶"),
    CKD_GENERATE_SHIP_LIST("CKD_GENERATE_SHIP_LIST", "CKD生成出货清单"),
    UPDATE_MFG_DATE_CODE_FORMAT("UPDATE_MFG_DATE_CODE_FORMAT", "修改制造商DC格式"),
    UPDATE_MFG_PACK_RULE("UPDATE_MFG_PACK_RULE", "修改制造商箱包规"),
    UPDATE_MFG_PACK_TYPE("UPDATE_MFG_PACK_TYPE", "修改制造商包装形式"),
    UPDATE_MFG_FEED_SIZE("UPDATE_MFG_FEED_SIZE", "修改制造商盘尺寸"),
    UPDATE_MFG_INFO("UPDATE_MFG_INFO", "修改制造商信息"),
    CREATE_POSTING_DAY_LOCK("CREATE_POSTING_DAY_LOCK", "创建过账周/日锁"),
    DELETE_POSTING_DAY_LOCK("DELETE_POSTING_DAY_LOCK", "删除过账周/日锁"),
    UPDATE_POSTING_DAY_LOCK("UPDATE_POSTING_DAY_LOCK", "修改过账周/日锁"),
    PRINT_SCRAP_HANDLE_CONTACT_DOC("PRINT_SCRAP_HANDLE_CONTACT_DOC", "打印报废处理联络单"),
    DELETE_MATERIAL_USAGE_CONFIG("DELETE_MATERIAL_USAGE_CONFIG", "删除工单锁料配置"),
    UPDATE_MATERIAL_USAGE_CONFIG("UPDATE_MATERIAL_USAGE_CONFIG", "修改工单锁料配置"),
    UPDATE_SCRAP_HANDLE_TAX("UPDATE_SCRAP_HANDLE_TAX", "修改报废处理单关税信息");

    private String dictCode;

    private String dictName;

    WmsFactoryOperateTypeEnum(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (WmsFactoryOperateTypeEnum commonConstant : values()) {
            if (commonConstant.getDictCode().equals(dictCode)) {
                return commonConstant.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

}