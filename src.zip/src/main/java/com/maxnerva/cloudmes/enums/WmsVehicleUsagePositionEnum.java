package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

public enum WmsVehicleUsagePositionEnum {

    WH("WH", "大仓使用"),
    PICK("PICK", "作业区使用"),
    PREPARE("PREPARE", "上线物料使用"),
    RETURN("RETURN", "退料使用"),
    EMPTY("EMPTY", "未使用");

    private String dictCode;

    private String dictName;

    WmsVehicleUsagePositionEnum(String dictCode,String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (WmsVehicleUsagePositionEnum commonConstant : values()) {
            if (commonConstant.getDictCode().equals(dictCode)) {
                return commonConstant.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }

}
