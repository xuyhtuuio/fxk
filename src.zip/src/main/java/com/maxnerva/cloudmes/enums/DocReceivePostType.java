package com.maxnerva.cloudmes.enums;

import cn.hutool.core.util.StrUtil;

public enum DocReceivePostType {
    GR("GR", "GR过账"),
    GOOD("GOOD", "转良品"),
    NOT_GOOD("NOT_GOOD", "转不良品");

    private String dictCode;

    private String dictName;

    DocReceivePostType(String dictCode, String dictName) {
        this.dictCode = dictCode;
        this.dictName = dictName;
    }

    public String getDictCode() {
        return dictCode;
    }

    public void setDictCode(String dictCode) {
        this.dictCode = dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public void setDictName(String dictName) {
        this.dictName = dictName;
    }

    public static String getDictNameByDictCode(String dictCode) {
        for (DocReceivePostType areaCategoryCode : values()) {
            if (areaCategoryCode.getDictCode().equals(dictCode)) {
                return areaCategoryCode.getDictName();
            }
        }
        return StrUtil.EMPTY;
    }
}
