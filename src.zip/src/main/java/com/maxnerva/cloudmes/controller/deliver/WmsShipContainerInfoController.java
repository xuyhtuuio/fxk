package com.maxnerva.cloudmes.controller.deliver;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.deliver.*;
import com.maxnerva.cloudmes.models.vo.deliver.*;
import com.maxnerva.cloudmes.service.deliver.IWmsShipContainerInfoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@Api(tags = "货柜信息")
@Slf4j
@RestController
@RequestMapping("/container")
public class WmsShipContainerInfoController {

    @Resource
    private IWmsShipContainerInfoService wmsShipContainerInfoService;

    @ApiOperation("货柜信息列表查询")
    @PostMapping("/list")
    public R<PageDataDTO<WmsShipContainerInfoDTO>> selectPage(@RequestBody ShipContainerPageQueryVO pageQueryVO) {
        return R.ok(wmsShipContainerInfoService.selectPage(pageQueryVO));
    }

    @ApiOperation("货柜已绑定DN信息列表查询")
    @GetMapping("/selectDnByContainerNo")
    public R<WmsShipContainerDnDataDTO> selectDnByContainerNo(@RequestParam("id") Integer id) {
        return R.ok(wmsShipContainerInfoService.selectDnByContainerNo(id));
    }

    @ApiOperation("新增货柜信息")
    @PostMapping("/add")
    public R<Void> add(@RequestBody ShipContainerSaveVO saveVO) {
        wmsShipContainerInfoService.add(saveVO);
        return R.ok();
    }

    @ApiOperation("绑定DN查询货柜信息")
    @GetMapping("/selectContainerInfo")
    public R<List<WmsShipContainerBindDnDTO>> selectContainerInfo(@RequestParam("orgCode") String orgCode,
                                                                  @RequestParam("plantCode") String plantCode,
                                                                  @RequestParam("containerNo") String containerNo) {
        return R.ok(wmsShipContainerInfoService.selectContainerInfo(orgCode, plantCode, containerNo));
    }

    @ApiOperation("绑定DN查询出货单信息")
    @GetMapping("/selectDnShipInfo")
    public R<List<WmsShipDnBindDnDTO>> selectDnShipInfo(@RequestParam("orgCode") String orgCode,
                                                        @RequestParam("plantCode") String plantCode,
                                                        @RequestParam("dnNo") String dnNo) {
        return R.ok(wmsShipContainerInfoService.selectDnShipInfo(orgCode, plantCode, dnNo));
    }

    @ApiOperation("绑定DN提交")
    @PostMapping("/bindDn")
    public R<Void> bindDn(@RequestBody ShipContainerBindDnVO shipContainerBindDnVO) {
        wmsShipContainerInfoService.bindDn(shipContainerBindDnVO);
        return R.ok();
    }

    @ApiOperation("离厂确认")
    @PostMapping("/leaveConfirm")
    public R<Void> leaveConfirm(@RequestBody ShipContainerLeaveConfirmVO leaveConfirmVO) {
        wmsShipContainerInfoService.leaveConfirm(leaveConfirmVO);
        return R.ok();
    }

    @ApiOperation("码头看板")
    @GetMapping("/quayBoard")
    public R<PageDataDTO<ShipQuayBoardDTO>> quayBoard(@RequestParam("orgCode") String orgCode,
                                                      @RequestParam("pageIndex") Integer pageIndex,
                                                      @RequestParam("pageSize") Integer pageSize) {
        return R.ok(wmsShipContainerInfoService.quayBoard(orgCode, pageIndex, pageSize));
    }

    @ApiOperation("码头看板-装柜进度详情")
    @GetMapping("/containerProgress")
    public R<PageDataDTO<ShipQuayBoardProgressDTO>> containerProgress(@RequestParam("id") Integer id,
                                                                      @RequestParam("pageIndex") Integer pageIndex,
                                                                      @RequestParam("pageSize") Integer pageSize) {
        return R.ok(wmsShipContainerInfoService.containerProgress(id, pageIndex, pageSize));
    }

    @ApiOperation("出货检验抛Q")
    @GetMapping("/containerSendToQms")
    public R<Void> containerSendToQms(@RequestParam("id") Integer id) {
        wmsShipContainerInfoService.containerSendToQms(id);
        return R.ok();
    }

    @ApiOperation("修改货柜信息")
    @PostMapping("/update")
    public R<Void> update(@RequestBody ShipContainerUpdateVO updateVO) {
        wmsShipContainerInfoService.updateContainer(updateVO);
        return R.ok();
    }

}
