package com.maxnerva.cloudmes.controller.warehouse;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.entity.warehouse.WmsProductInstorageRecord;
import com.maxnerva.cloudmes.models.dto.instorage.*;
import com.maxnerva.cloudmes.models.dto.warehouse.ProductReturnRecordDTO;
import com.maxnerva.cloudmes.models.dto.wo.WoDetailInStorageDTO;
import com.maxnerva.cloudmes.models.vo.instorage.InStorageSfcInfoVO;
import com.maxnerva.cloudmes.models.vo.instorage.ProductInStorageVO;
import com.maxnerva.cloudmes.models.vo.instorage.WmsPkgSfcInfoQueryVO;
import com.maxnerva.cloudmes.models.vo.warehouse.ProductReturnRecordQueryVO;
import com.maxnerva.cloudmes.models.vo.warehouse.ProductReturnSubmitVO;
import com.maxnerva.cloudmes.models.vo.warehouse.ScanWarehouseVo;
import com.maxnerva.cloudmes.service.lock.LockService;
import com.maxnerva.cloudmes.service.warehouse.ProductInStorageService;
import com.maxnerva.cloudmes.service.warehouse.ProductReturnService;
import com.maxnerva.cloudmes.service.wo.IWmsWorkOrderDetailInStorageService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @author sclq
 * @date 2022/9/6 10:50
 */
@Api(tags = "成品入库")
@Slf4j
@RestController
@RequestMapping("/productInStorage")
public class ProductInStorageController {

    @Resource
    private ProductInStorageService productInStorageService;

    @Resource
    private IWmsWorkOrderDetailInStorageService wmsWorkOrderDetailInStorageService;

    @Resource
    private ProductReturnService productReturnService;

    @Resource
    private LockService lockService;

    @Deprecated
    @ApiOperation("扫码入库")
    @PostMapping("/scanWarehouse")
    private R<Void> scanWarehouse(@RequestBody ScanWarehouseVo scanWarehouseVo) {
        List<WmsProductInstorageRecord> records = productInStorageService.scanWarehouse(scanWarehouseVo);
        return R.ok(records);
    }

    @ApiOperation("成品入库提交")
    @PostMapping("/inStorage")
    public R<ProductInStorageDTO> inStorage(@RequestBody ProductInStorageVO productInStorageVO) {
        return R.ok(lockService.inStorage(productInStorageVO));
    }

    @ApiOperation("扫描barCode")
    @GetMapping("/scanBarCode")
    public R<SfcPalletScanDTO> scanBarCode(@ApiParam(value = "barCode", required = true)
                                           @RequestParam("barCode") String barCode,
                                           @ApiParam(value = "工厂组织", required = true)
                                           @RequestParam("orgCode") String orgCode,
                                           @ApiParam(value = "plantCode")
                                           @RequestParam(value = "plantCode", required = false) String plantCode,
                                           @ApiParam(value = "dataSource")
                                           @RequestParam(value = "dataSource", required = false) String dataSource) {
        return R.ok(productInStorageService.scanBarCode(barCode, orgCode, plantCode, dataSource));
    }

    @ApiOperation("APP扫描barCode")
    @GetMapping("/appScanBarCode")
    public R<SfcPalletScanDTO> appScanBarCode(@ApiParam(value = "barCode", required = true)
                                              @RequestParam("barCode") String barCode,
                                              @ApiParam(value = "工厂组织", required = true)
                                              @RequestParam("orgCode") String orgCode,
                                              @ApiParam(value = "plantCode")
                                              @RequestParam(value = "plantCode", required = false) String plantCode,
                                              @ApiParam(value = "dataSource")
                                              @RequestParam(value = "dataSource", required = false) String dataSource) {
        return R.ok(productInStorageService.appScanBarCode(barCode, orgCode, plantCode, dataSource));
    }

    @ApiOperation("查询成品入库信息")
    @PostMapping("/list")
    public R<PageDataDTO<WmsPkgSfcInfoDTO>> selectPkgSfcInfoPage(@RequestBody WmsPkgSfcInfoQueryVO queryVO) {
        return R.ok(productInStorageService.selectPkgSfcInfoPage(queryVO));
    }

    @ApiOperation("查询工单明细531入库信息详情")
    @GetMapping("/woDetailInStorage/detail")
    public R<WoDetailInStorageDTO> selectDetailById(String id) {
        return R.ok(wmsWorkOrderDetailInStorageService.selectDetailById(Integer.valueOf(id)));
    }

    @ApiOperation("成品入库提交By箱号")
    @PostMapping("/inStorageByCartonNo")
    public R<ProductCartonDTO> inStorageByCartonNo(@RequestBody ProductInStorageVO productInStorageVO) {
        return R.ok(productInStorageService.inStorageByCartonNo(productInStorageVO));
    }

    @ApiOperation("入库作业清单导出")
    @PostMapping("/exportPkgSfcInfoList")
    public void exportPkgSfcInfoList(HttpServletResponse response,
                                        @RequestBody WmsPkgSfcInfoQueryVO queryVO) {
        productInStorageService.exportPkgSfcInfoList(response, queryVO);
    }

    @ApiOperation("成品退回确认")
    @PostMapping("/returnSubmit")
    public R<Void> returnSubmit(@RequestBody ProductReturnSubmitVO productReturnSubmitVO) {
        productReturnService.returnSubmit(productReturnSubmitVO);
        return R.ok();
    }

    @ApiOperation("分页查询成品退回清单")
    @PostMapping("/productReturnList")
    public R<PageDataDTO<ProductReturnRecordDTO>> selectProductReturnRecordPage(
            @RequestBody ProductReturnRecordQueryVO queryVO) {
        return R.ok(productReturnService.selectProductReturnRecordPage(queryVO));
    }

    @ApiOperation("成品退回清单导出")
    @PostMapping("/exportProductReturnRecord")
    public R<Void> exportProductReturnRecord(HttpServletResponse response,
                                             @RequestBody ProductReturnRecordQueryVO queryVO) {
        productReturnService.exportProductReturnRecord(response, queryVO);
        return R.ok();
    }

    @ApiOperation("已入库信息")
    @PostMapping("/inStorageList")
    public R<List<InStorageSfcInfoDTO>> selectInStorageSfcInfo(@RequestBody InStorageSfcInfoVO inStorageSfcInfoVO) {
        return R.ok(productInStorageService.selectInStorageSfcInfo(inStorageSfcInfoVO));
    }
}
