package com.maxnerva.cloudmes.controller.pack;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.util.CollectionUtils;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.fastjson.JSON;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.entity.pack.ArrangementPlanOriginDay;
import com.maxnerva.cloudmes.mapper.pack.ArrangementPlanOriginDayMapper;
import com.maxnerva.cloudmes.models.dto.pack.ArrangementPlanTargetDayDto;
import com.maxnerva.cloudmes.models.vo.ExcelImportVO;
import com.maxnerva.cloudmes.service.pack.IWmsArrangementPlanOriginDayService;
import com.maxnerva.cloudmes.service.pack.IWmsArrangementPlanTargetDayService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

/**
 * @ClassName ArrangementPlanDayController
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/6/10 上午 09:32
 * @Version 1.0
 **/
@Api(tags = "包材排配日计划")
@RestController
@RequestMapping("/arrangementPlanDay")
public class ArrangementPlanDayController {

    @Autowired
    IWmsArrangementPlanOriginDayService arrangementPlanOriginDayService;
    @Autowired
    IWmsArrangementPlanTargetDayService arrangementPlanTargetDayService;
    @Resource
    ArrangementPlanOriginDayMapper arrangementMapper;

    /**
     *  日排配计划数据导入分页查询
     * @param arrangementDate 日排配日期
     * @param schedule 班别
     * @return
     */
    @ApiOperation("日排配计划数据导入分页查询")
    @GetMapping("/queryImportDay")
    public R queryImportDay(
                            @RequestParam(value = "arrangementDate", required = false) String arrangementDate,
                            @RequestParam(value = "schedule", required = false) String schedule,
                            @RequestParam(value = "orgCode", required = false) String orgCode,
                            @RequestParam("pageIndex") int pageIndex,
                            @RequestParam("pageSize") int pageSize){
        return R.ok(arrangementPlanOriginDayService.queryImportDay(arrangementDate,schedule,orgCode,pageIndex,pageSize));
    }

    /**
     *  日计划数据导入
     * @return
     */
    @ApiOperation("日排配计划数据导入")
    @PostMapping("/dayPlanImport")
    public R dayPlanImport(ExcelImportVO excelImportVO){
         arrangementPlanOriginDayService.dayPlanImport(excelImportVO.getFile(), excelImportVO.getOrgCode());
         return R.ok();
    }

    /**
     *  查询每个日排计划  所需的包材需求量
     * @return
     */
    @ApiOperation("日排配计划详情")
    @GetMapping("/dayPlanTargetDetails")
    public R dayPlanTargetDetails(  @RequestParam("hhpn") String hhpn,
                                    @RequestParam("transportation") String transportation,
                                    @RequestParam("schedule") String schedule,
                                    @RequestParam("arrangementDate") String arrangementDate,
                                    @RequestParam("orgCode") String orgCode) {
        return arrangementPlanTargetDayService.queryDetails(hhpn, transportation, schedule, arrangementDate, orgCode);
    }

    /**
     *  日排配计划报表导出数据校验
     * @param arrangementDate 排配日期
     * @return
     */
    @ApiOperation("日排配计划报表导出数据校验")
    @GetMapping("/downloadDataVerify")
    public R downloadDataVerify(@RequestParam("orgCode") String orgCode,
                                           @RequestParam("arrangementDate") String arrangementDate) {
        //查询未完成数据  计算状态 0:未计算1:计算中2:完成3:失败   不等于2的都为计算失败
        List<ArrangementPlanOriginDay> notSuccess = arrangementPlanOriginDayService.queryNotSuccess(arrangementDate, orgCode,2);
        if(!CollectionUtils.isEmpty(notSuccess)) {
            return R.no("排配日期为：" + arrangementDate + "存在未计算完成或计算失败数据，请耐心等待计算完成或重新计算失败数据，再进行导出！");
        }
        //导出数据查询
        List<ArrangementPlanTargetDayDto> dtoList = arrangementPlanTargetDayService.getDtoByArrangementDate(arrangementDate, orgCode);
        if(CollectionUtils.isEmpty(dtoList)) {
            return R.no("导出数据不存在！");
        }
        return R.ok();
    }

    /**
     *  日排配计划报表导出
     * @param response
     * @param arrangementDate 排配日期
     * @return
     * @throws Exception
     */
    @ApiOperation("日排配计划报表导出")
    @GetMapping("/dayPlanDownload")
    public void dayPlanDownload(HttpServletResponse response,
                                @RequestParam("arrangementDate") String arrangementDate,
                                @RequestParam("orgCode") String orgCode) throws Exception{
        try {
            response.setContentType("application/vnd.ms-excel");
            response.setCharacterEncoding("utf-8");
            // 这里URLEncoder.encode可以防止中文乱码 当然和easyexcel没有关系
            String fileName = URLEncoder.encode("dayPlan", "UTF-8");
            response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");
//            EasyExcel.write(response.getOutputStream(), ArrangementPlanTargetDayDto.class).autoCloseStream(Boolean.FALSE).sheet("日排配计划報表")
//                    .doWrite(arrangementPlanTargetDayService.getDtoByArrangementDate(arrangementDate));

            //---------------导出多sheet页  begin---------------------------------
            ExcelWriter excelWriter = EasyExcel.write(response.getOutputStream(), ArrangementPlanTargetDayDto.class).build();
            //获取包装好的map集合  key为厂商名  value为其数据
            Map<String, List<ArrangementPlanTargetDayDto>> dtoDateMap = arrangementPlanTargetDayService.getDtoByArrangementDateMultiSheet(arrangementDate, orgCode);
            //倒序遍历map   [allData排配报表数据插入到了map末端，需要把它放在第一位导出]
            ListIterator<Map.Entry<String, List<ArrangementPlanTargetDayDto>>> iterator =
                    new ArrayList<Map.Entry<String, List<ArrangementPlanTargetDayDto>>>(dtoDateMap.entrySet()).listIterator(dtoDateMap.size());
            //sheet页码索引
            int sheeetIndex = 0;
            while (iterator.hasPrevious()) {
                //取entry节点
                Map.Entry<String, List<ArrangementPlanTargetDayDto>> entry = iterator.previous();
                //创建sheet页
                WriteSheet sheet = EasyExcel.writerSheet(sheeetIndex, entry.getKey()).build();
                //向sheet页中写入数据
                excelWriter.write(entry.getValue(),sheet);
                //更新sheet页码索引
                sheeetIndex = sheeetIndex + 1;
            }
            excelWriter.finish();
            response.flushBuffer();
            //---------------------导出多sheet页 end--------------------------------------
        } catch (Exception e) {
            //重置response
            response.reset();
            response.setContentType("application/json");
            response.setCharacterEncoding("utf-8");
            R result = R.no("excel download error");
            response.getWriter().println(JSON.toJSONString(result));
        }
    }

    /**
     *  重新计算数据
     * @param arrangementDate 排配日期
     * @return
     */
    @ApiOperation("重新计算数据")
    @GetMapping("/calculateInsAnew")
    public R calculateInsAnew(@RequestParam("arrangementDate") String arrangementDate, @RequestParam("orgCode") String orgCode) {
        return arrangementPlanOriginDayService.calculateIns(null,arrangementDate, orgCode);
    }

    /**
     * @description:  抛转数据到JIT
     * @author:  BZG
     * @date:  2021/7/8
    //         * @param buCode     各个BU事业处代码，JIT数据需要用到
     * @param orderType     订单类型，抛转JIT数据需要用到
     * @param arrangementDate     排配日期
     * @return: com.foxconn.cesbg.wms.wmsmanageservice.entity.result.R
     */
    @ApiOperation("抛转数据到JIT")
    @GetMapping("/transferToJIT")
    public R transferToJIT(
//                                       @RequestParam("buCode") String buCode,
                                       @RequestParam("orderType") String orderType,
                                       @RequestParam("orgCode") String orgCode,
                                       @RequestParam("arrangementDate") String arrangementDate) {
        return arrangementPlanOriginDayService.transferToJIT(orgCode, orderType, arrangementDate);
    }

    /**
     * @description:    JIT验证失败数据查询
     * @author:  BZG
     * @date:  2021/9/22
     * @param arrangementDate
     * @return: com.foxconn.cesbg.wms.wmsmanageservice.entity.result.R
     */
    @ApiOperation("JIT验证失败数据查询")
    @GetMapping("/queryValidationFailed")
    public R queryValidationFailed(
                                              @RequestParam("arrangementDate") String arrangementDate,
                                   @RequestParam("orgCode") String orgCode) {
        return arrangementPlanOriginDayService.errorAnalysis(arrangementDate, orgCode, null);
    }

    @ApiOperation("批量删除日数据")
    @DeleteMapping("/delete")
    public R delete(@RequestBody List<Integer> dayList) {
        return R.ok(arrangementMapper.batchDel(dayList));
    }

}
