package com.maxnerva.cloudmes.controller.basic;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.alarm.WmsSendMailConfigDTO;
import com.maxnerva.cloudmes.models.vo.alarm.MailConfigUpdateVO;
import com.maxnerva.cloudmes.models.vo.alarm.WmsSendMailConfigQueryVO;
import com.maxnerva.cloudmes.service.alarm.IWmsSendMailConfigService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @ClassName MailConfigController
 * @Description 邮件配置管理
 * @Author Likun
 * @Date 2024/6/25
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "邮件配置管理")
@Slf4j
@RestController
@RequestMapping("/mailConfig")
public class MailConfigController {

    @Resource
    private IWmsSendMailConfigService wmsSendMailConfigService;

    @ApiOperation("分页查询邮件配置")
    @PostMapping("/list")
    public R<PageDataDTO<WmsSendMailConfigDTO>> selectMailConfig(@RequestBody WmsSendMailConfigQueryVO queryVO){
        return R.ok(wmsSendMailConfigService.selectMailConfigPage(queryVO));
    }

    @ApiOperation("修改邮件配置")
    @PostMapping("/update")
    public R<Void> updateMailConfig(@RequestBody MailConfigUpdateVO mailConfigUpdateVO){
        wmsSendMailConfigService.updateMailConfig(mailConfigUpdateVO);
        return R.ok();
    }
}
