package com.maxnerva.cloudmes.controller.wo;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.entity.wo.WmsCkdShipAddress;
import com.maxnerva.cloudmes.models.dto.ckd.PickCkdInStockListDTO;
import com.maxnerva.cloudmes.models.dto.wo.*;
import com.maxnerva.cloudmes.models.vo.ExcelImportVO;
import com.maxnerva.cloudmes.models.vo.ckd.PickCkdInStockListVO;
import com.maxnerva.cloudmes.models.vo.wo.*;
import com.maxnerva.cloudmes.service.wo.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Description;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @author MFQ
 * @date 2023/10/19 下午 06:00
 */
@Api(tags = "ckd ")
@Slf4j
@RestController
@RequestMapping("/ckd")
public class CkdController {

    @Resource
    private IWmsCkdFilingService wmsCkdFilingService;

    @Resource
    private IWmsCkdCusService wmsCkdCusService;

    @Resource
    private IWmsCkdPrepareService ckdPrepareService;

    @Resource
    private IWmsWorkOrderPrepareCkdService wmsWorkOrderPrepareCkdService;

    @Autowired
    private IWmsCkdService ckdService;

    @Autowired
    private IWmsWorkOrderPrepareCkdShipDetailService wmsWorkOrderPrepareCkdShipDetailService;

    @Autowired
    private IWmsWorkOrderPrepareCkdShipHeaderService wmsWorkOrderPrepareCkdShipHeaderService;

    @Autowired
    private IWmsCreatePoDnConfigService wmsCreatePoDnConfigService;

    @Autowired
    private IWmsCkdPalletLockService wmsCkdPalletConfigService;

    @ApiOperation("备案清单导入")
    @PostMapping("/ckdFilingImport")
    public R<Void> ckdFilingImport(ExcelImportVO excelImportVO) {
        wmsCkdFilingService.ckdFilingImport(excelImportVO);
        return R.ok();
    }

    @ApiOperation("查询备案清单")
    @PostMapping("/ckdFilingList")
    public R<PageDataDTO<CkdFilingLogDTO>> ckdFilingList(@RequestBody CkdFilingQueryVO queryVO) {
        return R.ok(wmsCkdFilingService.ckdFilingList(queryVO));
    }

    @ApiOperation("ckd备案清单excel导出")
    @PostMapping("/exportCkdFiling")
    public void exportCkdFiling(HttpServletResponse response,
                                @RequestBody CkdFilingQueryVO queryVO) throws IOException {
        wmsCkdFilingService.exportCkdFiling(response, queryVO);
    }


    @ApiOperation("cus导入")
    @PostMapping("/ckdCusImport")
    public R<Void> ckdCusImport(ExcelImportVO excelImportVO) {
        wmsCkdCusService.ckdCusImport(excelImportVO);
        return R.ok();
    }

    @ApiOperation("查询CUS信息")
    @PostMapping("/ckdCusList")
    public R<PageDataDTO<CkdCusDTO>> ckdCusList(@RequestBody CkdCusQueryVO queryVO) {
        return R.ok(wmsCkdCusService.ckdCusList(queryVO));
    }

    @ApiOperation("CUS excel导出")
    @PostMapping("/exportCkdCus")
    public void exportCkdCus(HttpServletResponse response,
                             @RequestBody CkdCusQueryVO queryVO) throws IOException {
        wmsCkdCusService.exportCkdCus(response, queryVO);
    }

    @ApiOperation("CKD打包清单Excel导出")
    @PostMapping("/exportPrepareCkdLog")
    public void exportPrepareCkdLog(HttpServletResponse response, @RequestBody CkdPreparedLogExportVO ckdPreparedLogExportVO) throws IOException {
        wmsWorkOrderPrepareCkdService.exportPrepareCkdLog(response, ckdPreparedLogExportVO);
    }

    @ApiOperation("分页查询CKD工单header")
    @GetMapping("/ckdHeaderList")
    public R<PageDataDTO<CkdHeaderListDTO>> ckdHeaderList(CkdHeaderListVO vo) {
        return R.ok(ckdService.ckdHeaderList(vo));
    }

    @ApiOperation("分页查询CKD工单Detail")
    @GetMapping("/ckdDetailList")
    public R<PageDataDTO<CkdDetailListDTO>> ckdDetailList(CkdDetailListVO vo) {
        return R.ok(ckdService.ckdDetailList(vo, Boolean.TRUE));
    }

    @ApiOperation("CKD工单Detail导出")
    @GetMapping("/ckdDetailListExport")
    public void ckdDetailListExport(CkdDetailListVO vo, HttpServletResponse response) {
        ckdService.ckdDetailListExport(vo, response);
    }

    @ApiOperation("CKD在库捡料查询")
    @GetMapping("/pickCkdInStockList")
    public R<PageDataDTO<PickCkdInStockListDTO>> pickCkdInStockList(PickCkdInStockListVO vo) {
        return R.ok(ckdPrepareService.pickCkdInStockList(vo, Boolean.TRUE));
    }

    @ApiOperation("CKD在库捡料导出")
    @GetMapping("/pickCkdInStockListExport")
    public void pickCkdInStockListExport(PickCkdInStockListVO vo, HttpServletResponse response) {
        ckdPrepareService.exportPickCkdInStockList(vo, response);
    }

    @ApiOperation("CKD在库捡料查询库存信息 by 工单料号")
    @GetMapping("/pickCkdInStockInfoList")
    public R<PageDataDTO<PickCkdInStockInfoListDTO>> pickCkdInStockInfoList(PickCkdInStockInfoListVO vo) {
        return R.ok(ckdPrepareService.pickCkdInStockInfoList(vo));
    }

    @ApiOperation("CKD在库捡料扫描载具")
    @GetMapping("/scanVehicle")
    public R scanVehicle(@RequestParam(value = "workOrderNo") String workOrderNo,
                         @RequestParam(value = "vehicleCode") String vehicleCode,
                         @RequestParam(value = "orgCode") String orgCode) {
        ckdPrepareService.scanVehicle(workOrderNo, vehicleCode, orgCode);
        return R.ok();
    }

    @ApiOperation("CKD在库捡料提交")
    @PostMapping("/pickCkdInStockSubmit")
    public R pickCkdInStockSubmit(@Valid @RequestBody PickCkdInStockSubmitVO vo) {
        return R.ok(ckdPrepareService.pickCkdInStockSubmit(vo));
    }

    @ApiOperation("CKD在库打包")
    @PostMapping("/packCkdInStockSubmit")
    public R<PackCkdInStockSubmitDTO> packCkdInStockSubmit(@Valid PackCkdInStockSubmitVO vo) {
        return R.ok(ckdPrepareService.packCkdInStockSubmit(vo));
    }

    @ApiOperation("CKD在库上栈板")
    @PostMapping("/upperCkdPallet")
    public R<PackCkdInStockSubmitDTO> upperCkdPallet(@Valid @RequestBody UpperCkdPalletVO vo) {
        return R.ok(ckdPrepareService.upperPallet(vo));
    }

    @ApiOperation("CKD准时达打包")
    @PostMapping("/packCkdInJusdaSubmit")
    public R<Void> packCkdInJusdaSubmit(@Valid @RequestBody PackCkdInJusdaSubmitVO vo) {
        ckdPrepareService.packCkdInJusdaSubmit(vo);
        return R.ok();
    }

    @ApiOperation("CKD准时达上栈板")
    @PostMapping("/upperCkdJusdaPallet")
    public R<Void> upperCkdJusdaPallet(@Valid @RequestBody UpperCkdJusdaPalletVO vo) {
        ckdPrepareService.upperCkdJusdaPallet(vo);
        return R.ok();
    }

    @ApiOperation("CKD修改打包信息（毛重、材质、材积、包装方式信息）")
    @PostMapping("/updateCkdInfo")
    public R<Void> updateCkdInfo(UpdateCkdInfoVO vo) {
        ckdService.updateCkdInfo(vo);
        return R.ok();
    }

    @ApiOperation("CKD出货提交")
    @PostMapping("/shipCkdSubmit")
    public R<ShipCkdSubmitDTO> shipCkdSubmit(@RequestBody ShipCkdSubmitVO vo) {
        return R.ok(ckdService.shipCkdSubmit(vo));
    }

    @ApiOperation("CKD导入新料号")
    @PostMapping("/importAddCkdPartNo")
    public R importAddCkdPartNo(ImportAddCkdPartNoVO vo) {
        ckdService.importAddCkdPartNo(vo);
        return R.ok();
    }

    @ApiOperation("CKD工单结案")
    @PostMapping("/closeCkdWo")
    public R closeCkdWo(@RequestParam(value = "workOrderId") Integer workOrderId) {
        ckdService.closeCkdWo(workOrderId);
        return R.ok();
    }

    @ApiOperation("结束CKD栈板")
    @PostMapping("/stopCkdPallet")
    public R<CkdPalletPrintDTO> stopCkdPallet(CkdPrintVO ckdPrintVO) {
        return R.ok(ckdService.stopCkdPallet(ckdPrintVO));
    }

    @ApiOperation("结束CKD箱号")
    @PostMapping("/stopCkdCarton")
    public R<CkdCartonPrintDTO> stopCkdCarton(CkdPrintVO ckdPrintVO) {
        return R.ok(ckdService.stopCkdCarton(ckdPrintVO));
    }

    @ApiModelProperty("确认是否分盘")
    @PostMapping("/confirmCkdPartition")
    public R confirmCkdPartition(ConfirmCkdPartitionVO vo) {
        ckdService.confirmCkdPartition(vo);
        return R.ok();
    }

    @ApiOperation("导入CKD出货地址")
    @PostMapping("/importCkdShipAddress")
    public R importCkdShipAddress(ImportCkdShipAddressVO vo) {
        ckdService.importCkdShipAddress(vo);
        return R.ok();
    }

    @ApiOperation("CKD出货地址查询")
    @GetMapping("/getCkdShipAddressPageList")
    public R<PageDataDTO<WmsCkdShipAddress>> getCkdShipAddressPageList(GetCkdShipAddressPageListVO vo) {
        return R.ok(ckdService.getCkdShipAddressList(vo, true));
    }

    @ApiOperation("导出CKD出货地址")
    @GetMapping("/exportCkdShipAddress")
    public void exportCkdShipAddress(GetCkdShipAddressPageListVO vo, HttpServletResponse response) {
        ckdService.exportCkdShipAddress(vo, response);
    }

    @ApiOperation("分页查询CKD打包清单")
    @PostMapping("/ckdLogList")
    public R<PageDataDTO<CkdLogListDTO>> ckdLogList(@RequestBody  CkdLogListVO vo) {
        return R.ok(ckdService.ckdLogList(vo, true));
    }

    @ApiOperation("分页查询CKD打包清单导出")
    @PostMapping("/ckdLogListExport")
    public void ckdLogListExport(@RequestBody CkdLogListVO vo, HttpServletResponse response) {
        ckdService.ckdLogListExport(vo, response);
    }

    @ApiOperation("退港明细导出")
    @PostMapping("/departureDetailsCkdExport")
    @Description(value = "箱or栈板统一使用批量导入接口，该接口已废弃")
    @Deprecated
    public void departureDetailsCkdExport(@RequestBody DepartureDetailsCkdExportVO vo, HttpServletResponse response) {
        response.setHeader("Content-Disposition", "attachment; filename=tmp");
        ckdService.departureDetailsCkdExport(vo, response);
    }

    @ApiOperation("Packing list打印")
    @GetMapping("/printCkdPackingList")
    public R<PrintCkdPackingListDTO> printCkdPackingList(PrintCkdPackingListVO vo) {
        return R.ok(ckdService.printCkdPackingList(vo));
    }

    @ApiOperation("产生生成DN列表")
    @PostMapping("/generateCkdDnList")
    @Description(value = "不推荐使用，没有维护。")
    public R generateCkdDnList(@RequestBody GenerateCkdDnListVO vo) {
        ckdService.generateCkdDnList(vo);
        return R.ok();
    }

    
    @ApiOperation("栈板解绑check栈板")
    @PostMapping("/unbindCkdPalletCheckPallet")
    public R unbindCkdPalletCheckPallet(@RequestBody UnbindCkdPalletCheckPalletVO vo){
        ckdService.unbindCkdPalletCheckPallet(vo);
        return R.ok();
    }

    @ApiOperation("栈板解绑")
    @PostMapping("/unbindCkdPallet")
    public R unbindCkdPallet(@RequestBody UnbindCkdPalletVO vo){
        ckdService.unbindCkdPallet(vo);
        return R.ok();
    }

    @ApiOperation("箱解绑check箱号")
    @PostMapping("/unbindCkdCartonCheckCarton")
    public R unbindCkdCartonCheckCarton(@RequestBody UnbindCkdCartonCheckCartonVO vo){
        ckdService.unbindCkdCartonCheckCarton(vo);
        return R.ok();
    }

    @ApiOperation("箱解绑")
    @PostMapping("/unbindCkdCarton")
    public R unbindCkdCarton(@RequestBody UnbindCkdCartonVO vo){
        ckdService.unbindCkdCarton(vo);
        return R.ok();
    }

    @ApiOperation("打印栈板条码")
    @PostMapping("/printPalletList")
    public R<CkdPalletPrintDTO> printPalletList(@RequestBody CkdNotWoPrintVO vo){
        return R.ok(ckdService.printPalletList(vo));
    }

    @ApiOperation("打印箱条码")
    @PostMapping("/printCartonList")
    public R<CkdCartonPrintDTO> printCartonList(@RequestBody CkdNotWoPrintVO vo){
        return R.ok(ckdService.printCartonList(vo));
    }

    @ApiOperation("VN创建PO回写状态")
    @PostMapping("/reWriteCreatePoStatus")
    public R<Void> reWriteCreatePoStatus(@RequestBody ReWriteCreatePoVO reWriteCreatePoVO) {
        wmsWorkOrderPrepareCkdShipHeaderService.reWriteCreatePoStatus(reWriteCreatePoVO);
        return R.ok();
    }


    @ApiOperation("CKD出货清单列表查询")
    @PostMapping("/shipHeaderList")
    public R<PageDataDTO<WmsWorkOrderPrepareCkdShipHeaderDTO>> shipHeaderList(@RequestBody PrepareCkdShipHeaderPageQueryVO pageQueryVO) {
        return R.ok(wmsWorkOrderPrepareCkdShipHeaderService.shipHeaderList(pageQueryVO));
    }

    @ApiOperation("导出CKD出货清单单头")
    @PostMapping("/exportShipHeaderList")
    public R<Void> exportShipHeaderList(HttpServletResponse response,
                                        @RequestBody PrepareCkdShipHeaderPageQueryVO vo) {
        wmsWorkOrderPrepareCkdShipHeaderService.exportShipHeaderList(response, vo);
        return R.ok();
    }

    @ApiOperation("CKD出货清单明细列表查询")
    @PostMapping("/shipDetailList")
    public R<PageDataDTO<WmsWorkOrderPrepareCkdShipDetailDTO>> shipDetailList(@RequestBody PrepareCkdShipDetailPageQueryVO pageQueryVO) {
        return R.ok(wmsWorkOrderPrepareCkdShipDetailService.shipDetailList(pageQueryVO));
    }

    @ApiOperation("导出CKD出货清单明细")
    @PostMapping("/exportShipDetailList")
    public R<Void> exportShipDetailList(HttpServletResponse response,
                                        @RequestBody PrepareCkdShipDetailPageQueryVO vo) {
        wmsWorkOrderPrepareCkdShipDetailService.exportShipDetailList(response, vo);
        return R.ok();
    }

    @ApiOperation("VN确认收货查询出货信息")
    @PostMapping("/getCkdShipDetailSerialNo")
    public R<List<String>> getCkdShipDetailSerialNo(@RequestBody VnCkdConfirmReceiveVO vnCkdConfirmReceiveVO) {
        return R.ok(wmsWorkOrderPrepareCkdShipDetailService.getCkdShipDetailSerialNo(vnCkdConfirmReceiveVO));
    }

    @ApiOperation("绑定DN单")
    @PostMapping("/bindingDn")
    public R<Void> bindingDn(@RequestBody CkdBindingDnVO ckdBindingDnVO) {
        ckdService.bindingDn(ckdBindingDnVO);
        return R.ok();
    }

    @ApiOperation("修改CKD工单detail的需求数量")
    @PostMapping("/updateRequiredQuantity")
    public R<Void> updateRequiredQuantity(@RequestBody UpdateRequiredQuantityVO vo){
        ckdService.updateRequiredQuantity(vo);
        return R.ok();
    }

    @ApiOperation("删除CKD工单料号")
    @DeleteMapping("/deletePartNo")
    public R<Void> deletePartNo(@RequestBody DeletePartNoVO vo){
        ckdService.deletePartNo(vo);
        return R.ok();
    }

    @ApiOperation("修改CKD工单ABC")
    @PostMapping("/updateCkdWoAbc")
    public R<Void> updateCkdWoAbc(@RequestBody UpdateCkdWoAbcVO vo){
        ckdService.updateCkdWoAbc(vo);
        return R.ok();
    }

    @ApiOperation("手动同步CKD备案信息")
    @PostMapping("/syncCkdFilling")
    public R<Void> syncCkdFilling(@RequestBody SyncCkdFillingVO vo){
        wmsCkdFilingService.syncCkdFilling(vo);
        return R.ok();
    }

    @ApiOperation("批量栈板导出退港明细")
    @PostMapping("/departureDetailsCkdMultiPalletExport")
    public void departureDetailsCkdMultiPalletExport(@RequestBody DepartureDetailsCkdMultiPalletExportVO vo, HttpServletResponse response){
        // 防止前端不显示报错信息
        response.setHeader("Content-Disposition", "attachment; filename=tmp");
        ckdService.departureDetailsCkdMultiPalletExport(vo, response);
    }

    @ApiOperation("CKD捡料锁料查询列表")
    @GetMapping("/pickCkdInPkgStockList")
    public R<PageDataDTO<PickCkdInPkgStockListDTO>> pickCkdInPkgStockList(PickCkdInPkgStockListVO vo){
        return R.ok(ckdPrepareService.pickCkdInPkgStockList(vo, Boolean.TRUE));
    }

    @ApiOperation("CKD捡料锁料导出")
    @GetMapping("/pickCkdInPkgStockListExport")
    public void pickCkdInPkgStockListExport(PickCkdInPkgStockListVO vo, HttpServletResponse response){
        ckdPrepareService.pickCkdInPkgStockListExport(vo, response);
    }

    @ApiOperation("CKD工单以及锁料信息")
    @GetMapping("/woLockInfo")
    public R<WoLockInfoDTO> woLockInfo(WoLockInfoVO vo){
        return R.ok(ckdPrepareService.woLockInfo(vo));
    }

    @ApiOperation("CKD工单锁PKG")
    @PostMapping("/lockPkgByCkdWo")
    public R<WoLockInfoDTO> lockPkgByCkdWo(@RequestBody LockPkgByCkdWoVO vo){
        return R.ok(ckdPrepareService.lockPkgByCkdWo(vo));
    }

    @ApiOperation("CKD批量自动工单锁PKG")
    @PostMapping("/autoLockPkgByCkdWo")
    public R autoLockPkgByCkdWo(@RequestBody WoLockInfoVO vo){
        ckdPrepareService.autoLockPkgByCkdWo(vo);
        return R.ok();
    }

    @ApiOperation("CKD工单解锁PKG")
    @DeleteMapping("/unLockPkgByCkdWo")
    public R<WoLockInfoDTO> unLockPkgByCkdWo(@RequestBody UnLockPkgByCkdWoVO vo){
        return R.ok(ckdPrepareService.unLockPkgByCkdWo(vo));
    }

    @ApiOperation("CKD工单解锁全部PKG")
    @DeleteMapping("/unLockAllPkgByCkdWo")
    public R unLockAllPkgByCkdWo(@RequestBody WoLockInfoVO vo){
        ckdPrepareService.unLockAllPkgByCkdWo(vo);
        return R.ok();
    }

    @ApiOperation("查询已打包pkg by 箱")
    @GetMapping("/getPackedPkgList")
    public R<GetPackedPkgListDTO> getPackedPkgList(GetPackedPkgListVO vo){
        return R.ok(ckdService.getPackedPkgList(vo));
    }

    @ApiOperation("查询已打包散PKG by栈板")
    @GetMapping("/getPackedCartonList")
    public R<GetPackedCartonListDTO> getPackedCartonList(GetPackedCartonListVO vo){
        return R.ok(ckdService.getPackedCartonList(vo));
    }

    @ApiOperation("批量箱号导出退港明细")
    @PostMapping("/departureDetailsCkdMultiCartonExport")
    public void departureDetailsCkdMultiCartonExport(@RequestBody DepartureDetailsCkdMultiCartonExportVO vo, HttpServletResponse response){
        // 防止前端不显示报错信息
        response.setHeader("Content-Disposition", "attachment; filename=tmp");
        ckdService.departureDetailsCkdMultiCartonExport(vo, response);
    }

    @ApiOperation("导入退港明细转退运协议")
    @PostMapping("/departureDetailTransferReturnDetail")
    public void departureDetailTransferReturnDetail(DepartureTransferReturnVO vo, HttpServletResponse response){
        ckdService.departureDetailTransferReturnDetail(vo, response);
    }

    @ApiOperation("PDA上栈板后查询栈板状态")
    @GetMapping("/getUpperPalletInfo")
    public R<GetUpperPalletInfoDTO> getUpperPalletInfo(GetUpperPalletInfoVO vo){
        return R.ok(ckdService.getUpperPalletInfo(vo));
    }
}