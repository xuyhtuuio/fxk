package com.maxnerva.cloudmes.controller.basic;

import com.maxnerva.cloudmes.common.annotation.RedisLock;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.common.utils.WebContextUtil;
import com.maxnerva.cloudmes.entity.basic.WmsEccnControlInfo;
import com.maxnerva.cloudmes.excel.util.DataSourceUtil;
import com.maxnerva.cloudmes.models.dto.basic.*;
import com.maxnerva.cloudmes.models.vo.basic.*;
import com.maxnerva.cloudmes.service.basic.IWmsEccnControlInfoService;
import com.maxnerva.cloudmes.service.basic.IWmsEccnMaterialInfoService;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

@RestController
@RequestMapping("/eccn")
public class EccnMaterialController {

    @Autowired
    IWmsEccnMaterialInfoService wmsEccnMaterialInfoService;

    @Autowired
    IWmsEccnControlInfoService wmsEccnControlInfoService;

    @ApiOperation("Eccn物料清单分页查询")
    @PostMapping("/list")
    R<PageDataDTO<SelectEccnMaterialInfoPageDTO>> selectEccnMaterialInfoPage(@RequestBody SelectEccnMaterialInfoPageVO vo) {
        return R.ok(wmsEccnMaterialInfoService.selectEccnMaterialInfoPage(vo, Boolean.TRUE));
    }

    @ApiOperation("Eccn物料清单导出")
    @PostMapping("/export")
    void exportEccnMaterialInfo(@RequestBody SelectEccnMaterialInfoPageVO vo, HttpServletResponse response){
        wmsEccnMaterialInfoService.exportEccnMaterialInfo(vo, response);
    }

    @ApiOperation("Eccn物料清单导入")
    @PostMapping("/import")
    R importEccnMaterialInfo(ImportEccnMaterialInfoVO vo){
        wmsEccnMaterialInfoService.importEccnMaterialInfo(vo);
        return R.ok();
    }

    @ApiOperation("ECCN报表PKG信息分页查询")
    @GetMapping("/selectEccnPkgReportPage")
    R<PageDataDTO<EccnReportDTO>> selectEccnPkgReportPage(SelectEccnReportPageVO vo){
        return R.ok(wmsEccnMaterialInfoService.selectEccnPkgReportPage(vo, Boolean.TRUE));
    }

    @ApiOperation("ECCN报表工單PKG信息分页查询")
    @GetMapping("/selectEccnPreparePkgReportPage")
    R<PageDataDTO<EccnReportDTO>> selectEccnPreparePkgReportPage(SelectEccnReportPageVO vo){
        return R.ok(wmsEccnMaterialInfoService.selectEccnPreparePkgReportPage(vo, Boolean.TRUE));
    }

    @ApiOperation("ECCN报表SFC信息分页查询")
    @GetMapping("/selectEccnSfcInfoReportPage")
    R<PageDataDTO<EccnReportDTO>> selectEccnSfcInfoReportPage(SelectEccnReportPageVO vo){
        return R.ok(wmsEccnMaterialInfoService.selectEccnSfcInfoReportPage(vo, Boolean.TRUE));
    }

    @ApiOperation("ECCN报表导出")
    @GetMapping("/selectEccnReportExport")
    void selectEccnReportExport(SelectEccnReportPageVO vo, HttpServletResponse response){
        wmsEccnMaterialInfoService.exportEccnReport(vo, response);
    }

    @ApiOperation("数据中台，同步ECCN信息接口")
    @GetMapping("/fetchEccnList")
    R<List<FetchEccnListDTO>> fetchEccnList(FetchEccnListVO vo){
        DataSourceUtil.setWmsDataSource();
        return R.ok(wmsEccnMaterialInfoService.fetchEccnList(vo));
    }

    @ApiOperation("数据中台，同步ECCN信息关联AVL信息接口")
    @GetMapping("/fetchEccnListByAvl")
    R<List<FetchEccnListByAvlDTO>> fetchEccnListByAvl(FetchEccnListByAvlVO vo){
        DataSourceUtil.setWmsDataSource();
        return R.ok(wmsEccnMaterialInfoService.fetchEccnListByAvl(vo));
    }

    @ApiOperation("同步ECCN信息接口by MFG")
    @GetMapping("/fetchEccnListByMfg")
    R<List<JusdaFetchEccnListDTO>> jusdaFetchEccnList(JusdaFetchEccnListVO vo){
        DataSourceUtil.setWmsDataSource();
        return R.ok(wmsEccnMaterialInfoService.jusdaFetchEccnList(vo));
    }

    @ApiOperation("同步ECCN管控ECCNNo接口")
    @GetMapping("/fetchControlEccnNoList")
    R<List<JusdaFetchControlEccnNoListDTO>> jusdaFetchControlEccnNoList(){
        DataSourceUtil.setWmsDataSource();
        return R.ok(wmsEccnMaterialInfoService.jusdaFetchControlEccnNoList());
    }

    @ApiOperation("查询ECCN管控列表")
    @GetMapping("/selectEccnControlInfoPage")
    R<PageDataDTO<WmsEccnControlInfo>> selectEccnControlInfoPage(SelectEccnControlInfoPageVO vo){
        return R.ok(wmsEccnControlInfoService.selectEccnControlInfoPage(vo, Boolean.TRUE));
    }

    @ApiOperation("添加ECCN管控")
    @PostMapping("/createEccnControlInfo")
    @RedisLock(value = "lock:eccnNoControl", param = "#vo.eccnNo")
    R createEccnControlInfo(@RequestBody CreateEccnControlInfoVO vo){
        wmsEccnControlInfoService.createEccnControlInfo(vo);
        return R.ok();
    }

    @ApiOperation("修改ECCN管控")
    @PostMapping("/updateEccnControlInfo")
    @RedisLock(value = "lock:eccnNoControl", param = "#vo.eccnNo")
    R updateEccnControlInfo(@RequestBody UpdateEccnControlInfoVO vo){
        wmsEccnControlInfoService.updateEccnControlInfo(vo);
        return R.ok();
    }

    @ApiOperation("删除ECCN管控")
    @DeleteMapping("/deleteEccnControlInfo")
    R deleteEccnControlInfo(@RequestBody DeleteEccnControlInfoVO vo){
        wmsEccnControlInfoService.deleteEccnControlInfo(vo);
        return R.ok();
    }
}
