package com.maxnerva.cloudmes.controller.basic;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.basic.WmsPostingScheduleLockConfigDTO;
import com.maxnerva.cloudmes.models.vo.CommonDeleteVO;
import com.maxnerva.cloudmes.models.vo.basic.CreatePostingScheduleLockConfigVO;
import com.maxnerva.cloudmes.models.vo.basic.UpdatePostingScheduleLockConfigVO;
import com.maxnerva.cloudmes.models.vo.basic.WmsPostingScheduleLockConfigVO;
import com.maxnerva.cloudmes.service.basic.IWmsPostingScheduleLockConfigService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Api(tags = "WMS过账周期锁定")
@Slf4j
@RestController
@RequestMapping("/postingScheduleLockConfig")
public class PostingScheduleLockConfigController {

    @Autowired
    IWmsPostingScheduleLockConfigService wmsPostingScheduleLockConfigService;

    @ApiOperation("分页查询")
    @GetMapping("/selectPageList")
    R<PageDataDTO<WmsPostingScheduleLockConfigDTO>> selectPageList(WmsPostingScheduleLockConfigVO vo){
        return R.ok(wmsPostingScheduleLockConfigService.selectPageList(vo));
    }

    @ApiOperation("创建")
    @PostMapping("/createOne")
    R create(@RequestBody CreatePostingScheduleLockConfigVO vo){
        wmsPostingScheduleLockConfigService.create(vo);
        return R.ok();
    }

    @ApiOperation("修改")
    @PostMapping("/updateOne")
    R updateOne(@RequestBody UpdatePostingScheduleLockConfigVO vo){
        wmsPostingScheduleLockConfigService.updateOne(vo);
        return R.ok();
    }

    @ApiOperation("删除")
    @PostMapping("/delete")
    R delete(@RequestBody CommonDeleteVO vo){
        wmsPostingScheduleLockConfigService.delete(vo);
        return R.ok();
    }


}
