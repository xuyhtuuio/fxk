package com.maxnerva.cloudmes.controller.wo;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.wo.WmsBomFeederDTO;
import com.maxnerva.cloudmes.models.vo.wo.BomFeederPageQueryVO;
import com.maxnerva.cloudmes.service.wo.IWmsBomFeederService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @ClassName BomFeederController
 * @Description 上料表管理
 * @Author Likun
 * @Date 2022/9/14
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "上料表管理")
@Slf4j
@RestController
@RequestMapping("/bomFeeder")
public class BomFeederController {

    @Resource
    private IWmsBomFeederService wmsBomFeederService;

    @ApiOperation("查询上料表信息")
    @PostMapping("/list")
    public R<PageDataDTO<WmsBomFeederDTO>> selectPage(@RequestBody BomFeederPageQueryVO pageQueryVO) {
        return R.ok(wmsBomFeederService.selectBomFeederPage(pageQueryVO));
    }
}
