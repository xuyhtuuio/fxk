package com.maxnerva.cloudmes.controller.warehouse;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.entity.warehouse.WmsSteelScrapWeightLog;
import com.maxnerva.cloudmes.models.dto.warehouse.SteelScrapWeightPageDTO;
import com.maxnerva.cloudmes.models.vo.warehouse.*;
import com.maxnerva.cloudmes.service.warehouse.IWmsSteelScrapWeightLogService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;

@Api(tags = "废钢称重管理")
@Slf4j
@RestController
@RequestMapping("/steelScrapWeight")
public class SteelScrapWeightController {
    @Autowired
    IWmsSteelScrapWeightLogService wmsSteelScrapWeightLogService;

    @ApiOperation("分页查询")
    @GetMapping("/selectPageList")
    R<PageDataDTO<SteelScrapWeightPageDTO>> selectPageList(SteelScrapWeightPageVO vo){
        return R.ok(wmsSteelScrapWeightLogService.selectPageList(vo, Boolean.TRUE));
    }

    @ApiOperation("导出")
    @GetMapping("/export")
    void export(SteelScrapWeightPageVO vo, HttpServletResponse response){
        wmsSteelScrapWeightLogService.export(vo, response);
    }

    @ApiOperation("添加")
    @PostMapping("/createOne")
    R createOne(@RequestBody CreateSteelScrapWeightVO vo){
        wmsSteelScrapWeightLogService.createOne(vo);
        return R.ok();
    }

    @ApiOperation("更新")
    @PutMapping("/updateOne")
    R updateOne(@RequestBody UpdateSteelScrapWeightVO vo){
        wmsSteelScrapWeightLogService.updateOne(vo);
        return R.ok();
    }

    @ApiOperation("导入")
    @PostMapping("/importList")
    R importList(ImportSteelScrapWeightVO vo){
        wmsSteelScrapWeightLogService.importList(vo);
        return R.ok();
    }

    @ApiOperation("扫描钢桶编号")
    @PostMapping("/scanSteelBarcode")
    R<WmsSteelScrapWeightLog> scanSteelBarcode(@RequestBody ScanSteelBarcodeVO vo){
        return R.ok(wmsSteelScrapWeightLogService.scanSteelBarcode(vo));
    }

    @ApiOperation("上传称重数据")
    @PostMapping("/checkSubmit")
    R checkSubmit(@RequestBody CheckSteelScrapWeightVO vo){
        wmsSteelScrapWeightLogService.checkSubmit(vo);
        return R.ok();
    }

    @ApiOperation("删除钢桶")
    @PostMapping("/delete")
    R delete(@RequestBody DeleteSteelScrapVO vo){
        wmsSteelScrapWeightLogService.delete(vo);
        return R.ok();
    }
}
