package com.maxnerva.cloudmes.controller.doc;

import cn.hutool.json.JSONUtil;
import com.maxnerva.cloudmes.aspect.FactoryOperationLog;
import com.maxnerva.cloudmes.common.constant.OperationTypeConstant;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.entity.flownet.FlownetResponse;
import com.maxnerva.cloudmes.excel.util.DataSourceUtil;
import com.maxnerva.cloudmes.models.dto.doc.TransferUploadDTO;
import com.maxnerva.cloudmes.models.dto.doc.WmsAdjustDto;
import com.maxnerva.cloudmes.models.dto.doc.WmsAdjustInfoDto;
import com.maxnerva.cloudmes.models.dto.warehouse.WmsPkgInfoDTO;
import com.maxnerva.cloudmes.models.vo.doc.*;
import com.maxnerva.cloudmes.models.vo.pulllist.PulllistExcelImportVO;
import com.maxnerva.cloudmes.service.doc.IWmsAdjustService;
import com.sap.conn.jco.JCoException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;

@Api(tags = "调整单管理")
@Slf4j
@RestController
@RequestMapping("/adjust")
public class WmsAdjustController {

    @Resource
    private IWmsAdjustService wmsAdjustService;

    @ApiOperation(value = "查询调整单信息")
    @GetMapping("/list")
    public R<PageDataDTO<WmsAdjustDto>> selectPage(WmsAdjustDcoVo pageQueryVO) {
        return R.ok(wmsAdjustService.selectPage(pageQueryVO));
    }

    @ApiOperation(value = "新增调整单信息")
    @PostMapping("/addAdjust")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "新增调整单信息")
    public R<Integer> saveCost(WmsAdjustAdjustSaveVo saveVo) throws JCoException {
        return R.ok(wmsAdjustService.saveAdjust(saveVo));
    }

    @ApiOperation(value = "调整单保存并提交")
    @PostMapping("/addAdjustAndUpload")
    public R<Integer> addAdjustAndUpload(WmsAdjustAdjustSaveVo saveVo) throws JCoException {
        wmsAdjustService.addAdjustAndUpload(saveVo);
        return R.ok();
    }

    @ApiOperation(value = "上传")
    @PostMapping("/upload")
    public R<TransferUploadDTO> upload(@RequestBody List<Integer> idList) {
        return R.ok(wmsAdjustService.upload(idList));
    }

    @ApiOperation("Agile审批完成调用服务节点")
    @PostMapping("/approvalCompleted")
    public R<Void> approvalCompleted(@RequestBody WmsAdjustApprovalVo adjustApprovalVo) {
        log.info(">>>>>>>>>>>>Agile input parameter:{}", JSONUtil.toJsonStr(adjustApprovalVo));
        return wmsAdjustService.approvalCompleted(adjustApprovalVo);
    }

    @ApiOperation(value = "Agile审批完成回调接口")
    @PostMapping("/agileApproval")
    public R<Void> agileApproval(@RequestBody List<WmsAdjustApprovalVo> adjustApprovalVoList) {
        wmsAdjustService.agileApproval(adjustApprovalVoList);
        return R.ok();
    }

    @ApiOperation("Flownet审核完成调用服务节点")
    @PostMapping("/flownetApprovalCompleted")
    public R<Void> flownetApprovalCompleted(@RequestBody String jsonString) {
        log.info("flownetApprovalCompleted input parameter requestJson:{}", jsonString);
        DataSourceUtil.setWmsDataSource();
        wmsAdjustService.flownetApprovalCompleted(jsonString);
        return R.ok();
    }

    @ApiOperation(value = "Flownet审核完成")
    @PostMapping("/flownetApproval")
    public R<Void> flownetApproval(@RequestBody List<WmsFlownetApprovalVo> wmsFlownetApprovalVoList) {
        wmsAdjustService.flownetApproval(wmsFlownetApprovalVoList);
        return R.ok();
    }

    @ApiOperation(value = "Flownet签核状态")
    @GetMapping("/approvalStatus")
    public R<FlownetResponse> approvalStatus(@RequestParam("docNo") String docNo,
                                             @RequestParam("creator") String creator) {
        return R.ok(wmsAdjustService.approvalStatus(docNo, creator));
    }

    @ApiOperation(value = "料件调整信息")
    @GetMapping("/adjustInfo")
    public R<WmsAdjustInfoDto> adjustInfo(Integer id) {
        return R.ok(wmsAdjustService.adjustInfo(id));
    }

    @ApiOperation(value = "提交料件调整")
    @PostMapping("/submitAdjustInfo")
    public R<HashMap> submitAdjustInfo(@RequestBody WmsAdjustInfoVO adjustInfoVO) {
        return R.ok(wmsAdjustService.submitAdjustInfo(adjustInfoVO));
    }

    @ApiOperation(value = "删除")
    @DeleteMapping("/delete")
    @FactoryOperationLog(operationType = OperationTypeConstant.DELETE, description = "删除")
    public R<Void> deleteAdjust(@RequestBody DeleteAdjustVO vo) {
        wmsAdjustService.deleteAdjust(vo);
        return R.ok();
    }

    @ApiOperation(value = "获取打印条码信息")
    @GetMapping("/getPrintInfo")
    public R<WmsPkgInfoDTO> getPrintInfo(@RequestParam("pkgId") String pkgId, @RequestParam("orgCode") String orgCode) {
        return R.ok(wmsAdjustService.getPrintInfo(pkgId, orgCode));
    }

    @ApiOperation(value = "手动确认")
    @PostMapping("/confirm")
    public R<Void> confirm(@RequestBody CostIssueReturnUserComfirmVO comfirmVO) {
        wmsAdjustService.confirm(comfirmVO);
        return R.ok();
    }

    @ApiOperation("导出")
    @PostMapping("/export")
    public R<Void> export(HttpServletResponse response,
                          @RequestBody WmsAdjustDcoVo vo) {
        wmsAdjustService.export(response, vo);
        return R.ok();
    }

    @ApiOperation("料调单导入")
    @PostMapping("/import")
    public R<Void> importList(PulllistExcelImportVO excelImportVO) throws JCoException {
        wmsAdjustService.importList(excelImportVO);
        return R.ok();
    }
}
