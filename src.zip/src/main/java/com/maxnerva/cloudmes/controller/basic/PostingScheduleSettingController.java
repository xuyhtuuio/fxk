package com.maxnerva.cloudmes.controller.basic;

import com.maxnerva.cloudmes.aspect.FactoryOperationLog;
import com.maxnerva.cloudmes.common.constant.OperationTypeConstant;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.basic.WmsPostingScheduleSettingDTO;
import com.maxnerva.cloudmes.models.vo.basic.WmsPostingScheduleSettingQueryVO;
import com.maxnerva.cloudmes.models.vo.basic.WmsPostingScheduleSettingUpdateVO;
import com.maxnerva.cloudmes.service.basic.IWmsPostingScheduleSettingService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @Author yjw
 * @Description WMS过账时间段设置
 * @Date 2023/5/31
 */
@Api(tags = "WMS过账时间段设置")
@Slf4j
@RestController
@RequestMapping("/postingScheduleSetting")
public class PostingScheduleSettingController {

    @Resource
    private IWmsPostingScheduleSettingService wmsPostingScheduleSettingService;

    @ApiOperation("获取WMS过账时间段设置信息")
    @PostMapping("/getDataList")
    public R<PageDataDTO<WmsPostingScheduleSettingDTO>> getAdviceRetrievalInfo(@RequestBody WmsPostingScheduleSettingQueryVO postingScheduleSettingQueryVO) {
        return R.ok(wmsPostingScheduleSettingService.selectPage(postingScheduleSettingQueryVO));
    }

    @ApiOperation("WMS过账时间段设置信息")
    @PostMapping("/update")
    @FactoryOperationLog(operationType = OperationTypeConstant.MODIFY, description = "修改WMS过账时间段设置信息")
    public R<Void> updatePostingScheduleSetting(@RequestBody WmsPostingScheduleSettingUpdateVO updateVO) {
        wmsPostingScheduleSettingService.updatePostingScheduleSetting(updateVO);
        return R.ok();
    }
}
