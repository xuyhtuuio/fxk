package com.maxnerva.cloudmes.controller.deliver;

import cn.hutool.core.io.FileUtil;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.aspect.FactoryOperationLog;
import com.maxnerva.cloudmes.common.constant.OperationTypeConstant;
import com.maxnerva.cloudmes.common.enums.ResultCode;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.entity.deliver.WmsDocProductShipDetail;
import com.maxnerva.cloudmes.enums.WmsMouldResultCode;
import com.maxnerva.cloudmes.models.dto.AssyShipSendToQmsDTO;
import com.maxnerva.cloudmes.models.dto.deliver.*;
import com.maxnerva.cloudmes.models.dto.doc.ShipMergePalletDTO;
import com.maxnerva.cloudmes.models.dto.warehouse.WmsPkgInfoDTO;
import com.maxnerva.cloudmes.models.vo.ExcelImportVO;
import com.maxnerva.cloudmes.models.vo.ProductShipQmsReturnListVO;
import com.maxnerva.cloudmes.models.vo.ProductShipQmsReturnVO;
import com.maxnerva.cloudmes.models.vo.deliver.*;
import com.maxnerva.cloudmes.service.deliver.IWmsProductShipService;
import com.maxnerva.cloudmes.service.sap.po.model.DnInfoDto;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.List;


/**
 * @author sclq
 * @date 2022/9/8 14:24
 */
@Api(tags = "成品出货")
@Slf4j
@RestController
@RequestMapping("/productShip")
public class WmsProductShipController {

    @Resource
    private IWmsProductShipService productShipService;

    @ApiOperation("新增预出货单")
    @PostMapping("/addPreShipDoc")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "新增预出货单")
    public R<WmsDocProductShipSaveDTO> addPreShipDoc(@RequestBody PreShipDocVO preShipDocVO) {
        return R.ok(productShipService.addPreShipDoc(preShipDocVO));
    }

    @ApiOperation("条件查询")
    @GetMapping("/pageList")
    public R<PageDataDTO<WmsDocProductShipDTO>> pageList(ProductShipPageQueryVO productShipPageQueryVO) {
        if (productShipPageQueryVO.getPageIndex() != null && productShipPageQueryVO.getPageSize() != null
                && productShipPageQueryVO.getPageIndex() != 0 && productShipPageQueryVO.getPageSize() != 0) {
            Page page = PageHelper.startPage(productShipPageQueryVO.getPageIndex(), productShipPageQueryVO.getPageSize());
            List<WmsDocProductShipDTO> shipDTOList = productShipService.selectHeaderList(productShipPageQueryVO);
            PageDataDTO<WmsDocProductShipDTO> wmsDeliverDtoPageDataDTO = new PageDataDTO<>(page.getTotal(), shipDTOList);
            return R.ok(wmsDeliverDtoPageDataDTO);
        } else {
            List<WmsDocProductShipDTO> shipDTOList = productShipService.selectHeaderList(productShipPageQueryVO);
            PageDataDTO<WmsDocProductShipDTO> wmsDeliverDtoPageDataDTO = new PageDataDTO<>((long) shipDTOList.size(), shipDTOList);
            return R.ok(wmsDeliverDtoPageDataDTO);
        }
    }

    @ApiOperation(value = "预出货保存并提交")
    @PostMapping("/addAndUpload")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "预出货保存并提交")
    public R<Integer> addAndUpload(@RequestBody PreShipDocVO preShipDocVO) {
        productShipService.addAndUpload(preShipDocVO);
        return R.ok();
    }

    @ApiOperation(value = "DN单保存并提交")
    @PostMapping("/addDnAndUpload")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "DN单保存并提交")
    public R<Integer> addDnAndUpload(@RequestBody DnShipDocVO dnShipDocVO) {
        productShipService.addDnAndUpload(dnShipDocVO);
        return R.ok();
    }

    @ApiOperation("根据单头查询明细")
    @GetMapping("/detailInfo")
    public R<List<WmsDocProductShipDetailDTO>> detailInfo(Integer headerId) {
        ProductShipDetailSelectVO detailSelectVO = new ProductShipDetailSelectVO();
        detailSelectVO.setHeaderId(headerId);
        List<WmsDocProductShipDetailDTO> detailList = productShipService.selectDetailList(detailSelectVO);
        return R.ok(detailList);
    }

    @ApiOperation("同步DN单")
    @GetMapping("/syncDnDoc")
    public R<DnInfoDto> syncDnDoc(String orgCode, String plantCode, String dnNo) {
        return R.ok(productShipService.syncDnDoc(orgCode, plantCode, dnNo));
    }

    @ApiOperation("新增DN出货单")
    @PostMapping("/addDNShipDoc")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "新增DN出货单")
    public R<WmsDocProductShipSaveDTO> addDNShipDoc(@RequestBody DnShipDocVO dnShipDocVO) {
        return R.ok(productShipService.addDNShipDoc(dnShipDocVO));
    }

    @ApiOperation("提交")
    @PostMapping("/submit")
    public R<Void> submit(@RequestBody List<Integer> idList) {
        productShipService.submit(idList);
        return R.ok();
    }

    @ApiOperation("删除")
    @DeleteMapping("/delete")
    @FactoryOperationLog(operationType = OperationTypeConstant.DELETE, description = "删除")
    public R<Void> delete(@RequestBody List<Integer> idList) {
        productShipService.delete(idList);
        return R.ok();
    }

    @ApiOperation("绑定DN单")
    @GetMapping("/bindingDn")
    public R<Void> bindingDn(Integer id, String dnNo, String siteCode) {
        productShipService.bindingDn(id, dnNo, siteCode);
        return R.ok();
    }

    @ApiOperation("查询预出货信息")
    @GetMapping("/preShipInfo")
    public R<WmsPreShipInfoDTO> preShipInfo(Integer id) {
        return R.ok(productShipService.preShipInfo(id));
    }

    @ApiOperation("预出货推荐PKGID")
    @GetMapping("/recommendPkg")
    public R<List<WmsProductShipRecommendPkgDTO>> recommendPkg(@RequestParam("orgCode") String orgCode,
                                                               @RequestParam(value = "cusNo", required = false) String cusNo,
                                                               @RequestParam(value = "sapWarehouseCode", required = false) String sapWarehouseCode,
                                                               @RequestParam(value = "partNo", required = false) String partNo,
                                                               @RequestParam(value = "partVersion", required = false) String partVersion,
                                                               @RequestParam(value = "pkgId", required = false) String pkgId,
                                                               @RequestParam(value = "docType") String docType,
                                                               @RequestParam(value = "siNo", required = false) String siNo,
                                                               @RequestParam(value = "poNo", required = false) String poNo) {
        return R.ok(productShipService.recommendPkg(orgCode, cusNo, sapWarehouseCode, partNo, docType, partVersion,
                pkgId, siNo, poNo));
    }

    @ApiOperation("出货推荐PKGID")
    @GetMapping("/shipRecommendPkg")
    public R<List<WmsPkgInfoDTO>> shipRecommendPkg(@RequestParam("detailId") Integer detailId) {
        return R.ok(productShipService.shipRecommendPkg(detailId));
    }

    @ApiOperation("预出货绑定PKGID提交")
    @PostMapping("/preShipBindingPkg")
    public R<Void> preShipBindingPkg(@RequestBody PreShipBindingPkgVO bindingPkgVO) {
        productShipService.preShipBindingPkg(bindingPkgVO);
        return R.ok();
    }

    @ApiOperation("预出货绑定查询")
    @GetMapping("/selectPreShipBindingPkg")
    public R<List<WmsShipPkgBindRecordDTO>> selectPreShipBindingPkg(Integer id) {
        return R.ok(productShipService.selectPreShipBindingPkg(id));
    }

    @ApiOperation("出库执行提交")
    @PostMapping("/shipSubmit")
    public R<Void> shipSubmit(@RequestBody ShipSubmitVO shipSubmitVO) {
        return productShipService.shipSubmit(shipSubmitVO);
    }

    @ApiOperation("条码明细查询")
    @GetMapping("/bindPkgIdList")
    public R<PageDataDTO<WmsShipPkgBindRecordDTO>> bindPkgIdList(Integer id, Integer pageIndex, Integer pageSize) {
        if (pageIndex != null && pageSize != null && pageIndex != 0 && pageSize != 0) {
            Page page = PageHelper.startPage(pageIndex, pageSize);
            List<WmsShipPkgBindRecordDTO> pkgBindRecordDTOList = productShipService.selectBindPkgIdListByHeaderId(id);
            PageDataDTO<WmsShipPkgBindRecordDTO> wmsDeliverDtoPageDataDTO = new PageDataDTO<>(page.getTotal(), pkgBindRecordDTOList);
            return R.ok(wmsDeliverDtoPageDataDTO);
        } else {
            List<WmsShipPkgBindRecordDTO> pkgBindRecordDTOList = productShipService.selectBindPkgIdListByHeaderId(id);
            PageDataDTO<WmsShipPkgBindRecordDTO> wmsDeliverDtoPageDataDTO = new PageDataDTO<>((long) pkgBindRecordDTOList.size(), pkgBindRecordDTOList);
            return R.ok(wmsDeliverDtoPageDataDTO);
        }
    }

    @ApiOperation("预出货明细导入")
    @PostMapping("/importPreDetailExcel")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "预出货明细导入")
    public R<List<WmsDocProductShipDetail>> importPreDetailExcel(MultipartFile file) throws IOException {
        String fileExt = FileUtil.extName(file.getOriginalFilename());
        if (fileExt == null || (!"xls".equals(fileExt.toLowerCase()) && !"xlsx".equals(fileExt.toLowerCase()))) {
            return R.no(MessageUtils.get(WmsMouldResultCode.UNSUPPORTED_FILE_TYPES.getLocalCode()));
        }
        return R.ok(productShipService.importPreDetailExcel(file));
    }

    @ApiOperation("预出货导入单头、明细")
    @PostMapping("/importPreExcel")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "预出货导入单头、明细")
    public R<Void> importPreExcel(ExcelImportVO importVO) throws IOException {
        MultipartFile file = importVO.getFile();
        String orgCode = importVO.getOrgCode();
        String fileExt = FileUtil.extName(file.getOriginalFilename());
        if (fileExt == null || (!"xls".equals(fileExt.toLowerCase()) && !"xlsx".equals(fileExt.toLowerCase()))) {
            return R.no(MessageUtils.get(WmsMouldResultCode.UNSUPPORTED_FILE_TYPES.getLocalCode()));
        }
        productShipService.importPreExcel(file, orgCode);
        return R.ok();
    }

    @ApiOperation("成品出货单抛Q")
    @PostMapping("/sendToQms")
    public R<Void> sendToQms() {
        productShipService.sendToQms();
        return R.ok();
    }

    @ApiOperation("QMS返回结果")
    @PostMapping("/qmsReturn")
    public R<Void> qmsReturn(@RequestBody ProductShipQmsReturnVO vo) {
        productShipService.qmsReturn(vo);
        return R.ok();
    }

    @ApiOperation("APP可预出货明细查询")
    @GetMapping("/appShipList")
    public R<PageDataDTO<AppShipListDTO>> appShipList(ShipListAppVO shipListAppVO) {
        if (shipListAppVO.getPageIndex() != null && shipListAppVO.getPageSize() != null
                && shipListAppVO.getPageIndex() != 0 && shipListAppVO.getPageSize() != 0) {
            Page page = PageHelper.startPage(shipListAppVO.getPageIndex(), shipListAppVO.getPageSize());
            List<AppShipListDTO> shipDTOList = productShipService.appShipList(shipListAppVO);
            PageDataDTO<AppShipListDTO> wmsDeliverDtoPageDataDTO = new PageDataDTO<>(page.getTotal(), shipDTOList);
            return R.ok(wmsDeliverDtoPageDataDTO);
        } else {
            List<AppShipListDTO> shipDTOList = productShipService.appShipList(shipListAppVO);
            PageDataDTO<AppShipListDTO> wmsDeliverDtoPageDataDTO = new PageDataDTO<>((long) shipDTOList.size(), shipDTOList);
            return R.ok(wmsDeliverDtoPageDataDTO);
        }
    }

    @Deprecated
    @ApiOperation("APP推荐直备信息")
    @GetMapping("/appRecommendInfo")
    public R<AppShipRecommendDTO> appRecommendInfo(@RequestParam("detailId") Integer detailId) {
        return R.ok(productShipService.appRecommendInfo(detailId));
    }

    @Deprecated
    @ApiOperation("根据栈板查询箱号信息")
    @GetMapping("/selectCartonInfo")
    public R<PageDataDTO<WmsPreShipCartonDTO>> selectCartonInfo(PreShipCartonInfoVO preShipCartonInfoVO) {
        return R.ok(productShipService.selectCartonInfo(preShipCartonInfoVO));
    }

    @ApiOperation("APP预出货推荐PKGID")
    @GetMapping("/appRecommendPkg")
    public R<List<AppRecommendPkgDTO>> appRecommendPkg(@RequestParam("orgCode") String orgCode,
                                                       @RequestParam(value = "cusNo", required = false) String cusNo,
                                                       @RequestParam(value = "sapWarehouseCode", required = false) String sapWarehouseCode,
                                                       @RequestParam(value = "partNo", required = false) String partNo,
                                                       @RequestParam(value = "docType") String docType,
                                                       @RequestParam(value = "partVersion") String partVersion) {
        return R.ok(productShipService.appRecommendPkg(orgCode, cusNo, sapWarehouseCode, partNo, docType, partVersion));
    }

    @ApiOperation("组装段同步DN信息")
    @PostMapping("/assySyncDnDoc")
    public R<Void> assySyncDnDoc(@RequestBody AssySyncDnInfoVO assySyncDnInfoVO) {
        productShipService.assySyncDnDoc(assySyncDnInfoVO);
        return R.ok();
    }

    @ApiOperation("新出货扫描信息")
    @GetMapping("/newShipInfo")
    public R<WmsNewShipInfoDTO> newShipInfo(@RequestParam("no") String no,
                                            @RequestParam("type") String type,
                                            @RequestParam("plantCode") String plantCode,
                                            @RequestParam("orgCode") String orgCode) {
        return R.ok(productShipService.newShipInfo(no, type, orgCode, plantCode));
    }

    @ApiOperation("新出库执行提交")
    @PostMapping("/newShipSubmit")
    public R<Void> newShipSubmit(@RequestBody NewShipSubmitVO newShipSubmitVO) {
        return productShipService.newShipSubmit(newShipSubmitVO);
    }

    @ApiOperation("根据内交单号查询内交单信息")
    @GetMapping("/getTradingInfo")
    public R<ShipTradingInfoDTO> getTradingInfoByDn(@RequestParam("orgCode") String orgCode,
                                                    @RequestParam("plantCode") String plantCode,
                                                    @RequestParam("dnNo") String dnNo) {
        return R.ok(productShipService.getTradingInfoByDn(orgCode, plantCode, dnNo));
    }

    @ApiOperation("成品出货合板-扫描箱号")
    @GetMapping("/scanCartonNo")
    public R<List<MergePalletScanCartonNoDTO>> scanCartonNo(@RequestParam("orgCode") String orgCode,
                                                            @RequestParam("cartonNo") String cartonNo) {
        return R.ok(productShipService.scanCartonNo(orgCode, cartonNo));
    }

    @ApiOperation("成品出货合板-提交")
    @PostMapping("/submitMergePallet")
    public R<ShipMergePalletDTO> submitMergePallet(@RequestBody ShipMergePalletVO shipMergePalletVO) {
        return R.ok(MessageUtils.get(ResultCode.SUCCESS.getLocalCode()),
                productShipService.submitMergePallet(shipMergePalletVO));
    }

    @ApiOperation("出货合板列印")
    @PostMapping("/printMergePalletLabel")
    public R<PrintShipMergePalletLabelDTO> printMergePalletLabel(@RequestBody PrintMergePalletVO printMergePalletVO) {
        return R.ok(productShipService.printMergePalletLabel(printMergePalletVO));
    }

    @ApiOperation("出货合板条码补印-扫描箱号")
    @GetMapping("/againScanCartonNo")
    public R<List<MergePalletScanCartonNoDTO>> againScanCartonNo(@RequestParam("orgCode") String orgCode,
                                                                 @RequestParam("cartonNo") String cartonNo) {
        return R.ok(productShipService.againScanCartonNo(orgCode, cartonNo));
    }

    @ApiOperation("栈板出货查询")
    @PostMapping("/palletShipInfo")
    public R<List<PalletShipInfoDTO>> palletShipInfo(@RequestBody List<Integer> detailIdList) {
        return R.ok(productShipService.palletShipInfo(detailIdList));
    }

    @ApiOperation("栈板出货提交")
    @PostMapping("/palletNoShipSubmit")
    public R<Void> palletNoShipSubmit(@RequestBody PalletNoShipSubmitVO palletNoShipSubmitVO) {
        return productShipService.palletNoShipSubmit(palletNoShipSubmitVO);
    }

    @ApiOperation("实时装货信息抛Q")
    @GetMapping("/assySendToQms")
    public R<List<AssyShipSendToQmsDTO>> assySendToQms(@RequestParam("orgCode") String orgCode,
                                                       @RequestParam("plantCode") String plantCode,
                                                       @RequestParam("containerNo") String containerNo,
                                                       @RequestParam("shipFlag") String shipFlag) {
        return R.ok(productShipService.assySendToQms(orgCode, plantCode, containerNo, shipFlag));
    }

    @ApiOperation("QMS批量返回结果")
    @PostMapping("/qmsReturnList")
    public R<Void> qmsReturnList(@RequestBody ProductShipQmsReturnListVO listVO) {
        productShipService.qmsReturnList(listVO);
        return R.ok();
    }

    @ApiOperation("出货合板DELL列印")
    @PostMapping("/printMergeDellPalletLabel")
    public R<PrintShipMergeDellPalletLabelDTO> printMergeDellPalletLabel(@RequestBody PrintMergePalletVO printMergePalletVO) {
        return R.ok(productShipService.printMergeDellPalletLabel(printMergePalletVO));
    }

    @ApiOperation("出货合板MS列印")
    @PostMapping("/printMergeMsPalletLabel")
    public R<PrintShipMergeMsPalletLabelDTO> printMergeMsPalletLabel(@RequestBody PrintMergePalletVO printMergePalletVO) {
        return R.ok(productShipService.printMergeMsPalletLabel(printMergePalletVO));
    }

    @ApiOperation("出货合板Qolsys列印")
    @PostMapping("/printMergeQolsysPalletLabel")
    public R<PrintShipMergeQolsysPalletLabelDTO> printMergeQolsysPalletLabel(@RequestBody PrintMergePalletVO printMergePalletVO) {
        return R.ok(productShipService.printMergeQolsysPalletLabel(printMergePalletVO));
    }

    @ApiOperation("app出货合板DELL列印")
    @PostMapping("/printZplDellPalletLabel")
    public R<PrintShipMergeDellLabelZplDTO> printZplDellPalletLabel(@RequestBody PrintMergePalletVO printMergePalletVO) {
        return R.ok(productShipService.printZplDellPalletLabel(printMergePalletVO));
    }

    @ApiOperation("HPE出货合板列印")
    @PostMapping("/printHpePalletLabel")
    public R<PrintShipHpePalletLabelDTO> printHpePalletLabel(@RequestBody PrintMergePalletVO printMergePalletVO){
        return R.ok(productShipService.printHpePalletLabel(printMergePalletVO));
    }

    @ApiOperation("BD出货合板列印")
    @PostMapping("/printBdPalletLabel")
    public R<PrintShipBdPalletLabelDTO> printBdPalletLabel(@RequestBody PrintMergePalletVO printMergePalletVO){
        return R.ok(productShipService.printBdPalletLabel(printMergePalletVO));
    }

    @ApiOperation("是否SN扫描查询")
    @GetMapping("/getScanSnFlag")
    public R<Boolean> getScanSnFlag(@RequestParam("orgCode") String orgCode) {
        return R.ok(productShipService.getScanSnFlag(orgCode));
    }
}
