package com.maxnerva.cloudmes.controller.doc;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.doc.WmsDocFieldDTO;
import com.maxnerva.cloudmes.models.vo.doc.DocFieldPageQueryVO;
import com.maxnerva.cloudmes.models.vo.doc.WmsDocFieldVO;
import com.maxnerva.cloudmes.service.doc.IWmsDocFieldService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * @ClassName DocFieldController
 * @Description 字符(单据属性)管理
 * @Author Likun
 * @Date 2022/7/26
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "字符(单据属性)管理")
@Slf4j
@RestController
@RequestMapping("/docField")
public class DocFieldController {

    @Resource
    private IWmsDocFieldService wmsDocFieldService;

    @ApiOperation("新增字符")
    @PostMapping("/add")
    public R<Void> saveField(@Valid @RequestBody WmsDocFieldVO fieldVO) {
        wmsDocFieldService.saveField(fieldVO);
        return R.ok();
    }

    @ApiOperation("修改字符")
    @PutMapping("/update")
    public R<Void> updateField(@Valid @RequestBody WmsDocFieldVO fieldVO) {
        wmsDocFieldService.updateField(fieldVO);
        return R.ok();
    }

    @ApiOperation("删除字符")
    @DeleteMapping("/delete")
    public R<Void> deleteField(@RequestBody List<Integer> idList) {
        wmsDocFieldService.deleteFieldBatch(idList);
        return R.ok();
    }

    @ApiOperation("查询字符信息")
    @PostMapping("/list")
    public R<PageDataDTO<WmsDocFieldDTO>> selectPage(@RequestBody DocFieldPageQueryVO queryVO) {
        return R.ok(wmsDocFieldService.selectPage(queryVO));
    }
}
