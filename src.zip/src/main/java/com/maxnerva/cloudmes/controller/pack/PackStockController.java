package com.maxnerva.cloudmes.controller.pack;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.pack.WmsPackStockDetailDTO;
import com.maxnerva.cloudmes.models.dto.pack.WmsPackStockHeaderDTO;
import com.maxnerva.cloudmes.models.vo.pack.PackApprovalVO;
import com.maxnerva.cloudmes.models.vo.pack.PackWoStockDetailQueryVO;
import com.maxnerva.cloudmes.models.vo.pack.PackWoStockHeaderQueryVO;
import com.maxnerva.cloudmes.service.pack.IWmsPackStockDetailService;
import com.maxnerva.cloudmes.service.pack.IWmsPackStockHeaderService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @ClassName PackStockController
 * @Description TODO
 * @Author Likun
 * @Date 2024/12/6
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "包材发料单管理")
@Slf4j
@RestController
@RequestMapping("/packStock")
public class PackStockController {

    @Resource
    private IWmsPackStockHeaderService wmsPackStockHeaderService;

    @Resource
    private IWmsPackStockDetailService wmsPackStockDetailService;

    @ApiOperation("查询发料单单头信息")
    @PostMapping("/headerList")
    public R<PageDataDTO<WmsPackStockHeaderDTO>> selectStockHeaderPage(@RequestBody PackWoStockHeaderQueryVO queryVO) {
        return R.ok(wmsPackStockHeaderService.selectStockHeaderPage(queryVO));
    }

    @ApiOperation("查询发料单明细信息")
    @PostMapping("/detailList")
    public R<PageDataDTO<WmsPackStockDetailDTO>> selectStockDetailPage(@RequestBody PackWoStockDetailQueryVO queryVO) {
        return R.ok(wmsPackStockDetailService.selectStockDetailPage(queryVO));
    }

    @ApiOperation("签核")
    @PostMapping("/approvalSubmit")
    public R<Void> approvalSubmit(@RequestBody PackApprovalVO packApprovalVO){
        wmsPackStockDetailService.approvalSubmit(packApprovalVO);
        return R.ok();
    }
}
