package com.maxnerva.cloudmes.controller.prepare;

import com.maxnerva.cloudmes.aspect.FactoryOperationLog;
import com.maxnerva.cloudmes.common.constant.OperationTypeConstant;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.prepare.WmsMaterialUsageConfigDTO;
import com.maxnerva.cloudmes.models.vo.ExcelImportVO;
import com.maxnerva.cloudmes.models.vo.prepare.WmsMaterialUsageConfigPageQueryVO;
import com.maxnerva.cloudmes.models.vo.prepare.WmsMaterialUsageConfigSaveVo;
import com.maxnerva.cloudmes.service.prepare.IWmsMaterialUsageConfigService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @Author hgx
 * @Description 物控锁料管理
 * @Date 2023/5/22
 */
@Api(tags = "物控锁料管理")
@Slf4j
@RestController
@RequestMapping("/materialUsageConfig")
public class WmsMaterialUsageConfigController {
    @Resource
    private IWmsMaterialUsageConfigService wmsMaterialUsageConfigService;

    @ApiOperation(value = "新增物控锁料信息")
    @PostMapping("/add")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "新增物控锁料信息")
    public R<Void> saveMaterialUsageConfig(@RequestBody WmsMaterialUsageConfigSaveVo saveVo) {
        wmsMaterialUsageConfigService.saveMaterialUsageConfig(saveVo);
        return R.ok();
    }

    @ApiOperation("删除物控锁料")
    @DeleteMapping("/delete")
    @FactoryOperationLog(operationType = OperationTypeConstant.DELETE, description = "删除物控锁料")
    public R<Void> deleteMaterialUsageConfig(@RequestBody List<Integer> idList) {
        wmsMaterialUsageConfigService.deleteBatch(idList);
        return R.ok();
    }

    @ApiOperation("编辑物控锁料信息")
    @GetMapping("/editInfo")
    public R<WmsMaterialUsageConfigDTO> editInfo(@RequestParam("id") Integer id) {
        return R.ok(wmsMaterialUsageConfigService.editInfo(id));
    }

    @ApiOperation("编辑保存物控锁料信息")
    @PostMapping("/editSave")
    public R<WmsMaterialUsageConfigDTO> editSave(@RequestBody WmsMaterialUsageConfigSaveVo saveVo) {
        wmsMaterialUsageConfigService.editSave(saveVo);
        return R.ok();
    }

    @ApiOperation("物控锁料列表")
    @GetMapping("/list")
    public R<PageDataDTO<WmsMaterialUsageConfigDTO>> selectList(WmsMaterialUsageConfigPageQueryVO pageQueryVo) {
        return R.ok(wmsMaterialUsageConfigService.selectList(pageQueryVo));
    }

    @ApiOperation("导入")
    @PostMapping("/import")
    public R<Void> importWmsMaterialUsageConfig(ExcelImportVO excelImportVO) {
        wmsMaterialUsageConfigService.importWmsMaterialUsageConfig(excelImportVO.getFile(), excelImportVO.getOrgCode());
        return R.ok();
    }

    @ApiOperation("导出")
    @PostMapping("/export")
    public R<Void> exportMaterialUsageConfigInfo(HttpServletResponse response,
                                                 @RequestBody WmsMaterialUsageConfigPageQueryVO pageQueryVo){
        wmsMaterialUsageConfigService.exportMaterialUsageConfigInfo(response,pageQueryVo);
        return R.ok();
    }
}
