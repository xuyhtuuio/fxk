package com.maxnerva.cloudmes.controller.assyprepare;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.assyprepare.AssyAdviceRetrievalDTO;
import com.maxnerva.cloudmes.models.dto.assyprepare.WoPickTaskDTO;
import com.maxnerva.cloudmes.models.dto.assyprepare.WoUnPickDTO;
import com.maxnerva.cloudmes.models.vo.assyprepare.*;
import com.maxnerva.cloudmes.service.assyprepare.IWmsAgvTaskListService;
import com.maxnerva.cloudmes.service.assyprepare.IWmsAssyPickService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @ClassName AssyWoPickController
 * @Description 机构段工单捡料管理
 * @Author Likun
 * @Date 2024/5/11
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "机构段工单捡料管理")
@Slf4j
@RestController
@RequestMapping("/assyWoPick")
public class AssyWoPickController {

    @Resource
    private IWmsAssyPickService wmsAssyPickService;

    @Resource
    private IWmsAgvTaskListService wmsAgvTaskListService;

    @ApiOperation("分页查询捡料清单")
    @PostMapping("/list")
    public R<PageDataDTO<WoPickTaskDTO>> selectWoPickTaskPage(@RequestBody AssyPickTaskQueryVO queryVO) {
        return R.ok(wmsAssyPickService.selectWoPickTaskPage(queryVO));
    }

    @ApiOperation("获取取料信息")
    @PostMapping("/getAdviceRetrievalInfo")
    public R<AssyAdviceRetrievalDTO> getAdviceRetrievalInfo(@RequestBody AssyAdviceRetrievalVO adviceRetrievalVO) {
        return R.ok(wmsAssyPickService.getAdviceRetrievalInfo(adviceRetrievalVO));
    }

    @ApiOperation("校验捡料载具")
    @PostMapping("/checkPickVehicle")
    public R<Void> checkPickVehicle(@RequestBody AssyVehicleScanVO vehicleScanVO) {
        wmsAssyPickService.checkPickVehicle(vehicleScanVO);
        return R.ok();
    }

    @ApiOperation("分页查询待捡料清单")
    @PostMapping("/unPicklist")
    public R<PageDataDTO<WoUnPickDTO>> selectWoUnPickPage(@RequestBody WoUnPickQueryVO queryVO) {
        return R.ok(wmsAssyPickService.selectWoUnPickPage(queryVO));
    }

    @ApiOperation("提交捡料信息")
    @PostMapping("/submitAssyPickInfo")
    public R<Void> submitAssyPickInfo(@RequestBody AssyPickSubmitVO assyPickSubmitVO) {
        wmsAssyPickService.submitAssyPickInfo(assyPickSubmitVO);
        return R.ok();
    }

    @ApiOperation("叫AGV")
    @PostMapping("/callAgv")
    public R<Void> callAgv(@RequestBody CallAgvVO callAgvVO) {
        return wmsAgvTaskListService.callAgv(callAgvVO);
    }
}
