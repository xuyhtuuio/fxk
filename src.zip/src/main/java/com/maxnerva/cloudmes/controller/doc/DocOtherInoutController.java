package com.maxnerva.cloudmes.controller.doc;

import cn.hutool.core.io.FileUtil;
import com.maxnerva.cloudmes.aspect.FactoryOperationLog;
import com.maxnerva.cloudmes.common.constant.OperationTypeConstant;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.enums.WmsMouldResultCode;
import com.maxnerva.cloudmes.models.dto.doc.DocShelfDTO;
import com.maxnerva.cloudmes.models.dto.doc.WmsCostRemoveShelfInfoDTO;
import com.maxnerva.cloudmes.models.dto.doc.WmsDocOtherInoutDTO;
import com.maxnerva.cloudmes.models.dto.doc.WmsDocOtherInoutShelfDTO;
import com.maxnerva.cloudmes.models.vo.doc.DocOtherInoutExcelImportVO;
import com.maxnerva.cloudmes.models.vo.doc.DocOtherInoutQueryVO;
import com.maxnerva.cloudmes.models.vo.doc.DocOtherInoutRemoveShelfVO;
import com.maxnerva.cloudmes.models.vo.doc.WmsDocOtherInoutVO;
import com.maxnerva.cloudmes.models.vo.warehouse.DocShelfByPnVO;
import com.maxnerva.cloudmes.models.vo.warehouse.DocShelfVO;
import com.maxnerva.cloudmes.service.doc.IWmsDocOtherInoutService;
import com.sap.conn.jco.JCoException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@Api(tags = "其他出入库单据管理")
@Slf4j
@RestController
@RequestMapping("/otherInout")
public class DocOtherInoutController {

    @Resource
    private IWmsDocOtherInoutService wmsDocOtherInoutService;


    @ApiOperation("查询其他出入库单信息")
    @GetMapping("/list")
    public R<PageDataDTO<WmsDocOtherInoutDTO>> selectReceivePage(DocOtherInoutQueryVO queryVO) {
        return R.ok(wmsDocOtherInoutService.selectOtherInoutPage(queryVO));
    }

    @ApiOperation("新增其他出入库单")
    @PostMapping("/add")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "新增其他出入库单")
    public R<Void> saveDocOtherInout(@RequestBody WmsDocOtherInoutVO docOtherInoutVO) throws JCoException {
        return R.ok(wmsDocOtherInoutService.saveDocOtherInout(docOtherInoutVO));
    }

    @ApiOperation("删除其他出入库单信息")
    @DeleteMapping("/delete")
    @FactoryOperationLog(operationType = OperationTypeConstant.DELETE, description = "删除其他出入库单")
    public R<Void> deleteDocOtherInout(@RequestBody List<Integer> idList) {
        wmsDocOtherInoutService.deleteDocOtherInout(idList);
        return R.ok();
    }

    @ApiOperation("其他出入库单excel导入")
    @PostMapping("/import")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "新增其他出入库单")
    public R<Void> importOtherInout(DocOtherInoutExcelImportVO excelImportVO) throws JCoException {
        String fileExt = FileUtil.extName(excelImportVO.getFile().getOriginalFilename());
        if (fileExt == null || (!"xls".equals(fileExt.toLowerCase()) && !"xlsx".equals(fileExt.toLowerCase()))) {
            return R.no(MessageUtils.get(WmsMouldResultCode.UNSUPPORTED_FILE_TYPES.getLocalCode()));
        }
        wmsDocOtherInoutService.importOtherInout(excelImportVO.getOrgCode(), excelImportVO.getDocTypeCode(),
                excelImportVO.getFile());
        return R.ok();
    }

    @ApiOperation("其他入库单上架")
    @PostMapping("/docShelf")
    public R<DocShelfDTO> docShelf(@RequestBody DocShelfVO docShelfVO) {
        return R.ok(wmsDocOtherInoutService.docShelf(docShelfVO));
    }

    @ApiOperation("其他出库单下架")
    @PostMapping("/removeShelf")
    public R<Void> removeShelf(@RequestBody DocOtherInoutRemoveShelfVO removeShelfVO) {
        wmsDocOtherInoutService.removeShelf(removeShelfVO);
        return R.ok();
    }

    @ApiOperation(value = "上架信息")
    @GetMapping("/shelfInfo")
    public R<WmsDocOtherInoutShelfDTO> shelfInfo(@RequestParam("id") Integer id, @RequestParam("orgCode") String orgCode) {
        return R.ok(wmsDocOtherInoutService.shelfInfo(id, orgCode));
    }

    @ApiOperation(value = "下架推荐载具、储位、pkgid")
    @GetMapping("/recommend")
    public R<WmsCostRemoveShelfInfoDTO> recommend(@RequestParam("id") Integer id, @RequestParam("orgCode") String orgCode) {
        return R.ok(wmsDocOtherInoutService.recommend(id, orgCode));
    }

    @ApiOperation("PN单据上架")
    @PostMapping("/docShelfByPnMode")
    public R<DocShelfDTO> docShelfByPnMode(@RequestBody DocShelfByPnVO docShelfByPnVO) {
        return R.ok(wmsDocOtherInoutService.docShelfByPnMode(docShelfByPnVO));
    }
}
