package com.maxnerva.cloudmes.controller.doc;

import cn.hutool.http.HttpResponse;
import com.alibaba.fastjson2.JSON;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.doc.LrrPkgInfoDTO;
import com.maxnerva.cloudmes.models.dto.doc.LrrReceiveSnListPageDTO;
import com.maxnerva.cloudmes.models.dto.warehouse.PkgPrintDTO;
import com.maxnerva.cloudmes.models.vo.ExcelImportVO;
import com.maxnerva.cloudmes.models.vo.doc.*;
import com.maxnerva.cloudmes.service.datahub.DataHubService;
import com.maxnerva.cloudmes.service.doc.IWmsLrrReceiveSnListService;
import com.maxnerva.cloudmes.service.warehouse.IWmsPkgSfcImportInfoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;

@Api(tags = "LRR入库明细管理")
@Slf4j
@RestController
@RequestMapping("/lrrReceive")
public class LrrReceiveSnController {

    @Autowired
    IWmsLrrReceiveSnListService wmsLrrReceiveSnListService;

    @Autowired
    private DataHubService dataHubService;

    @Autowired
    private IWmsPkgSfcImportInfoService wmsPkgSfcImportInfoService;


    @ApiOperation("分页查询")
    @GetMapping("/selectPageList")
    R<PageDataDTO<LrrReceiveSnListPageDTO>> selectPageList(LrrReceiveSnListPageVO vo){
        return R.ok(wmsLrrReceiveSnListService.selectPageList(vo, Boolean.TRUE));
    }

    @ApiOperation("导出明细")
    @GetMapping("/exportDetail")
    void exportDetail(LrrReceiveSnListPageVO vo, HttpServletResponse response){
        wmsLrrReceiveSnListService.exportDetail(vo, response);
    }

    @ApiOperation("导入明细")
    @PostMapping("/importDetail")
    void importDetail(ExcelImportVO vo, HttpServletResponse response){
        wmsLrrReceiveSnListService.importDetail(vo, response);
    }

    @ApiOperation("来源单号是否有效")
    @GetMapping("/validFromDocNo")
    R validFromDocNo(LrrValidFromDocNoVO vo){
        wmsLrrReceiveSnListService.validFromDocNo(vo);
        return R.ok();
    }


    @ApiOperation("查询装箱信息")
    @GetMapping("/pkgInfo")
    R<LrrPkgInfoDTO> pkgInfo(LrrPkgInfoVO vo){
        return R.ok(wmsLrrReceiveSnListService.pkgInfo(vo));
    }

    @ApiOperation("扫描SN提交")
    @PostMapping("/submit")
    R submit(@RequestBody LrrScanSubmitVO vo){
        wmsLrrReceiveSnListService.submit(vo);
        return R.ok();
    }

    @ApiOperation("结束装箱")
    @PostMapping("/closePkgId")
    R<PkgPrintDTO> closePkgId(@RequestBody LrrClosePkgIdVO vo){
        return R.ok(wmsLrrReceiveSnListService.closePkgId(vo));
    }

    @ApiOperation("提供MES查询接口（不调用）")
    @GetMapping("/dataHub/selectLrrReceiveSnInfo")
    R<LrrReceiveSnListPageDTO> selectLrrReceiveSnInfoDataHub(String orgCode, String actualSn){
        return R.ok(wmsLrrReceiveSnListService.selectLrrReceiveSnInfo(orgCode, actualSn));
    }

    @ApiOperation("提供MES查询接口")
    @GetMapping("/selectLrrReceiveSnInfo")
    R<LrrReceiveSnListPageDTO> selectLrrReceiveSnInfo(String orgCode, String actualSn){
        HttpResponse response = dataHubService.selectLrrReceiveSnInfo(orgCode, actualSn);
        R r = JSON.parseObject(response.body(), R.class);
        if (r.isSuccess()){
            return R.ok(r.getData());
        } else {
            return r;
        }

    }

    @ApiOperation("导入初始SN数据")
    @PostMapping("/importPkgSfcInfo")
    R importPkgSfcInfo(ExcelImportVO vo){
        wmsPkgSfcImportInfoService.importDetail(vo);
        return R.ok();
    }
}
