package com.maxnerva.cloudmes.controller.doc;

import com.maxnerva.cloudmes.aspect.FactoryOperationLog;
import com.maxnerva.cloudmes.common.constant.OperationTypeConstant;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.entity.warehouse.WmsPkgInfo;
import com.maxnerva.cloudmes.enums.WmsMouldResultCode;
import com.maxnerva.cloudmes.models.dto.PoItemDTO;
import com.maxnerva.cloudmes.models.dto.basic.WmsLocationDTO;
import com.maxnerva.cloudmes.models.dto.doc.*;
import com.maxnerva.cloudmes.models.dto.warehouse.QmsPickPkgDTO;
import com.maxnerva.cloudmes.models.vo.ExcelImportVO;
import com.maxnerva.cloudmes.models.vo.PageQueryVO;
import com.maxnerva.cloudmes.models.vo.QmsInspectVO;
import com.maxnerva.cloudmes.models.vo.doc.*;
import com.maxnerva.cloudmes.models.vo.warehouse.PkgInfoPageQueryVO;
import com.maxnerva.cloudmes.service.doc.IWmsDocReceiveService;
import com.maxnerva.cloudmes.service.doc.IWmsQmsPickingRecordService;
import com.maxnerva.cloudmes.service.doc.IWmsReceiveSnListService;
import com.maxnerva.cloudmes.service.sap.po.model.PoItemInfoDto;
import com.sap.conn.jco.JCoException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;

/**
 * @ClassName ReceiveController
 * @Description 收货管理
 * @Author Likun
 * @Date 2022/8/4
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "收货管理")
@Slf4j
@RestController
@RequestMapping("/receive")
public class DocReceiveController {

    @Resource
    private IWmsDocReceiveService wmsDocReceiveService;

    @Resource
    private IWmsQmsPickingRecordService wmsQmsPickingRecordService;

    @Resource
    private IWmsReceiveSnListService wmsReceiveSnListService;

    @ApiOperation("确认收货")
    @PostMapping("confirmReceive")
    public R<Void> confirmReceive(ConfirmReceiveVO confirmReceiveVO) {
        wmsDocReceiveService.confirmReceive(confirmReceiveVO);
        return R.ok();
    }

    @ApiOperation("查询收货单列表信息")
    @PostMapping("/receiveList")
    public R<PageDataDTO<WmsDocReceiveDTO>> selectReceiveListPage(@RequestBody DocReceiveQueryVO queryVO) {
        return R.ok(wmsDocReceiveService.selectReceiveListPage(queryVO));
    }

    @ApiOperation("查询收货单信息")
    @PostMapping("/list")
    public R<PageDataDTO<WmsDocReceiveDTO>> selectReceivePage(@RequestBody DocReceiveQueryVO queryVO) {
        return R.ok(wmsDocReceiveService.selectReceivePage(queryVO));
    }

    @ApiOperation("收货检验明细导出")
    @PostMapping("/checkPartNoExport")
    public void checkPartNoExport(HttpServletResponse response,
                                  @RequestBody DocReceiveQueryVO exportVO) {
        wmsDocReceiveService.checkPartNoExport(response, exportVO);
    }

    @ApiOperation("新增收货单")
    @PostMapping("/add")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "新增收货单")
    public R<Void> saveDocReceive(@RequestBody WmsDocReceiveVO docReceiveVO) {
        return R.ok(wmsDocReceiveService.saveDocReceive(docReceiveVO));
    }

    @ApiOperation("修改收货信息")
    @PutMapping("/update")
    @FactoryOperationLog(operationType = OperationTypeConstant.MODIFY, description = "修改收货信息")
    public R<Void> updateDocReceive(@RequestBody WmsDocReceiveVO docReceiveVO) {
        return R.ok(wmsDocReceiveService.updateDocReceive(docReceiveVO));
    }

    @ApiOperation("删除收货信息")
    @DeleteMapping("/delete")
    @FactoryOperationLog(operationType = OperationTypeConstant.DELETE, description = "删除收货信息")
    public R<Void> deleteReceiveDoc(@RequestBody List<Integer> idList) {
        wmsDocReceiveService.deleteDocReceive(idList);
        return R.ok();
    }

    @ApiOperation("根据单据主键id查询单据详情")
    @GetMapping("/detailById")
    public R<WmsDocReceiveDTO> getDocReceiveDetailById(String id) {
        return R.ok(wmsDocReceiveService.getDocReceiveDetailById(id));
    }

    @ApiOperation("根据单据号查询单据详情")
    @GetMapping("/detailByDocNo")
    public R<WmsDocReceiveDTO> getDocReceiveDetailByDocNo(String docNo) {
        return R.ok(wmsDocReceiveService.getDocReceiveDetailByDocNo(docNo));
    }

    @ApiOperation("app-查询收货单信息")
    @PostMapping("/app/list")
    public R<PageDataDTO<WmsDocReceiveDTO>> selectAppReceivePage(@RequestBody PageQueryVO queryVO) {
        return R.ok(wmsDocReceiveService.selectAppReceivePage(queryVO));
    }

    @ApiOperation("更新qms检验结果")
    @PostMapping("/updateInspectResult")
    public R<Void> updateQmsInspectResult(@RequestBody QmsInspectVO qmsInspectVO) {
        wmsDocReceiveService.updateQmsInspectResult(qmsInspectVO);
        return R.ok();
    }

    @ApiOperation("根据po单号查询poItem")
    @GetMapping("/poItemList")
    public R<List<PoItemInfoDto>> selectPoItemInfo(@RequestParam("poNo") String poNo,
                                                   @RequestParam(value = "orgCode", required = false) String orgCode) {
        try {
            return R.ok(wmsDocReceiveService.selectPoItemInfo(poNo, orgCode));
        } catch (JCoException e) {
            log.error(">>>>>>>>>>>>>>>>根据po单号获取poItem异常:{}", e.getMessage(), e);
            throw new CloudmesException(WmsMouldResultCode.PO_GET_PO_ITEM_ERROR.getCode(),
                    MessageUtils.get(WmsMouldResultCode.PO_GET_PO_ITEM_ERROR.getLocalCode()));
        }
    }

    @ApiOperation("收货单excel导入")
    @PostMapping("/import")
    public R<Void> importDocReceive(DocReceiveExcelImportVO excelImportVO) {
        wmsDocReceiveService.importDocReceive(excelImportVO.getOrgCode(), excelImportVO.getDocTypeCode(),
                excelImportVO.getFile());
        return R.ok();
    }

    @ApiOperation("qms拣料记录列表")
    @PostMapping("/pickingRecordList")
    public R<PageDataDTO<WmsQmsPickingRecordDTO>> selectQmsPickingRecord(@RequestBody QmsPickingRecordQueryVO queryVO) {
        return R.ok(wmsQmsPickingRecordService.selectQmsPickingRecord(queryVO));
    }

    @ApiOperation("qms拣料信息")
    @GetMapping("/pickingInfo")
    public R<WmsQmsPickingInfoDTO> pickingInfo(@RequestParam("orgCode") String orgCode,
                                               @RequestParam("docNo") String docNo) {
        return R.ok(wmsQmsPickingRecordService.pickingInfo(orgCode, docNo));
    }

    @ApiOperation("qms拣料退回")
    @PostMapping("/pickingReturn")
    public R<HashMap> pickingReturn(@RequestBody QmsPickingReturnVO qmsPickingReturnVO) {
        return R.ok(wmsQmsPickingRecordService.pickingReturn(qmsPickingReturnVO));
    }

    @ApiOperation("根据单号获取库区")
    @GetMapping("/getLocationCode")
    public R<List<WmsLocationDTO>> getLocationCode(@RequestParam("docNo") String docNo,
                                                   @RequestParam("orgCode") String orgCode) {
        return R.ok(wmsQmsPickingRecordService.getLocationCode(docNo, orgCode));
    }

    @ApiOperation("根据单号、库区获取载具")
    @GetMapping("/getVehicleCode")
    public R<List<WmsPkgInfo>> getVehicleCode(@RequestParam("docNo") String docNo,
                                              @RequestParam("locationCode") String locationCode,
                                              @RequestParam("orgCode") String orgCode) {
        return R.ok(wmsQmsPickingRecordService.getVehicleCode(docNo, locationCode, orgCode));
    }

    @ApiOperation("拿料清单")
    @GetMapping("/getPkgList")
    public R<PageDataDTO<QmsPickPkgDTO>> getPkgList(PkgInfoPageQueryVO pkgInfoPageQueryVO) {
        return R.ok(wmsQmsPickingRecordService.getPkgList(pkgInfoPageQueryVO));
    }

    @ApiOperation("qms拣料/拆箱勾选打印条码")
    @PostMapping("/pickingMaterial")
    public R<Void> pickingMaterial(@RequestBody QmsPickingMaterialVO pickingMaterialVO) {
        wmsQmsPickingRecordService.pickingMaterial(pickingMaterialVO);
        return R.ok();
    }

    @ApiOperation("qms拆箱（不勾选打印条码）")
    @PostMapping("/Splitbox")
    public R<Void> Splitbox(@RequestBody QmsPickingSubmitVO qmsPickingSubmitVO) {
        wmsQmsPickingRecordService.pickingSubmit(qmsPickingSubmitVO);
        return R.ok();
    }

    @ApiOperation("获取已捡料数量")
    @GetMapping("/getPickingQty")
    public R<HashMap> getPickingQty(String docReceiveNo) {
        return R.ok(wmsQmsPickingRecordService.getPickingQty(docReceiveNo));
    }

    @ApiOperation("查询poItem")
    @GetMapping("/poItemInfo")
    public R<List<PoItemDTO>> selectPoItem(@RequestParam("poNo") String poNo,
                                           @RequestParam("poItem") String poItem,
                                           @RequestParam(value = "orgCode", required = false) String orgCode) {
        try {
            return R.ok(wmsDocReceiveService.selectPoItem(poNo, poItem, orgCode));
        } catch (JCoException e) {
            log.error(">>>>>>>>>>>>>>>>查询poItem异常:{}", e.getMessage(), e);
            throw new CloudmesException(WmsMouldResultCode.PO_GET_PO_ITEM_ERROR.getCode(),
                    MessageUtils.get(WmsMouldResultCode.PO_GET_PO_ITEM_ERROR.getLocalCode()));
        }
    }

    @ApiOperation("收货单excel导出")
    @PostMapping("/exportDocReceive")
    public void exportDocReceive(HttpServletResponse response,
                                 @RequestBody DocReceiveQueryVO queryVO) {
        wmsDocReceiveService.exportDocReceive(response, queryVO);
    }

    @ApiOperation("查询收货明细信息")
    @PostMapping("/receiveItemList")
    public R<PageDataDTO<WmsDocReceiveItemDTO>> selectReceiveItemPage(@RequestBody DocReceiveQueryVO queryVO) {
        return R.ok(wmsDocReceiveService.selectReceiveItemPage(queryVO));
    }

    @ApiOperation("收货明细excel导入")
    @PostMapping("/importReceiveItem")
    public R<Void> importReceiveItem(DocReceiveExcelImportVO excelImportVO) {
        wmsDocReceiveService.importDocReceiveItem(excelImportVO.getOrgCode(), excelImportVO.getDocTypeCode(),
                excelImportVO.getFile());
        return R.ok();
    }

    @ApiOperation("收货明细excel导出")
    @PostMapping("/exportDocReceiveItem")
    public R<Void> exportDocReceiveItem(HttpServletResponse response,
                                        @RequestBody DocReceiveQueryVO queryVO) {
        wmsDocReceiveService.exportDocReceiveItem(response, queryVO);
        return R.ok();
    }

    @ApiOperation("入库信息查询 ---供模具系统使用")
    @PostMapping("/getOutsourcingDocList")
    public R<List<OutsourcingDocDTO>> getOutsourcingDocList(@RequestBody OutsourcingDocQueryVO outsourcingDocQueryVO) {
        return R.ok(wmsDocReceiveService.getOutsourcingDocList(outsourcingDocQueryVO));
    }

    @ApiOperation("批量确认收货")
    @PostMapping("/confirmReceiveBatch")
    public R<Void> confirmReceiveBatch(@RequestBody List<Integer> idList) {
        wmsDocReceiveService.confirmReceiveBatch(idList);
        return R.ok();
    }

    @ApiOperation("APP扫描ASN")
    @PostMapping("/jitReceive")
    public R<AppJitReceiptDTO> jitReceive(@RequestBody AppJitReceiveVO appJitReceiveVO) throws JCoException {
        return R.ok(wmsDocReceiveService.jitReceive(appJitReceiveVO));
    }

    @ApiOperation("查询验料单信息")
    @PostMapping("/checkPartList")
    public R<PageDataDTO<CheckPartDTO>> selectCheckPartPage(@RequestBody CheckPartQueryVO queryVO) {
        return R.ok(wmsDocReceiveService.selectCheckPartPage(queryVO));
    }

    @ApiOperation("验料归还excel导出")
    @PostMapping("/exportQmsPickingRecord")
    public R<Void> exportQmsPickingRecord(HttpServletResponse response,
                                        @RequestBody QmsPickingRecordQueryVO queryVO) {
        wmsQmsPickingRecordService.exportQmsPickingRecord(response, queryVO);
        return R.ok();
    }

    @ApiOperation("验料单导出")
    @PostMapping("/exportCheckPartList")
    public void exportCheckPartList(HttpServletResponse response,
                                  @RequestBody CheckPartQueryVO queryVO) {
        wmsDocReceiveService.exportCheckPartList(response, queryVO);
    }

    @ApiOperation("收货SN清单excel导入")
    @PostMapping("/importReceiveSn")
    public R<Void> importReceiveSn(ExcelImportVO excelImportVO) {
        wmsReceiveSnListService.importReceiveSnList(excelImportVO);
        return R.ok();
    }

    @ApiOperation("待导入SN收货明细发送邮件")
    @GetMapping("/sendUnUploadSnMail")
    public R<Void> sendUnUploadSnMail(String orgCode){
        wmsDocReceiveService.sendUnUploadSnMail(orgCode);
        return R.ok();
    }

    @ApiOperation("同步ASN信息到收货单")
    @PostMapping("/syncAsnInfo")
    R syncAsnInfo(@RequestBody SyncAsnInfoVO vo) {
        wmsDocReceiveService.syncAsnInfo(vo);
        return R.ok();
    }

}
