package com.maxnerva.cloudmes.controller.inventory;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.inventory.InventoryAreaConfigDTO;
import com.maxnerva.cloudmes.models.vo.inventory.InventoryAreaConfigQueryVO;
import com.maxnerva.cloudmes.models.vo.inventory.InventoryAreaConfigSaveOrUpdateVO;
import com.maxnerva.cloudmes.service.inventory.IWmsInventoryAreaConfigService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName InventoryAreaConfigController
 * @Description 盘点库区配置管理
 * @Author Likun
 * @Date 2024/11/12
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "盘点库区配置管理")
@Slf4j
@RestController
@RequestMapping("/inventoryAreaConfig")
public class InventoryAreaConfigController {

    @Resource
    private IWmsInventoryAreaConfigService wmsInventoryAreaConfigService;

    @ApiOperation("分页查询盘点库区配置")
    @PostMapping("/list")
    public R<PageDataDTO<InventoryAreaConfigDTO>> selectAreaConfigPage(@RequestBody InventoryAreaConfigQueryVO queryVO){
        return R.ok(wmsInventoryAreaConfigService.selectAreaConfigPage(queryVO));
    }

    @ApiOperation("新增盘点库区配置")
    @PostMapping("/save")
    public R<Void> saveAreaConfig(@RequestBody InventoryAreaConfigSaveOrUpdateVO saveOrUpdateVO){
        wmsInventoryAreaConfigService.saveAreaConfig(saveOrUpdateVO);
        return R.ok();
    }

    @ApiOperation("修改盘点库区配置")
    @PutMapping("/update")
    public R<Void> updateAreaConfig(@RequestBody InventoryAreaConfigSaveOrUpdateVO saveOrUpdateVO){
        wmsInventoryAreaConfigService.updateAreaConfig(saveOrUpdateVO);
        return R.ok();
    }

    @ApiOperation("删除配置信息")
    @DeleteMapping("/delete")
    public R<Void> deleteAreaConfig(@RequestBody List<Integer> idList){
        wmsInventoryAreaConfigService.deleteAreaConfig(idList);
        return R.ok();
    }

    @ApiOperation("配置详情")
    @GetMapping("/detail/{id}")
    public R<InventoryAreaConfigDTO> selectAreaConfigById(@PathVariable("id") Integer id) {
        return R.ok(wmsInventoryAreaConfigService.selectAreaConfigById(id));
    }
}
