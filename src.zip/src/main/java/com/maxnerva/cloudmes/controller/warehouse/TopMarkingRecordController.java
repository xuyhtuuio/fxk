package com.maxnerva.cloudmes.controller.warehouse;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.warehouse.TopMarkingPkgDTO;
import com.maxnerva.cloudmes.models.dto.warehouse.TopMarkingResultDTO;
import com.maxnerva.cloudmes.models.dto.warehouse.WmsTopMarkingRecordDTO;
import com.maxnerva.cloudmes.models.vo.warehouse.TopMarkingConfirmVO;
import com.maxnerva.cloudmes.models.vo.warehouse.TopMarkingQueryVO;
import com.maxnerva.cloudmes.models.vo.warehouse.TopMarkingUnlockVO;
import com.maxnerva.cloudmes.service.warehouse.IWmsTopMarkingRecordService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @Author hgx
 * @Description 丝印管理
 * @Date 2023/7/5
 */
@Api(tags = "丝印管理")
@Slf4j
@RestController
@RequestMapping("/topMarking")
public class TopMarkingRecordController {
    @Resource
    IWmsTopMarkingRecordService wmsTopMarkingRecordService;

    @ApiOperation("根据PKGID查询丝印信息")
    @GetMapping("/getTopMarkingInfo")
    public R<TopMarkingPkgDTO> getTopMarkingInfo(@RequestParam("orgCode") String orgCode,
                                                 @RequestParam(value = "pkgId") String pkgId) {
        return R.ok(wmsTopMarkingRecordService.getTopMarkingInfo(orgCode, pkgId));
    }

    @ApiOperation("丝印确认")
    @PostMapping("/topMarkingConfirm")
    public R<Void> topMarkingConfirm(@RequestBody TopMarkingConfirmVO topMarkingConfirmVo) {
        return wmsTopMarkingRecordService.topMarkingConfirm(topMarkingConfirmVo);
    }

    @ApiOperation("查询丝印信息")
    @GetMapping("/topMarkingList")
    public R<PageDataDTO<WmsTopMarkingRecordDTO>> topMarkingList(TopMarkingQueryVO topMarkingQueryVO) {
        return R.ok(wmsTopMarkingRecordService.topMarkingList(topMarkingQueryVO));
    }

    @ApiOperation("丝印解锁")
    @PostMapping("/unLock")
    public R<Void> unLock(@RequestBody TopMarkingUnlockVO topMarkingUnlockVO) {
        wmsTopMarkingRecordService.unLock(topMarkingUnlockVO);
        return R.ok();
    }

    @ApiOperation("清除丝印")
    @PostMapping("/clearTopMarking")
    public R<Void> clearTopMarking(@RequestBody TopMarkingUnlockVO clearTopMarkingVO) {
        wmsTopMarkingRecordService.clearTopMarking(clearTopMarkingVO);
        return R.ok();
    }

    @ApiOperation("查询丝印结果")
    @GetMapping("/topMarkingResult")
    public R<TopMarkingResultDTO> topMarkingResult(@RequestParam("orgCode") String orgCode,
                                                   @RequestParam("pkgId") String pkgId) {
        return R.ok(wmsTopMarkingRecordService.topMarkingResult(orgCode, pkgId));
    }
}
