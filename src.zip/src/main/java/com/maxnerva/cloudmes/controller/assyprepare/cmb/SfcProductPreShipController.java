package com.maxnerva.cloudmes.controller.assyprepare.cmb;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.assyprepare.CartonBarcodeScanDTO;
import com.maxnerva.cloudmes.models.dto.assyprepare.SfcPreShipDnDTO;
import com.maxnerva.cloudmes.models.dto.assyprepare.StampBinScanDTO;
import com.maxnerva.cloudmes.models.vo.assyprepare.SfcPreShipAgvBindPkgVO;
import com.maxnerva.cloudmes.models.vo.assyprepare.SfcPreShipDnQueryVO;
import com.maxnerva.cloudmes.models.vo.assyprepare.StampBinScanVO;
import com.maxnerva.cloudmes.service.assyprepare.cmb.SfcProductPreShipService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName SfcProductPreShipController
 * @Description TODO
 * @Author Likun
 * @Date 2025/3/12
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "SFC采集备货")
@Slf4j
@RestController
@RequestMapping("/sfcProductPreShip")
public class SfcProductPreShipController {

    @Resource
    private SfcProductPreShipService sfcProductPreShipService;


    @ApiOperation("扫描barCode")
    @GetMapping("/scanBarCode")
    public R<CartonBarcodeScanDTO> scanBarCode(@ApiParam(value = "barCode", required = true)
                                               @RequestParam("barCode") String barCode,
                                               @ApiParam(value = "工厂组织", required = true)
                                               @RequestParam("orgCode") String orgCode){
        return R.ok(sfcProductPreShipService.scanBarCode(orgCode,barCode));
    }


    @ApiOperation("提交")
    @PostMapping("/submit")
    public R<Void> submitPreShipInfo(@RequestBody SfcPreShipAgvBindPkgVO preShipAgvBindPkgVO){
        return sfcProductPreShipService.submitPreShipInfo(preShipAgvBindPkgVO);
    }

    @ApiOperation("DN清单")
    @PostMapping("/dnInfoList")
    public R<List<SfcPreShipDnDTO>> selectSfcPreShipDnInfo(@RequestBody SfcPreShipDnQueryVO queryVO){
        return R.ok(sfcProductPreShipService.selectSfcPreShipDnInfo(queryVO));
    }

    @ApiOperation("扫描储位")
    @PostMapping("/scanBinCode")
    public R<StampBinScanDTO> scanBinCode(@RequestBody StampBinScanVO stampBinScanVO){
        return R.ok(sfcProductPreShipService.scanBinCode(stampBinScanVO));
    }
}
