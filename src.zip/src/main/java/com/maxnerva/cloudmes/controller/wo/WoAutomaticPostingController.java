package com.maxnerva.cloudmes.controller.wo;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.wo.WoAutomaticPostingDTO;
import com.maxnerva.cloudmes.models.vo.wo.WoAutomaticPostingQueryVO;
import com.maxnerva.cloudmes.models.vo.wo.WoAutomaticPostingRecordVO;
import com.maxnerva.cloudmes.service.wo.IWmsWoAutomaticPostingRecordService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@Api(tags = "工单自动过账")
@Slf4j
@RestController
@RequestMapping("/woAutomatic")
public class WoAutomaticPostingController {

    @Resource
    private IWmsWoAutomaticPostingRecordService wmsWoAutomaticPostingRecordService;

    @ApiOperation("工单自动过账")
    @PostMapping("/automaticPostingRecord")
    public R<Void> automaticPostingRecord(@RequestBody WoAutomaticPostingRecordVO postingRecordVO) {
        wmsWoAutomaticPostingRecordService.automaticPostingRecord(postingRecordVO);
        return R.ok();
    }

    @ApiOperation("工单自动过账")
    @PostMapping("/list")
    public  R<PageDataDTO<WoAutomaticPostingDTO>> list(@RequestBody WoAutomaticPostingQueryVO woAutomaticPostingQueryVO) {
        return R.ok(wmsWoAutomaticPostingRecordService.selectList(woAutomaticPostingQueryVO));
    }

}
