package com.maxnerva.cloudmes.controller.bigdata;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.bigdata.ProductStoreDTO;
import com.maxnerva.cloudmes.models.vo.bigdata.ProductStoreQueryVO;
import com.maxnerva.cloudmes.service.bigdata.IProductStoreService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName AmazonProductStoreController
 * @Description AMAZON成品库存管理
 * @Author Likun
 * @Date 2023/12/25
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "成品库存管理")
@Slf4j
@RestController
@RequestMapping("/productStore")
public class ProductStoreController {

    @Resource
    private IProductStoreService productStoreService;

    @ApiOperation("查询成品库存信息")
    @PostMapping("/list")
    public R<List<ProductStoreDTO>> selectProductStoreList(
            @RequestBody ProductStoreQueryVO queryVO) {
        return R.ok(productStoreService.selectProductStoreList(queryVO.getOrgCode(),
                queryVO.getCustomerCode()));
    }
}
