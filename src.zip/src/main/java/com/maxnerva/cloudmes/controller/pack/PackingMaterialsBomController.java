package com.maxnerva.cloudmes.controller.pack;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.entity.pack.PackingMaterialsBom;
import com.maxnerva.cloudmes.models.vo.ExcelImportVO;
import com.maxnerva.cloudmes.models.vo.pack.QueryPackingMaterialBomVO;
import com.maxnerva.cloudmes.service.pack.IWmsPackingMaterialsBomService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @ClassName PackingMaterialsBomController
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/6/10 下午 01:32
 * @Version 1.0
 **/
@Api(tags = "包材bom信息")
@RestController
@RequestMapping("/packingMaterialsBom")
public class PackingMaterialsBomController {

    @Autowired
    IWmsPackingMaterialsBomService packingMaterialsBomService;


    @ApiOperation("包材bom查询")
    @GetMapping("/queryBom")
    public R queryBom(@RequestParam(value = "hhPn", required = false) String hhPn,
                      @RequestParam(value = "packingMaterialsPn", required = false) String packingMaterialsPn,
                      @RequestParam("pageIndex") int pageIndex,
                      @RequestParam("pageSize") int pageSize) {
        return R.ok(packingMaterialsBomService.queryBomIpage(hhPn,packingMaterialsPn,pageIndex,pageSize));
    }

    @ApiOperation("包材bom导入")
    @PostMapping("/bomImport")
    public R bomImport(ExcelImportVO excelImportVO) {
         packingMaterialsBomService.importBom(excelImportVO.getFile(), excelImportVO.getOrgCode());
         return R.ok();
    }

    @ApiOperation("包材bom新增")
    @PostMapping("/createBom")
    public R createBom(@RequestBody PackingMaterialsBom bom) {
        return packingMaterialsBomService.createBom(bom);
    }

    @ApiOperation("包材bom修改")
    @PostMapping("/updateBom")
    public R updateBom(@RequestBody PackingMaterialsBom bom) {
        return packingMaterialsBomService.updateBom(bom);
    }

    @ApiOperation("包材bom删除")
    @GetMapping("/deleteBom")
    public R deleteBom(@RequestParam("id") int id) {
        packingMaterialsBomService.removeById(id);
        return R.ok();
    }

    @ApiOperation("包材bom批量删除")
    @PostMapping("/batchDelBom")
    public R batchDelBom(@RequestBody List<Integer> bomIdList) {
        return packingMaterialsBomService.batchDel(bomIdList);
    }

    @ApiOperation("包材bom导出")
    @PostMapping("/export")
    public R export(HttpServletResponse response, @RequestBody QueryPackingMaterialBomVO queryPackingMaterialBomVO) {
         packingMaterialsBomService.export(response, queryPackingMaterialBomVO);
         return R.ok();
    }




}
