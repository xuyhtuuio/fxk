package com.maxnerva.cloudmes.controller.basic;

import com.maxnerva.cloudmes.aspect.FactoryOperationLog;
import com.maxnerva.cloudmes.common.constant.OperationTypeConstant;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.basic.WmsAreaDTO;
import com.maxnerva.cloudmes.models.dto.basic.WmsAreaStaffDTO;
import com.maxnerva.cloudmes.models.vo.basic.AreaPageQueryVO;
import com.maxnerva.cloudmes.models.vo.basic.AreaStaffBindVO;
import com.maxnerva.cloudmes.models.vo.basic.WmsAreaVO;
import com.maxnerva.cloudmes.service.basic.IWmsAreaService;
import com.maxnerva.cloudmes.service.basic.IWmsAreaStaffService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * @ClassName AreaController
 * @Description 库区管理
 * @Author Likun
 * @Date 2022/7/20
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "库区管理")
@Slf4j
@RestController
@RequestMapping("/area")
public class AreaController {

    @Resource
    private IWmsAreaService wmsAreaService;

    @Resource
    private IWmsAreaStaffService wmsAreaStaffService;

    @ApiOperation("新增库区")
    @PostMapping("/add")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "新增库区")
    public R<Void> saveArea(@Valid @RequestBody WmsAreaVO areaVO) {
        wmsAreaService.saveArea(areaVO);
        return R.ok();
    }

    @ApiOperation("修改库区")
    @PutMapping("/update")
    @FactoryOperationLog(operationType = OperationTypeConstant.MODIFY, description = "修改库区")
    public R<Void> updateArea(@Valid @RequestBody WmsAreaVO areaVO) {
        wmsAreaService.updateArea(areaVO);
        return R.ok();
    }

    @ApiOperation("删除库区")
    @DeleteMapping("/delete")
    @FactoryOperationLog(operationType = OperationTypeConstant.DELETE, description = "删除库区")
    public R<Void> deleteArea(@RequestBody List<Integer> idList) {
        wmsAreaService.deleteAreaBatch(idList);
        return R.ok();
    }

    @ApiOperation("查询库区信息")
    @PostMapping("/list")
    public R<PageDataDTO<WmsAreaDTO>> selectPage(@RequestBody AreaPageQueryVO queryVO) {
        return R.ok(wmsAreaService.selectPage(queryVO));
    }

    @ApiOperation("库区员工绑定")
    @PostMapping("/bindStaff")
    public R<Void> bindAreaStaff(@Valid @RequestBody AreaStaffBindVO bindVO) {
        wmsAreaStaffService.bindAreaStaff(bindVO);
        return R.ok();
    }

    @ApiOperation("库区员工绑定信息查询")
    @GetMapping("/staffList")
    public R<List<WmsAreaStaffDTO>> getAreaStaffList(@RequestParam("wmsAreaId") Integer wmsAreaId) {
        return R.ok(wmsAreaStaffService.getAreaStaffList(wmsAreaId));
    }

    @ApiOperation("删除库区员工绑定信息")
    @DeleteMapping("/deleteStaff")
    public R<Void> deleteAreaStaff(@RequestBody List<Integer> ids) {
        wmsAreaStaffService.deleteAreaStaff(ids);
        return R.ok();
    }
}
