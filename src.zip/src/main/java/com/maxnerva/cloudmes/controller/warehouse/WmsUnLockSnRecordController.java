package com.maxnerva.cloudmes.controller.warehouse;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.vo.warehouse.UnLockSnVO;
import com.maxnerva.cloudmes.service.warehouse.IWmsUnLockSnRecordService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName WmsUnLockSnRecordController
 * @Description TODO
 * @Author Likun
 * @Date 2024/8/7
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "mes通知解锁sn管理")
@Slf4j
@RestController
@RequestMapping("/unLockSnRecord")
public class WmsUnLockSnRecordController {

    @Resource
    private IWmsUnLockSnRecordService wmsUnLockSnRecordService;

    @ApiOperation("解锁sn")
    @PostMapping("/unLockSn")
    public R<Void> unLockSn(@RequestBody List<UnLockSnVO> unLockSnVOList){
        wmsUnLockSnRecordService.unLockSn(unLockSnVOList);
        return R.ok();
    }
}
