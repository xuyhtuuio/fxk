package com.maxnerva.cloudmes.controller.alarm;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.alarm.DeclareFilingAlarmRecordDTO;
import com.maxnerva.cloudmes.models.vo.alarm.AlarmSendMailVO;
import com.maxnerva.cloudmes.models.vo.alarm.DeclareFilingAlarmRecordQueryVO;
import com.maxnerva.cloudmes.service.alarm.IWmsDeclareFilingAlarmRecordService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @ClassName DeclareFilingAlarmController
 * @Description 关务备案预警管理
 * @Author Likun
 * @Date 2023/12/19
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "关务备案预警管理")
@Slf4j
@RestController
@RequestMapping("/declareFilingAlarm")
public class DeclareFilingAlarmController {

    @Resource
    private IWmsDeclareFilingAlarmRecordService wmsDeclareFilingAlarmRecordService;

    @ApiOperation("更新备案状态")
    @PutMapping("/updateFilingStatus")
    public R<Void> updateFilingStatus(@RequestBody List<Integer> idList) {
        wmsDeclareFilingAlarmRecordService.updateFilingStatus(idList);
        return R.ok();
    }

    @ApiOperation("删除")
    @DeleteMapping("/delete")
    public R<Void> deleteFilingAlarmRecord(@RequestBody List<Integer> idList) {
        wmsDeclareFilingAlarmRecordService.deleteFilingAlarmRecord(idList);
        return R.ok();
    }

    @ApiOperation("关务备案预警列表")
    @PostMapping("/filingAlarmList")
    public R<PageDataDTO<DeclareFilingAlarmRecordDTO>> selectFilingAlarmRecordPage(@RequestBody DeclareFilingAlarmRecordQueryVO queryVO) {
        return R.ok(wmsDeclareFilingAlarmRecordService.selectFilingAlarmRecordPage(queryVO));
    }

    @ApiOperation("关务备案预警excel导出")
    @PostMapping("/export")
    public void exportDeclareFilingAlarmRecord(HttpServletResponse response,
                                               @RequestBody DeclareFilingAlarmRecordQueryVO queryVO) {
        wmsDeclareFilingAlarmRecordService.exportDeclareFilingAlarmRecord(response, queryVO);
    }

    @ApiOperation("发邮件")
    @PostMapping("/sendMail")
    public R<Void> sendMail(@RequestBody AlarmSendMailVO alarmSendMailVO){
        wmsDeclareFilingAlarmRecordService.sendMailBatch(alarmSendMailVO);
        return R.ok();
    }
}
