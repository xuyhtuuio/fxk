package com.maxnerva.cloudmes.controller.pack;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.entity.pack.PackingMaterialsSupplier;
import com.maxnerva.cloudmes.models.vo.ExcelImportVO;
import com.maxnerva.cloudmes.models.vo.pack.QueryPackingMaterialSupplierVO;
import com.maxnerva.cloudmes.service.pack.IWmsPackingMaterialsSupplierService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;

/**
 * @ClassName PackingMaterialsSupplierController
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/6/10 下午 01:51
 * @Version 1.0
 **/
@Api(tags = "包材供应商信息")
@RestController
@RequestMapping("/packingMaterialsSupplier")
public class PackingMaterialsSupplierController {

    @Autowired
    IWmsPackingMaterialsSupplierService packingMaterialsSupplierService;


    @ApiOperation("包材供应商查询")
    @GetMapping("/querySupplier")
    public R querySupplier(@RequestParam(value = "packingMaterialsPn" ,required = false) String packingMaterialsPn,
                           @RequestParam(value = "supplier",required = false) String supplier,
                           @RequestParam("pageIndex") int pageIndex,
                           @RequestParam("pageSize") int pageSize) {
        return R.ok(packingMaterialsSupplierService.querySupplier(packingMaterialsPn,supplier,pageIndex,pageSize));
    }

    @ApiOperation("包材供应商导入")
    @PostMapping("/supplierImport")
    public R supplierImport(ExcelImportVO excelImportVO){
         packingMaterialsSupplierService.importSupplier(excelImportVO.getFile(), excelImportVO.getOrgCode());
         return R.ok();
    }

    @ApiOperation("包材供应商新增")
    @PostMapping("/createSupplier")
    public R createSupplier(@RequestBody PackingMaterialsSupplier supplier) {
        return packingMaterialsSupplierService.createSupplier(supplier);
    }

    @ApiOperation("包材供应商修改")
    @PostMapping("/updateSupplier")
    public R updateSupplier(@RequestBody PackingMaterialsSupplier supplier) {
        return packingMaterialsSupplierService.updateSupplier(supplier);
    }

    @ApiOperation("包材供应商删除")
    @GetMapping("/deleteSupplier")
    public R deleteSupplier(@RequestParam("id") int id) {
        packingMaterialsSupplierService.removeById(id);
        return R.ok();
    }

    @ApiOperation("供应商导出")
    @PostMapping("/export")
    public R export(HttpServletResponse response, @RequestBody QueryPackingMaterialSupplierVO queryPackingMaterialBomVO) {
        packingMaterialsSupplierService.export(response, queryPackingMaterialBomVO);
        return R.ok();
    }

}
