package com.maxnerva.cloudmes.controller.assyprepare.cmb;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.vo.assyprepare.PreShipAgvBindPkgVO;
import com.maxnerva.cloudmes.service.assyprepare.cmb.ProductPreShipService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @ClassName ProductPreShipController
 * @Description TODO
 * @Author Likun
 * @Date 2025/3/12
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "成品备货")
@Slf4j
@RestController
@RequestMapping("/productPreShip")
public class ProductPreShipController {

    @Resource
    private ProductPreShipService productPreShipService;

    @ApiOperation("备货绑定")
    @PostMapping("/preShipBindingPkg")
    public R<Void> preShipBindingPkg(@RequestBody PreShipAgvBindPkgVO preShipAgvBindPkgVO){
        return productPreShipService.preShipBindingPkg(preShipAgvBindPkgVO);
    }
}
