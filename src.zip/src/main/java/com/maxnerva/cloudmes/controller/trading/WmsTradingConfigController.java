package com.maxnerva.cloudmes.controller.trading;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.trading.WmsTradingConfigDTO;
import com.maxnerva.cloudmes.models.vo.trading.TradingConfigPageQueryVo;
import com.maxnerva.cloudmes.models.vo.trading.WmsTradingConfigSaveVO;
import com.maxnerva.cloudmes.service.trading.IWmsTradingConfigService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author sclq
 * @date 2022/9/22 10:15
 */
@Api(tags = "内交配置")
@Slf4j
@RestController
@RequestMapping("/tradingConfig")
public class WmsTradingConfigController {

    @Resource
    private IWmsTradingConfigService wmsTradingConfigService;

    @ApiOperation("条件查询")
    @GetMapping("/pageList")
    public R<PageDataDTO<WmsTradingConfigDTO>> pageList(TradingConfigPageQueryVo queryVo) {
        Page page = PageHelper.startPage(queryVo.getPageIndex(), queryVo.getPageSize());
        List<WmsTradingConfigDTO> wmsTradingConfigDTOS = wmsTradingConfigService.selectPage(queryVo);
        PageDataDTO<WmsTradingConfigDTO> wmsTradingConfigDTOPageDataDTO = new PageDataDTO<>(page.getTotal(), wmsTradingConfigDTOS);
        return R.ok(wmsTradingConfigDTOPageDataDTO);
    }


    @ApiOperation("新增内交配置信息")
    @PostMapping("/save")
    public R<Void> save(@RequestBody WmsTradingConfigSaveVO saveVO) {
        wmsTradingConfigService.save(saveVO);
        return R.ok();
    }

    @ApiOperation("修改内交配置信息")
    @PostMapping("/update")
    public R<Void> update(@RequestBody WmsTradingConfigSaveVO saveVO) {
        wmsTradingConfigService.update(saveVO);
        return R.ok();
    }

    @ApiOperation("删除内交配置信息")
    @PostMapping("/delete")
    public R<Void> delete(@RequestBody List<Integer> ids) {
        wmsTradingConfigService.delete(ids);
        return R.ok();
    }

    @ApiOperation("获取内交工厂")
    @GetMapping("/getFromPlantCode")
    public R<List<WmsTradingConfigDTO>> getFromPlantCode(@RequestParam("fromOrgCode") String fromOrgCode,
                                                         @RequestParam(value = "tradingToOrgCode", required = false) String tradingToOrgCode) {
        return R.ok(wmsTradingConfigService.getFromPlantCode(fromOrgCode, tradingToOrgCode));
    }

    @ApiOperation("获取对应内交BU")
    @GetMapping("/getTradingToOrgCode")
    public R<List<WmsTradingConfigDTO>> getTradingToOrgCode(@RequestParam(value = "fromOrgCode", required = false) String fromOrgCode,
                                                            @RequestParam(value = "fromPlantCode", required = false) String fromPlantCode,
                                                            @RequestParam(value = "tradingToOrgCode", required = false) String tradingToOrgCode) {
        return R.ok(wmsTradingConfigService.getTradingToOrgCode(fromOrgCode, fromPlantCode, tradingToOrgCode));
    }

}
