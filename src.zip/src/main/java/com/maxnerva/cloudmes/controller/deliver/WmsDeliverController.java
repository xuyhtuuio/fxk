package com.maxnerva.cloudmes.controller.deliver;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.aspect.FactoryOperationLog;
import com.maxnerva.cloudmes.common.constant.OperationTypeConstant;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.deliver.WmsDeliverDto;
import com.maxnerva.cloudmes.models.vo.deliver.DeliverPageQueryVo;
import com.maxnerva.cloudmes.models.vo.deliver.DeliverVo;
import com.maxnerva.cloudmes.models.vo.deliver.ScanDeliverVo;
import com.maxnerva.cloudmes.service.deliver.WmsDeliverService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;


/**
 * @author sclq
 * @date 2022/9/8 14:24
 */
@Api(tags = "出货管理")
@Slf4j
@RestController
@RequestMapping("/wmsDeliver")
public class WmsDeliverController {

    @Resource
    private WmsDeliverService wmsDeliverService;

    @ApiOperation("条件查询")
    @GetMapping("/pageList")
    private R<PageDataDTO<WmsDeliverDto>> pageList(@RequestBody DeliverPageQueryVo deliverPageQueryVo) {
        if (deliverPageQueryVo.getPageIndex() != null && deliverPageQueryVo.getPageSize() != null
                && deliverPageQueryVo.getPageIndex() != 0 && deliverPageQueryVo.getPageSize() != 0) {
            Page page = PageHelper.startPage(deliverPageQueryVo.getPageIndex(), deliverPageQueryVo.getPageSize());
            List<WmsDeliverDto> wmsDeliverDtos = wmsDeliverService.selectPage(deliverPageQueryVo);
            PageDataDTO<WmsDeliverDto> wmsDeliverDtoPageDataDTO = new PageDataDTO<>(page.getTotal(), wmsDeliverDtos);
            return R.ok(wmsDeliverDtoPageDataDTO);
        } else {
            List<WmsDeliverDto> wmsDeliverDtos = wmsDeliverService.selectPage(deliverPageQueryVo);
            PageDataDTO<WmsDeliverDto> wmsDeliverDtoPageDataDTO = new PageDataDTO<>((long) wmsDeliverDtos.size(), wmsDeliverDtos);
            return R.ok(wmsDeliverDtoPageDataDTO);
        }
    }

    @ApiOperation("新增出货单")
    @PostMapping("/save")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "新增出货单")
    private R<Void> save(@RequestBody DeliverVo deliverVo) {
        wmsDeliverService.save(deliverVo);
        return R.ok();
    }

    @ApiOperation("扫码出货")
    @PostMapping("/scanDeliver")
    private R<Void> scanDeliver(@RequestBody ScanDeliverVo scanDeliverVo) {
        wmsDeliverService.scanDeliver(scanDeliverVo);
        return R.ok();
    }

    @ApiOperation("储位推荐")
    @GetMapping("/recommendBin")
    private R<Void> recommendBin(String areaCode) {
        return R.ok(wmsDeliverService.recommendBin(areaCode));
    }

}
