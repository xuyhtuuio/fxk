package com.maxnerva.cloudmes.controller.warehouse;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.warehouse.WmsBadProductInStorageConfigDTO;
import com.maxnerva.cloudmes.models.vo.warehouse.BadProductInStorageConfigQueryVO;
import com.maxnerva.cloudmes.models.vo.warehouse.WmsBadProductInStorageConfigVO;
import com.maxnerva.cloudmes.service.warehouse.IWmsBadProductInStorageConfigService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * @ClassName BadProductInStorageConfigController
 * @Description TODO
 * @Author Likun
 * @Date 2024/6/26
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "不良品配置管理")
@Slf4j
@RestController
@RequestMapping("/badProductInStorageConfig")
public class BadProductInStorageConfigController {

    @Resource
    private IWmsBadProductInStorageConfigService badProductInStorageConfigService;

    @ApiOperation("分页查询配置信息")
    @PostMapping("/list")
    public R<PageDataDTO<WmsBadProductInStorageConfigDTO>> selectConfigPage(
            @RequestBody BadProductInStorageConfigQueryVO queryVO){
        return R.ok(badProductInStorageConfigService.selectConfigPage(queryVO));
    }

    @ApiOperation("新增/修改配置信息")
    @PostMapping("/saveOrUpdateConfig")
    public R<Void> saveOrUpdateConfig(
            @Valid  @RequestBody WmsBadProductInStorageConfigVO wmsBadProductInStorageConfigVO){
        badProductInStorageConfigService.saveOrUpdateConfig(wmsBadProductInStorageConfigVO);
        return R.ok();
    }

    @ApiOperation("删除配置信息")
    @DeleteMapping("/delete")
    public R<Void> delete(@RequestBody List<Integer> idList) {
        badProductInStorageConfigService.deleteBatch(idList);
        return R.ok();
    }
}
