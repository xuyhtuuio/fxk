package com.maxnerva.cloudmes.controller.basic;

import com.maxnerva.cloudmes.aspect.FactoryOperationLog;
import com.maxnerva.cloudmes.common.annotation.RedisLock;
import com.maxnerva.cloudmes.common.constant.OperationTypeConstant;
import com.maxnerva.cloudmes.common.enums.ResultCode;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.enums.WmsMouldResultCode;
import com.maxnerva.cloudmes.models.dto.basic.ScanVehicleDTO;
import com.maxnerva.cloudmes.models.dto.basic.VehicleMaterialTransferDTO;
import com.maxnerva.cloudmes.models.dto.basic.WmsVehicleDTO;
import com.maxnerva.cloudmes.models.dto.warehouse.BinUsedDTO;
import com.maxnerva.cloudmes.models.dto.warehouse.RecommendDTO;
import com.maxnerva.cloudmes.models.vo.basic.*;
import com.maxnerva.cloudmes.service.basic.IWmsVehicleService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * @ClassName VehicleController
 * @Description 载具管理
 * @Author Likun
 * @Date 2022/7/22
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "载具管理")
@Slf4j
@RestController
@RequestMapping("/vehicle")
public class VehicleController {

    @Resource
    private IWmsVehicleService wmsVehicleService;

    @ApiOperation("新增载具")
    @PostMapping("/add")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "新增载具")
    public R<Void> saveVehicle(@Valid @RequestBody WmsVehicleVO vehicleVO) {
        wmsVehicleService.saveVehicle(vehicleVO);
        return R.ok();
    }

    @ApiOperation("修改载具")
    @PutMapping("/update")
    @FactoryOperationLog(operationType = OperationTypeConstant.MODIFY, description = "修改载具")
    public R<Void> updateVehicle(@Valid @RequestBody WmsVehicleVO vehicleVO) {
        wmsVehicleService.updateVehicle(vehicleVO);
        return R.ok();
    }

    @ApiOperation("删除载具")
    @DeleteMapping("/delete")
    @FactoryOperationLog(operationType = OperationTypeConstant.DELETE, description = "删除载具")
    public R<Void> deleteVehicle(@RequestBody List<Integer> idList) {
        wmsVehicleService.deleteVehicleBatch(idList);
        return R.ok();
    }

    @ApiOperation("分页查询载具信息")
    @PostMapping("/list")
    public R<PageDataDTO<WmsVehicleDTO>> selectPage(@RequestBody VehiclePageQueryVO queryVO) {
        return R.ok(wmsVehicleService.selectPage(queryVO));
    }

    @ApiOperation("扫描载具编码")
    @GetMapping("/scan")
    public R<String> scanVehicleCode(String orgCode, String vehicleCode) {
        String scanVehicleCode = wmsVehicleService.scanVehicleCode(orgCode, vehicleCode);
        return R.ok(ResultCode.SUCCESS.getCode(),
                MessageUtils.get(WmsMouldResultCode.SCAN_SUCCESS.getLocalCode()), scanVehicleCode);
    }

    @ApiOperation("绑定库位")
    @PostMapping("/bind")
    @RedisLock(value = "lock:vehicleCode", param = "#vehicleLocationBindVO.vehicleCode")
    public R<Void> bindLocation(@Valid @RequestBody VehicleLocationBindVO vehicleLocationBindVO) {
        wmsVehicleService.bindLocation(vehicleLocationBindVO);
        return R.ok();
    }

    @ApiOperation("解绑库位")
    @PostMapping("/unBind")
    public R<Void> unBindLocation(@Valid @RequestBody VehicleLocationBindVO vehicleLocationBindVO) {
        wmsVehicleService.unBindLocation(vehicleLocationBindVO);
        return R.ok();
    }

    @ApiOperation("载具物料转移")
    @PostMapping("/vehicleMaterialTransfer")
    public R<VehicleMaterialTransferDTO> vehicleMaterialTransfer(@Valid @RequestBody VehicleMaterialTransferVO vehicleMaterialTransferVO) {
        return R.ok(wmsVehicleService.vehicleMaterialTransfer(vehicleMaterialTransferVO));
    }

    @ApiOperation("根据载具推荐储位")
    @GetMapping("/recommend")
    public R<RecommendDTO> recommendBin(@ApiParam("vehicleCode") @RequestParam("vehicleCode") String vehicleCode,
                                        @ApiParam("binCode") @RequestParam(value = "binCode", required = false) String binCode,
                                        @ApiParam("orgCode") @RequestParam("orgCode") String orgCode,
                                        @ApiParam("partNo") @RequestParam(value = "partNo", required = false) String partNo) {
        return R.ok(wmsVehicleService.recommendBin(vehicleCode, binCode, orgCode, partNo));
    }

    @ApiOperation("扫描载具")
    @GetMapping("/scanVehicle")
    public R<ScanVehicleDTO> scanVehicle(@ApiParam("vehicleCode") @RequestParam("vehicleCode") String vehicleCode,
                                         @ApiParam("orgCode") @RequestParam("orgCode") String orgCode) {
        return R.ok(wmsVehicleService.scanVehicle(orgCode, vehicleCode));
    }

    @ApiOperation("载具使用报表")
    @PostMapping("/vehicleReportList")
    public R<PageDataDTO<WmsVehicleDTO>> selectVehicleReportPage(@RequestBody VehiclePageQueryVO pageQueryVO) {
        return R.ok(wmsVehicleService.selectVehicleReportPage(pageQueryVO));
    }

    @ApiOperation("查询载具下已使用储位信息")
    @PostMapping("/binUsedList")
    public R<PageDataDTO<BinUsedDTO>> selectBinUsedInfo(@RequestBody BinPageQueryVO pageQueryVO) {
        return R.ok(wmsVehicleService.selectBinUsedInfo(pageQueryVO));
    }

    @ApiOperation("QMS检验取料")
    @PostMapping("/qmsMaterialRetrieval")
    public R<VehicleMaterialTransferDTO> qmsMaterialRetrieval(
            @Valid @RequestBody VehicleMaterialTransferVO vehicleMaterialTransferVO) {
        return R.ok(wmsVehicleService.qmsMaterialRetrieval(vehicleMaterialTransferVO));
    }

    @ApiOperation("QMS归还扫描")
    @PostMapping("/qmsReturn")
    public R<VehicleMaterialTransferDTO> qmsReturn(
            @Valid @RequestBody VehicleMaterialTransferVO vehicleMaterialTransferVO) {
        return R.ok(wmsVehicleService.qmsReturn(vehicleMaterialTransferVO));
    }
}
