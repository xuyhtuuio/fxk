package com.maxnerva.cloudmes.controller.basic;

import com.maxnerva.cloudmes.aspect.FactoryOperationLog;
import com.maxnerva.cloudmes.common.constant.OperationTypeConstant;
import com.maxnerva.cloudmes.common.enums.ResultCode;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.enums.WmsMouldResultCode;
import com.maxnerva.cloudmes.models.dto.basic.WmsLocationDTO;
import com.maxnerva.cloudmes.models.vo.basic.LocationPageQueryVO;
import com.maxnerva.cloudmes.models.vo.basic.WmsLocationVO;
import com.maxnerva.cloudmes.service.basic.IWmsLocationService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * @ClassName LocationController
 * @Description 库位管理
 * @Author Likun
 * @Date 2022/7/22
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "库位管理")
@Slf4j
@RestController
@RequestMapping("/location")
public class LocationController {

    @Resource
    private IWmsLocationService wmsLocationService;

    @ApiOperation("新增库位")
    @PostMapping("/add")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "新增库位")
    public R<Void> saveLocation(@Valid @RequestBody WmsLocationVO locationVO) {
        wmsLocationService.saveLocation(locationVO);
        return R.ok();
    }

    @ApiOperation("修改库位")
    @PutMapping("/update")
    @FactoryOperationLog(operationType = OperationTypeConstant.MODIFY, description = "修改库位")
    public R<Void> updateLocation(@Valid @RequestBody WmsLocationVO locationVO) {
        wmsLocationService.updateLocation(locationVO);
        return R.ok();
    }

    @ApiOperation("删除库位")
    @DeleteMapping("/delete")
    @FactoryOperationLog(operationType = OperationTypeConstant.DELETE, description = "删除库位")
    public R<Void> deleteLocation(@RequestBody List<Integer> idList) {
        wmsLocationService.deleteLocationBatch(idList);
        return R.ok();
    }

    @ApiOperation("分页查询库位信息")
    @PostMapping("/list")
    public R<PageDataDTO<WmsLocationDTO>> selectPage(@RequestBody LocationPageQueryVO queryVO) {
        return R.ok(wmsLocationService.selectPage(queryVO));
    }

    @ApiOperation("扫描库位编码")
    @GetMapping("/scan")
    public R<String> scanLocationCode(String locationCode) {
        String scanLocationCode = wmsLocationService.scanLocationCode(locationCode);
        return R.ok(ResultCode.SUCCESS.getCode(),
                MessageUtils.get(WmsMouldResultCode.SCAN_SUCCESS.getLocalCode()), scanLocationCode);
    }
}
