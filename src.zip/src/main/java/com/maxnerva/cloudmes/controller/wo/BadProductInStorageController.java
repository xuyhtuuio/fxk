package com.maxnerva.cloudmes.controller.wo;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.entity.flownet.FlownetResponse;
import com.maxnerva.cloudmes.entity.wo.WmsBadProductInStorage;
import com.maxnerva.cloudmes.mapper.wo.WmsBadProductInStorageMapper;
import com.maxnerva.cloudmes.models.dto.QmsBadProductIssueDTO;
import com.maxnerva.cloudmes.models.dto.basic.SelectDTO;
import com.maxnerva.cloudmes.models.dto.doc.BadProductInStorageUploadDTO;
import com.maxnerva.cloudmes.models.dto.warehouse.BadProductPkgPrintDTO;
import com.maxnerva.cloudmes.models.dto.wo.*;
import com.maxnerva.cloudmes.models.vo.QmsBadProductFirstCheckVO;
import com.maxnerva.cloudmes.models.vo.QmsBadProductIssueVO;
import com.maxnerva.cloudmes.models.vo.QmsBadProductResultVO;
import com.maxnerva.cloudmes.models.vo.QmsBadProductSecondCheckVO;
import com.maxnerva.cloudmes.models.vo.doc.WmsFlownetApprovalVo;
import com.maxnerva.cloudmes.models.vo.warehouse.BadProductPkgInfoPrintVO;
import com.maxnerva.cloudmes.models.vo.wo.*;
import com.maxnerva.cloudmes.service.wo.IWmsBadInStorageService;
import com.sap.conn.jco.JCoException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @Author hgx
 * @Description 不良品管理
 * @Date 2023/4/17 16:58
 */
@Api(tags = "不良品管理")
@Slf4j
@RestController
@RequestMapping("/badProduct")
public class BadProductInStorageController {

    @Resource
    private IWmsBadInStorageService wmsBadInStorageService;
    @Resource
    private WmsBadProductInStorageMapper wmsBadProductInStorageMapper;

    @ApiOperation("不良品导入")
    @PostMapping("/import")
    public R<Void> importBadProduct(BadProductImprotVO excelImportVO) {
        wmsBadInStorageService.importBadProduct(excelImportVO);
        return R.ok();
    }

    @ApiOperation("不良品列表查询")
    @GetMapping("/list")
    public R<PageDataDTO<BadProductInStorageDTO>> selectPage(BadProductPageQueryVO pageQueryVO) {
        return R.ok(wmsBadInStorageService.selectBadProducPage(pageQueryVO));
    }

    @ApiOperation("不良品入库")
    @PostMapping("/inStorage")
    public R<BadProductOperateDTO> inStorage(@RequestBody BadProductInStorageVO inStorageVO) {
        return R.ok(wmsBadInStorageService.inStorage(inStorageVO));
    }

    @ApiOperation("推荐载具、储位")
    @GetMapping("/recommend")
    public R<BadProductOperateDTO> recommend(@RequestParam Integer id) {
        return R.ok(wmsBadInStorageService.recommend(id));
    }

    @ApiOperation("不良品置换")
    @PostMapping("/replace")
    public R<BadProductOperateDTO> replace(@RequestBody BadProductReplaceVO replaceVO) {
        return R.ok(wmsBadInStorageService.replace(replaceVO));
    }

    @ApiOperation("新增不良品")
    @PostMapping("/add")
    public R<Void> add(@RequestBody BadProductAddVO addVO) {
        wmsBadInStorageService.add(addVO);
        return R.ok();
    }

    @ApiOperation("不良品抛Q")
    @GetMapping("/postBadProductToQms")
    public R<Void> postBadProductToQms(@RequestParam("orgCode") String orgCode, @RequestParam("docNo") String docNo) {
        WmsBadProductInStorage wmsBadProductInStorage = wmsBadProductInStorageMapper.selectOne(Wrappers.<WmsBadProductInStorage>lambdaQuery()
                .eq(WmsBadProductInStorage::getOrgCode, orgCode)
                .eq(WmsBadProductInStorage::getDocNo, docNo));
        wmsBadInStorageService.postBadProductToQms(wmsBadProductInStorage);
        return R.ok();
    }

    @ApiOperation("QMS检验初判结果回传")
    @PostMapping("/qmsCheckFirstResult")
    public R<Void> qmsCheckFirstResult(@RequestBody QmsBadProductFirstCheckVO checkVo) {
        wmsBadInStorageService.qmsCheckFirstResult(checkVo);
        return R.ok();
    }

    @ApiOperation("QMS检验复判结果回传")
    @PostMapping("/qmsCheckSecondResult")
    public R<Void> qmsCheckSecondResult(@RequestBody List<QmsBadProductSecondCheckVO> checkVoList) {
        wmsBadInStorageService.qmsCheckSecondResult(checkVoList);
        return R.ok();
    }

    @ApiOperation("领用")
    @PostMapping("/qmsIssue")
    public R<List<QmsBadProductIssueDTO>> qmsIssue(@RequestBody List<QmsBadProductIssueVO> issueVOList) {
        return R.ok(wmsBadInStorageService.qmsIssue(issueVOList));
    }

    @ApiOperation("扫描SN查询SFC工单信息")
    @GetMapping("/getSfcWoInfo")
    public R<BadProductSfcWoDTO> getSfcWoInfo(@RequestParam("orgCode") String orgCode,
                                              @RequestParam("plantCode") String plantCode,
                                              @RequestParam("dataSource") String dataSource,
                                              @RequestParam("sn") String sn) {
        return R.ok(wmsBadInStorageService.getSfcWoInfo(orgCode, plantCode, dataSource, sn));
    }

    @ApiOperation("扫描PKGID查询六合一信息")
    @GetMapping("/scanPkgID")
    public R<BadProductScanPkgDTO> scanPkgId(@RequestParam("orgCode") String orgCode,
                                             @RequestParam("plantCode") String plantCode,
                                             @RequestParam("pkgId") String pkgId) {
        return R.ok(wmsBadInStorageService.scanPkgId(orgCode, plantCode, pkgId));
    }

    @ApiOperation("查询配置仓码")
    @GetMapping("/getWhConfig")
    public R<BadProductInStorageConfigDTO> getWhConfig(BadProductGetWhConfigVO getWhConfigVO) {
        return R.ok(wmsBadInStorageService.getWhConfig(getWhConfigVO));
    }

    @ApiOperation("根据不良代码获取不良原因")
    @GetMapping("/getSfcErrorDesc")
    public R<BadProductSfcWoDTO> getSfcErrorDesc(@RequestParam("orgCode") String orgCode,
                                                 @RequestParam("plantCode") String plantCode,
                                                 @RequestParam("operationType") String operationType,
                                                 @RequestParam("errorCode") String errorCode,
                                                 @RequestParam("workOrderNo") String workOrderNo) {
        return R.ok(wmsBadInStorageService.getSfcErrorDesc(orgCode, plantCode, operationType, errorCode, workOrderNo));
    }

    @ApiOperation(value = "查询制造商料号")
    @GetMapping("/getMfgPartNoLsit")
    public R<List<SelectDTO>> getMfgPartNoLsit(@RequestParam(value = "orgCode") String orgCode,
                                               @RequestParam(value = "plantCode") String plantCode,
                                               @RequestParam(value = "partNo") String partNo) {
        return R.ok(wmsBadInStorageService.getMfgPartNoLsit(orgCode, plantCode, partNo));
    }


    @ApiOperation(value = "查询制造商名称")
    @PostMapping("/getMfgNameList")
    public R<List<SelectDTO>> getMfgNameList(@RequestBody MfgNameListVO mfgNameListVO) {
        String orgCode = mfgNameListVO.getOrgCode();
        String plantCode = mfgNameListVO.getPlantCode();
        String partNo = mfgNameListVO.getPartNo();
        String supplierPartNo = mfgNameListVO.getSupplierPartNo();
        return R.ok(wmsBadInStorageService.getMfgNameList(orgCode, plantCode, partNo, supplierPartNo));
    }

    @ApiOperation("查询条码打印信息")
    @PostMapping("/printInfo")
    public R<BadProductPkgPrintDTO> selectPrintInfo(@RequestBody BadProductPkgInfoPrintVO pkgInfoPrintVO) {
        return R.ok(wmsBadInStorageService.selectPrintInfo(pkgInfoPrintVO));
    }

    @ApiOperation(value = "查询不良分类选项")
    @GetMapping("/getMaterialSourceList")
    public R<List<SelectDTO>> getMaterialSourceList(@RequestParam(value = "orgCode") String orgCode,
                                                    @RequestParam(value = "plantCode") String plantCode,
                                                    @RequestParam(value = "operationType") String operationType) {
        return R.ok(wmsBadInStorageService.getMaterialSourceList(orgCode, plantCode, operationType));
    }

    @ApiOperation("不良品处理列表查询")
    @GetMapping("/handleList")
    public R<PageDataDTO<BadProductHandleDTO>> handleList(BadProductPageQueryVO pageQueryVO) {
        return R.ok(wmsBadInStorageService.handleList(pageQueryVO));
    }

    @ApiOperation("不良品领用下架信息")
    @GetMapping("/issueUnshelfInfo")
    public R<IssueUnshelfInfoDTO> issueUnshelfInfo(@RequestParam("id") Integer id) {
        return R.ok(wmsBadInStorageService.issueUnshelfInfo(id));
    }

    @ApiOperation("不良品领用下架提交")
    @PostMapping("/issueUnShelf")
    public R<IssueUnshelfInfoDTO> issueUnShelf(@RequestBody BadIssueUnshelfVO badIssueUnshelfVO) {
        return R.ok(wmsBadInStorageService.issueUnShelf(badIssueUnshelfVO));
    }

    @ApiOperation("不良品归还上架提交")
    @PostMapping("/returnShelf")
    public R<IssueUnshelfInfoDTO> returnShelf(@RequestBody BadReturnShelfVO badReturnShelfVO) {
        return R.ok(wmsBadInStorageService.returnShelf(badReturnShelfVO));
    }

    @ApiOperation(value = "判断pkgId是否存在")
    @GetMapping("/reWorkCheckPkgId")
    public R<List<String>> reWorkCheckPkgId(@RequestParam("orgCode") String orgCode,
                                            @RequestParam("pkgIdList") List<String> pkgIdList) {
        return R.ok(wmsBadInStorageService.reWorkCheckPkgId(orgCode, pkgIdList));
    }

    @ApiOperation("来料不良结果回传")
    @PostMapping("/qmsBadProductResult")
    public R<Void> qmsBadProductResult(@RequestBody QmsBadProductResultVO qmsBadProductResultVO) {
        wmsBadInStorageService.qmsBadProductResult(qmsBadProductResultVO);
        return R.ok();
    }

    @ApiOperation("导出")
    @PostMapping("/export")
    public R<Void> export(HttpServletResponse response,
                          @RequestBody BadProductPageQueryVO vo) {
        wmsBadInStorageService.export(response, vo);
        return R.ok();
    }

    @ApiOperation("删除")
    @DeleteMapping("/delete")
    public R deleteBadProduct(@RequestBody DeleteBadProductVO vo) {
        wmsBadInStorageService.delete(vo);
        return R.ok();
    }

    @ApiOperation("Flownet审核完成调用服务节点")
    @PostMapping("/approvalCompleted")
    public R<Void> approvalCompleted(@RequestBody String jsonString) {
        log.info("badProductFlownet input parameter=========》：::requestJson={}", jsonString);
        wmsBadInStorageService.approvalCompleted(jsonString);
        return R.ok();
    }

    @ApiOperation(value = "Flownet审核完成")
    @PostMapping("/flownetApproval")
    public R<Void> flownetApproval(@RequestBody List<WmsFlownetApprovalVo> wmsFlownetApprovalVoList) {
        wmsBadInStorageService.flownetApproval(wmsFlownetApprovalVoList);
        return R.ok();
    }

    @ApiOperation(value = "上传")
    @GetMapping("/upload")
    public R<BadProductInStorageUploadDTO> upload(HttpServletRequest request, @RequestParam Integer id)
            throws JCoException {
        return R.ok(wmsBadInStorageService.upload(request, id));
    }

    @ApiOperation(value = "签核状态")
    @GetMapping("/approvalStatus")
    public R<FlownetResponse> approvalStatus(@RequestParam Integer id) {
        return R.ok(wmsBadInStorageService.approvalStatus(id));
    }
}