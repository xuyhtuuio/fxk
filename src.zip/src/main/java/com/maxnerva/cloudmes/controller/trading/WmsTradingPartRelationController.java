package com.maxnerva.cloudmes.controller.trading;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.basic.SelectDTO;
import com.maxnerva.cloudmes.models.dto.trading.WmsTradingPartRelationDTO;
import com.maxnerva.cloudmes.models.vo.trading.TradingPartRelationPageQueryVo;
import com.maxnerva.cloudmes.models.vo.trading.WmsTradingPartRelationSaveVO;
import com.maxnerva.cloudmes.service.trading.IWmsTradingPartRelationService;
import com.sap.conn.jco.JCoException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author sclq
 * @date 2022/9/23 16:54
 */
@Api(tags = "内交对照")
@Slf4j
@RestController
@RequestMapping("/tradingPartRelation")
public class WmsTradingPartRelationController {

    @Resource
    private IWmsTradingPartRelationService wmsTradingPartRelationService;

    @ApiOperation("条件查询")
    @GetMapping("/pageList")
    public R<PageDataDTO<WmsTradingPartRelationDTO>> pageList(TradingPartRelationPageQueryVo queryVo) {
        Page page = PageHelper.startPage(queryVo.getPageIndex(), queryVo.getPageSize());
        List<WmsTradingPartRelationDTO> relationDTOS = wmsTradingPartRelationService.selectPage(queryVo);
        PageDataDTO<WmsTradingPartRelationDTO> partRelationDTOPageDataDTO = new PageDataDTO<>(page.getTotal(), relationDTOS);
        return R.ok(partRelationDTOPageDataDTO);
    }

    @ApiOperation("新增内交对照信息")
    @PostMapping("/save")
    public R<Void> save(@RequestBody WmsTradingPartRelationSaveVO saveVO) throws JCoException {
        wmsTradingPartRelationService.save(saveVO);
        return R.ok();
    }

    @ApiOperation("修改内交对照信息")
    @PostMapping("/update")
    public R<Void> update(@RequestBody WmsTradingPartRelationSaveVO saveVO) throws JCoException {
        wmsTradingPartRelationService.update(saveVO);
        return R.ok();
    }

    @ApiOperation("删除内交对照信息")
    @PostMapping("/delete")
    public R<Void> delete(@RequestBody List<Integer> ids) {
        wmsTradingPartRelationService.delete(ids);
        return R.ok();
    }

    @ApiOperation("查询内交出BU选项")
    @GetMapping("/selectFromOrgCode")
    public R<List<SelectDTO>> selectFromOrgCode(@RequestParam("orgCode") String orgCode) {
        return R.ok(wmsTradingPartRelationService.selectFromOrgCode(orgCode));
    }

    @ApiOperation("查询内交入BU选项")
    @GetMapping("/selectToOrgCode")
    public R<List<SelectDTO>> selectToOrgCode(@RequestParam("orgCode") String orgCode) {
        return R.ok(wmsTradingPartRelationService.selectToOrgCode(orgCode));
    }
}
