package com.maxnerva.cloudmes.controller.basic;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.service.basic.IWmsPlantCustomerConfigService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName PlantCustomerConfigController
 * @Description 工厂客户数据源配置管理
 * @Author Likun
 * @Date 2023/10/6
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "工厂客户数据源配置管理")
@Slf4j
@RestController
@RequestMapping("/plantCustomerConfig")
public class PlantCustomerConfigController {

    @Resource
    private IWmsPlantCustomerConfigService wmsPlantCustomerConfigService;

    @ApiOperation("根据工厂组织获取mes数据源集合")
    @GetMapping("/dataSourceList")
    public R<List<String>> selectMesDataSourceList(@ApiParam(value = "工厂组织")
                                                   @RequestParam(value = "orgCode") String orgCode,
                                                   @RequestParam(value = "plantCode", required = false) String plantCode) {
        return R.ok(wmsPlantCustomerConfigService.selectMesDataSourceList(orgCode, plantCode));
    }
}
