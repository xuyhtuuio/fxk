package com.maxnerva.cloudmes.controller.wo;

import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.entity.wo.WmsMaterialShortageDetail;
import com.maxnerva.cloudmes.entity.wo.WmsWorkOrderVehicleRecord;
import com.maxnerva.cloudmes.excel.util.DataSourceUtil;
import com.maxnerva.cloudmes.models.dto.basic.SelectDTO;
import com.maxnerva.cloudmes.models.dto.mes.MoveOrderDTO;
import com.maxnerva.cloudmes.models.dto.warehouse.PkgInventoryDTO;
import com.maxnerva.cloudmes.models.dto.warehouse.ScrapProductPkgPrintDTO;
import com.maxnerva.cloudmes.models.dto.warehouse.WarehouseCodeInventoryDTO;
import com.maxnerva.cloudmes.models.dto.wo.*;
import com.maxnerva.cloudmes.models.vo.ExcelImportVO;
import com.maxnerva.cloudmes.models.vo.mes.MoveOrderVO;
import com.maxnerva.cloudmes.models.vo.sap.SapWoDetailVO;
import com.maxnerva.cloudmes.models.vo.sap.SapWoHeaderVO;
import com.maxnerva.cloudmes.models.vo.warehouse.*;
import com.maxnerva.cloudmes.models.vo.wo.*;
import com.maxnerva.cloudmes.service.wo.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

/**
 * @ClassName WoPrepareController
 * @Description 工单备料管理
 * @Author Likun
 * @Date 2022/9/8
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "工单管理")
@Slf4j
@RestController
@RequestMapping("/wo")
public class WoController {

    @Resource
    private IWoPrepareService woPrepareService;

    @Resource
    private IWmsBomFeederService wmsBomFeederService;

    @Resource
    private IWoService woService;

    @Resource
    private IWmsWorkOrderVehicleRecordService workOrderVehicleRecordService;

    @Resource
    private IWmsWorkOrderPrepareCkdLogService workOrderPrepareCkdLogService;

    @Resource
    private IWmsMaterialShortageDetailService wmsMaterialShortageDetailService;

    @Resource
    private IWmsWorkOrderPrepareLogService wmsWorkOrderPrepareLogService;

    @Resource
    private IWmsWorkOrderDetailInStorageService wmsWorkOrderDetailInStorageService;

    @Resource
    private IWmsWorkOrderDetailShortageDetailService wmsWorkOrderDetailShortageDetailService;

    @Resource
    private IWmsWorkOrderDetailShortageHeaderService wmsWorkOrderDetailShortageHeaderService;

    @Resource
    private IWmsJusdaInventoryService wmsJitInventoryService;

    @Resource
    private IWmsWorkOrderDetailScrapInStorageService wmsWorkOrderDetailScrapInStorageService;

    @Resource
    private IWmsWorkOrderDetailScrapInStorageDetailService wmsWorkOrderDetailScrapInStorageDetailService;

    @Resource
    private IWmsWorkOrderDetailJitShortageHeaderService wmsWorkOrderDetailJitShortageHeaderService;

    @Resource
    private IWmsWorkOrderDetailJitShortageDetailService wmsWorkOrderDetailJitShortageDetailService;

    @Resource
    private IWmsWorkOrderDetailService wmsWorkOrderDetailService;

    @ApiOperation("备料管理-----根据工单号获取可用工单位置信息")
    @GetMapping("/prepare/list")
    public R<List<WmsWorkOrderVehicleRecord>> getVehicleRecord(@ApiParam(value = "工单号", required = true) @RequestParam("workOrderNo") String workOrderNo, @ApiParam(value = "制程分类") @RequestParam("productCategory") String productCategory, @ApiParam(value = "工厂组织") @RequestParam(value = "orgCode", required = false) String orgCode) {
        return R.ok(woPrepareService.getWorkOrderVehicleRecord(workOrderNo, productCategory, orgCode));
    }

    @ApiOperation("备料管理-----工单位置信息绑定载具")
    @PostMapping("/prepare/bind")
    public R<Boolean> bindWoVehicle(@Valid @RequestBody WoVehicleBindVO bindVO) {
        return R.ok(woPrepareService.bindWoVehicle(bindVO.getWorkOrderNo(), bindVO.getWorkOrderLocation(), bindVO.getVehicleCode(), bindVO.getOrgCode()));
    }

    @ApiOperation("备料管理-----推荐备料信息")
    @GetMapping("/prepare/adviceWoInfo")
    public R<AdvicePrepareWoDTO> adviceWo(@ApiParam(value = "工单号", required = true) @RequestParam("workOrderNo") String workOrderNo, @ApiParam(value = "制程分类", required = true) @RequestParam("productCategory") String productCategory, @ApiParam(value = "工厂", required = true) @RequestParam("plantCode") String plantCode, @ApiParam(value = "BU", required = true) @RequestParam("orgCode") String orgCode) {
        return R.ok(woPrepareService.adviceWo(workOrderNo, plantCode, orgCode, productCategory));
    }

    @ApiOperation("备料管理-----工单备料提交")
    @PostMapping("/prepare/submit")
    public R<Void> prepareWo(@RequestBody PrepareWoVO prepareWoVO) {
        woPrepareService.prepareWo(prepareWoVO.getWorkOrderDetailId(), prepareWoVO.getVehicleCode(), prepareWoVO.getBinCode(), prepareWoVO.getAdvicePkgId(), prepareWoVO.getWorkOrderToLocation(), prepareWoVO.getCollectVO());
        return R.ok();
    }

    @ApiOperation("上料表管理-----查询上料表信息")
    @PostMapping("/bomFeeder/list")
    public R<PageDataDTO<WmsBomFeederDTO>> selectPage(@RequestBody BomFeederPageQueryVO pageQueryVO) {
        return R.ok(wmsBomFeederService.selectBomFeederPage(pageQueryVO));
    }

    @ApiOperation("同步工单header")
    @PostMapping("/syncWoHeader")
    public R<Void> syncWoHeader(@RequestBody SapWoHeaderVO sapWoHeaderVO) {
        woService.syncWoHeader(sapWoHeaderVO);
        return R.ok();
    }

    @ApiOperation("同步工单detail")
    @PostMapping("/syncWoDetail")
    public R<Void> syncWoDetail(@RequestBody SapWoDetailVO sapWoDetailVO) {
        woService.syncWoDetail(sapWoDetailVO);
        return R.ok();
    }

    @ApiOperation("工单补料")
    @PostMapping("/feedMaterial")
    public R<Void> feedMaterial(@Valid @RequestBody WoFeedMaterialVO woFeedMaterialVO) {
        return woService.feedMaterial(woFeedMaterialVO);
    }

    @ApiOperation("分页查询工单header")
    @PostMapping("/headerList")
    public R<PageDataDTO<WmsWorkOrderHeaderDTO>> selectHeaderPage(@RequestBody WoHeaderPageQueryVO pageQueryVO) {
        return R.ok(woService.selectHeaderPage(pageQueryVO));
    }

    @ApiOperation("分页查询工单detail")
    @PostMapping("/detailList")
    public R<PageDataDTO<WmsWorkOrderDetailDTO>> selectDetailPage(@RequestBody WoDetailPageQueryVO pageQueryVO) {
        return R.ok(woService.selectDetailPage(pageQueryVO));
    }

    @ApiOperation("备料管理-----工单位置信息解绑载具")
    @PostMapping("/prepare/unBind")
    public R<Integer> unBindWoVehicle(@Valid @RequestBody WoVehicleUnBindVO unBindVO) {
        return R.ok(woPrepareService.unBindWoVehicle(unBindVO.getWorkOrderNo(), unBindVO.getWorkOrderLocation(), unBindVO.getOrgCode()));
    }

    @ApiOperation("备料管理-----在库推荐直备Car(direction)")
    @PostMapping("/prepare/adviceBomFeeder")
    public R<AdvicePrepareWoDTO> adviceBomFeeder(@Valid @RequestBody AdviceBomFeederVO bomFeederVO) {
        return R.ok(woPrepareService.adviceBomFeeder(bomFeederVO.getWorkOrderNo(), bomFeederVO.getProductCategory(), bomFeederVO.getLocationVOList(), bomFeederVO.getOrgCode()));
    }

    @ApiOperation("备料管理-----在库直备Car(direction)提交")
    @PostMapping("/prepare/prepareBomFeeder")
    public R<Void> prepareBomFeeder(@Valid @RequestBody PrepareWoVO prepareWoVO) {
        return woPrepareService.prepareBomFeeder(prepareWoVO);
    }

    @ApiOperation("查询工单备料方向信息")
    @PostMapping("/vehicleRecordList")
    public R<PageDataDTO<WorkOrderVehicleRecordDTO>> selectVehicleRecordList(@RequestBody VehicleRecordQueryVO queryVO) {
        return R.ok(workOrderVehicleRecordService.selectRecordPage(queryVO));
    }


    @ApiOperation("备料管理-----CKD备料推荐")
    @GetMapping("/prepare/adviceCkd")
    public R<AdvicePrepareWoDTO> adviceCkd(@ApiParam(value = "工单号", required = true) @RequestParam("workOrderNo") String workOrderNo, @ApiParam(value = "制程分类", required = true) @RequestParam("originalPackagingFlag") String originalPackagingFlag, @ApiParam(value = "工厂组织", required = true) @RequestParam(value = "orgCode", required = false) String orgCode) {
        return R.ok(woPrepareService.adviceCkd(workOrderNo, originalPackagingFlag, orgCode));
    }

    @ApiOperation("备料管理-----CKD备料")
    @PostMapping("/prepare/prepareCkd")
    public R<Void> prepareBomFeeder(@Valid @RequestBody CkdPrepareVO ckdPrepareVO) {
        return woPrepareService.prepareCkd(ckdPrepareVO);
    }

    @ApiOperation("工单备料管理查询")
        @PostMapping("/prepareList")
    public R<PageDataDTO<WmsWorkOrderHeaderDTO>> selectPrepareList(@RequestBody WoHeaderPageQueryVO pageQueryVO) {
        return R.ok(woService.selectNotCkdHeaderPage(pageQueryVO));
    }

    @ApiOperation("根据工单号查询制程分类")
    @GetMapping("/productCategoryList")
    public R<List<ProductCategoryDTO>> selectProductCategory(@ApiParam(value = "workOrderNo", required = true) @RequestParam("workOrderNo") String workOrderNo, @ApiParam(value = "orgCode") @RequestParam(value = "orgCode", required = false) String orgCode) {
        return R.ok(woPrepareService.selectProductCategory(workOrderNo, orgCode));
    }

    @ApiOperation("分页查询CKD工单header")
    @PostMapping("/ckdHeaderList")
    public R<PageDataDTO<WmsWorkOrderHeaderDTO>> selectCkdHeaderPage(@RequestBody WoHeaderPageQueryVO pageQueryVO) {
        return R.ok(woService.selectCkdHeaderPage(pageQueryVO));
    }

    @ApiOperation("更新产品系列")
    @PutMapping("/updateProductSeries")
    public R<Void> updateProductSeries(@RequestBody WoHeaderUpdateVO woHeaderUpdateVO) {
        woService.updateProductSeries(woHeaderUpdateVO);
        return R.ok();
    }

    @ApiOperation("Ckd工单excel导入")
    @PostMapping("/importCkd")
    public R<Void> importCkdWorkOrder(ExcelImportVO excelImportVO) {
        woService.importCkdWorkOrder(excelImportVO.getOrgCode(), excelImportVO.getFile());
        return R.ok();
    }

    @ApiOperation("根据工单号查询未绑定栈板的箱号")
    @GetMapping("selectUnBindPalletCarton")
    public R<List<String>> selectUnBindPalletCarton(@ApiParam(value = "workOrderNo", required = true) @RequestParam("workOrderNo") String workOrderNo, @ApiParam(value = "orgCode") @RequestParam(value = "orgCode", required = false) String orgCode) {
        return R.ok(woPrepareService.selectUnBindPalletCarton(workOrderNo, orgCode));
    }

    @ApiOperation("CKD上栈板")
    @PostMapping("upperPallet")
    public R<Void> upperPallet(@Valid @RequestBody UpperPalletVO upperPalletVO) {
        woPrepareService.upperPallet(upperPalletVO);
        return R.ok();
    }

    @ApiOperation("工单锁料备料管理-----工单锁料(非CKD工单)")
    @PostMapping("/lockMaterialPrepare/lockMaterial")
    public R<Void> lockMaterial(@RequestBody LockMaterialVO lockMaterialVO) {
        woPrepareService.lockMaterial(lockMaterialVO.getWorkOrderNo(), lockMaterialVO.getOrgCode());
        return R.ok();
    }

    @ApiOperation("工单锁料备料管理-----在库推荐直备Car(direction)")
    @PostMapping("/lockMaterialPrepare/adviceBomFeeder")
    public R<AdvicePrepareWoDTO> adviceBomFeederUnderLockedMaterial(@Valid @RequestBody AdviceBomFeederVO bomFeederVO) {
        return R.ok(woPrepareService.adviceBomFeederUnderLockedMaterial(bomFeederVO.getWorkOrderNo(), bomFeederVO.getProductCategory(), bomFeederVO.getLocationVOList(), bomFeederVO.getOrgCode()));
    }

    @ApiOperation("工单锁料备料管理-----CKD工单锁料")
    @PostMapping("/lockMaterialPrepare/lockCkdMaterial")
    public R<Void> lockCkdMaterial(@RequestBody LockMaterialVO lockMaterialVO) {
        woPrepareService.lockCkdMaterial(lockMaterialVO.getWorkOrderNo(), lockMaterialVO.getOrgCode(), lockMaterialVO.getLockWholePlate());
        return R.ok();
    }

    @ApiOperation("工单锁料备料管理-----CKD备料推荐")
    @GetMapping("/lockMaterialPrepare/adviceCkd")
    public R<AdvicePrepareWoDTO> adviceCkdUnderLockedMaterial(@ApiParam(value = "工单号", required = true) @RequestParam("workOrderNo") String workOrderNo, @ApiParam(value = "制程分类", required = true) @RequestParam("originalPackagingFlag") String originalPackagingFlag, @ApiParam(value = "orgCode", required = true) @RequestParam(value = "orgCode", required = false) String orgCode) {
        return R.ok(woPrepareService.adviceCkdUnderLockedMaterial(workOrderNo, originalPackagingFlag, orgCode));
    }

    @ApiOperation("备料管理-----工单在库直备")
    @PostMapping("/prepare/prepareDirectInStock")
    public R<Void> prepareDirectInStock(@RequestBody InStockDirectPrepareVO stockDirectPrepareVO) {
        return woPrepareService.prepareDirectInStock(stockDirectPrepareVO.getPkgId(), stockDirectPrepareVO.getWorkOrderNo(), stockDirectPrepareVO.getOrgCode(), stockDirectPrepareVO.getVehicleCode());
    }

    @ApiOperation("工单锁料备料管理-----CKD备料")
    @PostMapping("/lockMaterialPrepare/prepareCkd")
    public R<Void> prepareCkdUnderLockMaterial(@Valid @RequestBody CkdPrepareVO ckdPrepareVO) {
        return woPrepareService.prepareCkdUnderLockMaterial(ckdPrepareVO);
    }

    @ApiOperation("备料管理-----CKD直备")
    @PostMapping("/prepare/prepareCkdDirectInStock")
    public R<Void> prepareCkdDirectInStock(@RequestBody CkdDirectPrepareVO ckdDirectPrepareVO) {
        return woPrepareService.prepareCkdDirectInStock(ckdDirectPrepareVO);
    }

    @ApiOperation("分页查询CKD打包清单")
    @PostMapping("/prepare/selectCkdLogPage")
    public R<PageDataDTO<WorkOrderPrepareCkdLogDTO>> selectCkdLogPage(@RequestBody CkdPrepareLogPageQueryVO pageQueryVO) {
        return R.ok(workOrderPrepareCkdLogService.selectCkdLogPage(pageQueryVO));
    }

    @ApiOperation("解锁工单物料")
    @PostMapping("/unLockMaterial")
    public R<Integer> unLockMaterial(@RequestBody LockMaterialVO lockMaterialVO) {
        woPrepareService.unLockMaterial(lockMaterialVO.getWorkOrderNo(), lockMaterialVO.getOrgCode());
        return R.ok();
    }

    @ApiOperation("解锁CKD物料")
    @PostMapping("/unLockCkdMaterial")
    public R<Void> unLockCkdMaterial(@RequestBody LockMaterialVO lockMaterialVO) {
        woPrepareService.unLockCkdMaterial(lockMaterialVO.getWorkOrderNo(), lockMaterialVO.getOrgCode());
        return R.ok();
    }

    @ApiOperation("JUSDA 直备料车")
    @PostMapping("/prepareJusda")
    public R<JusdaPrepareWoDTO> prepareJusda(@RequestBody PrepareJusdaVO prepareJusdaVO) {
        return woPrepareService.prepareJusda(prepareJusdaVO.getWorkOrderNo(), prepareJusdaVO.getProductCategory(), prepareJusdaVO.getPalletNo(), prepareJusdaVO.getOrgCode(), prepareJusdaVO.getLocationVOList(), prepareJusdaVO.getCollectVO());
    }

    @ApiOperation("JUSDA CKD直备")
    @PostMapping("/prepareCkdJusda")
    public R<Void> prepareCkdJusda(@RequestBody PrepareCkdJusdaVO prepareCkdJusdaVO) {
        return woPrepareService.prepareCkdJusda(prepareCkdJusdaVO);
    }

    @ApiOperation("缺料试算")
    @PostMapping("/materialShortage")
    public R<Void> calculateMaterialShortage(@RequestBody CalculateShortageVO calculateShortageVO) {
        log.info(">>>>>>>>>>缺料试算,试算工单:{},start:{}", JSONUtil.toJsonStr(calculateShortageVO.getWorkOrderNoList()), System.currentTimeMillis());
        woPrepareService.calculateMaterialShortage(calculateShortageVO.getWorkOrderNoList(), calculateShortageVO.getOrgCode());
        log.info(">>>>>>>>>>缺料试算,试算工单:{},end:{}", JSONUtil.toJsonStr(calculateShortageVO.getWorkOrderNoList()), System.currentTimeMillis());
        return R.ok();
    }

    @ApiOperation("缺料报表")
    @PostMapping("/materialShortageList")
    public R<PageDataDTO<WmsMaterialShortageDetail>> selectMaterialShortagePage(@RequestBody MaterialShortagePageQueryVO pageQueryVO) {
        return R.ok(wmsMaterialShortageDetailService.selectMaterialShortagePage(pageQueryVO));
    }


    @ApiOperation("缺料报表Excel导出")
    @PostMapping("/exportMaterialShortage")
    public R<Void> exportMaterialShortage(HttpServletResponse response, @RequestBody MaterialShortagePageQueryVO queryVO) {
        wmsMaterialShortageDetailService.exportMaterialShortage(response, queryVO);
        return R.ok();
    }

    @ApiOperation("首套料备料清单")
    @GetMapping("/firstMaterialHeaderList")
    public R<PageDataDTO<FirstMaterialHeaderDTO>> selectFirstMaterialHeaderList(@ApiParam(value = "工厂组织", required = true) @RequestParam("orgCode") String orgCode, @ApiParam(value = "页码", required = true) @RequestParam("pageIndex") Integer pageIndex, @ApiParam(value = "每页数量", required = true) @RequestParam("pageSize") Integer pageSize, @ApiParam(value = "工单号") @RequestParam(value = "workOrderNo", required = false) String workOrderNo) {
        return R.ok(woPrepareService.selectFirstMaterialHeaderPage(orgCode, pageIndex, pageSize, workOrderNo));
    }

    @ApiOperation("首套料备料清单详情")
    @GetMapping("/firstMaterialDetailList")
    public R<PageDataDTO<FirstMaterialDetailDTO>> selectFirstMaterialDetailList(@ApiParam(value = "工单号", required = true) @RequestParam("workOrderNo") String workOrderNo, @ApiParam(value = "工厂组织", required = true) @RequestParam("orgCode") String orgCode, @ApiParam(value = "页码", required = true) @RequestParam("pageIndex") Integer pageIndex, @ApiParam(value = "每页数量", required = true) @RequestParam("pageSize") Integer pageSize) {
        return R.ok(woPrepareService.selectFirstMaterialDetailPage(workOrderNo, orgCode, pageIndex, pageSize));
    }

    @ApiOperation("CKD打包清单Excel导出")
    @PostMapping("/exportCkdLog")
    public void exportCkdLog(HttpServletResponse response, @RequestBody CkdPreparedLogExportVO ckdPreparedLogExportVO) throws IOException {
        workOrderPrepareCkdLogService.exportCkdLog(response, ckdPreparedLogExportVO);
    }

    @ApiOperation("查询栈板打印信息")
    @PostMapping("/palletInfoList")
    public R<CkdPalletPrintDTO> palletInfoList(@RequestBody CkdPrintVO ckdPrintVO) {
        return R.ok(workOrderPrepareCkdLogService.printPalletInfo(ckdPrintVO));
    }

    @ApiOperation("查询箱号打印信息")
    @PostMapping("/cartonInfoList")
    public R<CkdCartonPrintDTO> cartonInfoList(@RequestBody CkdPrintVO ckdPrintVO) {
        return R.ok(workOrderPrepareCkdLogService.printCartonInfo(ckdPrintVO));
    }

    @ApiOperation("pn物料清单")
    @PostMapping("/pnDetailList")
    public R<PageDataDTO<PnWorkOrderDetailDTO>> selectPnWorkOrderDetailList(@RequestBody PnDetailPageQueryVO pageQueryVO) {
        return R.ok(woPrepareService.selectPnWorkOrderDetailList(pageQueryVO));
    }

    @ApiOperation("PN 备料建议")
    @GetMapping("/advicePnPrepare")
    public R<AdvicePnPrepareDTO> advicePnPrepare(@ApiParam(value = "工单号", required = true) @RequestParam("workOrderNo") String workOrderNo,
                                                 @ApiParam(value = "工厂组织", required = true) @RequestParam("orgCode") String orgCode,
                                                 @ApiParam(value = "料号", required = false) @RequestParam(value = "partNo", required = false) String partNo) {
        return R.ok(woPrepareService.advicePnPrepare(workOrderNo, orgCode, partNo));
    }

    @ApiOperation("PN 备料提交")
    @PostMapping("/preparePn")
    public R<Void> preparePn(@RequestBody PnPrepareVO pnPrepareVO) {
        woPrepareService.preparePn(pnPrepareVO);
        return R.ok();
    }

    @ApiOperation("校验msd level")
    @PostMapping("/checkMsdLevel")
    public R<Void> checkMsdLevel(@RequestBody CheckMsdLevelVO checkMsdLevelVO) {
        String partNo = checkMsdLevelVO.getPartNo();
        String mfgPartNo = checkMsdLevelVO.getMfgPartNo();
        String mfgName = checkMsdLevelVO.getMfgName();
        String orgCode = checkMsdLevelVO.getOrgCode();
        String pkgId = checkMsdLevelVO.getPkgId();
        BigDecimal remainQty = checkMsdLevelVO.getRemainQty();
        String plantCode = checkMsdLevelVO.getPlantCode();
        return woPrepareService.checkMsdLevel(partNo, mfgPartNo, mfgName, orgCode, pkgId, remainQty, plantCode);
    }

    @ApiOperation("pn工单清单")
    @PostMapping("/pnWorkOrderDetailList")
    public R<PageDataDTO<PnWorkOrderDetailDTO>> selectPnWorkOrderDetailInfo(@RequestBody PnDetailPageQueryVO pageQueryVO) {
        return R.ok(woPrepareService.selectPnWorkOrderDetailInfo(pageQueryVO));
    }

    @ApiOperation("PN 工单备料建议")
    @GetMapping("/advicePn")
    public R<AdvicePnPrepareDTO> advicePn(@ApiParam(value = "工单号", required = true) @RequestParam("workOrderNo") String workOrderNo, @ApiParam(value = "工厂组织", required = true) @RequestParam("orgCode") String orgCode, @ApiParam(value = "料号", required = true) @RequestParam("partNo") String partNo, @ApiParam(value = "工单群组", required = true) @RequestParam("workOrderItem") String workOrderItem) {
        return R.ok(woPrepareService.advicePn(workOrderNo, orgCode, partNo, workOrderItem));
    }

    @ApiOperation("工单锁料备料管理-----在库绑定料车并推荐直备Car(direction)")
    @PostMapping("/lockMaterialPrepare/bindAndAdviceBomFeeder")
    public R<AdvicePrepareWoDTO> bindAndAdviceBomFeederUnderLockedMaterial(@Valid @RequestBody AdviceBomFeederVO bomFeederVO) {
        return R.ok(woPrepareService.bindAndAdviceBomFeederUnderLockedMaterial(bomFeederVO));
    }

    @ApiOperation("备料管理-----在库推荐直备Car(direction)")
    @PostMapping("/prepare/bindAndAdviceBomFeeder")
    public R<AdvicePrepareWoDTO> bindAndAdviceBomFeeder(@Valid @RequestBody AdviceBomFeederVO bomFeederVO) {
        return R.ok(woPrepareService.bindAndAdviceBomFeeder(bomFeederVO));
    }

    @ApiOperation("首套料清单详情Excel导出")
    @PostMapping("/exportFirstMaterialDetail")
    public void exportFirstMaterialDetail(HttpServletResponse response, @RequestBody FirstMaterialDetailExportVO firstMaterialDetailExportVO) throws IOException {
        woPrepareService.exportFirstMaterialDetail(response, firstMaterialDetailExportVO);
    }

    @ApiOperation("分页查询缺料备料工单明细信息")
    @PostMapping("/prepareDetailList")
    public R<PageDataDTO<WorkDetailDTO>> selectPrepareDetailPage(@RequestBody DetailShortagePageQueryVO pageQueryVO) {
        return R.ok(woService.selectPrepareDetailPage(pageQueryVO));
    }

    @ApiOperation("分页查询工单料号对应的条码库存信息")
    @PostMapping("/pkgInventoryList")
    public R<PageDataDTO<PkgInventoryDTO>> selectInventoryPage(@RequestBody PkgInventoryPageQueryVO pageQueryVO) {
        return R.ok(woService.selectInventoryPage(pageQueryVO));
    }

    @ApiOperation("查询工单料号对应的料号库存信息")
    @GetMapping("/materialInventoryList")
    public R<List<WarehouseCodeInventoryDTO>> selectMaterialInventoryList(@ApiParam(value = "料号", required = true) @RequestParam("partNo") String partNo, @ApiParam(value = "工厂组织", required = true) @RequestParam("orgCode") String orgCode) {
        return R.ok(woService.selectMaterialInventory(partNo, StrUtil.EMPTY, orgCode));
    }

    @ApiOperation("返回SFCPrepareLog数据")
    @PostMapping("/sfcGetPrepareLogData")
    @CrossOrigin
    public R<List<WmsSfcWorkOrderPrepareLogDTO>> sfcGetPrepareLogData(@RequestBody SfcGetPrepareLogDataVO sfcGetPrepareLogDataVO) {
        log.info("sfcGetPrepareLogData input:{}", JSONUtil.toJsonStr(sfcGetPrepareLogDataVO));
        return R.ok(wmsWorkOrderPrepareLogService.sfcGetPrepareLogData(sfcGetPrepareLogDataVO));
    }

    @ApiOperation("根据工单号返回SFCPrepareLog数据")
    @PostMapping("/woPreparetionPkgList")
    @CrossOrigin
    public R<List<WmsSfcWorkOrderPrepareLogDTO>> sfcGetPrepareLogByWo(@RequestBody SfcGetPrepareLogByWoVO sfcGetPrepareLogByWoVO) {
        log.info("sfcGetPrepareLogByWo input:{}", JSONUtil.toJsonStr(sfcGetPrepareLogByWoVO));
        return R.ok(wmsWorkOrderPrepareLogService.sfcGetPrepareLogByWo(sfcGetPrepareLogByWoVO));
    }

    @ApiOperation("SFCPrepareLog数据下架")
    @PostMapping("/sfcUnshelfPkg")
    @CrossOrigin
    public R<Void> sfcUnshelfPkg(@RequestBody SfcUnshelfPkgVO vo) {
        log.info("sfcUnshelfPkg input:{}", JSONUtil.toJsonStr(vo));
        wmsWorkOrderPrepareLogService.sfcUnshelfPkg(vo);
        return R.ok();
    }

    @ApiOperation("工单合备")
    @PostMapping("/mergePrepare")
    public R<Void> mergePrepare(@RequestBody MeragePrepareVO vo) {
        woService.mergePrepare(vo);
        return R.ok();
    }

    @ApiOperation("工单移转")
    @PostMapping("/moveWorkOrder")
    public R<Void> moveWorkOrder(@RequestBody WorkOrderMoveVO workOrderMoveVO) {
        log.info(">>>>>>>>>>工单移转,移出工单:{},移入工单:{},start:{}", workOrderMoveVO.getFromWorkOrderNo(), workOrderMoveVO.getToWorkOrderNo(), System.currentTimeMillis());
        woService.moveWorkOrder(workOrderMoveVO);
        log.info(">>>>>>>>>>工单移转,移出工单:{},移入工单:{},end:{}", workOrderMoveVO.getFromWorkOrderNo(), workOrderMoveVO.getToWorkOrderNo(), System.currentTimeMillis());
        return R.ok();
    }

    @ApiOperation("工单移转记录查询")
    @PostMapping("/woMoveRecordList")
    public R<PageDataDTO<WoMoveRecordDTO>> selectWoMoveRecordPage(@RequestBody WoMoveRecordPageQueryVO pageQueryVO) {
        return R.ok(woService.selectWoMoveRecordPage(pageQueryVO));
    }

    @ApiOperation("工单明细531入库信息查询")
    @PostMapping("/woDetailInStorageList")
    public R<PageDataDTO<WoDetailInStorageDTO>> selectWoDetailInStoragePage(@RequestBody WoDetailInStoragePageQueryVO pageQueryVO) {
        return R.ok(wmsWorkOrderDetailInStorageService.selectDetailInStoragePage(pageQueryVO));
    }

    @ApiOperation("工单明细缺料试算")
    @PostMapping("/calculateWoDetailShortage")
    public R<Void> calculateWorkOrderDetailShortage(@RequestBody CalculateShortageVO calculateShortageVO) {
        woPrepareService.calculateWorkOrderDetailShortage(calculateShortageVO.getWorkOrderNoList(), calculateShortageVO.getOrgCode());
        return R.ok();
    }

    @ApiOperation("工单明细缺料单头信息")
    @PostMapping("/woDetailShortageHeaderList")
    public R<PageDataDTO<WoDetailShortageHeaderDTO>> selectWoDetailShortageHeaderPage(@RequestBody WoDetailShortageHeaderQueryVO pageQueryVO) {
        return R.ok(wmsWorkOrderDetailShortageHeaderService.selectShortageHeaderPage(pageQueryVO));
    }

    @ApiOperation("工单明细缺料单身信息")
    @PostMapping("/woDetailShortageDetailList")
    public R<PageDataDTO<WoDetailShortageDetailDTO>> selectWoDetailShortageDetailPage(@RequestBody WoDetailShortageDetailQueryVO pageQueryVO) {
        return R.ok(wmsWorkOrderDetailShortageDetailService.selectShortageDetailPage(pageQueryVO));
    }

    @ApiOperation("同步JUSDA库存")
    @GetMapping("/syncJusdaInventory")
    public R<String> syncJusdaInventory(@RequestParam(value = "orgCode") String orgCode,
                                        @RequestParam(value = "plantCode", required = false) String plantCode) {
        DataSourceUtil.setWmsDataSource();
        return R.ok(wmsJitInventoryService.syncJusdaInventory(orgCode, plantCode));
    }

    @ApiOperation("查询上料表备料缺料明细信息")
    @PostMapping("/bomFeederShortageList")
    public R<PageDataDTO<WoBomFeederShortageDTO>> selectBomFeederShortageInfo(@RequestBody WoBomFeederShortageQueryVO queryVO) {
        return R.ok(woPrepareService.selectBomFeederShortageInfo(queryVO));
    }

    @ApiOperation("缺料备料报表Excel导出")
    @PostMapping("/exportBomFeederShortageInfo")
    public R<Void> exportBomFeederShortageInfo(HttpServletResponse response, @RequestBody WoBomFeederShortageQueryVO queryVO) throws IOException {
        woPrepareService.exportBomFeederShortageInfo(response, queryVO);
        return R.ok();
    }

    @ApiOperation("工单明细缺料报表Excel导出")
    @PostMapping("/exportWoDetailShortageInfo")
    public void exportWoDetailShortageInfo(HttpServletResponse response, @RequestBody WoDetailShortageDetailQueryVO queryVO) throws IOException {
        wmsWorkOrderDetailShortageDetailService.exportWoDetailShortageInfo(response, queryVO);
    }

    @ApiOperation("新增工单明细报废单入库信息")
    @PostMapping("/addWoDetailScrapInStorage")
    public R<Void> addWoDetailScrapInStorage(@RequestBody String jsonString) {
        log.info("addWoDetailScrapInStorage request json：{}", jsonString);
        DataSourceUtil.setWmsDataSource();
        WoDetailScrapInStorageVO woDetailScrapInStorageVO = new WoDetailScrapInStorageVO();
        woDetailScrapInStorageVO.setDocInfo(jsonString);
        wmsWorkOrderDetailScrapInStorageService.addWoDetailScrapInStorage(woDetailScrapInStorageVO);
        return R.ok();
    }

    @ApiOperation("报废单入库查询工单")
    @GetMapping("/woDetailScrapInStorageInfo")
    public R<WoDetailScrapInStorageInfoDTO> woDetailScrapInStorageInfo(@RequestParam("orgCode") String orgCode,
                                                                       @RequestParam("pkgId") String pkgId,
                                                                       @RequestParam("dataSource") String dataSource) {
        return R.ok(wmsWorkOrderDetailScrapInStorageDetailService.woDetailScrapInStorageInfo(orgCode, pkgId, dataSource));
    }

    @ApiOperation("解锁工单物料By pkg")
    @PostMapping("/unLockMaterialByPkgId")
    public R<Integer> unLockMaterialByPkgId(@RequestBody LockMaterialVO lockMaterialVO) {
        woPrepareService.unLockMaterialByPkgId(lockMaterialVO);
        return R.ok();
    }

    @ApiOperation("报废单入库")
    @PostMapping("/woDetailScrapInStorage")
    public R<WoDetailScrapInStorageDoDTO> woDetailScrapInStorage(@RequestBody WoDetailScrapInStorageDoVO scrapInStorageDoVO) {
        return R.ok(wmsWorkOrderDetailScrapInStorageDetailService.woDetailScrapInStorage(scrapInStorageDoVO));
    }


    @ApiOperation("报废单入库查询条码打印信息")
    @PostMapping("/printInfo")
    public R<ScrapProductPkgPrintDTO> selectPrintInfo(@RequestBody BadProductPkgInfoPrintVO pkgInfoPrintVO) {
        return R.ok(wmsWorkOrderDetailScrapInStorageDetailService.selectPrintInfo(pkgInfoPrintVO));
    }

    @ApiOperation("解锁CKD物料By pkg")
    @PostMapping("/unLockCkdMaterialByPkgId")
    public R<Void> unLockCkdMaterialByPkgId(@RequestBody LockMaterialVO lockMaterialVO) {
        woPrepareService.unLockCkdMaterialByPkgId(lockMaterialVO);
        return R.ok();
    }

    @ApiOperation("工单单盘移转扫描pkg")
    @GetMapping("/scanMovePkg")
    public R<WoMovePkgScanDTO> selectMovePkgInfo(@ApiParam(value = "工厂组织", required = true) @RequestParam("orgCode") String orgCode, @ApiParam(value = "条码号", required = true) @RequestParam("pkgId") String pkgId) {
        return R.ok(wmsWorkOrderPrepareLogService.selectMovePkgInfo(orgCode, pkgId));
    }

    @ApiOperation("工单单盘移转提交")
    @PostMapping("/moveWorkOrderByPkg")
    public R<Void> moveWorkOrderByPkg(@RequestBody WoMovePkgVO woMovePkgVO) {
        woService.moveWorkOrderByPkg(woMovePkgVO);
        return R.ok();
    }

    @ApiOperation("报废单入库查询")
    @PostMapping("/scrap/list")
    public R<PageDataDTO<WoDetailScrapInStorageDTO>> selectScrapInStoragePage(@RequestBody WoDetailScrapInStorageQueryVO queryVO) {
        return R.ok(wmsWorkOrderDetailScrapInStorageDetailService.selectScrapInStoragePage(queryVO));
    }

    @ApiOperation("删除入库报废单")
    @PostMapping("/scrap/delete")
    public R<PageDataDTO<WoDetailScrapInStorageDTO>> scrapDelete(@RequestBody List<Integer> idList) {
        wmsWorkOrderDetailScrapInStorageDetailService.scrapDelete(idList);
        return R.ok();
    }

    @ApiOperation("同步报废入库单")
    @GetMapping("/syncScrapDoc")
    public R<Void> syncScrapDoc(@RequestParam("workOrderNo") String workOrderNo) {
        wmsWorkOrderDetailScrapInStorageDetailService.syncScrapDoc(workOrderNo);
        return R.ok();
    }

    @ApiOperation("报废入库单导出")
    @PostMapping("/scrapExport")
    public R<Void> scrapExport(HttpServletResponse response,
                          @RequestBody WoDetailScrapInStorageQueryVO queryVO) {
        wmsWorkOrderDetailScrapInStorageDetailService.scrapExport(response, queryVO);
        return R.ok();
    }

    @ApiOperation("根据工单找到机台号")
    @GetMapping("/getmachineCodeBywo")
    public R<List<SelectDTO>> getmachineCodeBywo(@RequestParam("orgCode") String orgCode,
                                                 @RequestParam("workOrderNo") String workOrderNo) {
        return R.ok(wmsBomFeederService.getmachineCodeBywo(orgCode, workOrderNo));
    }

    @ApiOperation("根据机台号找到轨道号")
    @GetMapping("/getFeederNoByMachine")
    public R<List<SelectDTO>> getFeederNoByMachine(@RequestParam("orgCode") String orgCode,
                                                   @RequestParam("workOrderNo") String workOrderNo,
                                                   @RequestParam("machineCode") String machineCode) {
        return R.ok(wmsBomFeederService.getFeederNoByMachine(orgCode, workOrderNo, machineCode));
    }

    @ApiOperation("wms备料找料")
    @GetMapping("/getWmsBomFeederMaterialList")
    public R<PageDataDTO<WmsBomFeederMaterialDTO>> getWmsBomFeederMaterialList(WmsBomFeederMaterialVO bomFeederMaterialVO) {
        return R.ok(wmsWorkOrderPrepareLogService.getWmsBomFeederMaterialList(bomFeederMaterialVO));
    }

    @ApiOperation("pn工单清单根据料号、数量备料")
    @PostMapping("/pnWorkOrderPrepare")
    public R<Void> pnWorkOrderPrepare(@RequestBody PnWorkOrderPrepareVO prepareVO) {
        woPrepareService.pnWorkOrderPrepare(prepareVO);
        return R.ok();
    }

    @ApiOperation("pn物料清单BY库存汇总")
    @GetMapping("/pnDetailInventory")
    public R<List<PnDetailInventoryDTO>> pnDetailInventory(@RequestParam("orgCode") String orgCode,
                                                           @RequestParam("plantCode") String plantCode,
                                                           @RequestParam("partNo") String partNo) {
        return R.ok(woPrepareService.pnDetailInventory(orgCode, plantCode, partNo));
    }

    @ApiOperation("PDAwms备料找料")
    @GetMapping("/getWmsBomFeederPrepareMaterialList")
    public R<List<WmsBomFeederPrepareMaterialDTO>> getWmsBomFeederPrepareMaterialList(WmsBomFeederMaterialVO bomFeederMaterialVO) {
        return R.ok(woPrepareService.getWmsBomFeederPrepareMaterialList(bomFeederMaterialVO));
    }

    @ApiOperation("PDAwms备料找料下架")
    @PostMapping("/unShelfBomFeederMaterial")
    public R<Void> unShelfBomFeederMaterial(@RequestBody UnShelfBomFeederMaterialVO unShelfBomFeederMaterialVO) {
        woPrepareService.unShelfBomFeederMaterial(unShelfBomFeederMaterialVO);
        return R.ok();
    }

    @ApiOperation("PDA查询组装缺料备料工单明细信息")
    @PostMapping("/assyPrepareDetailList")
    public R<PageDataDTO<AssyDetailShortageDTO>> assyPrepareDetailList(@RequestBody AssyDetailShortagePageQueryVO pageQueryVO) {
        return R.ok(woService.assyPrepareDetailList(pageQueryVO));
    }

    @ApiOperation("工单明细Jit缺料试算")
    @PostMapping("/calculateWoDetailJitShortage")
    public R<Void> calculateWoDetailJitShortage(@RequestBody CalculateShortageVO calculateShortageVO) {
        woPrepareService.calculateWorkOrderDetailJitShortage(calculateShortageVO.getWorkOrderNoList(),
                calculateShortageVO.getOrgCode());
        return R.ok();
    }

    @ApiOperation("工单明细Jit缺料单头信息")
    @PostMapping("/woDetailJitShortageHeaderList")
    public R<PageDataDTO<WoDetailJitShortageHeaderDTO>> selectWoDetailJitShortageHeaderPage(
            @RequestBody WoDetailShortageHeaderQueryVO pageQueryVO) {
        return R.ok(wmsWorkOrderDetailJitShortageHeaderService.selectJitShortageHeaderPage(pageQueryVO));
    }

    @ApiOperation("工单明细Jit缺料单身信息")
    @PostMapping("/woDetailJitShortageDetailList")
    public R<PageDataDTO<WoDetailJitShortageDetailDTO>> selectWoDetailJitShortageDetailPage(
            @RequestBody WoDetailShortageDetailQueryVO pageQueryVO) {
        return R.ok(wmsWorkOrderDetailJitShortageDetailService.selectJitShortageDetailPage(pageQueryVO));
    }

    @ApiOperation("工单明细Jit缺料报表Excel导出")
    @PostMapping("/exportWoDetailJitShortageInfo")
    public R<Void> exportWoDetailJitShortageInfo(HttpServletResponse response,
                                                 @RequestBody WoDetailShortageDetailQueryVO queryVO) {
        wmsWorkOrderDetailJitShortageDetailService.exportWoDetailJitShortageInfo(response, queryVO);
        return R.ok();
    }

    @ApiOperation("CKD打包清单excel导出")
    @PostMapping("/exportCkdPrepareLog")
    public R<Void> exportCkdPrepareLog(HttpServletResponse response,
                                       @RequestBody CkdPrepareLogPageQueryVO pageQueryVO) {
        workOrderPrepareCkdLogService.exportCkdPrepareLog(response, pageQueryVO);
        return R.ok();
    }

    @ApiOperation("手动抛转MSD")
    @PostMapping("/postingMSDToSFC")
    R<List<PostingMSDToSFCDTO>> postingMSDToSFC(@RequestBody PostingMSDToSFCVO vo){
        return R.ok(woService.postingMSDToSFC(vo));
    }

    @ApiOperation("工单在库直备ASSY")
    @PostMapping("/prepare/prepareAssyDirectInStock")
    public R<InStockDirectPrepareDTO> prepareAssyDirectInStock(@RequestBody InStockDirectPrepareVO stockDirectPrepareVO) {
        return woPrepareService.prepareAssyDirectInStock(stockDirectPrepareVO.getPkgId(), stockDirectPrepareVO.getWorkOrderNo(), stockDirectPrepareVO.getOrgCode(), stockDirectPrepareVO.getVehicleCode(), stockDirectPrepareVO.getConfirmStock());
    }

    @ApiOperation("查询移转工单明细信息")
    @PostMapping("/moveOrderDetailList")
    public R<List<MoveOrderDTO>> selectMoveOrderDetail(@RequestBody MoveOrderVO moveOrderVO){
        return R.ok(wmsWorkOrderDetailService.selectMoveOrderDetail(moveOrderVO));
    }

    @ApiOperation("查询备料载具接收信息")
    @PostMapping("/vehicleAcceptList")
    public R<List<PrepareVehicleAcceptDTO>> selectPrepareVehicleAcceptList(
            @RequestBody PrepareVehicleAcceptScanVO acceptScanVO){
        return R.ok(wmsWorkOrderPrepareLogService.selectPrepareVehicleAccept(acceptScanVO));
    }

    @ApiOperation("备料载具接收")
    @PostMapping("/acceptPrepareVehicle")
    public R<Integer> acceptPrepareVehicle(@RequestBody PrepareVehicleAcceptVO prepareVehicleAcceptVO) {
        return R.ok(wmsWorkOrderPrepareLogService.acceptPrepareVehicle(prepareVehicleAcceptVO));
    }
}
