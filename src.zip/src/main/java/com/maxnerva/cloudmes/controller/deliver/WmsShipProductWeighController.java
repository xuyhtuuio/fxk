package com.maxnerva.cloudmes.controller.deliver;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.deliver.ProductShipWeightScanDTO;
import com.maxnerva.cloudmes.models.dto.deliver.WeightScanCmbPkgIdDTO;
import com.maxnerva.cloudmes.models.vo.deliver.*;
import com.maxnerva.cloudmes.service.deliver.IWmsShipProductWeighService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @ClassName WmsShipProductWeighController
 * @Description shipping称重
 * @Author Likun
 * @Date 2023/10/5
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "shipping称重")
@Slf4j
@RestController
@RequestMapping("/productWeigh")
public class WmsShipProductWeighController {

    @Resource
    private IWmsShipProductWeighService wmsShipProductWeighService;

    @ApiOperation("扫描条码称重")
    @PostMapping("/scanPkgId")
    public R<ProductShipWeightScanDTO> scanPkgId(@RequestBody ProductShipWeightScanVO productShipWeightScanVO) {
        return R.ok(wmsShipProductWeighService.scanPkgId(productShipWeightScanVO));
    }

    @ApiOperation("称重提交")
    @PostMapping("/submit")
    public R<Void> submit(@RequestBody ProductShipWeightSubmitVO productShipWeightSubmitVO) {
        wmsShipProductWeighService.submit(productShipWeightSubmitVO);
        return R.ok();
    }

    @ApiOperation("机构CMB称重扫描PKG")
    @PostMapping("/scanCmbWeighPkgId")
    public R<WeightScanCmbPkgIdDTO> scanCmbPkgId(@RequestBody WeightScanCmbPkgIdVO vo){
        return R.ok(wmsShipProductWeighService.scanCmbPkgId(vo));
    }

    @ApiOperation("机构CMB称重提交")
    @PostMapping("/cmbSubmit")
    public R<Void> submit(@RequestBody ProductShipWeightCmbSubmitVO vo) {
        wmsShipProductWeighService.cmbSubmit(vo);
        return R.ok();
    }

    @ApiOperation("机构CMB称重超过3%发送邮件")
    @PostMapping("/weighFailSendEmail")
    public R weighFailSendEmail(@RequestBody WeighFailSendEmailVO vo){
        wmsShipProductWeighService.weighFailSendEmail(vo);
        return R.ok();
    }
}
