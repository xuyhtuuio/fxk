package com.maxnerva.cloudmes.controller.assyprepare;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.assyprepare.AssyLocationConfigDTO;
import com.maxnerva.cloudmes.models.vo.ExcelImportVO;
import com.maxnerva.cloudmes.models.vo.assyprepare.AssyLocationConfigQueryVO;
import com.maxnerva.cloudmes.service.assyprepare.IWmsAssyLocationConfigService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

/**
 * @ClassName AssyLocationConfigController
 * @Description 上料表信息管理
 * @Author Likun
 * @Date 2024/4/30
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "上料表信息管理")
@Slf4j
@RestController
@RequestMapping("/assyLocationConfig")
public class AssyLocationConfigController {

    @Resource
    private IWmsAssyLocationConfigService wmsAssyLocationConfigService;

    @ApiOperation("上料表信息excel导入")
    @PostMapping("/import")
    public R<Void> importAssyLocationConfig(ExcelImportVO excelImportVO) {
        wmsAssyLocationConfigService.importAssyLocationConfig(excelImportVO);
        return R.ok();
    }

    @ApiOperation("上料表信息excel导出")
    @PostMapping("/export")
    public R<Void> exportAssyLocationConfig(HttpServletResponse response,
                                        @RequestBody AssyLocationConfigQueryVO queryVO) {
        wmsAssyLocationConfigService.exportAssyLocationConfig(response, queryVO);
        return R.ok();
    }

    @ApiOperation("分页查询上料表信息")
    @PostMapping("/list")
    public R<PageDataDTO<AssyLocationConfigDTO>> selectConfigPage(@RequestBody AssyLocationConfigQueryVO queryVO){
        return R.ok(wmsAssyLocationConfigService.selectConfigPage(queryVO));
    }
}
