package com.maxnerva.cloudmes.controller.doc;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.doc.DocTcDetailDTO;
import com.maxnerva.cloudmes.models.dto.doc.DocTcHeaderDTO;
import com.maxnerva.cloudmes.models.vo.doc.*;
import com.maxnerva.cloudmes.service.doc.IWmsDocTcHeaderService;
import com.maxnerva.cloudmes.service.doc.IWmsDocTcService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;

@Api(tags = "特采单管理")
@Slf4j
@RestController
@RequestMapping("/docTc")
public class DocTcController {

    @Autowired
    IWmsDocTcHeaderService wmsDocTcHeaderService;

    @Autowired
    IWmsDocTcService wmsDocTcService;

    @ApiOperation("特采单回写（节点调用，不对外提供）")
    @PostMapping("/dataHub/replyByTcOrder")
    R dataHubReplyByTcOrder(@RequestBody ReplyByTcOrderVO vo){
        wmsDocTcHeaderService.replyByTcOrder(vo);
        return R.ok();
    }

    @ApiOperation("特采Header查询")
    @GetMapping("/selectPageList")
    R<PageDataDTO<DocTcHeaderDTO>> selectPageList(SelectDocTcHeaderPageVO vo){
        return R.ok(wmsDocTcHeaderService.selectPageList(vo, Boolean.TRUE));
    }

    @ApiOperation("特采Detail查询")
    @GetMapping("/selectDetailPageList")
    R<PageDataDTO<DocTcDetailDTO>> selectDetailPageList(SelectDocTcDetailPageVO vo){
        return R.ok(wmsDocTcHeaderService.selectDetailPageList(vo, Boolean.TRUE));
    }

    @ApiOperation("导出特采明细")
    @PostMapping("/exportDetail")
    void exportDetail(@RequestBody ExportTcDetailVO vo, HttpServletResponse response){
        wmsDocTcHeaderService.exportDetail(vo, response);
    }

    @ApiOperation("手动发起特采")
    @PostMapping("/handleTcHeader")
    R handleTcHeader(@RequestBody GenerateTcHeaderVO vo) {
        wmsDocTcService.handleTcHeader(vo);
        return R.ok();
    }
}
