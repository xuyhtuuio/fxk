package com.maxnerva.cloudmes.controller.inventory;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.inventory.InventoryPkgDTO;
import com.maxnerva.cloudmes.models.dto.inventory.InventoryPkgRecordDTO;
import com.maxnerva.cloudmes.models.dto.inventory.InventoryPlanDetailDTO;
import com.maxnerva.cloudmes.models.dto.inventory.InventoryPlanHeaderDTO;
import com.maxnerva.cloudmes.models.vo.inventory.*;
import com.maxnerva.cloudmes.service.inventory.IWmsInventoryPlanDetailService;
import com.maxnerva.cloudmes.service.inventory.IWmsInventoryPlanHeaderService;
import com.maxnerva.cloudmes.service.warehouse.IWmsPkgInfoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @ClassName InventoryController
 * @Description 盘点单管理
 * @Author Likun
 * @Date 2023/3/25
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "盘点单管理")
@Slf4j
@RestController
@RequestMapping("/inventory")
public class InventoryController {

    @Resource
    private IWmsInventoryPlanHeaderService wmsInventoryPlanHeaderService;

    @Resource
    private IWmsInventoryPlanDetailService wmsInventoryPlanDetailService;

    @Resource
    private IWmsPkgInfoService wmsPkgInfoService;

    @ApiOperation("新增盘点计划")
    @PostMapping("/add")
    public R<Void> addInventoryPlan(@RequestBody InventoryPlanInsertVO inventoryPlanInsertVO) {
        wmsInventoryPlanHeaderService.addInventoryPlan(inventoryPlanInsertVO);
        return R.ok();
    }

    @ApiOperation("查询盘点计划单头")
    @PostMapping("/headerList")
    public R<PageDataDTO<InventoryPlanHeaderDTO>> selectHeaderPage(@RequestBody InventoryPlanHeaderQueryVO queryVO) {
        return R.ok(wmsInventoryPlanHeaderService.selectHeaderPage(queryVO));
    }

    @ApiOperation("完成盘点计划")
    @PostMapping("/completePlan")
    public R<Integer> completePlan(@RequestBody List<Integer> idList) {
        return R.ok(wmsInventoryPlanHeaderService.completeInventoryPlan(idList));
    }

    @ApiOperation("查询盘点计划详情")
    @GetMapping("/headerInfo/{id}")
    public R<InventoryPlanHeaderDTO> selectHeaderInfo(@PathVariable("id") Integer id) {
        return R.ok(wmsInventoryPlanHeaderService.selectByHeaderId(id));
    }

    @ApiOperation("查询盘点计划单身")
    @PostMapping("/detailList")
    public R<PageDataDTO<InventoryPlanDetailDTO>> selectDetailPage(@RequestBody InventoryPlanDetailQueryVO queryVO) {
        return R.ok(wmsInventoryPlanDetailService.selectDetailPage(queryVO));
    }

    @ApiOperation("查询盘点条码记录")
    @PostMapping("/pkgRecordList")
    public R<List<InventoryPkgRecordDTO>> selectPkgRecordList(@RequestBody InventoryPkgRecordQueryVO queryVO) {
        return R.ok(wmsInventoryPlanDetailService.selectPkgRecordList(queryVO));
    }

    @ApiOperation("盘点pkgId")
    @PostMapping("/inventoryPkgId")
    public R<Void> inventoryPkgId(@RequestBody InventoryVO inventoryVO) {
        return wmsInventoryPlanDetailService.inventoryPkgId(inventoryVO);
    }

    @ApiOperation("查询盘点条码明细")
    @PostMapping("/pkgList")
    public R<PageDataDTO<InventoryPkgDTO>> selectInventoryPkgPage(@RequestBody InventoryPkgQueryVO queryVO) {
        return R.ok(wmsPkgInfoService.selectInventoryPkgList(queryVO));
    }

    @ApiOperation("盘点计划报表导出")
    @PostMapping("/exportDetailList")
    public R<Void> exportDetailList(HttpServletResponse response, @RequestBody InventoryPlanDetailQueryVO queryVO) {
        wmsInventoryPlanDetailService.exportDetailList(response, queryVO);
        return R.ok();
    }

    @ApiOperation("查询料车盘点计划详情")
    @GetMapping("/skipHeaderInfo/{id}")
    public R<InventoryPlanHeaderDTO> selectSkipHeaderInfo(@PathVariable("id") Integer id) {
        return R.ok(wmsInventoryPlanHeaderService.selectSkipHeaderInfo(id));
    }

    @ApiOperation("跳过位置")
    @PostMapping("/skipPosition")
    public R<Void> skipPosition(@RequestBody InventoryVO inventoryVO) {
        return R.ok(wmsInventoryPlanDetailService.skipPosition(inventoryVO));
    }

    @ApiOperation("料车盘点pkgId")
    @PostMapping("/inventorySkipPkgId")
    public R<Void> inventorySkipPkgId(@RequestBody InventoryVO inventoryVO) {
        return wmsInventoryPlanDetailService.inventorySkipPkgId(inventoryVO);
    }

    @ApiOperation("删除盘点单")
    @DeleteMapping("/delete")
    public R<Void> deleteInventory(@RequestBody DeleteInventoryVO vo) {
        wmsInventoryPlanDetailService.deleteInventory(vo);
        return R.ok();
    }

    @ApiOperation("盘点报表导出")
    @PostMapping("/exportInventoryReport")
    public R<Void> exportInventoryReport(HttpServletResponse response,
                                      @RequestBody List<String> inventoryPlanNoList) {
        wmsInventoryPlanHeaderService.exportInventoryReport(response, inventoryPlanNoList);
        return R.ok();
    }

    @ApiOperation("盘点计划报表导出")
    @PostMapping("/exportInventoryPlan")
    public R<Void> exportInventoryPlanHeader(HttpServletResponse response,
                                          @RequestBody InventoryPlanHeaderQueryVO queryVO) {
        wmsInventoryPlanHeaderService.exportInventoryPlanHeader(response, queryVO);
        return R.ok();
    }

    @ApiOperation("按照盘点库区配置定时新增盘点计划")
    @GetMapping("/regularlyCreateInventoryPlan")
    public R<Void> regularlyCreateInventoryPlan(@RequestParam("orgCode") String orgCode){
        wmsInventoryPlanHeaderService.regularlyCreateInventoryPlan(orgCode);
        return R.ok();
    }
}
