package com.maxnerva.cloudmes.controller.assyprepare;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.assyprepare.WmsMaterialAreaConfigDTO;
import com.maxnerva.cloudmes.models.vo.ExcelImportVO;
import com.maxnerva.cloudmes.models.vo.assyprepare.MaterialAreaConfigVO;
import com.maxnerva.cloudmes.models.vo.assyprepare.WmsMaterialAreaConfigQueryVO;
import com.maxnerva.cloudmes.service.assyprepare.IWmsMaterialAreaConfigService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @ClassName MaterialAreaConfigController
 * @Description 料号库区配置管理
 * @Author Likun
 * @Date 2024/7/30
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "料号库区配置管理")
@Slf4j
@RestController
@RequestMapping("/materialAreaConfig")
public class MaterialAreaConfigController {

    @Resource
    private IWmsMaterialAreaConfigService wmsMaterialAreaConfigService;

    @ApiOperation("分页查询料号库区配置")
    @PostMapping("/list")
    public R<PageDataDTO<WmsMaterialAreaConfigDTO>> selectMaterialAreaConfigPage(
            @RequestBody WmsMaterialAreaConfigQueryVO queryVO){
        return R.ok(wmsMaterialAreaConfigService.selectMaterialAreaConfigPage(queryVO));
    }

    @ApiOperation("料号库区配置导出")
    @PostMapping("/export")
    public R<Void> exportMaterialAreaConfig(HttpServletResponse response,
                                            @RequestBody WmsMaterialAreaConfigQueryVO queryVO){
        wmsMaterialAreaConfigService.exportMaterialAreaConfig(response,queryVO);
        return R.ok();
    }

    @ApiOperation("料号库区配置新增/修改")
    @PostMapping("/saveOrUpdateConfig")
    public R<Void> saveOrUpdateConfig(@RequestBody MaterialAreaConfigVO materialAreaConfigVO){
        wmsMaterialAreaConfigService.saveOrUpdateConfig(materialAreaConfigVO);
        return R.ok();
    }

    @ApiOperation("区域下拉查询")
    @GetMapping("/areaCodeList")
    public R<List<String>> selectAreaCodeByMaterialSort(@RequestParam("orgCode")String orgCode){
        return R.ok(wmsMaterialAreaConfigService.selectAreaCodeByMaterialSort(orgCode, "RAW"));
    }

    @ApiOperation("料号库区关系导入")
    @PostMapping("/importConfig")
    public R<Void> importConfig(ExcelImportVO excelImportVO){
        wmsMaterialAreaConfigService.importConfig(excelImportVO);
        return R.ok();
    }
}
