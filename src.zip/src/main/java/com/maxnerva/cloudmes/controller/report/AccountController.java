package com.maxnerva.cloudmes.controller.report;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.report.*;
import com.maxnerva.cloudmes.models.vo.report.*;
import com.maxnerva.cloudmes.service.report.IAccountService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;

@Api(tags = "过账报表")
@Slf4j
@RestController
@RequestMapping("/accountReport")
public class AccountController {
    @Autowired
    IAccountService accountService;

    @ApiOperation("工单发料261过账报表")
    @GetMapping("/getPost261")
    R<PageDataDTO<GetPost261DTO>> getPost261(GetPost261VO vo){
        return R.ok(accountService.getPost261(vo, true));
    }

    @ApiOperation("工单发料261过账报表导出")
    @GetMapping("/getPost261Export")
    void getPost261Export(GetPost261VO vo, HttpServletResponse response){
        accountService.getPost261Export(vo, response);
    }

    @ApiOperation("工单退料262过账报表")
    @GetMapping("/getReturn262")
    R<PageDataDTO<GetReturn262DTO>> getReturn262(GetReturn262VO vo){
        return R.ok(accountService.getReturn262(vo, true));
    }

    @ApiOperation("工单退料262过账报表导出")
    @GetMapping("/getReturn262Export")
    void getReturn262Export(GetReturn262VO vo, HttpServletResponse response){
        accountService.getReturn262Export(vo, response);
    }

    @ApiOperation("转仓单过账失败报表")
    @GetMapping("/getTransferFail")
    R<PageDataDTO<GetTransferFailDTO>> getTransferFail(GetTransferFailVO vo){
        return R.ok(accountService.getTransferFail(vo, true));
    }

    @ApiOperation("转仓单过账失败报表导出")
    @GetMapping("/getTransferFailExport")
    void getTransferFailExport(GetTransferFailVO vo, HttpServletResponse response){
        accountService.getTransferFailExport(vo, response);
    }

    @ApiOperation("料调单过账明细")
    @GetMapping("/getAdjustPartFail")
    public R<PageDataDTO<GetAdjustPartFailDTO>> getAdjustPartFail (GetAdjustPartFailVO vo){
        return R.ok(accountService.getAdjustPartFail(vo, true));
    }

    @ApiOperation("料调单过账明细导出")
    @GetMapping("/getAdjustPartFailExport")
    public void getAdjustPartFailExport (GetAdjustPartFailVO vo, HttpServletResponse response){
        accountService.getAdjustPartFailExport(vo, response);
    }

    @ApiOperation("成品入库过账明细")
    @GetMapping("/transaction101Fail")
    public R<PageDataDTO<Transaction101FailDTO>> transaction101Fail (Transaction101FailVO vo){
        return R.ok(accountService.transaction101Fail(vo, true));
    }

    @ApiOperation("成品入库过账明细导出")
    @GetMapping("/transaction101FailExport")
    public void transaction101FailExport (Transaction101FailVO vo, HttpServletResponse response){
        accountService.transaction101FailExport(vo, response);
    }

    @ApiOperation("531入库失败明细")
    @GetMapping("/get531Fail")
    public R<PageDataDTO<Get531FailDTO>> get531Fail (Get531FailVO vo){
        return R.ok(accountService.get531Fail(vo, true));
    }

    @ApiOperation("531入库失败明细导出")
    @GetMapping("/get531FailExport")
    public void get531FailExport (Get531FailVO vo, HttpServletResponse response){
        accountService.get531FailExport(vo, response);
    }

    @ApiOperation("收货过账失败明细")
    @GetMapping("/receiveFail")
    public R<PageDataDTO<ReceiveFailDTO>> receiveFail (ReceiveFailVO vo){
        return R.ok(accountService.receiveFail(vo, true));
    }

    @ApiOperation("收货过账失败明细导出")
    @GetMapping("/receiveFailExport")
    public void receiveFailExport (ReceiveFailVO vo, HttpServletResponse response){
        accountService.receiveFailExport(vo, response);
    }

    @ApiOperation("准时达（三方过账）收货明细")
    @GetMapping("/thirdFail")
    public R<PageDataDTO<ThirdFailDTO>> thirdFail (ThirdFailVO vo){
        return R.ok(accountService.thirdFail(vo, true));
    }

    @ApiOperation("准时达（三方过账）收货明细导出")
    @GetMapping("/thirdFailExport")
    public void thirdFailExport (ThirdFailVO vo, HttpServletResponse response){
        accountService.thirdFailExport(vo, response);
    }

    @ApiOperation("CKD过账明细")
    @GetMapping("/getCkdTransactionLogInfo")
    public R<PageDataDTO<GetCkdTransactionLogInfoDTO>> getCkdTransactionLogInfo (GetCkdTransactionLogInfoVO vo){
        return R.ok(accountService.getCkdTransactionLogInfo(vo, true));
    }

    @ApiOperation("CKD过账明细导出")
    @GetMapping("/getCkdTransactionLogInfoExport")
    public void getCkdTransactionLogInfoExport (GetCkdTransactionLogInfoVO vo, HttpServletResponse response){
        accountService.getCkdTransactionLogInfoExport(vo, response);
    }

    @ApiOperation("费领退过账失败")
    @GetMapping("/getCostIssue")
    public R<PageDataDTO<GetCostIssueDTO>> getCostIssue(GetCostIssueVO vo){
        return R.ok(accountService.getCostIssue(vo, true));
    }

    @ApiOperation("费领退过账失败导出")
    @GetMapping("/getCostIssueExport")
    public void getCostIssueExport(GetCostIssueVO vo, HttpServletResponse response){
        accountService.getCostIssueExport(vo, response);
    }

    @ApiOperation("工单过账失败明细报表")
    @GetMapping("/getWorkOrderPostFail")
    R<PageDataDTO<GetWorkOrderPostFailDTO>> getWorkOrderPostFail(GetWorkOrderPostFailVO vo){
        return R.ok(accountService.getWorkOrderPostFail(vo, true));
    }

    @ApiOperation("工单过账失败明细报表导出")
    @GetMapping("/getWorkOrderPostFailExport")
    void getWorkOrderPostFailExport(GetWorkOrderPostFailVO vo, HttpServletResponse response){
        accountService.getWorkOrderPostFailExport(vo, response);
    }

    @ApiOperation("DN是否扣账")
    @GetMapping("/getDnTransaction")
    R<PageDataDTO<GetDnTransactionDTO>> getDnTransaction(GetDnTransactionVO vo){
        return R.ok(accountService.getDnTransaction(vo, Boolean.TRUE));
    }

    @ApiOperation("DN是否扣账导出")
    @GetMapping("/getDnTransactionExport")
    void getDnTransactionExport(GetDnTransactionVO vo, HttpServletResponse response){
        accountService.getDnTransactionExport(vo, response);
    }

    @ApiOperation("勾兑报关单失败明细")
    @GetMapping("/docBlendingCusFail")
    R<PageDataDTO<DocBlendingCusFailDTO>> docBlendingCusFail(DocBlendingCusFailVO vo){
        return R.ok(accountService.docBlendingCusFail(vo, Boolean.TRUE));
    }

    @ApiOperation("勾兑报关单失败明细导出")
    @GetMapping("/docBlendingCusFailExport")
    void docBlendingCusFailExport(DocBlendingCusFailVO vo, HttpServletResponse response){
        accountService.docBlendingCusFailExport(vo, response);
    }

    @ApiOperation("手动终止报关单勾兑")
    @PostMapping("/updateDocBlendingCusFlag")
    R updateDocBlendingCusFlag(@RequestBody UpdateDocBlendingCusFlagVO vo){
        accountService.updateDocBlendingCusFlag(vo);
        return R.ok();
    }
}
