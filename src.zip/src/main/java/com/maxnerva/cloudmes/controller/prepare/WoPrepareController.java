package com.maxnerva.cloudmes.controller.prepare;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.enums.PickTaskTypeEnum;
import com.maxnerva.cloudmes.enums.PickingTypeEnum;
import com.maxnerva.cloudmes.models.dto.prepare.*;
import com.maxnerva.cloudmes.models.dto.warehouse.PkgPrintDTO;
import com.maxnerva.cloudmes.models.dto.wo.PickWoHeaderDTO;
import com.maxnerva.cloudmes.models.vo.basic.VehicleLocationBindVO;
import com.maxnerva.cloudmes.models.vo.basic.VehicleMaterialTransferVO;
import com.maxnerva.cloudmes.models.vo.prepare.*;
import com.maxnerva.cloudmes.models.vo.warehouse.PkgInfoPrintVO;
import com.maxnerva.cloudmes.models.vo.warehouse.ScanBinVO;
import com.maxnerva.cloudmes.models.vo.wo.LockMaterialVO;
import com.maxnerva.cloudmes.service.lock.LockService;
import com.maxnerva.cloudmes.service.prepare.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @ClassName WoPrepareController
 * @Description 工单备料管理(新)
 * @Author Likun
 * @Date 2023/5/8
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "工单备料管理(新)")
@Slf4j
@RestController
@RequestMapping("/woPrepare")
public class WoPrepareController {

    @Resource
    private IWmsLockMaterialService wmsLockMaterialService;

    @Resource
    private IWmsPickingService wmsPickingService;

    @Resource
    private IWorkOrderPrepareService workOrderPrepareService;

    @Resource
    private IWmsMaterialDistributionService wmsMaterialDistributionService;

    @Resource
    private IWmsPartitionService wmsPartitionService;

    @Resource
    private IWmsMaterialOnlineService wmsMaterialOnlineService;

    @Resource
    private IWmsBurnService wmsBurnService;

    @Resource
    private IWmsMaterialReturnWarehouseService wmsMaterialReturnWarehouseService;

    @Resource
    private IWmsVehicleUsageService wmsVehicleUsageService;

    @Resource
    private IWmsVehiclePkgTransferService wmsVehiclePkgTransferService;

    @Resource
    private IWmsMaterialControlService wmsMaterialControlService;

    @Resource
    private IWmsVehicleBindLocationService wmsVehicleBindLocationService;

    @Resource
    private IWmsUrgentPickService wmsUrgentPickService;

    @Resource
    private IWmsWorkOrderPickLogService wmsWorkOrderPickLogService;

    @Resource
    private LockService lockService;

    @ApiOperation("锁料-By工单")
    @PostMapping("/lockMaterial")
    public R<Void> lockMaterial(@RequestBody LockMaterialVO lockMaterialVO) {
        return wmsLockMaterialService.lockMaterial(lockMaterialVO);
    }

    @ApiOperation("解锁-By工单")
    @PostMapping("/unLockMaterial")
    public R<Void> unLockMaterial(@RequestBody LockMaterialVO lockMaterialVO) {
        wmsLockMaterialService.unLockMaterial(lockMaterialVO.getWorkOrderNo(), lockMaterialVO.getOrgCode());
        return R.ok();
    }

    @ApiOperation("解锁-By pkg")
    @PostMapping("/unLockMaterialByPkg")
    public R<Void> unLockMaterialByPkg(@RequestBody LockMaterialVO lockMaterialVO) {
        wmsLockMaterialService.unLockMaterialByPkg(lockMaterialVO);
        return R.ok();
    }

    @ApiOperation("捡料--获取取料信息")
    @PostMapping("/adviceRetrievalInfo")
    public R<AdviceRetrievalDTO> getAdviceRetrievalInfo(@RequestBody AdviceRetrievalVO adviceRetrievalVO) {
        return R.ok(wmsPickingService.getAdviceRetrievalInfo(adviceRetrievalVO));
    }

    @ApiOperation("捡料--扫描载具")
    @PostMapping("/scanPickingVehicle")
    public R<Void> scanPickingVehicle(@RequestBody PickingVehicleScanVO pickingVehicleScanVO) {
        wmsPickingService.scanPickingVehicle(pickingVehicleScanVO);
        return R.ok();
    }

    @ApiOperation("捡料--提交捡料信息")
    @PostMapping("/submitPickingInfo")
    public R<Void> submitPickingInfo(@RequestBody PickingSubmitVO pickingSubmitVO) {
        return lockService.submitPickingInfo(pickingSubmitVO);
    }

    @ApiOperation("生产排配列表")
    @GetMapping("/productSchedul")
    public R<PageDataDTO<ProductSchedulDTO>> productSchedul(ProductSchedulVO productSchedulVO) {
        return R.ok(workOrderPrepareService.productSchedul(productSchedulVO));
    }

    @ApiOperation("同步上料表")
    @GetMapping("/syncBomFeederFromSfc")
    public R<Void> syncBomFeederFromSfc(SyncWoInfoVO syncWoInfoVO) {
        workOrderPrepareService.syncBomFeederFromSfc(syncWoInfoVO);
        return R.ok();
    }

    @ApiOperation("同步工单Detail")
    @GetMapping("/syncSapWorkOrderDetail")
    public R<Void> syncSapWorkOrderDetail(SyncWoInfoVO syncWoInfoVO) {
        workOrderPrepareService.syncSapWorkOrderDetail(syncWoInfoVO);
        return R.ok();
    }

    @ApiOperation("回写工单信息")
    @GetMapping("/writeWoDetailInfo")
    public R<Void> writeWoDetailInfo(SyncWoInfoVO syncWoInfoVO) {
        workOrderPrepareService.writeWoDetailInfo(syncWoInfoVO);
        return R.ok();
    }

    @ApiOperation("捡料任务列表")
    @GetMapping("/pickTaskList")
    public R<PageDataDTO<PickTaskListDTO>> pickTaskList(PickTaskPageQueryVO pageQueryVO) {
        return R.ok(workOrderPrepareService.pickTaskList(pageQueryVO));
    }

    @ApiOperation("捡料任务详情列表")
    @GetMapping("/pickTaskDetailList")
    public R<PageDataDTO<PickTaskDetailListDTO>> pickTaskDetailList(PickTaskDetailVO pickTaskDetailVO) {
        return R.ok(workOrderPrepareService.pickTaskDetailList(pickTaskDetailVO));
    }

    @ApiOperation("对外CKD备料记录")
    @GetMapping("/ckdPrepaerLog")
    public R<List<CkdPrepaerLogDTO>> ckdPrepaerLog(@RequestParam("palletNo") String palletNo) {
        return R.ok(workOrderPrepareService.ckdPrepaerLog(palletNo));
    }

    @ApiOperation("同步SAP")
    @PostMapping("/synchronousSap")
    public R<Void> synchronousSap(@RequestBody SyncWoInfoVO syncWoInfoVO) {
        String msg = workOrderPrepareService.synchronousSap(syncWoInfoVO);
      /*  //调用同步工单Detail接口
        workOrderPrepareService.syncSapWorkOrderDetail(syncWoInfoVO);
        //调用同步上料表接口
        workOrderPrepareService.syncBomFeederFromSfc(syncWoInfoVO);*/
        return R.ok(msg);
    }

    @ApiOperation("分料--扫描捡料载具查询待分料信息")
    @PostMapping("/scanPickVehicle")
    public R<PickVehicleScanDTO> scanPickVehicle(@RequestBody VehicleScanVO vehicleScanVO) {
        return R.ok(wmsMaterialDistributionService.scanPickVehicle(vehicleScanVO));
    }

    @ApiOperation("分料--扫描捡料载具查询工单位置信息信息")
    @PostMapping("/getWorkOrderToLocation")
    public R<List<String>> getWorkOrderToLocation(@RequestBody VehicleScanVO vehicleScanVO) {
        return R.ok(wmsMaterialDistributionService.getWorkOrderToLocation(vehicleScanVO));
    }

    @ApiOperation("分料--载具绑定工单位置信息校验")
    @PostMapping("/bindWorkOrderLocation")
    public R<Void> bindWorkOrderLocation(@RequestBody DistributeBindCheckVO distributeBindCheckVO) {
        wmsMaterialDistributionService.bindWorkOrderLocation(distributeBindCheckVO);
        return R.ok();
    }

    @ApiOperation("分料--分料提交")
    @PostMapping("/submitDistributeInfo")
    public R<DistributeSubmitDTO> submitDistributeInfo(@RequestBody DistributeSubmitVO distributeSubmitVO) {
        return wmsMaterialDistributionService.submitDistributeInfo(distributeSubmitVO);
    }

    @ApiOperation("分盘操作--分盘提交")
    @PostMapping("/submitPartitionInfo")
    public R<PartitionSubmitDTO> submitPartitionInfo(@RequestBody PartitionSubmitVO partitionSubmitVO) {
        return R.ok(wmsPartitionService.submitPartitionInfo(partitionSubmitVO));
    }

    @ApiOperation("物料上线--校验移入载具")
    @PostMapping("/checkPrepareVehicle")
    public R<Void> checkPrepareVehicle(@RequestBody VehicleScanVO vehicleScanVO) {
        wmsMaterialOnlineService.checkPrepareVehicle(vehicleScanVO);
        return R.ok();
    }

    @ApiOperation("物料上线--校验起始储位")
    @PostMapping("/checkPrepareBin")
    public R<Void> checkPrepareBin(@RequestBody ScanBinVO scanBinVO) {
        wmsMaterialOnlineService.checkPrepareBin(scanBinVO);
        return R.ok();
    }

    @ApiOperation("物料上线--扫描移出载具")
    @PostMapping("/scanDistributeVehicle")
    public R<DistributeVehicleScanDTO> scanDistributeVehicle(@RequestBody VehicleScanVO vehicleScanVO) {
        return R.ok(wmsMaterialOnlineService.scanDistributeVehicle(vehicleScanVO));
    }

    @ApiOperation("物料上线--扫描pkg提交")
    @PostMapping("/submitMaterialOnlineInfo")
    public R<MaterialOnlineSubmitDTO> submitMaterialOnlineInfo(@RequestBody MaterialOnlineSubmitVO materialOnlineSubmitVO) {
        return R.ok(lockService.submitMaterialOnlineInfo(materialOnlineSubmitVO));
    }

    @ApiOperation("捡料--根据工单号查询制程类型")
    @GetMapping("/materialProductTypeList")
    public R<JusdaPickScanDTO> selectMaterialProductTypeList(@ApiParam(value = "工单号", required = true)
                                                             @RequestParam("workOrderNo") String workOrderNo,
                                                             @ApiParam(value = "工厂组织", required = true)
                                                             @RequestParam("orgCode") String orgCode,
                                                             @ApiParam(value = "栈板号", required = true)
                                                             @RequestParam("palletNo") String palletNo) {
        return R.ok(wmsPickingService.selectMaterialProductTypeList(workOrderNo, orgCode, palletNo));
    }

    @ApiOperation("捡料--jusda捡料")
    @PostMapping("/pickJusda")
    public R<JusdaPickDTO> pickJusdaInfo(@RequestBody JusdaPickVO jusdaPickVO) {
        return wmsPickingService.pickJusdaInfo(jusdaPickVO);
    }

    @ApiOperation("查询条码打印信息")
    @PostMapping("/printInfoList")
    public R<PkgPrintDTO> selectResources(@RequestBody PkgInfoPrintVO pkgInfoPrintVO) {
        return R.ok(wmsPartitionService.printPkgInfo(pkgInfoPrintVO));
    }

    @ApiOperation("烧录--校验烧录载具")
    @PostMapping("/checkBurnVehicle")
    public R<Void> checkBurnVehicle(@RequestBody VehicleScanVO vehicleScanVO) {
        wmsBurnService.checkBurnVehicle(vehicleScanVO);
        return R.ok();
    }

    @ApiOperation("烧录--物料能否烧录物料校验")
    @PostMapping("/checkBurnInfo")
    public R<Void> checkBurnInfo(@RequestBody BurnCheckVO burnCheckVO) {
        return wmsBurnService.checkBurnInfo(burnCheckVO);
    }

    @ApiOperation("分盘--烧录分盘")
    @PostMapping("/submitBurnPartitionInfo")
    public R<BurnPartitionSubmitDTO> submitBurnPartitionInfo(@RequestBody PartitionSubmitVO partitionSubmitVO) {
        return wmsPartitionService.submitBurnPartitionInfo(partitionSubmitVO);
    }

    @ApiOperation("生产排配-锁料清单")
    @GetMapping("/lockMaterialList")
    public R<PageDataDTO<LockMaterialListDTO>> lockMaterialList(LockMaterialListVO lockMaterialListVO) {
        return R.ok(workOrderPrepareService.lockMaterialList(lockMaterialListVO));
    }

    @ApiOperation("余料返仓")
    @PostMapping("/returnWarehouse")
    public R<MaterialReturnWarehouseDTO> returnWarehouse(@RequestBody VehicleMaterialTransferVO vehicleMaterialTransferVO) {
        return R.ok(wmsMaterialReturnWarehouseService.returnWarehouse(vehicleMaterialTransferVO));
    }

    @ApiOperation("载具使用现况")
    @PostMapping("/vehicleUsageList")
    public R<VehicleUsageDTO> getVehicleUsageInfo(@RequestBody VehicleScanVO vehicleScanVO) {
        return R.ok(wmsVehicleUsageService.getVehicleUsageInfo(vehicleScanVO));
    }

    @ApiOperation("校验移入载具")
    @PostMapping("/checkFromVehicle")
    public R<Void> checkFromVehicle(@RequestBody VehicleScanVO vehicleScanVO) {
        wmsVehiclePkgTransferService.checkFromVehicle(vehicleScanVO);
        return R.ok();
    }

    @ApiOperation("校验移出载具(需校验完移入载具)")
    @PostMapping("/checkToVehicle")
    public R<VehiclePkgTransferScanDTO> checkToVehicle(@RequestBody VehiclePkgTransferScanVO vehiclePkgTransferScanVO) {
        return R.ok(wmsVehiclePkgTransferService.checkToVehicle(vehiclePkgTransferScanVO));
    }

    @ApiOperation("载具pkg转移")
    @PostMapping("/transferPkg")
    public R<VehiclePkgTransferDTO> transferPkg(@RequestBody VehiclePkgTransferVO vehiclePkgTransferVO) {
        return R.ok(wmsVehiclePkgTransferService.transferPkg(vehiclePkgTransferVO));
    }

    @ApiOperation("物控限料")
    @PostMapping("/materialControlLimit")
    public R<Void> materialControlLimit(@RequestBody MaterialControlVO materialControlVO) {
        wmsMaterialControlService.materialControlLimit(materialControlVO);
        return R.ok();
    }

    @ApiOperation("前加工接收")
    @PostMapping("/bindPreWorkLocation")
    public R<Void> bindPreWorkLocation(@RequestBody VehicleLocationBindVO vehicleLocationBindVO) {
        wmsVehicleBindLocationService.bindPreWorkLocation(vehicleLocationBindVO);
        return R.ok();
    }

    @ApiOperation("作业区接收")
    @PostMapping("/bindOperationLocation")
    public R<Void> bindOperationLocation(@RequestBody VehicleLocationBindVO vehicleLocationBindVO) {
        wmsVehicleBindLocationService.bindOperationLocation(vehicleLocationBindVO);
        return R.ok();
    }

    @ApiOperation("查询组装捡料详情信息")
    @PostMapping("/assemblePickDetailList")
    public R<List<AssemblePickDetailDTO>> selectAssemblePickDetailInfo(@RequestBody AssemblePickDetailVO
                                                                               assemblePickDetailVO) {
        return R.ok(wmsPickingService.selectAssemblePickDetailInfo(assemblePickDetailVO));
    }

    @ApiOperation("查询组装捡料库存信息")
    @PostMapping("/assemblePickInventoryList")
    public R<List<AssemblePickInventoryDTO>> selectAssemblePickInventoryInfo(@RequestBody AssemblePickInventoryVO
                                                                                     assemblePickInventoryVO) {
        return R.ok(wmsPickingService.selectAssemblePickInventoryInfo(assemblePickInventoryVO));
    }

    @ApiOperation("组转捡料--提交捡料信息")
    @PostMapping("/submitAssemblePickInfo")
    public R<InStockPickDTO> submitAssemblePickInfo(@RequestBody AssemblePickSubmitVO assemblePickSubmitVO) {
        return wmsPickingService.submitAssemblePickInfo(assemblePickSubmitVO);
    }

    @ApiOperation("紧急叫料--提交")
    @PostMapping("/urgentPickSubmit")
    public R<UrgentPickSubmitDTO> urgentPickSubmit(@RequestBody UrgentPickSubmitVO urgentPickSubmitVO) {
        return lockService.urgentPickSubmit(urgentPickSubmitVO);
    }

    @ApiOperation("紧急叫料--详情")
    @PostMapping("/urgentPickTaskDetail")
    public R<UrgentPickTaskDetailDTO> selectPickTaskDetail(@RequestBody UrgentPickTaskDetailVO urgentPickTaskDetailVO) {
        return R.ok(wmsUrgentPickService.selectPickTaskDetail(urgentPickTaskDetailVO));
    }

    @ApiOperation("紧急叫料--跳过料号")
    @PostMapping("/completedUrgentPickTask")
    public R<Void> completedUrgentPickTask(@RequestBody UrgentPickSubmitVO urgentPickSubmitVO) {
        wmsUrgentPickService.completedUrgentPickTask(urgentPickSubmitVO);
        return R.ok();
    }

    @ApiOperation("紧急叫料--PN叫料提交")
    @PostMapping("/urgentPnPickSubmit")
    public R<Void> urgentPnPickSubmit(@RequestBody UrgentPickSubmitVO urgentPickSubmitVO) {
        wmsUrgentPickService.pnUrgentPickSubmit(urgentPickSubmitVO);
        return R.ok();
    }

    @ApiOperation("前加工任务--待分盘清单明细")
    @PostMapping("/unPartitionDetailList")
    public R<PageDataDTO<PreWorkTaskDetailDTO>> unPartitionDetailList(@RequestBody PreWorkTaskQueryVO
                                                                              preWorkTaskQueryVO) {
        preWorkTaskQueryVO.setTaskType(PickTaskTypeEnum.UN_DISTRIBUTE_PARTITION.getDictCode());
        return R.ok(wmsWorkOrderPickLogService.selectPreWorkTaskDetailPage(preWorkTaskQueryVO));
    }

    @ApiOperation("前加工任务--待烧录清单明细")
    @PostMapping("/unBurnDetailList")
    public R<PageDataDTO<PreWorkTaskDetailDTO>> unBurnDetailList(@RequestBody PreWorkTaskQueryVO
                                                                         preWorkTaskQueryVO) {
        preWorkTaskQueryVO.setTaskType(PickingTypeEnum.SMT_BURN.getDictCode());
        return R.ok(wmsWorkOrderPickLogService.selectPreWorkTaskDetailPage(preWorkTaskQueryVO));
    }

    @ApiOperation("前加工任务--待合盘清单明细")
    @PostMapping("/unMargeDetailList")
    public R<PageDataDTO<PreWorkTaskDetailDTO>> unMargeDetailList(@RequestBody PreWorkTaskQueryVO
                                                                          preWorkTaskQueryVO) {
        preWorkTaskQueryVO.setTaskType(PickingTypeEnum.SMT_MARGE.getDictCode());
        return R.ok(wmsWorkOrderPickLogService.selectPreWorkTaskDetailPage(preWorkTaskQueryVO));
    }

    @ApiOperation("前加工任务--待剪角清单明细")
    @PostMapping("/unCutDetailList")
    public R<PageDataDTO<PreWorkTaskDetailDTO>> unCutDetailList(@RequestBody PreWorkTaskQueryVO
                                                                        preWorkTaskQueryVO) {
        preWorkTaskQueryVO.setTaskType(PickingTypeEnum.SMT_CUT.getDictCode());
        return R.ok(wmsWorkOrderPickLogService.selectPreWorkTaskDetailPage(preWorkTaskQueryVO));
    }

    @ApiOperation("待烧录分盘明细")
    @PostMapping("/unBurnPartitionDetailList")
    public R<PageDataDTO<PreWorkTaskDetailDTO>> unBurnPartitionDetailList(@RequestBody PreWorkTaskQueryVO
                                                                                  preWorkTaskQueryVO) {
        preWorkTaskQueryVO.setTaskType(PickTaskTypeEnum.UN_BURN_PARTITION.getDictCode());
        return R.ok(wmsWorkOrderPickLogService.selectPreWorkTaskDetailPage(preWorkTaskQueryVO));
    }

    @ApiOperation("待回大仓明细")
    @PostMapping("/unReturnWhDetailList")
    public R<PageDataDTO<PreWorkTaskDetailDTO>> unReturnWhDetailList(@RequestBody PreWorkTaskQueryVO
                                                                             preWorkTaskQueryVO) {
        preWorkTaskQueryVO.setTaskType(PickTaskTypeEnum.UN_RETURN_TO_WH.getDictCode());
        return R.ok(wmsWorkOrderPickLogService.selectPreWorkTaskDetailPage(preWorkTaskQueryVO));
    }

    @ApiOperation("确认pkg是否要分料分盘")
    @PostMapping("/confirmDistributePartition")
    public R<Void> confirmDistributePartition(@RequestBody ConfirmPartitionVO confirmPartitionVO) {
        wmsMaterialDistributionService.confirmDistributePartition(confirmPartitionVO);
        return R.ok();
    }

    @ApiOperation("生产缺料明细")
    @PostMapping("/productShortageDetailList")
    public R<PageDataDTO<ProductShortageDetailDTO>> selectProductShortageDetailPage(
            @RequestBody ProductShortageDetailQueryVO queryVO) {
        return R.ok(wmsWorkOrderPickLogService.selectProductShortageDetailPage(queryVO));
    }

    @ApiOperation("缺料锁料-By工单")
    @PostMapping("/shortageLockMaterial")
    public R<Void> shortageLockMaterial(@RequestBody LockMaterialVO lockMaterialVO) {
        return wmsLockMaterialService.shortageMaterialLock(lockMaterialVO);
    }

    @ApiOperation("生产缺料明细导出")
    @PostMapping("/exportShortageDetail")
    public R<Void> exportShortageDetail(HttpServletResponse response,
                                        @RequestBody ProductShortageDetailQueryVO queryVO) {
        wmsWorkOrderPickLogService.exportProductShortageDetail(response, queryVO);
        return R.ok();
    }

    @ApiOperation("在库捡料-查询工单信息")
    @PostMapping("/pickWoHeaderInfo")
    public R<PickWoHeaderDTO> getPickWoHeaderInfo(@RequestBody PickWoHeaderCheckVO pickWoHeaderCheckVO) {
        return R.ok(wmsPickingService.getPickWoHeaderInfo(pickWoHeaderCheckVO));
    }

    @ApiOperation("在库捡料-查询工单制程类型")
    @PostMapping("/pickMaterialProductTypeList")
    public R<List<String>> getPickMaterialProductTypeList(@RequestBody PickWoHeaderCheckVO pickWoHeaderCheckVO) {
        return R.ok(wmsPickingService.getPickMaterialProductTypeList(pickWoHeaderCheckVO));
    }

    @ApiOperation("在库捡料-提交")
    @PostMapping("/inStockPick")
    public R<InStockPickDTO> inStockPick(@RequestBody InStockPickVO inStockPickVO) {
        return wmsPickingService.inStockPick(inStockPickVO);
    }

    @ApiOperation("合盘前加工")
    @PostMapping("/mergePreWork")
    public R<MergePreWorkDTO> mergePreWork(@RequestBody MergePreWorkVO mergePreWorkVO) {
        return R.ok(wmsWorkOrderPickLogService.mergePreWork(mergePreWorkVO));
    }

    @ApiOperation("待分料明细")
    @PostMapping("/unDistributeList")
    public R<PageDataDTO<PreWorkTaskDetailDTO>> unDistributeList(@RequestBody PreWorkTaskQueryVO
                                                                         preWorkTaskQueryVO) {
        preWorkTaskQueryVO.setTaskType(PickTaskTypeEnum.UN_DISTRIBUTE.getDictCode());
        return R.ok(wmsWorkOrderPickLogService.selectPreWorkTaskDetailPage(preWorkTaskQueryVO));
    }


    @ApiOperation("作业区物料清单")
    @PostMapping("/pickLogList")
    public R<PageDataDTO<WorkOrderPickLogDTO>> pickLogList(@RequestBody WorkOrderPickLogQueryVO
                                                                   queryVO) {
        return R.ok(wmsWorkOrderPickLogService.selectPickLogPage(queryVO));
    }

    @ApiOperation("作业区物料清单导出")
    @PostMapping("/exportPickLogList")
    public R<Void> exportPickLogList(HttpServletResponse response,
                                     @RequestBody WorkOrderPickLogQueryVO queryVO) {
        wmsWorkOrderPickLogService.exportPickLogList(response, queryVO);
        return R.ok();
    }

    @ApiOperation("剪脚前加工")
    @PostMapping("/cutOffPreWork")
    public R<CutOffPreWorkDTO> cutOffPreWork(@RequestBody CutOffPreWorkVO cutOffPreWorkVO) {
        return R.ok(wmsWorkOrderPickLogService.cutOffPreWork(cutOffPreWorkVO));
    }

    @ApiOperation("生产排配明细导出")
    @PostMapping("/exportProductSchedule")
    public R<Void> exportProductSchedule(HttpServletResponse response,
                                        @RequestBody ProductSchedulVO queryVO) {
        workOrderPrepareService.exportProductSchedule(response, queryVO);
        return R.ok();
    }
}
