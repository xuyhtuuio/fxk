package com.maxnerva.cloudmes.controller.basic;

import com.maxnerva.cloudmes.aspect.FactoryOperationLog;
import com.maxnerva.cloudmes.common.constant.OperationTypeConstant;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.basic.WmsSapWarehouseCodeDTO;
import com.maxnerva.cloudmes.models.vo.basic.SapWarehouseCodePageQueryVO;
import com.maxnerva.cloudmes.models.vo.basic.WmsSapWarehouseCodeVO;
import com.maxnerva.cloudmes.service.basic.IWmsSapWarehouseCodeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * @ClassName SapWareHouseCodeController
 * @Description SAP仓码(属性)管理
 * @Author caijun
 * @Date 2022/7/26
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "SAP仓码(属性)管理")
@Slf4j
@RestController
@RequestMapping("/sapWareHouseCode")
public class SapWarehouseCodeController {

    @Resource
    private IWmsSapWarehouseCodeService wmsSapWarehouseCodeService;

    @ApiOperation("新增SAP仓码")
    @PostMapping("/add")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "新增SAP仓码")
    public R<Void> saveWarehouseCode(@Valid @RequestBody WmsSapWarehouseCodeVO warehouseCodeVO) {
        wmsSapWarehouseCodeService.saveWarehouseCode(warehouseCodeVO);
        return R.ok();
    }

    @ApiOperation("修改SAP仓码")
    @PutMapping("/update")
    @FactoryOperationLog(operationType = OperationTypeConstant.MODIFY, description = "修改SAP仓码")
    public R<Void> updateWarehouseCode(@Valid @RequestBody WmsSapWarehouseCodeVO warehouseCodeVO) {
        wmsSapWarehouseCodeService.updateWarehouseCode(warehouseCodeVO);
        return R.ok();
    }

    @ApiOperation("删除SAP仓码")
    @DeleteMapping("/delete")
    @FactoryOperationLog(operationType = OperationTypeConstant.DELETE, description = "删除SAP仓码")
    public R<Void> deleteCode(@RequestBody List<Integer> idList) {
        wmsSapWarehouseCodeService.deleteCodeBatch(idList);
        return R.ok();
    }

    @ApiOperation("查询SAP仓码信息")
    @PostMapping("/list")
    public R<PageDataDTO<WmsSapWarehouseCodeDTO>> selectPage(@RequestBody SapWarehouseCodePageQueryVO queryVO) {
        return R.ok(wmsSapWarehouseCodeService.selectPage(queryVO));
    }

    @ApiOperation("查询SAP仓码信息")
    @PostMapping("/getWarehouseCodeListByCostType")
    public R<PageDataDTO<WmsSapWarehouseCodeDTO>> getWarehouseCodeListByCostType(@RequestBody SapWarehouseCodePageQueryVO queryVO) {
        return R.ok(wmsSapWarehouseCodeService.getWarehouseCodeListByCostType(queryVO));
    }

}
