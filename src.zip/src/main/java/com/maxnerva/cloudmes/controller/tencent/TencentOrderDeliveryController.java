package com.maxnerva.cloudmes.controller.tencent;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.vo.tencent.TencentOrderDeliverySyncVO;
import com.maxnerva.cloudmes.service.tencent.IWmsTencentOrderDeliveryService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName TecentOrderDeliveryController
 * @Description TODO
 * @Author Likun
 * @Date 2025/5/20
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "腾讯订单同步管理")
@Slf4j
@RestController
@RequestMapping("/tencentOrder")
public class TencentOrderDeliveryController {

    @Resource
    private IWmsTencentOrderDeliveryService wmsTencentOrderDeliveryService;

    @ApiOperation("同步腾讯订单配送信息")
    @PostMapping("/sync")
    public R<Void> syncTencentOrderDelivery(@RequestBody List<TencentOrderDeliverySyncVO> syncVOList) {
        wmsTencentOrderDeliveryService.syncTencentOrderDelivery(syncVOList);
        return R.ok();
    }
}
