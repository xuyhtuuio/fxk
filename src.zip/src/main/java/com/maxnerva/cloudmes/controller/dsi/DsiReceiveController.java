package com.maxnerva.cloudmes.controller.dsi;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.vo.dsi.DsiReceiveVO;
import com.maxnerva.cloudmes.service.dsi.IWmsDsiReceiveInfoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName DsiController
 * @Description TODO
 * @Author Likun
 * @Date 2025/6/27
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "DSI接收信息管理")
@Slf4j
@RestController
@RequestMapping("/dsiReceive")
public class DsiReceiveController {

    @Resource
    private IWmsDsiReceiveInfoService wmsDsiReceiveInfoService;

    @ApiOperation("接收DSI信息")
    @PostMapping("/save")
    public R<Void> saveDsiInfo(@RequestBody List<DsiReceiveVO> dsiReceiveVOList){
        wmsDsiReceiveInfoService.saveDsiInfo(dsiReceiveVOList);
        return R.ok();
    }
}
