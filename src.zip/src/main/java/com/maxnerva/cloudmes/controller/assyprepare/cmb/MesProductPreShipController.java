package com.maxnerva.cloudmes.controller.assyprepare.cmb;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.assyprepare.MesPreShipDnDTO;
import com.maxnerva.cloudmes.models.dto.assyprepare.StampBarcodeScanDTO;
import com.maxnerva.cloudmes.models.dto.assyprepare.StampBinScanDTO;
import com.maxnerva.cloudmes.models.vo.assyprepare.MesPreShipAgvBindPkgVO;
import com.maxnerva.cloudmes.models.vo.assyprepare.MesPreShipDnQueryVO;
import com.maxnerva.cloudmes.models.vo.assyprepare.StampBinScanVO;
import com.maxnerva.cloudmes.service.assyprepare.cmb.MesProductPreShipService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName MesProductPreShipController
 * @Description TODO
 * @Author Likun
 * @Date 2025/4/18
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "采集备货")
@Slf4j
@RestController
@RequestMapping("/mesProductPreShip")
public class MesProductPreShipController {

    @Resource
    private MesProductPreShipService mesProductPreShipService;

    @ApiOperation("扫描barCode")
    @GetMapping("/scanBarCode")
    public R<StampBarcodeScanDTO> scanBarCode(@ApiParam(value = "barCode", required = true)
                                               @RequestParam("barCode") String barCode,
                                              @ApiParam(value = "工厂组织", required = true)
                                               @RequestParam("orgCode") String orgCode){
        return R.ok(mesProductPreShipService.scanBarCode(barCode,orgCode));
    }


    @ApiOperation("提交")
    @PostMapping("/submit")
    public R<Void> submitPreShipInfo(@RequestBody MesPreShipAgvBindPkgVO preShipAgvBindPkgVO){
        preShipAgvBindPkgVO.setDataSource("MES");
        return mesProductPreShipService.submitPreShipInfo(preShipAgvBindPkgVO);
    }

    @ApiOperation("DN清单")
    @PostMapping("/dnInfoList")
    public R<List<MesPreShipDnDTO>> selectSfcPreShipDnInfo(@RequestBody MesPreShipDnQueryVO queryVO){
        return R.ok(mesProductPreShipService.selectPreShipDnInfo(queryVO));
    }

    @ApiOperation("扫描储位")
    @PostMapping("/scanBinCode")
    public R<StampBinScanDTO> scanBinCode(@RequestBody StampBinScanVO stampBinScanVO){
        return R.ok(mesProductPreShipService.scanBinCode(stampBinScanVO));
    }
}
