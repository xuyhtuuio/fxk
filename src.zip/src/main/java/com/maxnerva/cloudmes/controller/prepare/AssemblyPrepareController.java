package com.maxnerva.cloudmes.controller.prepare;

import cn.hutool.core.util.StrUtil;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.prepare.AssemblePrepareInventoryDTO;
import com.maxnerva.cloudmes.models.dto.prepare.JusdaReceiptPrepareDTO;
import com.maxnerva.cloudmes.models.dto.warehouse.PkgInventoryDTO;
import com.maxnerva.cloudmes.models.dto.warehouse.WarehouseCodeInventoryDTO;
import com.maxnerva.cloudmes.models.dto.wo.InStockDirectPrepareDTO;
import com.maxnerva.cloudmes.models.dto.wo.WmsWorkOrderFirstPrepareDTO;
import com.maxnerva.cloudmes.models.dto.wo.WoFirstPrepareDetailDTO;
import com.maxnerva.cloudmes.models.dto.wo.WorkDetailDTO;
import com.maxnerva.cloudmes.models.vo.prepare.AssembleJusdaPrepareVO;
import com.maxnerva.cloudmes.models.vo.prepare.AssemblePrepareInventoryVO;
import com.maxnerva.cloudmes.models.vo.prepare.JusdaReceiptPrepareQueryVO;
import com.maxnerva.cloudmes.models.vo.warehouse.PkgInventoryPageQueryVO;
import com.maxnerva.cloudmes.models.vo.wo.DetailShortagePageQueryVO;
import com.maxnerva.cloudmes.models.vo.wo.InStockDirectPrepareVO;
import com.maxnerva.cloudmes.models.vo.wo.WoFirstPreparePageQueryVO;
import com.maxnerva.cloudmes.models.vo.wo.WoFirstPrepareVO;
import com.maxnerva.cloudmes.service.prepare.IWmsAssemblyPrepareService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName AssemblyPrepareController
 * @Description 组装段备料管理
 * @Author Likun
 * @Date 2023/11/1
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "组装段备料管理")
@Slf4j
@RestController
@RequestMapping("/assemblyPrepare")
public class AssemblyPrepareController {

    @Resource
    private IWmsAssemblyPrepareService wmsAssemblyPrepareService;


    @ApiOperation("分页查询组装缺料备料工单明细信息")
    @PostMapping("/prepareDetailList")
    public R<PageDataDTO<WorkDetailDTO>> selectPrepareDetailPage(@RequestBody DetailShortagePageQueryVO pageQueryVO) {
        return R.ok(wmsAssemblyPrepareService.selectPrepareDetailPage(pageQueryVO));
    }

    @ApiOperation("分页查询工单料号版次对应的条码库存信息")
    @PostMapping("/pkgInventoryList")
    public R<PageDataDTO<PkgInventoryDTO>> selectInventoryPage(@RequestBody PkgInventoryPageQueryVO pageQueryVO) {
        return R.ok(wmsAssemblyPrepareService.selectInventoryPage(pageQueryVO));
    }

    @ApiOperation("查询对应的料号版次汇总的库存信息")
    @GetMapping("/materialInventoryList")
    public R<List<WarehouseCodeInventoryDTO>> selectMaterialInventoryList(@ApiParam(value = "料号", required = true)
                                                                          @RequestParam("partNo") String partNo,
                                                                          @ApiParam(value = "工厂组织", required = true)
                                                                          @RequestParam("orgCode") String orgCode,
                                                                          @ApiParam(value = "料号版次", required = true)
                                                                          @RequestParam("partVersion") String partVersion) {
        return R.ok(wmsAssemblyPrepareService.selectMaterialInventory(partNo, StrUtil.EMPTY, orgCode, partVersion));
    }

    @ApiOperation("组装在库直备")
    @PostMapping("/assemblyPrepareDirectInStock")
    public R<Void> prepareDirectInStock(@RequestBody InStockDirectPrepareVO stockDirectPrepareVO) {
        return wmsAssemblyPrepareService.assemblyPrepareDirectInStock(stockDirectPrepareVO);
    }

    @ApiOperation("查询分类信息")
    @GetMapping("/processTypeList")
    public R<List<String>> selectProcessTypeList(@RequestParam("orgCode") String orgCode,
                                                 @RequestParam("workOrderNo") String workOrderNo) {
        return R.ok(wmsAssemblyPrepareService.selectProcessTypeList(orgCode, workOrderNo));
    }

    @ApiOperation("首套料备料查询")
    @PostMapping("/firstPrepareList")
    public R<PageDataDTO<WmsWorkOrderFirstPrepareDTO>> selectFirstPrepareList(@RequestBody WoFirstPreparePageQueryVO pageQueryVO) {
        return R.ok(wmsAssemblyPrepareService.selectFirstPrepareList(pageQueryVO));
    }

    @ApiOperation("首套料备料明细查询")
    @PostMapping("/firstPrepareDetailList")
    public R<PageDataDTO<WoFirstPrepareDetailDTO>> firstPrepareDetailList(@RequestBody WoFirstPreparePageQueryVO pageQueryVO) {
        return R.ok(wmsAssemblyPrepareService.firstPrepareDetailList(pageQueryVO));
    }

    @ApiOperation("首套料备料")
    @PostMapping("/firstPrepare")
    public R<Void> firstPrepare(@RequestBody WoFirstPrepareVO woFirstPrepareVO) {
        return wmsAssemblyPrepareService.firstPrepare(woFirstPrepareVO.getPkgId(), woFirstPrepareVO.getWorkOrderDetailId(),
                woFirstPrepareVO.getOrgCode(), woFirstPrepareVO.getVehicleCode());
    }

    @ApiOperation("jusda收货备料")
    @PostMapping("/jusdaReceiptPrepare")
    public R<Void> jusdaReceiptPrepare(@RequestBody AssembleJusdaPrepareVO assembleJusdaPrepareVO) {
        return wmsAssemblyPrepareService.jusdaReceiptPrepare(assembleJusdaPrepareVO);
    }

    @ApiOperation("jusda收货待备工单清单")
    @PostMapping("/jusdaReceiptPrepareList")
    public R<PageDataDTO<JusdaReceiptPrepareDTO>> jusdaReceiptPrepareList(@RequestBody JusdaReceiptPrepareQueryVO
                                                                                      prepareQueryVO) {
        return R.ok(wmsAssemblyPrepareService.selectJusdaReceiptPreparePage(prepareQueryVO));
    }

    @ApiOperation("PDA组装备料查询推荐库存信息")
    @PostMapping("/assemblePrepareInventoryList")
    public R<List<AssemblePrepareInventoryDTO>> selectAssemblePrepareInventoryInfo(
            @RequestBody AssemblePrepareInventoryVO assemblePrepareInventoryVO){
        return R.ok(wmsAssemblyPrepareService.selectAssemblePrepareInventoryInfo(assemblePrepareInventoryVO));
    }
}
