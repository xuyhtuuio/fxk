package com.maxnerva.cloudmes.controller.doc;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.doc.WmsInvoiceNoFileDTO;
import com.maxnerva.cloudmes.models.dto.doc.WmsInvoiceNoListDTO;
import com.maxnerva.cloudmes.models.vo.doc.WmsInvoiceNoListDeleteFileVO;
import com.maxnerva.cloudmes.models.vo.doc.WmsInvoiceNoListQueryVO;
import com.maxnerva.cloudmes.models.vo.doc.WmsInvoiceNoListUploadFileVO;
import com.maxnerva.cloudmes.service.doc.IWmsInvoiceNoListService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * (WmsInvoiceNoList)表控制层
 *
 * @author hgx
 * @since 2024-02-26 17:03:58
 */
@Api(tags = "WmsInvoiceNoList管理")
@RestController
@RequestMapping("/InvoiceNo")
public class WmsInvoiceNoListController {
    /**
     * 服务对象
     */
    @Resource
    private IWmsInvoiceNoListService wmsInvoiceNoListService;

    @ApiOperation(value = "出货文件查询")
    @GetMapping("/list")
    public R<PageDataDTO<WmsInvoiceNoListDTO>> selectPage(WmsInvoiceNoListQueryVO pageQueryVO) {
        return R.ok(wmsInvoiceNoListService.selectPage(pageQueryVO));
    }

    @ApiOperation(value = "文件上传")
    @PostMapping("/uploadFile")
    public R<Void> uploadFile(WmsInvoiceNoListUploadFileVO uploadFileVO) {
        wmsInvoiceNoListService.uploadFile(uploadFileVO);
        return R.ok();
    }

    @ApiOperation(value = "文件删除")
    @PostMapping("/deleteFile")
    public R<Void> deleteFile(@RequestBody WmsInvoiceNoListDeleteFileVO deleteFileVO) {
        wmsInvoiceNoListService.deleteFile(deleteFileVO);
        return R.ok();
    }

    @ApiOperation(value = "文件列表")
    @GetMapping("/getFiles")
    public R<List<WmsInvoiceNoFileDTO>> getFiles(@RequestParam("id") Integer id) {
        return R.ok(wmsInvoiceNoListService.getFiles(id));
    }

    @ApiOperation("导出")
    @PostMapping("/export")
    public R<Void> export(HttpServletResponse response,
                          @RequestBody WmsInvoiceNoListQueryVO vo) {
        wmsInvoiceNoListService.export(response, vo);
        return R.ok();
    }
}