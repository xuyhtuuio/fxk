package com.maxnerva.cloudmes.controller.doc;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.doc.*;
import com.maxnerva.cloudmes.models.dto.warehouse.PkgPrintDTO;
import com.maxnerva.cloudmes.models.vo.doc.*;
import com.maxnerva.cloudmes.service.doc.IWmsDocSwrDetailService;
import com.maxnerva.cloudmes.service.doc.IWmsDocSwrHeaderService;
import com.maxnerva.cloudmes.service.doc.IWmsDocSwrService;
import com.maxnerva.cloudmes.service.lock.LockService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;

@Api(tags = "沾锡任务单管理")
@Slf4j
@RestController
@RequestMapping("/docSwr")
public class DocSwrController {

    @Autowired
    IWmsDocSwrHeaderService wmsDocSwrHeaderService;

    @Autowired
    IWmsDocSwrDetailService wmsDocSwrDetailService;

    @Autowired
    IWmsDocSwrService wmsDocSwrService;

    @Autowired
    LockService lockService;

    @ApiOperation("沾锡任务单查询")
    @GetMapping("/headerPageList")
    R<PageDataDTO<WmsDocSwrHeaderDTO>> docSwrHeaderPageList(WmsDocSwrHeaderQueryVO vo) {
        return R.ok(wmsDocSwrHeaderService.selectPageList(vo, Boolean.TRUE));
    }

    @ApiOperation("沾锡任务单导出")
    @GetMapping("/exportHeaderList")
    void exportHeaderList(WmsDocSwrHeaderQueryVO vo, HttpServletResponse response) {
        wmsDocSwrHeaderService.exportDetail(vo, response);
    }

    @ApiOperation("沾锡任务明细查询")
    @GetMapping("/detailPageList")
    R<PageDataDTO<WmsDocSwrDetailDTO>> docSwrDetailPageList(WmsDocSwrDetailQueryVO vo) {
        return R.ok(wmsDocSwrDetailService.selectPageList(vo, Boolean.TRUE));
    }

    @ApiOperation("沾锡任务明细导出")
    @GetMapping("/exportDetail")
    void exportDocSwrDetail(WmsDocSwrDetailQueryVO vo, HttpServletResponse response) {
        wmsDocSwrDetailService.exportDetail(vo, response);
    }

    @ApiOperation("待检料沾锡任务分页查询")
    @GetMapping("/pickPageList")
    R<PageDataDTO<WmsDocSwrHeaderDTO>> docSwrHeaderPickPageList(DocSwrHeaderPickQueryVO vo) {
        return R.ok(wmsDocSwrService.pickPageList(vo));
    }

    @ApiOperation("待取料明细")
    @GetMapping("/pickDetailList")
    R<PageDataDTO<DocSwrPickDetailDTO>> pickDetailList(DocSwrHeaderPickDetailQueryVO vo) {
        return R.ok(wmsDocSwrService.pickDetailList(vo));
    }

    @ApiOperation("取料提交")
    @PostMapping("/pickSubmit")
    R<DocSwrPickSubmitDTO> pickSubmit(@RequestBody DocSwrPickSubmitVO vo) {
        return R.ok(lockService.pickSwrSubmit(vo));
    }

    @ApiOperation("待分料明细")
    @GetMapping("/dividePageList")
    R<PageDataDTO<DocSwrDivideDTO>> dividePageList(DocSwrDivideQueryVO vo) {
        return R.ok(wmsDocSwrService.dividePageList(vo));
    }

    @ApiOperation("分料提交")
    @PostMapping("/divideSubmit")
    R<DocSwrDivideSubmitDTO> divideSubmit(@RequestBody DocSwrDivideSubmitVO vo) {
        return R.ok(wmsDocSwrService.divideSubmit(vo));
    }

    @ApiOperation("查询条码打印信息")
    @PostMapping("/printDividePkgInfo")
    public R<PkgPrintDTO> printDividePkgInfo(@RequestBody DocSwrPrintDividePkgInfoVO vo) {
        return R.ok(wmsDocSwrService.printDividePkgInfo(vo));
    }

    @ApiOperation("余料返仓")
    @PostMapping("/remainReturn")
    R<DocSwrRemainReturnDTO> remainReturnWarehouse(@RequestBody DocSwrRemainReturnVO vo) {
        return R.ok(wmsDocSwrService.remainReturnWarehouse(vo));
    }

    @ApiOperation("实验室接收提交")
    @PostMapping("/acceptSubmit")
    R acceptSubmit(@RequestBody DocSwrAcceptSubmitVO vo) {
        wmsDocSwrService.acceptSubmit(vo);
        return R.ok();
    }

    @ApiOperation("上传沾锡报告查询条码信息")
    @GetMapping("/checkReportPkgInfo")
    R<DocSwrCheckReportPkgInfoDTO> checkReportPkgInfo(DocSwrCheckReportPkgInfoVO vo) {
        return R.ok(wmsDocSwrService.checkReportPkgInfo(vo));
    }

    @ApiOperation("沾锡报告上传")
    @PostMapping("/checkReportSubmit")
    R checkReportSubmit(DocSwrCheckReportSubmitVO vo) {
        wmsDocSwrService.checkReportSubmit(vo);
        return R.ok();
    }

    @ApiOperation("客户确认查询条码信息")
    @GetMapping("/customerPkgInfo")
    R<DocSwrCustomerPkgInfoDTO> customerPkgInfo(DocSwrCustomerPkgInfoVO vo) {
        return R.ok(wmsDocSwrService.customerPkgInfo(vo));
    }

    @ApiOperation("客户确认")
    @PostMapping("/customerConfirmSubmit")
    R customerConfirmSubmit(DocSwrCustomerConfirmSubmitVO vo) {
        wmsDocSwrService.customerConfirmSubmit(vo);
        return R.ok();
    }

    @ApiOperation("自动抛转SWR单到Agile")
    @PostMapping("/postSwrDocToAgile")
    R postSwrDocToAgile(@RequestBody PostSwrDocToAgileVO vo) {
        wmsDocSwrService.postSwrDocToAgile(vo);
        return R.ok();
    }

    @ApiOperation("工单down详情后自动生成沾锡任务")
    @PostMapping("/calcWoLackGenerateSwrTask")
    R calcWoLackGenerateSwrTask(@RequestBody CalcWoLackGenerateSwrTaskVO vo) {
        wmsDocSwrService.calcWoLackGenerateSwrTask(vo);
        return R.ok();
    }


}
