package com.maxnerva.cloudmes.controller.warehouse;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.mes.ProductSnDTO;
import com.maxnerva.cloudmes.models.dto.warehouse.RequisitionNumberScanDTO;
import com.maxnerva.cloudmes.models.vo.instorage.DeliverySnInStoreVO;
import com.maxnerva.cloudmes.models.vo.mes.ProductSnVO;
import com.maxnerva.cloudmes.models.vo.warehouse.RequisitionNumberScanVO;
import com.maxnerva.cloudmes.service.warehouse.DeliverySnInStoreService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName DeliverySnInStoreController
 * @Description TODO
 * @Author Likun
 * @Date 2024/10/9
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "领用治具板入库")
@Slf4j
@RestController
@RequestMapping("/deliverySnInStore")
public class DeliverySnInStoreController {

    @Resource
    private DeliverySnInStoreService deliverySnInStoreService;

    @ApiOperation("扫描单据号")
    @PostMapping("/scanRequisitionNumber")
    public R<List<RequisitionNumberScanDTO>> scanRequisitionNumber(@RequestBody RequisitionNumberScanVO scanVO) {
        return R.ok(deliverySnInStoreService.scanRequisitionNumber(scanVO));
    }

    @ApiOperation("扫描sn")
    @PostMapping("/scanProductInfo")
    public R<ProductSnDTO> getProductSnInfo(@RequestBody ProductSnVO productSnVO) {
        return R.ok(deliverySnInStoreService.getProductSnInfo(productSnVO));
    }

    @ApiOperation("提交")
    @PostMapping("/submit")
    public R<Void> submit(@RequestBody DeliverySnInStoreVO deliverySnInStoreVO) {
        deliverySnInStoreService.deliverySnInStoreSubmit(deliverySnInStoreVO);
        return R.ok();
    }
}
