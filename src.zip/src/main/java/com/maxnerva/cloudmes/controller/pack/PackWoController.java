package com.maxnerva.cloudmes.controller.pack;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.pack.PackShortageDetailDTO;
import com.maxnerva.cloudmes.models.dto.pack.WmsPackWoHeaderDTO;
import com.maxnerva.cloudmes.models.dto.pack.WmsPackWorkBomDTO;
import com.maxnerva.cloudmes.models.vo.pack.*;
import com.maxnerva.cloudmes.service.pack.IWmsPackStockDetailService;
import com.maxnerva.cloudmes.service.pack.IWmsPackWorkBomService;
import com.maxnerva.cloudmes.service.pack.IWmsPackWorkOrderHeaderService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @ClassName PackWoController
 * @Description TODO
 * @Author Likun
 * @Date 2024/12/6
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "包材工单管理")
@Slf4j
@RestController
@RequestMapping("/packWo")
public class PackWoController {

    @Resource
    private IWmsPackWorkOrderHeaderService wmsPackWorkOrderHeaderService;

    @Resource
    private IWmsPackWorkBomService wmsPackWorkBomService;

    @Resource
    private IWmsPackStockDetailService wmsPackStockDetailService;

    @ApiOperation("同步工单")
    @PostMapping("/syncPackWoInfo")
    public R<Void> syncPackWoInfo(@RequestBody SyncPackWoHeaderVO syncPackWoHeaderVO) {
        wmsPackWorkOrderHeaderService.syncPackWoInfo(syncPackWoHeaderVO);
        return R.ok();
    }

    @ApiOperation("查询工单单头信息")
    @PostMapping("/headerList")
    private R<PageDataDTO<WmsPackWoHeaderDTO>> selectWoHeaderPage(@RequestBody PackWoHeaderQueryVO queryVO) {
        return R.ok(wmsPackWorkOrderHeaderService.selectWoHeaderPage(queryVO));
    }

    @ApiOperation("查询工单明细信息")
    @PostMapping("/detailList")
    private R<List<WmsPackWorkBomDTO>> selectWoBomPage(@RequestBody PackWoBomQueryVO queryVO) {
        return R.ok(wmsPackWorkBomService.selectBomList(queryVO));
    }

    @ApiOperation("送签")
    @PostMapping("/sendToSign")
    public R<Void> sendToSign(@RequestBody SendToSignVO sendToSignVO) {
        wmsPackStockDetailService.sendToSign(sendToSignVO);
        return R.ok();
    }

    @ApiOperation("查询包材缺料明细")
    @PostMapping("/shortageDetailList")
    public R<PageDataDTO<PackShortageDetailDTO>> selectShortageDetailPage(
            @RequestBody PackShortageQueryVO queryVO) {
        return R.ok(wmsPackWorkBomService.selectShortageDetail(queryVO));
    }

    @ApiOperation("包材缺料明细excel导出")
    @PostMapping("/exportShortageDetail")
    public void exportShortageDetail(HttpServletResponse response,
                                     @RequestBody PackShortageQueryVO queryVO) {
        wmsPackWorkBomService.exportShortageDetail(response, queryVO);
    }
}
