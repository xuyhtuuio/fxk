package com.maxnerva.cloudmes.controller.doc;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.doc.*;
import com.maxnerva.cloudmes.models.vo.doc.*;
import com.maxnerva.cloudmes.service.doc.IWmsScrapHandleDetailService;
import com.maxnerva.cloudmes.service.doc.IWmsScrapHandleDetailSnService;
import com.maxnerva.cloudmes.service.doc.IWmsScrapHandleHeaderService;
import com.maxnerva.cloudmes.service.doc.IWmsScrapHandleTaxService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Api(tags = "报废处理单管理")
@Slf4j
@RestController
@RequestMapping("/scrapHandle")
public class ScrapHandleController {

    @Autowired
    IWmsScrapHandleHeaderService wmsScrapHandleHeaderService;

    @Autowired
    IWmsScrapHandleDetailService wmsScrapHandleDetailService;

    @Autowired
    IWmsScrapHandleDetailSnService wmsScrapHandleDetailSnService;

    @Autowired
    IWmsScrapHandleTaxService wmsScrapHandleTaxService;

    @ApiOperation("Header分页查询")
    @GetMapping("/headerPageList")
    R<PageDataDTO<WmsScrapHandleHeaderDTO>> scrapHandleHeaderPageList(ScrapHandleHeaderPageVO vo){
        return R.ok(wmsScrapHandleHeaderService.selectPageList(vo));
    }

    @ApiOperation("新增Header")
    @PostMapping("/createHeader")
    R createScrapHandleHeader(@RequestBody CreateScrapHandleVO vo){
        wmsScrapHandleHeaderService.create(vo);
        return R.ok();
    }

    @ApiOperation("提交Header")
    @PostMapping("/submitHeader")
    R submitScrapHandleHeader(@RequestBody UpdateScrapHandleIdentifyVO vo){
        wmsScrapHandleHeaderService.submit(vo);
        return R.ok();
    }

    @ApiOperation("关务确认Header")
    @PostMapping("/confirmHeader")
    R confirmScrapHandleHeader(@RequestBody UpdateScrapHandleIdentifyVO vo){
        wmsScrapHandleHeaderService.customConfirm(vo);
        return R.ok();
    }

    @ApiOperation("导入明细")
    @PostMapping("/importDetailList")
    R importScrapHandleDetailList(ScrapHandleDetailImportListVO vo){
        wmsScrapHandleDetailService.importDetail(vo);
        return R.ok();
    }

    @ApiOperation("导出明细")
    @GetMapping("/exportDetail")
    void exportScrapHandleDetailList(Integer headerId, HttpServletResponse response){
        wmsScrapHandleDetailService.export(headerId, response);
    }

    @ApiOperation("生成PDF明细")
    @GetMapping("/printDetailPdf")
    // docNo，orgCode必传
    R<ScrapHandleDetailPrintDTO> printScrapHandleDetailPdf(ScrapHandleDetailPageVO vo){
        return R.ok(wmsScrapHandleDetailService.printToPDF(vo));
    }

    @ApiOperation("生成SN-PDF明细")
    @GetMapping("/printDetailSnPdf")
    R<ScrapHandleDetailSnPrintDTO> printScrapHandleDetailSnPdf(Integer headerId){
        return R.ok(wmsScrapHandleDetailSnService.printToPDF(headerId));
    }

    @ApiOperation("Detail分页查询")
    @GetMapping("/detailPageList")
    R<PageDataDTO<WmsScrapHandleDetailDTO>> scrapHandleDetailPageList(ScrapHandleDetailPageVO vo){
        return R.ok(wmsScrapHandleDetailService.selectPageList(vo, Boolean.TRUE));
    }

    @ApiOperation("打印PackingList")
    @PostMapping("/printDetailPackingList")
    R<ScrapHandlePackingListPrintDTO> printScrapHandleDetailPackingList(@RequestBody ScrapHandleDetailPackingListVO vo){
        if (vo.getPalletNoList().size() == 1){
            return R.ok(wmsScrapHandleDetailService.printPackingListSingle(vo));
        } else {
            return R.ok(wmsScrapHandleDetailService.printPackingList(vo));
        }

    }

    @ApiOperation("Detail-SN分页查询")
    @GetMapping("/detailSnPageList")
    R<PageDataDTO<WmsScrapHandleDetailSnDTO>> scrapHandleDetailSnPageList(ScrapHandleDetailSnPageVO vo){
        return R.ok(wmsScrapHandleDetailSnService.selectPageList(vo, Boolean.TRUE));
    }

    @ApiOperation("导出Detail-SN")
    @GetMapping("/exportDetailSn")
    void exportScrapHandleDetailSn(ScrapHandleDetailSnPageVO vo, HttpServletResponse response){
        wmsScrapHandleDetailSnService.export(vo, response);
    }

    @ApiOperation("已扫描明细")
    @GetMapping("/detailScanList")
    R<List<ScrapHandleScanDTO>> scrapHandleDetailScanList(ScrapHandleScanVO vo){
        return R.ok(wmsScrapHandleDetailService.selectScanList(vo));
    }

    @ApiOperation("扫描明细提交")
    @PostMapping("/scanDetailSubmit")
    R scanScrapHandleDetailSubmit(@RequestBody ScrapHandleScanSubmitVO vo){
        wmsScrapHandleDetailService.scanSubmit(vo);
        return R.ok();
    }

    @ApiOperation("查询单号(仅限PDA查询，限制只能查物料类)")
    @GetMapping("/docNoList")
    R<List<String>> scrapHandleDocNoList(ScrapHandleHeaderDocNoVO vo){
        return R.ok(wmsScrapHandleHeaderService.selectDocNoList(vo));
    }

    @ApiOperation("出货提交")
    @PostMapping("/shipSubmit")
    R scrapHandleShipSubmit(@RequestBody ScrapHandleShipSubmitVO vo){
        wmsScrapHandleDetailService.shipSubmit(vo);
        return R.ok();
    }

    @ApiOperation("Header上传图片")
    @PostMapping("/uploadHeaderImage")
    R scrapHandleHeaderUploadImage(UploadScrapHandleHeaderImageVO vo){
        wmsScrapHandleHeaderService.uploadImage(vo);
        return R.ok();
    }

    @ApiOperation("PKG信息")
    @GetMapping("/pkgInfo")
    R<ScrapHandlePkgInfoDTO> scrapHandlePkgInfo(String orgCode, String pkgId){
        return R.ok(wmsScrapHandleDetailService.scrapHandlePkgInfo(orgCode, pkgId));
    }

    @ApiOperation("扫描绑定SN")
    @PostMapping("/bindDetailSn")
    R<ScrapHandleDetailBindSnDTO> bindScrapHandleDetailSn(ScrapHandleBindSnVO vo){
        return R.ok(wmsScrapHandleDetailSnService.bind(vo));
    }

    @ApiOperation("上传报废文件")
    @PostMapping("/uploadScrapFile")
    R uploadScrapFile(UploadScrapFileVO vo){
        wmsScrapHandleHeaderService.uploadScrapFile(vo);
        return R.ok();
    }

    @ApiOperation("PKG拆栈板")
    @PostMapping("/unBindDetail")
    R unBindDetail(@RequestBody ScrapHandleUnBindDetailVO vo) {
        wmsScrapHandleDetailService.unBindDetail(vo);
        return R.ok();
    }

    @ApiOperation("称重提交")
    @PostMapping("/weighSubmit")
    R weighSubmit(@RequestBody ScrapHandleWeighSubmitVO vo){
        wmsScrapHandleDetailService.weighSubmit(vo);
        return R.ok();
    }

    @ApiOperation("打印联络单")
    @PostMapping("/printScrapContactPdf")
    R<PrintScrapContactDTO> printScrapContactPdf(@RequestBody PrintScrapContactVO vo){
        return R.ok(wmsScrapHandleHeaderService.printScrapContactPdf(vo));
    }

    @ApiOperation("删除报废文件")
    @PostMapping("/deleteScrapFile")
    R<List<ScrapFileDTO>> deleteScrapFile(@RequestBody DeleteScrapFileVO vo){
        return R.ok(wmsScrapHandleHeaderService.deleteScrapFile(vo));
    }

    @ApiOperation("导出栈板信息")
    @GetMapping("/exportDetailByPallet")
    void exportDetailByPallet(ScrapHandleDetailPageVO vo, HttpServletResponse response){
        wmsScrapHandleDetailService.exportDetailByPallet(vo, response);
    }

    @ApiOperation("打印栈板LABEL")
    @PostMapping("/closePallet")
    R<PrintCloseScrapPalletDTO> closePallet(@RequestBody CloseScrapPalletVO vo){
        return R.ok(wmsScrapHandleDetailService.closePallet(vo));
    }

    @ApiOperation("报废品类型提交")
    @PostMapping("/scrapSubmit")
    R scrapSubmit(@RequestBody ScrapHandleSubmitVO vo){
        wmsScrapHandleDetailService.scrapSubmit(vo);
        return R.ok();
    }

    @ApiOperation("查询税务信息")
    @GetMapping("/selectTaxByDocNo")
    @Deprecated
    R<ScrapHandleTaxSaveDetailVO> selectTaxByDocNo(String orgCode, String docNo){
        return R.ok(wmsScrapHandleTaxService.selectTaxByDocNo(orgCode, docNo));
    }

    @ApiOperation("保存税务信息")
    @PostMapping("/saveTaxDetail")
    @Deprecated
    R saveTaxDetail(@RequestBody ScrapHandleTaxSaveVO vo){
        wmsScrapHandleTaxService.saveDetail(vo);
        return R.ok();
    }

    @ApiOperation("报废处理栈板抛转SDS")
    @PostMapping("/postPalletToSds")
    R postPalletToSds(@RequestBody PostPalletToSdsVO vo) {
        wmsScrapHandleDetailService.postPalletToSds(vo);
        return R.ok();
    }
}
