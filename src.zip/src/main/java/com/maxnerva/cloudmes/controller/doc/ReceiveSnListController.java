package com.maxnerva.cloudmes.controller.doc;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.doc.ReceiveSnListDTO;
import com.maxnerva.cloudmes.models.vo.doc.ReceiveSnListQueryVO;
import com.maxnerva.cloudmes.service.doc.IWmsReceiveSnListService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

/**
 * @ClassName ReceiveSnListController
 * @Description TODO
 * @Author Likun
 * @Date 2024/9/3
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "收货sn清单管理")
@Slf4j
@RestController
@RequestMapping("/receiveSn")
public class ReceiveSnListController {

    @Resource
    private IWmsReceiveSnListService wmsReceiveSnListService;

    @ApiOperation("物料SN清单分页查询")
    @PostMapping("/list")
    public R<PageDataDTO<ReceiveSnListDTO>> selectReceiveSnList(@RequestBody ReceiveSnListQueryVO queryVO) {
        return R.ok(wmsReceiveSnListService.selectReceiveSnPage(queryVO));
    }

    @ApiOperation("物料SN清单导出")
    @PostMapping("/exportReceiveSnInfo")
    public void exportReceiveSnInfo(HttpServletResponse response,
                                    @RequestBody ReceiveSnListQueryVO queryVO) {
        wmsReceiveSnListService.exportReceiveSnInfo(response, queryVO);
    }
}
