package com.maxnerva.cloudmes.controller.warehouse;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.warehouse.GetPkgInfoLogDTO;
import com.maxnerva.cloudmes.models.dto.warehouse.WmsPkgInfoLogDTO;
import com.maxnerva.cloudmes.models.vo.warehouse.GetPkgInfoLogVO;
import com.maxnerva.cloudmes.models.vo.warehouse.PkgInfoLogPageQueryVO;
import com.maxnerva.cloudmes.models.vo.warehouse.WmsPkgInfoLogVO;
import com.maxnerva.cloudmes.service.warehouse.IWmsPkgInfoLogService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.List;

/**
 * @ClassName PkgInfoLogController
 * @Description 条码履历
 * @Author caijun
 * @Date 2022/09/02
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "条码履历")
@Slf4j
@RestController
@RequestMapping("/pkgInfoLog")
public class PkgInfoLogController {

    @Resource
    private IWmsPkgInfoLogService wmsPkgInfoLogService;

    @ApiOperation("新增履历信息")
    @PostMapping("/add")
    public R<Void> savePkgInfoLog(@Valid @RequestBody WmsPkgInfoLogVO pkgInfoLogVO) {
        wmsPkgInfoLogService.savePkgInfoLog(pkgInfoLogVO);
        return R.ok();
    }

    @ApiOperation("修改履历信息")
    @PutMapping("/update")
    public R<Void> updatePkgInfoLog(@Valid @RequestBody WmsPkgInfoLogVO pkgInfoLogVO) {
        wmsPkgInfoLogService.updatePkgInfoLog(pkgInfoLogVO);
        return R.ok();
    }

    @ApiOperation("删除履历信息")
    @DeleteMapping("/delete")
    public R<Void> deletePkgInfoLog(@RequestBody List<Integer> idList) {
        wmsPkgInfoLogService.deletePkgInfoLogBatch(idList);
        return R.ok();
    }

    @ApiOperation("查询履历信息")
    @PostMapping("/list")
    public R<PageDataDTO<GetPkgInfoLogDTO>> selectPage(@RequestBody GetPkgInfoLogVO pkgInfoLogPageQueryVO) {
        return R.ok(wmsPkgInfoLogService.selectPage(pkgInfoLogPageQueryVO));
    }

    @ApiOperation("查询履历信息导出")
    @PostMapping("/export")
    public void selectPage(@RequestBody GetPkgInfoLogVO pkgInfoLogPageQueryVO, HttpServletResponse response) {
        wmsPkgInfoLogService.export(pkgInfoLogPageQueryVO, response);
    }
}
