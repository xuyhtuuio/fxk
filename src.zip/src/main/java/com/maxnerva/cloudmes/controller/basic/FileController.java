package com.maxnerva.cloudmes.controller.basic;

import com.maxnerva.cloudmes.excel.util.DataSourceUtil;
import com.maxnerva.cloudmes.service.basic.IWmsFileDownloadLogService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;

@Slf4j
@RestController
@RequestMapping("/file")
public class FileController {
    @Autowired
    IWmsFileDownloadLogService wmsFileDownloadLogService;

    @GetMapping("/download")
    void test(Integer id, HttpServletResponse response){
        DataSourceUtil.setWmsDataSource();
        wmsFileDownloadLogService.downLoadFile(id, response);
    }
}
