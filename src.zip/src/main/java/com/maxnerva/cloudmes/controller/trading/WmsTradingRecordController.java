package com.maxnerva.cloudmes.controller.trading;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.entity.trading.WmsTradingRecord;
import com.maxnerva.cloudmes.models.dto.basic.WmsSapWarehouseCodeDTO;
import com.maxnerva.cloudmes.models.dto.trading.*;
import com.maxnerva.cloudmes.models.vo.trading.*;
import com.maxnerva.cloudmes.service.trading.IWmsTradingRecordService;
import com.sap.conn.jco.JCoException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.util.List;

/**
 * @author sclq
 * @date 2022/9/23 17:56
 */
@Api(tags = "内交单据")
@Slf4j
@RestController
@RequestMapping("/tradingRecord")
public class WmsTradingRecordController {

    @Resource
    private IWmsTradingRecordService wmsTradingRecordService;

    @ApiOperation("条件查询")
    @GetMapping("/deliveryList")
    public R<PageDataDTO<WmsTradingRecordDTO>> pageList(TradingRecordPageQueryVo queryVo) {
        Page page = PageHelper.startPage(queryVo.getPageIndex(), queryVo.getPageSize());
        List<WmsTradingRecordDTO> recordDTOList = wmsTradingRecordService.selectPageList(queryVo);
        PageDataDTO<WmsTradingRecordDTO> partRelationDTOPageDataDTO = new PageDataDTO<>(page.getTotal(), recordDTOList);
        return R.ok(partRelationDTOPageDataDTO);
    }

    @ApiOperation("内交出库新增")
    @PostMapping("/saveDelivery")
    public R<Void> save(@RequestBody TradingRecordDeliverySaveVO tradingRecordSaveVO) {
        wmsTradingRecordService.saveDelivery(tradingRecordSaveVO);
        return R.ok();
    }

    @ApiOperation("内交出库单信息")
    @GetMapping("/editInfo")
    public R<WmsTradingRecord> editInfo(Integer id) {
        return R.ok(wmsTradingRecordService.editInfo(id));
    }

    @ApiOperation("修改内交单信息")
    @PostMapping("/updateDelivery")
    public R<Void> updateDelivery(@RequestBody TradingRecordModifyVO tradingRecordModifyVO) {
        wmsTradingRecordService.updateDelivery(tradingRecordModifyVO);
        return R.ok();
    }

    @ApiOperation("复制内交单")
    @GetMapping("/copy")
    public R<Void> save(@RequestParam(value = "id", required = true) Integer id,
                        @RequestParam(value = "tradingQty", required = true) BigDecimal qty) {
        wmsTradingRecordService.copy(id, qty);
        return R.ok();
    }

    @ApiOperation("内交出")
    @GetMapping("/tradingOut")
    public R<Void> tradingOut(@RequestParam(value = "id") Integer id) throws JCoException {
        wmsTradingRecordService.tradingOut(id);
        return R.ok();
    }

    @ApiOperation("PGI")
    @GetMapping("/doPgi")
    public R<Void> doPgi(@RequestParam(value = "id", required = true) Integer id) {
        wmsTradingRecordService.doPgi(id);
        return R.ok();
    }

    @ApiOperation("出货推荐储位")
    @GetMapping("/recommendBin")
    public R<PageDataDTO<WmsTradingRecommendBinDTO>> recommendBin(TradingRecommendBinVO recommendBinVO) {
        Page page = PageHelper.startPage(recommendBinVO.getPageIndex(), recommendBinVO.getPageSize());
        List<WmsTradingRecommendBinDTO> recordDTOList = wmsTradingRecordService.recommendBin(recommendBinVO);
        PageDataDTO<WmsTradingRecommendBinDTO> partRelationDTOPageDataDTO = new PageDataDTO<>(page.getTotal(), recordDTOList);
        return R.ok(partRelationDTOPageDataDTO);
    }

    @ApiOperation("删除内交单信息")
    @PostMapping("/deleteByIds")
    public R<Void> deleteByIds(@RequestBody List<Integer> ids) {
        wmsTradingRecordService.deleteByIds(ids);
        return R.ok();
    }

    @ApiOperation("内交入库新增")
    @PostMapping("/saveEntry")
    public R<Void> saveEntry(@RequestBody TradingRecordEntrySaveVO entrySaveVO) {
        wmsTradingRecordService.saveEntry(entrySaveVO);
        return R.ok();
    }

    @ApiOperation("查询内交入信息")
    @GetMapping("/getTradingInInfo")
    public R<WmsTradingRecordDTO> getTradingInInfo(@RequestParam("id") Integer id,
                                                   @RequestParam("toPlantCode") String toPlantCode,
                                                   @RequestParam("toPartNo") String toPartNo) throws JCoException {
        return R.ok(wmsTradingRecordService.getTradingInInfo(id, toPlantCode, toPartNo));
    }

    @ApiOperation("查询内交入料号")
    @GetMapping("/getToPartNo")
    public R<WmsTradingRecordDTO> getToPartNo(@RequestParam("id") Integer id,
                                              @RequestParam("toPlantCode") String toPlantCode) {
        return R.ok(wmsTradingRecordService.getToPartNo(id, toPlantCode));
    }

    @ApiOperation("内交确认")
    @GetMapping("/tradingIn")
    public R<Void> tradingIn(TradingRecordEntryVO tradingRecordEntryVO) {
        wmsTradingRecordService.tradingIn(tradingRecordEntryVO);
        return R.ok();
    }

    @ApiOperation("出库")
    @PostMapping("/delivery")
    public R<Void> delivery(@RequestBody TradingRecordDeliveryVO deliveryVO) {
        wmsTradingRecordService.delivery(deliveryVO);
        return R.ok();
    }

    @ApiOperation("查询已出库数据")
    @GetMapping("/tradingDeliveryLogList")
    public R<PageDataDTO<WmsTradingDeliveryDTO>> recommendBin(@RequestParam("recordId") Integer recordId,
                                                              @RequestParam("orgCode") String orgCode,
                                                              @RequestParam("pageIndex") Integer pageIndex,
                                                              @RequestParam("pageSize") Integer pageSize) {
        WmsTradingDeliveryDTO dto = wmsTradingRecordService.tradingDeliveryLogList(recordId, orgCode, pageIndex, pageSize);
        return R.ok(dto);
    }

    @ApiOperation("入库")
    @PostMapping("/tradingShelf")
    public R<Void> tradingShelf(@RequestBody TradingRecordShelfVO recordShelfVO) {
        wmsTradingRecordService.tradingShelf(recordShelfVO);
        return R.ok();
    }

    @ApiOperation("查询条码打印信息")
    @PostMapping("/printTradingVehicle")
    public R<PrintVehicleDTO> printTradingVehicle(@RequestBody TradingPrintVehicleVO printVehicleVO) {
        return R.ok(wmsTradingRecordService.printTradingVehicle(printVehicleVO));
    }

    @ApiOperation("查询仓码保税性质")
    @GetMapping("/getWhCode")
    public R<WmsSapWarehouseCodeDTO> getWhCode(@RequestParam("fromOrgCode") String fromOrgCode,
                                               @RequestParam("fromPlantCode") String fromPlantCode,
                                               @RequestParam("fromWarehouseCode") String fromWarehouseCode) {
        return R.ok(wmsTradingRecordService.getWhCode(fromOrgCode, fromPlantCode, fromWarehouseCode));
    }

    @ApiOperation("打印内交单")
    @PostMapping("/printTradingInfo")
    public R<PrintTradingInfoDTO> printTradingInfo(@RequestBody List<Integer> idList) {
        return R.ok(wmsTradingRecordService.printTradingInfo(idList));
    }

    @ApiOperation("内交出导出")
    @PostMapping("/outExport")
    public R<Void> outExport(HttpServletResponse response,
                             @RequestBody TradingRecordPageQueryVo vo) {
        wmsTradingRecordService.outExport(response, vo);
        return R.ok();
    }
}
