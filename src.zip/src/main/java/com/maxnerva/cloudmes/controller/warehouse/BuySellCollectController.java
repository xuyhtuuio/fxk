package com.maxnerva.cloudmes.controller.warehouse;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.warehouse.BuySellCollectDTO;
import com.maxnerva.cloudmes.models.dto.warehouse.BuySellMaterialCollectRecordDTO;
import com.maxnerva.cloudmes.models.dto.warehouse.BuySellMaterialReportDTO;
import com.maxnerva.cloudmes.models.vo.warehouse.BuySellCollectQueryVO;
import com.maxnerva.cloudmes.models.vo.warehouse.BuySellCollectReportQueryVO;
import com.maxnerva.cloudmes.models.vo.warehouse.BuySellCollectVO;
import com.maxnerva.cloudmes.models.vo.warehouse.BuySellExcelImportVO;
import com.maxnerva.cloudmes.service.warehouse.IWmsBuySellMaterialCollectRecordService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

/**
 * @ClassName BuySellCollectController
 * @Description buySell物料采集管理
 * @Author Likun
 * @Date 2023/9/6
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "buySell物料采集管理")
@Slf4j
@RestController
@RequestMapping("/buySellCollect")
public class BuySellCollectController {

    @Resource
    private IWmsBuySellMaterialCollectRecordService wmsBuySellMaterialCollectRecordService;

    @ApiOperation("确认")
    @PostMapping("/confirm")
    public R<BuySellCollectDTO> buySellCollect(@RequestBody BuySellCollectVO buySellCollectVO) {
        return R.ok(wmsBuySellMaterialCollectRecordService.buySellCollect(buySellCollectVO));
    }

    @ApiOperation("pkg采集记录查询")
    @PostMapping("/pkgList")
    public R<PageDataDTO<BuySellMaterialCollectRecordDTO>> selectPkgCollectRecordPage(@RequestBody BuySellCollectQueryVO
                                                                                              queryVO) {
        return R.ok(wmsBuySellMaterialCollectRecordService.selectPkgCollectRecordPage(queryVO));
    }

    @ApiOperation("buySell报表查询")
    @PostMapping("/buySellReportList")
    public R<PageDataDTO<BuySellMaterialReportDTO>> selectBuySellReportPage(
            @RequestBody BuySellCollectReportQueryVO queryVO) {
        return R.ok(wmsBuySellMaterialCollectRecordService.selectBuySellReportPage(queryVO));
    }

    @ApiOperation("buySell报表excel导出")
    @PostMapping("/exportBuySellReport")
    public void exportBuySellReport(HttpServletResponse response,
                                    @RequestBody BuySellCollectReportQueryVO pageQueryVO) {
        wmsBuySellMaterialCollectRecordService.exportBuySellReport(response, pageQueryVO);
    }

    @ApiOperation("buySell采集信息导入")
    @PostMapping("/importBuySellRecord")
    public R<Void> importBuySellRecord(BuySellExcelImportVO buySellExcelImportVO) {
        wmsBuySellMaterialCollectRecordService.importBuySellRecord(buySellExcelImportVO);
        return R.ok();
    }
}
