package com.maxnerva.cloudmes.controller.doc;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.doc.WmsCostCenterConfigDto;
import com.maxnerva.cloudmes.service.doc.IWmsCostCenterConfigService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@Api(tags = "费用代码配置管理")
@Slf4j
@RestController
@RequestMapping("/costCenterConfig")
public class CostCenterConfigController {

    @Resource
    private IWmsCostCenterConfigService costCenterConfigService;

    @ApiOperation(value = "根据组织查询SAP工厂")
    @GetMapping("/getSapPlantCode")
    public R<List<WmsCostCenterConfigDto>> getSapPlantCode(@RequestParam("orgCode") String orgCode) {
        return R.ok(costCenterConfigService.getSapPlantCode(orgCode));
    }

    @ApiOperation(value = "根据组织SAP工厂查询费用代码")
    @GetMapping("/getCostCenter")
    public R<List<WmsCostCenterConfigDto>> getCostCenter(@RequestParam("orgCode") String orgCode,
                                                         @RequestParam("plantCode") String plantCode) {
        return R.ok(costCenterConfigService.getCostCenter(orgCode, plantCode));
    }


}
