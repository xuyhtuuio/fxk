package com.maxnerva.cloudmes.controller.wo;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.wo.ProductMoveCheckWorkOrderNoDTO;
import com.maxnerva.cloudmes.models.dto.wo.WmsWorkOrderProductMoveRecordDTO;
import com.maxnerva.cloudmes.models.vo.doc.WmsAdjustDcoVo;
import com.maxnerva.cloudmes.models.vo.wo.BadProductPageQueryVO;
import com.maxnerva.cloudmes.models.vo.wo.WorkOrderProductMoveRecordVO;
import com.maxnerva.cloudmes.models.vo.wo.WorkOrderProductMoveVO;
import com.maxnerva.cloudmes.service.wo.IWmsWorkOrderProductMoveRecordService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;

/**
 * 成品工单101移转记录
 * (WmsWorkOrderProductMoveRecord)表控制层
 *
 * @author hgx
 * @since 2024-01-02 11:12:18
 */
@Api(tags = "工单维护对应关系")
@RestController
@RequestMapping("/productMove")
public class WmsWorkOrderProductMoveRecordController {
    /**
     * 服务对象
     */
    @Resource
    private IWmsWorkOrderProductMoveRecordService wmsWorkOrderProductMoveRecordService;

    @ApiOperation("不良品列表查询")
    @GetMapping("/list")
    public R<PageDataDTO<WmsWorkOrderProductMoveRecordDTO>> selectPage(WorkOrderProductMoveRecordVO pageQueryVO) {
        return R.ok(wmsWorkOrderProductMoveRecordService.selectPage(pageQueryVO));
    }

    @ApiOperation("导出")
    @PostMapping("/export")
    public R<Void> export(HttpServletResponse response,
                          @RequestBody WorkOrderProductMoveRecordVO vo) {
        wmsWorkOrderProductMoveRecordService.export(response, vo);
        return R.ok();
    }

    @ApiOperation("校验原工单")
    @GetMapping("/checkWorkOrderNo")
    public R<ProductMoveCheckWorkOrderNoDTO> checkWorkOrderNo(@RequestParam("orgCode") String orgCode,
                                                              @RequestParam("plantCode") String plantCode,
                                                              @RequestParam("workOrderNo") String workOrderNo) {
        return R.ok(wmsWorkOrderProductMoveRecordService.checkWorkOrderNo(orgCode, plantCode, workOrderNo));
    }

    @ApiOperation("校验目的工单")
    @GetMapping("/checkTargetWorkOrderNo")
    public R<BigDecimal> checkTargetWorkOrderNo(@RequestParam("orgCode") String orgCode,
                                                @RequestParam("plantCode") String plantCode,
                                                @RequestParam("workOrderNo") String workOrderNo,
                                                @RequestParam("targetWorkOrderNo") String targetWorkOrderNo) {
        return R.ok(wmsWorkOrderProductMoveRecordService.checkTargetWorkOrderNo(orgCode, plantCode, workOrderNo, targetWorkOrderNo));
    }

     @ApiOperation("提交移动")
    @PostMapping("/submitMove")
    public R<Void> submitMove(@RequestBody WorkOrderProductMoveVO moveVO) {
        wmsWorkOrderProductMoveRecordService.submitMove(moveVO);
        return R.ok();
    }
}

