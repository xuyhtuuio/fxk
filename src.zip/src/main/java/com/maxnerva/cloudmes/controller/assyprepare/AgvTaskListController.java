package com.maxnerva.cloudmes.controller.assyprepare;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.assyprepare.PartNoDetailDTO;
import com.maxnerva.cloudmes.models.dto.assyprepare.ReturnWarehouseDTO;
import com.maxnerva.cloudmes.models.dto.assyprepare.WmsAgvTaskListDTO;
import com.maxnerva.cloudmes.models.vo.assyprepare.PartNoDetailQueryVO;
import com.maxnerva.cloudmes.models.vo.assyprepare.PublishTaskVO;
import com.maxnerva.cloudmes.models.vo.assyprepare.ReturnWarehouseCheckVO;
import com.maxnerva.cloudmes.models.vo.assyprepare.WmsAgvTaskListQueryVO;
import com.maxnerva.cloudmes.models.vo.mes.SendAgvVO;
import com.maxnerva.cloudmes.service.assyprepare.IWmsAgvTaskListService;
import com.maxnerva.cloudmes.service.assyprepare.MesSendAgvService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @ClassName AgvTaskListController
 * @Description TODO
 * @Author Likun
 * @Date 2024/5/11
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "AGV任务信息管理")
@Slf4j
@RestController
@RequestMapping("/agvTaskList")
public class AgvTaskListController {

    @Resource
    private IWmsAgvTaskListService wmsAgvTaskListService;

    @Resource
    private MesSendAgvService mesSendAgvService;

    @ApiOperation("分页查询agv任务列表")
    @PostMapping("/list")
    public R<PageDataDTO<WmsAgvTaskListDTO>> selectAgvTaskPage(@RequestBody WmsAgvTaskListQueryVO queryVO) {
        return R.ok(wmsAgvTaskListService.selectAgvTaskPage(queryVO));
    }

    @ApiOperation("导出")
    @PostMapping("/export")
    public R<Void> exportAgvTaskList(HttpServletResponse response,
                                     @RequestBody WmsAgvTaskListQueryVO queryVO) {
        wmsAgvTaskListService.exportAgvTaskList(response, queryVO);
        return R.ok();
    }

    @ApiOperation("发布任务")
    @PostMapping("/publishTask")
    public R<Void> publishTask(@RequestBody PublishTaskVO publishTaskVO) {
        return wmsAgvTaskListService.publishTask(publishTaskVO);
    }

    @ApiOperation("余料返仓check")
    @PostMapping("/returnWarehouseCheck")
    public R<ReturnWarehouseDTO> returnWarehouseCheck(@RequestBody ReturnWarehouseCheckVO checkVO) {
        return R.ok(wmsAgvTaskListService.returnWarehouseCheck(checkVO));
    }


    @ApiOperation("余料返仓")
    @PostMapping("/returnWarehouse")
    public R<Void> returnWarehouse(@RequestBody PublishTaskVO taskVO) {
        wmsAgvTaskListService.returnWarehouse(taskVO);
        return R.ok();
    }

    @ApiOperation("料号详情")
    @PostMapping("/partNoDetailList")
    public R<List<PartNoDetailDTO>> selectPartNoDetailList(@RequestBody PartNoDetailQueryVO queryVO){
        return R.ok(wmsAgvTaskListService.selectPartNoDetailList(queryVO));
    }

    @ApiOperation("产线送料")
    @PostMapping("/sendAgv")
    public R<Void> sendAgv(@RequestBody SendAgvVO sendAgvVO){
        mesSendAgvService.sendAgv(sendAgvVO);
        return R.ok();
    }
}
