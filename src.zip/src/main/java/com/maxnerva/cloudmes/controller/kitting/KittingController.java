package com.maxnerva.cloudmes.controller.kitting;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.basic.VehicleMaterialTransferDTO;
import com.maxnerva.cloudmes.models.dto.kitting.*;
import com.maxnerva.cloudmes.models.dto.mes.PkgLinkDTO;
import com.maxnerva.cloudmes.models.dto.prepare.PnUrgentPickTaskDTO;
import com.maxnerva.cloudmes.models.dto.prepare.UrgentPickTaskDTO;
import com.maxnerva.cloudmes.models.dto.warehouse.PkgPrintDTO;
import com.maxnerva.cloudmes.models.dto.wo.*;
import com.maxnerva.cloudmes.models.vo.basic.VehicleMaterialTransferVO;
import com.maxnerva.cloudmes.models.vo.kitting.*;
import com.maxnerva.cloudmes.models.vo.mes.MesCommonRequestVO;
import com.maxnerva.cloudmes.models.vo.prepare.PnUrgentPickTaskQueryVO;
import com.maxnerva.cloudmes.models.vo.prepare.UrgentPickTaskQueryVO;
import com.maxnerva.cloudmes.models.vo.prepare.UrgentPickVO;
import com.maxnerva.cloudmes.models.vo.warehouse.PkgInfoPrintVO;
import com.maxnerva.cloudmes.models.vo.warehouse.WmsLabelMergeScanVO;
import com.maxnerva.cloudmes.models.vo.warehouse.WmsLabelMergeVO;
import com.maxnerva.cloudmes.models.vo.warehouse.WmsLabelSplitVO;
import com.maxnerva.cloudmes.models.vo.wo.ClearVehicleVO;
import com.maxnerva.cloudmes.models.vo.wo.PackagingMaterialWoHeaderQueryVO;
import com.maxnerva.cloudmes.models.vo.wo.PnDetailPageQueryVO;
import com.maxnerva.cloudmes.models.vo.wo.PrepareLogPageQueryVO;
import com.maxnerva.cloudmes.service.lock.LockService;
import com.maxnerva.cloudmes.service.mes.MesService;
import com.maxnerva.cloudmes.service.prepare.IWmsUrgentPickService;
import com.maxnerva.cloudmes.service.wo.IWmsMaterialReturnLogService;
import com.maxnerva.cloudmes.service.wo.IWmsWorkOrderPrepareLogService;
import com.maxnerva.cloudmes.service.wo.IWoService;
import com.maxnerva.cloudmes.utils.CommonResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.util.List;

/**
 * @ClassName KittingController
 * @Description kitting管理
 * @Author Likun
 * @Date 2022/12/1
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "kitting管理")
@Slf4j
@RestController
@RequestMapping("/kitting")
public class KittingController {

    @Resource
    private IWmsWorkOrderPrepareLogService wmsWorkOrderPrepareLogService;

    @Resource
    private IWoService woService;

    @Resource
    private IWmsMaterialReturnLogService wmsMaterialReturnLogService;

    @Resource
    private IWmsUrgentPickService wmsUrgentPickService;

    @Resource
    private MesService mesService;

    @Resource
    private LockService lockService;

    @ApiOperation("物料清单")
    @PostMapping("/prepareLogList")
    public R<PageDataDTO<WorkOrderPrepareLogDTO>> selectPrepareLogPage(@RequestBody PrepareLogPageQueryVO pageQueryVO) {
        return R.ok(wmsWorkOrderPrepareLogService.selectPrepareLogPage(pageQueryVO));
    }

    @ApiOperation("查询工单下的可烧录物料清单")
    @GetMapping("/burnList")
    public R<List<PreparePkgDTO>> selectPrepareLogListByWorkOrderNo(@ApiParam(value = "工单号", required = true)
                                                                    @RequestParam("workOrderNo") String workOrderNo,
                                                                    @ApiParam(value = "工厂组织", required = true)
                                                                    @RequestParam("orgCode") String orgCode) {
        return R.ok(wmsWorkOrderPrepareLogService.selectPrepareLogListByWorkOrderNo(workOrderNo, orgCode));
    }

    @ApiOperation("烧录")
    @PostMapping("/burn")
    public R<PreparePkgDTO> burn(@RequestBody KittingBurnVO kittingBurnVO) {
        return R.ok(wmsWorkOrderPrepareLogService.burn(kittingBurnVO));
    }

    @ApiOperation("根据PKG烧录")
    @PostMapping("/burnByPkg")
    public R<Void> burnByPkg(@RequestBody KittingBurnVO kittingBurnVO) {
        wmsWorkOrderPrepareLogService.burnByPkg(kittingBurnVO);
        return R.ok();
    }

    @ApiOperation("pkg烧录信息")
    @GetMapping("/burnInfo")
    public R<PkgBurnDTO> burnInfo(@RequestParam("pkgId") String pkgId,
                                  @RequestParam("orgCode") String orgCode) {
        return R.ok(wmsWorkOrderPrepareLogService.burnInfo(pkgId, orgCode));
    }

    @ApiOperation(value = "合盘扫描条码")
    @PostMapping("/scanMerge")
    public R<KittingLabelScanDTO> scanMerge(@Valid @RequestBody WmsLabelMergeScanVO wmsLabelMergeScanVO) {
        return R.ok(wmsWorkOrderPrepareLogService.scanMerge(wmsLabelMergeScanVO));
    }

    @ApiOperation(value = "合盘")
    @PostMapping("/merge")
    public R<Void> labelMerge(@RequestBody WmsLabelMergeVO mergeVo) {
        wmsWorkOrderPrepareLogService.labelMerge(mergeVo);
        return R.ok();
    }

    @ApiOperation(value = "分盘")
    @PostMapping("/split")
    public R<List<String>> labelSplit(@RequestBody WmsLabelSplitVO wmsLabelSplitVO) {
        return R.ok(wmsWorkOrderPrepareLogService.splitLabel(wmsLabelSplitVO));
    }

    @ApiOperation(value = "转工单")
    @PostMapping("/transferInWorkOrder")
    public R<Void> transferInWorkOrder(@RequestBody TransferInWorkOrderVO transferInWorkOrderVO) {
        wmsWorkOrderPrepareLogService.transferInWorkOrder(transferInWorkOrderVO);
        return R.ok();
    }

    @ApiOperation(value = "分盘扫描条码")
    @GetMapping("/scanByPkgId")
    public R<KittingLabelScanDTO> scanByPkgId(@RequestParam("pkgId") String pkgId,
                                              @RequestParam("orgCode") String orgCode) {
        return R.ok(wmsWorkOrderPrepareLogService.scanByPkgId(pkgId, orgCode));
    }

    @ApiOperation("工单号查询")
    @GetMapping("workOrderList")
    public R<List<WmsWorkOrderHeaderDTO>> selectWorkOrderList(String orgCode) {
        return R.ok(wmsWorkOrderPrepareLogService.selectWorkOrderNo(orgCode));
    }

    @ApiOperation("kitting物料清单excel导出")
    @PostMapping("/exportPrepareLog")
    public void exportPrepareLog(HttpServletResponse response,
                                 @RequestBody PrepareLogPageQueryVO pageQueryVO) throws IOException {
        wmsWorkOrderPrepareLogService.exportPrepareLog(response, pageQueryVO);
    }

    @ApiOperation("查询条码打印信息")
    @PostMapping("/printInfoList")
    public R<PkgPrintDTO> selectResources(@RequestBody PkgInfoPrintVO pkgInfoPrintVO) {
        return R.ok(wmsWorkOrderPrepareLogService.printPkgInfo(pkgInfoPrintVO));
    }

    @ApiOperation("退料扫描pkg")
    @PostMapping("/returnMaterial/scanPkg")
    public R<ReturnScanPkgDTO> returnMaterialScanPkg(@RequestBody ReturnScanPkgVO returnScanPkgVO) {
        return R.ok(woService.returnMaterialScanPkg(returnScanPkgVO));
    }

    @ApiOperation("SFC SMT退料提交")
    @PostMapping("/returnMaterial/submit")
    public R<MaterialReturnDTO> returnMaterial(@RequestBody MaterialReturnVO materialReturnVO) {
        return R.ok(woService.returnMaterial(materialReturnVO));
    }

    @ApiOperation("ASSY退料提交")
    @PostMapping("/returnAssyMaterial/submit")
    public R<MaterialReturnDTO> returnAssyMaterial(@RequestBody MaterialReturnVO materialReturnVO) {
        return R.ok(woService.returnAssyMaterial(materialReturnVO));
    }

    @ApiOperation("盘点机退料")
    @PostMapping("/returnOfMaterialByMachine")
    public CommonResult returnOfMaterialByMachine(@RequestBody List<ReturnOfMaterialVO> returnOfMaterialVOList) {
        return woService.returnOfMaterialByMachine(returnOfMaterialVOList);
    }

    @ApiOperation("WMS SMT退料提交---退料绑载具")
    @PostMapping("/returnMaterial")
    public R<MaterialReturnDTO> returnMaterialAfterMachine(@RequestBody MaterialReturnVO materialReturnVO) {
        return R.ok(woService.returnMaterialAfterMachine(materialReturnVO));
    }

    @ApiOperation("kitting载具物料转移")
    @PostMapping("/vehicleMaterialTransfer")
    public R<VehicleMaterialTransferDTO> vehicleMaterialTransfer(@Valid @RequestBody VehicleMaterialTransferVO vehicleMaterialTransferVO) {
        return R.ok(wmsWorkOrderPrepareLogService.vehicleMaterialTransfer(vehicleMaterialTransferVO));
    }

    @ApiOperation("退料查询条码打印信息")
    @PostMapping("/printReturnPkgInfoList")
    public R<PkgPrintDTO> selectReturnPkgResources(@RequestBody PkgInfoPrintVO pkgInfoPrintVO) {
        return R.ok(wmsMaterialReturnLogService.printPkgInfo(pkgInfoPrintVO));
    }

    @ApiOperation("kitting载具初始化")
    @PostMapping("/clearVehicle")
    public R<Integer> clearVehicle(@RequestBody ClearVehicleVO clearVehicleVO) {
        return R.ok(wmsWorkOrderPrepareLogService.clearVehicle(clearVehicleVO));
    }

    @ApiOperation("SFC 大盘退料--退料盘点")
    @PostMapping("/returnLargeMaterial")
    public R<ReturnOfMaterialDTO> returnLargeMaterial(@RequestBody ReturnLargeMaterialVO returnLargeMaterialVO) {
        return R.ok(lockService.returnLargeMaterial(returnLargeMaterialVO));
    }

    @ApiOperation("紧急叫料--列表")
    @PostMapping("/urgentPickTaskList")
    public R<PageDataDTO<UrgentPickTaskDTO>> selectUrgentPickTaskPage(@RequestBody UrgentPickTaskQueryVO queryVO) {
        return R.ok(wmsUrgentPickService.selectUrgentPickTaskPage(queryVO));
    }

    @ApiOperation("紧急叫料--sfc紧急叫料")
    @PostMapping("/urgentPickBySfc")
    public R<Void> urgentPickBySfc(@RequestBody UrgentPickVO urgentPickVO) {
        return wmsUrgentPickService.urgentPickBySfc(urgentPickVO);
    }

    @ApiOperation("紧急叫料--导出")
    @PostMapping("/exportUrgentPickTaskList")
    public R<Void> exportUrgentPickTaskList(HttpServletResponse response,
                                            @RequestBody UrgentPickTaskQueryVO queryVO) {
        wmsUrgentPickService.exportUrgentPickTaskList(response, queryVO);
        return R.ok();
    }

    @ApiOperation("盘点拆盘")
    @PostMapping("/countingSplit")
    public R<CountingSplitDTO> countingSplit(@RequestBody CountingSplitVO countingSplitVO) {
        return R.ok(wmsWorkOrderPrepareLogService.countingSplit(countingSplitVO));
    }

    @ApiOperation("包材叫料清单")
    @PostMapping("/packagingMaterialList")
    public R<PageDataDTO<PnWorkOrderDetailDTO>> selectPackagingMaterialList(@RequestBody PnDetailPageQueryVO
                                                                                    pageQueryVO) {
        return R.ok(wmsUrgentPickService.selectPackagingMaterialPage(pageQueryVO));
    }

    @ApiOperation("包材叫料提交")
    @PostMapping("/packagingMaterialSubmit")
    public R<Void> packagingMaterialSubmit(@RequestBody PackagingMaterialSubmitVO packagingMaterialSubmitVO) {
        wmsUrgentPickService.packagingMaterialSubmit(packagingMaterialSubmitVO);
        return R.ok();
    }

    @ApiOperation("包材叫料对应捡料任务清单")
    @PostMapping("/pnUrgentPickTaskList")
    public R<PageDataDTO<PnUrgentPickTaskDTO>> selectPnUrgentPickTaskPage(@RequestBody PnUrgentPickTaskQueryVO queryVO) {
        return R.ok(wmsUrgentPickService.selectPnUrgentPickTaskPage(queryVO));
    }

    @ApiOperation("包材叫料工单信息查询")
    @PostMapping("/packagingMaterialWoHeaderList")
    public R<PageDataDTO<PackagingMaterialWoHeaderDTO>> selectPackagingMaterialWoHeaderPage(
            @RequestBody PackagingMaterialWoHeaderQueryVO queryVO) {
        return R.ok(wmsUrgentPickService.selectPackagingMaterialWoHeaderPage(queryVO));
    }

    @ApiOperation("合备工单退料扫描条码")
    @PostMapping("/scanMergeMaterialReturnPkg")
    public R<List<String>> scanMergeMaterialReturnPkg(@RequestBody MergeMaterialReturnScanVO materialReturnScanVO) {
        return R.ok(woService.scanMergeMaterialReturnPkg(materialReturnScanVO));
    }

    @ApiOperation("合备工单退料")
    @PostMapping("/returnMergeMaterial")
    public R<ReturnOfMaterialDTO> returnMergeMaterial(@RequestBody MergeReturnMaterialVO mergeReturnMaterialVO) {
        return R.ok(woService.returnMergeMaterial(mergeReturnMaterialVO));
    }

    @ApiOperation("扫描pkg获取MES拼接料信息")
    @PostMapping("/queryPkgLinkInfo")
    public R<List<PkgLinkDTO>> queryPkgLinkInfo(@RequestBody MesCommonRequestVO mesCommonRequestVO) {
        return R.ok(mesService.queryPkgLinkInfo(mesCommonRequestVO));
    }

    @ApiOperation("打散接料打印条码")
    @PostMapping("/printPkgLinkInfo")
    public R<PkgPrintDTO> printPkgLinkInfo(@RequestBody MesCommonRequestVO mesCommonRequestVO) {
        return R.ok(wmsWorkOrderPrepareLogService.printPkgLinkInfo(mesCommonRequestVO));
    }
}
