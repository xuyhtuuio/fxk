package com.maxnerva.cloudmes.controller.doc;

import com.maxnerva.cloudmes.aspect.FactoryOperationLog;
import com.maxnerva.cloudmes.common.constant.OperationTypeConstant;
import com.maxnerva.cloudmes.common.enums.ResultCode;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.doc.WmsDocTypeDTO;
import com.maxnerva.cloudmes.models.vo.doc.DocTypeByCodeVO;
import com.maxnerva.cloudmes.models.vo.doc.DocTypePageQueryVO;
import com.maxnerva.cloudmes.models.vo.doc.WmsDocTypeVO;
import com.maxnerva.cloudmes.service.doc.IWmsDocTypeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * @ClassName DocTypeController
 * @Description 单据类型管理
 * @Author Likun
 * @Date 2022/7/27
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "单据类型管理")
@Slf4j
@RestController
@RequestMapping("/docType")
public class DocTypeController {

    @Resource
    private IWmsDocTypeService wmsDocTypeService;

    @ApiOperation("新增单据类型")
    @PostMapping("/add")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "新增单据类型")
    public R<Void> saveDocType(@Valid @RequestBody WmsDocTypeVO docTypeVO) {
        wmsDocTypeService.saveDocType(docTypeVO);
        return R.ok();
    }

    @ApiOperation("修改单据类型")
    @PutMapping("/update")
    @FactoryOperationLog(operationType = OperationTypeConstant.MODIFY, description = "修改单据类型")
    public R<Void> updateDocType(@Valid @RequestBody WmsDocTypeVO docTypeVO) {
        wmsDocTypeService.updateDocType(docTypeVO);
        return R.ok();
    }

    @ApiOperation("删除单据类型")
    @DeleteMapping("/delete")
    @FactoryOperationLog(operationType = OperationTypeConstant.DELETE, description = "删除单据类型")
    public R<Void> deleteDocType(@RequestBody List<Integer> idList) {
        wmsDocTypeService.deleteDocTypeBatch(idList);
        return R.ok();
    }

    @ApiOperation("查询单据类型信息")
    @PostMapping("/list")
    public R<PageDataDTO<WmsDocTypeDTO>> selectPage(@RequestBody DocTypePageQueryVO queryVO) {
        return R.ok(wmsDocTypeService.selectPage(queryVO));
    }

    @ApiOperation("根据物料操作类型查询单据类型信息")
    @GetMapping("/list")
    public R<List<WmsDocTypeDTO>> getDocTypeListByOperateType(@RequestParam String materialOperateType) {
        return R.ok(wmsDocTypeService.getDocTypeListByOperateType(materialOperateType));
    }

    @ApiOperation("多个单据类型code查询单据类型信息")
    @PostMapping("/listByTypeCode")
    public R<List<WmsDocTypeDTO>> listByTypeCode(@RequestBody DocTypeByCodeVO vo) {
        return R.ok(wmsDocTypeService.listByTypeCode(vo));
    }

}
