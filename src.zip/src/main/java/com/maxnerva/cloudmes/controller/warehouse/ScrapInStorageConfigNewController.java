package com.maxnerva.cloudmes.controller.warehouse;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.warehouse.ScrapTypeDTO;
import com.maxnerva.cloudmes.models.dto.warehouse.WmsWorkOrderDetailScrapInStorageConfigNewDTO;
import com.maxnerva.cloudmes.models.vo.warehouse.ScrapInStorageConfigNewQueryVO;
import com.maxnerva.cloudmes.models.vo.warehouse.ScrapInStorageConfigNewVO;
import com.maxnerva.cloudmes.service.warehouse.IWmsWorkOrderDetailScrapInStorageConfigNewService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * @ClassName ScrapInStorageConfigNewController
 * @Description TODO
 * @Author Likun
 * @Date 2024/6/26
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "报废板仓码配置管理")
@Slf4j
@RestController
@RequestMapping("/scrapInStorageConfigNew")
public class ScrapInStorageConfigNewController {

    @Resource
    private IWmsWorkOrderDetailScrapInStorageConfigNewService scrapInStorageConfigNewService;

    @ApiOperation("分页查询配置信息")
    @PostMapping("/list")
    public R<PageDataDTO<WmsWorkOrderDetailScrapInStorageConfigNewDTO>> selectConfigPage(
            @RequestBody ScrapInStorageConfigNewQueryVO queryVO) {
        return R.ok(scrapInStorageConfigNewService.selectConfigPage(queryVO));
    }

    @ApiOperation("新增/修改配置信息")
    @PostMapping("/saveOrUpdateConfig")
    public R<Void> saveOrUpdateConfig(
            @Valid @RequestBody ScrapInStorageConfigNewVO scrapInStorageConfigNewVO) {
        scrapInStorageConfigNewService.saveOrUpdateConfig(scrapInStorageConfigNewVO);
        return R.ok();
    }

    @ApiOperation("删除配置信息")
    @DeleteMapping("/delete")
    public R<Void> delete(@RequestBody List<Integer> idList) {
        scrapInStorageConfigNewService.deleteBatch(idList);
        return R.ok();
    }

    @ApiOperation("报废类型列表")
    @GetMapping("/scrapeTypeList")
    private R<List<ScrapTypeDTO>> selectScrapeTypeList(@RequestParam("orgCode") String orgCode,
                                                       @RequestParam("plantCode") String plantCode) {
        return R.ok(scrapInStorageConfigNewService.selectTypeList(orgCode, plantCode));
    }
}
