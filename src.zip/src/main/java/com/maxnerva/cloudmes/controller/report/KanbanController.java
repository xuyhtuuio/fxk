package com.maxnerva.cloudmes.controller.report;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.excel.util.DataSourceUtil;
import com.maxnerva.cloudmes.models.dto.report.*;
import com.maxnerva.cloudmes.models.vo.report.*;
import com.maxnerva.cloudmes.service.report.IKanbanService;
import com.maxnerva.cloudmes.utils.ExcelMergeCellValue;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Api(tags = "看板")
@Slf4j
@RestController
@RequestMapping("/kanban")
public class KanbanController {
    @Autowired
    IKanbanService kanbanService;

    @ApiOperation("工单作业任务")
    @GetMapping("/getPickTask")
    public R<PageDataDTO<GetPickTaskDTO>> getPickTask(GetPickTaskVO vo){
        return R.ok(kanbanService.getPickTask(vo, Boolean.TRUE));
    }

    @ApiOperation("工单作业任务导出")
    @GetMapping("/getPickTaskExport")
    public void getPickTaskExport(GetPickTaskVO vo, HttpServletResponse response){
        kanbanService.getPickTaskExport(vo, response);
    }

    @ApiOperation("直备区作业看板")
    @GetMapping("/getDirectWorkStock")
    R<PageDataDTO<GetDirectWorkStockDTO>> getDirectWorkStock(GetDirectWorkStockVO vo){
        return R.ok(kanbanService.getDirectWorkStock(vo, Boolean.TRUE));
    }

    @ApiOperation("直备区作业看板导出")
    @GetMapping("/getDirectWorkStockExport")
    void getDirectWorkStockExport(GetDirectWorkStockVO vo, HttpServletResponse response){
        kanbanService.getDirectWorkStockExport(vo, response);
    }

    @ApiOperation("MES看板获取工单首套料备料情况")
    @GetMapping("/getWoPrepareFirstStatus")
    R<GetWoPrepareFirstStatusDTO> getWoPrepareFirstStatus(GetWoPrepareFirstStatusVO vo){
        DataSourceUtil.setWmsDataSource();
        return R.ok(kanbanService.getWoPrepareFirstStatus(vo));
    }

    @ApiOperation("查询岗位")
    @GetMapping("/getJobList")
    R<List<String>> getJobList(@RequestParam(value = "orgCode") String orgCode){
        return R.ok(kanbanService.getJobList(orgCode));
    }

    @ApiOperation("人员作业数据看板")
    @GetMapping("/getStaffWorkData")
    R<GetStaffWorkDataDTO> getStaffWorkData(GetStaffWorkDataVO vo){
        return R.ok(kanbanService.getStaffWorkData(vo));
    }

    @ApiOperation("出貨區作業看板")
    @GetMapping("/getShipWorkData")
    R<PageDataDTO<GetShipWorkDataDTO>> getShipWorkData(GetShipWorkDataVO vo){
        return R.ok(kanbanService.getShipWorkData(vo, Boolean.TRUE));
    }

    @ApiOperation("出貨區作業看板导出")
    @GetMapping("/getShipWorkDataExport")
    void getShipWorkDataExport(GetShipWorkDataVO vo, HttpServletResponse response){
        kanbanService.getShipWorkDataExport(vo, response);
    }

    @ApiOperation("工单备料进度看板")
    @GetMapping("/woStockProgress")
    R<PageDataDTO<WoStockProgressDTO>> woStockProgress(WoStockProgressVO vo){
        return R.ok(kanbanService.woStockProgress(vo));
    }

    @ApiOperation("工单备料缺料")
    @GetMapping("/woStockLack")
    R<PageDataDTO<WoStockLackDTO>> woStockLack(WoStockLackVO vo){
        return R.ok(kanbanService.woStockLack(vo));
    }

    @ApiOperation("原物料仓库概况")
    @GetMapping("/rawWarehouseOverview")
    R<RawWarehouseOverviewDTO> rawWarehouseOverview(RawWarehouseOverviewVO vo){
        return R.ok(kanbanService.rawWarehouseOverview(vo));
    }

    @ApiOperation("成品料仓库概况")
    @GetMapping("/prodWarehouseOverview")
    R<ProdWarehouseOverviewDTO> prodWarehouseOverview(RawWarehouseOverviewVO vo){
        return R.ok(kanbanService.prodWarehouseOverview(vo));
    }
}
