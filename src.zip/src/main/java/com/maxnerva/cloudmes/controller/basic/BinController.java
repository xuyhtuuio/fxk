package com.maxnerva.cloudmes.controller.basic;

import com.maxnerva.cloudmes.aspect.FactoryOperationLog;
import com.maxnerva.cloudmes.common.constant.OperationTypeConstant;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.basic.WmsBinDTO;
import com.maxnerva.cloudmes.models.vo.basic.BinPageQueryVO;
import com.maxnerva.cloudmes.models.vo.basic.WmsBinVO;
import com.maxnerva.cloudmes.models.vo.warehouse.ScanBinVO;
import com.maxnerva.cloudmes.service.basic.IWmsBinService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * @ClassName BinController
 * @Description 储位管理
 * @Author Likun
 * @Date 2022/7/22
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "储位管理")
@Slf4j
@RestController
@RequestMapping("/bin")
public class BinController {

    @Resource
    private IWmsBinService wmsBinService;

    @ApiOperation("新增储位")
    @PostMapping("/add")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "新增储位")
    public R<Void> saveBin(@Valid @RequestBody WmsBinVO binVO) {
        wmsBinService.saveBin(binVO);
        return R.ok();
    }

    @ApiOperation("修改储位")
    @PutMapping("/update")
    @FactoryOperationLog(operationType = OperationTypeConstant.MODIFY, description = "修改储位")
    public R<Void> updateBin(@Valid @RequestBody WmsBinVO binVO) {
        wmsBinService.updateBin(binVO);
        return R.ok();
    }

    @ApiOperation("删除储位")
    @DeleteMapping("/delete")
    @FactoryOperationLog(operationType = OperationTypeConstant.DELETE, description = "删除储位")
    public R<Void> deleteBin(@RequestBody List<Integer> idList) {
        wmsBinService.deleteBinBatch(idList);
        return R.ok();
    }

    @ApiOperation("查询储位信息")
    @PostMapping("/list")
    public R<PageDataDTO<WmsBinDTO>> selectPage(@RequestBody BinPageQueryVO queryVO) {
        return R.ok(wmsBinService.selectPage(queryVO));
    }

    @ApiOperation("扫描储位")
    @PostMapping("/scanBin")
    public R<Void> scanBin(@RequestBody ScanBinVO scanBinVO) {
        wmsBinService.scanBin(scanBinVO);
        return R.ok();
    }
}
