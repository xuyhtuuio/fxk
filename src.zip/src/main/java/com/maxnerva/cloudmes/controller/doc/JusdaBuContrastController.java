package com.maxnerva.cloudmes.controller.doc;

import com.maxnerva.cloudmes.aspect.FactoryOperationLog;
import com.maxnerva.cloudmes.common.constant.OperationTypeConstant;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.doc.JusdaBuContrastDTO;
import com.maxnerva.cloudmes.models.vo.doc.JusdaBuSaveVO;
import com.maxnerva.cloudmes.models.vo.doc.JusdaBuSelectVO;
import com.maxnerva.cloudmes.service.doc.IWmsJusdaBuContrastService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@Api(tags = "准时达BU对照")
@Slf4j
@RestController
@RequestMapping("/jusdaBu")
public class JusdaBuContrastController {

    @Resource
    private IWmsJusdaBuContrastService jusdaBuContrastService;

    @ApiOperation("新增")
    @PostMapping("/add")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "新增")
    public R<Integer> add(@RequestBody JusdaBuSaveVO buAddVO) {
        return R.ok(jusdaBuContrastService.add(buAddVO));
    }

    @ApiOperation("删除")
    @DeleteMapping("/delete")
    @FactoryOperationLog(operationType = OperationTypeConstant.DELETE, description = "删除")
    public R<Void> scanPallet(@RequestBody List<Integer> idList) {
        jusdaBuContrastService.deleteByIds(idList);
        return R.ok();
    }

    @ApiOperation("修改")
    @PostMapping("/update")
    @FactoryOperationLog(operationType = OperationTypeConstant.MODIFY, description = "修改")
    public R<Integer> update(@RequestBody JusdaBuSaveVO buSaveVO) {
        return R.ok(jusdaBuContrastService.updateContrast(buSaveVO));
    }

    @ApiOperation("查询列表")
    @GetMapping("/list")
    public R<PageDataDTO<JusdaBuContrastDTO>> selectLsit(JusdaBuSelectVO pageQueryVO) {
        return R.ok(jusdaBuContrastService.selectLsit(pageQueryVO));
    }


}
