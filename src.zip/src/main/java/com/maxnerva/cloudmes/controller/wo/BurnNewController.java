package com.maxnerva.cloudmes.controller.wo;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.excel.util.DataSourceUtil;
import com.maxnerva.cloudmes.models.dto.wo.*;
import com.maxnerva.cloudmes.models.vo.kitting.ClearBurndedValueByPkgVO;
import com.maxnerva.cloudmes.models.vo.kitting.RepeatWriteBurndedValueByPkgVO;
import com.maxnerva.cloudmes.models.vo.kitting.WmsWriteBurndedValueByPkgVO;
import com.maxnerva.cloudmes.models.vo.kitting.WriteBurndedValueByPkgVO;
import com.maxnerva.cloudmes.models.vo.wo.BurnPkgInfoPrintVO;
import com.maxnerva.cloudmes.service.wo.IWmsPkgBurnInfoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Author hgx
 * @Description
 * @Date 2023/6/6
 */
@Api(tags = "烧录管理-new")
@Slf4j
@RestController
@RequestMapping("/burn")
public class BurnNewController {

    @Resource
    private IWmsPkgBurnInfoService wmsPkgBurnInfoService;

    @ApiOperation("按成品料号查询烧录清单")
    @GetMapping("/getBurnedInfo")
    public R<List<BurnInfoNewDTO>> getBurnedInfo(@RequestParam("orgCode") String orgCode,
                                                 @RequestParam("finishedProductPartNo") String finishedProductPartNo) {
        DataSourceUtil.setWmsDataSource();
        return R.ok(wmsPkgBurnInfoService.getBurnedInfo(orgCode, finishedProductPartNo));
    }

    @ApiOperation("按工单查询烧录信息")
    @GetMapping("/getBurnedInfoOfWo")
    public R<List<GetBurnedInfoOfWoDTO>> getBurnedInfoOfWo(@RequestParam("workOrderNo") String workOrderNo,
                                                              @RequestParam("orgCode") String orgCode) {
        DataSourceUtil.setWmsDataSource();
        return R.ok(wmsPkgBurnInfoService.getBurnedInfoOfWo(orgCode, workOrderNo));
    }

    @Deprecated
    @ApiOperation("按PKGID查询烧录信息")
    @GetMapping("/getBurnedInfoOfPkgId")
    public R<GetBurnedInfoOfPkgIdDTO> getBurnedInfoOfPkgId(@RequestParam("pkgId") String pkgId,
                                                  @RequestParam("orgCode") String orgCode) {
        DataSourceUtil.setWmsDataSource();
        return R.ok(wmsPkgBurnInfoService.getBurnedInfoOfPkgId(orgCode, pkgId));
    }

    @ApiOperation("烧录完成回写")
    @PostMapping("/writeBurndedValueByPkg")
    public R<Void> writeBurndedValueByPkg(@RequestBody WriteBurndedValueByPkgVO writeBurndedValueByPkgVO) {
        DataSourceUtil.setWmsDataSource();
        wmsPkgBurnInfoService.writeBurndedValueByPkg(writeBurndedValueByPkgVO);
        return R.ok();
    }

    @ApiOperation("WMS烧录pkg烧录信息")
    @GetMapping("/burnInfo")
    public R<PkgBurnDTO> burnInfo(@RequestParam("pkgId") String pkgId,
                                  @RequestParam("orgCode") String orgCode,
                                  @RequestParam("workOrderNo") String workOrderNo) {
        return R.ok(wmsPkgBurnInfoService.burnInfo(pkgId, orgCode, workOrderNo));
    }

    @ApiOperation("WMS烧录完成回写-对外提供")
    @PostMapping("/wmsWriteBurndedValueByPkg")
    public R<Void> wmsWriteBurndedValueByPkg(@RequestBody WmsWriteBurndedValueByPkgVO wmsWriteBurndedValueByPkgVO) {
        DataSourceUtil.setWmsDataSource();
        wmsPkgBurnInfoService.wmsWriteBurndedValueByPkg(wmsWriteBurndedValueByPkgVO);
        return R.ok();
    }

    @ApiOperation("WMS烧录完成回写-内部使用")
    @PostMapping("/wmsWriteBurndedValueByPkgOwn")
    public R<Void> wmsWriteBurndedValueByPkgOwn(@RequestBody WmsWriteBurndedValueByPkgVO wmsWriteBurndedValueByPkgVO) {
        wmsPkgBurnInfoService.wmsWriteBurndedValueByPkg(wmsWriteBurndedValueByPkgVO);
        return R.ok();
    }

    @ApiOperation("擦除烧录")
    @PostMapping("/clearBurndedValueByPkg")
    public R<Void> clearBurndedValueByPkg(@RequestBody ClearBurndedValueByPkgVO clearBurndedValueByPkgVO) {
        DataSourceUtil.setWmsDataSource();
        wmsPkgBurnInfoService.clearBurndedValueByPkg(clearBurndedValueByPkgVO);
        return R.ok();
    }

    @ApiOperation("烧录标签列印")
    @PostMapping("/printInfo")
    public R<BurnPkgPrintDTO> selectPrintInfo(@RequestBody BurnPkgInfoPrintVO pkgInfoPrintVO) {
        return R.ok(wmsPkgBurnInfoService.selectPrintInfo(pkgInfoPrintVO));
    }

    @ApiOperation("按PKGID查询烧录清单")
    @GetMapping("/getBurnedInfoOfPkgIdWo")
    public R<List<GetBurnedInfoOfPkgIdWoDTO>> getBurnedInfoOfPkgIdWo(@RequestParam("orgCode") String orgCode,
                                                               @RequestParam("workOrderNo") String workOrderNo,
                                                               @RequestParam(value = "pkgId", required = false) String pkgId) {
        DataSourceUtil.setWmsDataSource();
        return R.ok(wmsPkgBurnInfoService.getBurnedInfoOfPkgIdWo(orgCode, workOrderNo, pkgId));
    }

    @ApiOperation("产线烧录完成回写")
    @PostMapping("/repeatWriteBurndedValueByPkg")
    public R<Void> repeatWriteBurndedValueByPkg(@RequestBody RepeatWriteBurndedValueByPkgVO vo) {
        DataSourceUtil.setWmsDataSource();
        wmsPkgBurnInfoService.repeatWriteBurndedValueByPkg(vo);
        return R.ok();
    }
}
