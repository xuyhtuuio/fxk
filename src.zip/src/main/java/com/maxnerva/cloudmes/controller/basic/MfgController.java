package com.maxnerva.cloudmes.controller.basic;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.service.basic.IWmsSapPlantService;
import com.maxnerva.cloudmes.service.sap.po.PoRfcService;
import com.maxnerva.cloudmes.service.sap.po.model.MfrInfoDto;
import com.sap.conn.jco.JCoException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@Api(tags = "制造商")
@Slf4j
@RestController
@RequestMapping("/mfg")
public class MfgController {

    @Resource
    private PoRfcService poRfcService;
    @Resource
    private IWmsSapPlantService wmsSapPlantService;

    @ApiOperation("查询制造商名称")
    @GetMapping("/getMfgName")
    public R<MfrInfoDto> getMfgName(@RequestParam("orgCode") String orgCode,
                                    @RequestParam("mfrCode") String mfrCode) throws JCoException {
        String sapClient = wmsSapPlantService.getErpInterface(orgCode);
        return R.ok(poRfcService.doGetMfrNameByCodeForQms(sapClient, mfrCode));
    }
}
