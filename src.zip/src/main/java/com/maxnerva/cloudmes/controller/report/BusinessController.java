package com.maxnerva.cloudmes.controller.report;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.ExcelMergeCommonDTO;
import com.maxnerva.cloudmes.models.dto.report.*;
import com.maxnerva.cloudmes.models.dto.warehouse.WmsSpecialUserMachineReturnLogDTO;
import com.maxnerva.cloudmes.models.vo.report.*;
import com.maxnerva.cloudmes.models.vo.warehouse.WmsSpecialUserMachineReturnLogQueryVO;
import com.maxnerva.cloudmes.service.report.IBusinessService;
import com.maxnerva.cloudmes.service.warehouse.IWmsSpecialUserMachineReturnLogService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Api(tags = "业务报表")
@Slf4j
@RestController
@RequestMapping("/businessReport")
public class BusinessController {

    @Autowired
    IBusinessService businessService;

    @Resource
    IWmsSpecialUserMachineReturnLogService wmsSpecialUserMachineReturnLogService;

    @ApiOperation("退料明细")
    @GetMapping("/returnToWms")
    R<PageDataDTO<ReturnToWmsDTO>> returnToWms(ReturnToWmsVO vo){
        return R.ok(businessService.returnToWms(vo, Boolean.TRUE));
    }

    @ApiOperation("退料明细导出")
    @GetMapping("/returnToWmsExport")
    void returnToWmsExport(ReturnToWmsVO vo, HttpServletResponse response){
        businessService.returnToWmsExport(vo, response);
    }

    @ApiOperation("退料进行中明细")
    @GetMapping("/returnToWmsIng")
    R<PageDataDTO<ReturnToWmsIngDTO>> returnToWmsIng(ReturnToWmsVO vo){
        return R.ok(businessService.returnToWmsIng(vo, Boolean.TRUE));
    }

    @ApiOperation("导出退料进行中明细")
    @GetMapping("/returnToWmsIngExport")
    void returnToWmsIngExport(ReturnToWmsVO vo, HttpServletResponse response){
        businessService.returnToWmsIngExport(vo, response);
    }

    @ApiOperation("准时达带栈板信息")
    @GetMapping("/jusdaPalletInfo")
    R<PageDataDTO<JusdaPalletInfoDTO>> jusdaPalletInfo(JusdaPalletInfoVO vo){
        return R.ok(businessService.jusdaPalletInfo(vo, Boolean.TRUE));
    }

    @ApiOperation("准时达带栈板信息导出")
    @GetMapping("/jusdaPalletInfoExport")
    void jusdaPalletInfoExport(JusdaPalletInfoVO vo, HttpServletResponse response){
        businessService.jusdaPalletInfoExport(vo, response);
    }

    @ApiOperation("工单发料信息")
    @GetMapping("/workOrderDetail")
    R<PageDataDTO<GetWorkOrderDetailDTO>> getWorkOrderDetail(GetWorkOrderDetailVO vo){
        return R.ok(businessService.getWorkOrderDetail(vo, Boolean.TRUE));
    }

    @ApiOperation("工单发料信息导出")
    @GetMapping("/workOrderDetailExport")
    void getWorkOrderDetailExport(GetWorkOrderDetailVO vo, HttpServletResponse response){
        businessService.getWorkOrderDetailExport(vo, response);
    }

    @ApiOperation("成品出货报表")
    @PostMapping("/shipInfo")
    R<PageDataDTO<ShipInfoDTO>> shipInfo(@RequestBody ShipInfoVO vo){
        return R.ok(businessService.shipInfo(vo, Boolean.TRUE));
    }

    @ApiOperation("成品出货报表导出")
    @PostMapping("/shipInfoExport")
    void shipInfoExport(@RequestBody ShipInfoVO vo, HttpServletResponse response){
        businessService.shipInfoExport(vo, response);
    }

    @ApiOperation("成品库存报表")
    @GetMapping("/finishStore")
    R<PageDataDTO<FinishStoreDTO>> finishStore(FinishStoreVO vo){
        return R.ok(businessService.finishStore(vo, Boolean.TRUE));
    }

    @ApiOperation("成品库存报表导出")
    @GetMapping("/finishStoreExport")
    void finishStoreExport(FinishStoreVO vo, HttpServletResponse response){
        businessService.finishStoreExport(vo, response);
    }

    @ApiOperation("准时达库存")
    @GetMapping("/jusdaInventory")
    R<PageDataDTO<GetJusdaInventoryDTO>> getJusdaInventory(GetJusdaInventoryVO vo) {
        return R.ok(businessService.getJusdaInventory(vo, Boolean.TRUE));
    }

    @ApiOperation("准时达库存导出")
    @GetMapping("/jusdaInventoryExport")
    void getJusdaInventoryExport(GetJusdaInventoryVO vo, HttpServletResponse response) {
        businessService.getJusdaInventoryExport(vo, response);
    }

    @ApiOperation("原物料库存报表")
    @GetMapping("/getRawMaterial")
    R<PageDataDTO<GetRawMaterialDTO>> getRawMaterial(GetRawMaterialVO vo) {
        return R.ok(businessService.getRawMaterial(vo, Boolean.TRUE));
    }

    @ApiOperation("原物料库存报表导出")
    @GetMapping("/getRawMaterialExport")
    void getRawMaterialExport(GetRawMaterialVO vo, HttpServletResponse response) {
        businessService.getRawMaterialExport(vo, response);
    }

    @ApiOperation("不良品库存报表")
    @GetMapping("/getDefectiveProduct")
    R<PageDataDTO<GetDefectiveProductDTO>> getDefectiveProduct(GetDefectiveProductVO vo) {
        return R.ok(businessService.getDefectiveProduct(vo, Boolean.TRUE));
    }

    @ApiOperation("不良品库存报表导出")
    @GetMapping("/getDefectiveProductExport")
    void getDefectiveProductExport(GetDefectiveProductVO vo, HttpServletResponse response) {
        businessService.getDefectiveProductExport(vo, response);
    }

    @ApiOperation("员工作业统计")
    @GetMapping("/getStaffPkgInfoLogDayNote")
    R<PageDataDTO<GetStaffPkgInfoLogDayNoteDTO>> getStaffPkgInfoLogDayNote(GetStaffPkgInfoLogDayNoteVO vo) {
        return R.ok(businessService.getStaffPkgInfoLogDayNote(vo, Boolean.TRUE));
    }

    @ApiOperation("员工作业统计导出")
    @GetMapping("/getStaffPkgInfoLogDayNoteExport")
    void getStaffPkgInfoLogDayNote(GetStaffPkgInfoLogDayNoteVO vo, HttpServletResponse response) {
        businessService.getStaffPkgInfoLogDayNoteExport(vo, response);
    }

    @ApiOperation("员工作业统计汇总")
    @GetMapping("/getStaffPkgInfoLogDayNoteSummary")
    R<PageDataDTO<GetStaffPkgInfoLogDayNoteSummaryDTO>> getStaffPkgInfoLogDayNoteSummary(GetStaffPkgInfoLogDayNoteSummaryVO vo) {
        return R.ok(businessService.getStaffPkgInfoLogDayNoteSummary(vo, Boolean.TRUE));
    }

    @ApiOperation("员工作业统计汇总导出")
    @GetMapping("/getStaffPkgInfoLogDayNoteSummaryExport")
    void getStaffPkgInfoLogDayNoteSummaryExport(GetStaffPkgInfoLogDayNoteSummaryVO vo, HttpServletResponse response) {
        businessService.getStaffPkgInfoLogDayNoteSummaryExport(vo, response);
    }

    @ApiOperation("WMS库存统计")
    @GetMapping("/accountInto")
    R<PageDataDTO<AccountIntoDTO>> accountInto(AccountIntoVO vo) {
        return R.ok(businessService.accountInto(vo, Boolean.TRUE));
    }

    @ApiOperation("WMS库存统计导出")
    @GetMapping("/accountIntoExport")
    void accountIntoExport(AccountIntoVO vo, HttpServletResponse response) {
        businessService.accountIntoExport(vo, response);
    }

    @ApiOperation("工单备料进度")
    @GetMapping("/workOrderStockProgress")
    R<PageDataDTO<WorkOrderStockProgressDTO>> workOrderStockProgress(WorkOrderStockProgressVO vo){
        return R.ok(businessService.workOrderStockProgress(vo, Boolean.TRUE));
    }

    @ApiOperation("工单备料进度导出")
    @GetMapping("/workOrderStockProgressExport")
    void workOrderStockProgressExport(WorkOrderStockProgressVO vo, HttpServletResponse response){
        businessService.workOrderStockProgressExport(vo, response);
    }

    @ApiOperation("工单备料载具使用清单（不分页）")
    @GetMapping("/workOrderStockVehicle")
    R<PageDataDTO<WorkOrderStockVehicleDTO>> workOrderStockVehicle(@RequestParam(value = "workOrderNo", required = true) String workOrderNo,
                                                                   @RequestParam(value = "orgCode", required = true) String orgCode){
        return R.ok(businessService.workOrderStockVehicle(workOrderNo, orgCode));
    }

    @ApiOperation("获取工单下未完成备料的项")
    @GetMapping("/workOrderDetailNotCompleteItem")
    R<PageDataDTO<WorkOrderDetailNotCompleteItemDTO>> workOrderDetailNotCompleteItem(WorkOrderDetailNotCompleteItemVO vo){
        return R.ok(businessService.workOrderDetailNotCompleteItem(vo, Boolean.TRUE));
    }

    @ApiOperation("获取工单下未完成备料的项")
    @GetMapping("/workOrderDetailNotCompleteItemExport")
    void workOrderDetailNotCompleteItemExport(WorkOrderDetailNotCompleteItemVO vo, HttpServletResponse response){
        businessService.workOrderDetailNotCompleteItemExport(vo, response);
    }

    @ApiOperation("工單检料进度")
    @GetMapping("/workOrderPickProgress")
    R<PageDataDTO<WorkOrderPickProgressDTO>> workOrderPickProgress(WorkOrderPickProgressVO vo){
        return R.ok(businessService.workOrderPickProgress(vo, Boolean.TRUE));
    }

    @ApiOperation("工單检料进度导出")
    @GetMapping("/workOrderPickProgressExport")
    void workOrderPickProgressExport(WorkOrderPickProgressVO vo, HttpServletResponse response){
        businessService.workOrderPickProgressExport(vo, response);
    }

    @ApiOperation("工单备料载具使用清单（不分页）")
    @GetMapping("/workOrderPickVehicle")
    R<PageDataDTO<WorkOrderPickVehicleDTO>> workOrderPickVehicle(@RequestParam(value = "workOrderNo", required = true) String workOrderNo,
                                                                 @RequestParam(value = "orgCode", required = true) String orgCode){
        return R.ok(businessService.workOrderPickVehicle(workOrderNo, orgCode));
    }

    @ApiOperation("获取工单下未完成檢料的项")
    @GetMapping("/workOrderDetailPickNotCompleteItem")
    R<PageDataDTO<WorkOrderDetailPickNotCompleteItemDTO>> workOrderDetailPickNotCompleteItem(WorkOrderDetailPickNotCompleteItemVO vo){
        return R.ok(businessService.workOrderDetailPickNotCompleteItem(vo, Boolean.TRUE));
    }

    @ApiOperation("获取工单下未完成檢料的项导出")
    @GetMapping("/workOrderDetailPickNotCompleteItemExport")
    void workOrderDetailPickNotCompleteItemExport(WorkOrderDetailPickNotCompleteItemVO vo, HttpServletResponse response){
        businessService.workOrderDetailPickNotCompleteItemExport(vo, response);
    }

    @ApiOperation("首套料备料进度")
    @GetMapping("/getFirstStockProcess")
    R<PageDataDTO<GetFirstStockProcessDTO>> getFirstStockProcess(GetFirstStockProcessVO vo){
        return R.ok(businessService.getFirstStockProcess(vo, Boolean.TRUE));
    }

    @ApiOperation("首套料备料进度导出")
    @GetMapping("/getFirstStockProcessExport")
    void getFirstStockProcessExport(GetFirstStockProcessVO vo, HttpServletResponse response){
        businessService.getFirstStockProcessExport(vo, response);
    }

    @ApiOperation("首套料缺料")
    @GetMapping("/getFirstNotStock")
    R<PageDataDTO<GetFirstNotStockDTO>> getFirstNotStock(GetFirstNotStockVO vo){
        return R.ok(businessService.getFirstNotStock(vo, Boolean.TRUE));
    }

    @ApiOperation("首套料缺料导出")
    @GetMapping("/getFirstNotStockExport")
    void getFirstNotStockExport(GetFirstNotStockVO vo, HttpServletResponse response){
        businessService.getFirstNotStockExport(vo, response);
    }

    @ApiOperation("非SMT缺料庫存統計")
    @GetMapping("/workOrderDetailLack")
    R<PageDataDTO<WorkOrderDetailLackDTO>> workOrderDetailLack(WorkOrderDetailLackVO vo) {
        return R.ok(businessService.workOrderDetailLack(vo, Boolean.TRUE));
    }

    @ApiOperation("非SMT缺料庫存統計导出")
    @GetMapping("/workOrderDetailLackExport")
    void workOrderDetailLackExport(WorkOrderDetailLackVO vo, HttpServletResponse response) {
        businessService.workOrderDetailLackExport(vo, response);
    }

    @ApiOperation("工单计算超耗")
    @PostMapping("/getcWorkOrderConsumption")
    R<PageDataDTO<GetcWorkOrderConsumptionDTO>> getcWorkOrderConsumption(@RequestBody GetcWorkOrderConsumptionVO vo){
        return R.ok(businessService.getcWorkOrderConsumption(vo));
    }

    @ApiOperation("工单计算超耗导出")
    @PostMapping("/getcWorkOrderConsumptionExport")
    void getcWorkOrderConsumptionExport(@RequestBody GetcWorkOrderConsumptionExportVO vo, HttpServletResponse response){
        businessService.getcWorkOrderConsumptionExport(vo, response);
    }

    @ApiOperation("工单成本损耗")
    @GetMapping("/getWorkOrderCostLoss")
    R<PageDataDTO<GetWorkOrderCostLossDTO>> getWorkOrderCostLoss(GetWorkOrderCostLossVO vo){
        return R.ok(businessService.getWorkOrderCostLoss(vo, Boolean.TRUE));
    }

    @ApiOperation("工单成本损耗导出")
    @GetMapping("/getWorkOrderCostLossExport")
    void getWorkOrderCostLossExport(GetWorkOrderCostLossVO vo, HttpServletResponse response){
        businessService.getWorkOrderCostLossExport(vo, response);
    }

    @ApiOperation("出货称重记录")
    @GetMapping("/getShipWeigh")
    R<PageDataDTO<GetShipWeighDTO>> getShipWeigh(GetShipWeighVO vo){
        return R.ok(businessService.getShipWeigh(vo, Boolean.TRUE));
    }

    @ApiOperation("出货称重记录导出")
    @GetMapping("/getShipWeighExport")
    void getShipWeighExport(GetShipWeighVO vo, HttpServletResponse response){
        businessService.getShipWeighExport(vo, response);
    }

    @ApiOperation("檢料缺料（byWorkOrderDetail 算detail pickQty）")
    @GetMapping("/getPickMaterialShortageListByDetail")
    public R<PageDataDTO<GetPickMaterialShortageListByDetailDTO>> getPickMaterialShortageListByDetail(GetPickMaterialShortageListByDetailVO vo){
        return R.ok(businessService.getPickMaterialShortageListByDetail(vo, Boolean.TRUE));
    }

    @ApiOperation("檢料缺料（byWorkOrderDetail 算detail pickQty）导出")
    @GetMapping("/getPickMaterialShortageListByDetailExport")
    public void getPickMaterialShortageListByDetailExport(GetPickMaterialShortageListByDetailVO vo, HttpServletResponse response){
        businessService.getPickMaterialShortageListByDetailExport(vo, response);
    }

    @ApiOperation("检料缺料（byBomFeeder）分料")
    @GetMapping("/getPickMaterialShortageList")
    public R<PageDataDTO<GetPickMaterialShortageListDTO>> getPickMaterialShortageList(GetPickMaterialShortageListVO vo) {
        return R.ok(businessService.getPickMaterialShortageList(vo, Boolean.TRUE));
    }

    @ApiOperation("检料缺料（byBomFeeder）分料导出")
    @GetMapping("/getPickMaterialShortageListExport")
    public void getPickMaterialShortageListExport(GetPickMaterialShortageListVO vo, HttpServletResponse response) {
        businessService.getPickMaterialShortageListExport(vo, response);
    }

    @ApiOperation("工单检料缺料（byWorkOrderDetail, 算捡料量(沒有到prepare_log的量)）新")
    @GetMapping("/getPickMaterialShortageListByPickLog")
    public R<PageDataDTO<GetPickMaterialShortageListByPickLogDTO>> getPickMaterialShortageListByPickLog(GetPickMaterialShortageListByPickLogVO vo){
        return R.ok(businessService.getPickMaterialShortageListByPickLog(vo, Boolean.TRUE));
    }

    @ApiOperation("工单检料缺料（byWorkOrderDetail, 算捡料量(沒有到prepare_log的量)）新导出")
    @GetMapping("/getPickMaterialShortageListByPickLogExport")
    public void getPickMaterialShortageListByPickLogExport(GetPickMaterialShortageListByPickLogVO vo, HttpServletResponse response){
        businessService.getPickMaterialShortageListByPickLogExport(vo, response);
    }

    @ApiOperation("整体工单备料进度")
    @GetMapping("/getGeneralWoStockProgress")
    public R<PageDataDTO<GetGeneralWoStockProgressDTO>> getGeneralWoStockProgress(GetGeneralWoStockProgressVO vo){
        return R.ok(businessService.getGeneralWoStockProgress(vo, true));
    }

    @ApiOperation("整体工单备料进度導出")
    @GetMapping("/getGeneralWoStockProgressExport")
    void getGeneralWoStockProgressExport(GetGeneralWoStockProgressVO vo, HttpServletResponse response){
        businessService.getGeneralWoStockProgressExport(vo, response);
    }

    @ApiOperation("制造商信息")
    @GetMapping("/getMaterialMfg")
    public R<PageDataDTO<GetMaterialMfgDTO>> getMaterialMfg(GetMaterialMfgVO vo){
        return R.ok(businessService.getMaterialMfg(vo, Boolean.TRUE));
    }

    @ApiOperation("制造商信息导出")
    @GetMapping("/getMaterialMfgExport")
    public void getMaterialMfgExport(GetMaterialMfgVO vo, HttpServletResponse response){
        businessService.getMaterialMfgExport(vo, response);
    }

    @ApiOperation(value = "修改制造商信息")
    @PostMapping("/updateMfgInfo")
    public R updateMfgInfo(@RequestBody UpdateMfgInfoVO vo){
        businessService.updateMfgInfo(vo);
        return R.ok();
    }

    @ApiOperation("工单处理时间")
    @GetMapping("/getWorkOperateDate")
    public R<PageDataDTO<GetWorkOperateDateDTO>> getWorkOperateDate(GetWorkOperateDateVO vo){
        return R.ok(businessService.getWorkOperateDate(vo, Boolean.TRUE));
    }

    @ApiOperation("工单处理时间導出")
    @GetMapping("/getWorkOperateDateExport")
    void getWorkOperateDateExport(GetWorkOperateDateVO vo, HttpServletResponse response){
        businessService.getWorkOperateDateExport(vo, response);
    }

    @ApiOperation("工单PKG处理时间")
    @GetMapping("/getWorkPkgOperateDate")
    public R<PageDataDTO<GetWorkPkgOperateDateDTO>> getWorkPkgOperateDate(GetWorkPkgOperateDateVO vo){
        return R.ok(businessService.getWorkPkgOperateDate(vo, Boolean.TRUE));
    }

    @ApiOperation("工单PKG处理时间導出")
    @GetMapping("/getWorkPkgOperateDateExport")
    void getWorkPkgOperateDateExport(GetWorkPkgOperateDateVO vo, HttpServletResponse response){
        businessService.getWorkPkgOperateDateExport(vo, response);
    }

    @ApiOperation("同步准时达库存")
    @GetMapping("/downloadJusdaInventory")
    R downloadJusdaInventory(DownloadJusdaInventoryVO vo){
        businessService.downloadJusdaInventory(vo);
        return R.ok();
    }

    @ApiOperation("新载具使用情况")
    @GetMapping("/vehicleReportList")
    R<PageDataDTO<VehicleReportListDTO>> vehicleReportList(VehicleReportListVO vo){
        return R.ok(businessService.vehicleReportList(vo, Boolean.TRUE));
    }

    @ApiOperation("新载具使用情况导出")
    @GetMapping("/vehicleReportListExport")
    void vehicleReportListExport(VehicleReportListVO vo, HttpServletResponse response){
        businessService.vehicleReportListExport(vo, response);
    }

    @ApiOperation("储位使用详情")
    @GetMapping("/vehicleReportPkgList")
    R<PageDataDTO<VehicleReportPkgListDTO>> vehicleReportPkgList(VehicleReportPkgListVO vo){
        return R.ok(businessService.vehicleReportPkgList(vo, Boolean.TRUE));
    }

    @ApiOperation("储位使用详情导出")
    @GetMapping("/vehicleReportPkgListExport")
    void vehicleReportPkgListExport(VehicleReportPkgListVO vo, HttpServletResponse response){
        businessService.vehicleReportPkgListExport(vo, response);
    }

    @ApiOperation("载具使用超期报表")
    @GetMapping("/getVehicleUsageExpired")
    R<PageDataDTO<GetVehicleUsageExpiredDTO>> getVehicleUsageExpired(GetVehicleUsageExpiredVO vo){
        return R.ok(businessService.getVehicleUsageExpired(vo, Boolean.TRUE));
    }

    @ApiOperation("载具使用超期报表导出")
    @GetMapping("/getVehicleUsageExpiredExport")
    void getVehicleUsageExpiredExport(GetVehicleUsageExpiredVO vo, HttpServletResponse response){
        businessService.getVehicleUsageExpiredExport(vo, response);
    }

    @ApiOperation("盘点机盘点库存明细分页查询")
    @PostMapping("/machineReturnLogList")
    public R<PageDataDTO<WmsSpecialUserMachineReturnLogDTO>> selectMachineReturnLogPage(
            @RequestBody WmsSpecialUserMachineReturnLogQueryVO queryVO) {
        return R.ok(wmsSpecialUserMachineReturnLogService.selectMachineReturnLogPage(queryVO));
    }

    @ApiOperation("盘点机盘点库存明细导出")
    @PostMapping("/exportMachineReturnLog")
    public R<Void> exportMachineReturnLog(HttpServletResponse response,
                                    @RequestBody WmsSpecialUserMachineReturnLogQueryVO queryVO) {
        wmsSpecialUserMachineReturnLogService.exportMachineReturnLog(response, queryVO);
        return R.ok();
    }

    @ApiOperation("成品库存汇总by料号")
    @GetMapping("/calcProductByPartNo")
    public R<PageDataDTO<CalcProductByPartNoDTO>> calcProductByPartNo(CalcProductByPartNoVO vo){
        return R.ok(businessService.calcProductByPartNo(vo, Boolean.TRUE));
    }

    @ApiOperation("成品库存汇总by料号导出")
    @GetMapping("/calcProductByPartNoExport")
    public void calcProductByPartNoExport(CalcProductByPartNoVO vo, HttpServletResponse response){
        businessService.calcProductByPartNoExport(vo, response);
    }

    @ApiOperation("成品库存汇总by箱号")
    @GetMapping("/calcProductByCarton")
    public R<PageDataDTO<CalcProductByCartonDTO>> calcProductByCarton(CalcProductByCartonVO vo){
        return R.ok(businessService.calcProductByCarton(vo, Boolean.TRUE));
    }

    @ApiOperation("库存库龄呈现报表")
    @GetMapping("/inventoryAgeReport")
    public R<PageDataDTO<InventoryAgeReportDTO>> inventoryAgeReport(InventoryAgeReportVO vo){
        return R.ok(businessService.inventoryAgeReport(vo, Boolean.TRUE));
    }

    @ApiOperation("库存库龄呈现报表导出")
    @GetMapping("/inventoryAgeReportExport")
    public void inventoryAgeReportExport(InventoryAgeReportVO vo, HttpServletResponse response){
        businessService.inventoryAgeReportExport(vo, response);
    }

    @ApiOperation("库存库龄呈现汇总报表")
    @PostMapping("/inventoryAgeSummaryReport")
    public R<List<InventoryAgeSummaryReportDTO>> inventoryAgeSummaryReport(@RequestBody InventoryAgeSummaryReportVO vo){
        return R.ok(businessService.inventoryAgeSummaryReport(vo, Boolean.TRUE, Boolean.FALSE));
    }

    @ApiOperation("库存库龄呈现汇总报表导出")
    @PostMapping("/inventoryAgeSummaryReportExport")
    public void inventoryAgeSummaryReportExport(@RequestBody InventoryAgeSummaryReportVO vo, HttpServletResponse response){
        businessService.inventoryAgeSummaryReportExport(vo, response);
    }

    @ApiOperation("报废品库存报表")
    @PostMapping("/getScrapMaterial")
    public R<PageDataDTO<ScrapMaterialDTO>> getScrapMaterial(@RequestBody ScrapMaterialQueryVO vo) {
        return R.ok(businessService.getScrapMaterial(vo));
    }

    @ApiOperation("报废品库存报表导出")
    @PostMapping("/exportScrapMaterial")
    public void exportScrapMaterial(@RequestBody ScrapMaterialQueryVO scrapMaterialQueryVO, HttpServletResponse response) {
        businessService.exportScrapMaterial(scrapMaterialQueryVO, response);
    }
    
    @ApiOperation("库存库龄呈现汇总报表抛GSCM")
    @PostMapping("/inventoryAgeSummaryToGSCM")
    public R<List<InventoryAgeSummaryReportDTO>> inventoryAgeSummaryToGSCM(@RequestBody InventoryAgeSummaryToGSCMVO vo){
        businessService.inventoryAgeSummaryToGSCM(vo);
        return R.ok();
    }

    @ApiOperation("生成客户分摊面积")
    @GetMapping("/generateCustomerAreaUsageInfo")
    R generateCustomerAreaUsageInfo(String orgCode, String year, String month) {
        businessService.generateCustomerAreaUsageInfo(orgCode, year, month);
        return R.ok();
    }

    @ApiOperation("查询客户分摊面积")
    @GetMapping("/getCustomerAreaUsageInfo")
    R<ExcelMergeCommonDTO> getCustomerAreaUsageInfo(String orgCode, String logVersion) {
        return R.ok(businessService.getCustomerAreaUsageInfo(orgCode, logVersion));
    }

    @ApiOperation("导出客户分摊面积")
    @GetMapping("/exportCustomerAreaUsageInfo")
    void exportCustomerAreaUsageInfo(String orgCode, String logVersion, HttpServletResponse response) {
        businessService.exportCustomerAreaUsageInfo(orgCode, logVersion, response);
    }
}
