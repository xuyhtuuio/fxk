package com.maxnerva.cloudmes.controller.assyprepare;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.vo.wo.LockMaterialVO;
import com.maxnerva.cloudmes.service.assyprepare.ILockMaterialService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @ClassName AssyLockMaterialController
 * @Description 机构段工单锁料管理
 * @Author Likun
 * @Date 2024/5/11
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "机构段工单锁料管理")
@Slf4j
@RestController
@RequestMapping("/assyWoLockMaterial")
public class AssyWoLockMaterialController {

    @Resource
    private ILockMaterialService lockMaterialService;

    @ApiOperation("锁料")
    @PostMapping("/lock")
    public R<Void> lockMaterial(@RequestBody LockMaterialVO lockMaterialVO){
        return lockMaterialService.lockMaterial(lockMaterialVO);
    }

    @ApiOperation("解锁")
    @PostMapping("/unLock")
    public R<Void> unLock(@RequestBody LockMaterialVO lockMaterialVO){
        lockMaterialService.unLockMaterial(lockMaterialVO.getWorkOrderNo(),lockMaterialVO.getOrgCode());
        return R.ok();
    }

    @ApiOperation("解锁-By pkg")
    @PostMapping("/unLockByPkg")
    public R<Void> unLockByPkg(@RequestBody LockMaterialVO lockMaterialVO) {
        lockMaterialService.unLockMaterialByPkg(lockMaterialVO);
        return R.ok();
    }
}
