package com.maxnerva.cloudmes.controller.wo;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.vo.wo.VnCkdConfirmReceiveVO;
import com.maxnerva.cloudmes.service.wo.IVnCkdService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @author MFQ
 * @date 2023/10/19 下午 06:00
 */
@Api(tags = "vnckd")
@Slf4j
@RestController
@RequestMapping("/vnckd")
public class VNCkdController {

    @Resource
    private IVnCkdService vnCkdService;

    @ApiOperation("确认收货")
    @PostMapping("/ckdConfirmReceive")
    public R<Void> ckdConfirmReceive(@RequestBody VnCkdConfirmReceiveVO vnCkdConfirmReceiveVO) {
        vnCkdService.ckdConfirmReceive(vnCkdConfirmReceiveVO);
        return R.ok();
    }

}