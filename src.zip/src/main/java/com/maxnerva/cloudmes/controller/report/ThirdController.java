package com.maxnerva.cloudmes.controller.report;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.report.GetFailPostToSfcPrepareLogDTO;
import com.maxnerva.cloudmes.models.dto.report.GetPkgPrintLogDTO;
import com.maxnerva.cloudmes.models.dto.report.MovePkgInWorkOrderDTO;
import com.maxnerva.cloudmes.models.dto.report.PrintWoVehicleDTO;
import com.maxnerva.cloudmes.models.vo.ExcelImportVO;
import com.maxnerva.cloudmes.models.vo.report.*;
import com.maxnerva.cloudmes.service.report.IThirdService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@Api(tags = "第三方报表")
@Slf4j
@RestController
@RequestMapping("/thirdReport")
public class ThirdController {
    @Autowired
    IThirdService thirdService;

    @ApiOperation("打印工单发料载具条码")
    @PostMapping("/printWoVehicle")
    R<PrintWoVehicleDTO> printWoVehicle(@RequestBody PrintWoVehicleVO vo){
        return R.ok(thirdService.printWoVehicle(vo));
    }

    @ApiOperation("工单PKG移转")
    @PostMapping("/movePkgInWorkOrder")
    R<MovePkgInWorkOrderDTO> movePkgInWorkOrder(@RequestBody MovePkgInWorkOrderVO vo){
        return R.ok(thirdService.movePkgInWorkOrder(vo));
    }

    @ApiOperation("特采解锁，修改到期日")
    @PostMapping("/updatePkgInfoEndDate")
    R updatePkgInfoEndDate(@RequestBody UpdatePkgInfoEndDateVO vo){
        thirdService.updatePkgInfoEndDate(vo);
        return R.ok();
    }

    @ApiOperation("批量特采解锁，修改到期日")
    @PostMapping("/updateMultiPkgInfoEndDate")
    R updateMultiPkgInfoEndDate(ExcelImportVO vo){
        thirdService.updateMultiPkgInfoEndDate(vo);
        return R.ok();
    }

    @ApiOperation("修改PKG原始datecode")
    @PostMapping("/updatePkgInfoOriginDateCode")
    R updatePkgInfoDateCodeFormat(@RequestBody UpdatePkgInfoDateCodeFormatVO vo) {
        thirdService.updatePkgInfoDateCodeFormat(vo);
        return R.ok();
    }

    @ApiOperation("修改PKG的lotCode")
    @PostMapping("/updatePkgInfoLotCode")
    R updatePkgInfoLotCode(@RequestBody UpdatePkgInfoLotCodeVO vo){
        thirdService.updatePkgInfoLotCode(vo);
        return R.ok();
    }

    @ApiOperation("修改工单重down状态")
    @PostMapping("/reDownWorkOrderHeader")
    R reDownWorkOrderHeader(@RequestBody ReDownWorkOrderHeaderVO vo){
        R r = R.ok();
        r.setMsg(thirdService.reDownWorkOrderHeader(vo));
        return r;
    }

    @ApiOperation("修改上料表重down状态")
    @PostMapping("/reDownBomFeeder")
    R reDownBomFeeder(@RequestBody ReDownWorkOrderHeaderVO vo){
        R r = R.ok();
        r.setMsg(thirdService.reDownBomFeeder(vo));
        return r;
    }

    @ApiOperation("修改工单header的mes_data_source")
    @PostMapping("/updateMesDataSource")
    R updateMesDataSource(@RequestBody UpdateMesDataSourceVO vo){
        thirdService.updateMesDataSource(vo);
        return R.ok();
    }

    @ApiOperation("获取抛转SFC失败的发料记录")
    @GetMapping("/getFailPostToSfcPrepareLog")
    R<List<GetFailPostToSfcPrepareLogDTO>> getFailPostToSfcPrepareLog(GetFailPostToSfcPrepareLogVO vo){
        return R.ok(thirdService.getFailPostToSfcPrepareLog(vo));
    }

    @ApiOperation("修改发料记录抛转SFC状态")
    @PostMapping("/putFailPostToSfcPrepareLog")
    R putFailPostToSfcPrepareLog(@RequestBody PutFailPostToSfcPrepareLogVO vo){
        thirdService.putFailPostToSfcPrepareLog(vo);
        return R.ok();
    }


    @ApiOperation("打印log查询")
    @GetMapping("/getPkgPrintLog")
    R<PageDataDTO<GetPkgPrintLogDTO>> getPkgPrintLog(GetPkgPrintLogVO vo) {
        return R.ok(thirdService.getPkgPrintLog(vo, Boolean.TRUE));
    }

    @ApiOperation("打印log查询导出")
    @GetMapping("/getPkgPrintLogExport")
    public void exportPkgPrintLog(HttpServletResponse response, GetPkgPrintLogVO vo){
        thirdService.getPkgPrintLogExport(vo, response);
    }

    @ApiOperation("手动抛SFC")
    @PostMapping("/postingSfcPkgInfo")
    R postingSfcPkgInfo(@RequestBody PostingSfcPkgInfoVO vo) {
        thirdService.postingSfcPkgInfo(vo);
        return R.ok();
    }

    @ApiOperation("手動鎖料")
    @PostMapping("/updatePkgLockManual")
    R<Void> updatePkgLockManual(@RequestBody UpdatePkgLockManualVO vo){
        thirdService.updatePkgLockManual(vo);
        return R.ok();
    }

    @ApiOperation("修改Recoating")
    @PostMapping("/updateRecoating")
    public R updateRecoating(@RequestBody UpdateRecoatingVO vo){
        thirdService.updateRecoating(vo);
        return R.ok();
    }

    @ApiOperation("修改工单发料仓码")
    @PostMapping("/updateWorkOrderDetailWarehouse")
    public R updateWorkOrderDetailWarehouse(@RequestBody UpdateWorkOrderDetailWarehouseVO vo){
        thirdService.updateWorkOrderDetailWarehouse(vo);
        return R.ok();
    }

    @ApiOperation("修改厂商名")
    @PostMapping("/updatePkgInfoMfgName")
    public R updatePkgInfoMfgName(@RequestBody UpdatePkgInfoMfgNameVO vo){
        thirdService.updatePkgInfoMfgName(vo);
        return R.ok();
    }

    @ApiOperation("修改仓码")
    @PostMapping("/updateWarehouse")
    public R updateWarehouse(@RequestBody UpdateWarehouseVO vo){
        thirdService.updateWarehouse(vo);
        return R.ok();
    }

    @ApiOperation("成品出货修改料号")
    @PostMapping("/updateProductShipPartNo")
    public R updateProductShipPartNo(@RequestBody UpdateProductShipPartNoVO vo){
        thirdService.updateProductShipPartNo(vo);
        return R.ok();
    }

    @ApiOperation("修改条码信息 lot, dateCode, 厂商名")
    @PostMapping("/updateBarcodeInfo")
    public R updateBarcodeInfo(@RequestBody UpdateBarcodeInfoVO vo){
        thirdService.updateBarcodeInfo(vo);
        return R.ok();
    }

    @ApiOperation("工单结案")
    @PostMapping("/closeWoWmsStatus")
    public R closeWoWmsStatus(@RequestBody CloseWoWmsStatusVO vo){
        thirdService.closeWoWmsStatus(vo);
        return R.ok();
    }

    @ApiOperation("手动同步工单")
    @PostMapping("/syncSapWorkOrderHeader")
    public R syncSapWorkOrderHeader(@RequestBody SyncSapWorkOrderHeaderVO vo){
        thirdService.syncSapWorkOrderHeader(vo);
        return R.ok();
    }

    @ApiOperation("同步到期日by有效期")
    @PostMapping("/syncEndDateByValidPeriod")
    public R syncEndDateByValidPeriod(@RequestBody SyncEndDateByValidPeriodVO vo){
        thirdService.syncEndDateByValidPeriod(vo);
        return R.ok();
    }

    @ApiOperation("工单试算缺料急料明细抛转QMS")
    @PostMapping("/urgentWoShortageToQms")
    R urgentWoShortageToQms(@RequestBody UrgentWoShortageToQmsVO vo) {
        thirdService.urgentWoShortageToQms(vo);
        return R.ok();
    }

}
