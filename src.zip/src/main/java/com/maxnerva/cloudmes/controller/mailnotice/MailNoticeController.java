package com.maxnerva.cloudmes.controller.mailnotice;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.service.mailnotice.IMailNoticeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(tags = "邮件提醒")
@Slf4j
@RestController
@RequestMapping("/mailNotice")
public class MailNoticeController {
    @Autowired
    IMailNoticeService reportMailNoticeService;

    @ApiOperation("收货失败邮件通知")
    @GetMapping("/receiveFailSendMail")
    R receiveFailSendMail(String orgCode){
        reportMailNoticeService.receiveFailSendMail(orgCode);
        return R.ok();
    }

    @ApiOperation("准时达收货失败邮件通知")
    @GetMapping("/thirdFailSendMail")
    R thirdFailSendMail(String orgCode){
        reportMailNoticeService.thirdFailSendMail(orgCode);
        return R.ok();
    }

    @ApiOperation("CKD-DN扣账失败邮件通知")
    @GetMapping("/ckdDnTransactionSendMail")
    R ckdDnTransactionSendMail(String orgCode){
        reportMailNoticeService.ckdDnTransactionSendMail(orgCode);
        return R.ok();
    }

    @ApiOperation("成品DN扣账失败明细")
    @GetMapping("/dnTransactionSendMail")
    R dnTransactionSendMail(String orgCode){
        reportMailNoticeService.dnTransactionSendMail(orgCode);
        return R.ok();
    }

    @ApiOperation("DC过期邮件通知")
    @GetMapping("/expireWarninglist")
    R expireWarninglist(String orgCode){
        reportMailNoticeService.expireWarninglist(orgCode);
        return R.ok();
    }

    @ApiOperation("DC即将过期邮件通知")
    @GetMapping("/willExpireWarninglist")
    R willExpireWarninglist(String orgCode, Integer lastDay){
        reportMailNoticeService.willExpireWarninglist(orgCode, lastDay);
        return R.ok();
    }

    @ApiOperation("抛QMS失败邮件通知")
    @GetMapping("/docReceivePostQmsFail")
    R docReceivePostQmsFail(String orgCode, String plantCode) {
        reportMailNoticeService.docReceivePostQmsFail(orgCode, plantCode);
        return R.ok();
    }

    @ApiOperation("JIT未采集邮件通知")
    @GetMapping("/jitNotCollectSendMail")
    R jitNotCollectSendMail(String orgCode, String plantCode) {
        reportMailNoticeService.jitNotCollectSendMail(orgCode, plantCode);
        return R.ok();
    }

}
