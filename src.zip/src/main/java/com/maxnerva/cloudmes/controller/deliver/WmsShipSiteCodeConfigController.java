package com.maxnerva.cloudmes.controller.deliver;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.entity.deliver.WmsShipSiteCodeConfig;
import com.maxnerva.cloudmes.models.dto.deliver.WmsShipSiteCodeConfigDTO;
import com.maxnerva.cloudmes.models.vo.deliver.ShipSiteCodeConfigPageQueryVO;
import com.maxnerva.cloudmes.models.vo.deliver.WmsShipSiteCodeConfigSaveVO;
import com.maxnerva.cloudmes.service.deliver.IWmsShipSiteCodeConfigService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * 成品出货 出货地配置(WmsShipSiteCodeConfig)表控制层
 *
 * @author hgx
 * @since 2024-02-21 16:28:47
 */
@Api(tags = "出货地址配置")
@RestController
@RequestMapping("/siteCodeConfig")
public class WmsShipSiteCodeConfigController {

    @Resource
    private IWmsShipSiteCodeConfigService wmsShipSiteCodeConfigService;

    @ApiOperation("出货地址信息列表查询")
    @PostMapping("/list")
    public R<PageDataDTO<WmsShipSiteCodeConfigDTO>> selectPage(@RequestBody ShipSiteCodeConfigPageQueryVO pageQueryVO) {
        return R.ok(wmsShipSiteCodeConfigService.selectPage(pageQueryVO));
    }

    @ApiOperation("新增出货地配置")
    @PostMapping("/add")
    public R<Void> add(@RequestBody WmsShipSiteCodeConfigSaveVO saveVO) {
        wmsShipSiteCodeConfigService.add(saveVO);
        return R.ok();
    }

    @ApiOperation("新增查询客户选项")
    @GetMapping("/selectCustomer")
    public R<List<String>> selectCustomer(@RequestParam("orgCode") String orgCode) {
        return R.ok(wmsShipSiteCodeConfigService.selectCustomer(orgCode));
    }

    @ApiOperation("新增查询国家代码选项")
    @GetMapping("/selectCountryCode")
    public R<List<String>> selectCountryCode() {
        return R.ok(wmsShipSiteCodeConfigService.selectCountryCode());
    }

    @ApiOperation("查询编辑信息")
    @GetMapping("/selectEditInfo")
    public R<WmsShipSiteCodeConfig> selectEditInfo(@RequestParam("id") Integer id) {
        return R.ok(wmsShipSiteCodeConfigService.selectEditInfo(id));
    }

    @ApiOperation("编辑出货地配置")
    @PostMapping("/edit")
    public R<Void> edit(@RequestBody WmsShipSiteCodeConfigSaveVO saveVO) {
        wmsShipSiteCodeConfigService.edit(saveVO);
        return R.ok();
    }

    @ApiOperation("删除出货地配置")
    @PostMapping("/deleteByIds")
    public R<Void> deleteByIds(@RequestBody List<Integer> idList) {
        wmsShipSiteCodeConfigService.deleteByIds(idList);
        return R.ok();
    }

    @ApiOperation("导出")
    @PostMapping("/export")
    public R<Void> export(HttpServletResponse response,
                          @RequestBody ShipSiteCodeConfigPageQueryVO vo) {
        wmsShipSiteCodeConfigService.export(response, vo);
        return R.ok();
    }
}