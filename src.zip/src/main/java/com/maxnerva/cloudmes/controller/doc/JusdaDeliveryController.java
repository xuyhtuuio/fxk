package com.maxnerva.cloudmes.controller.doc;

import com.maxnerva.cloudmes.common.enums.ResultCode;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.doc.*;
import com.maxnerva.cloudmes.models.vo.doc.*;
import com.maxnerva.cloudmes.service.doc.IWmsJusdaDeliveryService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Api(tags = "准时达收货管理")
@Slf4j
@RestController
@RequestMapping("/jusdaDelivery")
public class JusdaDeliveryController {

    @Resource
    private IWmsJusdaDeliveryService jusdaDeliveryService;

    @ApiOperation("收货-扫描栈板")
    @GetMapping("/scanPallet")
    public R<JusdaDeliveryReciveDTO> scanPallet(String palletNo) {
        return R.ok(jusdaDeliveryService.scanPallet(palletNo));
    }

    @ApiOperation("扫描栈板确认收货")
    @GetMapping("/scanPalletConfirmReceive")
    public R<Void> scanPalletConfirmReceive(String palletNo) {
        jusdaDeliveryService.scanPalletConfirmReceive(palletNo);
        return R.ok();
    }

    @ApiOperation("异常列表-收货-扫描栈板")
    @GetMapping("/scanPalletAbnormal")
    public R<JusdaDeliveryReciveDTO> scanPalletAbnormal(String palletNo) {
        return R.ok(jusdaDeliveryService.scanPalletAbnormal(palletNo));
    }

    @ApiOperation("扫描栈板确认收货-异常列表")
    @PostMapping("/scanPalletConfirmAbnormalReceive")
    public R<Void> scanPalletConfirmAbnormalReceive(@RequestBody JusdaAbnormalReceiveVO jusdaAbnormalReceiveVO) {
        List<JusdaReceiveVO> jusdaReceiveVOList = jusdaAbnormalReceiveVO.getJusdaReceiveVOList();
        String palletNo = jusdaAbnormalReceiveVO.getPalletNo();
        jusdaDeliveryService.scanPalletConfirmAbnormalReceive(jusdaReceiveVOList,palletNo);
        return R.ok();
    }

    @ApiOperation("上架-扫描栈板")
    @GetMapping("/selectShipId")
    public R<List<JusdaDeliveryDTO>> selectShipId(String palletNo) {
        return R.ok(jusdaDeliveryService.selectShipId(palletNo));
    }

    @ApiOperation("上架-扫描载具带出库位、储位")
    @GetMapping("/scanVehicle")
    public R<Map> scanVehicle(@RequestParam("vehicleCode") String vehicleCode,
                              @RequestParam("orgCode") String orgCode) {
        return R.ok(jusdaDeliveryService.scanVehicle(vehicleCode, orgCode));
    }

    @ApiOperation("上架-提交")
    @PostMapping("/shelveSubmit")
    public R<HashMap<String, Object>> shelveSubmit(@RequestBody JusdaShelveSubmitVO shelveSubmitVO) {
        return R.ok(jusdaDeliveryService.shelveSubmit(shelveSubmitVO));
    }

    @ApiOperation("查询列表")
    @GetMapping("/list")
    public R<PageDataDTO<JusdaReceiptDTO>> list(JusdaSelectVo jusdaSelectVo) {
        return R.ok(jusdaDeliveryService.selectList(jusdaSelectVo));
    }

    @ApiOperation("待收货列表")
    @GetMapping("/toBeReceivedlist")
    public R<PageDataDTO<JusdaToBeReceiptPalletDTO>> toBeReceivedlist(JusdaNoShelfSelectVo jusdaSelectVo) {
        return R.ok(jusdaDeliveryService.toBeReceivedlist(jusdaSelectVo));
    }

    @ApiOperation("收货详情")
    @GetMapping("/receiptPallet")
    public R<PageDataDTO<JusdaReceiptPalletDTO>> receiptPallet(Integer receiptId, Integer pageIndex, Integer pageSize) {
        return R.ok(jusdaDeliveryService.selectPalletList(receiptId, pageIndex, pageSize));
    }

    @ApiOperation("上架详情")
    @GetMapping("/shelfDetail")
    public R<PageDataDTO<JusdaShelfDTO>> shelfDetail(Integer receiptId, Integer pageIndex, Integer pageSize) {
        return R.ok(jusdaDeliveryService.shelfDetail(receiptId, pageIndex, pageSize));
    }

    @ApiOperation("绑定库位")
    @PostMapping("/bindingLocation")
    public R<JusdaPalletBindLocationDTO> bindingLocation(@RequestBody JusdaPalletBindLocationVO jusdaPalletBindLocationVO) {
        return R.ok(jusdaDeliveryService.bindingLocation(jusdaPalletBindLocationVO));
    }

    @ApiOperation("查询工单线别")
    @GetMapping("/getWoByorderNo")
    public R<JusdaDeliveryWoDTO> getWoByorderNo(@RequestParam("workOrderNo") String workOrderNo,
                                                @RequestParam("orgCode") String orgCode) {
        return R.ok(jusdaDeliveryService.getWoByorderNo(workOrderNo,orgCode));
    }

    @ApiOperation("shipping-label")
    @PostMapping("/printShippingLabel")
    public R<PrintShippingLabelDTO> printShippingLabel(@RequestBody ShippingLabelVO shippingLabelVO) {
        return R.ok(jusdaDeliveryService.printShippingLabel(shippingLabelVO));
    }

    @ApiOperation("EMCshipping-label")
    @PostMapping("/printShippingLabelByPalletNo")
    public R<PrintShippingLabelByPalletNoDTO> printShippingLabelByPalletNo(@RequestBody ShippingLabelVO shippingLabelVO) {
        return R.ok(jusdaDeliveryService.printShippingLabelByPalletNo(shippingLabelVO));
    }

    @ApiOperation("3C标签打印信息")
    @PostMapping("/print3c")
    public R<PrintShipping3CLabelDTO> print3c(@RequestBody Shipping3CLabelVO shipping3CLabelVO) {
        return R.ok(jusdaDeliveryService.print3c(shipping3CLabelVO));
    }

    @ApiOperation("导出")
    @PostMapping("/export")
    public R<Void> export(HttpServletResponse response,
                          @RequestBody JusdaSelectVo vo) {
        jusdaDeliveryService.export(response, vo);
        return R.ok();
    }

    @ApiOperation("上架-扫描栈板料号")
    @GetMapping("/selectShipIdByPartNo")
    public R<List<JusdaDeliveryDTO>> selectShipIdByPartNo(String orgCode, String palletNo, String customerPartNo) {
        return R.ok(jusdaDeliveryService.selectShipIdByPartNo(orgCode, palletNo, customerPartNo));
    }
}
