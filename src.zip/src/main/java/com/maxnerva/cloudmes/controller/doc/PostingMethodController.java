package com.maxnerva.cloudmes.controller.doc;

import com.maxnerva.cloudmes.aspect.FactoryOperationLog;
import com.maxnerva.cloudmes.common.constant.OperationTypeConstant;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.doc.WmsPostingMethodDTO;
import com.maxnerva.cloudmes.models.vo.doc.PostingMethodPageQueryVO;
import com.maxnerva.cloudmes.models.vo.doc.WmsPostingMethodVO;
import com.maxnerva.cloudmes.service.doc.IWmsPostingMethodService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * @ClassName PostingMethodController
 * @Description 过账方法管理
 * @Author Likun
 * @Date 2022/7/27
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "过账方法管理")
@Slf4j
@RestController
@RequestMapping("/postingMethod")
public class PostingMethodController {

    @Resource
    private IWmsPostingMethodService wmsPostingMethodService;

    @ApiOperation("新增过账方法")
    @PostMapping("/add")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "新增过账方法")
    public R<Void> savePostingMethod(@Valid @RequestBody WmsPostingMethodVO postingMethodVO) {
        wmsPostingMethodService.savePostingMethod(postingMethodVO);
        return R.ok();
    }

    @ApiOperation("修改过账方法")
    @PutMapping("/update")
    @FactoryOperationLog(operationType = OperationTypeConstant.MODIFY, description = "修改过账方法")
    public R<Void> updatePostingMethod(@Valid @RequestBody WmsPostingMethodVO postingMethodVO) {
        wmsPostingMethodService.updatePostingMethod(postingMethodVO);
        return R.ok();
    }

    @ApiOperation("删除过账方法")
    @DeleteMapping("/delete")
    @FactoryOperationLog(operationType = OperationTypeConstant.DELETE, description = "删除过账方法")
    public R<Void> deletePostingMethod(@RequestBody List<Integer> idList) {
        wmsPostingMethodService.deletePostingMethodBatch(idList);
        return R.ok();
    }

    @ApiOperation("查询过账方法信息")
    @PostMapping("/list")
    public R<PageDataDTO<WmsPostingMethodDTO>> selectPage(@RequestBody PostingMethodPageQueryVO queryVO) {
        return R.ok(wmsPostingMethodService.selectPage(queryVO));
    }
}
