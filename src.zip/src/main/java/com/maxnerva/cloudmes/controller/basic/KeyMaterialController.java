package com.maxnerva.cloudmes.controller.basic;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.entity.basic.WmsKeyMaterialList;
import com.maxnerva.cloudmes.models.vo.CommonDeleteVO;
import com.maxnerva.cloudmes.models.vo.ExcelImportVO;
import com.maxnerva.cloudmes.models.vo.doc.KeyPartNoPageListVO;
import com.maxnerva.cloudmes.service.basic.IWmsKeyMaterialListService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;

@Api(tags = "关键物料管理")
@Slf4j
@RestController
@RequestMapping("/keyMaterial")
public class KeyMaterialController {

    @Autowired
    IWmsKeyMaterialListService wmsKeyMaterialListService;

    @ApiOperation("分页查询关键物料")
    @GetMapping("/selectPageList")
    R<PageDataDTO<WmsKeyMaterialList>> selectPageList(KeyPartNoPageListVO vo){
        return R.ok(wmsKeyMaterialListService.selectPageList(vo, Boolean.TRUE));
    }

    @ApiOperation("导入关键物料")
    @PostMapping("/import")
    R importDetail(ExcelImportVO vo){
        wmsKeyMaterialListService.importDetail(vo);
        return R.ok();
    }

    @ApiOperation("导出关键物料")
    @GetMapping("/export")
    void export(KeyPartNoPageListVO vo, HttpServletResponse response){
        wmsKeyMaterialListService.export(vo, response);
    }

    @ApiOperation("删除关键物料")
    @PostMapping("/delete")
    R delete(@RequestBody CommonDeleteVO vo){
        wmsKeyMaterialListService.delete(vo);
        return R.ok();
    }
}
