package com.maxnerva.cloudmes.controller.wo;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.excel.util.DataSourceUtil;
import com.maxnerva.cloudmes.models.dto.wo.PkgBurnInfoDTO;
import com.maxnerva.cloudmes.models.dto.wo.WoBurnInfoDTO;
import com.maxnerva.cloudmes.models.vo.kitting.PkgFinishedBurnVO;
import com.maxnerva.cloudmes.service.prepare.IWmsWorkOrderPickLogService;
import com.maxnerva.cloudmes.service.wo.IWmsWorkOrderDetailService;
import com.maxnerva.cloudmes.service.wo.IWmsWorkOrderPrepareLogService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Author hgx
 * @Description
 * @Date 2023/6/6
 */
@Api(tags = "烧录管理")
@Slf4j
@RestController
@RequestMapping("/burn")
public class BurnController {

    @Resource
    private IWmsWorkOrderDetailService wmsWorkOrderDetailService;
    @Resource
    private IWmsWorkOrderPickLogService wmsWorkOrderPickLogService;
    @Resource
    private IWmsWorkOrderPrepareLogService wmsWorkOrderPrepareLogService;


    @ApiOperation("查询工单烧录信息")
    @GetMapping("/getWoBurnInfo")
    public R<List<WoBurnInfoDTO>> getWoBurnInfo(@RequestParam("workOrderNo") String workOrderNo,
                                                @RequestParam("orgCode") String orgCode) {
        return R.ok(wmsWorkOrderDetailService.getWoBurnInfo(orgCode,workOrderNo));
    }

    @ApiOperation("查询PKG烧录信息")
    @GetMapping("/getPkgBurnInfo")
    public R<PkgBurnInfoDTO> getPkgBurnInfo(@RequestParam("pkgId") String pkgId,
                                            @RequestParam("orgCode") String orgCode) {
        return R.ok(wmsWorkOrderPickLogService.getPkgBurnInfo(orgCode, pkgId));
    }

    @ApiOperation("烧录完成回写")
    @PostMapping("/pkgFinishedBurning")
    public R<Void> pkgFinishedBurning(@RequestBody PkgFinishedBurnVO pkgFinishedBurnVO) {
        DataSourceUtil.setWmsDataSource();
        wmsWorkOrderPrepareLogService.pkgFinishedBurning(pkgFinishedBurnVO);
        return R.ok();
    }
}
