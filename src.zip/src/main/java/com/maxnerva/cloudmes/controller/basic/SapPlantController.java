package com.maxnerva.cloudmes.controller.basic;

import com.maxnerva.cloudmes.aspect.FactoryOperationLog;
import com.maxnerva.cloudmes.common.constant.OperationTypeConstant;
import com.maxnerva.cloudmes.common.enums.ResultCode;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.basic.WmsSapPlantDTO;
import com.maxnerva.cloudmes.models.vo.basic.SapPlantPageQueryVO;
import com.maxnerva.cloudmes.models.vo.basic.WmsSapPlantVO;
import com.maxnerva.cloudmes.service.basic.IWmsSapPlantService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * @ClassName SapPlantController
 * @Description 工厂(属性)管理
 * @Author caijun
 * @Date 2022/7/26
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "sap工厂管理")
@Slf4j
@RestController
@RequestMapping("/sapPlant")
public class SapPlantController {

    @Resource
    private IWmsSapPlantService wmsSapPlantService;

    @ApiOperation("新增工厂")
    @PostMapping("/add")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "新增工厂")
    public R<Void> savePlant(@Valid @RequestBody WmsSapPlantVO plantVO) {
        wmsSapPlantService.savePlant(plantVO);
        return R.ok();
    }

    @ApiOperation("修改工厂")
    @PutMapping("/update")
    @FactoryOperationLog(operationType = OperationTypeConstant.MODIFY, description = "修改工厂")
    public R<Void> updatePlant(@Valid @RequestBody WmsSapPlantVO plantVO) {
        wmsSapPlantService.updatePlant(plantVO);
        return R.ok();
    }

    @ApiOperation("删除工厂")
    @DeleteMapping("/delete")
    @FactoryOperationLog(operationType = OperationTypeConstant.DELETE, description = "删除工厂")
    public R<Void> deletePlant(@RequestBody List<Integer> idList) {
        wmsSapPlantService.deletePlantBatch(idList);
        return R.ok();
    }

    @ApiOperation("查询工厂信息")
    @PostMapping("/list")
    public R<PageDataDTO<WmsSapPlantDTO>> selectPage(@RequestBody SapPlantPageQueryVO queryVO) {
        return R.ok(wmsSapPlantService.selectPage(queryVO));
    }

    @ApiOperation("不要分页查询工厂信息")
    @GetMapping("/getSapPlantlist")
    public R<List<WmsSapPlantDTO>> getSapPlantlist(@RequestParam("orgCode") String orgCode) {
        return R.ok(wmsSapPlantService.getSapPlantlist(orgCode));
    }

    @ApiOperation("查询管理方式")
    @GetMapping("/getSectionType")
    public R<String> getSectionType(@RequestParam("orgCode") String orgCode) {
        return R.ok(ResultCode.SUCCESS.getMsg(), wmsSapPlantService.getSegmentType(orgCode));
    }

    @ApiOperation("查询是否有效期管控")
    @GetMapping("/getEnableValidDateControl")
    public R<String> getEnableValidDateControl(@RequestParam("orgCode") String orgCode) {
        return R.ok(ResultCode.SUCCESS.getMsg(), wmsSapPlantService.getEnableValidDateControl(orgCode));
    }

}
