package com.maxnerva.cloudmes.controller.bigdata;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.bigdata.*;
import com.maxnerva.cloudmes.models.vo.bigdata.DellShipInfoQueryVO;
import com.maxnerva.cloudmes.models.vo.bigdata.HpeShipInfoQueryVO;
import com.maxnerva.cloudmes.models.vo.bigdata.SfcDataQueryVO;
import com.maxnerva.cloudmes.service.bigdata.ISfcDataService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName SfcDataController
 * @Description TODO
 * @Author Likun
 * @Date 2024/8/27
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "成品库存管理")
@Slf4j
@RestController
@RequestMapping("/sfcData")
public class SfcDataController {

    @Resource
    private ISfcDataService sfcDataService;
    @ApiOperation("查询856 sfcdata信息")
    @PostMapping("/list")
    public R<List<SfcDataDTO>> selectProductStoreList(
            @RequestBody SfcDataQueryVO queryVO) {
        return R.ok(sfcDataService.selectSfcDataList(queryVO.getDnNo()));
    }

    @ApiOperation("查询microsoft data信息")
    @PostMapping("/microsoftList")
    public R<List<MicrosoftDataDTO>> selectMicrosoftDataList(
            @RequestBody SfcDataQueryVO queryVO) {
        return R.ok(sfcDataService.selectMicrosoftDataList(queryVO.getDnNo()));
    }

    @ApiOperation("查询HPE 出货信息")
    @PostMapping("/hpeLxShipInfoList")
    public R<List<HpeLxShipInfoDTO>> selectHpeLxShipInfoList(
            @RequestBody HpeShipInfoQueryVO queryVO) {
        return R.ok(sfcDataService.selectHpeLxShipInfoList(queryVO));
    }

    @ApiOperation("查询AWS 出货信息")
    @PostMapping("/awsShipInfoList")
    public R<List<AwsShipDTO>> awsShipInfoList(
            @RequestBody HpeShipInfoQueryVO queryVO) {
        return R.ok(sfcDataService.queryAwsShipInfoList(queryVO.getDnNo()));
    }

    @ApiOperation("查询DELL 出货信息")
    @PostMapping("/dellShipInfoList")
    public R<List<DellShipInfoDTO>> selectDellShipInfo(
            @RequestBody DellShipInfoQueryVO queryVO) {
        return R.ok(sfcDataService.selectDellShipInfoList(queryVO));
    }
}
