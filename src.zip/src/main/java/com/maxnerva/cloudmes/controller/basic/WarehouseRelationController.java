package com.maxnerva.cloudmes.controller.basic;

import com.maxnerva.cloudmes.aspect.FactoryOperationLog;
import com.maxnerva.cloudmes.common.constant.OperationTypeConstant;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.basic.WmsWarehouseRelationDTO;
import com.maxnerva.cloudmes.models.vo.basic.WarehouseRelationPageQueryVO;
import com.maxnerva.cloudmes.models.vo.basic.WmsWarehouseRelationVO;
import com.maxnerva.cloudmes.service.basic.IWmsWarehouseRelationService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * @ClassName WarehouseRelationController
 * @Description 仓库对照关系管理
 * @Author Likun
 * @Date 2022/9/26
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "仓库对照关系管理")
@Slf4j
@RestController
@RequestMapping("/warehouseRelation")
public class WarehouseRelationController {

    @Resource
    private IWmsWarehouseRelationService wmsWarehouseRelationService;

    @ApiOperation("新增仓库对照关系")
    @PostMapping("/add")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "新增仓库对照关系")
    public R<Void> save(@Valid @RequestBody WmsWarehouseRelationVO warehouseRelationVO) {
        wmsWarehouseRelationService.save(warehouseRelationVO);
        return R.ok();
    }

    @ApiOperation("修改仓库对照关系")
    @PutMapping("/update")
    @FactoryOperationLog(operationType = OperationTypeConstant.MODIFY, description = "修改仓库对照关系")
    public R<Void> update(@Valid @RequestBody WmsWarehouseRelationVO warehouseRelationVO) {
        wmsWarehouseRelationService.update(warehouseRelationVO);
        return R.ok();
    }

    @ApiOperation("删除仓库对照关系")
    @DeleteMapping("/delete")
    @FactoryOperationLog(operationType = OperationTypeConstant.DELETE, description = "删除仓库对照关系")
    public R<Void> delete(@RequestBody List<Integer> idList) {
        wmsWarehouseRelationService.deleteBatch(idList);
        return R.ok();
    }

    @ApiOperation("查询仓库对照关系信息")
    @PostMapping("/list")
    public R<PageDataDTO<WmsWarehouseRelationDTO>> selectPage(@RequestBody WarehouseRelationPageQueryVO queryVO) {
        return R.ok(wmsWarehouseRelationService.selectPage(queryVO));
    }
}
