package com.maxnerva.cloudmes.controller.sap;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.vo.sap.SapWoDetailVO;
import com.maxnerva.cloudmes.models.vo.sap.SapWoHeaderVO;
import com.maxnerva.cloudmes.service.wo.IWoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @ClassName SaoDownloadController
 * @Description sap下载管理
 * @Author Likun
 * @Date 2022/8/29
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "sap下载管理")
@Slf4j
@RestController
@RequestMapping("/sap")
public class SapDownloadController {

    @Resource
    private IWoService woService;

    @ApiOperation("同步工单header")
    @PostMapping("/syncWoHeader")
    public R<Void> syncWoHeader(@RequestBody SapWoHeaderVO sapWoHeaderVO) {
        woService.syncWoHeader(sapWoHeaderVO);
        return R.ok();
    }

    @ApiOperation("同步工单detail")
    @PostMapping("/syncWoDetail")
    public R<Void> syncWoDetail(@RequestBody SapWoDetailVO sapWoDetailVO) {
        woService.syncWoDetail(sapWoDetailVO);
        return R.ok();
    }
}
