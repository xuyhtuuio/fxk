package com.maxnerva.cloudmes.controller.warehouse;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.warehouse.PkgMergeRecordCompleteDTO;
import com.maxnerva.cloudmes.models.vo.warehouse.PkgMergeFinishVO;
import com.maxnerva.cloudmes.service.warehouse.IWmsPkgMergeRecordService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@Api(tags = "合盘机合盘管理")
@Slf4j
@RestController
@RequestMapping("/merge")
public class WmsPkgMergeRecordController {

    @Resource
    private IWmsPkgMergeRecordService wmsPkgMergeRecordService;

    @ApiOperation("扫码查询合盘记录")
    @GetMapping("/pkgMergeRecordList")
    public R<PageDataDTO<PkgMergeRecordCompleteDTO>> pkgMergeRecordList(@RequestParam("pageIndex") Integer pageIndex,
                                                                        @RequestParam("pageSize") Integer pageSize,
                                                                        @RequestParam("orgCode") String orgCode,
                                                                        @RequestParam(value = "pkgId") String pkgId) {
        return R.ok(wmsPkgMergeRecordService.pkgMergeRecordList(pageIndex, pageSize, orgCode, pkgId));
    }

    @ApiOperation("合盘补偿提交")
    @PostMapping("/pkgMergeFinish")
    public R<Void> pkgMergeFinish(@RequestBody PkgMergeFinishVO pkgMergeFinishVO) {
        wmsPkgMergeRecordService.pkgMergeFinish(pkgMergeFinishVO);
        return R.ok();
    }
}
