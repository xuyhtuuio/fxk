package com.maxnerva.cloudmes.controller.doc;

import cn.hutool.core.io.FileUtil;
import com.maxnerva.cloudmes.aspect.FactoryOperationLog;
import com.maxnerva.cloudmes.common.constant.OperationTypeConstant;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.entity.flownet.FlownetResponse;
import com.maxnerva.cloudmes.enums.WmsMouldResultCode;
import com.maxnerva.cloudmes.models.dto.doc.*;
import com.maxnerva.cloudmes.models.vo.doc.*;
import com.maxnerva.cloudmes.models.vo.warehouse.CostHeaderRemoveShelfVO;
import com.maxnerva.cloudmes.models.vo.warehouse.CostHeaderShelfVO;
import com.maxnerva.cloudmes.models.vo.warehouse.CostRemoveShelfVO;
import com.maxnerva.cloudmes.models.vo.warehouse.CostShelfVO;
import com.maxnerva.cloudmes.service.doc.IWmsCostIssueReturnService;
import com.maxnerva.cloudmes.system.utils.DictLangUtils;
import com.sap.conn.jco.JCoException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

@Api(tags = "费领退管理")
@Slf4j
@RestController
@RequestMapping("/costIssueReturn")
public class CostIssueReturnController {

    @Resource
    private IWmsCostIssueReturnService costIssueReturnService;
    @Resource
    private DictLangUtils dictLangUtils;

    @ApiOperation(value = "查询费领退信息")
    @GetMapping("/list")
    public R<PageDataDTO<WmsCostIssueReturnDto>> selectPage(WmsCostIssueReturnVo pageQueryVO) {
        return R.ok(costIssueReturnService.selectPage(pageQueryVO));
    }

    @ApiOperation(value = "新增费领退信息")
    @PostMapping("/add")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "新增费领退信息")
    public R<Void> saveCost(WmsCostIssueReturnSaveVo saveVo) {
        return R.ok(costIssueReturnService.saveCost(saveVo));
    }

    @ApiOperation(value = "编辑费领退信息")
    @GetMapping("/editInfo")
    @FactoryOperationLog(operationType = OperationTypeConstant.MODIFY, description = "编辑费领退信息")
    public R<WmsCostIssueReturnEditInfoDto> editInfo(Integer id) {
        return R.ok(costIssueReturnService.editInfo(id));
    }

    @ApiOperation(value = "编辑保存费领退信息")
    @PostMapping("/edit")
    @FactoryOperationLog(operationType = OperationTypeConstant.MODIFY, description = "编辑保存费领退信息")
    public R<Void> editCost(WmsCostIssueReturnSaveVo saveVo) {
        return R.ok(costIssueReturnService.updateCost(saveVo));
    }

    @ApiOperation(value = "删除费领退信息")
    @PostMapping("/deleteByIds")
    @FactoryOperationLog(operationType = OperationTypeConstant.DELETE, description = "删除费领退信息")
    public R<Void> deleteByIds(@RequestBody List<Integer> idList) {
        costIssueReturnService.deleteByIds(idList);
        return R.ok();
    }

    @ApiOperation(value = "导出模板")
    @GetMapping("/exportTemplate")
    private R<Void> exportTemplate(HttpServletResponse httpServletResponse) {
        costIssueReturnService.exportTemplate(httpServletResponse);
        return null;
    }

    @ApiOperation(value = "报废单导出模板")
    @GetMapping("/scrapExportTemplate")
    private R<Void> scrapExportTemplate(HttpServletResponse httpServletResponse) {
        costIssueReturnService.scrapExportTemplate(httpServletResponse);
        return null;
    }

    @ApiOperation("费领/退管理—excel批量导入")
    @PostMapping("/importExcel")
    public R<Void> importExcel(MultipartFile file) throws IOException {
        String fileExt = FileUtil.extName(file.getOriginalFilename());
        if (fileExt == null || (!"xls".equals(fileExt.toLowerCase()) && !"xlsx".equals(fileExt.toLowerCase()))) {
            return R.no(MessageUtils.get(WmsMouldResultCode.UNSUPPORTED_FILE_TYPES.getLocalCode()));
        }
        costIssueReturnService.importExcel(file);
        return R.ok();
    }

    @ApiOperation(value = "费领退送签")
    @GetMapping("/sendToSign")
    public R<FlownetResponse> sendToSign(HttpServletRequest request, Integer id) {
        return R.ok(costIssueReturnService.sendToSign(request, id));
    }

    @ApiOperation(value = "报废单送签")
    @GetMapping("/scrapSendToSign")
    public R<FlownetResponse> scrapSendToSign(HttpServletRequest request, Integer id) {
        return R.ok(costIssueReturnService.scrapSendToSign(request, id));
    }

    @ApiOperation("Flownet审核完成调用服务节点")
    @PostMapping("/approvalCompleted")
    public R<Void> approvalCompleted(@RequestBody String jsonString) {
        log.info("Flownet input parameter=========》：::requestJson={}", jsonString);
        return costIssueReturnService.approvalCompleted(jsonString);
    }

    @ApiOperation(value = "Flownet审核完成")
    @PostMapping("/flownetApproval")
    public R<Void> flownetApproval(@RequestBody List<WmsFlownetApprovalVo> wmsFlownetApprovalVoList) {
        costIssueReturnService.flownetApproval(wmsFlownetApprovalVoList);
        return R.ok();
    }

    @ApiOperation(value = "收货完成")
    @GetMapping("/receiveCompleted")
    public R<Void> receiveCompleted(String docNo) {
        costIssueReturnService.receiveCompleted(docNo);
        return R.ok();
    }

    @ApiOperation(value = "查询明细信息")
    @GetMapping("/detailInfo")
    public R<List<WmsCostIssueReturnDetailDto>> detailInfo(@RequestParam("id") Integer id,
                                                           @RequestParam(value = "partNo", required = false) String partNo) {
        return R.ok(costIssueReturnService.detailInfo(id, partNo));
    }

    @ApiOperation(value = "费领下架推荐载具、储位、pkgid")
    @GetMapping("/recommend")
    public R<WmsCostRemoveShelfInfoDTO> recommend(@RequestParam("detailId") Integer detailId, @RequestParam("orgCode") String orgCode) {
        return R.ok(costIssueReturnService.recommend(detailId, orgCode));
    }

    @ApiOperation(value = "费领扫描条码推荐载具、储位")
    @GetMapping("/recommendPkg")
    public R<WmsCostRemoveShelfInfoDTO> recommendPkg(@RequestParam(value = "pkgId", required = false) String pkgId,
                                                     @RequestParam(value = "applyQty", required = false) BigDecimal applyQty,
                                                     @RequestParam(value = "completedQty", required = false) BigDecimal completedQty,
                                                     @RequestParam(value = "orgCode") String orgCode) {
        return R.ok(costIssueReturnService.recommendPkg(pkgId, applyQty, completedQty, orgCode));
    }

    @ApiOperation("费领下架提交")
    @PostMapping("/removeShelf")
    public R<Void> removeShelf(@RequestBody CostRemoveShelfVO costRemoveShelfVO) {
        costIssueReturnService.removeShelf(costRemoveShelfVO);
        return R.ok();
    }

    @ApiOperation("单头费领下架提交")
    @PostMapping("/headerRemoveShelf")
    public R<Void> headerRemoveShelf(@RequestBody CostHeaderRemoveShelfVO costHeaderRemoveShelfVO) {
        costIssueReturnService.headerRemoveShelf(costHeaderRemoveShelfVO);
        return R.ok();
    }

    @ApiOperation("费退上架")
    @PostMapping("/costShelf")
    public R<Void> costShelf(@RequestBody CostShelfVO costShelfVO) {
        costIssueReturnService.costShelf(costShelfVO);
        return R.ok();
    }

    @ApiOperation("单头费退上架")
    @PostMapping("/headerCostShelf")
    public R<Void> headerCostShelf(@RequestBody CostHeaderShelfVO headerShelfVO) {
        costIssueReturnService.headerCostShelf(headerShelfVO);
        return R.ok();
    }

    @ApiOperation("查询成本中心关系")
    @GetMapping("/getCostRelation")
    public R<List<WmsCostRelationDto>> getCostRelation(WmsCostRelationVo costRelationVo) {
        return R.ok(costIssueReturnService.getCostRelation(costRelationVo));
    }

    @ApiOperation("查询异动类型")
    @GetMapping("/getMovementType")
    public R<List<WmsCostRelationDto>> getMovementType(WmsCostRelationVo costRelationVo) {
        return R.ok(costIssueReturnService.getMovementType(costRelationVo));
    }

    @ApiOperation("根据异动类型查询原因")
    @GetMapping("/getReason")
    public R<List<WmsCostRelationDto>> getReason(WmsCostRelationVo costRelationVo) {
        return R.ok(costIssueReturnService.getReason(costRelationVo));
    }

    @ApiOperation("调用SAP接口获取单价、币别")
    @GetMapping("/getPrice")
    public R<WmsCostSapDto> getPrice(@RequestParam(value = "plantCode") String plantCode,
                                     @RequestParam(value = "warehouseCode", required = false) String warehouseCode,
                                     @RequestParam(value = "partNo") String partNo,
                                     @RequestParam(value = "partVersion", required = false) String partVersion,
                                     @RequestParam(value = "orgCode") String orgCode,
                                     @RequestParam(value = "qty") BigDecimal qty) throws JCoException, ParseException {
        Map<String, String> values = dictLangUtils.getByType(plantCode);
        return R.ok(costIssueReturnService.getPrice(plantCode, warehouseCode, partNo, partVersion, qty, values, orgCode));
    }

    @ApiOperation(value = "签核状态")
    @GetMapping("/approvalStatus")
    public R<FlownetResponse> approvalStatus(Integer id) {
        return R.ok(costIssueReturnService.approvalStatus(id));
    }

    @ApiOperation("明细导入")
    @PostMapping("/importDetail")
    public R<List<WmsCostIssueReturnDetailDto>> importDetail(CostIssueReturnDetailExcelImportVO importVO) throws IOException, JCoException, ParseException {
        MultipartFile file = importVO.getFile();
        String orgCode = importVO.getOrgCode();
        String fileExt = FileUtil.extName(file.getOriginalFilename());
        if (fileExt == null || (!"xls".equals(fileExt.toLowerCase()) && !"xlsx".equals(fileExt.toLowerCase()))) {
            return R.no(MessageUtils.get(WmsMouldResultCode.UNSUPPORTED_FILE_TYPES.getLocalCode()));
        }
        return R.ok(costIssueReturnService.importDetail(file, importVO.getPlantCode(), orgCode));
    }

    @ApiOperation("手动确认过账")
    @PostMapping("/userComfirm")
    public R<Void> userComfirm(@RequestBody CostIssueReturnUserComfirmVO comfirmVO) {
        costIssueReturnService.userComfirm(comfirmVO);
        return R.ok();
    }

    @ApiOperation("删除文件")
    @PostMapping("/delFiles")
    @FactoryOperationLog(operationType = OperationTypeConstant.DELETE, description = "删除文件")
    public R<Void> delFiles(@RequestBody CostIssueReturnDelFileVO delFileVO) {
        costIssueReturnService.delFiles(delFileVO);
        return R.ok();
    }


    @ApiOperation(value = "查询物料采购人")
    @GetMapping("/getPurchaser")
    public R<PartNoPurchaserDTO> getPurchaser(@RequestParam("orgCode") String orgCode,
                                              @RequestParam("plantCode") String plantCode,
                                              @RequestParam("partNo") String partNo) throws JCoException {
        return R.ok(costIssueReturnService.getPurchaser(orgCode, plantCode, partNo));
    }

    @ApiOperation("费领退or报废导出明细")
    @GetMapping("/costIssueDetailExport")
    void costIssueDetailExport(WmsCostIssueReturnVo vo, HttpServletResponse response){
        costIssueReturnService.costIssueDetailExport(vo, response);
    }

    @ApiOperation("费领报废处理单BY栈板导入")
    @PostMapping("/importScrapHandleDetail")
    public R<List<WmsCostIssueReturnDetailDto>> importScrapHandleDetail(CostIssueReturnDetailExcelImportVO importVO) throws IOException, JCoException, ParseException {
        MultipartFile file = importVO.getFile();
        String orgCode = importVO.getOrgCode();
        String fileExt = FileUtil.extName(file.getOriginalFilename());
        if (fileExt == null || (!"xls".equals(fileExt.toLowerCase()) && !"xlsx".equals(fileExt.toLowerCase()))) {
            return R.no(MessageUtils.get(WmsMouldResultCode.UNSUPPORTED_FILE_TYPES.getLocalCode()));
        }
        return R.ok(costIssueReturnService.importScrapHandleDetail(file, importVO.getPlantCode(), orgCode));
    }

    @ApiOperation("LRR单BY箱号导入")
    @PostMapping("/importLrrDetail")
    public R<List<WmsCostIssueReturnDetailDto>> importLrrDetail(CostIssueReturnDetailExcelImportVO importVO) throws IOException, JCoException, ParseException {
        MultipartFile file = importVO.getFile();
        String orgCode = importVO.getOrgCode();
        String fileExt = FileUtil.extName(file.getOriginalFilename());
        if (fileExt == null || (!"xls".equals(fileExt.toLowerCase()) && !"xlsx".equals(fileExt.toLowerCase()))) {
            return R.no(MessageUtils.get(WmsMouldResultCode.UNSUPPORTED_FILE_TYPES.getLocalCode()));
        }
        return R.ok(costIssueReturnService.importLrrDetail(file, importVO.getPlantCode(), orgCode));
    }

    @ApiOperation("SWR单导入")
    @PostMapping("/importSwrDetail")
    public R<List<WmsCostIssueReturnDetailDto>> importSwrDetail(CostIssueSwrImportVO importVO) throws IOException, JCoException, ParseException {
        return R.ok(costIssueReturnService.importSwrDetail(importVO));
    }


}
