package com.maxnerva.cloudmes.controller.doc;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.doc.DocCusRecordDTO;
import com.maxnerva.cloudmes.models.vo.doc.CusRecordExcelImportVO;
import com.maxnerva.cloudmes.models.vo.doc.DocCusFromDocExcelImportVO;
import com.maxnerva.cloudmes.models.vo.doc.DocCusRecordQueryVO;
import com.maxnerva.cloudmes.models.vo.wo.CusRecordInfoExportVO;
import com.maxnerva.cloudmes.service.doc.IWmsDocReceiveCusRecordService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @ClassName DocReceiveCusRecordController
 * @Description TODO
 * @Author Likun
 * @Date 2024/7/17
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "报关进口信息管理")
@Slf4j
@RestController
@RequestMapping("/cusRecord")
public class DocReceiveCusRecordController {

    @Resource
    private IWmsDocReceiveCusRecordService wmsDocReceiveCusRecordService;

    @PostMapping("/importCusRecord")
    @ApiOperation("导入报关信息")
    public R<Void> importCusRecord(CusRecordExcelImportVO cusRecordExcelImportVO) {
        wmsDocReceiveCusRecordService.importCusRecord(cusRecordExcelImportVO);
        return R.ok();
    }

    @ApiOperation("报关文件导出")
    @PostMapping("/exportCusRecordInfo")
    public void exportCusRecordInfo(@RequestBody CusRecordInfoExportVO exportVO, HttpServletResponse response) {
        response.setHeader("Content-Disposition", "attachment; filename=tmp");
        wmsDocReceiveCusRecordService.exportCusRecordInfo(exportVO, response);
    }

    @ApiOperation("报关进口信息查询")
    @PostMapping("/list")
    public R<PageDataDTO<DocCusRecordDTO>> selectCusRecordPage(@RequestBody DocCusRecordQueryVO pageQueryVO) {
        return R.ok(wmsDocReceiveCusRecordService.selectCusRecordPage(pageQueryVO));
    }

    @ApiOperation("报关进口信息excel导出")
    @PostMapping("/exportDocCusRecord")
    public R<Void> exportDocCusRecord(HttpServletResponse response,
                                      @RequestBody DocCusRecordQueryVO queryVO) {
        wmsDocReceiveCusRecordService.exportDocCusRecord(response, queryVO);
        return R.ok();
    }

    @ApiOperation("来源单号信息excel导入")
    @PostMapping("/importFromDocInfo")
    public R<Void> importFromDocInfo(DocCusFromDocExcelImportVO excelImportVO) {
        wmsDocReceiveCusRecordService.importFromDocInfo(excelImportVO);
        return R.ok();
    }

    @ApiOperation("删除报关信息")
    @DeleteMapping("/delete")
    public R<Void> delete(@RequestBody List<Integer> idList) {
        wmsDocReceiveCusRecordService.deleteCusRecordBatch(idList);
        return R.ok();
    }

}
