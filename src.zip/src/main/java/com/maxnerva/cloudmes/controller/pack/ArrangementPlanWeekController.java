package com.maxnerva.cloudmes.controller.pack;

import cn.hutool.core.collection.CollectionUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.fastjson2.JSON;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.entity.pack.WmsArrangementPlanOriginWeek;
import com.maxnerva.cloudmes.entity.pack.WmsArrangementPlanTargetWeek;
import com.maxnerva.cloudmes.models.dto.pack.WmsArrangementPlanTargetWeekDTO;
import com.maxnerva.cloudmes.models.vo.ExcelImportVO;
import com.maxnerva.cloudmes.service.pack.IWmsArrangementPlanOriginWeekService;
import com.maxnerva.cloudmes.service.pack.IWmsArrangementPlanTargetWeekService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

/**
 * @ClassName ArrangementPlanWeekController
 * @Description 包材排配计划controller
 * @Author Cuiyunhao
 * @Date 2025/6/9 下午 03:33
 * @Version 1.0
 **/
@Api(tags = "包材排配周计划")
@Slf4j
@RestController
@RequestMapping("/arrangementPlanWeek")
public class ArrangementPlanWeekController {

    @Autowired
    IWmsArrangementPlanOriginWeekService arrangementPlanOriginWeekService;
    @Autowired
    IWmsArrangementPlanTargetWeekService arrangementPlanTargetWeekService;


    /**
     *  周排配计划数据导入分页查询
     * @param hhPn  鸿海料号
     * @param importYear  导入年份
     * @param importWeek  导入周别
     * @return
     */
    @ApiOperation("周排配计划数据导入分页查询")
    @GetMapping("/queryImportWeek")
    public R queryImportWeek(@RequestParam(value = "hhPn", required = false) String hhPn,
                             @RequestParam(value = "orgCode", required = false) String orgCode,
                             @RequestParam(value = "importYear", required = false) Integer importYear,
                             @RequestParam(value = "importWeek", required = false) String importWeek,
                             @RequestParam("pageIndex") int pageIndex,
                             @RequestParam("pageSize") int pageSize){
        return R.ok(arrangementPlanOriginWeekService.queryImportWeek(hhPn,importYear,importWeek,orgCode,pageIndex,pageSize));
    }

    /**
     *  周排配计划数据导入
     * @return
     */
    @ApiOperation("周排配计划数据导入")
    @PostMapping("/weekPlanImport")
    public R weekPlanImport(ExcelImportVO excelImportVO) {
         arrangementPlanOriginWeekService.weekPlanImport(excelImportVO.getFile(),excelImportVO.getOrgCode());
         return R.ok();
    }

    /**
     *  日排配计划报表导出数据校验
     * @param importYear   导入年份
     * @param importWeek    导入周别
     * @return
     */
    @ApiOperation("周排配计划报表导出数据校验")
    @GetMapping("/downloadDataVerify")
    public R downloadDataVerify(@RequestParam("importYear") int importYear,
                                @RequestParam("importWeek") String importWeek,@RequestParam("orgCode")String orgCode) {
        //查询未完成数据  计算状态 0:未计算1:计算中2:完成3:失败   不等于2的都为计算失败
        List<WmsArrangementPlanOriginWeek> notSuccess = arrangementPlanOriginWeekService.getNotSuccess(importYear, importWeek, orgCode,2);
        if(!CollectionUtil.isEmpty(notSuccess)) {
            return R.no("导入年份：" + importYear + "，导入周别：" + importWeek + "存在未计算完成或计算失败数据，请耐心等待计算完成或重新计算失败数据，再进行导出！");
        }
        //导出数据查询
        List<WmsArrangementPlanTargetWeek> tarByYearAndWeek = arrangementPlanTargetWeekService.getTarByYearAndWeek(importYear, importWeek, orgCode);
        if(CollectionUtil.isEmpty(tarByYearAndWeek)) {
            return R.no("导出数据不存在！");
        }
        return R.ok();
    }

    /**
     *  周排配计划报表导出
     * @param response
     * @param importYear   导入年份
     * @param importWeek   导入周别
     * @throws Exception
     */
    @ApiOperation("周排配计划报表导出")
    @GetMapping("/weekPlanDownload")
    public void weekPlanDownload(HttpServletResponse response,
                                 @RequestParam(value = "importYear") Integer importYear,
                                 @RequestParam(value = "importWeek") String importWeek,
                                 @RequestParam(value = "orgCode") String orgCode) throws Exception {
        arrangementPlanOriginWeekService.exportWeekPlan(importYear, importWeek, orgCode, response);
    }

    /**
     *  重新计算失败数据
     * @param importYear   导入年份
     * @param importWeek   导入周别
     * @return
     */
    @ApiOperation("重新计算失败数据")
    @GetMapping("/calculateInsAnew")
    public R calculateInsAnew(@RequestParam(value = "importYear") Integer importYear,
                                         @RequestParam(value = "importWeek") String importWeek
    ,@RequestParam(value = "orgCode") String orgCode) {
        return arrangementPlanOriginWeekService.statementCalculateAndIns(null,importYear,importWeek, orgCode);
    }

}
