package com.maxnerva.cloudmes.controller.scrap;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @ClassName ScrapController
 * @Description 报废单管理
 * @Author Likun
 * @Date 2023/3/30
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "报废单管理")
@Slf4j
@RestController
@RequestMapping("/scrap")
public class ScrapController {
}
