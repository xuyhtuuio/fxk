package com.maxnerva.cloudmes.controller.doc;

import com.maxnerva.cloudmes.common.enums.ResultCode;
import com.maxnerva.cloudmes.common.exception.CloudmesException;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.doc.WmsDocTemplateSettingDTO;
import com.maxnerva.cloudmes.models.vo.doc.TemplateSettingVO;
import com.maxnerva.cloudmes.service.doc.IWmsDocTypeTemplateSettingService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName DocTypeTemplateSettingController
 * @Description 单据类型模板参数管理
 * @Author Likun
 * @Date 2022/7/26
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "单据类型模板管理")
@Slf4j
@RestController
@RequestMapping("/docTypeTemplate")
public class DocTypeTemplateController {

    @Resource
    private IWmsDocTypeTemplateSettingService wmsDocTypeTemplateSettingService;


    @ApiOperation("添加单据类型对应的模板信息")
    @PostMapping("/add")
    public R<Void> saveDocTypeTemplateSetting(@RequestBody TemplateSettingVO templateSettingVO) {
        wmsDocTypeTemplateSettingService.saveDocTypeTemplateSetting(Integer.valueOf(templateSettingVO.getWmsDocTypeId()),
                templateSettingVO.getList());
        return R.ok();
    }

    @ApiOperation("根据单据类型主键id查询单据类型模板参数列表")
    @GetMapping("/list")
    public R<List<WmsDocTemplateSettingDTO>> getTemplateSettingListByTypeId(@RequestParam Integer wmsDocTypeId) {
        return R.ok(wmsDocTypeTemplateSettingService.getTemplateSettingListByTypeId(wmsDocTypeId));
    }
}
