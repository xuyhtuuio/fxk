package com.maxnerva.cloudmes.controller.deliver;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.excel.util.DataSourceUtil;
import com.maxnerva.cloudmes.models.vo.deliver.ShipVehicleInfoInsertVO;
import com.maxnerva.cloudmes.service.deliver.IWmsShipVehicleInfoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(tags = "入厂车辆信息")
@RestController
@RequestMapping("/shipVehicleInfo")
public class WmsShipVehicleInfoController {

    @Autowired
    IWmsShipVehicleInfoService wmsShipVehicleInfoService;

    @ApiOperation("插入车辆信息（对位免鉴权）")
    @PostMapping("/create")
    R create(@RequestBody ShipVehicleInfoInsertVO vo) {
        DataSourceUtil.setWmsDataSource();
        wmsShipVehicleInfoService.create(vo);
        return R.ok();
    }

}
