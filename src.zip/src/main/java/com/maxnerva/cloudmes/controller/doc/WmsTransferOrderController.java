package com.maxnerva.cloudmes.controller.doc;

import com.maxnerva.cloudmes.aspect.FactoryOperationLog;
import com.maxnerva.cloudmes.common.constant.OperationTypeConstant;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.entity.basic.WmsSapPlant;
import com.maxnerva.cloudmes.entity.doc.WmsDocTransferLog;
import com.maxnerva.cloudmes.entity.flownet.FlownetResponse;
import com.maxnerva.cloudmes.excel.util.DataSourceUtil;
import com.maxnerva.cloudmes.models.dto.basic.MaterialVersionDTO;
import com.maxnerva.cloudmes.models.dto.basic.RemovedMaterialDTO;
import com.maxnerva.cloudmes.models.dto.basic.WmsSapWarehouseCodeDTO;
import com.maxnerva.cloudmes.models.dto.doc.*;
import com.maxnerva.cloudmes.models.dto.warehouse.RecommendDTO;
import com.maxnerva.cloudmes.models.dto.warehouse.WmsPkgInfoDTO;
import com.maxnerva.cloudmes.models.vo.basic.*;
import com.maxnerva.cloudmes.models.vo.doc.*;
import com.maxnerva.cloudmes.service.doc.IWmsTransferOrderService;
import com.maxnerva.cloudmes.service.lock.LockService;
import com.sap.conn.jco.JCoException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.util.List;

@Api(tags = "转仓单管理")
@Slf4j
@RestController
@RequestMapping("/transferOrder")
public class WmsTransferOrderController {

    @Resource
    private IWmsTransferOrderService wmsTransferOrderService;

    @Resource
    private LockService lockService;

    @ApiOperation(value = "查询转仓单信息")
    @GetMapping("/list")
    public R<PageDataDTO<WmsTransferOrderDto>> selectPage(WmsTransferOrderVO pageQueryVO) {
        return R.ok(wmsTransferOrderService.selectPage(pageQueryVO));
    }

    @ApiOperation(value = "查询跨工厂转仓单信息")
    @GetMapping("/interFactoryList")
    public R<PageDataDTO<WmsTransferOrderDto>> interFactoryList(WmsTransferOrderVO pageQueryVO) {
        return R.ok(wmsTransferOrderService.selectInterFactoryPage(pageQueryVO));
    }

    @ApiOperation(value = "新增转仓单信息")
    @PostMapping("/add")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "新增转仓单信息")
    public R<Void> saveTransferOrder(@RequestBody WmsTransferOrderSaveVo saveVo) throws JCoException {
        wmsTransferOrderService.saveTransferOrder(saveVo);
        return R.ok();
    }

    @ApiOperation(value = "转仓单保存并提交")
    @PostMapping("/addAndSubmit")
    public R<Void> addAndSubmit(HttpServletRequest request, @RequestBody WmsTransferOrderSaveVo saveVo) throws JCoException {
        wmsTransferOrderService.addAndSubmit(request, saveVo);
        return R.ok();
    }

    @ApiOperation(value = "上传")
    @GetMapping("/upload")
    public R<TransferUploadDTO> upload(HttpServletRequest request, @RequestParam Integer id) {
        return R.ok(wmsTransferOrderService.upload(request, id));
    }

    @ApiOperation(value = "签核状态")
    @GetMapping("/approvalStatus")
    public R<FlownetResponse> approvalStatus(Integer id) {
        return R.ok(wmsTransferOrderService.approvalStatus(id));
    }

    @ApiOperation(value = "查询转仓信息")
    @GetMapping("/getRollOverById")
    public R<WmsAdjustTransferInfoDto> getRollOverById(Integer id) {
        WmsAdjustTransferInfoDto infoDto = wmsTransferOrderService.getRollOverById(id);
        return R.ok(infoDto);
    }

    @ApiOperation(value = "转仓提交")
    @PostMapping("/submitTansfer")
    public R<Integer> submitRollOver(@RequestBody WmsAdjustSubmitRollOverVo submitRollOverVo) {
        wmsTransferOrderService.submitRollOver(submitRollOverVo);
        return R.ok();
    }

    @ApiOperation(value = "查询条码详情")
    @GetMapping("/getPkgInfoDetail")
    public R<List<WmsPkgInfoDTO>> getPkgInfoDetail(RollOverPkgInfoPageQueryVO pageQueryVO) {
        return R.ok(wmsTransferOrderService.getPkgInfoDetail(pageQueryVO));
    }

    @ApiOperation(value = "转仓执行勾选数量")
    @GetMapping("/selectNum")
    public R<BigDecimal> selectNum(RollOverSelectNumVO selectNumVO) {
        wmsTransferOrderService.selectNum(selectNumVO);
        return R.ok();
    }

    @ApiOperation(value = "手动确认")
    @PostMapping("/confirm")
    public R<Void> confirm(@RequestBody CostIssueReturnUserComfirmVO comfirmVO) {
        wmsTransferOrderService.confirm(comfirmVO);
        return R.ok();
    }

    @ApiOperation("转仓单excel导入")
    @PostMapping("/import")
    public R<Void> importTransferOrder(WmsAsnUploadImportVO excelImportVO) throws JCoException {
        wmsTransferOrderService.importTransferOrder(excelImportVO.getFile(), excelImportVO.getOrgCode(), excelImportVO.getPlantCode());
        return R.ok();
    }

    @ApiOperation("转仓单excel导入")
    @PostMapping("/crossFactoryImport")
    public R<Void> crossFactoryImport(WmsAsnUploadImportVO excelImportVO) throws JCoException {
        wmsTransferOrderService.crossFactoryImport(excelImportVO.getFile(), excelImportVO.getOrgCode(), excelImportVO.getPlantCode());
        return R.ok();
    }

    @ApiOperation("Flownet审核完成调用服务节点")
    @PostMapping("/approvalCompleted")
    public R<Void> approvalCompleted(@RequestBody String jsonString) {
        log.info("Flownet input parameter=========》：::requestJson={}", jsonString);
        DataSourceUtil.setWmsDataSource();
        wmsTransferOrderService.approvalCompleted(jsonString);
        return R.ok();
    }

    @ApiOperation(value = "Flownet审核完成")
    @PostMapping("/flownetApproval")
    public R<Void> flownetApproval(@RequestBody List<WmsFlownetApprovalVo> wmsFlownetApprovalVoList) {
        wmsTransferOrderService.flownetApproval(wmsFlownetApprovalVoList);
        return R.ok();
    }

    @ApiOperation("导出")
    @PostMapping("/export")
    public R<Void> export(HttpServletResponse response,
                          @RequestBody WmsTransferOrderVO vo) {
        wmsTransferOrderService.export(response, vo);
        return R.ok();
    }

    @ApiOperation("跨工厂导出")
    @PostMapping("/crossFactoryExport")
    public R<Void> crossFactoryExport(HttpServletResponse response,
                          @RequestBody WmsTransferOrderVO vo) {
        wmsTransferOrderService.crossFactoryExport(response, vo);
        return R.ok();
    }

    @ApiOperation("删除")
    @DeleteMapping("/delete")
    public R<Void> delete(@RequestBody TransferDocDeleteVO vo) {
        wmsTransferOrderService.delete(vo);
        return R.ok();
    }

    @ApiOperation(value = "新增转仓单收货信息")
    @PostMapping("/addTransferAndReceiveDoc")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "新增转仓单收货信息")
    public R<Void> saveTransferAndReceive(@RequestBody WmsTransferAndReceiveDocSaveVo saveVo) {
        wmsTransferOrderService.saveTransferAndReceive(saveVo);
        return R.ok();
    }

    @ApiOperation("批量新增转仓单")
    @PostMapping("/saveDocTransferBatch")
    public R<Void> saveDocTransferBatch(@RequestBody List<TransferOrderAddVO> transferOrderAddVOList) {
        wmsTransferOrderService.saveDocTransferBatch(transferOrderAddVOList);
        return R.ok();
    }

    @ApiOperation("同步转仓单/报废单到SPM")
    @PostMapping("/syncDocToSpm")
    public R<Void> syncDocToSpm(@RequestBody SpmDocSyncVO spmDocSyncVO){
        return wmsTransferOrderService.syncDocToSpm(spmDocSyncVO);
    }

    @ApiOperation(value = "PDA扫描PKG转仓提交")
    @PostMapping("/transferSubmitByPkgId")
    public R transferSubmitByPkgId(@RequestBody TransferSubmitByPkgIdVO vo) {
        lockService.transferSubmitByPkgId(vo);
        return R.ok();
    }

    @ApiOperation(value = "檢測料號是否在SAP存在")
    @PostMapping("/checkMaterial")
    public R<Void> checkMaterial(@RequestBody CheckMaterialVO checkMaterialVO) throws JCoException{
        wmsTransferOrderService.checkMaterial(checkMaterialVO);
        return R.ok();
    }

    @ApiOperation(value = "检测工厂的管控方式")
    @PostMapping("/checkSectionType")
    public R<Void> checkSectionType(@RequestBody CheckPlantSectionVO checkPlantSectionVO){
        wmsTransferOrderService.checkSectionType(checkPlantSectionVO);
        return R.ok();
    }

    @ApiOperation(value = "获取目的仓码")
    @GetMapping("/getTargetWareHouseCode")
    public  R<List<WmsSapWarehouseCodeDTO>> getTargetWareHouseCode(TargetPlantVO targetPlantVO) {
        return R.ok(wmsTransferOrderService.getTargetWareHouseCode(targetPlantVO));
    }

    @ApiOperation(value = "跨工廠轉倉保存")
    @PostMapping("/addTransfer")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "新增跨工厂转仓单信息")
    public R<Void> addTransfer(@RequestBody WmsTransferOrderSaveVo saveVo) throws JCoException {
        wmsTransferOrderService.addTransfer(saveVo);
        return R.ok();
    }

    @ApiOperation(value = "跨工廠轉倉提交")
    @GetMapping("/crossFactorySubmit")
    public R<TransferUploadDTO> crossFactorySubmit(HttpServletRequest request, @RequestParam Integer id) {
        return R.ok(wmsTransferOrderService.crossFactorySubmit(request, id));
    }

    @ApiOperation(value = "跨工廠轉倉上架")
    @PostMapping("/crossFactoryShelf")
    public R<CrossShelfReturnDTO> crossFactoryShelf(@RequestBody CrossFactoryOnVO crossFactoryOnVO) throws JCoException{
        return R.ok(wmsTransferOrderService.crossFactoryShelf(crossFactoryOnVO));
    }

    @ApiOperation(value = "跨工廠轉倉下架")
    @PostMapping("/crossFactoryRemoved")
    public R<BigDecimal> crossFactoryRemoved(@RequestBody CrossFactoryShelfDTO crossFactoryShelfDTO) {
        return R.ok(wmsTransferOrderService.crossFactoryRemoved(crossFactoryShelfDTO));
    }

    @ApiOperation(value = "获取当前下架的PKG")
    @GetMapping("/getCurrentRemovePkg")
    public R<List<WmsDocTransferLog>> getCurrentRemovePkg(@RequestParam("docNo") String docNo,
                                                           @RequestParam("orgCode") String orgCode) {
        return R.ok(wmsTransferOrderService.getCurrentRemovePkg(docNo,orgCode));
    }

    @ApiOperation(value = "扫描推荐储位")
    @GetMapping("/recommendBin")
    public R<RecommendDTO> recommendBin(@RequestParam("vehicleCode") String vehicleCode,
                                        @RequestParam("orgCode") String orgCode,
                                        @RequestParam("partNo")  String partNo) {
        return R.ok(wmsTransferOrderService.recommendBin(vehicleCode, orgCode, partNo));
    }



}
