package com.maxnerva.cloudmes.controller.doc;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.doc.DocSwrLogDetailDTO;
import com.maxnerva.cloudmes.models.dto.doc.DocSwrLogHeaderDTO;
import com.maxnerva.cloudmes.models.vo.doc.DocSwrLogDetailQueryVO;
import com.maxnerva.cloudmes.models.vo.doc.DocSwrLogHeaderQueryVO;
import com.maxnerva.cloudmes.service.doc.IWmsDocSwrLogDetailService;
import com.maxnerva.cloudmes.service.doc.IWmsDocSwrLogHeaderService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(tags = "SWR单管理")
@Slf4j
@RestController
@RequestMapping("/docSwrLog")
public class DocSwrLogController {

    @Autowired
    IWmsDocSwrLogHeaderService wmsDocSwrLogHeaderService;

    @Autowired
    IWmsDocSwrLogDetailService wmsDocSwrLogDetailService;

    @ApiOperation("SWR单查询")
    @GetMapping("/headerPageList")
    R<PageDataDTO<DocSwrLogHeaderDTO>> headerPageList(DocSwrLogHeaderQueryVO vo) {
        return R.ok(wmsDocSwrLogHeaderService.selectPageList(vo));
    }

    @ApiOperation("SWR明细查询")
    @GetMapping("/detailPageList")
    R<PageDataDTO<DocSwrLogDetailDTO>> detailPageList(DocSwrLogDetailQueryVO vo) {
        return R.ok(wmsDocSwrLogDetailService.selectPageList(vo, Boolean.TRUE));
    }

}
