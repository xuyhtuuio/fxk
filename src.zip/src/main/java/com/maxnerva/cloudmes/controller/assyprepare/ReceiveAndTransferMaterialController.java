package com.maxnerva.cloudmes.controller.assyprepare;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.assyprepare.ReceiveAndTransferMaterialDTO;
import com.maxnerva.cloudmes.models.vo.assyprepare.BinScanVO;
import com.maxnerva.cloudmes.service.assyprepare.ReceiveAndTransferMaterialService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @ClassName ReceiveAndTransferMaterialController
 * @Description 收货移料管理
 * @Author Likun
 * @Date 2024/8/9
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "收货移料管理")
@Slf4j
@RestController
@RequestMapping("/receiveAndTransferMaterial")
public class ReceiveAndTransferMaterialController {

    @Resource
    private ReceiveAndTransferMaterialService receiveAndTransferMaterialService;

    @ApiOperation("扫描采集储位")
    @PostMapping("/scanBinCode")
    public R<ReceiveAndTransferMaterialDTO> scanBinCode(@RequestBody BinScanVO binScanVO){
        return R.ok(receiveAndTransferMaterialService.scanBinCode(binScanVO));
    }

    @ApiOperation("提交")
    @PostMapping("/submit")
    public R<Void> submit(@RequestBody BinScanVO binScanVO){
        return receiveAndTransferMaterialService.submit(binScanVO);
    }
}
