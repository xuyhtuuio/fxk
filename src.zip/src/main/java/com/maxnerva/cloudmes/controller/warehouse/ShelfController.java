package com.maxnerva.cloudmes.controller.warehouse;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.doc.DocShelfDTO;
import com.maxnerva.cloudmes.models.dto.material.MaterialMfgDTO;
import com.maxnerva.cloudmes.models.dto.warehouse.RecommendDTO;
import com.maxnerva.cloudmes.models.vo.warehouse.*;
import com.maxnerva.cloudmes.models.vo.wo.MfgNameListVO;
import com.maxnerva.cloudmes.service.lock.LockService;
import com.maxnerva.cloudmes.service.warehouse.IShelfService;
import com.maxnerva.cloudmes.utils.DateCodeUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.List;

/**
 * @ClassName ShelfController
 * @Description 上架管理
 * @Author Likun
 * @Date 2022/8/10
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "上架管理")
@Slf4j
@RestController
@RequestMapping("/shelf")
public class ShelfController {

    @Resource
    private IShelfService shelfService;

    @Resource
    private LockService lockService;

    @ApiOperation("单据上架")
    @PostMapping("/docShelf")
    public R<DocShelfDTO> docShelf(@RequestBody DocShelfVO docShelfVO) {
        return R.ok(lockService.docShelf(docShelfVO));
    }

    @Deprecated
    @ApiOperation("单据下架")
    @PostMapping("/docRemoveShelf")
    public R<Void> docRemoveShelf(@RequestBody DocRemoveShelfVO docRemoveShelfVO) {
        shelfService.docRemoveShelf(docRemoveShelfVO);
        return R.ok();
    }

    @ApiOperation("根据载具推荐储位")
    @GetMapping("/recommend")
    public R<RecommendDTO> recommendBin(@ApiParam("vehicleCode") @RequestParam("vehicleCode") String vehicleCode,
                                        @ApiParam("binCode") @RequestParam(value = "binCode", required = false) String binCode,
                                        @ApiParam("orgCode") @RequestParam("orgCode") String orgCode,
                                        @ApiParam("partNo") @RequestParam(value = "partNo", required = false) String partNo) {
        return R.ok(shelfService.recommendBin(vehicleCode, binCode, orgCode, partNo));
    }

    @ApiOperation("扫描储位")
    @PostMapping("/scanBin")
    public R<Void> scanBin(@RequestBody ScanBinVO scanBinVO) {
        shelfService.scanBin(scanBinVO);
        return R.ok();
    }

    @Deprecated
    @ApiOperation("计算剩余数量")
    @GetMapping("/calculateRemainQty")
    public R<BigDecimal> calculateRemainQty(@ApiParam(value = "单据类型编码", required = true)
                                            @RequestParam("docTypeCode") String docTypeCode,
                                            @ApiParam(value = "条码数量", required = true)
                                            @RequestParam("pkgQty") BigDecimal pkgQty) {
        return R.ok(shelfService.calculateRemainQty(docTypeCode, pkgQty));
    }

    @Deprecated
    @ApiOperation("单据类型上架")
    @PostMapping("/docTypeShelf")
    public R<Void> docTypeShelf(@RequestBody DocTypeShelfVO docTypeShelfVO) {
        shelfService.docTypeShelf(docTypeShelfVO);
        return R.ok();
    }

    @ApiOperation("查找制造商信息")
    @PostMapping("/mfgInfoList")
    public R<List<MaterialMfgDTO>> selectMfgInfo(@RequestBody MfgNameListVO mfgNameListVO) {
        String orgCode = mfgNameListVO.getOrgCode();
        String plantCode = mfgNameListVO.getPlantCode();
        String partNo = mfgNameListVO.getPartNo();
        String mfgPartNo = mfgNameListVO.getMfgPartNo();
        return R.ok(shelfService.selectMfgInfo(partNo, mfgPartNo, orgCode, plantCode));
    }

    @ApiOperation("解析D/C")
    @GetMapping("/analysisDateCode")
    public R<String> analysisDateCode(@RequestParam("dateCodeFormat") String dateCodeFormat,
                                      @RequestParam("originalDateCode") String originalDateCode) {
        return R.ok(DateCodeUtil.analysisDateCode(dateCodeFormat, originalDateCode));
    }

    @ApiOperation("PN上架扫描载具,并推荐储位")
    @GetMapping("/recommendBinByPn")
    public R<RecommendDTO> recommendBinByPn(@ApiParam("vehicleCode") @RequestParam("vehicleCode") String vehicleCode,
                                            @ApiParam("orgCode") @RequestParam(value = "orgCode", required = false)
                                            String orgCode,
                                            @ApiParam("partNo") @RequestParam("partNo") String partNo,
                                            @ApiParam("sapWarehouseCode") @RequestParam("sapWarehouseCode")
                                            String sapWarehouseCode) {
        return R.ok(shelfService.recommendBinByPn(vehicleCode, orgCode, partNo, sapWarehouseCode));
    }

    @ApiOperation("PN单据上架")
    @PostMapping("/docShelfByPnMode")
    public R<DocShelfDTO> docShelfByPnMode(@RequestBody DocShelfByPnVO docShelfByPnVO) {
        return R.ok(shelfService.docShelfByPnMode(docShelfByPnVO));
    }

    @ApiOperation("扫描储位ByPn")
    @PostMapping("/scanBinByPn")
    public R<Void> scanBinByPn(@RequestBody ScanBinVO scanBinVO) {
        shelfService.scanBinByPn(scanBinVO);
        return R.ok();
    }

    @ApiOperation("获取制造商信息")
    @PostMapping("/selectMfgInfo")
    public R<MaterialMfgDTO> selectMaterialMfg(@RequestBody MfgNameListVO mfgNameListVO) {
        String orgCode = mfgNameListVO.getOrgCode();
        String plantCode = mfgNameListVO.getPlantCode();
        String partNo = mfgNameListVO.getPartNo();
        String mfgPartNo = mfgNameListVO.getMfgPartNo();
        String mfgName = mfgNameListVO.getMfgName();
        return R.ok(shelfService.selectMaterialMfgDTO(partNo, mfgPartNo, orgCode, mfgName, plantCode));
    }

    @ApiOperation("531入库上架")
    @PostMapping("/woDetailInStorageShelf")
    public R<DocShelfDTO> woDetailInStorageShelf(@RequestBody WoDetailInStorageShelfVO woDetailInStorageShelfVO) {
        return R.ok(shelfService.woDetailInStorageShelf(woDetailInStorageShelfVO));
    }
}
