package com.maxnerva.cloudmes.controller.warehouse;

import cn.hutool.core.util.ObjectUtil;
import com.maxnerva.cloudmes.aspect.FactoryOperationLog;
import com.maxnerva.cloudmes.common.constant.OperationTypeConstant;
import com.maxnerva.cloudmes.common.enums.ResultCode;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.MessageUtils;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.enums.WmsMouldResultCode;
import com.maxnerva.cloudmes.model.dto.PkgIdStatusDTO;
import com.maxnerva.cloudmes.model.vo.WMSHoldQueryVO;
import com.maxnerva.cloudmes.models.dto.*;
import com.maxnerva.cloudmes.models.dto.basic.SelectDTO;
import com.maxnerva.cloudmes.models.dto.warehouse.*;
import com.maxnerva.cloudmes.models.vo.*;
import com.maxnerva.cloudmes.models.vo.warehouse.*;
import com.maxnerva.cloudmes.models.vo.wo.MfgNameListVO;
import com.maxnerva.cloudmes.service.warehouse.IWmsPkgInfoService;
import com.sap.conn.jco.JCoException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.List;

/**
 * @ClassName PkgInfoController
 * @Description 条码(属性)管理
 * @Author caijun
 * @Date 2022/09/06
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "条码管理")
@Slf4j
@RestController
@RequestMapping("/pkgInfo")
public class PkgInfoController {

    @Resource
    private IWmsPkgInfoService wmsPkgInfoService;

    @ApiOperation("查询条码信息")
    @PostMapping("/list")
    public R<PageDataDTO<WmsPkgInfoDTO>> selectPage(@RequestBody PkgInfoPageQueryVO pkgInfoPageQueryVO) {
        return R.ok(wmsPkgInfoService.selectPage(pkgInfoPageQueryVO));
    }

    @ApiOperation("条码重印")
    @GetMapping("/scanPkgId")
    public R<WmsPkgInfoDTO> scanPkgId(String pkgId, String orgCode) {
        if (StringUtils.isBlank(pkgId)) {
            return R.no(WmsMouldResultCode.BAR_CODE_NUMBER_NOT_NULL.getCode(), MessageUtils.get(WmsMouldResultCode.BAR_CODE_NUMBER_NOT_NULL.getLocalCode()));
        }
        WmsPkgInfoDTO detailByPkgId = wmsPkgInfoService.getDetailByPkgId(pkgId, orgCode);
        if (ObjectUtil.isNull(detailByPkgId)) {
            return R.no(WmsMouldResultCode.BAR_CODE_NUMBER_NOT_EXIST.getCode(), MessageUtils.get(WmsMouldResultCode.BAR_CODE_NUMBER_NOT_EXIST.getLocalCode()));
        }
        return R.ok(detailByPkgId);
    }

    @ApiOperation("非在库条码列印")
    @PostMapping("/print")
    public R<Void> savePkgInfo(@Valid @RequestBody PkgPrintVO pkgPrintVO) {
        wmsPkgInfoService.savePrintLog(pkgPrintVO);
        return R.ok();
    }

    @ApiOperation(value = "合盘扫描条码")
    @PostMapping("/scanMerge")
    public R<LabelScanDTO> scanMerge(@Valid @RequestBody WmsLabelMergeScanVO wmsLabelMergeScanVO) {
        return R.ok(wmsPkgInfoService.scanMerge(wmsLabelMergeScanVO));
    }

    @ApiOperation(value = "分盘")
    @PostMapping("/split")
    public R<List<String>> labelSplit(@RequestBody WmsLabelSplitVO wmsLabelSplitVO) {
        return R.ok(wmsPkgInfoService.splitLabel(wmsLabelSplitVO));
    }

    @ApiOperation(value = "合盘")
    @PostMapping("/merge")
    public R<Void> labelMerge(@RequestBody WmsLabelMergeVO mergeVo) {
        wmsPkgInfoService.labelMerge(mergeVo);
        return R.ok();
    }

    @ApiOperation("查询条码打印信息")
    @PostMapping("/printInfoList")
    public R<PkgPrintDTO> selectResources(@RequestBody PkgInfoPrintVO pkgInfoPrintVO) {
        return R.ok(wmsPkgInfoService.printPkgInfo(pkgInfoPrintVO));
    }

    @ApiOperation("解锁条码")
    @PostMapping("/unLockPkgId")
    public R<Void> unLockPkgId(@RequestBody UnLockPkgIdVO unLockPkgIdVO) {
        wmsPkgInfoService.unLockPkgId(unLockPkgIdVO);
        return R.ok();
    }

    @ApiOperation("拆栈板")
    @PostMapping("/palletSplit")
    public R<Void> palletSplit(@RequestBody PalletSplitVO palletSplitVO) {
        wmsPkgInfoService.palletSplit(palletSplitVO);
        return R.ok();
    }

    @ApiOperation("APP拆栈板扫描栈板")
    @GetMapping("/scanPalletSplit")
    public R<List<ScanPalletSplitDTO>> scanPalletSplit(@RequestParam("orgCode") String orgCode,
                                                       @RequestParam("palletNo") String palletNo) {
        return R.ok(wmsPkgInfoService.scanPalletSplit(orgCode, palletNo));
    }

    @ApiOperation("修改有效期")
    @PostMapping("/updatePkgEndDate")
    @FactoryOperationLog(operationType = OperationTypeConstant.MODIFY, description = "修改有效期")
    public R<Void> updatePkgEndDate(@RequestBody PkgUpdateVO pkgUpdateVO) {
        wmsPkgInfoService.updatePkgEndDate(pkgUpdateVO);
        return R.ok();
    }

    @ApiOperation("在库报表列表")
    @GetMapping("/inStockList")
    public R<PageDataDTO<WmsPkgInfoInStockDTO>> inStockList(@RequestParam("orgCode") String orgCode,
                                                            @RequestParam("plantCode") String plantCode,
                                                            @RequestParam("partNo") String partNo,
                                                            @RequestParam(value = "sapWarehouseCode", required = false) String sapWarehouseCode,
                                                            @RequestParam(value = "pkgId", required = false) String pkgId,
                                                            @RequestParam(value = "pageIndex", required = false) Integer pageIndex,
                                                            @RequestParam(value = "pageSize", required = false) Integer pageSize) {
        return R.ok(wmsPkgInfoService.selectInStockList(orgCode, plantCode, partNo, sapWarehouseCode, pkgId, pageIndex, pageSize));
    }

    @ApiOperation("在库报表明细列表")
    @GetMapping("/inStockDetailList")
    public R<List<WmsPkgInfoDTO>> inStockDetailList(@RequestParam("orgCode") String orgCode, @RequestParam("plantCode") String plantCode, @RequestParam("partNo") String partNo, @RequestParam("sapWarehouseCode") String sapWarehouseCode) {
        return R.ok(wmsPkgInfoService.inStockDetailList(orgCode, plantCode, partNo, sapWarehouseCode));
    }

    @ApiOperation("在库差异报表列表")
    @GetMapping("/differentInStockList")
    public R<PageDataDTO<WmsPkgInfoInDifferentStockDTO>> differentInStockList(@RequestParam("orgCode") String orgCode,
                                                                              @RequestParam("plantCode") String plantCode,
                                                                              @RequestParam("partNo") String partNo,
                                                                              @RequestParam("sapWarehouseCode") String sapWarehouseCode,
                                                                              @RequestParam("type") String type,
                                                                              @RequestParam(value = "pageIndex", required = false) Integer pageIndex,
                                                                              @RequestParam(value = "pageSize", required = false) Integer pageSize,
                                                                              @RequestParam(value = "diff", required = false) String diff) {
        return R.ok(wmsPkgInfoService.selectDifferentInStockList(orgCode, plantCode, partNo, sapWarehouseCode, type, pageIndex, pageSize, diff));
    }

    @ApiOperation("在库差异报表-Excel导出")
    @PostMapping("/exportDifferentInStockList")
    public void exportDifferentInStockList(HttpServletResponse response, @RequestBody DifferentInstockExportVO exportVO) throws JCoException {
        wmsPkgInfoService.exportDifferentInStockList(response, exportVO);
    }

    @ApiOperation("条码管理Excel导出")
    @PostMapping("/exportPkgInfo")
    public void exportPkgInfo(HttpServletResponse response, @RequestBody PkgInfoPageQueryVO pkgInfoPageQueryVO) {
        wmsPkgInfoService.exportPkgInfo(response, pkgInfoPageQueryVO);
    }

    @ApiOperation("DC过期预警")
    @GetMapping("/expireWarninglist")
    public R<PageDataDTO<WmsPkgInfoExpireWarningDTO>> expireWarninglist(PkgInfoExpireWarningVO pkgInfoExpireWarningVO) {
        return R.ok(wmsPkgInfoService.expireWarninglist(pkgInfoExpireWarningVO));
    }

    @ApiOperation(value = "整箱拆盘扫描pkg")
    @GetMapping("/scanByPkg")
    public R<PkgScanDTO> scanByPkg(PkgScanVO pkgScanVO) {
        return R.ok(wmsPkgInfoService.scanByPkg(pkgScanVO));
    }


    @ApiOperation(value = "整箱拆盘提交")
    @PostMapping("/unpack")
    public R<Void> unpackPkgUnderFullBox(@RequestBody PkgUnpackVO pkgUnpackVO) {
        wmsPkgInfoService.unpackPkgUnderFullBox(pkgUnpackVO);
        return R.ok();
    }

    @ApiOperation(value = "Qhold查询PKG信息")
    @PostMapping("/qholdselectPkgInfoList")
    public R<QholdPkgInfoDTO> qholdSelectPkgInfoList(@RequestBody QholdSelectPkgVO qholdSelectPkgVO) {
        return R.ok(wmsPkgInfoService.qholdSelectPkgInfoList(qholdSelectPkgVO));
    }

    @ApiOperation(value = "Qhold子查询")
    @PostMapping("/qholdSubSelect")
    public R<List<QholdSubSelectDTO>> qholdSubSelect(@RequestBody QholdSubSelectPkgVO qholdSubSelectPkgVO) {
        return R.ok(wmsPkgInfoService.qholdSubSelect(qholdSubSelectPkgVO));
    }

    @ApiOperation(value = "Qhold按规则锁料")
    @PostMapping("/qholdLockMaterial")
    public R<List<QholdLockMaterialDto>> qholdLockMaterialByPkgId(@RequestBody QholdLockPkgVO qholdLockPkgVO) {
        return R.ok(wmsPkgInfoService.qholdLockMaterialByPkgId(qholdLockPkgVO));
    }

    @ApiOperation(value = "Qhold按PKGID解锁")
    @PostMapping("/qholdUnLockMaterial")
    public R<Void> qholdUnLockMaterial(@RequestBody QholdUnLockMaterialVO qholdUnLockMaterialVO) {
        wmsPkgInfoService.qholdUnLockMaterial(qholdUnLockMaterialVO);
        return R.ok();
    }

    @ApiOperation(value = "Qhold查询PKG是否可用")
    @PostMapping("/pkgIdIsHold")
    public R<PkgIdStatusDTO> pkgIdIsHold(@RequestBody WMSHoldQueryVO wmsHoldQueryVO) {
        return R.ok(wmsPkgInfoService.pkgIdIsHold(wmsHoldQueryVO));
    }

    @ApiOperation(value = "条码重印(新)")
    @PostMapping("/pkgIdReprint")
    public R<PkgPrintDTO> pkgIdReprint(@RequestBody PkgInfoPrintVO pkgInfoPrintVO) {
        return R.ok(wmsPkgInfoService.pkgIdReprint(pkgInfoPrintVO));
    }

    @ApiOperation(value = "条码重印扫码")
    @GetMapping("/scanPkgIdReprint")
    public R<PkgInfoDTO> scanPkgIdReprint(@RequestParam("orgCode") String orgCode, @RequestParam("pkgId") String pkgId) {
        return R.ok(wmsPkgInfoService.scanPkgIdReprint(orgCode, pkgId));
    }

    @ApiOperation(value = "条码列印查询制造商")
    @PostMapping("/getMfgNameList")
    public R<List<SelectDTO>> getMfgNameList(@RequestBody MfgNameListVO mfgNameListVO) {
        String orgCode = mfgNameListVO.getOrgCode();
        String plantCode = mfgNameListVO.getPlantCode();
        String partNo = mfgNameListVO.getPartNo();
        String mfgPartNo = mfgNameListVO.getMfgPartNo();
        return R.ok(wmsPkgInfoService.getMfgNameList(orgCode, plantCode, partNo, mfgPartNo));
    }

    @ApiOperation("条码列印(新)")
    @PostMapping("/pkgPrint")
    public R<PkgPrintDTO> pkgPrint(@RequestBody PkgInfoPrintVO pkgInfoPrintVO) {
        return R.ok(wmsPkgInfoService.pkgPrint(pkgInfoPrintVO));
    }

    @ApiOperation("LCR扫描PKGID")
    @GetMapping("/scanLCRPkgid")
    public R<ScanLCRPkgidDTO> scanLCRPkgid(@RequestParam("orgCode") String orgCode,
                                           @RequestParam("pkgId") String pkgId) {
        return R.ok(wmsPkgInfoService.scanLCRPkgid(orgCode, pkgId));
    }

    @ApiOperation("校验LCR测量值")
    @PostMapping("/checkLCRVal")
    public R<Void> checkLCRVal(@RequestBody LCRFeignVO lcrFeignVO) {
        return wmsPkgInfoService.checkLCRVal(lcrFeignVO);
    }

    @ApiOperation("LCR结果")
    @GetMapping("/lcrResult")
    public R<LCRResultDTO> lcrResult(@RequestParam("orgCode") String orgCode,
                                     @RequestParam("pkgId") String pkgId) {
        return R.ok(wmsPkgInfoService.lcrResult(orgCode, pkgId));
    }

    @ApiOperation("清除LCR")
    @PostMapping("/clearLCRVal")
    public R<Void> clearLCRVal(@RequestBody ClearLcrVO clearLcrVO) {
        wmsPkgInfoService.clearLCRVal(clearLcrVO);
        return R.ok();
    }

    @ApiOperation("app查询条码打印信息")
    @PostMapping("/app/printInfoList")
    public R<PkgPrintZplDTO> selectPrintInfo(@RequestBody PkgInfoPrintVO pkgInfoPrintVO) {
        return R.ok(wmsPkgInfoService.printPkgInfoByZpl(pkgInfoPrintVO));
    }

    @ApiOperation(value = "pkg现况")
    @GetMapping("/pkgLocation")
    public R<PkgLocationDTO> pkgLocation(@RequestParam(value = "orgCode") String orgCode,
                                         @RequestParam(value = "pkgId") String pkgId) {
        return R.ok(wmsPkgInfoService.pkgLocation(orgCode, pkgId));
    }

    @ApiOperation(value = "生成pkgid")
    @GetMapping("/generatePkgId")
    public R<String> generatePkgId() {
        return R.ok(MessageUtils.get(ResultCode.SUCCESS.getLocalCode()), wmsPkgInfoService.generatePkgId());
    }

    @ApiOperation(value = "成品hold查询分布")
    @PostMapping("/qholdProductList")
    public R<PageDataDTO<QholdProductDTO>> qholdProductList(@RequestBody QholdProductVO qholdProductVO) {
        return R.ok(wmsPkgInfoService.qholdProductList(qholdProductVO));
    }

    @ApiOperation(value = "成品hold查询子分布")
    @PostMapping("/qholdProductChildList")
    public R<PageDataDTO<QholdProductChildDTO>> qholdProductChildList(@RequestBody QholdProductChildVO qholdProductChildVO) {
        return R.ok(wmsPkgInfoService.qholdProductChildList(qholdProductChildVO));
    }

    @ApiOperation(value = "成品hold根据分布条件查询所有子分布不分页")
    @PostMapping("/qholdProductChildListData")
    public R<List<QholdProductChildDTO>> qholdProductChildListData(@RequestBody QholdProductVO qholdProductVO) {
        return R.ok(wmsPkgInfoService.qholdProductChildListData(qholdProductVO));
    }

    @ApiOperation(value = "成品hold锁定")
    @PostMapping("/qholdProductLock")
    public R<Void> qholdProductLock(@RequestBody QholdProductLockVO qholdProductLockVO) {
        wmsPkgInfoService.qholdProductLock(qholdProductLockVO);
        return R.ok();
    }

    @ApiOperation(value = "查询待解锁SN")
    @PostMapping("/selectQholdProductLockList")
    public R<PageDataDTO<QholdProductLockDTO>> selectQholdProductLockList(@RequestBody ExportProductHoldVO vo) {
        return R.ok(wmsPkgInfoService.selectQholdProductLockList(vo));
    }

    @ApiOperation(value = "查询待解锁SN")
    @PostMapping("/selectQholdProductList")
    public R<List<QholdProductLockDTO>> selectQholdProductList(@RequestBody ExportProductHoldVO vo) {
        return R.ok(wmsPkgInfoService.selectQholdProductList(vo));
    }

    @ApiOperation(value = "成品hold解锁")
    @PostMapping("/qholdProductUnlock")
    public R<Void> qholdProductUnlock(@RequestBody QholdProductUnlockVO qholdProductUnlockVO) {
        wmsPkgInfoService.qholdProductUnlock(qholdProductUnlockVO);
        return R.ok();
    }

    @ApiOperation("成品hold导出")
    @PostMapping("/exportProductHold")
    public R<Void> exportProductHold(HttpServletResponse response,
                                     @RequestBody ExportProductHoldVO exportVO) {
        wmsPkgInfoService.exportProductHold(response, exportVO);
        return R.ok();
    }

    @ApiOperation("成品hold子分布导出")
    @PostMapping("/exportProductHoldChild")
    public R<Void> exportProductHoldChild(HttpServletResponse response,
                                          @RequestBody QholdProductChildVO exportVO) {
        wmsPkgInfoService.exportProductHoldChild(response, exportVO);
        return R.ok();
    }

    @ApiOperation("CMB-PDA打印六合一条码")
    @PostMapping("/app/printCmbSixInOneByZpl")
    public R<PrintCmbSixInOneByZplDTO> printCmbSixInOneByZpl(@RequestBody PrintCmbSixInOneByZplVO vo){
        return R.ok(wmsPkgInfoService.printCmbSixInOneByZpl(vo));
    }

    @ApiOperation("DC过期预警导出")
    @GetMapping("/expireWarninglistExport")
    public void expireWarninglistExport(PkgInfoExpireWarningVO pkgInfoExpireWarningVO, HttpServletResponse response) {
        wmsPkgInfoService.expireWarninglistExport(pkgInfoExpireWarningVO, response);
    }

    @ApiOperation("app查询重印条码打印信息")
    @PostMapping("/app/rePrintInfoList")
    public R<PkgPrintZplDTO> rePrintInfoList(@RequestBody PkgInfoPrintVO pkgInfoPrintVO) {
        return R.ok(wmsPkgInfoService.rePrintPkgInfoByZpl(pkgInfoPrintVO));
    }

    @ApiOperation("PDA库外条码列印")
    @PostMapping("/app/printOutStockByZpl")
    public R<PrintOutStockByZplDTO> printOutStockByZpl(@RequestBody PrintOutStockByZplVO vo){
        return R.ok(wmsPkgInfoService.printOutStockByZpl(vo));
    }

    @ApiOperation("锁定LCR测值")
    @PostMapping("/lockLCRPkgid")
    public R lockLCRPkgid(@RequestBody LockLCRPkgidVO vo){
        wmsPkgInfoService.lockLCRPkgid(vo);
        return R.ok();
    }

    @ApiOperation("解锁LCR测值")
    @PostMapping("/datahub/unLockLcr")
    public R unLockLcr(@RequestBody UnLockLcrVO vo){
        wmsPkgInfoService.unLockLcr(vo);
        return R.ok();
    }
}





