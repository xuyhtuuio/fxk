package com.maxnerva.cloudmes.controller.assyprepare.cmb;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.assyprepare.StampBarcodeScanDTO;
import com.maxnerva.cloudmes.models.dto.assyprepare.StampBinScanDTO;
import com.maxnerva.cloudmes.models.dto.instorage.ProductInStorageDTO;
import com.maxnerva.cloudmes.models.vo.assyprepare.StampBinScanVO;
import com.maxnerva.cloudmes.models.vo.instorage.ProductInStorageVO;
import com.maxnerva.cloudmes.service.assyprepare.cmb.MesProductInStorageService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @ClassName MesProductInStorageController
 * @Description TODO
 * @Author Likun
 * @Date 2025/3/12
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "MES采集入库")
@Slf4j
@RestController
@RequestMapping("/mesProductInStorage")
public class MesProductInStorageController {

    @Resource
    private MesProductInStorageService mesProductInStorageService;

    @ApiOperation("扫描barCode")
    @GetMapping("/scanBarCode")
    public R<StampBarcodeScanDTO> scanBarCode(@ApiParam(value = "barCode", required = true)
                                               @RequestParam("barCode") String barCode,
                                               @ApiParam(value = "工厂组织", required = true)
                                               @RequestParam("orgCode") String orgCode){
        return R.ok(mesProductInStorageService.scanBarCode(barCode, orgCode));
    }

    @ApiOperation("扫描储位")
    @PostMapping("/scanBinCode")
    public R<StampBinScanDTO> scanBinCode(@RequestBody StampBinScanVO stampBinScanVO){
        return R.ok(mesProductInStorageService.scanBinCode(stampBinScanVO));
    }

    @ApiOperation("采集入库提交")
    @PostMapping("/inStorage")
    public R<ProductInStorageDTO> inStorage(@RequestBody ProductInStorageVO productInStorageVO){
        productInStorageVO.setDataSource("MES");
        return mesProductInStorageService.inStorage(productInStorageVO);
    }
}
