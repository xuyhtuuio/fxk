package com.maxnerva.cloudmes.controller.doc;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.doc.JitReceiveGrDTO;
import com.maxnerva.cloudmes.models.vo.doc.JitReceiveGrVO;
import com.maxnerva.cloudmes.models.vo.warehouse.ScanPkgJitReceiveVO;
import com.maxnerva.cloudmes.service.doc.IJitReceiveGrService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @ClassName JitReceiveController
 * @Description TODO
 * @Author Likun
 * @Date 2025/2/13
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "JIT收货管理")
@Slf4j
@RestController
@RequestMapping("/jitReceive")
public class JitReceiveController {

    @Resource
    private IJitReceiveGrService jitReceiveGrService;

    @ApiOperation("JIT收货提交")
    @PostMapping("/submit")
    public R<JitReceiveGrDTO> submit(@RequestBody JitReceiveGrVO jitReceiveGrVO){
        return R.ok(jitReceiveGrService.submit(jitReceiveGrVO));
    }

    @ApiOperation("JIT信息采集")
    @PostMapping("/scanPkg")
    public R<Void> scanPkg(@RequestBody ScanPkgJitReceiveVO scanPkgJitReceiveVO){
        jitReceiveGrService.scanPkg(scanPkgJitReceiveVO);
        return R.ok();
    }

}
