package com.maxnerva.cloudmes.controller.kitting;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.kitting.LabelTranferableDTO;
import com.maxnerva.cloudmes.models.vo.kitting.LabelTransferableByPkgVO;
import com.maxnerva.cloudmes.models.vo.kitting.LabelTransferableVO;
import com.maxnerva.cloudmes.service.kitting.ILabelService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author MFQ
 * @date 2023/11/10 上午 11:21
 */
@Api(tags = "lable管理")
@Slf4j
@RestController
@RequestMapping("/label")
public class LabelController {

    @Resource
    private ILabelService lableService;

    @ApiOperation("查询可移转工单")
    @PostMapping("/getTransferableWorkOrder")
    public R<PageDataDTO<LabelTranferableDTO>> getTransferableWorkOrder(@RequestBody LabelTransferableVO lableTransferableVO) {
        return R.ok(lableService.getTransferableWorkOrder(lableTransferableVO));
    }


    @ApiOperation("移转工单")
    @PostMapping("/getTransferWorkOrder")
    public R<Void> getTransferWorkOrder(@RequestBody List<Integer> idList) {
        lableService.getTransferWorkOrder(idList);
        return R.ok();
    }

    @ApiOperation("查询可移转工单BY pkgid")
    @PostMapping("/getTransferableWorkOrderByPkg")
    public R<LabelTranferableDTO> getTransferableWorkOrderByPkg(@RequestBody LabelTransferableByPkgVO labelTransferableByPkgVO) {
        return R.ok(lableService.getTransferableWorkOrderByPkg(labelTransferableByPkgVO));
    }

    @ApiOperation("移转工单BY pkgid")
    @PostMapping("/getTransferWorkOrderByPkg")
    public  R<List<LabelTranferableDTO>> getTransferWorkOrderByPkg(@RequestBody LabelTransferableByPkgVO labelTransferableByPkgVO) {
        return R.ok(lableService.getTransferWorkOrderByPkg(labelTransferableByPkgVO));
    }
}
