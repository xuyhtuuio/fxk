package com.maxnerva.cloudmes.controller.doc;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.excel.util.DataSourceUtil;
import com.maxnerva.cloudmes.models.vo.doc.WmsFlownetApprovalVo;
import com.maxnerva.cloudmes.service.doc.IWmsInterFactoryTransferService;
import com.maxnerva.cloudmes.service.doc.IWmsTransferOrderService;
import com.maxnerva.cloudmes.service.lock.LockService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName WmsInterFactoryTransferController
 * @Description TODO
 * @Author Cuiyunhao
 * @Date 2025/4/28 下午 02:00
 * @Version 1.0
 **/

@Api(tags = "跨工廠转仓单管理")
@Slf4j
@RestController
@RequestMapping("/interFactoryTransfer")
public class WmsInterFactoryTransferController {

    @Resource
    private IWmsTransferOrderService wmsTransferOrderService;

    @Resource
    private IWmsInterFactoryTransferService wmsInterFactoryTransferService;

    @Resource
    private LockService lockService;

    @ApiOperation("Flownet审核完成调用服务节点")
    @PostMapping("/approvalCompleted")
    public R<Void> approvalCompleted(@RequestBody String jsonString) {
        log.info("Flownet input parameter=========》：::requestJson={}", jsonString);
        DataSourceUtil.setWmsDataSource();
        wmsInterFactoryTransferService.approvalCompleted(jsonString);
        return R.ok();
    }

    @ApiOperation(value = "Flownet审核完成")
    @PostMapping("/flownetApproval")
    public R<Void> flownetApproval(@RequestBody List<WmsFlownetApprovalVo> wmsFlownetApprovalVoList) {
        wmsInterFactoryTransferService.flownetApproval(wmsFlownetApprovalVoList);
        return R.ok();
    }
}
