package com.maxnerva.cloudmes.controller.printer;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.CommonPrintZplDTO;
import com.maxnerva.cloudmes.models.vo.basic.PrinterAlignmentVO;
import com.maxnerva.cloudmes.service.basic.IPrinterService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(tags = "打印机管理")
@Slf4j
@RestController
@RequestMapping("/printer")
public class PrinterController {

    @Autowired
    IPrinterService printerService;

    @ApiOperation("打印机校准")
    @GetMapping("/alignment")
    R<CommonPrintZplDTO> alignment(PrinterAlignmentVO vo) {
        return R.ok(printerService.alignment(vo));
    }
}
