package com.maxnerva.cloudmes.controller.deliver;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.entity.deliver.WmsCkdShipContainerInfo;
import com.maxnerva.cloudmes.models.dto.deliver.WmsCkdShipContainerDnDataDTO;
import com.maxnerva.cloudmes.models.dto.deliver.WmsCkdShipContainerInfoDTO;
import com.maxnerva.cloudmes.models.dto.deliver.WmsCkdShipDnBindDnDTO;
import com.maxnerva.cloudmes.models.vo.deliver.*;
import com.maxnerva.cloudmes.service.deliver.IWmsCkdShipContainerInfoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Api(tags = "CKD货柜信息")
@Slf4j
@RestController
@RequestMapping("/ckdContainer")
public class WmsCkdShipContainerInfoController {

    @Autowired
    IWmsCkdShipContainerInfoService wmsCkdShipContainerInfoService;

    @ApiOperation("货柜信息列表查询")
    @PostMapping("/list")
    public R<PageDataDTO<WmsCkdShipContainerInfoDTO>> selectPage(@RequestBody CkdShipContainerPageQueryVO pageQueryVO) {
        return R.ok(wmsCkdShipContainerInfoService.selectPageList(pageQueryVO));
    }

    @ApiOperation("货柜已绑定出货序列号信息列表查询")
    @PostMapping("/selectDnByContainerNo")
    public R<WmsCkdShipContainerDnDataDTO> selectDnByContainerNo(@RequestBody CkdShipDnContainerNoVO vo) {
        return R.ok(wmsCkdShipContainerInfoService.selectDnByContainerNo(vo, Boolean.TRUE));
    }

    @ApiOperation("货柜已绑定出货序列号信息导出")
    @PostMapping("/selectDnByContainerNoExport")
    public void selectDnByContainerNoExport(@RequestBody CkdShipDnContainerNoVO vo, HttpServletResponse response){
        wmsCkdShipContainerInfoService.selectDnByContainerNoExport(vo, response);
    }

    @ApiOperation("新增货柜信息")
    @PostMapping("/add")
    public R<Void> add(@RequestBody CkdShipContainerSaveVO saveVO) {
        wmsCkdShipContainerInfoService.add(saveVO);
        return R.ok();
    }

    @ApiOperation("绑定DN查询货柜信息")
    @PostMapping("/selectContainerInfo")
    public R<List<WmsCkdShipContainerInfo>> selectContainerInfo(@RequestBody CkdShipContainerVO vo) {
        return R.ok(wmsCkdShipContainerInfoService.selectContainerInfo(vo));
    }

    @ApiOperation("绑定DN查询出货单信息")
    @PostMapping("/selectDnShipInfo")
    public R<List<WmsCkdShipDnBindDnDTO>> selectDnShipInfo(@RequestBody CkdShipDnBindDnVO vo) {
        return R.ok(wmsCkdShipContainerInfoService.selectDnShipInfo(vo));
    }

    @ApiOperation("绑定DN提交")
    @PostMapping("/bindDn")
    public R<Void> bindDn(@RequestBody CkdShipContainerBindDnVO shipContainerBindDnVO) {
        wmsCkdShipContainerInfoService.bindDn(shipContainerBindDnVO);
        return R.ok();
    }

    @ApiOperation("离厂确认")
    @PostMapping("/leaveConfirm")
    public R<Void> leaveConfirm(@RequestBody CkdShipContainerLeaveConfirmVO leaveConfirmVO) {
        wmsCkdShipContainerInfoService.leaveConfirm(leaveConfirmVO);
        return R.ok();
    }

}
