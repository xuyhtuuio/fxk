package com.maxnerva.cloudmes.controller.prepare.outsourcing;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.prepare.AssemblePrepareInventoryDTO;
import com.maxnerva.cloudmes.models.dto.prepare.outsourcing.*;
import com.maxnerva.cloudmes.models.vo.prepare.AssemblePrepareInventoryVO;
import com.maxnerva.cloudmes.models.vo.prepare.outsourcing.*;
import com.maxnerva.cloudmes.service.prepare.outsourcing.*;
import com.sap.conn.jco.JCoException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @ClassName OutsourcingPrepareController
 * @Description 委外备料管理
 * @Author Likun
 * @Date 2023/11/30
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "委外备料管理")
@Slf4j
@RestController
@RequestMapping("/outsourcingPrepare")
public class OutsourcingPrepareController {

    @Resource
    private IWmsOutsourcingWorkOrderHeaderService wmsOutsourcingWorkOrderHeaderService;

    @Resource
    private IWmsOutsourcingWorkOrderDetailService wmsOutsourcingWorkOrderDetailService;

    @Resource
    private IWmsOutsourcingWorkOrderPrepareLogService wmsOutsourcingWorkOrderPrepareLogService;

    @Resource
    private IWmsOutsourcingPrepareService wmsOutsourcingPrepareService;

    @Resource
    private IWmsOutsourcingSapTransactionLogService wmsOutsourcingSapTransactionLogService;

    @ApiOperation("委外备料单头分页查询")
    @PostMapping("/outsourcingWoHeaderList")
    public R<PageDataDTO<OutsourcingWoHeaderDTO>> selectOutsourcingWoHeaderPage(
            @RequestBody OutsourcingWoHeaderQueryVO queryVO) {
        return R.ok(wmsOutsourcingWorkOrderHeaderService
                .selectOutsourcingWoHeaderPage(queryVO));
    }

    @ApiOperation("委外备料po信息同步")
    @PostMapping("/syncPoHeaderAndDetail")
    public R<Void> syncPoHeaderAndDetail(@RequestBody OutsourcingWoInfoSyncVO syncVO) throws JCoException {
        wmsOutsourcingWorkOrderHeaderService.syncPoHeaderAndDetail(syncVO);
        return R.ok();
    }

    @ApiOperation("委外入库")
    @PostMapping("/inStorage")
    public R<Void> inStorage(@RequestBody OutsourcingWoInStorageVO inStorageVO) {
        wmsOutsourcingWorkOrderHeaderService.inStorage(inStorageVO);
        return R.ok();
    }

    @ApiOperation("委外备料单身分页查询")
    @PostMapping("/outsourcingWoDetailList")
    public R<PageDataDTO<OutsourcingWoDetailDTO>> selectOutsourcingWoDetailPage(
            @RequestBody OutsourcingWoDetailQueryVO queryVO) {
        return R.ok(wmsOutsourcingWorkOrderDetailService
                .selectOutsourcingWoDetailPage(queryVO));
    }

    @ApiOperation("委外备料提交")
    @PostMapping("/prepareDirect")
    public R<Void> prepareDirect(@RequestBody OutsourcingPrepareVO outsourcingPrepareVO) {
        wmsOutsourcingPrepareService.prepareDirect(outsourcingPrepareVO);
        return R.ok();
    }

    @ApiOperation("委外备料清单分页查询")
    @PostMapping("/outsourcingPrepareList")
    public R<PageDataDTO<OutsourcingWoPrepareLogDTO>> selectOutsourcingPreparePage(
            @RequestBody OutsourcingWoPrepareLogQueryVO queryVO) {
        return R.ok(wmsOutsourcingWorkOrderPrepareLogService
                .selectOutsourcingPreparePage(queryVO));
    }

    @ApiOperation("委外备料清单excel导出")
    @PostMapping("/exportOutsourcingPrepareLog")
    public void exportPrepareLog(HttpServletResponse response,
                                 @RequestBody OutsourcingWoPrepareLogQueryVO pageQueryVO) {
        wmsOutsourcingWorkOrderPrepareLogService.exportOutsourcingPrepareLog(response, pageQueryVO);
    }

    @ApiOperation("委外备料确认过账清单查询")
    @PostMapping("/outsourcingConfirmPostingList")
    public R<PageDataDTO<OutsourcingConfirmPostingDTO>> selectOutsourcingWoDetailPage(
            @RequestBody OutsourcingPostingQueryVO queryVO) {
        return R.ok(wmsOutsourcingWorkOrderDetailService
                .selectConfirmPostingPage(queryVO));
    }

    @ApiOperation("委外备料确认过账")
    @PostMapping("/confirmPosting")
    public R<Void> confirmPosting(@RequestBody OutsourcingConfirmPostingVO confirmPostingVO) {
        wmsOutsourcingPrepareService.confirmPosting(confirmPostingVO);
        return R.ok();
    }

    @ApiOperation("委外过账清单查询")
    @PostMapping("/outsourcingSapTransactionLogList")
    public R<PageDataDTO<OutsourcingSapTransactionLogDTO>> selectTransactionLogPage(
            @RequestBody OutsourcingSapTransactionLogQueryVO queryVO) {
        return R.ok(wmsOutsourcingSapTransactionLogService
                .selectTransactionLogPage(queryVO));
    }

    @ApiOperation("查询库存信息")
    @PostMapping("/inventoryList")
    public R<List<AssemblePrepareInventoryDTO>> selectInventoryInfo(
            @RequestBody AssemblePrepareInventoryVO assemblePrepareInventoryVO) {
        return R.ok(wmsOutsourcingPrepareService.selectInventoryInfo(assemblePrepareInventoryVO));
    }
}
