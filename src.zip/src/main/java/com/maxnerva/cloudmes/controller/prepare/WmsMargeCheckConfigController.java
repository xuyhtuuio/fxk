package com.maxnerva.cloudmes.controller.prepare;

import com.maxnerva.cloudmes.aspect.FactoryOperationLog;
import com.maxnerva.cloudmes.common.constant.OperationTypeConstant;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.prepare.MargeCheckConfigDTO;
import com.maxnerva.cloudmes.models.vo.ExcelImportVO;
import com.maxnerva.cloudmes.models.vo.prepare.MargeCheckConfigQueryVO;
import com.maxnerva.cloudmes.models.vo.prepare.MargeCheckConfigVO;
import com.maxnerva.cloudmes.service.prepare.IWmsMargeCheckConfigService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName WmsMargeCheckConfigController
 * @Description 合盘check配置管理
 * @Author Likun
 * @Date 2023/8/21
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "合盘check配置管理")
@Slf4j
@RestController
@RequestMapping("/margeCheckConfig")
public class WmsMargeCheckConfigController {

    @Resource
    private IWmsMargeCheckConfigService wmsMargeCheckConfigService;

    @ApiOperation(value = "新增合盘check配置信息")
    @PostMapping("/add")
    @FactoryOperationLog(operationType = OperationTypeConstant.ADD, description = "新增合盘check配置信息")
    public R<Void> saveMargeCheckConfig(@RequestBody MargeCheckConfigVO margeCheckConfigVO) {
        wmsMargeCheckConfigService.saveMargeCheckConfig(margeCheckConfigVO);
        return R.ok();
    }

    @ApiOperation("修改合盘check配置信息")
    @PutMapping("/update")
    @FactoryOperationLog(operationType = OperationTypeConstant.MODIFY, description = "修改合盘check配置信息")
    public R<Void> updateMargeCheckConfig(@RequestBody MargeCheckConfigVO margeCheckConfigVO) {
        wmsMargeCheckConfigService.updateMargeCheckConfig(margeCheckConfigVO);
        return R.ok();
    }

    @ApiOperation("删除合盘check配置信息")
    @DeleteMapping("/delete")
    @FactoryOperationLog(operationType = OperationTypeConstant.DELETE, description = "删除合盘check配置信息")
    public R<Void> deleteMargeCheckConfig(@RequestBody List<Integer> idList) {
        wmsMargeCheckConfigService.deleteMargeCheckConfigBatch(idList);
        return R.ok();
    }

    @ApiOperation("查询合盘check配置信息")
    @PostMapping("/list")
    public R<PageDataDTO<MargeCheckConfigDTO>> selectList(@RequestBody MargeCheckConfigQueryVO queryVO) {
        return R.ok(wmsMargeCheckConfigService.selectMargeCheckConfigPage(queryVO));
    }

    @ApiOperation("导入")
    @PostMapping("/import")
    public R<Void> importMargeCheckConfig(ExcelImportVO excelImportVO) {
        wmsMargeCheckConfigService.importMargeCheckConfig(excelImportVO.getFile(), excelImportVO.getOrgCode());
        return R.ok();
    }
}
