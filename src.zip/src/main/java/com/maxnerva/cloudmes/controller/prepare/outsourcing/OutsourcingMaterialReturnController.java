package com.maxnerva.cloudmes.controller.prepare.outsourcing;

import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.prepare.outsourcing.MaterialReturnDTO;
import com.maxnerva.cloudmes.models.dto.warehouse.PkgPrintZplDTO;
import com.maxnerva.cloudmes.models.vo.prepare.outsourcing.MaterialReturnPrintPkgVO;
import com.maxnerva.cloudmes.models.vo.prepare.outsourcing.MaterialReturnSubmitVO;
import com.maxnerva.cloudmes.service.prepare.outsourcing.IOutsourcingMaterialReturnService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @ClassName OutsourcingMaterialReturnController
 * @Description TODO
 * @Author Likun
 * @Date 2025/7/3
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "委外退料管理")
@Slf4j
@RestController
@RequestMapping("/outsourcingMaterialReturn")
public class OutsourcingMaterialReturnController {

    @Resource
    private IOutsourcingMaterialReturnService wmsOutsourcingMaterialReturnService;

    @ApiOperation("委外退料提交")
    @PostMapping("/submit")
    public R<MaterialReturnDTO> submit(@RequestBody MaterialReturnSubmitVO submitVO){
       return R.ok(wmsOutsourcingMaterialReturnService.submit(submitVO));
    }

    @ApiOperation("委外退料条码zpl打印")
    @PostMapping("/print")
    public R<PkgPrintZplDTO> printReturnPkg(@RequestBody MaterialReturnPrintPkgVO printPkgVO){
        return R.ok(wmsOutsourcingMaterialReturnService.printReturnPkg(printPkgVO));
    }
}
