package com.maxnerva.cloudmes.controller.pulllist;

import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.models.dto.pulllist.PulllistDetailDTO;
import com.maxnerva.cloudmes.models.dto.pulllist.PulllistHeaderDTO;
import com.maxnerva.cloudmes.models.vo.pulllist.PulllistDetailQueryVO;
import com.maxnerva.cloudmes.models.vo.pulllist.PulllistExcelImportVO;
import com.maxnerva.cloudmes.models.vo.pulllist.PulllistHeaderQueryVO;
import com.maxnerva.cloudmes.models.vo.wo.PullListPostJusdaVO;
import com.maxnerva.cloudmes.service.pulllist.IWmsJusdaPulllistDetailService;
import com.maxnerva.cloudmes.service.pulllist.IWmsJusdaPulllistHeaderService;
import com.maxnerva.cloudmes.service.wo.IWmsWorkOrderDetailShortageDetailService;
import com.maxnerva.cloudmes.service.wo.IWoPrepareService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @ClassName PulllistController
 * @Description pulllist管理
 * @Author Likun
 * @Date 2022/12/19
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Api(tags = "pulllist管理")
@Slf4j
@RestController
@RequestMapping("/pulllist")
public class PulllistController {

    @Resource
    private IWmsJusdaPulllistHeaderService wmsJusdaPulllistHeaderService;

    @Resource
    private IWmsWorkOrderDetailShortageDetailService wmsWorkOrderDetailShortageDetailService;

    @Resource
    private IWoPrepareService woPrepareService;

    @Resource
    private IWmsJusdaPulllistDetailService wmsJusdaPulllistDetailService;

    @ApiOperation("pulllist 导入")
    @PostMapping("/import")
    public R<Void> importPulllist(PulllistExcelImportVO excelImportVO) {
        wmsJusdaPulllistHeaderService.importPulllist(excelImportVO);
        return R.ok();
    }

    @ApiOperation("查询pulllist header")
    @PostMapping("/headList")
    public R<PageDataDTO<PulllistHeaderDTO>> selectHeaderPage(@RequestBody PulllistHeaderQueryVO queryVO) {
        return R.ok(wmsJusdaPulllistHeaderService.selectHeaderPage(queryVO));
    }

    @ApiOperation("查询pulllist detail")
    @PostMapping("/detailList")
    public R<PageDataDTO<PulllistDetailDTO>> selectDetailPage(@RequestBody PulllistDetailQueryVO pageQueryVO) {
        return R.ok(wmsWorkOrderDetailShortageDetailService.selectPulllistShortageDetailPage(pageQueryVO));
    }

    @ApiOperation("删除pulllist detail")
    @PostMapping("/delDetailList")
    public R<Void> delDetailList(@RequestBody List<Integer> idList) {
        wmsJusdaPulllistDetailService.delDetailList(idList);
        return R.ok();
    }

    @ApiOperation("pulllist抛jusda")
    @PostMapping("/pullistPostJusda")
    public R<Void> pullistPostJusda(@RequestBody PullListPostJusdaVO postJusdaVO) {
        woPrepareService.pullistPostJusda(postJusdaVO);
        return R.ok();
    }

    @ApiOperation("pulllist详情导出")
    @PostMapping("/exportPulllistDetail")
    public R<Void> exportPulllistDetail(HttpServletResponse response,
                                       @RequestBody PulllistDetailQueryVO queryVO) {
        wmsWorkOrderDetailShortageDetailService.exportPulllistDetail(response, queryVO);
        return R.ok();
    }

}
