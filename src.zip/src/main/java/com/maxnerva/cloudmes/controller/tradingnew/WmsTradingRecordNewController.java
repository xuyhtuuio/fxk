package com.maxnerva.cloudmes.controller.tradingnew;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.maxnerva.cloudmes.common.models.dto.PageDataDTO;
import com.maxnerva.cloudmes.common.utils.R;
import com.maxnerva.cloudmes.entity.trading.WmsTradingRecord;
import com.maxnerva.cloudmes.models.dto.basic.SelectDTO;
import com.maxnerva.cloudmes.models.dto.basic.WmsSapWarehouseCodeDTO;
import com.maxnerva.cloudmes.models.dto.trading.*;
import com.maxnerva.cloudmes.models.dto.warehouse.PkgPrintDTO;
import com.maxnerva.cloudmes.models.vo.doc.JusdaSelectVo;
import com.maxnerva.cloudmes.models.vo.trading.*;
import com.maxnerva.cloudmes.service.tradingnew.IWmsTradingRecordServiceNew;
import com.sap.conn.jco.JCoException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.util.List;

/**
 * @author sclq
 * @date 2022/9/23 17:56
 */
@Api(tags = "内交单据")
@Slf4j
@RestController
@RequestMapping("/tradingRecordNew")
public class WmsTradingRecordNewController {

    @Resource
    private IWmsTradingRecordServiceNew wmsTradingRecordService;

    @ApiOperation("条件查询")
    @GetMapping("/deliveryList")
    public R<PageDataDTO<WmsTradingRecordDTO>> pageList(TradingRecordPageQueryVo queryVo) {
        Page page = PageHelper.startPage(queryVo.getPageIndex(), queryVo.getPageSize());
        List<WmsTradingRecordDTO> recordDTOList = wmsTradingRecordService.selectPageList(queryVo);
        PageDataDTO<WmsTradingRecordDTO> partRelationDTOPageDataDTO = new PageDataDTO<>(page.getTotal(), recordDTOList);
        return R.ok(partRelationDTOPageDataDTO);
    }

    @ApiOperation("内交出库新增")
    @PostMapping("/saveDelivery")
    public R<Void> save(@RequestBody TradingRecordDeliverySaveVO tradingRecordSaveVO) throws JCoException {
        wmsTradingRecordService.saveDelivery(tradingRecordSaveVO);
        return R.ok();
    }

    @ApiOperation("内交出库单信息")
    @GetMapping("/editInfo")
    public R<WmsTradingRecord> editInfo(Integer id) {
        return R.ok(wmsTradingRecordService.editInfo(id));
    }

    @ApiOperation("修改内交单详情")
    @GetMapping("/updateInfo")
    public R<TradingUpdateInfoDTO> updateInfo(@RequestParam("id") Integer id) {
        return R.ok(wmsTradingRecordService.updateInfo(id));
    }

    @ApiOperation("修改内交单信息")
    @PostMapping("/updateDelivery")
    public R<Void> updateDelivery(@RequestBody TradingRecordModifyVO tradingRecordModifyVO) {
        wmsTradingRecordService.updateDelivery(tradingRecordModifyVO);
        return R.ok();
    }

    @ApiOperation("复制内交单")
    @GetMapping("/copy")
    public R<Void> save(@RequestParam(value = "id", required = true) Integer id,
                        @RequestParam(value = "tradingQty", required = true) BigDecimal qty) {
        wmsTradingRecordService.copy(id, qty);
        return R.ok();
    }

    @ApiOperation("内交出")
    @GetMapping("/tradingOut")
    public R<Void> tradingOut(@RequestParam(value = "id") Integer id) {
        wmsTradingRecordService.tradingOut(id);
        return R.ok();
    }

    @Deprecated
    @ApiOperation("PGI")
    @GetMapping("/doPgi")
    public R<Void> doPgi(@RequestParam(value = "id", required = true) Integer id) {
        wmsTradingRecordService.doPgi(id);
        return R.ok();
    }

    @ApiOperation("出货推荐储位")
    @GetMapping("/recommendBin")
    public R<PageDataDTO<WmsTradingRecommendBinDTO>> recommendBin(TradingRecommendBinVO recommendBinVO) {
        Page page = PageHelper.startPage(recommendBinVO.getPageIndex(), recommendBinVO.getPageSize());
        List<WmsTradingRecommendBinDTO> recordDTOList = wmsTradingRecordService.recommendBin(recommendBinVO);
        PageDataDTO<WmsTradingRecommendBinDTO> partRelationDTOPageDataDTO = new PageDataDTO<>(page.getTotal(), recordDTOList);
        return R.ok(partRelationDTOPageDataDTO);
    }

    @ApiOperation("删除内交单信息")
    @PostMapping("/deleteByIds")
    public R<Void> deleteByIds(@RequestBody List<Integer> ids) {
        wmsTradingRecordService.deleteByIds(ids);
        return R.ok();
    }

    @ApiOperation("内交入库新增")
    @PostMapping("/saveEntry")
    public R<Void> saveEntry(@RequestBody TradingRecordEntrySaveVO entrySaveVO) {
        wmsTradingRecordService.saveEntry(entrySaveVO);
        return R.ok();
    }

    @ApiOperation("查询内交入信息")
    @GetMapping("/getTradingInInfo")
    public R<WmsTradingRecordDTO> getTradingInInfo(@RequestParam("id") Integer id,
                                                   @RequestParam("toPlantCode") String toPlantCode,
                                                   @RequestParam("toPartNo") String toPartNo) throws JCoException {
        return R.ok(wmsTradingRecordService.getTradingInInfo(id, toPlantCode, toPartNo));
    }

    @ApiOperation("内交确认")
    @PostMapping("/tradingIn")
    public R<Void> tradingIn(@RequestBody TradingRecordEntryVO tradingRecordEntryVO) {
        wmsTradingRecordService.tradingIn(tradingRecordEntryVO);
        return R.ok();
    }

    @ApiOperation("出货扫描详情")
    @GetMapping("/deliveryInfo")
    public R<TradingDeliveryDTO> deliveryInfo(@RequestParam("id") Integer id) {
        return R.ok(wmsTradingRecordService.deliveryInfo(id));
    }

    @ApiOperation("出货采集详情")
    @GetMapping("/deliveryCollectInfo")
    public R<TradingDeliveryCollectDTO> deliveryCollectInfo(@RequestParam("id") Integer id) {
        return R.ok(wmsTradingRecordService.deliveryCollectInfo(id));
    }

    @ApiOperation("出货-扫描")
    @PostMapping("/delivery")
    public R<Void> delivery(@RequestBody TradingRecordDeliveryVO deliveryVO) {
        wmsTradingRecordService.delivery(deliveryVO);
        return R.ok();
    }

    @ApiOperation("查询已出库数据")
    @GetMapping("/tradingDeliveryLogList")
    public R<PageDataDTO<WmsTradingDeliveryDTO>> recommendBin(@RequestParam("recordId") Integer recordId,
                                                              @RequestParam("orgCode") String orgCode,
                                                              @RequestParam("pageIndex") Integer pageIndex,
                                                              @RequestParam("pageSize") Integer pageSize) {
        WmsTradingDeliveryDTO dto = wmsTradingRecordService.tradingDeliveryLogList(recordId, orgCode, pageIndex, pageSize);
        return R.ok(dto);
    }

    @ApiOperation("入库")
    @PostMapping("/tradingShelf")
    public R<Void> tradingShelf(@RequestBody TradingRecordShelfVO recordShelfVO) {
        wmsTradingRecordService.tradingShelf(recordShelfVO);
        return R.ok();
    }

    @ApiOperation("查询条码打印信息")
    @PostMapping("/printTradingVehicle")
    public R<PrintVehicleDTO> printTradingVehicle(@RequestBody TradingPrintVehicleVO printVehicleVO) {
        return R.ok(wmsTradingRecordService.printTradingVehicle(printVehicleVO));
    }

    @ApiOperation("查询仓码保税性质")
    @GetMapping("/getWhCode")
    public R<WmsSapWarehouseCodeDTO> getWhCode(@RequestParam("fromOrgCode") String fromOrgCode,
                                               @RequestParam("fromPlantCode") String fromPlantCode,
                                               @RequestParam("fromWarehouseCode") String fromWarehouseCode) {
        return R.ok(wmsTradingRecordService.getWhCode(fromOrgCode, fromPlantCode, fromWarehouseCode));
    }

    @ApiOperation("打印内交单")
    @PostMapping("/printTradingInfo")
    public R<PrintTradingInfoDTO> printTradingInfo(@RequestBody List<Integer> idList) {
        return R.ok(wmsTradingRecordService.printTradingInfo(idList));
    }

    @ApiOperation("查询内交入工厂")
    @GetMapping("/getToPlantCode")
    public R<List<SelectDTO>> getToPlantCode(@RequestParam("fromOrgCode") String fromOrgCode,
                                             @RequestParam("fromPlantCode") String fromPlantCode,
                                             @RequestParam("tradingToOrgCode") String tradingToOrgCode) {
        return R.ok(wmsTradingRecordService.getToPlantCode(fromOrgCode, fromPlantCode, tradingToOrgCode));
    }

    @ApiOperation("查询内交入料号")
    @GetMapping("/getToPartNo")
    public R<ToPartNoDTO> getToPartNo(@RequestParam("fromOrgCode") String fromOrgCode,
                                      @RequestParam("partNo") String partNo,
                                      @RequestParam("tradingToOrgCode") String tradingToOrgCode,
                                      @RequestParam("toPlantCode") String toPlantCode) {
        return R.ok(wmsTradingRecordService.getToPartNo(fromOrgCode, partNo, tradingToOrgCode, toPlantCode));
    }

    @ApiOperation("查询出货是否需要扫描、打印")
    @GetMapping("/needScan")
    public R<NeedScanPrintDTO> needScan(@RequestParam("id") Integer id) {
        return R.ok(wmsTradingRecordService.needScan(id));
    }

    @ApiOperation("出货-采集")
    @PostMapping("/deliveryCollect")
    public R<Void> deliveryCollect(@RequestBody TradingRecordDeliveryVO deliveryVO) {
        wmsTradingRecordService.deliveryCollect(deliveryVO);
        return R.ok();
    }

    @ApiOperation("查询采集记录")
    @GetMapping("/selectCollectRecord")
    public R<PageDataDTO<CollectRecordDTO>> selectCollectRecord(CollectRecordPageVO pageQueryVO) {
        return R.ok(wmsTradingRecordService.selectCollectRecord(pageQueryVO));
    }

    @ApiOperation("查询采集总数")
    @GetMapping("/selectCollectQty")
    public R<BigDecimal> selectCollectQty(@RequestParam("id") Integer id) {
        return R.ok(wmsTradingRecordService.selectCollectQty(id));
    }

    @ApiOperation("查询条码打印信息")
    @PostMapping("/printInfo")
    public R<PkgPrintDTO> selectResources(@RequestBody TradingPkgInfoPrintVO pkgInfoPrintVO) {
        return R.ok(wmsTradingRecordService.printPkgInfo(pkgInfoPrintVO));
    }

    @ApiOperation("查询内交信息")
    @GetMapping("/tradingInfo")
    public R<WmsTradingInInfoDTO> tradingInfo(@RequestParam("id") Integer id) {
        return R.ok(wmsTradingRecordService.tradingInfo(id));
    }

    @ApiOperation("内交入导出")
    @PostMapping("/inExport")
    public R<Void> inExport(HttpServletResponse response,
                          @RequestBody TradingRecordPageQueryVo vo) {
        wmsTradingRecordService.inExport(response, vo);
        return R.ok();
    }

    @ApiOperation("内交出导出")
    @PostMapping("/outExport")
    public R<Void> outExport(HttpServletResponse response,
                            @RequestBody TradingRecordPageQueryVo vo) {
        wmsTradingRecordService.outExport(response, vo);
        return R.ok();
    }
}