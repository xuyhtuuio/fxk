package com.maxnerva.cloudmes.config;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import com.maxnerva.cloudmes.common.utils.WebContextUtil;
import com.maxnerva.cloudmes.entity.BaseEntity;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

/**
 * @ClassName MyMetaObjectHandler
 * @Description 自动填充拦截
 * @Author Likun
 * @Date 2022/7/20
 * @Version 1.0
 * @Since JDK 1.8
 **/
@Slf4j
@Component
public class MyBatisMetaObjectHandler implements MetaObjectHandler {
    @Override
    public void insertFill(MetaObject metaObject) {
        //如果不继承BaseEntity
        if (!(BaseEntity.class).isAssignableFrom(metaObject.getOriginalObject().getClass())) {
            return;
        }
        String userName = "syncadmin";
        try {
            if (ObjectUtil.isNotNull(WebContextUtil.getContext())
                    && !StrUtil.isEmpty(WebContextUtil.getCurrentStaffCode())) {
                userName = WebContextUtil.getCurrentStaffCode();
            }
        } catch (Exception e) {
            log.error("获取登录信息上下文异常:{}", e.getMessage());
            userName = "sysadmin";
        }
        this.setFieldValByName("creator", userName, metaObject);
        this.setFieldValByName("lastEditor", userName, metaObject);
        this.setFieldValByName("createdDt", LocalDateTime.now(), metaObject);
        this.setFieldValByName("lastEditedDt", LocalDateTime.now(), metaObject);
    }

    @Override
    public void updateFill(MetaObject metaObject) {
        //如果不继承BaseEntity
        if (!(BaseEntity.class).isAssignableFrom(metaObject.getOriginalObject().getClass())) {
            return;
        }
        String userName = "syncadmin";
        try {
            if (ObjectUtil.isNotNull(WebContextUtil.getContext())
                    && !StrUtil.isEmpty(WebContextUtil.getCurrentStaffCode())) {
                userName = WebContextUtil.getCurrentStaffCode();
            }
        } catch (Exception e) {
            log.error("获取登录信息上下文异常:{}", e.getMessage());
            userName = "sysadmin";
        }
        this.setFieldValByName("lastEditor", userName, metaObject);
        this.setFieldValByName("lastEditedDt", LocalDateTime.now(), metaObject);
    }
}
