package com.maxnerva.cloudmes.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

@RefreshScope
@Component
@Data
public class EcusConfig {

    @Value("${ecus.cus-url:}")
    private String cusUrl;

    @Value("${ecus.cus-p_cnn.bonded:}")
    private String cusBoundCnn;

    @Value("${ecus.cus-p_cnn.non-bonded:}")
    private String cusNonBoundCnn;

    @Value("${ecus.filing-p_cnn:}")
    private String filingCnn;

    @Value("${ecus.filing-url:}")
    private String filingUrl;
}
