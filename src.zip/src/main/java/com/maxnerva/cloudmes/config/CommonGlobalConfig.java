package com.maxnerva.cloudmes.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/**
 * @ClassName CommonGlobalConfig
 * @Description 通用全局配置加载
 * @Author Likun
 * @Date 2023/8/31
 * @Version 1.0
 * @Since JDK 1.8
 **/
@RefreshScope
@Component
@Data
public class CommonGlobalConfig {

    /**
     * 发料时间在当前日期上延长的天数  默认0
     */
    @Value("${delay.day:0}")
    private String delayDay;

    /**
     * 截止日期叠加天数
     */
    @Value("${endDate.addDay:0}")
    private String endDateAddDay;

    /**
     * rcs地址
     */
    @Value("${rcs.url:0}")
    private String rcsUrl;


    /**
     * EDI856 HPE SFC接口
     */
    @Value("${sfcSystem.hpeEdi856:0}")
    private String hpeEdiSfcUrl;
}
