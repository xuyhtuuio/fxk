package com.maxnerva.cloudmes.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/**
 * @ClassName DatahubConfig
 * @Description 服务节点地址配置类
 * @Author Likun
 * @Date 2023/9/13
 * @Version 1.0
 * @Since JDK 1.8
 **/
@RefreshScope
@Component
@Data
public class DataHubUrlConfig {

    @Value("${agileSystem.adjustApprovalCompleted:}")
    private String adjustApprovalCompletedUrl;

    @Value("${flownetSystem.flownetApprovalCompleted:}")
    private String flownetApprovalCompletedUrl;

    @Value("${flownetSystem.flownetTransferApprovalCompleted:}")
    private String flownetTransferApprovalCompletedUrl;

    @Value("${flownetSystem.flownetInterFactoryTransferApprovalCompleted:}")
    private String flownetInterFactoryTransferApprovalCompleted;

    @Value("${flownetSystem.flownetAdjustApprovalCompleted:}")
    private String flownetAdjustApprovalCompletedUrl;

    @Value("${mesSystem.shippingPassStation:}")
    private String shippingPassStationUrl;

    @Value("${mesSystem.getBurnValue:}")
    private String getBurnValueUrl;

    @Value("${mesSystem.queryFeignPkgInfo:}")
    private String queryFeignPkgInfoUrl;

    @Value("${machineSystem.returnOfMaterialByMachine:}")
    private String returnOfMaterialByMachineUrl;

    @Value("${basic.getMfgInfo:}")
    private String basicGetMfgInfoUrl;

    @Value("${mesSystem.queryWipPackSn:}")
    private String wipPackSnUrl;

    @Value("${jobs.passSnStation:}")
    private String passSnStationUrl;

    @Value("${qmsSystem.pkgidIsHold:}")
    private String pkgidIsHold;

    @Value("${mesSystem.queryCustomDataByMes:}")
    private String queryCustomDataByMes;

    @Value("${bigDataSystem.queryProductStoreInfo:}")
    private String queryProductStoreInfo;

    @Value("${mesSystem.syncMsd:}")
    private String syncMsd;

    @Value("${wmsSystem.ckdShipDetailSerialNo:}")
    private String ckdShipDetailSerialNo;

    @Value("${mesSystem.cartonsByPkgInfo:}")
    private String cartonsByPkgInfo;

    @Value("${mesSystem.returnStation:}")
    private String returnStation;

    @Value("${wmsSystem.scanLCRPkgid:}")
    private String scanLCRPkgid;

    @Value("${flownetSystem.flownetBadProductApprovalCompleted:}")
    private String flownetBadProductApprovalCompletedUrl;

    @Value("${spmSystem.getWmsSourceNo:}")
    private String getWmsSourceNo;

    @Value("${mesSystem.getBurnValueTemp:}")
    private String getBurnValueUrlTemp;

    @Value("${mesSystem.queryFeignPkgInfoTemp:}")
    private String queryFeignPkgInfoUrlTemp;

    @Value("${mesSystem.checkReturnPkgInfo:}")
    private String checkReturnPkgInfoUrl;

    @Value("${mesSystem.queryPkgLink:}")
    private String queryPkgLinkUrl;

    @Value("${mesSystem.deletePkgLink:}")
    private String deletePkgLinkUrl;

    @Value("${wmsSystem.replyByTcOrder:}")
    private String replyByTcOrderUrl;

    @Value("${bigDataSystem.querySfcDataInfo:}")
    private String querySfcDataInfo;

    @Value("${bigDataSystem.queryAwsShipInfo:}")
    private String queryAwsShipInfo;

    @Value("${wmsSystem.selectLrrReceiveSnInfo:}")
    private String selectLrrReceiveSnInfo;

    @Value("${mesSystem.getProductBySn:}")
    private String getProductBySnUrl;

    @Value("${bigDataSystem.queryMicrosoftDataInfo:}")
    private String queryMicrosoftDataInfo;

    @Value(("${qmsSystem.receptionData:}"))
    private String receptionDataUrl;

    @Value("${sdsSystem.syncWmsScrapHandlePallet:}")
    private String syncWmsScrapHandlePalletUrl;

    @Value("${mesSystem.getProductInfoByPn:}")
    private String productInfoByPn;

    @Value("${bigDataSystem.queryHpeLxShipInfo:}")
    private String queryHpeLxShipDataInfo;
    
    @Value("${qmsSystem.iqcDispatchData:}")
    private String iqcDispatchDataUrl;

    @Value("${bigDataSystem.queryDellShipInfo:}")
    private String queryDellShipInfo;

    @Value("${wmsSystem.receiveDsiInfo:}")
    private String receiveDsiInfo;
}
